<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
include_once(BASE_PATH."fileHandler/utils/ftpInfoUtilities.php");
include_once(BASE_PATH."fileHandler/utils/utilities.php");

//initialize obj
$ftpObj		=	new ftpInfoUtilities();
$utils		=	new utilities();

if(!$_REQUEST || $_REQUEST['data']==''){
	$reponse = array('status'=>'failed','msg'=>'Invalid JSON request.');
	$utils->callback($reponse);
}

// get JSON request
$request = json_decode($_REQUEST['data'],true);

if($request && $request['req'] == 'is_file_open') {
	
	$arrData['path']	=	(isset($request['path']) ? $request['path'] : '');
	//validate data
	$utils->validator($arrData);
	$details	=	fileOpenValidation($arrData['path']);
	if(isset($details["error"]) && count($details["error"])> 0){
		$str =implode(",",$details["error"]);
		$response = array('status'=>'failed', 'msg'=>$str);
	} else {
		$response = array('status'=>'success', 'msg'=>'File is not available for close');
	}
	$utils->callback($response);
	
} else {
	$reponse = array('status'=>'failed','msg'=>'Invalid JSON request.');
	$utils->callback($reponse);
}

function fileOpenValidation($source_path) {

	$rootPath				=	$GLOBALS['utils']->cleanupPath($source_path);
	$rootPath1				=	str_ireplace(FILE_HOST, '', $rootPath);

	$conn_id				=	$GLOBALS['ftpObj']->ftp_connection();	
	$details				= 	$GLOBALS['ftpObj']->ftpRecursiveFileListing($conn_id, $rootPath1);

	$validateFiles  = array();		
	if(!empty($details)) {
		foreach($details as $filelist) {
			$exp1	=	explode('/',$filelist);
			$fileName1	=	end($exp1);
		
			if($fileName1!='Thumbs.db'){
				$duplicateFile =  str_replace('.','_.',$filelist);
				if (ftp_rename($conn_id, $filelist, $duplicateFile))
				{
					ftp_rename($conn_id, $duplicateFile,$filelist );
				}
				else
				{
					$exp	=	explode('/',$filelist);
					$fileName	=	end($exp);
					$validateFiles['error'][] = $fileName;
				}
			}
		}
	}
	return $validateFiles;
}

?>