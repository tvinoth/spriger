<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
ini_set('max_execution_time', 300);
include_once(BASE_PATH."fileHandler/utils/ftpInfoUtilities.php");
include_once(BASE_PATH."fileHandler/utils/utilities.php");

//initialize obj
$ftpObj		=	new ftpInfoUtilities();	
$utils		=	new utilities();

if(!$_REQUEST || $_REQUEST['data']==''){
	$reponse = array('status'=>'failed','msg'=>'Invalid JSON request.');
	$utils->callback($reponse);
}
// get JSON request
$request = json_decode($_REQUEST['data'],true);

if($request && $request['req'] == 'directory_copy') {
	
	$arrData['src_path']			=	(isset($request['data']['src_path'])?$request['data']['src_path']:'');
	$arrData['dest_path']			=	(isset($request['data']['dest_path'])?$request['data']['dest_path']:'');
	//$arrData['ext']					=	(isset($request['data']['ext'])?$request['data']['ext']:'.*');
	$arrData['is_delete']			=	(isset($request['data']['is_delete'])?$request['data']['is_delete']:'NO');		
	$utils->validator($arrData);
	$response = directoryCopy($arrData);
	$utils->callback($response);
	
} else if($request['req'] == 'file_copy') {
	
	if(count($request['data']) > 0) {
		foreach($request['data'] as $res){
		
			$arrData['src_path']			=	(isset($res['src_path'])?$res['src_path']:'');
			$arrData['dest_path']			=	(isset($res['dest_path'])?$res['dest_path']:'');
			$arrData['is_delete']			=	(isset($res['is_delete'])?$res['is_delete']:'NO');		
			$utils->validator($arrData);
			$response = fileCopy($arrData);
			if($response['status']=='failed'){
				//stop exection and send response immediately
				$utils->callback($response);
			}
		}	
	} else {	
		$response = array('status'=>'failed','msg'=>'Invalid JSON request.');
	}	
	$utils->callback($response);
	
} else if($request['req'] == 'file_copy_from_local') {
	
	// connect ftp server
	$conn_id  =	$ftpObj->ftp_connection();
	
	if(count($request['data']) > 0) {
		foreach($request['data'] as $res){
		
			$arrData['src_path']			=	(isset($res['src_path'])?$res['src_path']:'');
			$arrData['dest_path']			=	(isset($res['dest_path'])?$res['dest_path']:'');
			$arrData['is_delete']			=	(isset($res['is_delete'])?$res['is_delete']:'NO');		
			$utils->validator($arrData);
			$response = localFileCopy($conn_id, $arrData);
			if($response['status']=='failed'){
				//stop exection and send response immediately
				$utils->callback($response);
			}
		}	
	} else {	
		$response = array('status'=>'failed','msg'=>'Invalid JSON request.');
	}	
	$utils->callback($response);
} else {

	$reponse = array('status'=>'failed','msg'=>'Invalid JSON request.');
	$utils->callback($reponse);
}
//copying local file to ftp server
function localFileCopy($conn_id, $arrData) {
	ini_set('track_errors', 1);
	$sourcePath			=	$GLOBALS['utils']->cleanupPath($arrData['src_path']);	

	$destPath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '', $GLOBALS['utils']->cleanupPath($arrData['dest_path']));
	$destPath			=	str_ireplace(FILE_HOST, '', $destPath);		
	$destDir			=	$GLOBALS['utils']->removeFilename($destPath);
	//verify  is source directory
 	$isdir 			= $GLOBALS['ftpObj']->ftp_is_dir($conn_id, $destDir);
	if(!$isdir) {		
		$GLOBALS['ftpObj']->ftp_make_dir($destDir, $conn_id); // create directories that do not yet exist
		$dataRes = ftp_put($conn_id, $destPath, $sourcePath, FTP_BINARY); // put the files
	} else {
		$dataRes = ftp_put($conn_id, $destPath, $sourcePath, FTP_BINARY); // put the files
	}
	
	if($arrData['is_delete'] == 'YES' && $dataRes == true){	
		// try to delete the file in $dir
		unlink ($conn_id, $sourcePath);
	}		
	if($dataRes == true) {
		$response = array("status"=>"success","msg"=>"file copied successfully");
		return $response;	
	} else {
		$response = array("status"=>"failed","msg"=>"Error Copying File : $php_errormsg");
		ini_set('track_errors', 0); 
		return $response;
	}
	
}


function directoryCopy($arrData) {
	
	$sourcePath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '',  $GLOBALS['utils']->cleanupPath($arrData['src_path']));
	$sourcePath			=	str_ireplace(FILE_HOST, '', $sourcePath);
	$actualPath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '', $sourcePath);
	
	$destPath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '', $GLOBALS['utils']->cleanupPath($arrData['dest_path']));
	$destPath			=	str_ireplace(FILE_HOST, '', $destPath);		
	
	// connect ftp server
	$conn_id  =	$GLOBALS['ftpObj']->ftp_connection();
	
	//verify  is source directory
	$isdir 			= $GLOBALS['ftpObj']->ftp_is_dir($conn_id,$sourcePath);
	if(!$isdir) {
		$response = array("status"=>"failed","msg"=>"Source directory is not available for copy");
		return $response;
	}
	
	$dataRes			=	$GLOBALS['ftpObj']->ftp_dir_copy($conn_id, $sourcePath, $destPath);
	if($arrData['is_delete'] == 'YES' && $dataRes == true){
	
		// try to delete the directory $dir
		$GLOBALS['ftpObj']->recursiveDelete($conn_id,$sourcePath);		 
		//$articleUtilObj->rmdir($sourcePath,$conn_id,true);
		
	}	
	if($dataRes == true) {
		$response = array("status"=>"success","msg"=>"file copied successfully");
		return $response;
	} else {
		$response = array("status"=>"success","msg"=>"Error Copying File : $actualPath");
		return $response;
	}
}

function fileCopy($arrData) {
	
	$actualPath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '',  $GLOBALS['utils']->cleanupPath($arrData['src_path']));	
	$sourcePath 		= 	FILE_SERVER_FTTP_CREDENTIAL.$actualPath;
	 
	$destPath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '', $GLOBALS['utils']->cleanupPath($arrData['dest_path']));
	$destPath			=	str_ireplace(FILE_HOST, '', $destPath);		
	
	// connect ftp server
	$conn_id  =	$GLOBALS['ftpObj']->ftp_connection();
	$dataRes = ftp_put($conn_id, $destPath, $sourcePath, FTP_BINARY); // put the files
	if($arrData['is_delete'] == 'YES' && $dataRes == true){
		//remove host address from URL
		$finalPath = str_ireplace(FILE_HOST, '', $actualPath);	
		// try to delete the file in $dir
		ftp_delete($conn_id, $finalPath);
	}		
	if($dataRes == true) {
		$response = array("status"=>"success","msg"=>"file copied successfully");
		return $response;	
	} else {
		$response = array("status"=>"failed","msg"=>"Error Copying File : $actualPath");
		return $response;
	}

}
// delete directory
function directoryDelete($deletedirpath){

	$sourcePath			=	str_ireplace(FILE_SERVER_CREDENTIAL, '', $deletedirpath);
	$sourcePath			=	str_ireplace(FILE_HOST, '', $sourcePath);
	
	// connect ftp server
	$conn_id  =	$GLOBALS['ftpObj']->ftp_connection();
	// try to delete the directory $dir
	$GLOBALS['ftpObj']->recursiveDelete($conn_id,$sourcePath);
	  
	//$articleUtilObj->rmdir($sourcePath,$conn_id,true);
	return true;
	
}






?>