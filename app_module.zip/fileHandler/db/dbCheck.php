<?php
error_reporting(E_ALL);
$ip="";
if(isset($_REQUEST['ip'])){
$ip = $_REQUEST['ip'];
}
$mode=$_REQUEST['mode'];
if($mode=="select"){
	if ($ip!="") {
		$sql_role= mysql_query("SELECT * FROM inddlaunch WHERE system_ip = '".$ip."' and status=0;");
		$totVal="";
	while($row_query_info_chp = mysql_fetch_array($sql_role)){
		$methodName = $row_query_info_chp['method_name'];
		if($methodName=="launchindd"){
			$inddVersion = $row_query_info_chp["indd_version"];
			$filepath = $row_query_info_chp["file_path"];
			$projectId = $row_query_info_chp["project_id"];
			$scptPath = $row_query_info_chp["scpt_path"];
			$totVal = $methodName."[]".$inddVersion."[]".$filepath."[]".$projectId."[]".$scptPath;
		}
		if($methodName=="openLocalDrive"){
			$filepath = $row_query_info_chp["file_path"];
			$totVal = $methodName."[]".$filepath;
		}
		if($methodName=="fileServertoLocal" || $methodName=="fileLocaltoServer" || $methodName=="fileServertoServer"){
			$src = $row_query_info_chp["src_path"];
			$dest = $row_query_info_chp["dest_path"];
			$ext = $row_query_info_chp["ext"];
			$isDelete = $row_query_info_chp["isdelete"];
			$openPath = $row_query_info_chp["openpath"];
			$totVal = $methodName."[]".$src."[]".$dest."[]".$ext."[]".$isDelete."[]".$openPath;
		}
	}
	echo $totVal;
	return $totVal;
	}
// print_r($arr);
}
if($mode=="update"){
	$resp = $_REQUEST['resp'];
	$resp=str_replace("_"," ",$resp);
	$id = $_REQUEST['id'];
	$sql_role= mysql_query("update inddlaunch set status=1,remarks='".$resp."' WHERE system_ip = '".$ip."' and status=0;");
}
if($mode=="selectDb"){
$dbParam="";

$host           =       '172.24.191.58';        //Host name of the Server
$username       =       'developer';        //User Name of the Server
$password       =       'developer@58';    //Password of the Server
$dbname         =       'springer'; 
$tablename      =       'file_handler';

$dbParam=$host."[]".$username."[]".$password."[]".$dbname."[]".$tablename;
echo $dbParam;
return $dbParam;
}
if($mode=="download"){
	
	$file=$script_dir."FileHandler_".$_REQUEST['version'].".jar";
if (file_exists($file)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/x-download');
    header('Content-Disposition: attachment; filename='.basename($file));
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
	header('Content-Transfer-Encoding: binary');
    header('Pragma: public');
    header('Content-Length: ' . filesize($file));
    ob_clean();
    flush();
    readfile($file);
    exit;
}
}
?>  
