<?php
class ftpInfoUtilities{
	public function ftp_copy($src_dir, $dst_dir){
		//error_reporting(1);
		//error_reporting(E_ALL);
		//ini_set('display_errors', 1);
	    $ftp_server 	= FILE_SERVER_FTTP_HOST;
	    $ftp_user 		= FILE_SERVER_FTTP_USER;
	    $ftp_password 	= FILE_SERVER_FTTP_PASSWORD;
	
	    $conn_id 		= ftp_connect($ftp_server);
	    $login_result 	= ftp_login($conn_id, $ftp_user, $ftp_password)or die('echo');
	    
	    $stream_options = array('ftp' => array('overwrite' => true));

		// Creates a stream context resource with the defined options
		$stream_context = stream_context_create($stream_options);
	
	    if(copy(FILE_SERVER_FTTP_CREDENTIAL.$src_dir, FILE_SERVER_FTTP_CREDENTIAL.$dst_dir,$stream_context)) {
  			return true;
  			ftp_close($conn_id);
		}else {
			return false;
			ftp_close($conn_id);
		}
		
	}
	
	
	public function ftp_file_exist($filePath) {
		
		$conn_id = ftp_connect(FILE_SERVER_FTTP_HOST);
		// login with username and password
		$login_result = ftp_login($conn_id, FILE_SERVER_FTTP_USER, FILE_SERVER_FTTP_PASSWORD) or die("Could not connect to $ftp_server");
	
		if(ftp_size($conn_id,$filePath)!='-1')
			return true;
			else 
			return false;
			
			
			ftp_close($conn_id);
	}
	
	public function ftp_delet_dir($dir){
		$ftp_server 	= FILE_SERVER_FTTP_HOST;
		$ftp_user 		= FILE_SERVER_FTTP_USER;
		$ftp_password 	= FILE_SERVER_FTTP_PASSWORD;
		
		// set up basic connection
		$conn_id = ftp_connect($ftp_server);
		
		// login with username and password
		$login_result = ftp_login($conn_id, $ftp_user, $ftp_password);
		
		// try to delete the directory $dir
		if (ftp_rmdir($conn_id, $dir)) {
		    echo "Successfully deleted $dir\n";
		} else {
		    echo "There was a problem while deleting $dir\n";
		}
		exit;
		ftp_close($conn_id);
		
	}
	
	
	public function ftp_dir_copy($conn_id, $srcdirPath, $desdirPath) {

		$res	=	$this->ftp_dir_copy_rec($conn_id, FILE_HOST.$srcdirPath, $desdirPath);
		return $res;
		
	}
	
	public function get_ftp_file_list($folderPath) {
		
		$ftp_server 	= FILE_SERVER_FTTP_HOST;
		$ftp_user 		= FILE_SERVER_FTTP_USER;
		$ftp_password 	= FILE_SERVER_FTTP_PASSWORD;

		$conn_id 		= ftp_connect($ftp_server);
		
		$login_result 	= ftp_login($conn_id, $ftp_user, $ftp_password)or die('echo');
		
		$mode = ftp_pasv($conn_id, TRUE);
	 
		// get contents of the current directory
		$contents = ftp_nlist($conn_id,$folderPath);
		ftp_close($conn_id);
			
		return $contents;
	}
	
	
	public function ftp_file_size($filePath) {
		
		$conn_id 	= ftp_connect(FILE_SERVER_FTTP_HOST);
		// login with username and password
		$login_result = ftp_login($conn_id, FILE_SERVER_FTTP_USER, FILE_SERVER_FTTP_PASSWORD) or die("Could not connect to $ftp_server");
		
		$fileSize	=	ftp_size($conn_id,$filePath);
		
		if($fileSize == '-1')
			return '0';
		else 
			return $fileSize;
			
			
			ftp_close($conn_id);
	}
	
	/**
	 * ftp:kdkdd@kkHost
	 * Enter description here ...
	 * @param unknown_type $fileNamepath
	 */
	public function ftp_file_put($fileName, $fileData){
	
	// Allows overwriting of existing files on the remote FTP server
	$stream_options = array('ftp' => array('overwrite' => true));
	
	// Creates a stream context resource with the defined options
	$stream_context = stream_context_create($stream_options);
	
	// Opens the file for writing and truncates it to zero length
	if ($fh = fopen($fileName, 'w', 0, $stream_context))
	{
	    // Writes contents to the file
	    fputs($fh, $fileData);
	   
	    // Closes the file handle
	    fclose($fh);
	}
	return $fh;
	}
	
	public function ftp_make_dir ($folderPath){
		//echo "fdsfsfdsf";
		$ftp_server 	= FILE_SERVER_FTTP_HOST;
		$ftp_user 		= FILE_SERVER_FTTP_USER;
		$ftp_password 	= FILE_SERVER_FTTP_PASSWORD;

		$conn_id 		= ftp_connect($ftp_server);
		$login_result 	= ftp_login($conn_id, $ftp_user, $ftp_password)or die('echo');
		// echo $login_result;
		$mode = ftp_pasv($conn_id, TRUE);
		//  echo $mode;
		// get contents of the current directory
		$contents = $this->make_directory($conn_id,$folderPath);
		//echo "<br><br>".$contents;
		ftp_close($conn_id);
		
		return $contents;
		
	}
	
	public function make_directory($ftp_stream, $dir){
	
	//echo "fdsfdafd";
	// if directory already exists or can be immediately created return true
	if ($this->ftp_is_dir($ftp_stream, $dir) || @ftp_mkdir($ftp_stream, $dir)) return true;
	// otherwise recursively try to make the directory
	if (!$this->make_directory($ftp_stream, dirname($dir))) return false;
	// final step to create the directory
	return ftp_mkdir($ftp_stream, $dir);
	}
	
	public function ftp_is_dir($ftp_stream, $dir){
		// get current directory
		$original_directory = ftp_pwd($ftp_stream);
		// test if you can change directory to $dir
		// suppress errors in case $dir is not a file or not a directory
		if ( @ftp_chdir( $ftp_stream, $dir ) ) {
		// If it is a directory, then change the directory back to the original directory
		ftp_chdir( $ftp_stream, $original_directory );
			return true;
		} else {
			return false;
		}
	}
		
	function ftp_dir_copy_rec($conn_id, $src_dir, $dst_dir) {

		//$conn_id	=	$this->ftp_connection();
		$src_dir	=	FILE_SERVER_FTTP_CREDENTIAL.$src_dir;
		$dst_dir	=	str_replace(FILE_HOST, '', $dst_dir);
		
		return 	$this->ftp_putAll($conn_id, $src_dir, $dst_dir);

	}
	
	

	function ftp_putAll($conn_id, $src_dir, $dst_dir) {
		
		$d = dir($src_dir);
		
	//	print_r($d);
		while($file = $d->read()) { // do this for each file in the directory
			 
			if ($file != "." && $file != "..") { // to prevent an infinite loop
				if (is_dir($src_dir."/".$file)) { // do the following if it is a directory
					if (!@ftp_nlist($conn_id, $dst_dir."/".$file)) {
						$this->ftp_make_dir($dst_dir."/".$file, $conn_id); // create directories that do not yet exist
					}
					$this->ftp_putAll($conn_id, $src_dir."/".$file, $dst_dir."/".$file); // recursive part
				} else {
						
					$this->ftp_make_dir($dst_dir,$conn_id);
					if($file != 'Thumbs.db')
					$upload = ftp_put($conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files
				}
			}
		}
		$d->close();
		
		return true;
	}
	function ftp_connection() {

		$ftp_server 	= FILE_SERVER_FTTP_HOST;
		$ftp_user 		= FILE_SERVER_FTTP_USER;
		$ftp_password 	= FILE_SERVER_FTTP_PASSWORD;

		$conn_id 		= ftp_connect($ftp_server);
		$login_result 	= ftp_login($conn_id, $ftp_user, $ftp_password) or die('Unable to connect FTP Host');
		
		$mode = ftp_pasv($conn_id, TRUE);
	  
		$stream_options = array('ftp' => array('overwrite' => true));
		// Creates a stream context resource with the defined options
		$stream_context = stream_context_create($stream_options);

		return $conn_id;

	}
	function recursiveDelete($handle,$directory) {
	
		error_reporting(0);
		ini_set('display_errors', 0);
	    # here we attempt to delete the file/directory
	    if( !(@ftp_rmdir($handle, $directory) || @ftp_delete($handle, $directory)) )
	    {
	        # if the attempt to delete fails, get the file listing
	        $filelist = @ftp_nlist($handle, $directory);
			
	        # loop through the file list and recursively delete the FILE in the list
	        if(!empty($filelist)) {
				foreach($filelist as $file)
		        {
		             $this->recursiveDelete($handle,$file);
		        }
	        }
	
	        #if the file list is empty, delete the DIRECTORY we passed
	         $this->recursiveDelete($handle,$directory);
	         
	         return true;
	    }
	    
	    return true;
	    
	    
	}
	function ftpRecursiveFileListing($ftpConnection, $path) { 

		static $allFiles = array(); 
	    
		$contents = ftp_nlist($ftpConnection, $path); 
		if(!empty($contents)){
		    foreach($contents as $currentFile) { 
			    // assuming its a folder if there's no dot in the name 
		        if (strpos($currentFile, '.') === false) { 
		            $this->ftpRecursiveFileListing($ftpConnection, $currentFile); 
		        } 
				if(strpos($currentFile, '.') != false) {
					
				 $setpath	=	str_replace('//','/',$path.'/'. substr($currentFile, strlen($path) + 1));
				
		        $allFiles[] = $setpath;
				}
	   	 } 
		}
    	return $allFiles; 
	} 
	
	
}

?>