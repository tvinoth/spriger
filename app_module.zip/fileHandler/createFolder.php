<?php 
ini_set('max_execution_time', 300);
error_reporting(1);
ob_start();
include("../config.php"); 
include("../const_link.php"); 
include_once(BASE_PATH."fileHandler/utils/ftpInfoUtilities.php");
include_once(BASE_PATH."fileHandler/utils/utilities.php");

//initialize obj
$ftpObj		=	new ftpInfoUtilities();
$utils		=	new utilities();

if(!$_REQUEST || $_REQUEST['data']==''){
	$reponse = array('status'=>'failed','msg'=>'folder creation failed.');
	$utils->callback($reponse);
}
// get JSON request
$request = json_decode($_REQUEST['data'],true);

if($request && $request['req'] == 'create_folder') {
	
	// initialize post data 
	if(!empty($request['data'][0])) {
		foreach($request['data'] as $data) { 
			//server path
			$serverPath = trim($data['serverPath']);
			$folderArray = explode(':', $data['directory']);
			//get folder list 
			$directory = str_replace('|','/', $folderArray[0]);
			//get subfolder list
			$subDirectory = explode('|', $folderArray[1]);

			if($serverPath!=''  && $directory!='') { 
				if(createFolder($serverPath, $subDirectory, $directory)) {		
					$reponse = array('status'=>'success','msg'=>'folder created successfully');
				} else {
					$reponse = array('status'=>'failed','msg'=>'folder creation failed');
					$utils->callback($reponse);					
				}
			} else {
				$reponse = array('status'=>'failed','msg'=>'No data found for create folder');
			}
		}
	} else {
		$reponse = array('status'=>'failed','msg'=>'No data found for create folder');
	}
	$utils->callback($reponse);
} else {
	$reponse = array('status'=>'failed','msg'=>'parameter missing');
	$utils->callback($reponse);
}
				
function createFolder($path, $additionalfolders, $directory){
	
	$dstPath = $GLOBALS['utils']->cleanupPath($path);
	//explode destination path host from destination path
	$pathSplit = explode('/',$dstPath);	
	$dstHost = $pathSplit[0]; // host address
	
	$serverpath = str_replace($dstHost,"",$dstPath);
	$serverpath =  $serverpath.'/'.$directory;
	// make directory
	$status	= $GLOBALS['ftpObj']->ftp_make_dir($serverpath);			
	if($status){
		foreach($additionalfolders as $folder){		
			if(!$GLOBALS['ftpObj']->ftp_make_dir($serverpath.'/'.$folder)) {
				return false;
			}
		}
	} else {
		return false;
	}
	return true;	
}

		
				
?>