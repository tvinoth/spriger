<?php
echo 'Access Denied';
?>