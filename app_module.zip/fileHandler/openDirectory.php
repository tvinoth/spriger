<?php
error_reporting( E_ALL );
error_reporting(1); 
include_once("../config.php"); 
include_once("../fileHandler/utils/utilities.php");
//initialize obj
$utils		=	new utilities();
use DB;
if(!$_REQUEST || $_REQUEST['data']==''){
	$reponse = array('status'=>'failed','msg'=>'Invalid JSON request');
	$utils->callback($reponse);
}

// get JSON request
$request = json_decode($_REQUEST['data'],true);

if($request && $request['req'] == 'open_folder') {	
	$response = openFolder($request['data']);
	$utils->callback($response);	
} else if ($request && $request['req'] == 'check_status') {	
	$response = checkStatus($request);
	$utils->callback($response);	
} else {
	$response = array('status'=>'failed','msg'=>'Invalid JSON request');
	$utils->callback($response);
}

function openFolder($request) {	
	
	$ip = $GLOBALS['utils']->get_ip_address();	
	
	foreach($request as $res){
		$arrData = array();
		$arrData['file_path'] 		= $GLOBALS['utils']->cleanupPath(trim($res['openPath']));
		$arrData['method_name'] 	= trim($res['methodName']);
		//$arrData['processname'] 	= trim($res['processName']);
		$arrData['system_ip'] 		= $ip;				
		//validate array value is empty
		$GLOBALS['utils']->validator($arrData);
		//insert data
		$response = insertData($arrData);
		if(!$response) {
			$response = array('status'=>'failed','msg'=>'Data inserted failed.');
			$GLOBALS['utils']->callback($response);
		}
	}
	if($response) {
		$response = array('status'=>'success','msg'=>'Data saved successfully.','data'=>array('last_insert_id'=>$response));			
	} else {
		$response = array('status'=>'failed','msg'=>'Data inserted failed.');
	}		
	return $response;	
}

function checkStatus($request){
	
	$ip = $GLOBALS['utils']->get_ip_address();	
	$arrData['id']	= $request['id'];
	//validate array value is empty
	$GLOBALS['utils']->validator($arrData);
	$userQuery  	= "SELECT id,status,is_running,remarks FROM  rmi_status  WHERE system_ip = '".$ip."' and ID=".$arrData['id'];	
	$query = DB::select( $userQuery );
	$data			=	mysql_fetch_assoc($query);	
	
	if($data['status'] == 0){
		$response = array('status'=>'failed','msg'=>$data['remarks'],'is_running'=>$data['is_running']);
	} else {
		$response = array('status'=>'success','msg'=>$data['remarks'],'is_running'=>$data['is_running']);	
	}
	return $response;
}

function insertData($insertvalue){
	
	$lastinsertId	=	'';
	$colums			=	array_keys($insertvalue);
	$userColumn 	=  "(".implode(",",array_values($colums)).")" ;
	$userValues		=  "('".implode("','",array_values($insertvalue))."')" ;
	$userQuery  	= "INSERT INTO rmi_status ".$userColumn." values ".$userValues."";
	
	$query = DB::select( $userQuery );
	
	$lastinsertId = mysql_insert_id();
	
	if(!empty($lastinsertId))
		return $lastinsertId;
	else 
		return false;
		
}



?>