BEGIN

#Declare @qury varchar(1000) NULL;

DROP TABLE IF EXISTS `result`;
CREATE TEMPORARY TABLE IF NOT EXISTS result
(
JOB_ID INT NULL,
BOOK_ID varchar(50) NULL, 
ROUND_ID INT NULL ,
ROUND INT NULL,
ROUND_NAME Varchar(50) NULL,
ACTIVE INT NULL,
JOB_TITLE varchar(100) NULL,
LOCATION varchar(50) NULL,
JOB_ASSIGNED_DATE datetime NULL,
receivedDate datetime NULL,
ISSN_ONLINE varchar(50) NULL,
PMname varchar(50) NULL,
PM INT NULL,
AM INT NULL,
AM_NAME Varchar(50),
deadline TEXT,
PLATFORM_TYPE Varchar(200),
JOB_TYPE Varchar(200)
);

SET @cndID = ' and 1=1';
If(userid is NOT NULL and Role = 'AM')
THEN
SET @cndID = concat(' AND ji.AM =', userid);
END IF;

If(userid is NOT NULL and Role = 'PM')
THEN
SET @cndID = concat(' AND j.PM =', userid);
END IF;

IF(round IS NULL)
THEN
SET @rund = 'ad.ROUND IN (104)';
ELSe
SET @rund = concat('ad.round IN (',round,')' );
END IF;

#SELECT @AMID, @PMID, @rund;

IF(limit_start IS NULL AND limit_end IS NULL)
THEN

SET @lit = concat( ' LIMIT 0, 50');

ELSE 

SET @lit = concat( ' LIMIT ',limit_start,',',limit_end);

END IF;

SET @qury = concat('INSERT INTO result 
select j.JOB_ID,ad.BOOK_ID , ad.ROUND AS ROUND_ID , ad.ROUND AS ROUND_ID , case ad.ROUND WHEN 114 then "S50"
ELSE "S5" END AS ROUND_NAME ,ad.is_active as ACTIVE,  j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,j.CREATED_DATE as receivedDate, ji.ISSN_PRINT, concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname, j.PM , ji.AM , ji.AM_NAME,ji.STAGE_DEADLINES_COLLECTION as deadline,ji.PLATFORM_TYPE,j.JOB_TYPE
from api_download ad 
inner join job j on j.BOOK_ID = ad.BOOK_ID 
left join `job_info` as `ji` on `ji`.`JOB_ID` = `j`.`JOB_ID` 
left join `user` as `u` on `j`.`PM` = `u`.`USER_ID` 
where ',@rund , @cndID ,'
and ad.is_completed = 1 and ad.is_active = 1
group by ad.book_id, ad.Round, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM , ji.AM , ji.AM_NAME',@lit);

PREPARE stmt FROM @qury;
EXECUTE stmt;

select r.* 
, ame.`STATUS` as  JOB_SHEET_UPDATE, ame.`REMARKS` as  UPDATE_REMARKS
, afu.`STATUS` as  JOB_SHEET_UPLOAD, afu.`REMARKS` as  UPLOAD_REMARKS
, ac.`STATUS` as  SUCCESS_REDO ,ac.ID as CLIACKID, ac.`REMARKS` as  SR_REMARKS ,
tapmeta.`REMARKS` as  TAPS_REMARKS ,tapmeta.`STATUS` as  TAPS_STATUS,tapmeta.`WOMAT_TYPE`,ifnull(tapmeta.`END_TIME`,'') as  TAPS_END_TIME ,1 as SHEET_FLAG
 from result r
left JOIN api_meta_extractor ame	on ame.JOB_ID = r.Job_Id and ame.ROUND = r.Round and ame.ID IN ( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND process_type = 1  order by ame2.ID desc )
left join api_file_upload afu on afu.JOB_ID = r.Job_Id and afu.ROUND = r.Round and afu.ID IN ( select max(afu2.ID) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND process_type = 1 order by afu2.ID desc )
left join api_client_acknowledgement ac on ac.JOB_ID = r.Job_Id and ac.ROUND = r.Round and ac.ID IN ( select max( ac2.ID ) from api_client_acknowledgement ac2 where ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND and ac2.PROCESS_TYPE_DIFF=1 order by ac2.ID desc)
left join taps_metadata tapmeta on tapmeta.JOB_ID = r.Job_Id and tapmeta.ROUND = r.Round and tapmeta.ID IN ( select max( tapmeta2.ID ) from taps_metadata tapmeta2 where tapmeta2.JOB_ID = tapmeta.JOB_ID AND tapmeta2.ROUND = tapmeta.ROUND order by tapmeta2.ID desc)
order by r.JOB_ID DESC Limit 0,50
;


END