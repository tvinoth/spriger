-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.download_view_source
CREATE TABLE IF NOT EXISTS `download_view_source` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `REQUIRED_CONSTANT_NAME` varchar(250) NOT NULL,
  `NAME` varchar(150) DEFAULT NULL,
  `DESCRIPTION` varchar(150) DEFAULT NULL,
  `FILE_FORMAT` text,
  `IS_ACTIVE` tinyint(4) DEFAULT '1',
  `CREATED_AT` datetime DEFAULT NULL,
  `UPDATED_AT` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

-- Dumping data for table springer.download_view_source: ~29 rows (approximately)
/*!40000 ALTER TABLE `download_view_source` DISABLE KEYS */;
INSERT INTO `download_view_source` (`ID`, `REQUIRED_CONSTANT_NAME`, `NAME`, `DESCRIPTION`, `FILE_FORMAT`, `IS_ACTIVE`, `CREATED_AT`, `UPDATED_AT`) VALUES
	(1, '0', 'View MetaPDF', NULL, NULL, 0, NULL, NULL),
	(2, '0', 'View Source', NULL, NULL, 0, NULL, NULL),
	(3, '0', 'Reference Files', NULL, NULL, 0, NULL, NULL),
	(4, '0', 'Dispatch Log', NULL, NULL, 0, NULL, NULL),
	(5, '0', 'Download manuscript', NULL, NULL, 0, NULL, NULL),
	(6, '0', 'Extracted XML', NULL, NULL, 0, NULL, NULL),
	(7, 'CORRECTION_RAW_PATH', 'eProof Author Correction Files', NULL, NULL, 1, NULL, NULL),
	(8, 'CORRECTION_PRODUCTION_PATH', 'eProof InCorporated XML', NULL, '.xml', 1, NULL, NULL),
	(9, 'EPROOF_PACKAGE_DESTINATION_PATH', 'eProof Author Package', NULL, '.zip', 1, NULL, NULL),
	(10, 'CORRECTION_PRODUCTION_PATH', 'eProof Corrections Log', NULL, '.log,.html', 1, NULL, NULL),
	(11, 'EPROOF_PACKAGE_INVALID_FILES', 'eProof Invalid Files', NULL, NULL, 1, NULL, NULL),
	(12, '0', 'Print Ready For Dispath', NULL, NULL, 0, NULL, NULL),
	(13, '0', 'Support Files', NULL, NULL, 0, NULL, NULL),
	(14, '0', 'CastOff Files', NULL, NULL, 0, NULL, NULL),
	(15, '0', 'CUC Files', NULL, NULL, 0, NULL, NULL),
	(16, '0', 'Merge Files', NULL, NULL, 0, NULL, NULL),
	(17, '0', 'View Old PDF', NULL, NULL, 0, NULL, NULL),
	(18, '0', 'Latest PDF - All Stage', NULL, NULL, 0, NULL, NULL),
	(19, '0', 'Open BWF Download', NULL, NULL, 0, NULL, NULL),
	(20, '0', 'Spin Off Download', NULL, NULL, 0, NULL, NULL),
	(21, '0', 'View PDF with Meta', NULL, NULL, 0, NULL, NULL),
	(22, '0', 'Modified Index Terms', NULL, NULL, 0, NULL, NULL),
	(23, '0', 'Art PDF Download', NULL, NULL, 0, NULL, NULL),
	(24, '0', 'Author Review', NULL, NULL, 0, NULL, NULL),
	(25, '0', 'JobSheet Explorer', NULL, NULL, 0, NULL, NULL),
	(26, '0', 'Source Download', NULL, NULL, 0, NULL, NULL),
	(27, '0', 'Robo Reader PDF', NULL, NULL, 0, NULL, NULL),
	(28, '0', 'OPS Correction Download', NULL, NULL, 0, NULL, NULL),
	(29, '0', 'LWW Indexing', NULL, NULL, 0, NULL, NULL);
/*!40000 ALTER TABLE `download_view_source` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
