-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.aps_proofing_status
CREATE TABLE IF NOT EXISTS `aps_proofing_status` (
  `ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TOKEN` varchar(250) NOT NULL,
  `JOB_ID` int(10) unsigned DEFAULT NULL,
  `METADATA_ID` int(10) unsigned DEFAULT NULL,
  `VOLUME_ISSUE` int(10) unsigned DEFAULT NULL,
  `ROUND` int(11) unsigned DEFAULT NULL,
  `PROOF_LETTER_TYPE_ID` int(11) unsigned DEFAULT NULL,
  `TYPE` enum('AUTHOR','EDITOR') DEFAULT NULL,
  `PROOFING_URL` text,
  `MAIL_SEND` tinyint(1) DEFAULT '0' COMMENT '0 - YET TO SEND , 2 - SEND , 3 - FAIL',
  `CORRECTION_REQUIRED` varchar(50) DEFAULT '0',
  `NAME` text,
  `SUBJECT` text,
  `FROM_NAME` text,
  `TO_EMAIL` text,
  `CC_EMAIL` text,
  `SUBJECT_LINE` text,
  `MAIL_ATTACHMENT_URL` text,
  `ITERATION` tinyint(1) DEFAULT NULL,
  `STATUS` enum('1.5','2','3') DEFAULT '1.5' COMMENT '1.5 - inprogress,2 -Success,3- Failed',
  `REMARKS` text NOT NULL,
  `EMAIL_CONTENT` text NOT NULL,
  `CORRECTION_DUE` datetime DEFAULT NULL,
  `FIRST_CORRECTION_DUE` datetime DEFAULT NULL,
  `SECOND_CORRECTION_DUE` datetime DEFAULT NULL,
  `THIRD_CORRECTION_DUE` datetime DEFAULT NULL,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `REQUEST_LOG` text,
  `RESPONSE_LOG` text,
  `START_TIME` timestamp NULL DEFAULT NULL,
  `END_TIME` timestamp NULL DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `IS_ACTIVE` enum('0','1') DEFAULT '1' COMMENT '1- ACTIVE,2 - IN ACTIVE',
  PRIMARY KEY (`ID`),
  KEY `FK_aps_proofing_status_proof_letter_types` (`PROOF_LETTER_TYPE_ID`),
  CONSTRAINT `FK_aps_proofing_status_proof_letter_types` FOREIGN KEY (`PROOF_LETTER_TYPE_ID`) REFERENCES `proof_letter_types` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- Dumping data for table springer.aps_proofing_status: ~2 rows (approximately)
/*!40000 ALTER TABLE `aps_proofing_status` DISABLE KEYS */;
INSERT INTO `aps_proofing_status` (`ID`, `TOKEN`, `JOB_ID`, `METADATA_ID`, `VOLUME_ISSUE`, `ROUND`, `PROOF_LETTER_TYPE_ID`, `TYPE`, `PROOFING_URL`, `MAIL_SEND`, `CORRECTION_REQUIRED`, `NAME`, `SUBJECT`, `FROM_NAME`, `TO_EMAIL`, `CC_EMAIL`, `SUBJECT_LINE`, `MAIL_ATTACHMENT_URL`, `ITERATION`, `STATUS`, `REMARKS`, `EMAIL_CONTENT`, `CORRECTION_DUE`, `FIRST_CORRECTION_DUE`, `SECOND_CORRECTION_DUE`, `THIRD_CORRECTION_DUE`, `CREATED_BY`, `UPDATED_BY`, `REQUEST_LOG`, `RESPONSE_LOG`, `START_TIME`, `END_TIME`, `created_at`, `updated_at`, `IS_ACTIVE`) VALUES
	(16, 'VClCsh0iDoxYiWyo', 6444, 3489, NULL, 118, 1, 'AUTHOR', 'http://eproofing.springer.com/books/index.php?token=B2WtpIQeN8D37DdslUR_VHW3ta5B84su36B807GKmCw\r\n', 0, '0', 'vinoth', 'test subject', 'vinoth', 'vinoth.t@spi-global.com', '', 'tets', '450217_1_En_CHAPTER_1_cDzOBdFhKa9xfek5_package.xml', NULL, '2', 'File uploaded successfully', '<p><fontName=’Arial’ fontsize=’2’>\r\nDear <b>vinoth</b>,<br><br>\r\n\r\nI am happy to inform you that the page proofs of your chapter in <b>Survival Strategies in Extreme Cold and Desiccation</b> have been completed in accordance with our style manual. The proofs are now available as a PDF file for your review. <br><br>\r\n\r\n1. Please click on the link below or copy and paste the link to your browser window <br><br>\r\n\r\n<a href=http://eproofing.springer.com/books/index.php?token=B2WtpIQeN8D37DdslUR_VHW3ta5B84su36B807GKmCw\r\n>http://eproofing.springer.com/books/index.php?token=B2WtpIQeN8D37DdslUR_VHW3ta5B84su36B807GKmCw\r\n</a><br><br>\r\n	\r\n2. On the download page, right click on the link of the PDF file and select <b>Save Target as</b> and save it to your hard disk. <br><br>\r\n\r\nPlease review the proofs and indicate any corrections preferably by:<br><br>\r\n\r\n> Opening the PDF file in Adobe Acrobat and using the Annotations tool to add comments.<br><br>\r\n\r\nIf desired you may print the file and mark corrections on hardcopy. Please mark all corrections legibly in dark pen in the text and in the margin at least ¼” (6 mm) from the edge.<br><br> \r\n\r\n<b>Please be aware</b> that the figures in this proof are shown in low resolution. <br>\r\nThe final published version of the book will show the figures in high resolution. <br><br>\r\n\r\n<b>IMPORTANT!</b> Please provide an answer to any Author Queries raised during typesetting. Unanswered queries will lead to delays in publication. <br><br>\r\n\r\nPlease return either the annotated PDF or marked hard copy as an email attachment to <b>B Ananth</b>. <br><br>\r\n\r\nPlease return the corrected proofs by <b>26th-Sep-2018</b>.<br><br>\r\n\r\nPlease note that any changes at this stage are limited to typographical errors and serious errors of fact. If the figures were converted to black and white, please check that the quality of such figures is sufficient and that all references to color in any text discussing the figures are changed accordingly. If the quality of some figures is judged to be insufficient, please send an improved greyscale figure.<br><br>\r\n\r\nPlease ensure that you return all necessary corrections together. After receipt of your corrections, Springer Nature will proceed with publication of the book and any subsequent corrections can only be considered in exceptional cases. <br><br>\r\n\r\nIf you have any questions, please feel free to contact me. <br><br>\r\n\r\nCordially, <br><br>\r\n\r\n<b>B Ananth</b><br>\r\nProject Manager<br>\r\nE: <a href=“ananth.b@spi-global.com">ananth.b@spi-global.com</a><br>\r\nSPi Technologies India Private Ltd.,<br>\r\n<br>\r\ntuticorin <br>\r\nTamil nadu <br>\r\n628202 <br>\r\nAfghanistan <br><br>\r\n<br>\r\nF: +49 9131 85 28732<br>\r\n<a href=”www.spi-global.com”>www.spi-global.com</a><br><br></p>\r\n\r\n', '2018-09-27 00:00:00', '2018-09-27 00:00:00', '2018-10-01 00:00:00', '2018-09-30 00:00:00', 29162, 29162, '<uploadMeta><bookid>435189_1_En</bookid><stage>S300</stage><uploadtype>PACKAGE_UPLOAD</uploadtype><sourceFile><filepath>\\\\172.24.191.59\\e\\ftp\\SP_BOOKS\\TAPS\\TAPS_FINAL_OUT\\435189_1_En_3_Chapter</filepath></sourceFile><destPath><ftpType>sftp</ftpType><fingerPrint>ssh-rsa 1024 e4:dd:11:2e:82:34:ab:62:59:1c:c8:62:1d:4b:48:99</fingerPrint><ftpSite>us-atl-sftp01.spi-global.com</ftpSite><path>SP_BOOKS/PACKAGE_UPLOAD/</path><username>Bflux</username><password>5lj6fO5z</password></destPath><WorkflowAPI>\n                                <Url value="http://172.24.183.33:82/Magnus_Springer/api/apscallback"/>\n                                <parameter key="process" value="upload" type="fixed"/>\n                                <parameter key="jobid" value="6444" type="fixed"/>\n                                <parameter key="chapterid" value="3489" type="fixed"/>\n                                <parameter key="bookid" value="435189_1_En" type="fixed"/>\n                                <parameter key="tokenkey" value="VClCsh0iDoxYiWyo" type="fixed"/>\n                                <parameter key="round" value="118" type="fixed"/>\n                                <parameter key="status" type="boolean"/>\n                                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>\n                                <parameter key="remarks" type="string"/>\n                            </WorkflowAPI></uploadMeta>', '{\r\n  "process": "upload",\r\n  "jobid": "6444",\r\n  "chapterid": "3489",\r\n  "bookid": "435189_1_En",\r\n  "tokenkey": "VClCsh0iDoxYiWyo",\r\n  "round": "118",\r\n  "status": "2",\r\n  "apsurl": "File uploaded successfully",\r\n  "endtime": [\r\n    "{0:yyyy-MM-dd HH-mm-ss}",\r\n    "2018-09-26 00-59-05"\r\n  ],\r\n  "remarks": "File uploaded successfully"\r\n}', '2018-09-25 13:11:52', '2018-09-26 00:59:05', '2018-09-25 13:13:24', '2018-09-27 16:36:34', '1');
/*!40000 ALTER TABLE `aps_proofing_status` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
