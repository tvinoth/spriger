-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.aps_production_filepath_validation
CREATE TABLE IF NOT EXISTS `aps_production_filepath_validation` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ROUND_ID` int(11) NOT NULL DEFAULT '0',
  `JOB_STAGE_ID` int(11) NOT NULL DEFAULT '0',
  `FILE_PATH` text,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  `IS_ACTIVE` enum('0','1') DEFAULT '1',
  `FILE_PATH_TYPE` enum('pdfmerge','jobsheet','proofpdf','chapterxml','deltapdf','tapsoutpath','aps_proofing_url') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- Dumping data for table springer.aps_production_filepath_validation: ~6 rows (approximately)
/*!40000 ALTER TABLE `aps_production_filepath_validation` DISABLE KEYS */;
INSERT INTO `aps_production_filepath_validation` (`ID`, `ROUND_ID`, `JOB_STAGE_ID`, `FILE_PATH`, `CREATED_BY`, `UPDATED_BY`, `IS_ACTIVE`, `FILE_PATH_TYPE`, `created_at`, `updated_at`) VALUES
	(1, 118, 0, '/SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/{BID}_{CNO}_Chapter_OnlinePDF_APS.pdf', 0, NULL, '1', 'pdfmerge', '2018-09-18 19:07:39', NULL),
	(2, 114, 0, '/SP_BOOKS/RAW/{BID}/{RNAME}/{BID}_JobSheet_50.xml', NULL, NULL, '1', 'jobsheet', '2018-09-19 11:55:41', NULL),
	(3, 118, 0, '/SP_BOOKS/RAW/{BID}/{RNAME}/Chapter_{CNO}/{BID}_{CNO}_JobSheet_300.xml', NULL, NULL, '1', 'jobsheet', '2018-09-19 16:51:13', NULL),
	(4, 118, 0, '/SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/{BID}_{CNO}_Chapter_OnlinePDF.pdf', NULL, NULL, '1', 'proofpdf', '2018-09-19 16:53:13', NULL),
	(5, 118, 0, '/SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/{BID}_{CNO}_Chapter_Delta.pdf', NULL, NULL, '1', 'deltapdf', '2018-09-19 16:57:19', NULL),
	(6, 118, 0, '/SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/{BID}_{CNO}_Chapter.xml', NULL, NULL, '1', 'chapterxml', '2018-09-19 18:52:41', NULL),
	(7, 118, 0, '/SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter', NULL, NULL, '1', 'tapsoutpath', '2018-09-20 15:08:24', NULL),
	(8, 118, 0, 'http://eproofing.springer.com/books/index.php?token=B2WtpIQeN8D37DdslUR_VHW3ta5B84su36B807GKmCw\r\n', NULL, NULL, '1', 'aps_proofing_url', '2018-09-24 16:39:56', NULL);
/*!40000 ALTER TABLE `aps_production_filepath_validation` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
