-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.application_menu_name
CREATE TABLE IF NOT EXISTS `application_menu_name` (
  `APPLICATION_MENU_NAME_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `NAME` varchar(255) NOT NULL,
  `SUBFIX_NAME` varchar(255) NOT NULL,
  `PREFIX_NAME` varchar(255) NOT NULL,
  `CODE` varchar(25) NOT NULL,
  `IS_ACTIVE` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `CREATED_DATE` datetime NOT NULL,
  `UPDATED_DATE` datetime NOT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `UPDATED_BY` int(10) unsigned NOT NULL,
  PRIMARY KEY (`APPLICATION_MENU_NAME_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;

-- Dumping data for table springer.application_menu_name: ~34 rows (approximately)
/*!40000 ALTER TABLE `application_menu_name` DISABLE KEYS */;
INSERT INTO `application_menu_name` (`APPLICATION_MENU_NAME_ID`, `NAME`, `SUBFIX_NAME`, `PREFIX_NAME`, `CODE`, `IS_ACTIVE`, `CREATED_DATE`, `UPDATED_DATE`, `CREATED_BY`, `UPDATED_BY`) VALUES
	(1, 'Dashboard', '', '', 'MSDA1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(2, 'Download', '', '', 'MSDO2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(3, 'Assigned job(s)', '', '', 'MSPR3', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(4, 'PAR Report', '', '', 'MSPAR1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(5, 'Proof Email Remainder Setup', '', '', 'MSPR17', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(6, 'Book Info', '', '', 'MSBOO1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(7, 'Workflow List', '', '', 'MSWOR1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(8, 'Check List', '', '', 'MSCHE2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(9, 'Transaction Package', '', '', 'MSTRA3', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(10, 'Email Notification Setup', '', '', 'MSEMA4', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(11, 'BG Process', '', '', 'MSBGP2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(12, 'Project Bin', '', '', 'MSPRO1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(13, 'Job Contact Information', '', '', 'MSCO12', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(14, 'Reports - Arrivals', '', '', 'MSARR1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(15, 'Reports - Track title', '', '', 'MSTRA2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(16, 'Reports - Productivity', '', '', 'MSPRO3', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(17, 'View Source', '', '', 'MSVIE18', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(18, 'Manage Invoice', '', '', 'MSFSINVMAN1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(19, 'New Invoice', '', '', 'MSFSINVNEW2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(20, 'Upload Pricing Grid', '', '', 'MSFSUPL1', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(21, 'Stage Process Mapping', '', '', 'MSFSSTA3', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(22, 'Additional Line Item Management', '', '', 'MSFSADD4', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(23, 'Template Management', '', '', 'MSFSTEM4', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(24, 'Split List', '', '', 'MSSPL2', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(26, 'CUC', '', '', 'MSCUC4', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(27, 'INDEXING', '', '', 'MSIND5', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(28, 'CE - Input Analysis', '', '', 'MSCEI6', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(29, 'Art Work', '', '', 'MSART7', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(30, 'Consolidated Report', '', '', 'MSCON8', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(31, 'PRR Activity/S5 notification', '', '', 'MSPRR9', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(32, 'Proof Email Remainder Setup', '', '', 'MSPRO17', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(33, 'Introductory Letter', '', '', 'MSINT13', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(34, 'Revised Jobsheet', '', '', 'MSREV14', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(35, 'ESM', '', '', 'MSESM16', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(36, 'Collaborative Proofing System', '', '', 'MSCOL15', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(37, 'Jobsheet Modification', '', '', 'MSJOB11', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(38, 'Chapter Promotion', '', '', 'MSCHA54', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0),
	(39, 'Split Completed', '', '', 'MSSCOM3', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, 0);
/*!40000 ALTER TABLE `application_menu_name` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
