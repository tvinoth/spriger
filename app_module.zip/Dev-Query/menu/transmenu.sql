-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.transaction_menu
CREATE TABLE IF NOT EXISTS `transaction_menu` (
  `TRANSACTION_MENU_ID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `TRANSACTION_NAME` varchar(255) NOT NULL,
  `CODE` varchar(25) NOT NULL,
  `IS_ACTIVE` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `TRANSACTION_TYPE` tinyint(1) unsigned NOT NULL COMMENT '(1-NEW, 2-SEARCH)',
  `CREATED_DATE` datetime NOT NULL,
  `CREATED_BY` int(10) unsigned NOT NULL,
  `URL` varchar(150) DEFAULT NULL,
  `MENU_ICON` varchar(150) DEFAULT NULL,
  `IS_CHECK_ACTIVE_NAME` varchar(150) DEFAULT NULL,
  `PACKAGE_DISPLAY_ORDER` int(11) DEFAULT NULL,
  `MENU_DISPLAY_ORDER` int(11) DEFAULT NULL,
  PRIMARY KEY (`TRANSACTION_MENU_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

-- Dumping data for table springer.transaction_menu: ~53 rows (approximately)
/*!40000 ALTER TABLE `transaction_menu` DISABLE KEYS */;
INSERT INTO `transaction_menu` (`TRANSACTION_MENU_ID`, `TRANSACTION_NAME`, `CODE`, `IS_ACTIVE`, `TRANSACTION_TYPE`, `CREATED_DATE`, `CREATED_BY`, `URL`, `MENU_ICON`, `IS_CHECK_ACTIVE_NAME`, `PACKAGE_DISPLAY_ORDER`, `MENU_DISPLAY_ORDER`) VALUES
	(1, 'Dashboard', 'MSDA1', 1, 1, '2018-04-18 15:35:15', 1, 'dashboard', 'menu-icon fa fa-tachometer', 'Dashboard', NULL, 1),
	(2, 'Download>>S5/S50 Download', 'MSDOW1', 0, 2, '2018-04-18 15:36:18', 1, 'download-list', NULL, 'Job Download', NULL, NULL),
	(3, 'Download>>S200 Download', 'T3', 0, 2, '2018-04-18 15:37:07', 1, 'chapter_download_list/116', NULL, 'Chapter Download', NULL, NULL),
	(4, 'Project List', 'MSPR3', 1, 1, '2018-04-18 15:40:27', 1, 'job-list', 'menu-icon fa fa-list-alt', 'Project List', NULL, 3),
	(5, 'Pre-Production', 'MSPR4', 1, 1, '2018-04-18 15:46:28', 1, NULL, 'menu-icon fa fa-tasks', NULL, NULL, 4),
	(6, 'Pre-Production>>Book Info', 'MSBOO1', 1, 2, '2018-04-18 15:46:28', 1, 'book_info', NULL, 'Book Info', 1, NULL),
	(7, 'Pre-Production>>Split Process', 'MSSPL2', 1, 2, '2018-04-18 15:43:52', 2, 'preproduction/split-job-list', NULL, 'Split Process', 2, NULL),
	(8, 'Pre-Production>>CUC Process', 'MSCUC4', 1, 2, '2018-04-18 15:44:49', 1, 'cucprocess-list', NULL, 'CUC Process', 4, NULL),
	(9, 'Pre-Production>>Indexing', 'MSIND5', 1, 2, '2018-04-18 15:45:46', 2, 'indexing-list', NULL, 'Indexing', 5, NULL),
	(10, 'Pre-Production>>CE - Input Analysis', 'MSCEI6', 1, 2, '2018-04-18 15:46:28', 2, 'copyediting-list', NULL, 'CE - Input Analysis', 6, NULL),
	(11, 'Pre-Production>>Art Work', 'MSART7', 1, 2, '2018-04-18 15:46:28', 1, 'artprocess-booklist', NULL, 'Art Work', 7, NULL),
	(12, 'Pre-Production>>Consolidated Report', 'MSCON8', 1, 2, '2018-04-18 15:49:01', 2, 'consolidate-report', NULL, 'Consolidated Report', 8, NULL),
	(13, 'Pre-Production>>Spicast/PRR Report', 'MSPRR9', 1, 2, '2018-04-18 15:49:56', 1, 'prr-report', NULL, 'Spicast/PRR Report', 9, NULL),
	(14, 'Pre-Production>>Contact Import', 'MSCO12', 1, 2, '2018-04-18 15:50:51', 1, 'book_contact_import', NULL, 'Contact Import', 12, NULL),
	(15, 'Pre-Production>>Introductory Letter', 'MSINT13', 1, 2, '2018-04-18 15:52:25', 1, 'introductory', NULL, 'Introductory Letter', 13, NULL),
	(16, 'Pre-Production>>Revised Jobsheet upload', 'MSREV14', 1, 2, '2018-04-18 15:53:12', 1, 'jobrevised', NULL, 'Revised Jobsheet upload', 14, NULL),
	(17, 'Pre-Production>>Jobsheet Modification', 'MSJOB11', 1, 2, '2018-04-18 15:46:28', 1, 'metaextractor', NULL, 'Jobsheet Modification', 11, NULL),
	(18, 'Production', 'MSPR5', 1, 1, '2018-04-18 15:56:33', 1, NULL, 'menu-icon fa fa-tasks', NULL, NULL, 5),
	(19, 'Production>>Project Bin', 'MSPRO1', 1, 2, '2018-04-18 15:46:28', 1, 'projectbin', NULL, 'Project Bin', NULL, NULL),
	(20, 'Customization', 'MSCU6', 1, 1, '2018-04-18 15:46:28', 1, NULL, 'menu-icon fa fa-cogs', NULL, NULL, 6),
	(21, 'Customization>>Workflow List', 'MSWOR1', 1, 2, '2018-04-18 15:58:54', 1, 'workflow-list', NULL, 'Workflow List', NULL, NULL),
	(22, 'Customization>>Transaction Package', 'MSTRA3', 1, 2, '2018-04-18 15:59:57', 1, 'package', NULL, 'Transaction Package', NULL, NULL),
	(23, 'Customization>>Contact Import', '', 0, 2, '2018-04-18 16:01:22', 1, 'book_contact_import', NULL, 'Contact Import', NULL, NULL),
	(24, 'Download', 'MSDO2', 1, 1, '2018-04-18 17:46:46', 1, 'download-index', 'menu-icon fa fa-cogs', 'Download', NULL, 2),
	(25, 'Production>>BG Process', 'MSBGP2', 1, 2, '2018-04-20 12:40:32', 1, 'getbgprocess', NULL, 'BG Process', NULL, NULL),
	(26, 'Pre-Production>>PAR Report', 'MSPAR1', 1, 2, '2018-04-20 14:43:05', 1, 'par_report', NULL, 'PAR Report', 10, NULL),
	(27, 'Finance', 'Fin', 1, 1, '2018-07-16 22:31:08', 31874, 'finance', 'menu-icon fa fa-dollar', '(NULL)', NULL, 7),
	(28, 'Finance>>Service Item', 'SI', 1, 2, '2018-07-16 22:31:08', 31874, NULL, NULL, 'Service Item', 3, NULL),
	(29, 'Finance>>Service Item>>Upload Pricing Grid', 'MSFSUPL1', 1, 3, '2018-07-16 22:31:08', 31874, 'fin/pricinggrid/upload', NULL, 'Upload Pricing Grid', 1, NULL),
	(30, 'Finance>>Service Item>>Template Setup', 'MSFSTEM4', 1, 3, '2018-04-20 14:43:05', 1, 'fin/lineitem/template', NULL, 'Template Setup', 5, NULL),
	(31, 'Finance>>Invoice', 'INV', 1, 2, '2018-07-16 22:31:08', 31874, NULL, NULL, 'Invoice', 2, NULL),
	(32, 'Finance>>Invoice>>New Invoice', 'MSFSINVNEW2', 1, 3, '2018-07-16 22:31:08', 31874, 'fin/invoice/add', NULL, 'New Invoice', NULL, NULL),
	(33, 'Finance>>Invoice>>Manage Invoice', 'MSFSINVMAN1', 1, 3, '2018-07-16 22:31:08', 31874, 'fin/invoice/list', NULL, 'Invoice List', NULL, NULL),
	(34, 'Finance>>Pricing Grid>>Edit', 'PG03', 0, 3, '2018-07-16 22:31:08', 31874, 'fin/pricinggrid/files/edit', NULL, 'Edit', NULL, NULL),
	(35, 'Finance>>Service Item>>Update Pricing Grid', 'SI02', 0, 3, '2018-07-16 22:31:08', 31874, 'fin/pricinggrid/updatePricing/10885', NULL, 'Update Pricing Grid', 2, NULL),
	(36, 'Finance>>Service Item>>Additional Line Item', 'MSFSADD4', 1, 3, '2018-07-16 22:31:08', 31874, 'fin/lineitem/additional', NULL, 'Additional Line Item', 3, NULL),
	(37, 'Finance>>Service Item>>Stage Process Mapping', 'MSFSSTA3', 1, 3, '2018-07-16 22:31:08', 31874, 'fin/lineitem/stage-process/mapping', NULL, 'Stage Process Mapping', 2, NULL),
	(38, 'Download>>S300 Download', 'T27', 0, 2, '2018-04-18 15:37:07', 1, 'chapter_download_list_eproof/118', NULL, 'Chapter Eproof Download', NULL, NULL),
	(39, 'Pre-Production>>Proof Email Remainder', 'MSPRO17', 1, 2, '2018-04-20 14:43:05', 1, 'emailremaindersetup', NULL, 'Proof Email Remainder', 17, NULL),
	(40, 'Pre-Production>>Split Completed', 'MSSCOM3', 1, 2, '2018-04-18 15:43:52', 2, 'preproduction/split-completed-job-list', NULL, 'Split Completed', 3, NULL),
	(42, 'Customization>>Email Notification Setup', 'MSEMA4', 1, 2, '2018-09-22 11:41:46', 1, 'emailsetup', NULL, 'Email Notification Setup', NULL, NULL),
	(43, 'Finance>>WIP', 'WI', 0, 2, '2018-10-04 14:53:07', 31874, NULL, NULL, 'WIP', 1, NULL),
	(44, 'Finance>>WIP>>Setup', 'WI1', 0, 3, '2018-10-04 15:04:23', 31874, 'fin/wip/setup', NULL, 'WIP Setup', 1, NULL),
	(45, 'Customization>>Checklist', 'MSCHE2', 1, 2, '2018-10-04 15:45:12', 1, 'checklistsetup', NULL, 'Checklist', NULL, NULL),
	(46, 'Reports', 'R1', 1, 1, '2018-04-18 15:56:33', 1, NULL, 'menu-icon fa fa-cogs', NULL, NULL, 7),
	(47, 'Reports>>Arrivals', 'MSARR1', 1, 2, '2018-04-18 15:46:28', 1, 'reports/1', NULL, 'Arrivals', 1, NULL),
	(48, 'Reports>>Track Title', 'MSTRA2', 1, 2, '2018-04-18 15:46:28', 1, 'reports/2', NULL, 'Track Title', 2, NULL),
	(49, 'Reports>>Productivity', 'MSPRO3', 1, 2, '2018-04-18 15:46:28', 1, 'reports/3', NULL, 'Productivity', 3, NULL),
	(50, 'Pre-Production>>ESM', 'MSESM16', 1, 2, '2018-04-18 15:46:28', 1, 'Esmlist-list', NULL, 'ESM', 16, NULL),
	(51, 'Pre-Production>>Collaborative Proofing System', 'MSCOL15', 1, 2, '2018-04-18 15:46:28', 1, 'aps_system', NULL, 'Collaborative Proofing System', 15, NULL),
	(52, 'Download', 'MSDO2', 0, 1, '2018-04-18 15:36:18', 1, 'download-index', 'menu-icon fa fa-cogs', 'Download', NULL, NULL),
	(53, 'Pre-Production>>View Source', 'MSVIE18', 1, 2, '2018-04-20 14:43:05', 1, 'viewSourceIndex', NULL, 'View Source', 18, NULL),
	(54, 'Pre-Production>>Chapter Promotion', 'MSCHA54', 1, 2, '2018-04-18 15:46:28', 1, 'promotionIndex', NULL, 'Chapter Promotion', 19, NULL);
/*!40000 ALTER TABLE `transaction_menu` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
