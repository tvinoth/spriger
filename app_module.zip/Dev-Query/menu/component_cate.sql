-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for springer
CREATE DATABASE IF NOT EXISTS `springer` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `springer`;

-- Dumping structure for table springer.component_category
CREATE TABLE IF NOT EXISTS `component_category` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(150) NOT NULL,
  `CODE` varchar(150) NOT NULL,
  `IS_ACTIVE` enum('1','0') DEFAULT '1' COMMENT '1 -ACTIVE , 2 IN ACTIVE',
  `CREATED_DATE` datetime DEFAULT CURRENT_TIMESTAMP,
  `UPDATED_DATE` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CREATED_BY` int(11) DEFAULT NULL,
  `UPDATED_BY` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- Dumping data for table springer.component_category: ~4 rows (approximately)
/*!40000 ALTER TABLE `component_category` DISABLE KEYS */;
INSERT INTO `component_category` (`ID`, `NAME`, `CODE`, `IS_ACTIVE`, `CREATED_DATE`, `UPDATED_DATE`, `CREATED_BY`, `UPDATED_BY`) VALUES
	(1, 'Front Matter', '#FM', '0', '2019-02-08 16:53:29', '2019-02-11 16:15:52', NULL, NULL),
	(2, 'Chapter', '#CHAPTER', '1', '2019-02-08 16:56:13', '2019-02-11 16:15:59', NULL, NULL),
	(3, 'Part', '#PART', '0', '2019-02-08 16:56:20', '2019-02-11 16:16:04', NULL, NULL),
	(4, 'Back Matter', '#BM', '0', '2019-02-08 16:56:30', '2019-02-11 16:16:11', NULL, NULL);
/*!40000 ALTER TABLE `component_category` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
