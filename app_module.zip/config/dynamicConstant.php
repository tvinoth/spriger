<?php
    
/**
 * Laravel - A PHP Framework For Web Artisans
 *
 * @package  Laravel
 * @author   Ananth B <ananth.b@spi-global.com>
 * Customizable application constant file
 * This file will load automaticaly through autoload functionality of laraval
 * 
  */

    $constFolderPath     =       public_path().'/dynamicConstants/';
    $constFilePath       =       '';        
    $curEnvironment      =       !empty( Config('app.env') ) ? \Config('app.env') : 'local';
    
    switch( $curEnvironment ){
        case 'DEV' :
            $constFilePath  =   $constFolderPath.'constants.xml';
            break;
        case 'UAT';
            $constFilePath  =   $constFolderPath.'constants_uat.xml';
            break;
        case 'LIVE':
            $constFilePath  =   $constFolderPath.'constants.xml';
            break;
        case 'local':
            $constFilePath  =   $constFolderPath.'constants.xml';
            break;
        default:
            $constFilePath  =   $constFolderPath.'constants.xml';
            break;
        
    }
    
    $getConstData       =       simplexml_load_file( $constFilePath );
    $json               =       json_encode( $getConstData );
    $array_val          =       json_decode( $json , TRUE);
    
    return $array_val;                    
    
?>