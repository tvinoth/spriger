<?php

    $file_serverpath                        =               '172.24.191.63';
    
    //common jobsheet copy file server information
    $default_ip                             =               $file_serverpath;
    $ds                                     =               DIRECTORY_SEPARATOR;      
    $defult_root_path                       =               '/ftp/';
    $default_root_dir                       =               'SP_BOOKS/';    
    $default_server_root_path               =               $default_ip.$defult_root_path.$default_root_dir; 
    $default_server_user                    =               'developer';
    $default_server_pass                    =               'dev.@123';
    
return [
    'FILE_SERVER_HOST'                      =>              $default_ip  ,
    'FILE_SERVER_CREDENTIALS'               =>              'ftp://'.$default_server_user.':'.$default_server_pass.'@' , 
    'FILE_SERVER_ROOT_DIR'                  =>              $defult_root_path ,
    'FILE_SERVER_FTP_PATH'                  =>              $default_root_dir ,
    'FILE_SERVER_USER'                      =>              $default_server_user ,
    'FILE_SERVER_PASS'                      =>              $default_server_pass ,
    'DRIVE_FILE_SERVER_PATH'                =>              $defult_root_path.$default_root_dir,
    'DRIVE_FILE_SERVER_ROOT_PATH'           =>              $defult_root_path,
    'RAW_PATH'                              =>              'RAW/'      ,
    'JOBSHEET_PATH'                         =>              'JOBSHEET/' ,
    'JOBSHEET_FULL_PATH'                    =>              'JOBSHEET/BOOK_ID/ROUND_NAME/',
    'PRE_PROCESSING_PATH'                   =>              'FILE-PROCESS/PRE_PROCESSING/',
    'USER_WORK_PATH'                        =>              'USER-WORK/',
    'RESOURCE_VIEW'                        =>              'RESOURCE_VIEW/',
    'PRE_PROCESS_PATH'                        =>              'PRE_PROCESS_PATH',
    'CHAPTER_PROMOTION'                     =>              'CHAPTER_PROMOTION',
    'ARTFILES_PATH'                         =>              'ARTFILES/' ,
    'TEMP_PATH'                             =>              'TEMP/'     ,
    'MAGNUS_DOMAIN_USERNAME'                =>              'spidom/magnususer' , 
    'MAGNUS_DOMAIN_PASSWORD'                =>              'm@Gnu$@5PiGl0baL' , 
    'ZIP_BACKUPS_BEFORE_UPLOAD'             =>              'UPLOAD/CLIENT/' ,
    'DEFAULT_JOBSHEET_COPY_PATH'            =>              $default_server_root_path.'JOBSHEET/BOOK_ID/STAGE_NAME/',
    'PRODUCTION_JOBSHEET_PATH'              =>              $default_server_root_path.'PRODUCTION/{BID}/{RID}/JOBSHEET/{CID}/',
    'RAW_PATH_FULL_INFO'                    =>              $default_server_root_path.'RAW/{BID}/{RID}/{CID}/',
    'ARTWORK_PRODUCTION_PATH'               =>              $default_server_root_path.'FILE-PROCESS/PRE_PROCESSING/{BID}/ARTFILES/{CID}/',
    'ARTWORK_PRODUCTION_PATH_S300'          =>         		$default_server_root_path.'PRODUCTION/{BID}/{RID}/ARTFILES/{CID}/',
    'ARTWORK_VALIDATION_WATCH_PATH'         =>              'SP_BOOKS/WATCHFOLDER/FIGURE_VALIDATION/IN/',
    'ARTWORK_PDF_CREATION_WATCH_PATH'       =>              'SP_BOOKS/WATCHFOLDER/ARTPDF_CREATION/IN/',
    //'S50_COPY_EDITING_PATH'                 =>              'FILE-PROCESS/PRE_PROCESSING/{BID}/COPY_EDITING/{CID}/',
    'S50_COPY_EDITING_PATH'                 =>              'RAW/{BID}/{RID}/{CID}/',
	'COMMON_JOBSHEET_PATH'      			=>              'JOBSHEET/{BID}/{RID}/',
    'PRODUCTION_CHAPTER_JOBSHEET_PATH'      =>              'PRODUCTION/{BID}/{RID}/JOBSHEET/{CID}/',
    'ART_TEMP_FILE_SERVER_PATH'             =>              $default_server_root_path.'TEMP/ARTFILES/',
    'TEMP_FILE_SERVER_PATH'                 =>              $default_server_root_path.'TEMP/',
    'ART_TEMP_FILE_ROOT_SERVER_PATH'        =>              $file_serverpath.'/'.$default_root_dir.'TEMP/ARTFILES/',
    'TEMP_FILE_ROOT_SERVER_PATH'            =>              $file_serverpath.'/'.$default_root_dir.'TEMP/',
    'TEMP_DRIVE_FILE_ROOT_SERVER_PATH'      =>              $file_serverpath.$defult_root_path.$default_root_dir.'TEMP/',
    'HOST_FILE_ROOT_SERVER_PATH'            =>              $file_serverpath.$defult_root_path.$default_root_dir,
    'SPICE_PRODUCTION_CHAPTER_PATH'         =>              'PRODUCTION/{BID}/{RID}/{STAGE}/{CID}/',
    'ART_QC_PRODUCTION_PATH'                =>              'PRODUCTION/{BID}/{RID}/ART_QC/{CID}/',
    'ART_PDF_PRODUCTION_PATH'               =>              'PRODUCTION/{BID}/{RID}/ART_PDF/{CID}/' ,  
    'ART_PRODUCTION_PATH'                   =>              'PRODUCTION/{BID}/{RID}/ART_MANIPULATION/{CID}/',
    'ART_PREPROCESSING_PATH'                =>              'FILE-PROCESS/PRE_PROCESSING/{BID}/ARTFILES/{CID}/',
    'COPY_EDITING_PRODUCTION_PATH'          =>              'PRODUCTION/{BID}/{RID}/COPY_EDITING/{CID}/',
    'CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_650'      =>              $default_server_root_path.'RAW/{BID}/S650/CORRECTION/',
    'CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_600'      =>              $default_server_root_path.'RAW/{BID}/S600/CORRECTION/',
    'CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION'      =>              $default_server_root_path.'RAW/{BID}/{RID}/{CID}/CORRECTION/',
	'CORRECTION_DOWNLOAD_PRODUCTION_STORAGE_LOCATION' =>              $default_server_root_path.'PRODUCTION/{BID}/{RID}/CORRECTION/{CID}/',

];

?>