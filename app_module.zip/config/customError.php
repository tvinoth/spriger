<?php

/**
 * Need to specify controller or models
 * 
 */
return [
    
    'Controller'        =>      [
        //displaying at 
        'projectBin'    =>      [ 
               '3001' => 
                [   
                    'msg'        =>      'Requested jobstageid is invalid.'  ,
                    //coding available in
                    'coding_in'   =>      'checkoutController/checkindisplay' ,
                    'notify'      =>      'danger'
                ]
            ]
            ,
        'artProcess'    =>      [
            
        ]
            ,
        'serverMapPathController'    =>      [
            '4001'  =>
            [   
                'msg'         =>      'Record Insertion Failed' , 
                'coding_in'   =>      'serverMapController/updateWorkflowServerPath' ,
                'notify'      =>      'danger'
            ],
            '4002'  =>
            [   
                'msg'         =>      'Workflow Records Saved Successfully' , 
                'coding_in'   =>      'serverMapController/updateWorkflowServerPath' ,
                'notify'      =>      'success'
            ],
            '4003'  =>
            [   
                'msg'         =>      'Invalid parameter given.' , 
                'coding_in'   =>      'serverMapController/updateWorkflowServerPath' ,
                'notify'      =>      'danger'
            ],
            '4004'  =>
            [   
                'msg'         =>      'Invalid try' , 
                'coding_in'   =>      'serverMapController/updateWorkflowServerPath' ,
                'notify'      =>      'danger'
            ]
        ]
    ]  ,
    'ApiController'     =>      [
        
        
    ]  , 
    
    
];
