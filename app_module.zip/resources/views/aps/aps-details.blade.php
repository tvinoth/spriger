@extends('layouts.templateMaster')
@section('content')
<style>
    .trrowhighlight
    {
        color: #17b9bb;
        font-size:15px;
    }
</style>
<!--<div class="row" ng-show="errorvalidationmsg">  
    <div style="height:80px;overflow:auto;">
        <ul  ng-repeat="exist in shownotavaiablechapter track by $index">
            <li>
                <p class="text-danger">@{{exist}}</p>
            </li>
        </ul>
    </div>
</div>-->
<div class="row">
    <table class="table table-striped table-bordered">
        <tr>
            <td>
                <p> Book ID :  
                <select name="bookid" chosen data-placeholder="--select--" id="bookidselect" class="chosen-select form-control"
                         ng-model="bookname" ng-change="bookinfodetails()">
                    <option value=""></option>
                    <?php echo $bookidCollect; ?>
                </select>
                </p>
            </td>
            @if($projectId !=   '') 
            <td>
				<div class="col-md-6 col-md-offset-3">
                <span ng-repeat="stage in apstypeofstage">
                <input name="stagename" type="radio" class="ace" id="stagename_@{{stage.id}}" ng-value="@{{stage.id}}" ng-model="$parent.stagename" ng-change="searchprocess()">
                <span class="lbl"> @{{stage.name}} </span>
                </span>
				</div>
            </td>
            @endif
            @if($projectId !=   '') 
            <td>
                <span ng-repeat="stage in apstypeofcontact">
                <input name="authoreditor" type="radio" id="authoreditor" class="ace" ng-value="@{{stage.id}}" ng-model="$parent.authoreditor" ng-change="authorprocess()">
                <span class="lbl"> @{{stage.name}} </span>
                </span>
            </td>
            @endif
        </tr>
    </table>
</div>
@if($projectId !=   '')

<div class="row">  
    <table class="table table-striped table-bordered" datatable="ng" dt-options="vm.dtOptions">
        <thead class="thin-border-bottom">
            <tr  style="font-size:15px">
                <th>Chapter No.</th>
                <th>Chapter Name</th>
                <th>Chapter Seq</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <tr ng-repeat="par in ApsList" ng-class="(par.APS_ID) ? 'trrowhighlight' : ''">
                <td width="10%" ng-if="!par.APS_ID">
                    <input type="checkbox" ng-click="proof_check($index,ApsList)" ng-model="par.checked" value="@{{par.METADATA_ID}}" name="authorproofchapter[]"/> @{{par.CHAPTER_NO}}
                </td>
                <td width="10%" ng-if="par.APS_ID">
                    <input type="checkbox" disabled/> @{{par.CHAPTER_NO}}
                </td>
                <td>@{{par.CHAPTER_NAME}}</td>
                <td>@{{par.CHAPTER_SEQ}}</td>
                <td>
                    <span ng-if="!par.APS_ID">Merge Completed.Please proceed to author</span>
                    <span ng-if="par.APS_ID">Merging &amp; Auto Mailing Completed.Proof sent</span>
                </td>
            </tr>
        </tbody>
    </table>	
    <br>
</div>	

<div class="row" ng-if="ApsList.length  !=  0" style="display:none">  
	<div class="">
		<table class="table table-striped table-bordered">
			<tr>
				<td><p>Source <span class="red">*</span> :</p></td>
				<td>
					<input name="apsSource" type="file" id="apsSource" class="form-control" accept=".txt,.zip,.xlsx,.xls,.doc,.docx,.xml">
				</td>
				<td>
					<button type="button" class="btn-primary" ng-click="clearfile()">Clear</button>
				</td>
			</tr>
		</table>
	</div>
</div>

    <div class="container-fluid" ng-if="ApsList.length  !=  0">   
        <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 
            <legend style="border-style: none;border-width: 0;font-size: 14px;line-height: 20px;margin-bottom: 0;width: auto;padding: 0 10px;border: 1px solid #e0e0e0;">
                &nbsp;  <i class="ace-icon fa fa-hand-o-right green"></i> &nbsp;&nbsp; Author/Editor information &nbsp;&nbsp;
            </legend>
            <form id="emailsetupform">

                <div class="row">
                    <div class="col-md-1" ng-if="authoreditor    ==  1">Author <span class="red">*</span> :</div>
                    <div class="col-md-1" ng-if="authoreditor    ==  2">Editor <span class="red">*</span> :</div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <input type="text" name="authorname" id="authorname" ng-model="ApsBookinfo.AUTHOR_NAME" placeholder="Author Name" class="form-control" ng-if="authoreditor    ==  1">
                            <input type="text" name="authorname" id="authorname" ng-model="ApsBookinfo.EDITOR_NAME" placeholder="Editor Name" class="form-control" ng-if="authoreditor    ==  2">
                        </div>
                    </div>
                    <div class="col-md-1">From <span class="red">*</span> :</div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <input type="text" name="fromapsemail" ng-model="apsemailsetup.fromapsemail" class="form-control" value="">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-1">To <span class="red">*</span> :</div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <textarea class="form-control toemailstage" id="toemail"  name="toemail" emails-only ng-model="ApsBookinfo.AUTHOR_EMAIL" value="@{{ApsBookinfo.AUTHOR_EMAIL}}" required ng-if="authoreditor    ==  1"></textarea>
                            <textarea class="form-control toemailstage" id="toemail" name="toemail" emails-only ng-model="ApsBookinfo.EDITOR_EMAIL" value="@{{ApsBookinfo.EDITOR_EMAIL}}" required ng-if="authoreditor    ==  2"></textarea>
                        </div>
                    </div>
                    <div class="col-md-1">Cc :</div>
                    <div class="col-md-5">
                        <div class="form-group">
                            <textarea class="form-control"  name="ccemail" emails-only ng-model="apsemailsetup.ccemail" id="ccemail" required></textarea>
                        </div>
                    </div>
                </div>

                <div class="row">
                    
					<div class="col-md-1">
						Proof Letter 
							<span class="red">*</span> :
					</div>
                    <div class="col-md-5">   
                        <span class="block input-icon input-icon-right">
                            <select ng-model="apsemailsetup.proofletter" class="form-control form-required-validation" name="proofletter">
                                <option value="">--Select--</option>
                                <option ng-repeat="apsletter in apsProofletter" value="@{{apsletter.ID}}">@{{apsletter.PROOF_NAME}}
                            </select>
                        </span>
                         <span class="help-block round_help"></span>
					</div>

					<div class="col-md-1">
						Author/Editor Subject Line 
						<span class="red">*</span> :
					</div>
					
                    <div class="col-md-5 col-sm-5"> 
                        
                        <input type="text" name="authoreditorsubject" ng-model="apsemailsetup.authoreditorsubject" placeholder="author/editor subject" class="form-control form-required-validation">
                    </div>

                </div>
				
                <div class="row" style="display:none">
				
					<div class="col-md-1">
						Subject 
							<span class="red"></span> :
					</div>
					
					<div class="col-md-5">
						<div class="form-group">
							<input type="text" name=subject"  class="form-control form-required-validation" ng-model="apsemailsetup.subject"/> 
						</div>
					</div>
					
                    <div class="col-md-1">Mail Attachment :</div>
					
                    <div class="col-md-5">
					<div class="form-group">
                        <input name="apsmailattachment" type="file" id="myFileField" class="form-control" accept=".txt,.zip,.xlsx,.xls,.doc,.docx,.xml">
						</div>
                    </div>
					
                </div>
				
				<div class="col-md-12">
					
				</div>
				
				<div class="row">
				
					<div class="col-md-1">
						Proof Returned Date 
							<span class="red">*</span> :
					</div>
					
					<div class="col-md-5">
					
						<div class="input-group date" data-provide="datepicker"  data-date-format="yyyy-mm-dd">
							<input type="text" class="form-control"  ng-model="apsemailsetup.proof_returendate">
							<div class="input-group-addon">
								<span class="fa fa-calendar"></span>
							</div>
						</div>
					
						<div class="form-group" style="display:none">
							<input type="text" id="proof_returendate" class="form-control proof_returned_date form-required-validation" placeholder="Proof Returned Date" >
						</div>
						
					</div>
					
				</div>
				<hr/>
				<div class="row">
                    <div class="col-md-8 col-md-offset-5 form-group col-sm-12">
						
							<button type="button" class="btn-warning btn btn-round" ng-click="doOpenmergepdf()">View Merge PDF</button> &nbsp;&nbsp;&nbsp;
							<button type="button" class="btn-warning btn btn-round" ng-click="proofapssubmit(2)">E-Mail Preview</button> &nbsp;&nbsp;&nbsp;
							<button type="button" class="btn-primary btn btn-round" ng-click="proofapssubmit(1)" ng-disabled="sendproofdisabled">Send</button>
						
                    </div>
                </div>
                
            </form>
        </fieldset>
    </div>
    
    <a href="#modal-redo" id="show-redo" data-toggle="modal"></a>
    <div id="modal-redo" class="modal fade" tabindex="-1">
            <div class="modal-dialog" style="width: 80%">
                    <div class="modal-content">
                        <div class="modal-header no-padding">
                            <div class="table-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                            <span class="white">&times;</span>
                                    </button>
                                    @{{Msgbox}}
                            </div>
                        </div>

                        <div class="modal-body" style="height:500px;overflow:auto">
                                <div id="redofailed"><p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p></div>
                                <div class="row" ng-show="errorvalidationmsg">  
                                    <ul  ng-repeat="exist in shownotavaiablechapter track by $index">
                                        <li>
                                            <p class="text-danger">@{{exist}}</p>
                                        </li>
                                    </ul>
                                </div>
                        </div>

                        <div class="modal-footer no-margin-top">

                        </div>
                    </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
    </div>
    
@endif
@endsection

@section('bootomScripts')	

<script src="{{url('/assets/dist/js/chosen.jquery.min.js')}}"></script> 
<script src="{{url('/angular/aps_system.app.js')}}"></script> 
<link rel="stylesheet" href="{{url('/assets/dist/js/datepicker/datepicker3.css')}}">
<script src="{{url('/assets/dist/js/datepicker/bootstrap-datepicker.js')}}"></script>

<script>
	
	$(document).ready(function(){
		
            $.fn.datepicker.defaults.autoclose = true;
            $.fn.datepicker.defaults.orientation = 'bottom';

            $("#proof_returendate").datepicker({
                    autoclose	: true,
                    format	: 'yyyy-mm-dd',
                    todayHighlight	: true,
                    orientation	: "bottom"
            });
		
	});
	
	
	//    $(".proof_returendate").datepicker({
	//            autoclose: true,
	//            format: 'yyyy-mm-dd',
	//            todayHighlight: true
	//        });
	//     $(document).ready(function(){
	//         
	//        
	//        $("#proof_returendate").datepicker({
	//            autoclose: true,
	//            format: 'yyyy-mm-dd',
	//            todayHighlight: true
	//        }).on('changeDate', function (selected) {
	//            //var settodatdate    =   new Date();
	//            var setstartdate    =   settodatdate.setDate(settodatdate.getDate()+3);
	////            var minDate         =   new Date(selected.date.valueOf());
	//                //$('#proof_returendate').datepicker('setStartDate', new Date(setstartdate.valueOf()));
	////                $('#proof_returendate').datepicker('setDate', settodatdate);
	//        });
	//    });

</script>
@endsection