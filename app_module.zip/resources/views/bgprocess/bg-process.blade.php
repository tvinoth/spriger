@extends('layouts.templateMaster')
@section('content')
<div class="row">
    <div class="col-xs-12 col-sm-12 widget-container-col ui-sortable" id="widget-container-col-1">
            <div class="widget-box ui-sortable-handle" id="widget-box-1">
                
                <div class="widget-header">
                    
                    <h5 class="widget-title">Background Process Tracker</h5>
                    
                    <div class="widget-toolbar pull-right">
                        <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                    </div>
                    
                </div>
                
            </div>

            <div class="widget-body ng-cloak">
                <div class="widget-main">
                    <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 
                        
                        <div class="col-md-12 col-xs-12">
                            
                            <div class="col-md-5 col-xs-12 form-group">
                                <div class="col-md-5 col-xs-12"> 
                                    <label for="Title"> Process Type : </label> 
                                </div>
                                <div class="col-md-10 col-xs-12"> 
                                    <span class="block input-icon input-icon-right">
                                        <select name="projects" data-placeholder="--select--" ng-change="changeProcess()" class="form-control" ng-model="process">
                                            <option value="">--Select--</option>
                                            <option value="@{{items.ID}}" ng-repeat="items in processList">@{{items.PROCESS_TYPES}}</option>
                                        </select>
                                    </span>
                                    <span class="help-block bookId_help"></span>
                                </div>
                            </div>
                            
                            <div class="col-md-5 col-xs-12 form-group">
                                <div class="col-md-5 col-xs-12"> 
                                    <label for="Title"> Status : </label> 
                                </div>
                                <div class="col-md-10 col-xs-12"> 
                                    <span class="block input-icon input-icon-right">
                                        <select name="projects" data-placeholder="--select--" ng-change="changeProcess()" class="form-control" ng-model="statusitems">
                                            <option value="">--Select--</option>
                                            <option value="@{{value}}" ng-repeat="(key,value) in statustypes">@{{key}}</option>
                                        </select>
                                    </span><span class="help-block bookId_help"></span>
                                </div>
                            </div>
                            
                        </div>  
                        
                    </fieldset>
                </div>
            </div>
        </div>
    </div>

<br>
<div class="row">
    <div class="col magnus-box">  
        <table class="table table-striped table-bordered" datatable="ng" dt-options="vm.dtOptions">
            <thead class="thin-border-bottom">
                <tr>
                    <th width="15%">Book ID</th>
                    <th width="15%">Chapter Title</th>
                    <th width="15%">Chapter No</th>
                    <th width="15%">Start Time</th>
                    <th width="15%">End Time</th>
                    <th width="20%">Status</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="book in bgprocessList">
                    <td>@{{book.BOOK_ID}}</td>
                    <td>@{{book.CHAPTER_TITLE}}</td>
                    <td> @{{book.CHAPTER_NO}}	&nbsp;&nbsp;&nbsp;<span ng-if="process == 14" class="label label-sm label-success arrowed-in"> @{{book.ROUND_NAME}}</span> </td>
                    <td>@{{book.START_TIME}}</td>
                    <td>@{{book.END_TIME}}</td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 1">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 1.5">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retrySpicastbackground(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 2">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span> &nbsp;&nbsp; 
						
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span> &nbsp;&nbsp; 
                        
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'>                                
                            </i>&nbsp;&nbsp; 
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
						
                    </td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  3">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                             &nbsp;
                             <span>
                                <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "eproof")' aria-hidden="true"></i>
                                 &nbsp;
                            </span>
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUploadEproof(book);retryEproof(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  4">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                              &nbsp;&nbsp;
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "package")' aria-hidden="true"></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process ==  5">
                        
                        <span ng-if="book.STATUS == 2">
                            <i class="fa fa-check green"  aria-hidden="true"></i>
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview("success",book)'></i>
                        </span>
                        
                        <span ng-if="book.STATUS == '1.5'"> 
                               <i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code> 
                        </span>
                        
                        <span ng-if="book.STATUS == 3">
                            <i class="fa fa-close red" style="font-size:20px"></i> 
                            &nbsp;
							<i class='fa fa-eye bigger-120 blue fa-1x pointer' ng-click='showSuccessredologview( "error" , book)'></i>
                            <!--	<i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i> -->
                            &nbsp;
                            <span>
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "package")' aria-hidden="true"></i>
                            </span>
							&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book)' aria-hidden='true'></i>
                            &nbsp;
                             
                        </span>
                        <span ng-if="book.STATUS == null || book.STATUS == 0"> -- </span>
                        
                    </td>
                                                
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  6">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryCucbackground(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  8">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <span >
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "package")' aria-hidden="true"></i>
                            &nbsp;&nbsp;
                            </span>
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book);' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>                            
                        </span>
                    </td>

                    <td id="spicast_@{{book.JOB_ID}}" ng-if="(process ==  21 || process ==  27 || process == 38 || process == 39)">

                          <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <span >
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "package")' aria-hidden="true"></i>
                            &nbsp;&nbsp;
                            </span>
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book);' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>                            
                        </span>
                    </td>
                    
                   
                    
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  10">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  11">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcessdummy(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
					<td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  12">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <!--<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcessdummy(book)' aria-hidden='true'></i>-->
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
					
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 13">
                        
                        <span ng-if="book.STATUS == 2">
                            <i class="fa fa-check green"  aria-hidden="true"></i>
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview("success",book)'></i>
                        </span>
                        
                        <span ng-if="book.STATUS == '1.5'"> 
                               <i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code> 
                        </span>
                        <span ng-if="book.STATUS == 3">
                            <i class="fa fa-close red" style="font-size:20px"></i> 
							&nbsp;
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview( "error" , book)'></i>
                            &nbsp;
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click="downloadPackageZip( book , 'package' )" aria-hidden="true"></i>
                            &nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book)' aria-hidden='true'></i>
                            
                        </span>
                        <span ng-if="book.STATUS == null || book.STATUS == 0"> -- </span>
                    </td>
                      
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 14">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>                        
                        <span ng-if="book.STATUS == 1.5">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>                        
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
								&nbsp;&nbsp;
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
								&nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
								&nbsp;&nbsp; 
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                        
                    </td>
                    
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  15">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
							
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            <!-- <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click="downloadPackageZip( book , 'package' )" aria-hidden="true"></i> -->
                            <span>
                                &nbsp;&nbsp;
                                <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "package")' aria-hidden="true"></i>
                            </span>
								
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                            
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  16 || process ==  9">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                     
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  18 || process ==  40">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
					
					<td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 19">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 1.5">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
					
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process ==  20">
                        
                        <span ng-if="book.STATUS == 2">
                            <i class="fa fa-check green"  aria-hidden="true"></i>
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview("success",book)'></i>
                        </span>
                        
                        <span ng-if="book.STATUS == '1.5'"> 
                               <i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code> 
                        </span>
                        <span ng-if="book.STATUS == 3">
                            <i class="fa fa-close red" style="font-size:20px"></i> 
                            &nbsp;
							<i class='fa fa-info bigger-120 blue fa-1x pointer' ng-click='showSuccessredologview( "error" , book)'></i>
                            &nbsp;
							<span >
							 <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "eproof")' aria-hidden="true"></i>
                            </span>
							&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUploadEproof(book);retryEproof(book)' aria-hidden='true'></i>
                            &nbsp;
                             
                        </span>
                        <span ng-if="book.STATUS == null || book.STATUS == 0"> -- </span>
                    </td>

                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 22">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 1.5">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
                     <td id="spicast_@{{book.METADATA_ID}}" ng-if="process == 28">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 1.5">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>

                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  25">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcessApn(book,"print")' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  26">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcessApn(book,"online")' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="(process == 29 || process == 30)">
                        
                        <span ng-if="book.STATUS == 2 && book.PACKAGE_STATUS != '1.5'">
                            <i class="fa fa-check green"  aria-hidden="true"></i>
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview("success",book)'></i>
                        </span>
                        
                        <span ng-if="book.STATUS == '1.5' && book.PACKAGE_STATUS != '1.5'"> 
                               <i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code> 
                        </span>
						
						<span ng-if="book.PACKAGE_STATUS == '1.5' || book.PACKAGE_STATUS == 3">
							<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for package response</code> 
						</span>
                        <span ng-if="book.STATUS == 3 && book.PACKAGE_STATUS != '1.5'">
                            <i class="fa fa-close red" style="font-size:20px"></i> 
							&nbsp;
                            <i class='fa fa-eye bigger-120 blue pointer' ng-click='showSuccessredologview( "error" , book)'></i>
                            &nbsp;
                            <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click="downloadPackageZip( book , 'package' )" aria-hidden="true"></i>
                            &nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUpload(book)' aria-hidden='true'></i>
                            
                        </span>
                        <span ng-if="book.STATUS == null || book.STATUS == 0"> -- </span>
                    </td>
                    
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="(process ==  31 || process ==  32)">
                        
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
					
					<td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  34 || process   ==  35 || process   ==  36 || process   ==  38 || process   ==  39 || process   ==  40">
                        <span>
                            --
                        </span>
                    </td>
                    
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  33">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                             &nbsp;
                             <span>
                                <i class="fa fa-download bigger-120 blue fa-1x pointer"  ng-click='downloadPackageZip(book , "eproof")' aria-hidden="true"></i>
                                 &nbsp;
                            </span>
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='packagefileUploadEproofs650(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    
					
                    <td id="spicast_@{{book.JOB_ID}}" ng-if="process ==  37">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == '1.5'">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 3" id="spicastretry_@{{book.JOB_ID}}">
                            <i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>
                            &nbsp;&nbsp;
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retryBgProcess(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                </tr>								
            </tbody>
        </table>	
	</div>	
    </div>

        <!-- show log file -->
        <a href="#modal-redo" id="show-redo" data-toggle="modal"></a>
        <div id="modal-redo" class="modal fade" tabindex="-1">
            <div class="modal-dialog" style="width: 80%"> 
                <div class="modal-content">
                    <div class="modal-header no-padding">
                        <div class="table-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                <span class="">&times;</span>
                            </button>
                            Remarks
                        </div>
                    </div>

                    <div class="modal-body">
                            <div id="redofailed"><p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p></div>
                    </div>

                    <div class="modal-footer no-margin-top">

                    </div>
                </div><!-- /.modal-content -->
            </div><!-- /.modal-dialog -->
        </div>
        
        

@endsection

@section('bootomScripts')	
<script src="{{url('/angular/bgprocess.app.js')}}"></script> 
<script src="{{url('/assets/dist/js/chosen.jquery.min.js')}}"></script>
<script>

var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
$('.magnus-box').ace_ajax('loadScripts', scripts , function() {});
</script>
@endsection
                        