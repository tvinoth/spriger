@extends('layouts.templateMaster')
@section('content')
<div class="row">
    <div class="col-xs-12 col-sm-12 widget-container-col ui-sortable" id="widget-container-col-1">
        <div class="widget-box ui-sortable-handle" id="widget-box-1">
            <div class="widget-header">
                <div class="col-sm-6">
                    <div class="widget-toolbar">
                        <p class="widget-title">Background Process Tracker</p>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="widget-toolbar">
                        <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                    </div>
                </div>
            </div>

            <div class="widget-body">
                <div class="widget-main">
                    <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 
                        <div class="col-md-12 col-xs-12">
                            <div class="col-md-2 col-xs-12 form-group">
                                <div class="col-md-10 col-xs-12"> 
                                    <span class="block input-icon input-icon-right">
                                        <select name="projects" data-placeholder="--select--" ng-change="changeProcess()" class="form-control" ng-model="process">
                                            <option value="">--Select Job--</option>
                                            <option  ng-repeat="item in bookList" value="@{{item.JOB_ID}}"> @{{item.BOOK_ID}}</option>
                                        </select>
                                    </span><span class="help-block bookId_help"></span>
                                </div>
                            </div>
                            <div class="col-md-2 col-xs-12 form-group">
                                <div class="col-xs-8 col-sm-11">
                                    <div class="input-group">
                                        <input class="form-control date-picker" id="id-date-picker-1" type="text" data-date-format="dd-mm-yyyy">
                                        <span class="input-group-addon">
                                                <i class="fa fa-calendar bigger-110"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 col-xs-12 form-group">
                                <div class="col-xs-8 col-sm-11">
                                    <div class="input-group">
                                        <input class="form-control date-picker" id="id-date-picker-2" type="text" data-date-format="dd-mm-yyyy">
                                        <span class="input-group-addon">
                                                <i class="fa fa-calendar bigger-110"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2 col-xs-12 form-group">
                                <div class="col-md-10 col-xs-12"> 
                                    <span class="block input-icon input-icon-right">
                                        <select name="projects" data-placeholder="--select--" ng-change="changeProcess()" class="form-control" ng-model="stageitems">
                                            <option value="">--Select Stage--</option>
                                            <option  ng-repeat="item in processList" value="@{{item.ID}}"> @{{item.NAME}}</option>
                                        </select>
                                    </span><span class="help-block bookId_help"></span>
                                </div>
                            </div>
                            <div class="col-md-2 col-xs-12 form-group">
                                <div class="col-md-10 col-xs-12"> 
                                    <span class="block input-icon input-icon-right">
                                        <select name="projects" data-placeholder="--select--" class="form-control" ng-model="statusitems">
                                            <option value="">--Select Status--</option>
                                            <option  ng-repeat="item in statustypes" value="@{{item.id}}"> @{{item.name}}</option>
                                        </select>
                                    </span><span class="help-block bookId_help"></span>
                                </div>
                            </div>
                        </div>  
                    </fieldset>
                </div>
            </div>
        </div>
    </div>
</div>
<br>

<div class="row">
    <div class="col magnus-box">  
        <table class="table table-striped table-bordered" datatable="ng" dt-options="vm.dtOptions">
            <thead class="thin-border-bottom">
                <tr>
                    <th width="5%">Rev</th>
                    <th width="5%">Article</th>
                    <th width="5%">Gcns Update</th>
                    <th width="5%">Stripins</th>
                    <th width="5%">Required Stage</th>
                    <th width="5%">XMP-PDF</th>
                    <th width="5%">S5 Dataset</th>
                    <th width="5%">EW Upload</th>
                    <th width="5%">OPT Dataset</th>
                    <th width="5%">PC Upload</th>
                    <th width="5%">S50 Dataset</th>
                    <th width="5%">S200 Dataset</th>
                    <th width="5%">Email Notifiction</th>
                    <th width="5%">RemarksResume</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="book in bgprocessList">
                    <td>@{{book.BOOK_ID}}</td>
                    <td>@{{book.CHAPTER_TITLE}}</td>
                    <td>@{{book.CHAPTER_NO}}</td>
                    <td>@{{book.START_TIME}}</td>
                    <td>@{{book.END_TIME}}</td>
                    <td>@{{book.BOOK_ID}}</td>
                    <td>@{{book.CHAPTER_TITLE}}</td>
                    <td>@{{book.CHAPTER_NO}}</td>
                    <td>@{{book.START_TIME}}</td>
                    <td>@{{book.END_TIME}}</td>
                    <td>@{{book.START_TIME}}</td>
                    <td>@{{book.END_TIME}}</td>
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  1">
                        <span ng-if="book.STATUS == 1 && book.END_TIME != null ">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 0 && !book.END_TIME">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 0 && book.END_TIME != null" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retrySpicastbackground(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                    <td id="spicast_@{{book.METADATA_ID}}" ng-if="process   ==  2">
                        <span ng-if="book.STATUS == 2">
                            <span class="label label-success arrowed-in arrowed-in-right">Success</span>
                        </span>
                        <span ng-if="book.STATUS == 1 && !book.END_TIME">
                            <span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>
                        </span>
                        <span ng-if="book.STATUS == 4 && book.END_TIME != null" id="spicastretry_@{{book.METADATA_ID}}">
                            <i class='fa fa-info bigger-120 blue fa-1x' ng-click='showClientack(book.REMARKS)'></i>&nbsp;<i class='fa fa-times bigger-120 red fa-1x'></i>
                            &nbsp;&nbsp; 
                            <i class='fa fa-repeat bigger-100 blue fa-1x pointer' ng-click='retrySpicastbackground(book)' aria-hidden='true'></i>
                            <span class="label label-danger arrowed-in arrowed-in-right">Failed</span>
                        </span>
                    </td>
                </tr>								
            </tbody>
        </table>	
	</div>	
        
        <!-- show log file -->
        <a href="#modal-redo" id="show-redo" data-toggle="modal"></a>
        <div id="modal-redo" class="modal fade" tabindex="-1">
                <div class="modal-dialog" style="width: 80%">
                        <div class="modal-content">
                            <div class="modal-header no-padding">
                                <div class="table-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                                <span class="white">&times;</span>
                                        </button>
                                        @{{Msgbox}}
                                </div>
                            </div>

                            <div class="modal-body">
                                    <div id="redofailed"><p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p></div>
                            </div>

                            <div class="modal-footer no-margin-top">

                            </div>
                        </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
        </div>
</div>
@endsection

@section('bootomScripts')	
<script src="{{url('/angular/bgprocess-status.app.js')}}"></script> 
<script src="{{url('/assets/dist/js/chosen.jquery.min.js')}}"></script>
<script>

var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
$('.magnus-box').ace_ajax('loadScripts', scripts , function() {});
</script>
@endsection
                        