@extends('layouts.templateMaster')
@section('content')

<div class="row">
        
         <div class="container-fluid">    
            
<!--            <div class="col-md-12">
                <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 
                <legend style="border-style: none;border-width: 0;font-size: 14px;line-height: 20px;margin-bottom: 0;width: auto;padding: 0 10px;border: 1px solid #e0e0e0;">
                    &nbsp;  <i class="ace-icon fa fa-hand-o-right green"></i> &nbsp;&nbsp; BG Setup &nbsp;&nbsp;
                </legend>

                 <div class="col-md-12 row">      
                            
                        <div class="col-md-5 form-group">
                            
                            <label for="Title"> Auto Stages : </label>
                            <span class="block input-icon input-icon-right">
                                
                                <select name="stageid" chosen 
                                        data-placeholder="--select--" 
                                        id="stageselect" 
                                        class="chosen-select form-control"
                                        ng-model="stages.stageid">
                                    <option value=""></option>
                                    <?php 
                                        echo $stageOption; 
                                    ?>
                                </select>
                                
                            </span>
                            <span class="help-block stageid_help"></span>
                        </div>
                     
                        <div class="col-md-1">
                         
                            <label for="Title"></label>
                            <span class="block input-icon input-icon-right">
                                <button class="btn btn-info" type="button" ng-click="getStageRelatedXmlConfig( stages )">
                                    <i class="ace-icon fa fa-arrow-right bigger-110 pull-right"></i> &nbsp;&nbsp; 
                                </button>
                            </span>
                       
                        </div>
                     
                 </div>
                    
                </fieldset>
            </div>
             -->
             
                <div class="col-md-12">
                
                <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 
                    
                    <legend style="border-style: none;border-width: 0;font-size: 14px;line-height: 20px;margin-bottom: 0;width: auto;padding: 0 10px;border: 1px solid #e0e0e0;">
                        &nbsp;  <i class="ace-icon fa fa-hand-o-right green"></i> &nbsp;&nbsp; Xml Format &nbsp;:&nbsp; <?php echo $stagename;?>
                    </legend>

                    <input type="hidden"  id="stageid" name="stageid" value="<?php echo $stageid; ?>"/>
                    <input type="hidden"  id="round"  name="round" value="<?php echo $round; ?>"/>
                    <input type="hidden"  id="wmid"  name="wmid" value="<?php echo $wmid; ?>"/>
                    <input type="hidden"  id="wfid"  name="wfid" value="<?php echo $wfid; ?>"/>
                    <input type="hidden"  id="bgtype"  name="bgtype" value="<?php echo $bgtype; ?>"/>
                    <input type="hidden"  id="modetype"  name="bgtype" value="<?php echo $modetype; ?>"/>
                    <input type="hidden"  id="chunkid"  name="chunkid" value=""/>
                    <input type="hidden"  id="chunkname"  name="chunkname" value=""/>
                            
                            
                    <div class="col-md-12 row clearfix">   
                       
                        
                        <div class="col-md-6">
                            
                            <div class="col-md-2 pull-right"> 
                                
                                <a href="#" class="btn btn-primary no-radius smaller-100 pull-left" ng-click="addnewChunk()" ng-model="addNewChunk">
                                    <i class="ace-icon fa glyphicon-plus smaller-100"></i>
                                    Add
                                    <span class="badge badge-warning badge-left"></span>
                                </a>
                               
                            </div>
                            
                            <div class="col-md-10 treeboard"> 
                                
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="form-group">
                                <h4 class="smaller lighter green">
                                        <i class="ace-icon fa fa-list"></i>
                                        Input Screen   :  <span> <b> @{{caption}} </b></span>
                                </h4>
                            </div>
                            <div class="form-group">
                            <textarea ng-model="bgsetup.xmlFormat" id="xmlFormat"  name="content" data-provide="markdown" data-iconlibrary="fa" rows="30" class="form-control">                    
                            </textarea>
                            </div>
                            <div class="form-group">
                                <div class="col-md-offset-4 col-md-6">
                                    <button class="btn btn-info" type="button" ng-click="saveXml( bgsetup )">
                                        <i class="ace-icon fa fa-check bigger-110"></i>
                                        Submit
                                    </button>
                                    &nbsp; &nbsp; &nbsp;
                                    <button class="btn" type="reset" ng-click="reset()">
                                        <i class="ace-icon fa fa-undo bigger-110"></i>
                                        Reset
                                    </button>
                                </div>
                        
                            </div>
                            
                       </div>
                        
                  </div>
                    
                </fieldset>
                
            </div>     
             
        </div>
    
</div>     
    

@endsection

@section('bootomScripts')	


<script src="{{url('/assets/dist/js/chosen.jquery.min.js')}}"></script>
<script src="{{url('/assets/dist/js/jquery.nestable.min.js')}}"></script>

<link rel="stylesheet" href="{{url('assets/dist/css/animsition.min.css')}}" />
<script src="{{url('/assets/dist/js/animsition.min.js')}}"></script> 
<script src="{{url('/angular/bgsetup.app.js')}}"></script> 

<script>
    var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
    $('.magnus-box').ace_ajax('loadScripts', scripts , function() {});
</script>

@endsection
                        