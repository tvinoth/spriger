@extends('layouts.templateMaster')
@section('content')

<div class="row">
    <div class="container-fluid">    
        
        <div class="col-md-12">
            
        </div>
        
        <div class="col-md-12">

            <fieldset style="border: 1px solid #2B7DBC;padding: 10px;"> 

            <legend style="border-style: none;border-width: 0;font-size: 14px;line-height: 20px;margin-bottom: 0;width: auto;padding: 0 10px;border: 1px solid #e0e0e0;">
                &nbsp;  <i class="ace-icon fa fa-hand-o-right green"></i> &nbsp;&nbsp; BG cofiguration &nbsp;:&nbsp; <?php //echo $stagename;?>
            </legend>

            <div class="col-md-12 row clearfix">   
                
                <div class="col-md-6">
                  
                    <div class="col-md-10 form-group">
                        <label for="Title"> Select Workflow :</label>
                        <span class="block input-icon input-icon-right">
                            <select name="wfmstr" chosen 
                                    data-placeholder="--select--" 
                                    id="wkflwmstselect" 
                                    class="chosen-select form-control"
                                    ng-model="workflow.workflowMasterlist">
                                <option value=""></option>
                                <?php echo $workflowmasterlist; ?>
                            </select>
                
                        </span>
                        <span class="help-block wflwm_help"></span>
                    </div>
                
                    <div id="list" class="col-md-12 treeboard"> 
                        
                    </div>

                </div>

                <div class="col-md-6">
                    <div class="form-group">
                        <h4 class="smaller lighter green">
                                <i class="ace-icon fa fa-list"></i>
                                Input Screen   :  <span> <b> @{{caption}} </b></span>
                        </h4>
                    </div>
                    <div class="form-group">
                    <textarea ng-model="bgsetup.xmlFormat" id="xmlFormat"  name="content" data-provide="markdown" data-iconlibrary="fa" rows="30" class="form-control">                    
                    </textarea>
                    </div>
                    <div class="form-group">
                        <div class="col-md-offset-4 col-md-6">
                            <button class="btn btn-info" type="button" ng-click="saveXml( bgsetup )">
                                <i class="ace-icon fa fa-check bigger-110"></i>
                                Submit
                            </button>
                            &nbsp; &nbsp; &nbsp;
                            <button class="btn" type="reset" ng-click="reset()">
                                <i class="ace-icon fa fa-undo bigger-110"></i>
                                Reset
                            </button>
                        </div>

                    </div>

               </div>

          </div>

        </fieldset>

        </div>     
            
    </div>
</div>     
    

@endsection

@section('bootomScripts')	


<script src="{{url('/assets/dist/js/chosen.jquery.min.js')}}"></script>
<script src="{{url('/assets/dist/js/jquery.nestable.min.js')}}"></script>

<link rel="stylesheet" href="{{url('assets/dist/css/animsition.min.css')}}" />
<script src="{{url('/assets/dist/js/animsition.min.js')}}"></script> 
<script src="{{url('/angular/bgindex.app.js')}}"></script> 

<script>
    var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
    $('.magnus-box').ace_ajax('loadScripts', scripts , function() {});
</script>
<style  type="text/css">
        .drag_disabled{
        pointer-events: none;
    }

    .drag_enabled{
        pointer-events: all;
    }
</style>
@endsection
                        