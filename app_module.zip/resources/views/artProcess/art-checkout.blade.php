@extends('layouts.templateMaster')
@section('content')		

<div class="row">
    <div class="col magnus-box">
        
        <div class="row">      
            
            <div class="col-md-12">

                    <div class="progress" style="display: none">
                        <div  
                             class="progress-bar progress-bar-striped progress-bar-animated" 
                             role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" 
                             style="width: 75%;">
                        </div>
                    </div>
            </div>
            <div class="col-md-12">
                  
                <div class="col-md-4">
                    <div class="form-group">
                            <label for="Title"> Book Id : </label>
                            <input type="text" class="form-control" name="bookpublishername" value="{{$book_id}}"  disabled="true">
                    </div>
                </div>
                    
                         
                <div class="col-md-4">
                    <div class="form-group">
                            <label for="Title"> Book Title : </label>
                            <input type="text" class="form-control" name="bookpublishername" value="{{$job_title}}"  disabled="true">
                    </div>
                </div>
                    
                
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="Title"> Chapter No : </label>
                            <input type="text" class="form-control" name="bookpublishername" value="{{$chapter_no}}"  disabled="true">
                     </div>
                </div>
                
            </div>
            
            <div class="col-md-12">
                @if(in_array(strtolower($chapter_no),$typefmbm) != true)
                <div class="col-md-3">
                       <div class="form-group">
                        <label for="Title"> Chapter Title : </label>
                            <input type="text" class="form-control" name="bookpublishername" value="{{$chpater_name}}"  disabled="true">
                     </div>
                </div>
                @endif
                <div class="col-md-3">
                    <div class="form-group">
                        <label for="Title"> Stage : </label>
                            <input type="text" class="form-control" name="bookpublishername" value="{{$stage}}"  disabled="true">
                    </div>
                </div>
                
                <div class="col-md-2">
                        <div class="form-group"> 
                            <label for="Title"> <font color="white">.</font></label><br/>
                            <i class="fa fa-window-maximize" aria-hidden="true"></i>
                            
                            <button id="openFolderBtn" type="button" class="btn btn-round btn-info btn-sm" ng-click="openDrive( '{{$open_path}}'  , '' )" ng-disabled="openButtonDisabled">
                                <span ng-show="openFolderButtonText == 'In Progress'">
                                    <i class="fa fa-spinner fa-spin"></i>
                                </span> 
                                <i class="ace-icon fa fa-folder-open bigger-120" ng-show="openFolderButtonText == 'Open Folder'"></i> 
                                &nbsp; @{{openFolderButtonText}}&nbsp;
                            </button>
                            
                            <?php if(  $isDownloaded !== 2){ ?> 
                            <button id="downloadButton" class="btn btn-round btn-info btn-sm" 
                            ng-disabled="downloadButtonDisabled"
                            ng-click="artInputFileDownload( '{{$job_id}}'  , '{{$meta_id}}'  , '{{$fhParam['methodName']}}'  , '{{$fhParam['checkoutSrcPath']}}'  , '{{$fhParam['checkoutDestPath']}}'  , '{{$fhParam['extension']}}'  , '{{$fhParam['deleteFlag']}}' )" 
                            style="display:none"
                            >
                                <span ng-show="downloadButtonText == 'Download In Progress'">
                                    <i class="fa fa-spinner fa-spin"></i>
                                </span> 
                                <i class="ace-icon fa fa-download bigger-120" ng-show="downloadButtonText == 'Download Raw Files'"></i> 
                                &nbsp;@{{downloadButtonText}}&nbsp;
                            </button>
                            <?php } ?>
                        </div>
                </div>
                <div class="col-md-2">
                    <div class="form-group">
                        <label for="Title">Job sheet view</label><br/>
                        <button type="button" ng-click="viewjobSheet( '{{$job_id}}','{{$stage}}','{{$chapter_no}}')" class="btn  btn-round btn-warning btn-sm">
                        <i class="ace-icon fa fa-file-excel-o bigger-100"></i> 
                        &nbsp;  View  &nbsp;
                        </button>
                    </div>
                </div>
                <div class="col-md-2">
                     <div class="form-group">
                        <label for="Title"> Query : </label>
                        <a ng-click="qmsspike('{{$job_id}}','{{$currentuserid}}','{{$book_id}}','qms')" data-toggle="modal" data-target="#qmsModal" class="fa fa-comments-o fa-2x pointer" /></a>  
                    </div>
                     <div class="form-group">
                        <label for="Title"> Spike : </label>
                        <a ng-click="qmsspike('{{$job_id}}','{{$currentuserid}}','{{$book_id}}','spike')" data-toggle="modal" data-target="#spikeModal" class="fa fa-list-ul fa-2x pointer" /></a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-12">
                
                <div class="col-md-4">
                    
                </div>
                <div class="col-md-4">
                    
                </div>
                
                
            </div>
            <div class="clear:both"></div>
            
            <br/><br/><br/>
            
            <div class="col-md-12">
             
                
            <div class="col-md-8 pull-right">
                
                <div class="col-md-2">
                    <button type="button" 
                            ng-disabled="checkinButtonDisabled"
                            
                            class="btn btn-primary btn-round" 
                            ng-click="artCheckin(  '{{$job_id}}'  , '{{$meta_id}}'  , '{{$fhParam['methodName']}}' , '{{$fhParam['checkinSrcPath']}}' , '{{$fhParam['checkinTempDestPath']}}' , '{{$fhParam['extension']}}' , '{{$fhParam['deleteFlag']}}', '{{$open_path}}'  )">
                        
                        <span ng-show="checkinButtonText == 'In Progress'">
                                <i class="fa fa-spinner fa-spin"></i>
                        </span>
                        
                        <i class="ace-icon fa fa-anchor bigger-120" ng-show="checkinButtonText == 'Check-in'"></i>
                        &nbsp;
                        @{{checkinButtonText}}
                        &nbsp;
                    </button>
                    
                </div>
                
                <div class="col-md-2">      
                   <input type="hidden" value="<?php echo $isDownloaded;?>" name="isTokenDownloaded" /> 
				     <input type="hidden" value="<?php echo $open_path;?>" id="doCloseFolder" /> 
                    <button type="button" ng-show ='artProcesscomplete' 
                            ng-disabled="submitButtonDisabled" id="submitbutton"
                          
                            class="btn btn-primary btn-round" 
                            ng-click="artComplete(  '{{$job_id}}'  , '{{$meta_id}}' , '{{$fhParam['methodName']}}' , '{{$fhParam['checkinSrcPath']}}' , '{{$fhParam['checkinDestPath']}}' , '{{$fhParam['extension']}}' , '{{$fhParam['deleteFlag']}}'  )" >
                         
                        <span ng-show="submitButtonText == 'In Progress'">
                                <i class="fa fa-spinner fa-spin"></i>
                        </span> 
                        <i class="ace-icon fa fa-file-word-o bigger-120" ng-show="submitButtonText == 'Submit'"></i>
                        
                        &nbsp;
                        @{{submitButtonText}}
                        &nbsp;
                        
                    </button>
                    
                    <button style="display:none" type="button"  id="barreportsubmitbutton" ng-show="Parreportbuttonenable"
                            class="btn btn-primary btn-round" 
                            ng-click="parreportProcess('{{$job_id}}')">
                        <i class="ace-icon fa fa-file-word-o bigger-120" ng-show="submitButtonText == 'Submit'"></i>
                        
                        &nbsp;
                        @{{submitparreportButtonText}}
                        &nbsp;
                    </button>
                    
                </div>
            </div>
            
	</div>
        
    </div>	
    </div>
    @include('layouts.qms-spikeblade')
    <!-- click open chapter wise files -->
    <a href="#show-openfiles" id="show-doopenfiles" data-toggle="modal"></a>
    <div id="show-openfiles" class="modal fade" tabindex="-1">
    <div class="modal-dialog" style="width: 90%;">
        <div class="modal-content">
            <div class="modal-header no-padding">
                <div class="table-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        <span class="white">&times;</span>
                    </button>
                    Art Information of Chapter @{{chaptershow}} - Book ID @{{bookidshow}} 
                </div>
            </div>
            
            <form method="post" name="addartworkinfo" ng-submit="insertArtitem('{{$open_path}}')" >
            <div class="modal-body" style="height:@{{heightofmodal}}px;overflow:auto">            
                <span><p class="text-center red" style="color:red;font-weight:bolder">@{{showallresponse}}</p></span>
                <span><p class="red">@{{existchapterlist}}</p></span>
		<input type="hidden" ng-model="ChapterJobId" class="form-control" value="{{$job_id}}"  />
		<input type="hidden" name="metaid" ng-model="ChapterMetaid" class="form-control" value="{{$meta_id}}"  />
                <input type="hidden" name="chaptername" class="form-control" value="@{{chaptershow}}"/>
                
		<table class="table table-bordered table-striped artchapteritems">
                     <colgroup>
                                        <col class="col-md-2">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-1">
                                        <col class="col-md-2">
                                        <col class="col-md-1">                                        
                                    </colgroup>
                                    
                    <thead class="thin-border-bottom">
			<tr>
                            <th>Art Name</th>                            
                            <th>File</th>
                            <th>Type</th>
                            <th>Complexity</th>
                            <th>Mode</th>                            
                            <th>Work Involved</th>
                            <th>Input Color Mode</th>
                            <th>Output Color Mode</th>
                            <th>Remarks</th>
                            <th>Action</th>
			</tr>
                    </thead>
                    <tr ng-repeat="item in chapterlist track by $index" id="chapter_@{{$index}}">
                        <td>
                            <input type="text" name="chapters[]" class="form-control" value="@{{item.name}}" ng-model="item.name" readonly="true" required/>
                        </td>
                        <td> 
                            <select  class="form-control" name="file[]" ng-model="item.inputFileType" required/>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="filety in filetype track by $index"  value="@{{filety}}" ng-selected="filety == item.inputFileType?true:false"> @{{filety}}</option>
                            </select>
                        <td>
                            <select  class="form-control" name="type[]" ng-model="item.modeofReceipt" required>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="fileexn in fileextension track by $index"  value="@{{fileexn}}" ng-selected="fileexn == item.modeofReceipt?true:false"> @{{fileexn}}</option>
                            </select>
                        <td>
                            <select  class="form-control" name="complexity[]" ng-model="item.complexity"/>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="complex in complexity track by $index"  value="@{{complex.id}}" ng-selected="complexity[2]"> @{{complex.name}}</option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="mode[]" ng-model="item.mode" required/>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="modety in modetype track by $index"  value="@{{modety}}" ng-selected="modety == item.mode?true:false"> @{{modety}}</option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="workinvolved[]" ng-model="item.workInvolved" required>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="work in workinvolved track by $index"  value="@{{work}}" ng-selected="work == item.workInvolved?true:false"> @{{work}}</option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="inputcolor[]" ng-model="item.inputColor" required/>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="color in colours track by $index"  value="@{{color}}" ng-selected="color == item.inputColor?true:false"> @{{color}}</option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="outputcolor[]" ng-model="item.outputColor" required/>
                                <option  value=""> -- Select -- </option>
                                <option ng-repeat="color in colours track by $index"  value="@{{color}}" ng-selected="color == item.outputColor?true:false"> @{{color}}</option>
                            </select>
                        </td>
                        <td>
                            <input type="text" class="form-control" name="remarks[]">
                        </td>
                        <td>
                            <i class="fa fa-times-circle red fa-2x"  ng-click="deleteArtItem($index)" aria-hidden="true"></i>
                        </td>
                    </tr>  
		</table>
                </div>
            </div>
                <!--ng-show="saveChapterbutton"-->
            <div class="modal-footer no-margin-top">
                <button type="submit"  class="btn btn-round btn-primary" id="chapterinfo"  ng-disabled="savechapterdisabled">Submit</button>		
                <button class="btn btn-round btn-primary" id="editCheckItem-close" data-dismiss="modal">Cancel</button>					
            </div>
            </form>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    
    <a href="#modal-edit" id="show-cucview" data-toggle="modal"></a>
    <div id="modal-edit" class="modal fade" tabindex="-1">
        <div class="modal-dialog" style="width: 80%">
            <div class="modal-content">
                <div class="modal-header no-padding">
                    <div class="table-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                <span class="white">&times;</span>
                        </button>
                        @{{jobandcucview}}
                    </div>
                </div>

                <div class="modal-body">
                    <div id="xmlContent" style="height:@{{heightofmodal}}px;overflow:auto;"><p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p></div>
                </div>
                <div class="modal-footer no-margin-top">
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
    
    <a href="#show-artmeataerror" id="show-doartmetafiles" data-toggle="modal"></a>
    <div id="show-artmeataerror" class="modal fade" tabindex="-1">
    <div class="modal-dialog" style="width: 80%;">
        <div class="modal-content">
            <div class="modal-header no-padding">
                <div class="table-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                        <span class="white">&times;</span>
                    </button>
                    Art Metadata Invalid Images @{{chaptershow}} - Book ID @{{bookidshow}} 
                </div>
            </div>
            <div class="modal-body">            
                <span><p class="text-center red" style="color:red;font-weight:bolder">@{{artmeatadatarror}}</p></span>
                <div style="height:200px;overflow:auto;">
                    <table class="table table-bordered table-striped">
                    <tr ng-repeat="item in artmeatachapterlist track by $index" id="chapter_@{{$index}}">
                        <td>
                            @{{item}}
                        </td>
                    </table>
                </div>
            </div>
                <!--ng-show="saveChapterbutton"-->
            <div class="modal-footer no-margin-top">
                <button class="btn btn-round btn-primary" id="editCheckItem-close" data-dismiss="modal">Cancel</button>					
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
    </div>
@endsection
@section('bootomScripts')	
<script src="{{url('/angular/art-chapter-list.app.js')}}"></script> 
@endsection