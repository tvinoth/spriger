@extends('layouts.templateMaster')
@section('content')	

<div class="row chpterlist_sec" ng-cloak>
	<div class="col magnus-box">
		
		<div>
			<table class="table table-striped table-bordered table-hover" datatable="ng" dt-options="vm.dtOptions">
				<thead class="thin-border-bottom">
                                    <tr width="100">	
                                        <th width="35%"  style="display: none">  </th>
                                        <th width="35%"> Chapter No </th>
                                        <th width="35%"> Status </th>
                                        <th width="15%"> Action </th>
                                    </tr>
				</thead>
				<tbody>	
                                    <input type="hidden" name="getjobID" id="currentjob" value="{{$jobID}}">
                                    <tr ng-repeat="item in chapterList" ng-if = "item.LOCATION !='' && item.metaRound ==104  ">
                                        <td style="display: none">
                                            <div style="word-wrap: break-word;">@{{item.CHAPTER_SEQ}}</div>
                                        </td>
                                        <td>
                                            <div style="word-wrap: break-word;">@{{item.CHAPTER_NO}}</div>
                                        </td>
                                        <td>
                                            <span ng-if="item.status == 2">
                                                Completed
                                            </span>
                                            <span ng-if="item.status != 2">
                                                Available
                                            </span>
                                        </td>
                                        <td class="pointer">
                                            <span ng-if="item.status == 2">
                                                <button  class="btn btn-success btn-sm"> Completed </button>
                                            </span>
                                            <span ng-if="item.status == null || item.status == 1">
                                                <button type="button" id="artCheckout_@{{item.METADATA_ID}}" class="btn btn-primary btn-sm" 
                                                ng-click="artCheckout( item , this )" 
                                                > Checkout </button>
                                            </span>
                                            
                                            <span ng-if="item.status == null">
                                                <button type="button" id="artCheckout_@{{item.METADATA_ID}}" class="btn btn-danger btn-sm" 
                                                ng-click="noArt( item , this )" 
                                                > No Art </button>
                                            </span>
                                        </td>
                                    </tr>
									
                                    <tr ng-repeat="item in chapterList" ng-if = "item.LOCATION !='' && item.metaRound ==116 && item.clientstatus == 2  ">
                                        <td style="display: none">
                                            <div style="word-wrap: break-word;">@{{item.CHAPTER_SEQ}}</div>
                                        </td>
                                        <td>
                                            <div style="word-wrap: break-word;">@{{item.CHAPTER_NO}}</div>
                                        </td>
                                        <td>
                                            <span ng-if="item.status == 2">
                                                Completed
                                            </span>
                                            <span ng-if="item.status != 2">
                                                Available
                                            </span>
                                        </td>
                                        <td class="pointer">
                                            <span ng-if="item.status == 2">
                                                <button  class="btn btn-success btn-sm"> Completed </button>
                                            </span>
                                            <span ng-if="item.status == null || item.status == 1">
                                                <button type="button" id="artCheckout_@{{item.METADATA_ID}}" class="btn btn-primary btn-sm" 
                                                ng-click="artCheckout( item , this )" 
                                                > Checkout </button>
                                            </span>
                                            
                                             <span ng-if="item.status == null">
                                                <button type="button" id="artCheckout_@{{item.METADATA_ID}}" class="btn btn-danger btn-sm" 
                                                ng-click="noArt( item , this )" 
                                                > No Art </button>
                                            </span>
                                            
                                        </td>
                                    </tr>
				</tbody>			
			</table>
		</div>
	</div>	
</div> 

@endsection
@section('bootomScripts')	
<script src="{{url('/angular/art-chapter-list.app.js')}}"></script> 
@endsection