@extends('layouts.templateMaster')
@section('content')	
<div class="row joblist_sec" ng-show="jobListView" ng-cloak>
    <div class="col magnus-box">
		<div>	
                    
			<table class="table table-striped table-bordered table-hover" datatable="ng" dt-options="vm.dtOptions">
				<thead class="thin-border-bottom">
				<tr>	
                                        
					<th width="10%">Book Id</th>
					<th width="30%">Book Title</th>
					<th width="10%">PM Name</th>
					<th width="10%">Created Date</th>
                                       
				</tr>
				</thead>
				
				<tbody>					
                                    <tr ng-repeat="item in projectList" >
                                            
                                            <td><div style="word-wrap: break-word;">@{{item.BOOK_ID}}</div></td>
                                            <td id="Checkout_@{{item.JOB_ID}}" ng-click="artContinue( item , this )" class="pointer"  >@{{item.JOB_TITLE}} - <span class="authornamestyle">@{{item.AUTHOR_NAME    ==  ''?item.EDITOR_NAME:item.AUTHOR_NAME}}</span></td>
                                            <td>@{{item.PM_NAME}}</td>
                                            <td>@{{item.CREATED_DATE}}</td>
					</tr>
				</tbody>
								
			</table>	
		</div>
    </div>	
</div>


<div class="row chpterlist_sec" ng-show="chapterListView">
    <div class="col magnus-box">
		<div>	
                    
			<table class="table table-striped table-bordered table-hover" datatable="ng" dt-options="vm.dtOptions">
				<thead class="thin-border-bottom">
				<tr width="100">	
                                        
					<th width="25%"> Chapter No </th>
					<th width="45%"> Chapter Title </th>
					<th width="15%"> Due Date </th>
					<th width="15%"> Action </th>
				</tr>
				</thead>
				
				<tbody>					
					<tr ng-repeat="item in chapterList" class="pointer">
                                            
                                            <td><div style="word-wrap: break-word;">@{{item.CHAPTER_NO}}</div></td>
                                            <td><div style="word-wrap: break-word;">@{{item.CHAPTER_TITLE}}</div></td>
                                            <td>@{{item.DUE_DATE}}</td>
                                            <td>
                                                <button type="button" id="artCheckout_@{{item.METADATA_ID}}" class="btn btn-primary btn-sm" 
                                                ng-click="artCheckout( item , this )" 
                                                data-loading-text="<i class='fa fa-circle-o-notch fa-spin'></i> Processing "
                                                > Checkout </button>
                                            </td>
					</tr>
                                        
				</tbody>
								
			</table>	
		</div>
    </div>	
</div>
@endsection

@section('bootomScripts')	
    <script src="{{url('/angular/art-project-list.app.js')}}"></script>
@endsection