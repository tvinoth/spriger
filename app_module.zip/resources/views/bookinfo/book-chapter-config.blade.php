<style>
.modalpopuptitlecolor{
    color:#3da4cb;font-weight:bolder;    
}
</style>
    
<div class="row" ng-init='getChapterConf()'>
    
    <div class="col-md-3">
        <h4>
            <b>Book Title : </b>  
            {{$book_title}}
        </h4>
    </div>
    
    <div class="col-md-3" >
        <h4>
            <b> Book ID : </b>  
            {{$book_id}}
        </h4>
    </div>
    
    <div class="col-md-3">
        <h4>
           <b>  Job ID : </b>  
            <?php 
                if( isset( $job_code_id ) ){
                    echo $job_code_id;
                }else{
                    echo '&nbsp;&nbsp;--';
                }
            ?>

        </h4>
    </div>
    
    <div class="col-md-3" ng-show="jobsheetlessbtn">
        <h4>
            <b> Jobsheet Less : </b>  
        <label>
            <input id="jsless"  name="jsless" class="ace ace-switch ace-switch-5" ng-click="ConfirmJsless()" type="checkbox">
            <span class="lbl"></span>
        </label> 
        </h4>
    </div>
    
</div>

<br>

<div style="height:50px;overflow:auto;" ng-show="errorshow">
    <ul  ng-repeat="exist in shownotavaiablechapter track by $index">
        <li>
            <p class="text-danger">@{{exist}}</p>
        </li>
    </ul>
</div>

<div class="row">
        <table class="table table-striped table-bordered" datatable="ng" dt-options="chpconfig.dtOptions">
        <thead class="thin-border-bottom">
            <tr>
                <th width="05%">Chapter No</th>
                <th width="05%">CE Level</th>
                <th width="10%">Worflow </th>
                <th width="10%">Action </th>
            </tr>
        </thead>
        <tbody>
       <!--<input type='hidden' name='embType' id='embType' value='@{{emptype}}' /> -->
       <input type='hidden' name='embType' id='embType' value='1' />
        <tr ng-repeat="item in chapterlist">
            
            <td>@{{item.CHAPTER_NO}}</td>
            
            <td  id="checkinbutton_@{{item.METADATA_ID}}">                
                <select ng-readonly = 'item.productionStart' id="categoryId_@{{item.METADATA_ID}}" class="form-control" name="chapterlevel" ng-init="eproofsystemtype=item.ARTICLE_CATEGORY.toString()||jobCategoryType.toString()" ng-change="selectworkflow('@{{item.METADATA_ID}}')" ng-model="eproofsystemtype">
                    <option  value=""> -- Select -- </option>
                    <option  value="1"> 1</option>
                    <option  value="2"> 2</option>
                    <option  value="3"> 3 </option>
                </select>
            </td>
            <td>
                
                <select ng-readonly = 'item.productionStart' name="workflow" class="form-control" ng-init="workflowId=item.PRODUCTION_WORKFLOW.toString()||bookWorkflowId.toString()" ng-model="workflowId" id="workflowId_@{{item.METADATA_ID}}">
                    <option value=""> --Select--</option>
                    <option id="@{{ul.CATEGORY}}" data-comid ="@{{ul.CATEGORY}}_@{{ul.EMBBED_TYPE}}_@{{ul.ROUND_ID}}" ng-if="eproofsystemtype == ul.CATEGORY"  ng-repeat="ul in wfdata" value="@{{ul.WORKFLOW_MASTER_ID}}">@{{ul.WORKFLOW_MASTER_NAME}}</option>
                </select>
            </td>
            <td>
                
              <button ng-disabled = 'item.productionStart' type="button" id="artCheckout_2717" class="btn btn-primary btn-sm btn-success" ng-click="chapterConfig(item.METADATA_ID)"> Save </button>
             <span ng-if="jobsheetless == 1" >
              <button data-ng-if="!item.productionStart" ng-show='jobsheetless' type="button" id="movetoPro" class="btn btn-primary btn-sm" ng-click="metaMovetopro(item.METADATA_ID)"> Move to Production </button>
              <button  data-ng-if="item.productionStart" ng-show='jobsheetless' type="button" id="movetoPro" ng-disabled="true" class="btn btn-primary btn-sm btn-warning" > In Production </button>
               
              <!-- <button  type="button" id="movetoPro" class="btn btn-primary btn-sm" ng-click="metaMovetopro(item.METADATA_ID)"> Move to Production </button>-->
             <span ng-if="jobsheetless == 1" >
		    </td>
            
        </tr>	
        </tbody>
    </table>		
</div>

@section('bootomScripts')	

<script src="{{url('/angular/book-info.app.js')}}"></script>

<script>
function ConfirmJsless(){
    
  var x = confirm("Are you sure you want to delete?");
  
  if (x){
      return true;
  }else{
      return false;
  }
    
}

var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
$('.magnus-box').ace_ajax('loadScripts', scripts, function() {});
</script>
@endsection