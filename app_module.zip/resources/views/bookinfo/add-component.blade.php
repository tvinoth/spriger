 @include( 'bookinfo/tab-header-section' )
        
    <div class="">
        <button type="button" class="btn btn-primary btn-sm" id="addCompoRow" style="margin:10px;float:right;position:absolute;z-index:1;top:20px;left:92%;">Add Component</button>
    </div>
 
    <div class="row">
        <table class="table table-striped table-bordered" datatable="ng" id="componentDatatable">
            <thead class="thin-border-bottom">
                <tr>	
                    <th>Created at </th>
                    <th>Component Name</th>
                    <th>Component type</th>
                    <th>Description</th>
                    <th>Created Date</th>					
                    <th>Status</th>
                    <th>Action  &nbsp; </th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="item in compolist track by $index" ng-include="getCompoTemplate(item)">
                </tr>
            </tbody>
        </table>
    </div>
    
    <a href="#showcompoedit" id="show-showcompoform" data-toggle="modal"></a>
    <div id="showcompoedit" class="modal fade" tabindex="-1">
            <div class="modal-dialog" style="width: 80%">
                <div class="modal-content">
                    <div class="modal-header no-padding">
                        <div class="table-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                                    <span class="white">&times;</span>
                            </button>
                            Add Component
                        </div>
                    </div>
                    <div style="height:50px;overflow:auto;" ng-show="validerrorshow">
                        <ul  ng-repeat="exist in showvalidationerror track by $index">
                            <li>
                                <p class="text-danger">@{{exist}}</p>
                            </li>
                        </ul>
                    </div>
                    <div class="modal-body">
                        <span id="xmlContent" class="">
                            <div class="row">
                                <form style="padding: 20px">
                                    <div class="form-group">
                                      <label for="exampleInputEmail1">Component Name</label>
                                      <input type="email" class="form-control" id="formcompname" aria-describedby="emailHelp" placeholder="Enter component name">
                                      <small id="emailHelp" class="form-text text-muted">It will consider as client filenaming format.</small>
                                    </div>

                                    <div class="form-group">
                                        <label for="inlineFormCustomSelect">Round Name</label>
                                        <select class="form-control" id="formcompround">
                                            <option selected>--Select--</option>
                                            <option ng-repeat="roundinf in roundsenum" value="@{{roundinf.ID}}">
                                                @{{roundinf.NAME}}
                                            </option>
                                        </select>
                                    </div>
 
                                    <div class="form-group">
                                        <label for="exampleInputPassword12">Component Type</label>
                                        <select class="form-control" id="formcomptype">
                                            <option selected>--Select--</option>
                                            <option ng-repeat="compinf in compsenum" value="@{{compinf.ID}}">
                                            @{{compinf.NAME}}
                                            </option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                      <label for="exampleInputPassword13">Description</label>
                                      <input type="text" class="form-control" id="formcompdescrip" placeholder="Description">
                                    </div>
                                </form>
                            </div>   
                        </span>

                    </div>

                    <div class="modal-footer no-margin-top">    
                        <div class="modal-footer no-margin-top">
                            <button type="submit"  class="btn btn-round btn-primary" ng-click="createComponet()">Save</button>		
                            <button class="btn btn-round btn-primary" id="editCheckItem-close" data-dismiss="modal">Cancel</button>					
                        </div>
                   </div>
                </div>
                <!-- /.modal-content -->
            </div>
        <!-- /.modal-dialog -->
    </div>

 
 
    <script type="text/ng-template" id="listTemplate">
        <td>
            <select class="form-control" disabled>
                <option value="">--Select--</option>
                <option ng-repeat="roundinf in roundsenum" ng-selected="roundinf.ID == item.ROUND_ID ? true : false " value="@{{roundinf.ID}}">
                    @{{roundinf.NAME}}
                </option>
            </select>
        </td>
        <td>
            @{{item.NAMING_CONVENTION}}</td>
        <td>
            <select class="form-control" disabled>
                    <option value="">--Select--</option>
                    <option ng-repeat="compinf in compsenum" ng-selected="compinf.ID == item.COMPONENT_TYPE ? true : false " value="@{{compinf.ID}}">
                        @{{compinf.NAME}}
                    </option>
            </select>
        </td>
        <td>@{{item.DESCRIPTION}}</td>
        <td>@{{item.CREATED_AT}}</td>
        <td>
            <select class="form-control" disabled>
                <option value="">--Select--</option>
                <option ng-repeat="status in statusenum" ng-selected="status.STATUS_ID == item.STATUS?true:false" value="@{{status.STATUS_ID}}">@{{status.NAME}}
            </select>
        </td>
        <td id="setupdatefile_@{{$index}}">
                <div class="hidden-sm hidden-xs action-buttons">
                    <a class="green" ng-click="editComponent(item)"><i class="ace-icon fa fa-pencil bigger-130"></i></a>
                    <a class="red" ng-click="removeComponentRow($index,item.ID)"><i class="ace-icon fa fa-trash-o bigger-130"></i></a>
                </div>
            </td>
        </td>
    </script>
    
    <script type="text/ng-template" id="editTemplate">
        <td>
            <select class="form-control required_@{{$index}}" id="roundname_@{{$index}}">
                <option value="">--Select--</option>
                <option ng-repeat="roundinf in roundsenum" ng-selected="roundinf.ID == item.ROUND_ID ? true : false " value="@{{roundinf.ID}}">
                    @{{roundinf.NAME}}
                </option>
            </select>
        </td>
        <td>
            <input style="width:100%" type="text" value="@{{item.NAMING_CONVENTION}}" class="form-control required_@{{$index}}" id="componame_@{{$index}}">
            <input style="width:100%" type="hidden" value="@{{item.ID}}" class="form-control required_@{{$index}}" id="rowid_@{{$index}}">
        </td>
        <td>
            <select class="form-control required_@{{$index}}" id="compotype_@{{$index}}">
                    <option value="">--Select--</option>
                    <option ng-repeat="compinf in compsenum" ng-selected="compinf.ID == item.COMPONENT_TYPE ? true : false " value="@{{compinf.ID}}">
                        @{{compinf.NAME}}
                    </option>
            </select>
        </td>
        <td>
            <textarea class="form-control required_@{{$index}}" id="compodesc_@{{$index}}" ng-model="item.DESCRIPTION" style="width:100%">@{{item.DESCRIPTION}}</textarea>
        </td>
        <td> -- </td>
        <td>
            <select class="form-control" id="status_@{{$index}}">
                <option value="">--Select--</option>
                <option ng-repeat="status in statusenum" ng-selected="status.STATUS_ID == item.STATUS?true:false" value="@{{status.STATUS_ID}}">@{{status.NAME}}
            </select>
        </td>
        <td id="updateComponents_@{{$index}}">
            <button type="button" class="btn btn-primary btn-xs pointer"  ng-click="updateComponentInfo($index,item)">Update</button> &nbsp;&nbsp;
            <button type="button" class="btn btn-primary btn-xs pointer"  ng-click="undoChanges()">Undo</button>
        </td>
        </td>
    </script>
    
@section('bootomScripts')	
<script src="{{url('/angular/book-info.app.js')}}"></script> 
<script>
var scripts = [null,"{{url('/assets/dist/js/bootbox.min.js')}}",null]
$('.magnus-box').ace_ajax('loadScripts', scripts, function() {});
</script>
@endsection