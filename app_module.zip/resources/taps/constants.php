<?php

    $file_serverpath    =      '172.24.191.63';
    $tools_service      =      'http://172.24.175.46:8100/PGDWCFSERVICE.svc';
    $tools_job_download_service      =      "http://10.234.10.40:8010/PGDWCFSERVICE.svc";
    $default_production_ip      =       $file_serverpath;

    $lowrespath         =       'SP_BOOKS/PRODUCTION/{BID}/S200/LOW_RES/{CID}/';
    $highrespath        =       'SP_BOOKS/PRODUCTION/{BID}/{RID}/HIGH_RES/{CID}/';

    $round_info         =       [   
                                    'S5'    =>  '104'   , 
                                    'S50'   =>  '114'   ,
                                    'S200'  =>  '116'   , 
                                    'S300'  =>  '118'   ,
                                    'S600'  =>  '119'   ,
                                    'S650'  =>  '120'   ,
                                    'CUC'   =>  '127',
                                    'ESM'   =>  '128' 
                                ];    
    
    $round_temp         =       array_flip( $round_info ); 
    $round_info         =       $round_info + $round_temp;
    $correctionFileUploadIp = $file_serverpath;
                    
return [
    'BASE_URL'      =>      Config('app.url') ,
    'ROUTE_URL'     =>      Config('app.url') ,
    'BASE_PATH'     =>      '' ,
    'MANAGER_ROLE_ID'   =>  [ '8','9','10','12','45','49'] , 
    'CONSOLIDATE_MANAGER_ROLE_ID'   =>  [   12,45,8   ] , 
    'CONSOLIDATE_MANAGER_ROLE_ID'   =>  [   12,45,8   ] , 
    'RAW_FILE_BUTTON'   =>  [   12,45 ] , 
    'BOOK_MODULE_EPROOF_CHAPTER'   =>  [   12,8 ] , 
    'CIRCLE'    => [ 'SUBCIRCLEID' => 757 ] ,	
    'FILE_SERVER'       =>  $file_serverpath ,
    'FILE_SERVER_ROOT_DIR' =>   '/ftp/' , 
    'BACKSLSH_CEFILE_SERVER_ROOT_DIR' => '\ftp' , 
    'BACKSLAH_FILE_SERVER_ROOT_DIR' => '\SP_BOOKS' , 
    'FILE_SERVER_WITH_ROOT_DIR' => $file_serverpath.'/ftp/' , 
    'FILE_SERVER_CREDENTIALS' => 'ftp://developer:dev.@123@' , 
    'FILE_SERVER_USER_NAME' => 'spidom/magnususer' , 
    'FILE_SERVER_PASSWORD' => 'Magnus123' , 
    'CHENNAI_PRODUCTION_SERVER' => $file_serverpath.'/ftp/SP_BOOKS/',
    'PONDY_FILE_SERVER'     =>  $file_serverpath.'/ftp/SP_BOOKS/',
    'RAW_PATH'  =>  'RAW/'  ,
    'UPDATED_JOBSHEET_PATH'   =>      'JOBSHEET/BOOK_ID/ROUND_NAME/' ,
    'RAW_JOBSHEET_PATH'   =>      'RAW/BOOK_ID/ROUND_NAME/' ,
    'JOBSHEET_SUFFIX_CONVENTION'   =>     [  
                                             'S5' => '_JobSheet_5.xml' , '104' => '_JobSheet_5.xml' , 
                                             'S50' => '_JobSheet_50.xml' , '114' => '_JobSheet_50.xml' ,
                                             'S200' => '_JobSheet_200.xml' , '116'  => '_JobSheet_200.xml',
                                             'S300' => '_JobSheet_300.xml' , '118'  => '_JobSheet_300.xml',
                                             'S600' => '_JobSheet_600.xml' , '119'  => '_JobSheet_600.xml',
                                             'S650' => '_JobSheet_650.xml' , '120'  => '_JobSheet_650.xml'
                                          ] ,
    'FILE_HANDLER_ACTION'  =>  ['success'=>'completed']  ,
    'USER_WORK_TEMP_PATH' => 'TEMP/BOOK_ID_JOB_TIME_SHEET_ID/' ,
    'USER_WORK_PATH' =>  'USER-WORK/USER_DIR/' ,
    //'USER_WORK_PATH' =>  'USER-WORK/USER_DIR/ROUND/STAGE_NAME/' ,
    'SPLIT_DESTINATION_PATH' =>  'FILE-PROCESS/PRE_PROCESSING/BOOK_ID/STAGE_NAME/' ,
    'EMS_DESTINATION_PATH'   =>  'FILE-PROCESS/PRE_PROCESSING/BOOK_ID/ESM/' ,
    'BACKSLAH_SPLIT_DESTINATION_PATH' =>  'FILE-PROCESS\PRE_PROCESSING' ,
    'BACKSLAH_CASTOFF_DESTINATION_PATH' =>  'FILE-PROCESS\PRE_PROCESSING' ,
    'ART_SOURCE_PATHS'       =>      'ARTFILES/' ,
    'ART_DESTINATION_PATH'  =>      'FILE-PROCESS/PRE_PROCESSING/' , 
    'SPLIT_SOURCE_PATH'     =>      'RAW/BOOK_ID/ROUND_NAME' ,
    'JOB_ASSIGNED_CONST'    =>      'S50',
    'PROCESS_TYPE'          =>      'NOTIFICATION',
    'JOBSHEET_DOWNLOAD'          =>      'JOBSHEET_DOWNLOAD',
    'REVISED_PROCESS_TYPE'      =>      ["REVISED_RECEIPT"=>"REVISED_RECEIPT","RECEIPT"=>"RECEIPT"],
    'AM' => 45 , 
    'PM' => 12 ,  
    'TL' => 10 ,  
    'CL' => 9  ,
    'ART_REVIEWER' => 23 ,  
    'CREATIVE_ART' => 14 ,  
    'LOGISTIC_OPERATOR'  =>  46 ,
    'CUC_OPERATOR'  =>  43 ,
    'COPY_EDITOR'  =>  1,
    'SPICE_MERGE_PROCESS_NAME'=>'SPiCE-Merge',
    'STAGE_NAME' => [ 
		'SPLIT'=>'SPLIT', 
		'CUC' => 'CUC' , 
		'ART_FILES'  => 'ART_FILES',
		'INDEXING'  => 'INDEXING',
		'COPY_EDITING'  => 'COPY_EDITING',
		'SPICE'  => 'SPICE',
		'TAPS'  => 'TAPS',
		'ART_QC'  => 'ART_QC',
		'CE_INPUT_ANALYSIS' => 'CE_INPUT_ANALYSIS',
                'ESM' => 'ESM',
                'RAZOR' => 'RAZOR',
                'INDEXER' => 'INDEXER',
                'SPICE_MERGE' => 'SPICE_MERGE'
		
    ] ,
    'ROUND_OF_NAME'=>[ 'S5' => 'S5' , 'S50' => 'S50' ] ,
    'FM_ARTICLE_BM' => 4  ,
    'ARTICLE_FM' => 1  ,
    'ARTICLE_CHAPTER' => 2  ,
    'ARTICLE_BM' => 3  ,	
    'CHECK_PART' => 'PA'  ,
    'CHECK_FM' => 'FM1'  ,
    'CHECK_BM' => 'BM1'  ,
    'UNIT_OF_MEASURE' => '556'  ,
    'REMINDER_PROCESS_TYPE'=>["E_PROOF"=>"E_PROOF","APS"=>"APS"],
    'READ_BM_FM_EXTENSTION' =>  ['fm1','bm1'],
    'ARTICLE_COVER' => 5, 
    'ARTICLE_PART'  => 3, 
    'COVERNAMING'   =>  'COVER' ,
    'CHAPTER_ENUM_ID' => 70  ,
    'JOBSHEET_RAW_LOCATION' => [
		'FTP_HOST' => $default_production_ip ,
		'FTP_USERNAME'  =>  'developer',
		'FTP_PASSWORD'  =>  'eyJpdiI6Ijd3R21LdjFGUFJUaHg0WWFLK29ubmc9PSIsInZhbHVlIjoiZWV1N2NTZHl3WDRuMitTbWw4U0JNUT09IiwibWFjIjoiNDRiNzAxNDljMjBmYmQxYzFjYjBhYTdjMTA5YjA1NmFkNzBkNGE5ZWNiMDUyNzRhZjJmNzZlZjA2Y2UxZTFhYiJ9',
		'XML_PATH'      =>  'SP_BOOKS/RAW/BOOK_ID/',
	],
    'JOBSHEETPATH'  =>  'JOBSHEET',
    'WSDL_OF_METAEXTRACTOR'     =>  'http://172.24.177.155:1987/testing_api/test.php' , 
    'WS_OF_CLIENTACKNOWLEDGE'   =>  'http://172.24.177.155:1987/testing_api/test.php' , 
    'PSTVTWINOVER_SOAP_SERVER_PATH' => $tools_service.'?singleWsdl',
    'ROUND_ID'      =>  $round_info , 
    'ROUND_NAME'    =>  $round_info , 
    'DEFAULT_TOOLS_SERVICE_PATH'    =>  '',
    'EXTRACTOR_TOOLS_INPUT_JOBSHEET_PATH' => '' , 
    'SUCCESS_REDO_MAIL_BCC'  =>  'BooksXMLSpringerHB-Pondy@spi-global.com,BooksSpringerBWFXML-MedicalBoutique@spi-global.com,BooksXMLSpringerDD-Pondy@spi-global.com,BooksXMLSpringerNY-Pondy@spi-global.com,BooksPalgraveXML-India@spi-global.com' ,
    'WATCH_PRD_FILE_TRANSFER_WATCH_FOLDER' 	=>  '/els_jrnls/BOOKS/WATCHFOLDER/UPLOAD/WATCH_DOG/IN/' , 
    'WATCH_CLIENT_ACK_SUCCESS_WATCH_FOLDER' =>  'SP_BOOKS/WATCHFOLDER/DOWNLOAD/SUCCESS_WATCH_DOG/OUT/' ,
    'BOOK_BUILDING_DB_WATHC_PATH'           =>  'SP_BOOKS/PRODUCTION/{BID}/{RID}/PAGINATION_FILES/{CID}/',
    'BOOK_BUILDING_LOW_RES_PATH'            =>  'SP_BOOKS/PRODUCTION/{BID}/{RID}/LOW_RES/{CID}/',
    'CHAPTER_BUILDING_SPICEMERGE_PATH'      =>  'SP_BOOKS/PRODUCTION/{BID}/{RID}/{CID}/',
    
    'BOOK_BUILDING_WEB_URL'                => 'http://172.24.136.122:9880/PDFMerge/InitiateMergeBookPDFByOrderall/',
    'WATCH_CLIENT_ACK_REDO_WATCH_FOLDER' 	=>  '/SP_BOOKS/WATCHFOLDER/DOWNLOAD/REDO_WATCH_DOG/OUT/' , 
    'COPY_CLIENT_ACK_FOLDER_SUCCESS'    	=>  '/SP_BOOKS/DOWNLOAD/SUCCESS_LOG/BOOK_ID/ROUND_NAME/' , 
    'EPROOF_TOOLS_CLIENT_ACK_LOG_LOCATION' 	=>  '/SP_BOOKS/WATCHFOLDER/EPROOF_WATCH_DOG/ACKNOWLEDGEMENT/OUT/' , 
    'EPROOF_CLIENT_ACK_PRODUCTION_STORAGE_LOCATION'    =>  '/SP_BOOKS/PRODUCTION/{BID}/{RID}/E_PROOF_CLIENT_ACK/' , 
    'CORRECTION_DOWNLOADED_ZIP_TOOLS_LOCATION' 	=>  '/SP_BOOKS/WATCHFOLDER/EPROOF_WATCH_DOG/OUT_PACKAGE/OUT/' ,
    'COPY_CLIENT_ACK_FOLDER_FAILED'     =>  '/SP_BOOKS/DOWNLOAD/REDO_LOG/BOOK_ID/ROUND_NAME/' , 
    'WATCH_CE_ESTIMATION_FOLDER' 	=>	'/SP_BOOKS/WATCHFOLDER/WATCH_CE_ESTIMATION/IN',
    'WATCH_ESMDETAILS_FOLDER' 	=>	'/SP_BOOKS/WATCHFOLDER/WATCH_ESMDETAILS/',
    'CUC_JOBSHEET_VIEW_FOLDER' 	=>	'/SP_BOOKS/RAW/',
    'S5_JOBSHEET_UPLOAD_PATH'   =>      'SP_BOOKS/S5_JOBSHEET_UPLOAD/' ,
    'CE_ESTIMATION_FOLDER' 	=>  '/ELS_JRNLS/CE_ESTIMATION/',
    'GENERATE_ART_METAXML'	=>  $tools_service.'/ArtworkFigurePropertyRetrieval',
    'ESM_VALIDATE'         	=>  $tools_service.'/VideoPropertiesValidation',
    'STAGE_COLLEECTION' => [ 
		'SPLIT_PROCESS' =>      '1291'  , 
		'CUC'           =>      1236 , 
		'INDEXING'      =>      1296 , 
		'S5_ART_CREATION'   =>  1292 ,
		'COPY_EDITING'      =>  1315 , 
		'ART_MANIPULATION'  =>  1310 ,
		'TAPS_DESKTOP'  	=>  1334 ,
		'CE_ESTIMATION'  	=>  1320 ,
		'SPICAST'  	=>  1321 ,
		'DESPATCH_UPLOAD'	=>	7 ,
		'ART_QC'    =>  1307 , 
		'AUTO_PAGE' =>   1340 , 
		'3B2'   =>  1343  ,
		'AUTO_PAGE_BG' => 1343 , 
		'AUTO_PAGINATION' => 1340 ,
		'MANUAL_PAGINATION' => 1338 ,
		'DESKTOP_PAGINATION' => 1345 ,
		'AUTO_CAP'   =>  1356  ,
		'AUTO_DP'   =>  1344 , 
		'PR_QC'     =>  1342 ,
		'PACKAGE' => 1329 ,
		'AUTO_PDFCOMPARE' => 1349 , 
		'AUTO_EPSILON_COMPARE' => 1350 , 
		'AUTO_REFERENCE_PDF'   =>  1347,
		'CE_INPUT_ANALYSIS'   =>  1315,
		'ESM_VALIDATION'   =>  1361,
		'ESM_FILE_NAME'   =>  1362,
		'ESM'   =>  1363,
		'TAPS_SIGNAL' =>1360,
		'SUCCESS_REDO' =>1328,
		'AUTO_PDF_MERGE' => 1346,
		'ART_XML_DELIVERY' => 1369,
		'XML_DELIVERY'  => 1367,
		'PACKAGING'	=>	1329 ,

		'AUTO_APN' =>   1371 , 
		'COVER_DP'  =>  1375 , 
		'COVER_DP_MYCOPY'   =>  1376 , 
		'COVER_DP_SOFTCOPY' =>  1378 , 
		'COVER_FC' => 1379 ,
		'BOOK_BUILDING'     =>  1370,
		'S600_DP_PRINT'     =>  1381,
		'S600_DP_ONLINE'    =>  1380,
		'S600_BB_DP_PRINT'    =>  1382,
		'S600_BB_DP_ONLINE' =>  1383,
		'S600_BB_DP_MYCOPY' => 1385,
		'BOOK_BUILDING_REVIEW' => 1391,
		'XML_QC' => 1351,
		'S600_BB_DP_SOFTCOPY' => 1386,
		'S600_DP_ONLINE'    =>  1380 ,
		'EPROOF'    => 1364,
		'INDEXING_VALIDATION'    => 1368,
		'RAZOR'    => 1393,
                'INDEXER'    => 1407


    ] ,
    'ACTIVE_MQ_PROCESS_NAME'     =>   [ 
        144 => 'RECEIPT' , 
        1398 => 'NOTIFICATION' , 
        1399 => 'WRONG_INSTRUCTION' , 
        1400 => 'CORRECTION',
        1401 => 'REVISED_RECEIPT',
        1329 => 'PACKAGING',
        1402 => 'E_PROOF'
    ] ,
    'PRE_PRODUCTION_PROCESS_TYPE' => [ 
        1 => 'CUC' , 
        2 => 'ART' , 
        3 => 'SPLIT' , 
        4 => 'CE_SPLIT'
    ] ,
    'AUTO_PAGINATION_STAGES'    =>   [ '1340' ] ,
    'NAMING_CONVENTIONS' =>  [ 
            'METADATA_ENTRY_NAME' =>  'CHAPTER'  , 
        ] , 
    'STATUS_ENUM_COLLEECTION' => [   
		'AVAILABLE' => 27 , 'IN_PROGRESS' => 23 , 'COMPLETED' => 24 ,'NEWACTIVITY' => 25 , 
		'WAITINGFORPARALLEL' => 31 , 
		'WAITINGFORCHAPTERSCOMPLETION' => 76 , 
		'JOB_LEVEL' =>  [ 'JOB_CREATED' => 71 , 'JOB_INPROGRESS' => 72 , 'JOB_COMPLETED' => 73 ]
	] , 
	'CUC_CHECKOUT_FOLDER' 	=>  'FILE-PROCESS/PRE_PROCESSING/CUC/IN/',
	'CUC_CHECKIN_FOLDER' 	=>  'FILE-PROCESS/PRE_PROCESSING/CUC/OUT/',
	'CUC_USER_WORK_FOLDER' 	=>  'USER-WORK/',
	'JOBSHEET_BACKUP_FOLDER'=>  'BACKUP/',
	'CUC_USER_TEMP_WORK_FOLDER' =>  'TEMP/',
	'CHAPTER_PART_READ_EXTENSTION' =>  ['.docx','.doc','.docm'],
	'READ_EXTENSTION_OF_SPLIT_PDF_VALIDATION' =>  ['.pdf'],
	'COPY_WORD_XML_FILE_NAME'   =>  ['WORD_FILE_ONLY'=>'WORD','WORD_XML_FILE_ONLY'=>'WORD_WITH_XML'],
	'COPY_FILE_EXTENTION'   =>  ['READ_WORD_EXTENSTION' =>  ['.docx','.doc','.pdf','.docm'],'READ_WORD_XML_EXTENSTION' =>  ['.docx','.doc','.xml','.docm']],
	'READ_TYPEOF_PM_FM' =>  ['ch','pa','fm','pm','bm','cn'],
	'READ_TYPEOF_PART' =>  ['pa'],
	'READ_TYPEOF_PART_STRING' => 'part',
	'READ_TYPEOF_CHAPTER' =>  ['ch'],
	'READ_CHAPTER_EXTENSTION' =>  ['ch','cn'],
	'READ_TYPEOF_PM_FM_EXTENSTION' =>  ['fm','pm','bm'],
	'READ_FRONT_BACK_MATTER_VLIDATION' =>  ['FM1','BM1'],
	'SPLIT_PROCESS_VLIDATION' =>  ['CHAPTER'=>'chapter_','PART'=>'part_'],
	'BACK_MATTER' =>  ['bm'],
	'FRONT_MATTER' =>  ['fm'],
	'CLIENTID' =>  "Springer_Books",
	'CLIENTNAME' =>  "Springer",
	'CHAPTER_READ_EXCEPTDOT_EXTENSTION' =>  ['docx'] ,
	'SPICASTPROCESS_FOLDER' =>  'SP_BOOKS/SPICAST_PROCESS/',
	'SPICAST_WATCH_FOLDER' 	=>  'SP_BOOKS/SPICAST_PROCESS/SPICAST_WATCHFOLDER/',
	'SPICAST_ZIP_FILE' 	=>  'SP_BOOKS/UPLOAD/SPICASTOFF/',
	'BACKSLAH_SPICAST_ZIP_FILE' =>  'UPLOAD\SPICASTOFF',
	'SPICAST_WATCH_FILE' 	=>  'SP_BOOKS/WATCHFOLDER/SPICAST_REPORT/',
	'SPICE_WATCH_FILE' 	=>  'SP_BOOKS/WATCHFOLDER/SPICE/',
	'ARTFIES_WATCH_FILE' 	=>  'SP_BOOKS/WATCHFOLDER/ART_FILES/TYPEOFART/',
	'WATCH_CUC'             =>  'SP_BOOKS/WATCHFOLDER/CUC/In/',
	'VENDORXML_FILE'        =>  'SP_BOOKS\PRODUCTION\{BID}\{RNAME}\EPROOF_VENDOR\{CNAME}',
	'LOWRESIMAGEFOLDER'     =>  'SP_BOOKS/PRODUCTION/{BID}/{RNAME}/LOW_RES/{CID}/',
	'ART_QC_PATH'          =>  'SP_BOOKS/PRODUCTION/{BID}/{RNAME}/ART_QC/{CID}/',
	'APN_PROCESS_APP_PATH'  =>  '{SIP}/{RDIR}/PRODUCTION/{BID}/S600/PAGINATION_FILES/{CID}/{PAGING_FILENAMING}.{APP_EXT}' ,
	'PRR_REPORTDWONLOAD_EXTENSTION' =>  ['xlsx','xls'],
	'PRR_REPORTDWONLOAD_FOLDER' =>  'SP_BOOKS/RAW/BOOK_ID/',
	'PRR_REPORTDWONLOAD_SEARCH' =>  'BOOK_ID',
	'BACKSLASH_PRR_REPORTDWONLOAD_FOLDER' =>  'SP_BOOKS\RAW',
	'THIRDPARTYAPIKEY' =>  '@#_-spi+=1@mail@#$000#',
	'ART_METADATA_FILE' =>  'ArtMetadata.xml',
	'ART_METADATA_FILE_DEFAULT' =>  'ArtMetadata_default.xml',
	'CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT' =>  ['docx','doc','avi','wmv','mp4','mov','m2p','mp2','mpg','mpeg','flv','mxf','mts','m4v','3gp'],
	'ART_METADATA_XML_FILE_READ' =>  ['xml','xlsx','xls','zip'],
	'PRODUCTION_FILE_READ' =>  ['xml','xlsx','xls','zip','doc','docx'],
	'ART_FIG_COUNT' =>  'Fig',
	'ART_TAB_COUNT' =>  'Tab',
	'ART_SCHEMES_COUNT' =>  'Sch',
	'ART_STRUCTURE_COUNT' =>  'Str',
	'ART_EQAUTION_COUNT' =>  'Equ',
	'PRR_REPORT_FILE' =>  'SP_BOOKS/UPLOAD/PRR_REPORT/',
	'PRR_REPORT_FILE_NAME_SUFFIX'   =>  '_Production_Review_Report.xlsx' ,
	'COLOR_MODE' => [ 
		'BW' => 'BW' , 
		'Color' => 'Color' 
	] ,
	'STATUS_ENUM'=>['COMPLETED'=>2,'INPROGRESS' => '1.5' ,  'SUCCESS' => 2,'FAILURE'=>3,'ONE'=>1],
	
	'DOCUMENT_TYPE'     =>['meta'=>['xml','json'],'document'=>['docx','doc']],
	'ESM_FILE_TYPE'     =>['avi','wmv','mp4','mov','m2p','mp2','mpg','mpeg','flv','mxf','mts','m4v','3gp'],
	'ART_CATALOGUE_NAME'=>'BWF',
	'SPICASTOFF_EMAILID'=>'spicast@springer.com',
	'SPICAST_BACKGROUND_FILE'=>'SP_BOOKS/UPLOAD/SPICAST/S50',
	'BACKSLAH_SPICAST_BACKGROUND_FILE' =>  'UPLOAD\SPICAST\S50' ,
	'SPICAST_EXCEL_FILE'=>'SP_BOOKS/UPLOAD/SPICAST/EXCELPATH',
	'BACKSLAH_SPICAST_EXCEL_FILE' =>  'UPLOAD\SPICAST\EXCELPATH' ,
	'SPICAST_PROFILE_FILE'=>'SP_BOOKS/UPLOAD/SPICAST/PROFILEPATH',
	'BACKSLAH_SPICAST_PROFILE_FILE' =>  'UPLOAD\SPICAST\PROFILEPATH',
	'SPICAST_XML_FILE' =>  'SPiCAST_Profiles.xml',
	'SPICAST_IMAGES_FILE'=>'/images/',
	'SPICAST_IMAGE_FILEXTN'=>['.PDF','.TIF','.TIFF','.EPS','.JPG','.BMP','.GIF','.AI','.PNG','.EMF','.PPT','.Excel','.SVG','.DOC','.SVG','.CDR','.PSD'],
	'ART_IMAGE_VALIDATION_FILEXTN'=>['.TIF','.EPS'],
	'INTRODUCTORY' => [ 
		'LETTER_FORMAT' => [ 
			'Eproofing_Book Author[Editor]' , 
			'PDF proofing_BookAuthor[Editor]' , 
			'Eproofing – Chapter Author' , 
			'PDF proofing_Chapter Author' , 
			'Eproofing_Editor' , 
			'PDF proofing_Editor'
		] ,
		'LETTER_TEMPLATE'   =>  [
			'02_FS_ScheduleProductionNotesLetter_BookAuthor[Editor] (eproofing)Jan 17.docx' ,
			'02_FS_ScheduleProductionNotesLetter_BookAuthor[Editor] (PDFOnly proofing)Jan 17.docx' , 
			'02_FS_ScheduleProductionNotesLetter_ChapterAuthor (eproofing)Jan2017.docx' , 
			'02_FS_ScheduleProductionNotesLetter_ChapterAuthor (PDFOnly proofing)Jan 17.docx' , 
			'02_FS_ScheduleProductionNotesLetter_Editor(eproofing)Jan 17.docx' , 
			'02_FS_ScheduleProductionNotesLetter_Editor(PDFOnly Proofing)Jan 17.docx'                                
		]
	],
	//MOVETOPRODUCTION
	'S200_WORKFLOWID'=>47,
	'S200_ART_WORKFLOWID'=>48,
	'S300_ART_WORKFLOWID'=>89,
	'S300_WORKFLOWID'=>45,
	'AUTO_STAGE' => [ 
		'1302' => 'doSpicerequest' ,
		'1311'  =>      array( 'type' => 'normalfunction' ,  'executable' => 'artProcess\artProcessController@isArtAllStagesCompleted' , 'waiting' => true ) ,
		'1330'  =>      array( 'type' => 'normalfunction' ,  'executable' => 'Api\lowResController@doDeltapdfvalidation' , 'waiting' => true ) , 
		'1329'  =>      array( 'type' => 'watchfolder'    ,  'executable' => 'bgprocess\bgprocessController@doPackaging' , 'waiting' => false  ) , 
		'7'     =>      array( 'type' => 'watchfolder'    ,  'executable' => 'Api\apiFtpUploadController@sendRequestForPackagingUploadChapterLevel' , 'waiting' => false )
    ] ,
	'ART_STATUS'=>['ART_COMPLETED'=>47 , 'ART_CREATED' => 45 , 'ART_IN_PROGRESS' =>  46 ],
	'TAPS'  =>  [ 
		'ART_LOWRES_CREATION'           =>   Config('app.url').'/api/createLowResFile' ,
		'ART_COMPLETION_SIGNAL_URL'     =>  'http://172.24.191.62/TapsWeb/chapterstatus.php' , 
		'TAPS_TEMP_PATH'                =>  'SP_BOOKS/TEMP/TAPS/' ,
		'TAPS_CHAPTER_PATH'             =>   $lowrespath , 
		'TAPS_WEB_URL'  =>  [
			'1' =>  'http://172.24.191.62/TapsWeb/' , 
			'2' =>  'http://172.24.191.62/TapsWeb/' , 
			'3' =>  'http://172.24.191.62/TapsWeb/' , 
		]
	] ,
	'WOMAT' => [ 
		'WOMAT_ART_COMPLETED_SIGNAL'  =>  'http://172.24.148.41:9119/clsWorkflowCoordinator.svc/UpdateMagnusArtMetadataChapterInfo',
		'WOMAT_UPDATE_METADATA_BOOKINFO_SIGNAL'  =>  'http://172.24.148.41:9119/clsWorkflowCoordinator.svc/UpdateMetadataBookInfo'
	], 
	'PRODUCTION_TOOLS_SETUP'   =>      [    
		'PRODUCTION_FILE_TRANSFER_API_ASYNC'    =>      $tools_service.'/ProductionFileMovementAsync' ,
		'PRODUCTION_FILE_TRANSFER_API'          =>      $tools_service.'/ProductionFileMovement' , 
		'PM_S5_METADATA_UPDATE'                 =>      $tools_service.'/MetadataUpdate'  ,
		'JOBSHEET_S50_UPDATE'                   =>      $tools_service.'/MetadataUpdateS50',
		'JOBSHEET_DOWNLOAD_SERVICE'             =>      $tools_job_download_service.'/ExtractJobsheet',
		'UPLOAD_WATCH_FOLDER'                   =>      'SP_BOOKS/WATCHFOLDER/UPLOAD/WATCH_DOG/IN/' ,
		'PACKAGE_WATCH_FOLDER'                  =>      'SP_BOOKS/WATCHFOLDER/EPROOF_WATCH_DOG/PACKAGING/IN/' ,
		'LOWRES_WATCH_FOLDER'                   =>      'SP_BOOKS/WATCHFOLDER/DATASET_IMAGE_CONVERSION/IN/',
		'EPROOF_PACKAGE_FOLDER'                 =>      'SP_BOOKS/WATCHFOLDER/EPROOF_WATCH_DOG/PACKAGING/IN/',
		'EPROOF_PACKAGE_FOLDER_DEV'             =>      'SP_BOOKS/WATCHFOLDER/EPROOF_WATCH_DOG/PACKAGING_DEV/',
		'AUTO_PAGE_WATCH_PATH'                  =>      'SP_BOOKS/WATCHFOLDER/AUTOPAGE_WATCH/',
		'AUTO_REFERENCE_PDF'                    =>      'SP_BOOKS/WATCHFOLDER/REFERENCE_PDF/IN/',
		'AUTO_BOOK_MERGE'                       =>      'SP_BOOKS/WATCHFOLDER/BOOK_MERGE/IN/',
		'AUTO_PDF_MERGE'                        =>      'SP_BOOKS/WATCHFOLDER/PDF_MERGE/IN/',
		'ESM_FILE_NAME'                         =>      'SP_BOOKS/WATCHFOLDER/ESM/IN/' ,
		'APN_PROCESS'                           =>      'SP_BOOKS/WATCHFOLDER/APN_HOTPATH/IN/'
	] ,
	'PACKAGE_PATH' => [ 

		'BOOKPRINTPDF'              =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' ,
		'BOOKPRINTPDFPITSTOPLOG'    =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKMYCOPYPDF'             =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKMYCOPYPDFPITSTOPLOG'   =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKCOVERPRINTPDF'         =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKPRINTCOVERPDFPITSTOPLOG'   =>  'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKMYCOPYCOVERPDF'            =>  'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKMYCOPYCOVERPDFPITSTOPLOG'  =>  'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKCOVERIMAGE'            =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKEPSILONPDF'            =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'BOOKECHECKLIST'            =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' , 
		'XMLFILE'                   =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/SPICE/{PAGING_FILENAMING}.xml' , 
		'XMLFILE_S200'              =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/XML_DELIVERY/{CID}/{PAGING_FILENAMING}.xml' , 
		'PDFFILE'                   =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/{PAGING_FILENAMING}_OnlinePDF.pdf' , 
		'PITSTOPSTOPFILE'           =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/{PAGING_FILENAMING}_OnlinePDF_log.pdf' , 
		//'REFPDFFILE'                =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/SPICE/{BID}_{CNO}_ReferencePDF.pdf' , 
		'REFPDFFILE'                =>      'SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/{BID}/REFERENCE_PDF/{CID}/{CID}.pdf' ,  
		//'DELTAPDFFILE'              =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{BID}_{CNO}_Chapter/SPICE/{BID}_{CNO}_DeltaPDF.pdf' , 
		'DELTAPDFFILE'              =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/SPICE/{PAGING_FILENAMING}_delta.pdf' ,  
		'TEXTFILE'                  =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/SPICE/{PAGING_FILENAMING}.txt' , 
		'PROOFPDFFILE'              =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/{PAGING_FILENAMING}_ProofFeedback.pdf' , 
		'AUTHORPDFLOCATION'              =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/{PAGING_FILENAMING}_Author.pdf' , 
		'ESMDETAILS'                =>      '/SP_BOOKS/WATCHFOLDER/WATCH_ESMDETAILS/' ,
		'LOWRESIMAGEFOLDER'         =>      $lowrespath  , 
		'HIGHRESIMAGEFOLDER'        =>      $highrespath , 
		'STRIPINSFOLDER'            =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/STRIPINS/{CID}/' , 
		'DESTINATIONPATH'           =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/PACKAGING/{CID}/{DID}' ,  
		'UPLOADDESTINATIONPATH'           =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/PACKAGING/{CID}/Package/{DID}' ,  
		'DESTINATIONPATH_S300'       =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/PACKAGING/{CNAME}/' , 
		'PACKAGE_UPLOAD_PATH'       =>      'SP_BOOKS/PACKAGE_UPLOAD/' ,
		'E_PROOF_PACKAGE_UPLOAD_PATH'       =>      'eproofing/{PMLOC}/in/' ,
		'FAILURE_PACKAGE_PATH'        =>      'SP_BOOKS/USER-WORK/{EMPID}/FAILURE_PACKAGE/{BID}/{CID}/' ,
		'FAILURE_PACKAGE_PATH2'       =>      'SP_BOOKS/USER-WORK/{EMPID}/FAILURE_PACKAGE/{BID}/{CID}/' ,
		'S650'  => [
			'EPROOFPACKAGE' => [
				'COMPO' => [
					'XMLFILE' => 'SP_BOOKS/PRODUCTION/{BID}/S600/PAGINATION_FILES/{CID}/{PAGING_FILENAMING}.xml' , 
					'DELTAPDFFILE' => 'SP_BOOKS/PRODUCTION/{BID}/S600/PAGINATION_FILES/{CID}/{PAGING_FILENAMING}_delta.pdf' ,
					'AUTHORPDFLOCATION' => 'SP_BOOKS/PRODUCTION/{BID}/S600/PDF_MERGE/{CID}/{PAGING_FILENAMING}_Author.pdf' ,
					'LOWRESIMAGEFOLDER' => 'SP_BOOKS/PRODUCTION/{BID}/{FINDARTLATESTROUND}/LOW_RES/{CID}/' , 
					'ESMDETAILS' => '' , 
					'COVERJPEG'  => 'SP_BOOKS/PRODUCTION/{BID}/S600/PAGINATION_FILES/COVER/' , 
				] , 
				'BOOK' => [ 'VENDORXML' => 'SP_BOOKS/PRODUCTION/{BID}/{RID}/VENDORXML/VendorDetails.xml' , 
					'DESTINATION_PATH' => 'SP_BOOKS/PRODUCTION/{BID}/{RID}/EPROOF/{PACKAGEZIPNAME}' ]
			]
		]
	] , 

	'BOOK_MERGE_SRCPATH' =>      'PRODUCTION/{BID}/{RID}/PAGINATION_FILES/{CID}/' ,
	'JS_COMPARE'   => [
	   'TAPS_XML_PATH'               =>      'SP_BOOKS/TAPS/TAPS_FINAL_OUT/{PAGING_FILENAMING}/' ,
	   'NON_TAPS_XML_PATH'           =>      'SP_BOOKS/PRODUCTION/{BID}/{RID}/PAGINATION_FILES/{CID}/' ,
	   'POST_URL'                    =>       'http://172.24.136.197/CompareJobSheet_Api/api/Values/GetJobsheetOperation'
	],
	'CREATE_REJECT_ART_PATH'                =>    '\\\\'.$file_serverpath.'\ftp\SP_BOOKS\TEMP\TAPS',
	'TAPS_CREATE_ART_PATH'                  =>    'http://172.24.191.57/Magnus/api/createArtFromTaps',
	'TAPS_REJECT_ART_PATH'                  =>    'http://172.24.191.57/Magnus/api/rejectArtFromTaps' ,
	'TAPS_SUCCESS_PATH'                     =>     Config('app.url').'/api/tapsCompletion?ChapterID={CID}&RequestType=TAPSSuccess&RequestID={TOKEN_KEY}&RequestStatus=2',
	'TAPS_CESUCCESS_PATH'                   =>     Config('app.url').'/api/tapsCeCompletion?ChapterID={CID}&RequestType=TAPSCeSuccess&RequestID={TOKEN_KEY}&RequestCeStatus=2',
	'CUC_CALL_BACK_URL'                     =>    'http://172.24.137.132:8046/Ride.svc/processreport' ,
	'PROJECT_DEST_PATH'                     =>    '\\\\'.$file_serverpath.'\ftp\SP_BOOKS\TAPS\TAPS_FINAL_OUT',
	'REFERENCE_PDF_PATH'                    =>     'FILE-PROCESS/PRE_PROCESSING/{BID}/REFERENCE_PDF/{CID}/',
	'TAPS_PROJECT_DEST_PATH'                =>    'TAPS/TAPS_FINAL_OUT/',
	'CC_EMAIL_LIST'                         =>    ['mohan.m@spi-global.com','shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com','E.Anitha@spi-global.com'],
	'BCC_EMAIL_LIST'                         =>    ['mohan.m@spi-global.com','shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com','E.Anitha@spi-global.com'],

	'NEW_JOB_MAIL_CONTENT'                  =>  [   
											'MAIL_FROM_NAME'    =>  'Magnus Notification UAT',  
											'NEW_TITLE_ACK_NAME'=>  'Acknowledgement',
											'NEW_TITLE_HEAD_TITLE'=>  'New Title has arrived',
											'REPLAY_EMAIL'=>  'MagnusAlertsDEV@spi-global.com',
											'NEW_TITLE_ARRIVED_CONTENT'=>  'New Title has arrived from Springer Nature with the following details.',
											'NEW_CHAPTER_ARRIVED_CONTENT'=>  'Attention Please - We have received Chapters for',
											'NO_AM_NAME_CONTENT'=>'Unable To Assign, Kindy check the Account manager setup.',
											'PRODUCTION_LOCATION_CONTENT'=>'Production Location has changed',
											'NEW_PRODUCTION_LOCATION_CONTENT'=>'New Production Location assigned for the title of - ',
											'PRODUCTION_LOCATION_CHANGES'=>'Production Location Changed for the title of - '],
											'MAIL_TEMPLATE_NAME'                    =>  ['NEW_JOB_ASSIGN_TEMP'=>'emailtemplate.download.newjobAssign',
											'JOB_ASSIGN_TEMP'=>'emailtemplate.download.jobAssign',
											'NEW_PRODUCTION_LOCATION_TEMP'=>'emailtemplate.download.prdlNew',
											'PRODUCTION_LOCATION_CHANGE_TEMP'=>'emailtemplate.download.prdlChg',
											'NEW_CHAPTER_ASSIGN_TEMP'=>'emailtemplate.download.newChapterAssign'                                                    
											],
	'BOOK_EMBBED_TYPE'                      =>  [['id'=>1,'name'=>'Embedded'],['id'=>2,'name'=>'Non-Embedded']],
	'SPRINGER_PROJECT_TYPE'                 =>  [['id'=>'1','name'=>'SpringerBWF'],['id'=>'2','name'=>'SpringerMRWS']],
	'ART_CORRECTION_MAIL_ALERT'             =>   'ananth.b@spi-global.com',
	'ART_IMAGE_NAME_PROCESSING'             =>  ['FM'=>'BookFrontmatter','BM'=>'BookBackmatter','PRINTNAME'=>'_Print.'],
	'ART_IMAGE_NAME_CHECKWITHNUM'=>['GR','TAB','SCH','OTH','MMC','EQU','FGR','STR','BOX','ICO','IEQN','CP','CO','UO','SO','AU','AP','ANS','ALG','EQ','EX'],
	'ART_IMAGE_NAME_CHECKWITHAALPHA'=>['IGR','UEQU','ISCH','IEQU'],
	'ART_IMAGE_NAME_COLLECTION'             =>  ['Gr'=>'Fig','Ieqn'=>'IEq','Tab'=>'Tab','Sch'=>'Sch','Oth'=>'Oth','Mmc'=>'Mmc','Equ'=>'Equ','Fgr'=>'Fgr','Str'=>'Str','Box'=>'Box','Ico'=>'Ico'
		,'Uequ'=>'uEqu','Isch'=>'Sch','Iequ'=>'Equ','Cp'=>'Cp','Co'=>'Co','Uo'=>'Uo','So'=>'So','Au'=>'Au','Ap'=>'Ap','Ans'=>'Ans','Alg'=>'Alg','Eq'=>'Eq','Ex'=>'Ex'],
	'ART_IMAGE_NAME_COLLECTION_ALPHA'       =>  ['Igr'=>'Fig','Uequ'=>'uEqu','Isch'=>'Sch','Iequ'=>'Equ'],
	'WORKFLOW' => [
		'S300' =>   [ 'MASTER_ID_ERR' => '45'  , 'MASTER_ID' => '46' , 'MASTER_ID_AUTHOR' => '65'  ],
		'S600' =>   [ 'MASTER_ID_INDEX' => '58'  , 'MASTER_ID_PAGINATION' => '61' , 
					   'MASTER_ID_COVER' => '62' , 'MASTER_ID_CORRECTION' => '59' ,  
						'MASTER_ID_FM' => '63','MASTER_ID_BOOKBUILDING' => '60' 
					]
	] ,
	'DEFAULT_WORKFLOW_LIST'=>['33','34','35','44','55'],
	'S300_DEFAULT_WORKFLOW_LIST'    =>  ['45','46']     ,
	'S600_DEFAULT_WORKFLOW_LIST'    =>  [59,58,61,62,63]   ,
	'S650_DEFAULT_WORKFLOW_LIST'    =>  [59,58,61,62]   ,
	'DEFAULT_PRE_PRODUCTION_WORKFLOW_LIST'=>'44',
	'DEFAULT_PRE_PRODUCTION_WORKFLOW_COPYJOB_ID'=>'6495',
	'DEFAULT_S200_WORKFLOW_COPYJOB_ID'=>'6413', // 6368 - TAPS
	'DEFAULT_S300_WORKFLOW_COPYJOB_ID'=>'6526',  
	'DEFAULT_S600_WORKFLOW_COPYJOB_ID'=>'6523',  
	'DEFAULT_S650_WORKFLOW_COPYJOB_ID'=>'6523',  
	'DEFAULT_S200_WORKFLOW_JS_LESS_COPYJOB_ID'=>'6571', // 6368 - TAPS
	'DEFAULT_S200_WORKFLOW_LIST_JS_LESS'=>['33','34','35','59','60','61','62','63'],
	'DEFAULT_S200_AUTO_STAGE_WORKFLOW_ID'=>[1302,1311,1313],
	'DEFAULT_S200_JS_LESS_AUTO_STAGE_WORKFLOW_ID' => [1346,1334,1330,1329,1328,1313,1311,1302,7],
	'ADMIN_USER_ID'  => '29162',
	'DEFAULT_WORKFLOW' => '34',
	'DEFAULT_CONVENTIONAL_WORKFLOW'=>['55'],
	'OFF_SERIES_DEFAULT_WORKFLOW' => '44',
	'DEFAULT_PRODUCTION_LOCATION' => '3',
	'WORKFLOW_SERVER_PATH'                  =>  [
	'FOLDER_TYPE'       =>  [ 'SRC_TYPE' => 6 ,  'WRK_TYPE' => 7 ,  'DEST_TYPE' => 9 ]
	],
	
	'ART_SUPPORTING_FOLDER_STAGES' =>[1310],
	'ART_SUPPORTING_FOLDER_PATH' =>'SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/{BID}/ARTFILES/{CID}/WORK_UP',
	//'ART_PRINT_FOLDER_PATH' =>'SP_BOOKS/PRODUCTION/{BID}/{RID}/WORK_UP/',
	'ART_PRINT_FOLDER_STAGES' =>[1310],

	'WIP_REPORT_STAGES' => '1296,1315',

	/** Rule setup **/
	'RULE_IF_ERROR'     => '1',
	'RULE_IF_NO_ERROR'  => '2',
	'RULE_IF_REJECT'    => '3',
	'RULE_COMPLETE_ALL' => '4' ,
	'CLIENT_INFORMATION'    =>      [
		'UPLOAD_FTP_INFO' =>    [
			'type' => 'sftp' , 
			'host' => 'us-atl-sftp01.spi-global.com' , 
			'username' => 'Bflux' , 
			'password' => '5lj6fO5z' , 
			'path'  => 'CLIENT_UPLOAD',
			'fingerprint' =>    'ssh-rsa 2048 2d:44:27:22:4a:07:24:07:cc:da:9f:07:ce:67:ff:66'
		]
	],

    'JOB_CODE_PATTERN' =>[ '1' , '[YY]/[SEQ]' , '[YY]-TS-[SEQ]' , '[YY]-DC-[SEQ]' , 'EX[YY]/[SEQ]' , 'CA[YY]/[SEQ]'],
    
    'FINANCE' => [
        'INVOICE_EMAIL_NOTIFICATION' => false,
        'NOTIFICATION_EMAIL' => [
            'FROM_MAIL' => 'MagnusAlerts@spi-global.com',
            'FROM_NAME' => 'FINANCE NOTIFICATION',
            'INVOICE_APPROVER_TO_MAIL' => ['mathankumar.p@spi-global.com'],
            'INVOICE_APPROVER_CC_MAIL' => [],
            'FINANCE_TO_MAIL' => ['sagayaraj.i@spi-global.com'],
            'FINANCE_CC_MAIL' => ['mathankumar.p@spi-global.com', 'arunkumar.p@spi-global.com', 'sagayaraj.i@spi-global.com'],
            'TO_MAIL' => ['mathankumar.p@spi-global.com', 'sagayaraj.i@spi-global.com'], // temp
            'CC_MAIL' => ['arunkumar.p@spi-global.com', 'sagayaraj.i@spi-global.com'], // temp
        ],
        'INVOICE_STATUS_LABEL' => [
            0 => 'label-info', //New Invoice Generated          //PM roles
            2 => 'label-primary', // Invoice 1L - Approval      // CL Head (account lead) - roles 
            3 => 'label-warning', // Invoice 2L - Approval      // EG Head (account lead) - roles   
            4 => 'label-pink', // Invoice 3L - Approval      //Finance admin roles
            5 => 'label-success', // Invoice 4L - PDF Review    //PM roles
            6 => 'label-success', // Invoice 5L - Despatched    //Fin roles
        ],
        'ROLES' => [
            'PM' => [12], //PM roles
            'AM' => [45], // CL Head (account lead) - roles  
            'AL' => [53], // EG Head (account lead) - roles  
            'FIN' => [48], //Finance admin roles
            'ADMIN' => [8], //super admin roles
        ],
        'ROLES_PRIVILEGES' => [
            'PM' => [0, 4, 5], //REQUEST_LEVEL_ID
            'AM' => [0, 2],
            'AL' => [2, 3],
            'FIN' => [3, 4, 5, 6],
            'ADMIN' => [0, 2, 3, 4, 5, 6],
        ],
        'ROLES_APPROVAL' => [
            'PM' => [5], //REQUEST_LEVEL_ID
            'AM' => [2],
            'AL' => [3],
            'FIN' => [4,6],
            'ADMIN' => [0, 2, 3, 4, 5, 6],
        ],
//        'SPRINGER_CUSTOMER_ID' => 10885,
//        'SPRINGER_CUSTOMER_DIVISION_ID' => 178,
        'SPRINGER_CUSTOMER_ID_SEL' => 10885,
        'SPRINGER_CUSTOMER_DIVISION_ID_SEL' => 178,
        'SPRINGER_CUSTOMER_ID' => [10885],
        'SPRINGER_CUSTOMER_DIVISION_ID' => [178, 179],
        'TEAM' => ['MB' => 2670],
        'WORK_TYPE' => ['STANDARD' => 1, 'COMPLEX' => 2],
        'SERVICE_ITEM' => [
            'CATEGORY' => ['A' => 2, 'B' => 3, 'C' => 4, 'D' => 5],
            'CE_LEVEL' => [1 => 11, 2 => 12, 3 => 13],
        ]
    ],
    
    'MAGNUS_STATUS_LABEL' =>[
		'danger' => 'label-danger', //failed
		'primary' => 'label-primary',
		'warning' => 'label-warning', // In progress   
		'success' => 'label-success', // success
	],
    
    'MAGNUS_STATUS_MESSAGE' =>[
		'failed' => 'Failed', //failed
		'inprogress' => 'In Progress', // In progress   
		'success' => 'Success', // success
	],

    'BOOK_SERIES_TYPE'  =>  [ 'REGULAR' => 'Regular title' ,  'FAST_TRACK' => 'Fast track title' ,  'S200_SERIES' => 'S200 Of Series' ],
    'ACTIVEMQ_URL'  =>  'http://172.24.137.75:8080/Exporter/Message/activemq',
    'ACTIVEMQ_REPORT'  =>  [
                                "ARRIVAL"=>"http://172.24.137.85:8080/pentaho/api/repos/%3Apublic%3ASpringer%3AMagnus%3Adashboard_report.wcdf/generatedContent?userid=reportuser&password=reportuser123&report=arrivals&empid=204106",
                                "PRODUCTIVITY"=>"http://172.24.137.85:8080/pentaho/api/repos/%3Apublic%3ASpringer%3AMagnus%3Adashboard_report.wcdf/generatedContent?userid=reportuser&password=reportuser123&report=productivity&empid=204106",
                                "TRACKTITLE"=>"http://172.24.137.85:8080/pentaho/api/repos/%3Apublic%3ASpringer%3AMagnus%3Adashboard_report.wcdf/generatedContent?userid=reportuser&password=reportuser123&report=track_title&empid=204106"
                            ],
    'STAGE_ALERT_EMAIL' => [
        'ART_TEAM' => ['mohan.m@spi-global.com', 'shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com'],
        'CE_TEAM' => ['mohan.m@spi-global.com', 'shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com'],
        'INDEXING_TEAM' => ['mohan.m@spi-global.com', 'shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com']
	],
    'REMAINDER_TYPE'  	=>  [ 'EPROOF' => '1' ,  'APS' => '2'],
    'QMS_QUERIES_URL'   =>  'http://172.24.136.122/QMSMagnusUATAPI/api/ChapterQueryInfo/GetQueriesByChapterNo/',
    'QMS_CHAPTER_QUERIES_URL'   =>  'http://172.24.136.122/QMSMagnusUATAPI/api/QueryList/GetQueryCountbyTitleAcronym/',
    'QMS_JOB_QUERIES_URL'   =>  'http://172.24.136.122/QMSMagnusUATAPI/api/QueryList/',
    
	/* 'CORRECTION_FILE_UPLOAD_IP' => $correctionFileUploadIp,
	'CORRECTTION_FILE_SOURCE_PATH' => $correctionFileUploadIp.'/e/ftp/SP_BOOKS/USER-WORK/<referenceTag>',
	'CORRECTTION_FILE_DESTINATION_PATH' => $correctionFileUploadIp.'/e/ftp/SP_BOOKS/PRODUCTION/<referenceTag>',	 */
	'CORRECTION_FILE_UPLOAD_IP' => '\\\\'.$correctionFileUploadIp,
	'CORRECTTION_FILE_SOURCE_PATH' => 'USER-WORK/<referenceTag>',
	'CORRECTTION_FILE_DESTINATION_PATH' => '\\\\'.$correctionFileUploadIp.'\\UserWork\\<referenceTag>',
	/* 'CORRECTION_FILE_UPLOAD_IP' => '/'.$correctionFileUploadIp,
	'CORRECTTION_FILE_SOURCE_PATH' => '/'.$correctionFileUploadIp.'/magnus/SP_BOOKS/USER-WORK/<referenceTag>',
	'CORRECTTION_FILE_DESTINATION_PATH' => '/'.$correctionFileUploadIp.'/UserWork/<referenceTag>', */
	//'FILE_MOVE_APP_PATH' => 'http://172.24.189.76/projects/routineApp/api/local/fileCopy'
	'FILE_MOVE_APP_PATH' => 'http://'.$correctionFileUploadIp.'/routineApp/api/local/fileCopy',
	'CORRECTTION_FILE_DESTINATION_PATH' => 'SP_BOOKS/RAW/', 
	'CLIENT_CHAPTER_NAME'=>['BOOK'=>'#BOOK','CHAPTER'=>'#CHAPTER','PART'=>'#PART','FM'=>'#FM','BM'=>'#BM'],
	'OST_ACTIVE'=>'0',
	'OST_URL'=>'http://208.113.120.117/dem/index.php?q=OST.pl%20',
	'OST_SITE'=>"https://ost.springer.com/ost/bflux.jsp",
	'ALFRESCO'=>[
		'ALFRESCO_WEB_URL'  =>  "http://172.24.191.79:8080/alfresco/api/-default-/public/cmis/versions/1.1/browser",
		'ALFRESCO_SOAP_URL'  =>  "http://172.24.191.79/Springer_CMIS/Springer_CMIS_Service?wsdl",
//                        http://172.24.190.141:8090/Springer_CMIS/Springer_CMIS_Service?wsdl
		'USER_FOLDER'       =>  "RETRIEVEVERSION"
	],
	'LDAP'=>    [
					'LDAP_IP'  =>  "LDAP://172.20.145.23",
					'LDAP_PORT'  =>  "389"
	],
	'SERVICE_ENUM'=>    [
					'OST'  =>  "#SERVICE1"
	],
	
	//INDEXER AND RAZOR
    'RAZOR_OF_METAEXTRACTOR'     =>  'http://10.235.69.161/razor/pdy/springer/api/receive_jobs_from_womat.php/receivejobsmeta' , 
    'INDEXER_OF_METAEXTRACTOR'   =>  'http://13.126.3.74/InDEXr_WebServices/API/Springer' , 
    'RAZOR_OF_TITLEPATH'     =>  '\\\\172.24.191.63\\ftp\\SP_BOOKS\\FILE-PROCESS\\PRE_PROCESSING' ,
    'RAZOR_OF_JSPATH'     =>  '\\\\172.24.191.63\\ftp\\SP_BOOKS\\JOBSHEET' ,
    'RAZOR_OF_SIGNALINFO'     =>  url('api/Indexer/UpdateRazorInfo/'),
     'INDEXER_OF_SIGNALINFO'     =>  url('api/Indexer/UpdateIndexerInfo/'),
  //INDEXER AND RAZOR ends  
];

?>