<div class="row">
    <div class="col-md-3">
        <h4>
            <b>Book Title : </b>  
            {{$book_title}}
        </h4>
    </div>
    <div class="col-md-3" >
        <h4>
            <b> Book ID : </b>  
            {{$book_id}}
        </h4>
    </div>
    <div class="col-md-3">
        <h4>
           <b>  Job ID : </b>  
            <?php 
                if( isset( $job_code_id ) ){
                    echo $job_code_id;
                }else{
                    echo '--';
                }
            ?>
            
        </h4>
    </div>
    
    @if($showrawdownloadbutton  ==  true)
    <div class="col-md-3">
        <h4>
            @if($rawbutton ==   "YES")
            <input class="openrawfile" type="submit" ng-click="openjobrawfile({{$projectId}})" data-rawbutton="{{$rawbuttonrequestid}}" id="txtDoopenrawfile" name="openjobrawfile" value="Open Raw File">
            @else
            <input class="openrawfile" type="submit" ng-click="openjobrawfile({{$projectId}})" data-rawbutton="{{$rawbuttonrequestid}}" id="txtDoopenrawfile" name="openjobrawfile" value="Downloading" disabled="true">
            @endif
        </h4>
    </div>
    @endif
</div>

<br/>
<form name="addCheckItemFrm" id="addCheckItemFrm">
{{ csrf_field() }}
 
<div class="container-fluid">
@if(count($book_details)>=1) 
	@foreach($book_details as $books) 
            <?php             
                $color_img          =   ($books->NO_OF_IMAGES    -   $books->BLACK_WHITE_IMAGES); 
                $series_collect     =   json_decode( $books->SERIES_INFORMATION );       
                $last_series        =   count( $series_collect ) - 1;
                $series_array       =   (array)$series_collect[$last_series];                                
            ?>
    <div class="row">    
        
        <div class="col-md-3">
           
            <div class="form-group">
                <label for="Title"> Job Type : </label> 
                <select name="book_jobtype" id="book_jobtype" class="form-control" ng-change="prepareJobCode()" ng-model="preparejobcode" ng-init="preparejobcode='{{$job_code_type}}'">
                    <option value="0">--select--</option>
                    <option value="1" <?php if( $job_code_type == '1' ) echo 'selected="selected"'?>>Non Xml</option>
                    <option value="2" <?php if( $job_code_type == '2' ) echo 'selected="selected"'?>>Xml [Typesetting &  others]</option>
                    <option value="3" <?php if( $job_code_type == '3' ) echo 'selected="selected"'?>> Xml Conversion</option>
                    <option value="4" <?php if( $job_code_type == '4' ) echo 'selected="selected"'?>> Extra </option>
                    <option value="5" <?php if( $job_code_type == '5' ) echo 'selected="selected"'?>> Castoff </option>
                </select>
                <input type="hidden" value="" name="book_jobcode" id="book_jobcode" />
            </div>
            
           
            
            <div class="form-group">
                <label for="Title">CE Required :</label>              
                <?php $app_info     =  $books->CE_REQUIRED; ?>               
                <select name="ce_required" class="form-control">
                    <option value="">--select--</option>
                    <option value="Yes" <?php if( $app_info == 'Yes' ) echo 'selected="selected"'?>>Yes</option>
                    <option value="No" <?php if( $app_info == 'No' ) echo 'selected="selected"'?>>No</option>
                </select>
            </div>
            
             <div class="form-group">
                <label for="Title">Production Type :</label>                
                <?php $productionType     =  $books->PRODUCTION_SYSTEM; ?>               
                <select name="ptype" class="form-control">
                    <option value="">--select--</option>
                    <option value="1" <?php if( $productionType == '1' ) echo 'selected="selected"'?>>TAPS</option>
                    <option value="2" <?php if( $productionType == '2' ) echo 'selected="selected"'?>>NON TAPS</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="Title">E-proofing Type :</label>                
                <select name="eproof_type" class="form-control">
                    <option value=""> --Select--</option>
                    @foreach($eproofingtype as $value)
                        <option value="{{ $value['id']}}" {{ $value['id']   ==  $books->EPROOFING_TYPE?'selected':''}}> {{ $value['name']}}</option>
                    @endforeach
                </select>
            </div>
            
            <div class="form-group">
                <label for="Title">Project :</label>
                <select name="book_projectname" class="form-control" disabled="true">
                    <option value=""> --Select--</option>
                    @foreach($projecttype as $value)
                        <option value="{{ $value['id']}}" {{ $value['id']   ==  $books->PROJECT_NAME?'selected':''}}> {{ $value['name']}}</option>
                    @endforeach
                </select>
            </div>
            
            <div class="form-group">
                <label for="pwd">Book ID :</label>
                <input type="text" class="form-control" name="bookid" value="{{$books->BOOK_ID}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">E-ISBN :</label>
                <input type="text" class="form-control" name="bookprintissn" value="{{$books->ISSN_ONLINE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Author/Editor <span class="red">*</span> :</label>
                <input type="text" class="form-control required_field" name="book_authorname" value="{{($books->AUTHOR_NAME != ''?$books->AUTHOR_NAME:($books->EDITOR_NAME ==  ""?'--':$books->EDITOR_NAME))}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Series Title :</label>
                <input type="text" class="form-control" name="bookpename" value="{{@$series_array['SeriesTitle']}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">TOC Levels :</label>
                <input type="text" class="form-control" name="booktoclevel" value="{{$books->TOC_LEVELS}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Copy Editing Level :</label>
               <!-- <input type="text" class="form-control" name="celevel" value="{{$books->COPY_EDITING_LEVEL}}"> -->
                <?php $ceLevel     =  $books->COPY_EDITING_LEVEL; ?>    
                <select name="copyeditinglevel" class="form-control">
                    <option value="0" <?php if( $ceLevel == '0' ) echo 'selected="selected"'?>>0</option>
                    <option value="1" <?php if( $ceLevel == '1' ) echo 'selected="selected"'?>>1</option>
                    <option value="2" <?php if( $ceLevel == '2' ) echo 'selected="selected"'?>>2</option>
                    <option value="3" <?php if( $ceLevel == '3' ) echo 'selected="selected"'?>>3</option>
                </select>
                
            </div>
            
            <div class="form-group">
                <label for="Title">Purchase Order Number :</label>
                <input type="text" class="form-control" name="bookauthor" value="{{$books->PURCHASE_ORDER_NUMBER}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">SPI Contact :</label>
                <input type="text" class="form-control" name="bookspicontactname" value="{{$books->AM_NAME}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Manuscript Number Of Pages :</label>
                <input type="text" class="form-control" name="bookmanuscriptpages" value="{{$books->NO_PAGES}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Part  Count :</label>
                <input type="text" class="form-control" name="bookpartcount" value="{{$books->NO_PART_COUNT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Layout :</label>
                <input type="text" class="form-control" name="booklayout" value="{{$books->LAYOUT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Profile :</label>
                <input type="text" class="form-control" name="book_profile" value="{{$books->PROFILE}}" readonly="readonly">
            </div>
            
            <div class="checkbox">
                <label><input name="book_ispar" type="checkbox" {{$books->IS_PAR == 1?'checked':''}}>Is PAR</label>
            </div>
            
	</div> 
        
        <div class="col-md-3">
            
            <div class="form-group">
                <label for="Title">Embedded :</label>                
                <select name="embbedname" class="form-control" id="assigndeFaultWroflow">
                    <option value="">--Select--</option>
                        @foreach($embbedtypes as $value)
                            <option value="{{ $value['id'] }}"  {{$value['id'] == $books->EMBBED_TYPE?'selected':''}}> {{ $value['name']}}</option>
                        @endforeach
                </select>
            </div>
            
            <div class="form-group">
                <label for="Title">Publisher Name <span class="red">*</span> :</label>
                <input type="text" class="form-control required_field" name="book_publishername" value="{{$books->PUBLISHER_NAME}}"  readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Book Title <span class="red">*</span> :</label>
                <input type="text" class="form-control required_field" name="book_title" value="{{$books->JOB_TITLE}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Print ISBN <span class="red">*</span> :</label>
                <input type="text" class="form-control required_field" name="book_print_issn" value="{{$books->ISSN_PRINT}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Production Editor :</label>
                <input type="text" class="form-control" name="bookprdeditor" value="{{$books->PRODUCTION_EDITOR}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Series E-ISSN :</label>
                <input type="text" class="form-control" name="bookseriesissn" value="{{@$series_array['SeriesEISSN']}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Numbering Style :</label>
                <input type="text" class="form-control" name="booknumberingstyle" value="{{$books->NUMBERING_STYLE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Trim Size :</label>
                <input type="text" class="form-control" name="booktrimsize" value="{{$books->FORMAT_TRIM_SIZE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Book Type <span class="red">*</span> :</label>
                <input type="text" class="form-control required_field" name="book_type" value="{{$books->JOB_TYPE}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">No Of Images :</label>
                <input type="text" class="form-control" name="booknoofimg" value="{{$books->NO_OF_IMAGES}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Chapter Count :</label>
                <input type="text" class="form-control" name="bookchpcount" value="{{$books->NO_CHAPTER_COUNT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Abstract In Document Language :</label>
                <input type="text" class="form-control" name="bookabsdctln" value="{{$books->ABSTRACT_IN_DOCUMENT_LANGUAGE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Start Page :</label>
                <input type="text" class="form-control" name="bookstartpage" value="{{$books->START_PAGE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Color Images In Print :</label>
                <input type="text" class="form-control" name="bookclrimgprint" value="{{$books->COLOR_IMAGES_IN_PRINT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">KeywordsInDocumentLanguage :</label>
                <input type="text" class="form-control" name="bookprofile" value="{{$books->KEYWORDS_IN_DOCUMENT_LANGUAGE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Layout Color Count :</label>
                <input type="text" class="form-control" name="booklayoutclrcnt" value="{{$books->LAYOUT_COLOR_COUNT}}" disabled="true">
            </div>
                
            <div class="form-group">
                <label for="pwd">Spicast Details <span class="red">*</span> :</label>
                <select name="profilename" class="form-control required_field">
                    <option value="">--Select Layout Details--</option>
                    @if(count($profiles)>=1)
                            @foreach($profiles as $value)
                                <option value="{{ $value->SPICAST_ID }}"  {{$value->SPICAST_ID == $books->LAYOUT_PROFILE?'selected':''}}> {{ $value->PROFILE_NAME }}</option>
                            @endforeach
                    @endif
                </select>
            </div>
	</div> 
        <div class="col-md-3">
            <div class="form-group">
                <label for="Title">Workflow :</label>                
                <select id="workflowtype" name="workflowtype" class="form-control">
                    <option value="">--Select--</option>
                        @foreach($workflowDetails as $value)
                            <option value="{{ $value->WORKFLOW_MASTER_ID }}"  {{$value->WORKFLOW_MASTER_ID == $books->WORKFLOW_TYPE?'selected':''}}> {{ $value->WORKFLOW_MASTER_NAME}}</option>
                        @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="Title">Publisher Imprint Name :</label>
                <input type="text" class="form-control" name="bookpublisherimprintname" value="{{$books->PUBLISHER_IMPRINT_NAME}}"  disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Book Sub Title :</label>
                <input type="text" class="form-control" name="booksubtitle" value="{{$books->BOOK_SUB_TITLE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Copyright Year :</label>
                <input type="text" class="form-control" name="bookcopyyear" value="{{$books->COPYRIGHT_YEAR}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title"> Contact Person :</label>
                <input type="text" class="form-control required_field" name="contact_person" value="{{$books->PE_NAME}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Series Print-ISSN :</label>
                <input type="text" class="form-control" name="bookseriesissn" value="{{@$series_array['SeriesPrintISSN']}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Numbering Depth :</label>
                <input type="text" class="form-control" name="booknumberingdepth" value="{{$books->NUMBERING_DEPTH}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Book Multi Volume Count :</label>
                <input type="text" class="form-control" name="bookmultivolumecount" value="{{$books->BOOK_MULTI_VOLUME_COUNT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Location :</label>
                <input type="text" class="form-control" name="booklocation" value="{{$books->LOCATIONJOBINFO}}" disabled="true">
            </div>
           
            <div class="form-group">
                <label for="Title">Production Location <span class="red">*</span> :</label>
                @if(isset($prdloc->LOCATION_NAME))
                <input type="text" class="form-control required_field" name="book_production_location" value="{{$prdloc->LOCATION_NAME}}" readonly="readonly">
                @else
                <input type="text" class="form-control required_field" name="book_production_location" value="" readonly="readonly">
                @endif
            </div>
            
            <div class="form-group">
                <label for="Title">Black/White Images :</label>
                <input type="text" class="form-control" name="bookblkwhitimages" value="{{$books->BLACK_WHITE_IMAGES}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">APage Objects Count :</label>
                <input type="text" class="form-control" name="bookapagecount" value="{{$books->NO_APAGE_COUNT}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Classification Style :</label>
                <input type="text" class="form-control" name="bookclassificationstyle" value="{{$books->CLASSIFICATION_STYLE}}" disabled="true">
            </div>
            <div class="form-group">
                <label for="pwd">Running Head :</label>
                <input type="text" class="form-control" name="bookrunninghead" value="{{$books->RUNNING_HEAD}}" disabled="true">
            </div>
            <div class="form-group">
                <label for="pwd">Citation Style :</label>
                <input type="text" class="form-control" name="bookprofile" value="{{$books->CITATION_STYLE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">TitleUpperCase :</label>
                <input type="text" class="form-control" name="bookprofile" value="{{$books->TITLE_UPPERCASE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Taps Location :</label>
                <select name="tapslocation" class="form-control required_field">
                    <option value="">--Select Taps Location--</option>
                    @if(count($location_details)>=1)
                        @foreach($location_details as $value)
                            <option value="{{ $value->ID }}"  {{$value->ID == $books->TAPS_LOCATION?'selected':''}}> {{ $value->LOCATION_NAME }}</option>
                        @endforeach
                    @endif
                </select>
            </div>
            
	</div> 
        
	<div class="col-md-3">
            <div class="form-group">
                 <label for="Title">Category <span class="red">*</span>:</label>                
                <select name="eproof_system" class="form-control required_field">
                    <option value=""> --Select--</option>
                    @foreach($bookcategory as $value)
                        <option value="{{ $value->ID }}"  {{$value->ID == $books->EPROOFING_SYSTEM?'selected':''}}> {{ $value->NAME}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                    <label for="pwd">Publisher Location :</label>
                    <input type="text" class="form-control required_field" name="book_publisher_location" value="{{$books->PUBLISHER_LOCATION}}" readonly="readonly">
            </div>
            
            <div class="form-group">
                <label for="Title">Book DOI :</label>
                <input type="text" class="form-control" name="booktitle" value="{{$books->DOI}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="pwd">Copyright Holder Name :</label>
                <input type="text" class="form-control" name="bookcpyrightholdername" value="{{$books->COPYRIGHT_HOLDER_NAME}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Series ID :</label>
                <input type="text" class="form-control" name="bookseriesid" value="{{@$series_array['SerieId']}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Language :</label>
                <input type="text" class="form-control" name="booklanguage" value="{{$books->LANGUAGE}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Contains ESM :</label>
                <input type="text" class="form-control" name="booktcontainsesm" value="{{$books->CONTAINS_ESM}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Volume No :</label>
                <input type="text" class="form-control" name="bookevolume" value="" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Production Classification :</label>
                <input type="text" class="form-control" name="bookprdclassification" value="{{$books->PRODUCTION_CLASSIFICATION}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Application <span class="red">*</span> :</label>                
                <?php $app_info   =  $books->APPLICATION; ?>                
                <select name="book_application" class="form-control required_field">
                    <option value="">--select--</option>
                    <option value="3B2" <?php if( $app_info == '3B2' ) echo 'selected="selected"'?>>3B2</option>
                    <option value="InDesign" <?php if( $app_info == 'InDesign' ) echo 'selected="selected"'?>>InDesign</option>
                    <option value="LaTeX" <?php if( $app_info == 'LaTeX' ) echo 'selected="selected"'?>>LaTeX</option>                    
                </select>   
            </div>
            
            <div class="form-group">
                <label for="Title">Color Images :</label>
                <input type="text" class="form-control" name="booknoofclrimg" value="{{$color_img}}" disabled="true">
            </div>
            
            <div class="form-group">
                <label for="Title">Author Information Style :</label>
                
                <input type="text" class="form-control" name="bookauthorinformstyle" value="{{$books->AUTHOR_INFORMATION_STYLE}}" disabled="true">
                
            </div>
            
            <div class="form-group">
                <label for="pwd">Bibliography Style :</label>
                <input type="text" class="form-control" name="bookbibliographystyle" value="{{$books->BIBLIOGRAPHY_STYLE}}" disabled="true">
            </div>
            <div class="form-group">
                <label for="pwd">Logo On First Page :</label>
                <input type="text" class="form-control" name="booklogonfirstpage" value="{{$books->LOGO_ON_FIRST_PAGE}}" disabled="true">
            </div>
            <div class="form-group">
                <label for="pwd">Printing Color Count :</label>
                <input type="text" class="form-control" name="bookprintingcolorcnt" value="{{$books->PRINTING_COLOR_COUNT}}" disabled="true">
            </div>
            
            <input type="hidden" name="jobId" value="{{$projectId}}">
            
            
             <div class="form-group">
                <label for="pwd">Indexing Required:</label>
                <?php $indexReq     =  $books->IS_INDEXING; ?>    
                <select name="indexing" class="form-control">
                    <option value="Yes" <?php if( $indexReq == 'Yes' ) echo 'selected="selected"'?>>Yes</option>
                    <option value="No" <?php if( $indexReq == 'No' ) echo 'selected="selected"'?>>No</option>
                </select>
            </div>
            
	</div>
    </div>
        
        <?php $deadline_array    =   (array)json_decode( $books->STAGE_DEADLINES_COLLECTION); ?>
        
	<!-- deadline-->
        <div class="row">
            <h3 class="text-primary"><center>Deadline</center></h3>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Title">Stage5 :</label>
                    <input type="text" class="form-control" name="booktitle" value="{{@$deadline_array['S5']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="Title">Stage300 :</label>
                    <input type="text" class="form-control" name="bookamname" value="{{@$deadline_array['S300']}}" disabled="true">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="pwd">Stage50 :</label>
                    <input type="text" class="form-control" name="bookcopyright" value="{{@$deadline_array['S50']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="Title">Stage600 :</label>
                    <input type="text" class="form-control" name="booktitle" value="{{@$deadline_array['S600']}}" disabled="true">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Title">Stage200 :</label>
                    <input type="text" class="form-control" name="bookpelocation" value="{{@$deadline_array['S200']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="pwd">Stage650 :</label>
                    <input type="text" class="form-control" name="bookcopyright" value="{{@$deadline_array['S650']}}" disabled="true">
                </div>
            </div>
        </div>
    
        <!--received on -->
        
        <div class="row">
            <h3 class="text-primary"><center>Received on</center></h3>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Title">Stage5 :</label>
                    <input type="text" class="form-control" name="books5received" value="{{@$jobRoundMilestone['S5']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="Title">Stage300 :</label>
                    <input type="text" class="form-control" name="book300received" value="{{@$jobRoundMilestone['S300']}}" disabled="true">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="pwd">Stage50 :</label>
                    <input type="text" class="form-control" name="bookss50received" value="{{@$jobRoundMilestone['S50']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="Title">Stage600 :</label>
                    <input type="text" class="form-control" name="books600received" value="{{@$jobRoundMilestone['S600']}}" disabled="true">
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="Title">Stage200 :</label>
                    <input type="text" class="form-control" name="bookp200received" value="{{@$jobRoundMilestone['S200']}}" disabled="true">
                </div>
                <div class="form-group">
                    <label for="pwd">Stage650 :</label>
                    <input type="text" class="form-control" name="book650received" value="{{@$jobRoundMilestone['S650']}}" disabled="true">
                </div>
            </div>
        </div>
      
        <div class="clear2"></div>
        <div class="row">
                <div class="col-md-12 text-center">
                    <input class="btn btn-round btn-primary" ng-click="updatebookdata()" type="submit" name="updateispar" value="Update">
                </div>
            <div class="col-md-2"></div>	
        </div>
        
	@endforeach
@else
	<div class="col-md-12 alert alert-danger"><center>No Data Found</center></div>
@endif 
</div>   
</form>
@section('bootomScripts')
<script src="{{url('/assets/dist/js/bootbox.min.js')}}"></script> 
<script src="{{url('/angular/book-info.app.js')}}"></script> 
<script src="{{url('/assets/dist/js/jquery.nestable.min.js')}}"></script>

<script>
    var embbedval   =   $("#assigndeFaultWroflow").val();
    if(embbedval    ==  '')
    {
        $("#workflowtype option[value='33']").attr('selected',true);
    }
    $("#assigndeFaultWroflow").change(function() {
        var embType  =   this.value;
        if(embType == ''){
//            changeattr();
            $("#workflowtype option[value='33']").attr('selected',true);
            $("#workflowtype option[value='34']").removeAttr('selected');
            $("#workflowtype option[value='35']").removeAttr('selected');
        }
        if(embType == 1){
//            changeattr();
            $("#workflowtype option[value='34']").attr('selected',true);
            $("#workflowtype option[value='33']").removeAttr('selected');
            $("#workflowtype option[value='35']").removeAttr('selected');
        }
        if(embType == 2){
//            changeattr();
            $("#workflowtype option[value='35']").attr('selected',true);
            $("#workflowtype option[value='34']").removeAttr('selected');
            $("#workflowtype option[value='33']").removeAttr('selected');
        }
    }); 
    function changeattr()
    {
        $('select[name="embbedname"]').each(function() {
            $("#workflowtype").find('option').removeAttr("selected");
        });
    }
    var updatebutton    =   "<?php echo $workflowenable;?>";
    if(updatebutton     ==  1)
    {
        $(document).find(':submit').css("display",'none');
        $("#addCheckItemFrm").find(':input').prop("disabled", true);
    }
    
    </script>
@endsection