/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ( $scope , $http , $rootScope, $filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
    
    $scope.projectList 	=   [];
    $scope.showProject 	=   false;
    $scope.menuParent 	=   'Download';
    $scope.menuChild  	=   '';
    
    if(isNaN(getUrlParameter(1))){
        $scope.searchrounddownload  =   "";
    }else{
        $scope.searchrounddownload  =   getUrlParameter(1);
    }
//    $scope.stopwatch    =   new Date();
//    $interval(function() {
//        $scope.date         =   new Date();
//        $scope.diff         =   new Date($scope.date)-new Date($scope.strt);
//        $scope.diffMins     =   Math.round((($scope.diff % 86400000) % 3600000) / 60000);
//        console.log($scope.diffMins);
//    },1000);
//    $scope.dif     =   (Math.floor(milisecondsDiff(1000*60))%60).toLocaleString(undefined, {minimumIntegerDigits: 2}) ;
       
    $scope.contentloadtimer     =   1;
    $scope.getDownloadFailedList    =   function( ){
        var input   =   { id : '' };
        $scope.downloadFailed  =   [];
        $http.get(  BASE_URL+"getChapterdownloadFailedList" , input ) .then(
             
             function mySuccess( response ){  
                   $scope.downloadFailed    =   response.data.downloadfailed; 
                   $scope.processtypes      =   PROCESS_TYPE; 
             } ,              
             function myError( response ){ 
                 if($scope.contentloadtimer    <  10){
                    $scope.getDownloadFailedList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                $scope.contentloadtimer++;   
             }
                  
        );
        
    }
  
    $scope.retryMetaExtractor = function( item ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
           
           if(result){
               
               var inp      =      {  book_id : item.BOOK_ID  };
               
               $http.post( BASE_URL+'' , inp ).then( function mySuccess( response ){
                   
                   
                   
               }, 
               function myError(response) {
                    console.log(response);
                    showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
           }
            
        });
    
    }
    
    $scope.contentloadtimer     =   1;
    $scope.jobassigned     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
        var input   		= 	{ roudid : '116' };
                
        $http.get(  BASE_URL+"chapterlevelassignedlist" , input ) .then(function mySuccess( response ){  
            $scope.jobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
            $scope.pmuserlist    =   response.data.pmUserList;
        } ,
        function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;   
        });
        
    }
    
    $scope.assignAm = function(pmselect,item)
    {   
       
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {        
            if( result ){                
                showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect  , book_id : item.BOOK_ID };
                    
                    $http.post( API_URL+"jobassignAm" , inp ).then(function mySuccess(response) {
                        hideLoader();
                          
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                              
                            //$scope.showProjectList();
                        //showMessage('Message', response.data , response.data );
                        
                    },function myError(response) {
                        console.log(response);
                        showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
            }
        });
    }
    
    $rootScope.currentworkflowname  =   "";
    //TAPS SIGNALING
    $scope.tapsType     =   function(item,ptype)
    {   
        //get workflow name
        $scope.errorshow    =   false;
        showLoader( 'please wait for a while...' );
        var inp     =   {	
                            jobId : item.JOB_ID
                        }; 
            $http.post(BASE_URL+"getworkflowname", inp ).then(function mySuccess(response) 
            {
                hideLoader();
                if( response.data.status == 1 ){
                    $rootScope.currentworkflowname  =   response.data.errMsg;
                    $scope.currentlocationname      =   response.data.locationname;
                    bootbox.confirm('<b>Worflow Selected : '+$rootScope.currentworkflowname+'</b> <br> <b>Location Selected : '+$scope.currentlocationname+'</b> <br> Are you sure to proceed on this ?', function( result ) 
                    {     
                        if( result )
                        {                
                            showLoader( 'please wait for a while...' );
                            var inp     =   {	
                                                jobId : item.JOB_ID, 
                                                metadataId : item.METADATA_ID,
                                                tapsstype:angular.element("#taps_"+item.METADATA_ID).val(),
                                                ChapterNo : item.CHAPTER_NO ,
                                                ChapterTitle : item.CHAPTER_TITLE,
                                                roundid :item.ROUND_ID
                                            };  

                                $http.post(API_URL+"domovenonTaps", inp ).then(function mySuccess(response) 
                                {
                                    hideLoader();
                                    if( response.data.status == 1 ){

                                        var appenddata  =   '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for womat response</code>';
                                        angular.element(".tapserrorres_"+item.METADATA_ID).remove();
                                        angular.element("#tapsresponse_"+item.METADATA_ID).append(appenddata);
                                        showNotify( response.data.errMsg , 'success' );
                                    }
                                    if( response.data.status == 401 ){    
                                        $scope.errorshow    =   true;
                                        $scope.shownotavaiablechapter   =   response.data.errMsg;
                                        showNotify( "All field's are required" , 'danger' );
                                    }

                                    if( response.data.status == 0 ){                                 
                                        showNotify( response.data.errMsg , 'danger' );
                                    }
                                },function myError(response) {
                                    hideLoader();
                                    showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
                            });
                        }else{
                            $("#taps_"+item.METADATA_ID).val(ptype);
                        }

                    });
                }
                if( response.data.status == 0 ){                                 
                    showNotify( response.data.errMsg , 'danger' );
                }
            },function myError(response) {
                hideLoader();
                showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
        });
        
        
    }
    
    $scope.showXMLInModal   =   function(item) 
    {     
        var inp             = 	{
                                        jobId       :   item.JOB_ID,
                                        metadataid  :   item.METADATA_ID,
                                        Chapter     :   item.CHAPTER_NO,
                                        bookid      :   item.BOOK_ID,
                                        roundid     :   item.ROUND_ID
                                    };
        $scope.htmlcon      =   "Chapter XML Information";
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
                url         :   API_URL + "getChapterjobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('#xmlContent').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $('#xmlContent').html('<p class="text-center">'+response.errMsg+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    $scope.showMeataextratorremarksview = 	function(params){   

             var printMsg    =   ( params.UPDATE_REMARKS == null || params.UPDATE_REMARKS == '') ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
            
    //show meta extrator remarks commands
    $scope.showUploadRemarksview = 	function(params){   
         var printMsg    =   ( params.UPLOAD_REMARKS == null || params.UPLOAD_REMARKS == '' ) ? 'remarks not found..' : params.UPLOAD_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Jobsheet Uploade";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };	
    
    $scope.showDownloadRemarksview = 	function(params){   
         var printMsg    =   ( params.APFT_REMARKS == null || params.APFT_REMARKS == '' ) ? 'remarks not found..' : params.APFT_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Jobsheet Download";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
    
    $scope.retryJobsheetDownload    = 	function(params){
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobdownloadid        =   params.APFTID;
       var dynamic_url  =   "retrydownload/"+jobdownloadid;   

       $http.get(API_URL+dynamic_url).then(function mySuccess(response) {
            if(response.data.status == 1) {
              $timeout( function(){  
                hideLoader();
                showNotify(response.data.errMsg , 'success' );
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );
               }, 5000 );
            }
            if(response.data.status == 0) {
               showNotify(response.data.errMsg , 'danger' );
               hideLoader();
            }

        },function myError(response) {
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
    $scope.sendRedoExtration 			= 	function(params){   
            
           console.log( params );
           var printMsg    =   ( params.REMARKS == null || params.REMARKS == '' ) ? 'remarks not found..' : params.REMARKS;
           $('#show-redo').trigger('click');
           $scope.Msgbox 	=	"Success Redo";
           $('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
        
    $scope.downloadClientAckFiles  = function( params , type  ){
        
        var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID , type : type };
        
        showLoader('Please wait while opening...');                
            
        $http.post( API_URL+"downloadClientAckFailureRetryFiles" , inp ).then(function mySuccess(response) {
            
            if( response.data.status == 1 ){
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 || response.data.status == 'failed'){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });            
        
    };
    
    
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    };    
    
    
    $scope.showRedoview =   function(params){
             var printMsg    =   ( params.SR_REMARKS == null || params.SR_REMARKS == '' ) ? 'remarks not found..' : params.SR_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Client Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
    
    $scope.showTapsremarks =   function(params)
    {
        var printMsg    =   ( params.TAPS_REMARKS == null || params.TAPS_REMARKS == '' ) ? 'remarks not found..' : params.TAPS_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Taps Acknowledgement";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    }
    
    $scope.showSuccessredologview   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.CLIACKID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    $scope.retryJobsheetUpdate 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/RECEIPT/'+params.METADATA_ID+'/Retry';   

       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {      

              $timeout( function(){  
                hideLoader();
                showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
	
    $scope.retryJobsheetUpload 			= 	function(params){   
            
        console.log( params );
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();

        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/RECEIPT/'+params.METADATA_ID;      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            //$scope.getUserDetail();
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             console.log(response);
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

        //$('#show-redo').trigger('click');
        //$scope.Msgbox 	=	"Success Redo";
        //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');

        };
    
    $scope.sendRedo = function(params) 
    {   
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {
            if(result) 
            {
                var inp 	= 	{ jobID: params.JOB_ID};
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success Redo";
                $('#redofailed').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $http({
                                url: BASE_URL + "retrySuccessRedo",
                                method: 'post',
                                data:inp
                         })
                        .success(function(response) {
                                $('#redofailed').html(response);
                        })
                        .error(function(response) {

                        });
            }
        });
    }

    $scope.getDownloadFailedList();
    
    $scope.jobassigned();
    
    $scope.contentloadtimer     =   1;
    $scope.getAllPrdLocations   =       function(){
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){
                if($scope.contentloadtimer    <  10){
                $scope.getAllPrdLocations();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;   
        });        
    }
    
    $scope.getAllPrdLocations();
    
    $scope.chgPrdLoc    =       function( drpdwn , row_info ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
         $('#xmlContent1').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	    
            if( result ){
                
                var inp = {	location_id : drpdwn  , book_id : row_info.BOOK_ID ,  job_id : row_info.JOB_ID  };

                    $http.post( API_URL+"changePrdLocation" , inp ).then(function mySuccess(response) {
                        
                        $('#xmlContent1').html('');
                        showMessage('Message', response.data.errMsg , response.data.msg );               
                        
                    }, 
                    function myError(response) {
                             console.log(response);
                    });
                    
            }
             $('#xmlContent1').html('');
            
        });
        
    }
    
    $scope.contentloadtimer     =   1;
    $scope.getPmList            =   function(){     
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){
                if($scope.contentloadtimer    <  10){
                $scope.getPmList();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;   
        });        
    }
    
    
    $scope.assignAm = function(pmselect,item){
       
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
             
            if( result ){                
                showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect  , book_id : item.BOOK_ID };
                    
                    $http.post( API_URL+"jobassignAm" , inp ).then(function mySuccess(response) {
                        hideLoader();
                          
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                              
                            //$scope.showProjectList();
                        //showMessage('Message', response.data , response.data );
                        
                    },function myError(response) {
                        console.log(response);
                        showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
            }
            
        });
        
    }
    
    $scope.assignPm = function( pmselect,item ){
           
           bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
               if( result ){
                   showLoader( 'please wait for a while...' ); 
                   
                   
                   
                    var inp = {	user_id : pmselect, book_id : item.BOOK_ID};
                    $http.post(API_URL+"jobassignPm",inp) .then(function mySuccess(response) {
                        
                        hideLoader();                        
                        if( response.data.status == 1 ){                                 
                            showNotify( response.data.msg , 'success' );
                            $scope.retryJobsheetUpdate( item );
                        }
                        if( response.data.status == 0 ){                                 
                            showNotify( response.data.msg , 'danger' );
                        }
                        
                        /*
                         * 
                         setTimeout( function(){ 
                            $window.location.reload();
                        } , 5000 );
                        
                        */
                    }, 
                    function myError(response) {
                        hideLoader();                        
                         showNotify( 'Oops, Kindly reload the page...' , 'danger');
                    });	
                    
                }    

            });
        }
        
        
    $scope.chgPrdLoc2    =       function( drpdwn , row_info ){
 
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
            showLoader( 'please wait for a while...' );
            if( result ){
                var inp = {	location_id : drpdwn  , book_id : row_info.BOOK_ID ,  job_id : row_info.JOB_ID , metaid : row_info.METADATA_ID };
                    $http.post( API_URL+"changePrdLocation" , inp ).then(function mySuccess(response) {

                        if( response.data.status == 1 ){
                            hideLoader();
                            showNotify( response.data.errMsg , 'success' );
                            $("#locationdisable_"+row_info.METADATA_ID+"_"+row_info.ROUND_ID).attr('disabled',true);
                        }

                        if( response.data.status == 0 ){    
                            hideLoader();
                            showNotify( response.data.errMsg , 'danger' );
                        }
                        //showMessage('Message', response.data.errMsg , response.data.msg );               
                    }, 
                    function myError(response) {
                        hideLoader();
                        console.log(response);
                        showNotify( 'Oops, Try again after sometimes' , 'danger' );
                    });
                }
            hideLoader();
        });

    }
    
});