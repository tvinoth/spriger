<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\apitapsModel;
use App\Models\tapsmetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\metadataInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\jobStage;
use App\Models\checkoutModel;
use App\Models\bookinfoModel;
use App\Models\jobRound;
use App\Models\customizationModel;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel;
use App\Models\workflowServerMapPathModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\packageController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class tapsController extends Controller
{  
    public function domoveTapstest(Request $request)
    {
        $getToolresponse    =   json_decode(file_get_contents('php://input'));
        $returndata         =   json_encode(array('TOKEN_KEY'=>'MGj8UvjP0h',
                                                                'STATUS'=>1,
                                                                'DESTINATION_PATH'=>'\\ppdys-fs02\Production_V\SPRINGER\WOMAT-II\Production\Prodenv\0000000053\TAPS\IN\0003045570',
                                                                'END_TIME'=>'2018-03-29 14:12:03',
                                                                'ESM_LOCATION'=>'\\ppdys-fs02\Production_V\SPRINGER\WOMAT-II\Production\Prodenv\0000000053\TAPS\ESM\0003045570',
                                                                'ESM_DETAILS'=>array('FileName'=>'',
                                                                                        'Extension'=>'',
                                                                                        'Size'=>'',
                                                                                        'VideoSize'=>'',
                                                                                        'ESMType'=>'',
                                                                                        'VideoDuration'=>'',
                                                                                        'VideoResolution'=>'',
                                                                                        'VideoStreaming'=>'',
                                                                                        'VideoID'=>''
                                                                                    ),
                                                                'QURIES'=>'',
                                                                'REMARKS'=>'')
                                            );
        print_r($getToolresponse); exit;
//        $returndata     =   "success|Chapter 1|EJI3FmB0NK|2018-03-30 10:03:18";
        return $getToolresponse;
    }
    
    public function getTapsWebUrlBasedOnProductionArea( $jobId ){
        
        //use default path if prduction location is not avail
        $tapsWebUrlconst    =   \Config::get('constants.TAPS.TAPS_WEB_URL');
        $url                =   $tapsWebUrlconst[1];
        
        $getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );
        
        if( !empty( $getlocationftp ) ) {
            $locationid         =       $getlocationftp->PRODUCTION_LOCATION;
            $url                =       $tapsWebUrlconst[ $locationid ];
        }
        
        return $url;        
        
    }
    
     public function domoveTaps($jobId,$metadataID,$roundID,$ChapterNo,$ChapterTitle,$jstageId='')
    {
        try
        {
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $getchapters        =   taskLevelMetadataModel::getMetadatadetailsChapter($metadataID);
            
            $chapterlist        =   $getchapters->pluck('CHAPTER_NO')->toArray(); 
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
            
            if(!empty($jstageId)){
                $workflowPath                       =   new workflowServerMapPathModel();
                $serverMapPath                      =   $workflowPath->getWorkflowServerMapPath($jstageId);
                if(!empty($serverMapPath['detail']['src'])){
                    $srcPath        =   array_filter(explode('/',$serverMapPath['detail']['src']));
                    array_pop($srcPath);
                    $stageName      =   end($srcPath);
                }
                
            }
            
            
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($chapterlist)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                
                $ftp_root_dir       =   Config::get('constants.SPICAST_BACKGROUND_FILE').'/';
                $open_path          =   $ftp_root_dir.$bookid;         
                $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                
                if(!empty($jstageId) && !empty($stageName)){
                    $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundID),
                                            '{STAGE}' =>  $stageName,
                                            '{CID}' =>    $ChapterNo,
                                         );
                }else{
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundID),
                                            '{STAGE}' =>  Config::get('constants.STAGE_NAME.SPICE'),
                                            '{CID}' =>    $ChapterNo,
                                         );
                }
                $cmn_obj            =   new CommonMethodsController();
                $open_path          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $open_path          =   $hostpath.$open_path;
                $serverDirallFiles  =   $ftpObj->allFiles($open_path);
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $getoriginalchapter =   [];
                $getartpaths        =   [];
                $getchapterpaths    =   [];
                $ChapterName        =   "";
                if(count($serverDirallFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    foreach($serverDirallFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    if(strpos($splitname[0],$bookid) !== false)
                                    {
                                        $ChapterName    =   $splitname[0];
                                    }
                                }
                            }
                            
//                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
//                            if(in_array($spiltchapter,$chapterlist))
//                            {
//                                $serverDirFiles  =   $ftpObj->allDirectories($open_path.'/'.$spiltchapter);
//                                if(count($serverDirFiles)>=1)
//                                {
//                                    foreach($serverDirFiles as $key=>$valueimg)
//                                    {
//                                        if(strpos($valueimg,'/') !== 	false)
//                                        {
//                                            $atrspiltchapter    =   substr(strrchr($valueimg, "/"), 1);
//                                            if($atrspiltchapter ==  "images")
//                                            {
//                                                $getartpaths[]  =   $hostserver.$ftp_root_dir.$valueimg;
//                                            }
//                                        }
//                                    }
//                                }
//                                else {
//                                    $getartpaths[]      =   "";
//                                }
//                                $getchapterpaths[]      =   $hostserver.$ftp_root_dir.$jsonvalue;
//                                $getoriginalchapter[]   =   $spiltchapter;
//                            }
                        }
                    }
                }
                
                if(count($serverDirallFiles)  ==  0)
                {
                    $result             =   array('result'=>400,'status'=>0,'errMsg'=>'Chapter path is empty');   
                    return response()->json($result);
                }
                $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                if(!empty($jstageId) && !empty($stageName)){
                    $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundID),
                                            '{STAGE}' =>  $stageName,
                                            '{CID}' =>    $ChapterNo,
                                         );
                }else{
                    $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundID),
                                            '{STAGE}' =>  Config::get('constants.STAGE_NAME.COPY_EDITING'),
                                            '{CID}' =>    $ChapterNo,
                                         );
                }
                $cmn_obj            =   new CommonMethodsController();
                $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                $open_path          =   $hostpath.$rawpath;
                $service_path       =   $hostserver.$rootdir.$open_path;
                $service_path       =   str_replace('//','/',$service_path);
                $destinationurl     =   $hostserver.$rootdir.$open_path; 
                $destinationurl     =   str_replace(Config::get('constants.STAGE_NAME.COPY_EDITING'),Config::get('constants.STAGE_NAME.SPICE'),$destinationurl);
              
                $destinationurl     =   str_replace("//","/",$destinationurl);
                if(!empty($destinationurl))
                {
                    $destinationurl =   "\\\\".$destinationurl;
                    $destinationurl =   str_replace( '/' ,'\\', $destinationurl );
                }
                
                //art reject path
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundID),
                                            '{STAGE}' =>  Config::get('constants.STAGE_NAME.ART_QC'),
                                            '{CID}' =>    $ChapterNo,
                                         );
                $cmn_obj            =   new CommonMethodsController();
                $artsourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $artsourceqcpath    =   $hostpath.$artsourceqcpath;
                
                $serverartqcFiles   =   $ftpObj->allFiles($open_path);
                if(count($serverartqcFiles) > 0 )
                {
                    $artsourceqcpath    =   $hostserver.$rootdir.$artsourceqcpath;
                    $artsourceqcpath    =   str_replace("//","/",$artsourceqcpath);
                }/*else{
                    $artsourceqcpath    =   $hostserver.$rootdir.$artsourceqcpath;
                    $artsourceqcpath    =   str_replace("//","/",$artsourceqcpath);
                }*/
                if(!empty($artsourceqcpath))
                {
                    $artsourceqcpath    =   "\\\\".$artsourceqcpath;
                    $artsourceqcpath    =   str_replace( '/' ,'\\', $artsourceqcpath );
                }
                $artsourceqcpath        =   rtrim($artsourceqcpath,'\\');
                $tapsdata               =   [];
                if(strpos(strtoupper($ChapterNo),Config::get('constants.CHECK_PART')) !== false)
                {
                    $chapterno          =   $ChapterNo;
                }else
                {
                    $chapterno          =   (strpos($ChapterNo,'_') !== false?substr(strrchr($ChapterNo, "_"), 1):$ChapterNo);
                }
                
                $tapsdata['chapter_id']     =   $metadataID;
                $tapsdata['chapter_name']   =   (strpos($ChapterName,$bookid) !== false?$ChapterName:$ChapterNo);
                $tapsdata['chapter_no']     =   $chapterno;
                $tapsdata['platform']       =   (count($bookdata)>=1?$bookdata->APPLICATION:'');
                $whereart                   =   array('METADATA_ID'=>$metadataID,'IS_ACTIVE'=>1);
                $artmetaid                  =   taskLevelArtMetadataModel::where($whereart)->get();
                $checkartcomplete           =   $artmetaid->where('STATUS_ENUM_ID',Config::get('constants.ART_STATUS.ART_COMPLETED'))->all();
                $tapsdata['Project']        =   "Magnus Springer";
                $tapsdata['Template_Code']  =   "--Select--";
                $tapsdata['ce_required']    =   (count($bookdata)>=1?$bookdata->CE_REQUIRED:'');
                $tapsdata['client_name']    =   Config::get('constants.CLIENTNAME');
                $tapsdata['copyrightyear']  =   (count($bookdata)>=1?$bookdata->COPYRIGHT_YEAR:'');
                $tapsdata['is_art_present'] =   (count($artmetaid)>=1?'Yes':'No');
                if(count($checkartcomplete) ==  count($artmetaid))
                {
                    $tapsdata['is_art_requested']   =   'Yes'; 
                }
                else
                {
                    $tapsdata['is_art_requested']   =   'No'; 
                }
                $tapsdata['is_query_raised']=   'No';
                $tapsdata['jcode']          =   '';
                $tapsdata['stage']          =   Config::get('constants.ROUND_NAME.116');
                $tapsdata['jid']            =   $bookid;
                $tapsdata['originated_from']=   "MAGNUS";
                $tapsdata['originated_on']  =   date( 'Y-m-d h:i:s a');
                //get taps metadata info
                $wheredata['METADATA_ID']   =   $metadataID;
                $wheredata['ROUND']         =   $roundID;
                $wheredata['STATUS']        =   true;
                $tapsdespath                =   $hostpath.Config::get('constants.TAPS_PROJECT_DEST_PATH').$ChapterName;
                $checkdestdirexist          =   $ftpObj->has($tapsdespath);
                if(empty($checkdestdirexist) && $checkdestdirexist != 1){
                    $ftpObj->makeDirectory($tapsdespath,0777);
                }
                $gettapsmetainfo            =   tapsmetadataModel::where($wheredata)->orderBy('ID','desc')->first();
//                if(count($gettapsmetainfo)>=1)
//                {
//                    $tapsdata['projectSrcPath'] =   rtrim($destinationurl,'\\');
////                    $tapsdata['projectdestPath']=   Config::get('constants.PROJECT_DEST_PATH').'\\'.$ChapterName;
//                    $tapsdata['projectdestPath']=   (count($gettapsmetainfo)>=1?$gettapsmetainfo->DESTINATION_PATH:'');
//                    $tapsdata['ESMLocation']    =   (count($gettapsmetainfo)>=1?$gettapsmetainfo->ESM_LOCATION:'');
//                }
//                else
//                {
                    $tapsdata['projectSrcPath'] =   rtrim($destinationurl,'\\');
                    $tapsdata['projectdestPath']=   Config::get('constants.PROJECT_DEST_PATH').'\\'.$ChapterName;
                    $tapsdata['ESMLocation']    =   "";
//                }
                
                $tapsdata['CreateRejectArtPath']=   Config::get('constants.CREATE_REJECT_ART_PATH');
                $tapsdata['ArtSourcePath']      =   $artsourceqcpath;
                $tapsdata['ArtLowResCreation']  =   Config::get('constants.TAPS.ART_LOWRES_CREATION');

                $artpath            =   Config::get('constants.SPLIT_DESTINATION_PATH');
                $artfilename        =   Config::get('constants.ART_SOURCE_PATHS');
                $hostpath           =   str_replace( '/' ,'', $hostpath );
                $raw_path           =   $hostserver.$ftp_root_dir.$hostpath.'/'.Config::get('constants.SPLIT_SOURCE_PATH');                    
                $raw_path           =   str_replace( 'BOOK_ID' ,$bookid, $raw_path );
                $raw_path           =   str_replace( 'ROUND_NAME' ,Config::get('constants.ROUND_OF_NAME.S200'), $raw_path );
                $tapsdata['WithBleed']      =   "NO";
                if($raw_path != '')
                {
                    $raw_path           =   "\\\\".$raw_path;
                    $raw_path           =   str_replace( '/' ,'\\', $raw_path );
                }
                $tapsdata['rawSrcPath'] =   rtrim($raw_path,'\\');
                if($service_path != '')
                {
                    $service_path       =   "\\\\".$service_path;
                    $service_path       =   str_replace( '/' ,'\\', $service_path );
                }
		$tapsdata['ESMDetails']	=	(count($gettapsmetainfo)>=1?json_decode($gettapsmetainfo->ESM_DETAILS):'');
                /*if(count($decodeesm)>=1)
                {
                    $tapsdata['ESMDetails']['FileName']     =   $decodeesm->FileName;
                    $tapsdata['ESMDetails']['Extension']    =   $decodeesm->Extension;
                    $tapsdata['ESMDetails']['Size']         =   $decodeesm->Size;
                    $tapsdata['ESMDetails']['VideoSize']    =   $decodeesm->VideoSize;
                    $tapsdata['ESMDetails']['ESMType']      =   $decodeesm->ESMType;
                    $tapsdata['ESMDetails']['VideoDuration']    =   $decodeesm->VideoDuration;
                    $tapsdata['ESMDetails']['VideoResolution']  =   $decodeesm->VideoResolution;
                    $tapsdata['ESMDetails']['VideoStreaming']   =   $decodeesm->VideoStreaming;
                    $tapsdata['ESMDetails']['VideoID']      =   $decodeesm->VideoID;
                    
                }*/
                /*else 
                {
                    $tapsdata['ESMDetails']['FileName']     =   "";
                    $tapsdata['ESMDetails']['Extension']    =   "";
                    $tapsdata['ESMDetails']['Size']         =   "";
                    $tapsdata['ESMDetails']['VideoSize']    =   "";
                    $tapsdata['ESMDetails']['ESMType']      =   "";
                    $tapsdata['ESMDetails']['VideoDuration']    =   "";
                    $tapsdata['ESMDetails']['VideoResolution']  =   "";
                    $tapsdata['ESMDetails']['VideoStreaming']   =   "";
                    $tapsdata['ESMDetails']['VideoID']      =   "";
                }*/
                
		$decodewomat          	=   (count($gettapsmetainfo)>=1?json_decode($gettapsmetainfo->WOMAT_DETAILS):[]);
                $tapsdata['queries']    =   (count($gettapsmetainfo)>=1?$gettapsmetainfo->QURIES:'');
//        	$tapsdata['WOMATAPISignalDetails'] 	=	$decodewomat;
                //api taps info store
                $tapsmeatadata                  =   [];
                $tapsmeatadata['ROUND']         =   $roundID;
                $tapsmeatadata['METADATA_ID']   =   $metadataID;
                $tapsmeatadata['START_TIME']    =   Carbon::now();
                $tapsmeatadata['CREATED_DATE']  =   Carbon::now();
                $tapsmeatadata['CREATED_BY']    =   (Session::get('users')['user_id'] == null?1:Session::get('users')['user_id']);
                $tapsmeatadata['REQUEST_LOG']   =   json_encode($tapsdata);
				
                $storeapitapsmeata              =   apitapsModel::store($tapsmeatadata);
                //$storeapitapsmeata  =   1;
                if($storeapitapsmeata)
                {
                    $tokenkey                   =   $storeapitapsmeata->TOKEN;
                    $tapsdata['TOKEN_KEY']      =   $tokenkey;
                    //update REQUEST_LOG
                    $updatetapsdata     =   [];
                    if(count($decodewomat)>=1)
                    {
                        $dynamicassign  =   ['TAPSCreateArt'=>Config::get('constants.TAPS_CREATE_ART_PATH'),'TAPSRejectArt'=>Config::get('constants.TAPS_REJECT_ART_PATH'),'TAPSCESuccess'=>Config::get('constants.TAPS_CESUCCESS_PATH'),'TAPSSuccess'=>Config::get('constants.TAPS_SUCCESS_PATH'),'TAPSRejection'=>''];
                        $i  =   0;
                        foreach($dynamicassign as $key=>$value)
                        {
                            $inp_rep_arr    =   array( 
                                                            '{TOKEN_KEY}' =>  $tokenkey,
                                                            '{CID}' =>    $metadataID,
                                                        );
                            $tapspath       =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $value );
                            
                            $tapsdata['WOMATAPISignalDetails'][$i]['ServiceUrl']    =   $tapspath;
                            $tapsdata['WOMATAPISignalDetails'][$i]['RequestType']   =   $key;
                            $i++;
                        }
//                        $key    =   2;
//                        foreach($decodewomat as $value)
//                        {                       
////                            $tapsdata['WOMATAPISignalDetails'][$key]['ServiceUrl']    =   ($value->RequestType  ==  'TAPSSuccess'?$tapsaccessserviceurl:$value->ServiceUrl);
//                            $tapsdata['WOMATAPISignalDetails'][$key]['ServiceUrl']    =   $value->ServiceUrl;
//                            $tapsdata['WOMATAPISignalDetails'][$key]['ChapterID']     =   $value->ChapterID;
//                            $tapsdata['WOMATAPISignalDetails'][$key]['RequestType']   =   $value->RequestType;
//                            $tapsdata['WOMATAPISignalDetails'][$key]['RequestID']     =   $value->RequestID;
//                            $tapsdata['WOMATAPISignalDetails'][$key]['RequestStatus'] =   $value->RequestStatus;
//                            $tapsdata['WOMATAPISignalDetails'][$key]['Process']       =   $value->Process;
//                            $key++;   
//                        }
                    }
					 
                    $updatetapsdata['REQUEST_LOG']  =   json_encode($tapsdata);
                    $updatereglog       =   apitapsModel::doupdate($tokenkey,$updatetapsdata);
                    $url    =   $this->getTapsWebUrlBasedOnProductionArea( $jobId ).'iWork_WMSProjectPush.php';
                    $ch     = 	curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
                    if ($tapsdata)
                    {
                        curl_setopt($ch, CURLOPT_POST, 1);
                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($tapsdata));
                    }
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 ;Windows NT 6.1; WOW64; AppleWebKit/537.36 ;KHTML, like Gecko; Chrome/39.0.2171.95 Safari/537.36");
                    $contents       =   curl_exec($ch);
                    $headers        =   curl_getinfo($ch);
                    curl_close($ch);
                    Log::useDailyFiles(storage_path().'/Api/tapsapilog.log');
                    Log::info($contents);
                    if(!empty($contents))
                    {
                        if(strpos($contents,'|') !== false)
                        {
                            $returndata         =   explode('|',$contents);
                            $updatetapsdata     =   [];
                            if($returndata[0]   == "already exist")
                            {
                                $updatetapsdata['STATUS']   =   3;
                                $updatetapsdata['REMARKS']  =   $returndata[0];
                            }
                            else if($returndata[0]  == "success")
                            {
                                $updatetapsdata['STATUS']   =   2;
                                $updatetapsdata['REMARKS']  =   $returndata[0];
                            }
                            else
                            {
                                $updatetapsdata['STATUS']   =   4;
                                $updatetapsdata['REMARKS']  =   $returndata[0];
                            }
                            $updatetapsdata['RESPONSE_LOG']   =   $contents;
                            $token_key          =   (isset($returndata[2])?$returndata[2]:'');
                            //$updatetapsdata['END_TIME'] =   (isset($returndata[3])?$returndata[3]:'');
                            $updatereglog       =   apitapsModel::doupdate($token_key,$updatetapsdata);
                            if($updatereglog)
                            {
                                $result             =   array('result'=>200,'status'=>1,'errMsg'=>'Taps signal has passed successfully');   
                                return response()->json($result);
                            }
                        }
                        $result             =   array('result'=>200,'status'=>0,'errMsg'=>'Taps signal not has been passed successfully try again');   
                        return response()->json($result); 
                    }
                    $result             =   array('result'=>200,'status'=>0,'errMsg'=>'Taps signal not has been passed successfully try again');   
                    return response()->json($result); 
                }
                $result             =   array('result'=>200,'status'=>0,'errMsg'=>'Taps signal not has been passed successfully try again');   
                return response()->json($result); 
            }
            $result         =   array('result'=>404,'errMsg'=>'Job or Metadata not found try again...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {   
print_r( $e->getTraceAsString() );        
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
    
       public function domovenonTaps(Request $request)
    {
        try
        {
            $getinput   =   json_decode($request->getContent(),true);
         
//            if(count($getinput)>=1 && isset($getinput->skipval)){
//                
//            }else{
            $validation             =   Validator::make($getinput, [
                                                'jobId' 	=> 'required|numeric',
                                                'metadataId' 	=> 'required',
                                                'tapsstype' 	=> 'required|numeric',
                                                'ChapterNo' 	=> 'required',
                                                'ChapterTitle' 	=> 'required',
                                                'roundid' 	=> 'required|numeric'
                                        ]);
            
                
                if ($validation->fails())
                {
                    $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                    return response()->json($result);
                }
//            }
                
            $userId             =   (!empty(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID'));
            $jobId              =   $getinput['jobId'];
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            if (empty($bookdata->WORKFLOW_TYPE)) {
                $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Workflow is not configured');   
                return response()->json($result);
            }
            
            $metadataID         =   $getinput['metadataId'];
            $chapternoreq       =   $getinput['ChapterNo'];
			$receivedRoundId	=	$getinput['roundid'];
            $getchapters        =   taskLevelMetadataModel::getMetadatadetailsChapter($metadataID);
            $chapterlist        =   $getchapters->pluck('CHAPTER_NO')->toArray(); 
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            
            $artCompletion      =   $this->artCompletedValidation($getchapters,$request->all());
            if ($artCompletion == '0') {
                $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Art Input analysis not completed');   
                return response()->json($result);
            }
            
           
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($chapterlist)>=1)
            {
                $hostserver     =   $getlocationftp['HOST'];
                $hostusername   =   $getlocationftp['FTP_USERNAME'];
                $hostpassword   =   $getlocationftp['FTP_PASSWORD'];
                $hostpath       =   $getlocationftp['HOST_PATH'];
                $hostuserfieserver      =   $getlocationftp['FTP_USERNAME'];
                $hostpasswordfieserver  =   $getlocationftp['FTP_PASSWORD'];
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                $noofquality        =   (count($getchapters)>=1?$getchapters[0]->NO_MSP:0);
                $ftp_root_dir       =   Config::get('constants.SPICAST_BACKGROUND_FILE').'/';
                $open_path          =   $ftp_root_dir.$bookid.'/'.$chapternoreq.'/images/';   
		
                $serverDirallFiles  =   $ftpObj->allFiles($open_path);
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $getartpaths        =   "";
                $getchapterpathname =   "";
                //get chapter path
                
                if($getinput['roundid'] == '114'){
                    $chapterpathurl     =   $getlocationftp['HOST_PATH'].Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.SPLIT').'/'.$getinput['ChapterNo'].'/'; 
                    $roundname          =   Config::get('constants.ROUND_NAME.114');
                    $chapterreturnurl   =   Config::get('constants.CHENNAI_PRODUCTION_SERVER').Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.SPLIT').'/'.$chapternoreq;
                    $getjobsheetfile    =   Config::get('serverconstants.COMMON_JOBSHEET_PATH');
					
                }else{
                    $chapterpathurl     =   $getlocationftp['HOST_PATH'].Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.COPY_EDITING').'/'.$chapternoreq.'/';   
                    $roundname          =   Config::get('constants.ROUND_NAME.116');
                    $chapterreturnurl   =   Config::get('constants.CHENNAI_PRODUCTION_SERVER').Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.COPY_EDITING').'/'.$chapternoreq;
                    $getjobsheetfile    =   Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                }
            
                $getchapterdirfiles =   $ftpObj->allFiles($chapterpathurl);
               

                $exntcheck          =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                
                
               // $getuserid          =   Session::get('users')['emp_id'];
                
               
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    $roundname,
                                            '{CID}' =>    $chapternoreq
                                         );

                $cmn_obj            =   new CommonMethodsController();
                $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $getjobsheetfile );
                $cucuserworkfolder  =   $hostpath.$rawpath;   
				
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                $jobsheetFilePath   =   "";
                if(!empty($cucDirFiles)) 
                {
                    $xmlFilePath    =   "";
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $jobsheetFilePath   =   $hostserver.$ftp_root_dir.$serverDirFile;
                        }
                    }
                }
              
					foreach($getchapterdirfiles as $key=>$jsonvalue)
					{
						if(strpos($jsonvalue,'/') !== 	false)
						{
							$spiltchapter       =   substr(strrchr($jsonvalue, "/"), 1);
							$removedocchapter   =   strchr($jsonvalue, "/");
							$splitname          =   explode('.',$spiltchapter);
	//                        if(in_array($splitname[1],$exntcheck) && in_array($splitname[0],$chapterlist))
							if(in_array($splitname[1],$exntcheck))
							{
								$getchapterpathname     =   $chapterreturnurl;
							}
						}
					}
			
				$getchapterpathname     =   $chapterreturnurl;
			
                if(!empty($getchapterpathname))
                {
                    $getchapterpathname     =   "\\\\".$getchapterpathname;
                    $getchapterpathname     =   str_replace( '/' ,'\\', $getchapterpathname );
                }
                
                if(!empty($jobsheetFilePath))
                {
                    $jobsheetFilePath       =   "\\\\".$jobsheetFilePath;
                    $jobsheetFilePath       =   str_replace( '/' ,'\\', $jobsheetFilePath );
                }
                
                if(count($serverDirallFiles)>=1)
                {
                    $getartpaths    =   $hostserver.$ftp_root_dir.$open_path;

                }
                if(!empty($getartpaths))
                {
                    $getartpaths       =   "\\\\".$getartpaths;
                    $getartpaths       =   str_replace( '/' ,'\\', $getartpaths );
                }
                $tapsdata['BookDetails']['BOOK_ID']         =   ($bookdata->BOOK_ID == null?'':$bookdata->BOOK_ID);
                $tapsdata['BookDetails']['PROJECT_NAME']    =   ($bookdata->PROJECT_NAME == null?'':$bookdata->PROJECT_NAME);
                $tapsdata['BookDetails']['ISSN_ONLINE']     =   ($bookdata->ISSN_ONLINE == null?'':$bookdata->ISSN_ONLINE);
                $tapsdata['BookDetails']['AUTHOR_NAME']     =   ($bookdata->AUTHOR_NAME == null?'':$bookdata->AUTHOR_NAME);
                $tapsdata['BookDetails']['TOC_LEVELS']      =   ($bookdata->TOC_LEVELS == null?'':$bookdata->TOC_LEVELS);
                $tapsdata['BookDetails']['COPY_EDITING_LEVEL']      =   ($bookdata->COPY_EDITING_LEVEL == null?'':$bookdata->COPY_EDITING_LEVEL);
                $tapsdata['BookDetails']['PURCHASE_ORDER_NUMBER']   =   ($bookdata->PURCHASE_ORDER_NUMBER == null?'':$bookdata->PURCHASE_ORDER_NUMBER);
                $tapsdata['BookDetails']['AM_NAME']         =   ($bookdata->AM_NAME == null?'':$bookdata->AM_NAME);
                $tapsdata['BookDetails']['PM_NAME']         =   ($bookdata->PM_NAME == null?'':$bookdata->PM_NAME);
                $tapsdata['BookDetails']['NO_PAGES']        =   ($bookdata->NO_PAGES == null?'':$bookdata->NO_PAGES);
                $tapsdata['BookDetails']['NO_PART_COUNT']   =   ($bookdata->NO_PART_COUNT == null?'':$bookdata->NO_PART_COUNT);
                $getlayout                                  =   spicastProfileModel::where('SPICAST_ID',$bookdata->LAYOUT_PROFILE)->first();
                $tapsdata['BookDetails']['LAYOUT_PROFILE']  =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
                $tapsdata['BookDetails']['LAYOUT']          =   ($bookdata->LAYOUT == null?'':$bookdata->LAYOUT);
                $tapsdata['BookDetails']['PROFILE']         =   ($bookdata->PROFILE == null?'':$bookdata->PROFILE);
                $tapsdata['BookDetails']['CE_REQUIRED']     =   ($bookdata->CE_REQUIRED == null?'':$bookdata->CE_REQUIRED);
                $tapsdata['BookDetails']['PUBLISHER_NAME']  =   ($bookdata->PUBLISHER_NAME == null?'':$bookdata->PUBLISHER_NAME);
                $tapsdata['BookDetails']['JOB_TITLE']       =   ($bookdata->JOB_TITLE == null?'':$bookdata->JOB_TITLE);
                $tapsdata['BookDetails']['ISSN_PRINT']      =   ($bookdata->ISSN_PRINT == null?'':$bookdata->ISSN_PRINT);
                $tapsdata['BookDetails']['PRODUCTION_EDITOR']   =   ($bookdata->PRODUCTION_EDITOR == null?'':$bookdata->PRODUCTION_EDITOR);
                $tapsdata['BookDetails']['PE_MAIL']         =   ($bookdata->PE_MAIL == null?'':$bookdata->PE_MAIL);
                $tapsdata['BookDetails']['FORMAT_TRIM_SIZE']=   ($bookdata->FORMAT_TRIM_SIZE == null?'':$bookdata->FORMAT_TRIM_SIZE);
                $tapsdata['BookDetails']['JOB_TYPE']        =   ($bookdata->JOB_TYPE == null?'':$bookdata->JOB_TYPE);
                $tapsdata['BookDetails']['CATEGORY']        =   "";
                $tapsdata['BookDetails']['PLATFORM']        =   ($bookdata->APPLICATION == null?'':$bookdata->APPLICATION);
                $tapsdata['BookDetails']['NO_OF_IMAGES']    =   ($bookdata->NO_OF_IMAGES == null?'':$bookdata->NO_OF_IMAGES);
                $tapsdata['BookDetails']['NO_CHAPTER_COUNT']=   ($bookdata->NO_CHAPTER_COUNT == null?'':$bookdata->NO_CHAPTER_COUNT);
                $tapsdata['BookDetails']['ABSTRACT_IN_DOCUMENT_LANGUAGE']   =   ($bookdata->NO_CHAPTER_COUNT == null?'':$bookdata->ABSTRACT_IN_DOCUMENT_LANGUAGE);
                $tapsdata['BookDetails']['START_PAGE']                      =   ($bookdata->START_PAGE == null?'':$bookdata->START_PAGE);
                $tapsdata['BookDetails']['COLOR_IMAGES_IN_PRINT']           =   ($bookdata->COLOR_IMAGES_IN_PRINT == null?'':$bookdata->COLOR_IMAGES_IN_PRINT);
                $tapsdata['BookDetails']['PUBLISHER_IMPRINT_NAME']          =   ($bookdata->PUBLISHER_IMPRINT_NAME == null?'':$bookdata->PUBLISHER_IMPRINT_NAME);
                $tapsdata['BookDetails']['BOOK_SUB_TITLE']  =   ($bookdata->BOOK_SUB_TITLE == null?'':$bookdata->BOOK_SUB_TITLE);
                $tapsdata['BookDetails']['COPYRIGHT_YEAR']  =   ($bookdata->COPYRIGHT_YEAR == null?'':$bookdata->COPYRIGHT_YEAR);
                $tapsdata['BookDetails']['PE_NAME']         =   ($bookdata->PE_NAME == null?'':$bookdata->PE_NAME);
                $tapsdata['BookDetails']['NUMBERING_DEPTH'] =   ($bookdata->NUMBERING_DEPTH == null?'':$bookdata->NUMBERING_DEPTH);
                $tapsdata['BookDetails']['BOOK_MULTI_VOLUME_COUNT'] =   ($bookdata->BOOK_MULTI_VOLUME_COUNT == null?'':$bookdata->BOOK_MULTI_VOLUME_COUNT);
                $tapsdata['BookDetails']['LOCATION']                =   ($bookdata->LOCATION == null?'':$bookdata->LOCATION);
                $tapsdata['BookDetails']['LOCATION_NAME']           =   ($bookdata->LOCATION_NAME == null?'':$bookdata->LOCATION_NAME);
                $tapsdata['BookDetails']['BLACK_WHITE_IMAGES']      =   ($bookdata->BLACK_WHITE_IMAGES == null?'':$bookdata->BLACK_WHITE_IMAGES);
                $tapsdata['BookDetails']['NO_APAGE_COUNT']          =   ($bookdata->NO_APAGE_COUNT == null?'':$bookdata->NO_APAGE_COUNT);
                $tapsdata['BookDetails']['CLASSIFICATION_STYLE']    =   ($bookdata->CLASSIFICATION_STYLE == null?'':$bookdata->CLASSIFICATION_STYLE);
                $tapsdata['BookDetails']['RUNNING_HEAD']            =   ($bookdata->RUNNING_HEAD == null?'':$bookdata->RUNNING_HEAD);
                $tapsdata['BookDetails']['LAYOUT_COLOR_COUNT']      =   ($bookdata->LAYOUT_COLOR_COUNT == null?'':$bookdata->LAYOUT_COLOR_COUNT);
                $tapsdata['BookDetails']['PUBLISHER_LOCATION']      =   ($bookdata->PUBLISHER_LOCATION == null?'':$bookdata->PUBLISHER_LOCATION);
                $tapsdata['BookDetails']['DOI']                     =   ($bookdata->DOI == null?'':$bookdata->DOI);
                $tapsdata['BookDetails']['COPYRIGHT_HOLDER_NAME']   =   ($bookdata->COPYRIGHT_HOLDER_NAME == null?'':$bookdata->COPYRIGHT_HOLDER_NAME);
                $tapsdata['BookDetails']['LANGUAGE']                =   ($bookdata->LANGUAGE == null?'':$bookdata->LANGUAGE);
                $tapsdata['BookDetails']['CONTAINS_ESM']            =   ($bookdata->CONTAINS_ESM == null?'':$bookdata->CONTAINS_ESM);
                $tapsdata['BookDetails']['VOLUME_NO']               =   "";
                $tapsdata['BookDetails']['PRODUCTION_CLASSIFICATION']   =   ($bookdata->PRODUCTION_CLASSIFICATION == null?'':$bookdata->PRODUCTION_CLASSIFICATION);
                $tapsdata['BookDetails']['APPLICATION']             =   ($bookdata->APPLICATION == null?'':$bookdata->APPLICATION);
                $noimages   =   ($bookdata->NO_OF_IMAGES == null?'':$bookdata->NO_OF_IMAGES);
                $blackimages   =   ($bookdata->BLACK_WHITE_IMAGES == null?'':$bookdata->BLACK_WHITE_IMAGES);
                $tapsdata['BookDetails']['COLOUR_IMAGE']            =   $noimages.' - '.$blackimages;
                $tapsdata['BookDetails']['AUTHOR_INFORMATION_STYLE']=   ($bookdata->AUTHOR_INFORMATION_STYLE == null?'':$bookdata->AUTHOR_INFORMATION_STYLE);
                $tapsdata['BookDetails']['BIBLIOGRAPHY_STYLE']      =   ($bookdata->BIBLIOGRAPHY_STYLE == null?'':$bookdata->BIBLIOGRAPHY_STYLE);
                $tapsdata['BookDetails']['LOGO_ON_FIRST_PAGE']      =   ($bookdata->LOGO_ON_FIRST_PAGE == null?'':$bookdata->LOGO_ON_FIRST_PAGE);
                $tapsdata['BookDetails']['PRINTING_COLOR_COUNT']    =   ($bookdata->PRINTING_COLOR_COUNT == null?'':$bookdata->PRINTING_COLOR_COUNT);
                $tapsdata['BookDetails']['IS_PAR']                  =   ($bookdata->IS_PAR == null?'':$bookdata->IS_PAR);
                $tapsdata['BookDetails']['PM_EMPLOYEE_ID']          =   ($bookdata->PM_EMPLOYEE_ID == null?'':$bookdata->PM_EMPLOYEE_ID);
                $tapsdata['BookDetails']['AM_EMPLOYEE_ID']          =   ($bookdata->AM_EMPLOYEE_ID == null?'':$bookdata->AM_EMPLOYEE_ID);
				
				$embb												=	'';
				
				if(!empty($bookdata->EMBBED_TYPE)){
					
					if($bookdata->EMBBED_TYPE == '1'){
						$embb			=	'embedded';
					}elseif($bookdata->EMBBED_TYPE == '2'){
						$embb			=	'non-embedded';
					}
				}
				
				$productionLocation		=   '';
                                $defaultlocation                =   (!empty($bookdata->TAPS_LOCATION)?$bookdata->TAPS_LOCATION:$bookdata->LOCATION);
				if(!empty($defaultlocation)){
					$sql2    		=   "select *from production_area_location as ap where ap.ID = '$defaultlocation'";
			
					$location		=   DB::select( $sql2 );
					$locationDetails	=   $location['0'];		
					$productionLocation     =   $locationDetails->LOCATION_NAME;
				}
                                
				$receiptStatus		=	'';
		if($receivedRoundId  == '116'){
		$sql3    			=	"select *from api_client_acknowledgement as ap where ap.BOOK_ID = '$bookid' and ap.ROUND = '$receivedRoundId' and ap.METADATA_ID = '$metadataID' and ap.PROCESS_TYPE_DIFF = 'RECEIPT' order by ap.ID desc limit 1";
		}else{
			$sql3    			=	"select *from api_client_acknowledgement as ap where ap.BOOK_ID = '$bookid' and ap.ROUND = '$receivedRoundId' and ap.PROCESS_TYPE_DIFF = 'RECEIPT' order by ap.ID desc limit 1";
		}
		
				$receipt			=	DB::select( $sql3 );
				
				if(!empty($receipt)){
					$receiptDetail		=	$receipt['0']->STATUS;
					if($receiptDetail == '2'){
						$receiptStatus  = 'success';
					}else if($receiptDetail == '3'){
						$receiptStatus  = 'redo';
					}else{
						$receiptStatus  = 'in progress';
					}
				}
				
				
				$tapsdata['BookDetails']['EMBEDDED_TYPE']        =   $embb;
				$tapsdata['BookDetails']['LOCATION_NAME']        =   $productionLocation;
				$tapsdata['BookDetails']['RECEIPT_STATUS']       =   $receiptStatus;
				
                
                $deadline_array     =   json_decode( $bookdata->SERIES_INFORMATION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['SERIESEISSN']     =   ($deadline_array[0]['SerieId'] == null?'':$deadline_array[0]['SerieId']);
                    $tapsdata['BookDetails']['SERIESTITLE']     =   ($deadline_array[0]['SeriesTitle'] == null?'':$deadline_array[0]['SeriesTitle']);
                    $tapsdata['BookDetails']['SERIESPRINTISSN'] =   ($deadline_array[0]['SeriesEISSN'] == null?'':$deadline_array[0]['SeriesEISSN']);
                    $tapsdata['BookDetails']['SERIESID']        =   ($deadline_array[0]['SerieId'] == null?'':$deadline_array[0]['SerieId']);
                }
                else
                {
                    $tapsdata['BookDetails']['SERIESEISSN']     =   "";
                    $tapsdata['BookDetails']['SERIESTITLE']     =   "";
                    $tapsdata['BookDetails']['SERIESPRINTISSN'] =   "";
                    $tapsdata['BookDetails']['SERIESID']        =   "";
                }
                
                $deadline_array     =   json_decode( $bookdata->STAGE_DEADLINES_COLLECTION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['DEADLINE']['STAGE5']         =   ($deadline_array['S5'] == null?'':$deadline_array['S5']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE50']        =   ($deadline_array['S50'] == null?'':$deadline_array['S50']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE200']       =   ($deadline_array['S200'] == null?'':$deadline_array['S200']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE300']       =   ($deadline_array['S300'] == null?'':$deadline_array['S300']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE600']       =   ($deadline_array['S600'] == null?'':$deadline_array['S600']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE650']       =   ($deadline_array['S650'] == null?'':$deadline_array['S650']);
                }
                else
                {
                    $tapsdata['BookDetails']['DEADLINE']['STAGE5']         =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE50']        =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE200']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE300']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE600']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE650']       =   "";
                }
                
                $deadline_array     =   json_decode( $bookdata->STAGE_RECEIVED_COLLECTION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE5']        =   ($deadline_array['S5'] == null?'':$deadline_array['S5']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE50']       =   ($deadline_array['S50'] == null?'':$deadline_array['S50']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE200']      =   ($deadline_array['S200'] == null?'':$deadline_array['S200']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE300']      =   ($deadline_array['S300'] == null?'':$deadline_array['S300']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE600']      =   ($deadline_array['S600'] == null?'':$deadline_array['S600']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE650']      =   ($deadline_array['S650'] == null?'':$deadline_array['S650']);
                }
                else
                {
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE5']        =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE50']       =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE200']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE300']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE600']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE650']      =   "";
                }
                
                $tapsdata['ChapterDetails']['ChapterID']        =   $metadataID;
                $tapsdata['ChapterDetails']['ChapterNo']        =   $getinput['ChapterNo'];
                $tapsdata['ChapterDetails']['ChapterTitle']     =   $getinput['ChapterTitle'];
                $tapsdata['ChapterDetails']['ChapterPath']      =   $getchapterpathname;
                $tapsdata['ChapterDetails']['ArtPath']          =   $getartpaths;
                $artpath            =   Config::get('constants.SPLIT_DESTINATION_PATH');
                $artfilename        =   Config::get('constants.ART_SOURCE_PATHS');
                $hostpath           =   str_replace( '/' ,'', $hostpath );
                $raw_path           =   $hostserver.$ftp_root_dir.$hostpath.'/'.Config::get('constants.SPLIT_SOURCE_PATH');                    
                 $raw_path           =   str_replace( 'BOOK_ID' ,$bookid, $raw_path );
                $raw_path           =   str_replace( 'ROUND_NAME' ,'', $raw_path );
                $raw_path           =   "\\\\".$raw_path;
                $originalrawpath    =   str_replace( '/' ,'\\', $raw_path );
                $tapsdata['RawPath']=   $originalrawpath;
                $tapsdata['JobsheetPath']   =   $jobsheetFilePath;
                $tapsdata['processType']    =   ($getinput['tapsstype'] == 1 ?'TAPS':'non-TAPS');
                $roundID            =   $getinput['roundid'];
                //taps meta info store
				
                $tapsmeatadata                  =   [];
                $tapsmeatadata['ROUND']         =   $roundID;
                $tapsmeatadata['METADATA_ID']   =   $metadataID;
                $tapsmeatadata['JOB_ID']        =   $jobId;
                $tapsmeatadata['START_TIME']    =   Carbon::now();
                $tapsmeatadata['CREATED_DATE']  =   Carbon::now();
                $tapsmeatadata['CREATED_BY']    =   $userId;
                $tapsmeatadata['REQUEST_LOG']   =   json_encode($tapsdata);
                $tapsmeatadata['STATUS']        =   '0';
                $tapsmeatadata['WOMAT_TYPE']    =   $getinput['tapsstype'];
                               
                $storetapsmeata                 =   tapsmetadataModel::store($tapsmeatadata);
                if($storetapsmeata)
                {
                    $tapsdata['TOKEN_KEY']      =   $storetapsmeata->TOKEN;
                    $updatetapsdata['REQUEST_LOG']  =   json_encode($tapsdata);
                    $updatereglog       =   tapsmetadataModel::doupdate($tapsdata['TOKEN_KEY'],$updatetapsdata);
//                    $sendsingal         =   $this->doSendtapssingnal($tapsdata,$tapsdata['processType'],$jobId,$metadataID,$noofquality);
                    //$url                =   'http://172.24.148.41:9119/clsWorkflowCoordinator.svc/UpdateMetadataBookInfo';
                    switch($defaultlocation){
                        case    ($defaultlocation == 1 || $defaultlocation == 3):
                            $url        =   Config::get('constants.WOMAT.WOMAT_UPDATE_METADATA_BOOKINFO_SIGNAL');
                        break;
                        case  2:
                            $url        =   Config::get('constants.WOMAT.WOMAT_UPDATE_METADATA_BOOKINFO_SIGNAL');
                        break;
                        default:
                            $url        =   Config::get('constants.WOMAT.WOMAT_UPDATE_METADATA_BOOKINFO_SIGNAL');
                        break;
                    }
                    
                    $getToolresponse    =   app('App\Http\Controllers\CommonMethodsController')->PostcUrlExecution($tapsdata,$url,0);
                    //update metadata info
                    $updatedata         =   [];
                    $updatedata['PRODUCTION_SYSTEM']    =   $getinput['tapsstype'];
                    $updateinfo         =   metadataInfoModel::where('METADATA_ID',$metadataID)->update($updatedata);
					if($roundID == '114' && $getinput['tapsstype'] == '3'){
					$tasklevelmetadata_query        =	"update api_download set IS_ACTIVE = 0 where BOOK_ID = '$bookdata->BOOK_ID' AND ROUND = 114";
                    $tsk_crn_upd    				=       DB::update( $tasklevelmetadata_query );
					
					}else{
						if( $getinput['tapsstype'] == '3' ){
							$tasklevelmetadata_query        =	"update api_download set IS_ACTIVE = 0 where BOOK_ID = '$bookdata->BOOK_ID' AND ROUND = $roundID AND METADATA_ID=$metadataID ";
							$tsk_crn_upd    				=       DB::update( $tasklevelmetadata_query );
						}
					}
				
					
                    $result             =   array('result'=>200,'status'=>1,'errMsg'=>'Taps signal has passed successfully');   
                    return response()->json($result);
                }
                $result             =   array('result'=>200,'status'=>0,'errMsg'=>'Taps signal not has been passed successfully try again');   
                return response()->json($result);        
            }
            $result         =   array('result'=>200,'status'=>0,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result,404);
        }
    }

    
    
    public function artCompletedValidation($chapterDetails, $response){
        $artCompleted   = '0'; 
        if(count($chapterDetails) >= 1){
        $metadataId     =   $chapterDetails['0']->METADATA_ID;
        
       if($chapterDetails['0']->FIGURE_COUNT >= 1 ){
            $artCompleted  = '1';
        }else{
           $sql            =  'select * from job_time_sheet jts2 WHERE jts2.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION').' and  jts2.ROUND_ID IN ( '.\Config::get('constants.ROUND_ID.S200').','.\Config::get('constants.ROUND_ID.S5').' ) and METADATA_ID = '.$metadataId.' ORDER BY jts2.JOB_TIME_SHEET_ID DESC LIMIT 1';            
           $response       =  DB::select( $sql );
           if(!empty($response)){
              if($response['0']->STATUS == '2'){
                  $artCompleted  = '1';
                } 
                }
            }
        }
     
        return $artCompleted;
    }
    
public function dosfiftymovenonTaps(Request $request)
    {
        try
        { 
				
	         $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric',
                                                'tapstype' 	=> 'required|numeric',
                                                'roundid' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                return response()->json($result);
            }
            
            
            $jobId              =   $request->input('jobId');
			
            $bookdata           =   jobModel::getjobInfodetails($jobId);
			$bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
			
			$sql    			=	"select *from api_download as ap where ap.BOOK_ID = '$bookid' and ap.ROUND = '104' order by ap.ID desc limit 1";
			
			$download			=	DB::select( $sql );
			$downloadDetail		=	$download['0'];			
			
            $tapsdata           =   [];
          
            $tapsreqtype        =   $request->input('tapstype');
            $roundID            =   $request->input('roundid');
            if($tapsreqtype     ==  1)
            {
                //taps meta info store
                $tapsmeatadata                  =   [];
                $tapsmeatadata['ROUND']         =   $roundID;
                $tapsmeatadata['METADATA_ID']   =   '';
                $tapsmeatadata['JOB_ID']        =   $jobId;
                $tapsmeatadata['START_TIME']    =   Carbon::now();
                $tapsmeatadata['CREATED_DATE']  =   Carbon::now();
                $tapsmeatadata['END_TIME']      =   Carbon::now();
                $tapsmeatadata['CREATED_BY']    =   Session::get('users')['user_id'];
                $tapsmeatadata['REQUEST_LOG']   =   json_encode($tapsdata);
                $tapsmeatadata['STATUS']        =   '1';
                $tapsmeatadata['WOMAT_TYPE']    =   $tapsreqtype;
                $storetapsmeata                 =   tapsmetadataModel::store($tapsmeatadata);
//                jobInfoModel::where('JOB_ID',$jobId)->update(['PLATFORM_TYPE'=>$tapsreqtype]);
                $result         =   array('result'=>200,'status'=>2,'errMsg'=>'Successfully platform has been changed');   
                return response()->json($result);
            }
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
			  if( empty( $getlocationftp ) ){
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
                $locationFlag       =		0;
                
                $getlocationftp->FTP_PASSWORD   =   \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
			}
		
        if(is_object($getlocationftp)){
            $getlocationftp   =    (array) $getlocationftp;
		}
     			
			
            if(count($getlocationftp)>=1 && count($bookdata)>=1)
            {
                $hostserver     =   $getlocationftp['HOST'];
                $hostusername   =   $getlocationftp['FTP_USERNAME'];
                $hostpassword   =   $getlocationftp['FTP_PASSWORD'];
                $hostpath       =   $getlocationftp['HOST_PATH'];
                $hostuserfieserver      =   $getlocationftp['FTP_USERNAME'];
                $hostpasswordfieserver  =   $getlocationftp['FTP_PASSWORD'];
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                $noofquality        =   0;
                $ftp_root_dir       =   Config::get('constants.SPICAST_BACKGROUND_FILE').'/';
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $getartpaths        =   "";
                $getchapterpathname =   "";
                $exntcheck          =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                
                $roundname          =   Config::get('constants.ROUND_NAME.104');
                $getuserid          =   Session::get('users')['emp_id'];
                $getjobsheetfile    =   Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                $tapsdata['BookDetails']['BOOK_ID']         =   ($bookdata->BOOK_ID == null?'':$bookdata->BOOK_ID);
                $tapsdata['BookDetails']['PROJECT_NAME']    =   ($bookdata->PROJECT_NAME == null?'':$bookdata->PROJECT_NAME);
                $tapsdata['BookDetails']['ISSN_ONLINE']     =   ($bookdata->ISSN_ONLINE == null?'':$bookdata->ISSN_ONLINE);
                $tapsdata['BookDetails']['AUTHOR_NAME']     =   ($bookdata->AUTHOR_NAME == null?'':$bookdata->AUTHOR_NAME);
                $tapsdata['BookDetails']['TOC_LEVELS']      =   ($bookdata->TOC_LEVELS == null?'':$bookdata->TOC_LEVELS);
                $tapsdata['BookDetails']['COPY_EDITING_LEVEL']      =   ($bookdata->COPY_EDITING_LEVEL == null?'':$bookdata->COPY_EDITING_LEVEL);
                $tapsdata['BookDetails']['PURCHASE_ORDER_NUMBER']   =   ($bookdata->PURCHASE_ORDER_NUMBER == null?'':$bookdata->PURCHASE_ORDER_NUMBER);
                $tapsdata['BookDetails']['AM_NAME']         =   ($bookdata->AM_NAME == null?'':$bookdata->AM_NAME);
                $tapsdata['BookDetails']['PM_NAME']         =   ($bookdata->PM_NAME == null?'':$bookdata->PM_NAME);
                $tapsdata['BookDetails']['NO_PAGES']        =   ($bookdata->NO_PAGES == null?'':$bookdata->NO_PAGES);
                $tapsdata['BookDetails']['NO_PART_COUNT']   =   ($bookdata->NO_PART_COUNT == null?'':$bookdata->NO_PART_COUNT);
                $getlayout                                  =   spicastProfileModel::where('SPICAST_ID',$bookdata->LAYOUT_PROFILE)->first();
                $tapsdata['BookDetails']['LAYOUT_PROFILE']  =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
                $tapsdata['BookDetails']['LAYOUT']          =   ($bookdata->LAYOUT == null?'':$bookdata->LAYOUT);
                $tapsdata['BookDetails']['PROFILE']         =   ($bookdata->PROFILE == null?'':$bookdata->PROFILE);
                $tapsdata['BookDetails']['CE_REQUIRED']     =   ($bookdata->CE_REQUIRED == null?'':$bookdata->CE_REQUIRED);
                $tapsdata['BookDetails']['PUBLISHER_NAME']  =   ($bookdata->PUBLISHER_NAME == null?'':$bookdata->PUBLISHER_NAME);
                $tapsdata['BookDetails']['JOB_TITLE']       =   ($bookdata->JOB_TITLE == null?'':$bookdata->JOB_TITLE);
                $tapsdata['BookDetails']['ISSN_PRINT']      =   ($bookdata->ISSN_PRINT == null?'':$bookdata->ISSN_PRINT);
                $tapsdata['BookDetails']['PRODUCTION_EDITOR']   =   ($bookdata->PRODUCTION_EDITOR == null?'':$bookdata->PRODUCTION_EDITOR);
                $tapsdata['BookDetails']['PE_MAIL']         =   ($bookdata->PE_MAIL == null?'':$bookdata->PE_MAIL);
                $tapsdata['BookDetails']['FORMAT_TRIM_SIZE']=   ($bookdata->FORMAT_TRIM_SIZE == null?'':$bookdata->FORMAT_TRIM_SIZE);
                $tapsdata['BookDetails']['JOB_TYPE']        =   ($bookdata->JOB_TYPE == null?'':$bookdata->JOB_TYPE);
                $tapsdata['BookDetails']['CATEGORY']        =   "";
                $tapsdata['BookDetails']['PLATFORM']        =   ($bookdata->APPLICATION == null?'':$bookdata->APPLICATION);
                $tapsdata['BookDetails']['NO_OF_IMAGES']    =   ($bookdata->NO_OF_IMAGES == null?'':$bookdata->NO_OF_IMAGES);
                $tapsdata['BookDetails']['NO_CHAPTER_COUNT']=   ($bookdata->NO_CHAPTER_COUNT == null?'':$bookdata->NO_CHAPTER_COUNT);
                $tapsdata['BookDetails']['ABSTRACT_IN_DOCUMENT_LANGUAGE']   =   ($bookdata->NO_CHAPTER_COUNT == null?'':$bookdata->ABSTRACT_IN_DOCUMENT_LANGUAGE);
                $tapsdata['BookDetails']['START_PAGE']                      =   ($bookdata->START_PAGE == null?'':$bookdata->START_PAGE);
                $tapsdata['BookDetails']['COLOR_IMAGES_IN_PRINT']           =   ($bookdata->COLOR_IMAGES_IN_PRINT == null?'':$bookdata->COLOR_IMAGES_IN_PRINT);
                $tapsdata['BookDetails']['PUBLISHER_IMPRINT_NAME']          =   ($bookdata->PUBLISHER_IMPRINT_NAME == null?'':$bookdata->PUBLISHER_IMPRINT_NAME);
                $tapsdata['BookDetails']['BOOK_SUB_TITLE']  =   ($bookdata->BOOK_SUB_TITLE == null?'':$bookdata->BOOK_SUB_TITLE);
                $tapsdata['BookDetails']['COPYRIGHT_YEAR']  =   ($bookdata->COPYRIGHT_YEAR == null?'':$bookdata->COPYRIGHT_YEAR);
                $tapsdata['BookDetails']['PE_NAME']         =   ($bookdata->PE_NAME == null?'':$bookdata->PE_NAME);
                $tapsdata['BookDetails']['NUMBERING_DEPTH'] =   ($bookdata->NUMBERING_DEPTH == null?'':$bookdata->NUMBERING_DEPTH);
                $tapsdata['BookDetails']['BOOK_MULTI_VOLUME_COUNT'] =   ($bookdata->BOOK_MULTI_VOLUME_COUNT == null?'':$bookdata->BOOK_MULTI_VOLUME_COUNT);
                $tapsdata['BookDetails']['LOCATION']                =   ($bookdata->LOCATION == null?'':$bookdata->LOCATION);
                $tapsdata['BookDetails']['LOCATION_NAME']           =   ($bookdata->LOCATION_NAME == null?'':$bookdata->LOCATION_NAME);
                $tapsdata['BookDetails']['BLACK_WHITE_IMAGES']      =   ($bookdata->BLACK_WHITE_IMAGES == null?'':$bookdata->BLACK_WHITE_IMAGES);
                $tapsdata['BookDetails']['NO_APAGE_COUNT']          =   ($bookdata->NO_APAGE_COUNT == null?'':$bookdata->NO_APAGE_COUNT);
                $tapsdata['BookDetails']['CLASSIFICATION_STYLE']    =   ($bookdata->CLASSIFICATION_STYLE == null?'':$bookdata->CLASSIFICATION_STYLE);
                $tapsdata['BookDetails']['RUNNING_HEAD']            =   ($bookdata->RUNNING_HEAD == null?'':$bookdata->RUNNING_HEAD);
                $tapsdata['BookDetails']['LAYOUT_COLOR_COUNT']      =   ($bookdata->LAYOUT_COLOR_COUNT == null?'':$bookdata->LAYOUT_COLOR_COUNT);
                $tapsdata['BookDetails']['PUBLISHER_LOCATION']      =   ($bookdata->PUBLISHER_LOCATION == null?'':$bookdata->PUBLISHER_LOCATION);
                $tapsdata['BookDetails']['DOI']                     =   ($bookdata->DOI == null?'':$bookdata->DOI);
                $tapsdata['BookDetails']['COPYRIGHT_HOLDER_NAME']   =   ($bookdata->COPYRIGHT_HOLDER_NAME == null?'':$bookdata->COPYRIGHT_HOLDER_NAME);
                $tapsdata['BookDetails']['LANGUAGE']                =   ($bookdata->LANGUAGE == null?'':$bookdata->LANGUAGE);
                $tapsdata['BookDetails']['CONTAINS_ESM']            =   ($bookdata->CONTAINS_ESM == null?'':$bookdata->CONTAINS_ESM);
                $tapsdata['BookDetails']['VOLUME_NO']               =   "";
                $tapsdata['BookDetails']['PRODUCTION_CLASSIFICATION']   =   ($bookdata->PRODUCTION_CLASSIFICATION == null?'':$bookdata->PRODUCTION_CLASSIFICATION);
                $tapsdata['BookDetails']['APPLICATION']             =   ($bookdata->APPLICATION == null?'':$bookdata->APPLICATION);
                $noimages   =   ($bookdata->NO_OF_IMAGES == null?'':$bookdata->NO_OF_IMAGES);
                $blackimages   =   ($bookdata->BLACK_WHITE_IMAGES == null?'':$bookdata->BLACK_WHITE_IMAGES);
                $tapsdata['BookDetails']['COLOUR_IMAGE']            =   $noimages.' - '.$blackimages;
                $tapsdata['BookDetails']['AUTHOR_INFORMATION_STYLE']=   ($bookdata->AUTHOR_INFORMATION_STYLE == null?'':$bookdata->AUTHOR_INFORMATION_STYLE);
                $tapsdata['BookDetails']['BIBLIOGRAPHY_STYLE']      =   ($bookdata->BIBLIOGRAPHY_STYLE == null?'':$bookdata->BIBLIOGRAPHY_STYLE);
                $tapsdata['BookDetails']['LOGO_ON_FIRST_PAGE']      =   ($bookdata->LOGO_ON_FIRST_PAGE == null?'':$bookdata->LOGO_ON_FIRST_PAGE);
                $tapsdata['BookDetails']['PRINTING_COLOR_COUNT']    =   ($bookdata->PRINTING_COLOR_COUNT == null?'':$bookdata->PRINTING_COLOR_COUNT);
                $tapsdata['BookDetails']['IS_PAR']                  =   ($bookdata->IS_PAR == null?'':$bookdata->IS_PAR);
				$tapsdata['BookDetails']['PM_EMPLOYEE_ID']          =   ($bookdata->PM_EMPLOYEE_ID == null?'':$bookdata->PM_EMPLOYEE_ID);
                $tapsdata['BookDetails']['AM_EMPLOYEE_ID']          =   ($bookdata->AM_EMPLOYEE_ID == null?'':$bookdata->AM_EMPLOYEE_ID);
				$embb												=	'';
				
				if(!empty($bookdata->EMBBED_TYPE)){
					
					if($bookdata->EMBBED_TYPE == '1'){
						$embb			=	'embedded';
					}elseif($bookdata->EMBBED_TYPE == '2'){
						$embb			=	'non-embedded';
					}
				}
				
				$productionLocation		=	'';
				if(!empty($bookdata->LOCATION)){
					$sql2    			=	"select *from production_area_location as ap where ap.ID = '$bookdata->LOCATION'";
			
					$location			=	DB::select( $sql2 );
					$locationDetails		=	$location['0'];		
					$productionLocation      = $locationDetails->LOCATION_NAME;
				}
				$receiptStatus		=	'';
				$sql3    			=	"select *from api_client_acknowledgement as ap where ap.BOOK_ID = '$bookid' and ap.ROUND = '104' and ap.PROCESS_TYPE_DIFF = 'RECEIPT' order by ap.ID desc limit 1";
				$receipt			=	DB::select( $sql3 );
				
				if(!empty($receipt)){
					$receiptDetail		=	$receipt['0']->STATUS;
					if($receiptDetail == '2'){
						$receiptStatus  = 'success';
					}else if($receiptDetail == '3'){
						$receiptStatus  = 'redo';
					}else{
						$receiptStatus  = 'in progress';
					}
				}
				
				
				$tapsdata['BookDetails']['EMBEDDED_TYPE']          =   $embb;
				$tapsdata['BookDetails']['LOCATION_NAME']          =   $productionLocation;
				$tapsdata['BookDetails']['RECEIPT_STATUS']         =   $receiptStatus;
              
                $deadline_array     =   json_decode( $bookdata->SERIES_INFORMATION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['SERIESEISSN']     =   ($deadline_array[0]['SerieId'] == null?'':$deadline_array[0]['SerieId']);
                    $tapsdata['BookDetails']['SERIESTITLE']     =   ($deadline_array[0]['SeriesTitle'] == null?'':$deadline_array[0]['SeriesTitle']);
                    $tapsdata['BookDetails']['SERIESPRINTISSN'] =   ($deadline_array[0]['SeriesEISSN'] == null?'':$deadline_array[0]['SeriesEISSN']);
                    $tapsdata['BookDetails']['SERIESID']        =   ($deadline_array[0]['SerieId'] == null?'':$deadline_array[0]['SerieId']);
                }
                else
                {
                    $tapsdata['BookDetails']['SERIESEISSN']     =   "";
                    $tapsdata['BookDetails']['SERIESTITLE']     =   "";
                    $tapsdata['BookDetails']['SERIESPRINTISSN'] =   "";
                    $tapsdata['BookDetails']['SERIESID']        =   "";
                }
                
                $deadline_array     =   json_decode( $bookdata->STAGE_DEADLINES_COLLECTION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['DEADLINE']['STAGE5']         =   ($deadline_array['S5'] == null?'':$deadline_array['S5']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE50']        =   ($deadline_array['S50'] == null?'':$deadline_array['S50']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE200']       =   ($deadline_array['S200'] == null?'':$deadline_array['S200']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE300']       =   ($deadline_array['S300'] == null?'':$deadline_array['S300']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE600']       =   ($deadline_array['S600'] == null?'':$deadline_array['S600']);
                    $tapsdata['BookDetails']['DEADLINE']['STAGE650']       =   ($deadline_array['S650'] == null?'':$deadline_array['S650']);
                }
                else
                {
                    $tapsdata['BookDetails']['DEADLINE']['STAGE5']         =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE50']        =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE200']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE300']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE600']       =   "";
                    $tapsdata['BookDetails']['DEADLINE']['STAGE650']       =   "";
                }
                
                $deadline_array     =   json_decode( $bookdata->STAGE_RECEIVED_COLLECTION,true);
                if(count($deadline_array)>=1)
                {
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE5']        =   ($deadline_array['S5'] == null?'':$deadline_array['S5']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE50']       =   ($deadline_array['S50'] == null?'':$deadline_array['S50']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE200']      =   ($deadline_array['S200'] == null?'':$deadline_array['S200']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE300']      =   ($deadline_array['S300'] == null?'':$deadline_array['S300']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE600']      =   ($deadline_array['S600'] == null?'':$deadline_array['S600']);
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE650']      =   ($deadline_array['S650'] == null?'':$deadline_array['S650']);
                }
                else
                {
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE5']        =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE50']       =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE200']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE300']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE600']      =   "";
                    $tapsdata['BookDetails']['RECEIVEDON']['STAGE650']      =   "";
                }
                
//                $tapsdata['ChapterDetails']['ChapterID']        =   '';
//                $tapsdata['ChapterDetails']['ChapterNo']        =   '';
//                $tapsdata['ChapterDetails']['ChapterTitle']     =   '';
//                $tapsdata['ChapterDetails']['ChapterPath']      =   '';
//                $tapsdata['ChapterDetails']['ArtPath']          =   '';
                $artpath            =   Config::get('constants.SPLIT_DESTINATION_PATH');
                $artfilename        =   Config::get('constants.ART_SOURCE_PATHS');
                $hostpath           =   str_replace( '/' ,'', $hostpath );
                $raw_path           =   $hostserver.$ftp_root_dir.$hostpath.'/'.Config::get('constants.SPLIT_SOURCE_PATH');                    
                $raw_path           =   str_replace( 'BOOK_ID' ,$bookid, $raw_path );
                $raw_path           =   str_replace( 'ROUND_NAME' ,Config::get('constants.ROUND_OF_NAME.S200'), $raw_path );
                $raw_path           =   "\\\\".$raw_path;
                $originalrawpath    =   str_replace( '/' ,'\\', $raw_path );
		$tapsdata['RawPath']=   $originalrawpath;
				
		if(empty($bookdata->LOCATION ) || $bookdata->LOCATION == '' ){
					
		$tapsdata['RawPath']=  $downloadDetail->DOWNLOAD_PATH;
					
		}
				
               
                                
                $raw_path1           =   $hostserver.$ftp_root_dir.$hostpath.'/'.Config::get('serverconstants.JOBSHEET_PATH').'BOOK_ID/S5/';                    
                $raw_path1           =   str_replace( 'BOOK_ID' ,$bookid, $raw_path1 );
                $raw_path1           =   str_replace( 'ROUND_NAME' ,Config::get('constants.ROUND_OF_NAME.S200'), $raw_path1 );
                $raw_path1           =   "\\\\".$raw_path1;
                $originaljobshettpath    =   str_replace( '/' ,'\\', $raw_path1 );
				
				//	$whereS50data = ['ROUND_ID' => $this->round_ID_5];
                  //  $getjobsheetpath = jobsheetViewpathModel::active()->where($whereS50data)->first();
					
                    $jobsheetPath = $hostpath.'/'.Config::get('serverconstants.JOBSHEET_PATH').'BOOK_ID/S5/'; 
					
					
                    $inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $this->round_NAME_S5);
					 $cmn_obj            =   new CommonMethodsController();
                    $reaadjobsheetpath = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
					
                    $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
					
					  $metadoctypeexnt    =   Config::get('constants.DOCUMENT_TYPE.meta');
					
                    if(count($jobsheetDirFiles)>=1) {
                        foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                            $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
							$nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
							$splitname = explode('.', $spiltchapter);
                                if (in_array($nameofchapterextn, ['xml'])) {
                                    if (strpos($spiltchapter, $bookid) !== false) {
                                        if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                            $jobdoctype[] = "meta";
                                        } else {
                                            $jobdoctype[] = "other";
                                        }
                                        $jobdirfiles[] = $spiltchapter;
                                        $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                    }
                                }

                        }
                    }
                
                           
                $tapsdata['JobsheetPath']   =   $originaljobshettpath.$jobdirfiles['0'];
                $tapsdata['processType']    =   ($tapsreqtype == 1 ?'Magnus':'Womat');
   
                $tapsmeatadata                  =   [];
                $tapsmeatadata['ROUND']         =   $roundID;
                $tapsmeatadata['METADATA_ID']   =   '';
                $tapsmeatadata['JOB_ID']        =   $jobId;
                $tapsmeatadata['START_TIME']    =   Carbon::now();
                $tapsmeatadata['CREATED_DATE']  =   Carbon::now();
                $tapsmeatadata['CREATED_BY']    =   (Session::has('users')['user_id']?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID'));
                $tapsmeatadata['REQUEST_LOG']   =   json_encode($tapsdata);
                $tapsmeatadata['STATUS']        =   '0';
                $tapsmeatadata['WOMAT_TYPE']    =   $tapsreqtype;
			
                $storetapsmeata                 =   tapsmetadataModel::store($tapsmeatadata);
                if($storetapsmeata)
                {
//                    jobInfoModel::where('JOB_ID',$jobId)->update(['PLATFORM_TYPE'=>$tapsreqtype]);
                    $tapsdata['TOKEN_KEY']      =   $storetapsmeata->TOKEN;
                    $updatetapsdata['REQUEST_LOG']  =   json_encode($tapsdata);
                  
                    $updatereglog       =   tapsmetadataModel::doupdate($tapsdata['TOKEN_KEY'],$updatetapsdata);
//                    $sendsingal         =   $this->doSendtapssingnal($tapsdata,$tapsdata['processType'],$jobId,$metadataID,$noofquality);
                    //$url                =   'http://172.24.148.41:9119/clsWorkflowCoordinator.svc/UpdateMetadataBookInfo';
                    $url            		=   Config::get('constants.WOMAT.WOMAT_UPDATE_METADATA_BOOKINFO_SIGNAL');
					if($tapsreqtype  == 3){
						$tasklevelmetadata_query        =	"update api_download set IS_ACTIVE = 0 where ID = $downloadDetail->ID";
						$tsk_crn_upd    				=  	DB::update( $tasklevelmetadata_query );
					}
					Log::useDailyFiles(storage_path().'/Api/movetowomatsignal.log');
				    Log::info($tasklevelmetadata_query);
                    
                    $getToolresponse    =   app('App\Http\Controllers\CommonMethodsController')->PostcUrlExecution($tapsdata,$url,0);
					
					$result             =   array('result'=>200,'status'=>1,'errMsg'=>'Womat signal has passed successfully');
					
                    return response()->json($result);
                }
                $result             =   array('result'=>200,'status'=>0,'errMsg'=>'Womat signal not has been passed successfully try again');   
                return response()->json($result);        
            }
            $result         =   array('result'=>200,'status'=>0,'errMsg'=>'Location not mapped to this title..');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {       
			print_r($e->getMessage());exit;
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result,404);
        }
    }
    
    public function doResponsewomatsingnal(Request $request)
    {
        $getToolresponse    =   json_decode($request->getContent());
				
        Log::useDailyFiles(storage_path().'/Api/afterTapsMoveToProduction.log');
        Log::info($request->getContent());
     
        
        if(count($getToolresponse)>=1)
        {     
            $gettypeofprocess   =   tapsmetadataModel::where('TOKEN',$getToolresponse->TOKEN_KEY)->first();
            
            if(count($gettypeofprocess)>=1)
            {
                $typeofwomat    =   $gettypeofprocess->WOMAT_TYPE;
                $metadataID     =   $gettypeofprocess->METADATA_ID;
                if($typeofwomat     ==  2 || $typeofwomat     ==  3)
                {
                    $token                  =   trim($getToolresponse->TOKEN_KEY);
                    $status                 =   trim($getToolresponse->STATUS);
                    $endtime                =   trim($getToolresponse->END_TIME);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    $updatedata['REMARKS']  =   trim($getToolresponse->REMARKS);
                    $updatedata['RESPONSE_LOG'] =   json_encode($getToolresponse);
                    $updatereglog               =   tapsmetadataModel::doupdate($token,$updatedata);
                    if($updatereglog)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                        return response()->json($result);
                    }
                    else
                    {
                        $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>'token is not valid');
                        return response()->json($result);
                    }
                }
                else
                {
                 
                    $getchapters        =   taskLevelMetadataModel::getMetadatadetailsChapter($metadataID);
                    
                    $noofquality        =   (count($getchapters)>=1?$getchapters[0]->NO_MSP:0);
                    $dataofproduction['JOB_ID']         =   (count($getchapters)>=1?$getchapters[0]->JOB_ID:0);
                    $bookdata           =   jobModel::getjobInfodetails($dataofproduction['JOB_ID']);
                    
                   // echo "<pre>";print_r($bookdata);exit;
                    $dataofproduction['ROUND_ID']       =   Config::get('constants.ROUND_ID.S200');
                    
                    $metadataid =       $dataofproduction['META_ID']        =   $metadataID;
                    $dataofproduction['QUANTITY']       =   $noofquality;
                    $dataofproduction['WORKFLW_ID']     =   Config::get('constants.S200_WORKFLOWID');
                    $dataofproduction['USER_ID']        =   (count($bookdata)>=1?$bookdata->USER_ID:0);
                    $jbr_obj    =   new jobRound();
                   
                    $roundInfo1          =           $jbr_obj->getjobRoundEntryExistByMetaId(  $metadataid , $dataofproduction['ROUND_ID']  , null  );
                    
                    $roundInfo2          =           $jbr_obj->getjobRoundEntryExistByMetaId(  $metadataid , $dataofproduction['ROUND_ID']  , 1  );
                    $copyEditingLevel    =           $bookdata->COPY_EDITING_LEVEL;
                    $embbedType          =           $bookdata->EMBBED_TYPE;
                    $workflowMId         =           $bookdata->WORKFLOW_TYPE; 
                  
                    $parallelWorflowdata['parallelWrokflow']   =   array();
                   
                    if(!empty($getchapters['0']->PRODUCTION_WORKFLOW)){
                        $workflowMId    =   $getchapters['0']->PRODUCTION_WORKFLOW;
                    }
                    
                    if(!empty($workflowMId)){
                        $customObj          =   new customizationModel();
                        $workflowDetails    =   $customObj->getWorkflowAndStages($workflowMId);
                        foreach($workflowDetails['workflow'] as $wfdata ){
                            if($wfdata->WORKFLOW_TYPE == '0'){
                                $dataofproduction['WORKFLW_ID'] = $wfdata->WORKFLOW_ID;
                            }elseif($wfdata->WORKFLOW_TYPE == '2'){
                                $parallelWorflowdata['parallelWrokflow'][]   =   $wfdata->WORKFLOW_ID;
                            }
                        }
                    }
                     
                    if( empty( $roundInfo1 ) ){
                        $moveproductionurl  =   url('/').'/api/movetoproduction';
                        $movepro            =   app('App\Http\Controllers\CommonMethodsController')->PostcUrlExecution( $dataofproduction , $moveproductionurl , 1 );
                    }
                    
                     $whereCondi         =           array( 'METADATA_ID' => $metadataid);
                     $taskartInfo        =           DB::table( 'task_level_art_metadata' )->select()->where( $whereCondi )->get()->toArray();
                    
                    if( empty( $roundInfo2 ) && !empty($taskartInfo) ){
                        
                        $paralleWfid            =   Config::get('constants.S200_ART_WORKFLOWID');
                        $roundNamearray         =   Config::get('constants.ROUND_NAME');
                        $roundNamearray         =   Config::get('constants.ROUND_NAME');
                        
                        $roundName              =  $roundNamearray[$dataofproduction['ROUND_ID']];
                        $dueDateDetais          =  json_decode($bookdata->STAGE_DEADLINES_COLLECTION);
                        $duedate                =   date( 'Y-m-d H:i:s' );
                        
                       /* if(!empty($dueDateDetais->$roundName)){
                            $duedate = str_ireplace('.','-',$dueDateDetais->$roundName);
                            $duedate = date_format(date_create($duedate),"Y-m-d H:i:s");
                        }*/
                        
                        if(!empty($parallelWorflowdata['parallelWrokflow'])){
                            
                            foreach($parallelWorflowdata['parallelWrokflow'] as $wfpId){
                                $paralleWfid        =   $wfpId;
                                
                                $return_status      =   $this->artMovetoProduction( $dataofproduction['JOB_ID'], $dataofproduction['ROUND_ID'], $paralleWfid, $metadataid ,$duedate, $user='' );
                            }
                            
                        }else{
                           // echo $paralleWfid;exit;
                             $return_status      =   $this->artMovetoProduction( $dataofproduction['JOB_ID'], $dataofproduction['ROUND_ID'], $paralleWfid, $metadataid ,$duedate, $user=''  );
                        }                        
                    }
                    $esmlocation			=	'';
                    //update auto stage tool response
                    $token                  =   trim($getToolresponse->TOKEN_KEY);
                    $status                 =   trim($getToolresponse->STATUS);
                    $endtime                =   trim($getToolresponse->END_TIME);
					 
					if(isset($getToolresponse->ESMLocation)){
						$esmlocation            =   trim($getToolresponse->ESMLocation);
					}
                    $platform               =   trim($getToolresponse->PLATFORM);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    
                    if(!empty($getToolresponse->QUERIES))
                    {
                        $updatedata['QURIES']   =   trim($getToolresponse->QUERIES[0]->message);
                    }
                    else
                    {
                        $updatedata['QURIES']   =   trim($getToolresponse->QUERIES);
                    }
                    
                    if(isset($getToolresponse->ESMDetails))
                    {
                        $updatedata['ESM_DETAILS']   =   json_encode($getToolresponse->ESMDetails);
                    }
					if(isset($getToolresponse->WOMATAPISignalDetails))
                    {
                        $updatedata['WOMAT_DETAILS'] =   json_encode($getToolresponse->WOMATAPISignalDetails);
                    }
                    $updatedata['DESTINATION_PATH']   =   trim($getToolresponse->DESTINATION_PATH);
                    $updatedata['REMARKS']      =   trim($getToolresponse->REMARKS);
                    $updatedata['ESM_LOCATION'] =   $esmlocation;
                    $updatedata['PLATFORM']     =   $platform;
                    $updatedata['RESPONSE_LOG'] =   $request->getContent();
                    $updatereglog               =   tapsmetadataModel::doupdate($token,$updatedata);
                    if($updatereglog)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                        return response()->json($result);
                    }
                    $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>'token is not valid');
                    return response()->json($result);
                }
            }
            $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>'token is not valid');
            return response()->json($result);
        }
        $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>'token is not valid');
        return response()->json($result);
    }
    
    public function doArtMoveToProduction( $metaid ,$artworkflow){
        
        app('App\Http\Controllers\production\movetoproductionController')->runArtMoveToProductionProcedure( $metaid,$artworkflow );
        
    }
    
    public function artMovetoProduction($jobid, $roundid, $workflowid, $metaId, $duedate, $user ){
		
		$datetime 			= 	date("Y-m-d H:i:s"); 
		try {
                
                DB::beginTransaction();
                
		if(empty($user)) {
                   $user = Config::get('constants.ADMIN_USER_ID');
                }
		$sql1	 =  "SELECT 1 FROM metadata_status ms WHERE ms.metadata_id = $metaId AND ms.CURRENT_ROUND = $roundid AND ms.IS_ART=1";
                
                $metadata = DB::select( $sql1 );
				
		if(empty($metadata)){
		
			$metaTable      =   array('JOB_ID' => $jobid, 'METADATA_ID' => $metaId, 'CURRENT_ROUND' => $roundid,'DUE_DATE'=>$duedate, 'CURRENT_STATUS' => '46','LAST_MOD_DATE' => $datetime,'LAST_MOD_BY' =>$user,'IS_ART' => '1','RECEIVED_DATE'=>$datetime,'CURRENT_ITERATION'=>'1' );
			$metaStatusId   =   DB::table('metadata_status')->insertGetId( $metaTable );
                       
			if($metaStatusId == ''){
				DB::rollBack();
				return false;
				//return 'Not able to store MetaData Status ';
			}
			
			$metaTable      =   array('JOB_ID' => $jobid, 'METADATA_ID' => $metaId, 'METADATA_STATUS_ID'=>$metaStatusId,'DUE_DATE'=>$duedate,                            
									  'ROUND_ID' => $roundid, 'STATUS' => '27','ROUND_SEQ'=>'1','CREATED_DATE' => $datetime,'CREATED_BY' =>$user,'IS_ART' => '1');
			$autroundId   =   DB::table('job_round')->insertGetId( $metaTable );
			
			//$autroundId = mysql_insert_id();
		
			if($autroundId == ''){
				DB::rollBack();
				return false;
			}
			
			$sql3 = "INSERT INTO job_stage (job_round_id, workflow_master_id, workflow_id, workflow_type, stage_id, start_stage_id, end_stage_id, skip_enabled, STATUS, stage_seq)
									SELECT '.$autroundId.', t.WORKFLOW_MASTER_ID, t.WORKFLOW, t.WORKFLOW_TYPE, t.STAGE, t.START_STAGE, t.END_STAGE, t.SKIP_STAGE, 25, t.STAGE_SEQ
									FROM task_level_userdefined_workflow t
									WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."'";
			DB::insert( $sql3 );
	
			$sql4           = "UPDATE job_stage s, job_round jr SET s.STATUS = 27, jr.CURRENT_STAGE = s.STAGE_ID WHERE jr.JOB_ROUND_ID = s.JOB_ROUND_ID AND s.JOB_ROUND_ID = '".$autroundId."' AND s.STAGE_SEQ = 1";
			$updateTable2   = DB::update( $sql4 );
			
			$sql5           =   "select s.STAGE_ID from job_round as jr
									join job_stage as s ON jr.JOB_ROUND_ID = s.JOB_ROUND_ID
									WHERE jr.JOB_ROUND_ID = s.JOB_ROUND_ID AND s.JOB_ROUND_ID = '".$autroundId."' AND s.STAGE_SEQ = 1";
			$stageRes       =   DB::select( $sql5 );
		   
			if(!empty($stageRes)){
				
				$currentStage	=   $stageRes['0']->STAGE_ID;
				$sql6           =   "update metadata_status as ms SET ms.CURRENT_STAGE = '".$currentStage."' where ms.CURRENT_ROUND = '".$roundid."' AND ms.METADATA_ID = '".$metaId."' AND ms.IS_ART=1";
				DB::update( $sql6 );
				$sql7   =   "update task_level_art_metadata as tam  SET tam.METADATA_STATUS_ID ='".$metaStatusId."',tam.CURRENT_STAGE ='".$currentStage."' ,tam.CURRENT_ROUND = '".$roundid."' where tam.METADATA_ID = '".$metaId."'";
				DB::update( $sql7 );
			
			}
			
			
		}else{
			  return false;
			
		}
			
		
		} catch (Exception $e) {
                    DB::rollBack();
                    echo "Have some error insterting to table";
                            return $e->getMessage();
		
		}
                
		DB::commit();
		return true;
		
	}
    
    public function createArtFromTaps( Request $request ){
       
        $response['status']     =       0;
        $response['msg']        =       'Failed';
        $response['errMsg']     =       'art creation got failed.';
        
        Log::useDailyFiles(storage_path().'/Api/tapsArtCreation.log');
        Log::info( $request->getContent() );
        
        $inputarr           =       json_decode( $request->getContent() , true );
        
        $tlm                =       new taskLevelMetadataModel();
        $cmn_obj            =       new CommonMethodsController();
           
        //$inputarr           =       ( array_keys( $inputarr ));
        $inputarr           =         (object)$inputarr;
        
        $metaid             =       ( $inputarr->chapterid );
        $whereMetaCond      =       array( 'METADATA_ID' => $metaid );
        
        $taskart_arr        =       DB::table('task_level_art_metadata')
                                        ->where( $whereMetaCond )
                                        ->get();
        
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        
        $chapter_name       =       $chapterlist[0];
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        $fignnopurpose      =       DB::select( 'select max(figure_no) as figureno , current_round , revision_no from task_level_art_metadata where metadata_id = '.$metaid );
        $figno              =       0;
        
        if( count( $fignnopurpose ) > 0 ){
            $figno      =        $fignnopurpose[0]->figureno;
            $revision   =        $fignnopurpose[0]->revision_no;
            $round      =        $fignnopurpose[0]->current_round;
        }
        
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id                  =       $jobinfo[0];
        
        if(empty( $chapterlist ))  
            throw new \Exception( 'chapter level information is not found' );
        
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                =       $bookinfo[0];
        $getlocationftp         =       productionLocationModel::getJobLocationServerPath( $job_id );
        $ftpObj                 =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
        $host                   =       $getlocationftp['HOST'];
       
        $ftp_path               =       $getlocationftp['HOST_PATH'];
        
        $artPath                =       \Config::get('serverconstants.ART_PREPROCESSING_PATH');
        $roundname              =       $round_arr[$round];
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname     ,
                                            '{BID}'         =>      $book_id ,   '{RID}' => $roundname   ,      
                                            '{CID}'         =>      $chapter_name
                                        );

        $artPath                 =        $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $ftp_path.$artPath )  );
        
        if( count( $taskart_arr ) > 0 ){
            
            $file_arr           =       explode( ',' , $inputarr->file ); 
            $instruc_arr        =       explode( '|' , $inputarr->instruction );
            $arra_remarks       =       array();
            $insert_mul_arr     =       array();
                    
            foreach( $instruc_arr as $key => $value ){
                
                $figno  =   $figno+1;
                $arra_remarks[$file_arr[$key] ] =       $value;
                $insert_arr     =       array();
                $insert_arr['FILE_NAME']       =        $file_arr[$key];    
                $insert_arr['METADATA_ID']     =        $metaid;    
                $insert_arr['JOB_ID']          =        $job_id;    
                $insert_arr['FIGURE_NO']       =        ($figno);    
                $insert_arr['COMPLEXITY']      =        1;    
                $insert_arr['REVISION_NO']     =        $revision;    
                $insert_arr['CURRENT_ROUND']   =        $round;    
                $insert_arr['CURRENT_STAGE']   =        \Config::get('constants.STAGE_COLLEECTION.ART_MANIPULATION');    
                $insert_arr['CURRENT_ITERATION']=       1;    
                $insert_arr['STATUS_ENUM_ID']   =       \Config::get( 'constants.ART_STATUS.ART_CREATED');    
                $insert_arr['REMARKS']          =       $value;    
                $insert_arr[ 'CREATED_BY' ]     =       '5556405';
                
                //INSERT TASKLEVEL ART META multiarray insert                 
                $insert_mul_arr[]   =   (array)$insert_arr;
                
                $temppath                    =       $host.'/'.\Config::get( 'serverconstants.FILE_SERVER_FTP_PATH' ).\Config::get( 'serverconstants.TEMP_PATH' );    
                $sourcePath                  =       $getlocationftp['FTP_PATH_CREDENTIAL'].$temppath.'TAPS/'.$file_arr[$key];            
                $descPath                    =       $getlocationftp['FTP_PATH_CREDENTIAL'].$host.$artPath.$file_arr[$key];
                $fileExistPath               =       $artPath.$file_arr[$key];
                $fileExistPath               =       str_replace( '\\' , '/'  , $fileExistPath );
                $fileExist                   =       $ftpObj->ftpFileExist( $fileExistPath );
                if( !$fileExist  ){
                    $content                     =       file_get_contents($sourcePath);
                    if(!empty($content)) {
                        $descPath                =       str_replace( '\\' , '/'  , $descPath );
                        $response_file           =       file_put_contents($descPath,$content);
                    }
                
                }
            }
            
            if( !empty($insert_mul_arr) ){
                
                $insert_objs                =   DB::table('task_level_art_metadata')->insert( $insert_mul_arr );
            
                if( $insert_arr ){
                    
                    $return_status          =    app('App\Http\Controllers\production\movetoproductionController')->runArtMoveToProductionProcedure( $metaid );
                    
                    $response['status']     =   1;
                    $response['msg']        =   'Success';
                    $response['errMsg']     =   'Successfully Completed';   
                    
                }else{
                    $response['errMsg']     =   'Tasklevel entry has done. Movetoproduction issue occured';
                }
                
            }else{
                $response['errMsg']     =   'Art table insert data preparation got failed';
            }
                
            
        }else{
            $response['errMsg']  =  'Invalid try , given chapterid or metaid is wrong ';
        }
        
        return response()->json( $response );
        
    }
    
    public function rejectArtFromTaps( Request $request ){
        
        Log::useDailyFiles(storage_path().'/Api/tapsArtRejection.log');
        Log::info( $request->getContent() );
        
        $inputarr           =       json_decode( $request->getContent() , true );
        $inputarr           =       (object)$inputarr;
        $metaid             =       ( $inputarr->chapterid ); 
        
        $file_arr           =       explode( ',' , $inputarr->file ); 
        $instruc_arr        =       explode( '|' , $inputarr->instruction );
        $arra_remarks       =       array();
        
        foreach( $instruc_arr as $key => $value ){
            $arra_remarks[$file_arr[$key] ] =   $value;
        }
        
        $whereMetaCond      =       array( 'METADATA_ID' => $metaid );
        $taskart_arr        =       DB::table('task_level_art_metadata')
                                            ->where( $whereMetaCond )
                                            ->get();
        
        $tlm                =       new taskLevelMetadataModel();
        $cmn_obj            =       new CommonMethodsController();
        
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $round_obj          =       $taskLevelInfo->pluck('CURRENT_ROUND')->toArray(); 
        $round              =       $round_obj[0]; 
        
        $chapter_name       =       $chapterlist[0];
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
         
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                =       $bookinfo[0];
        $getlocationftp         =       productionLocationModel::getJobLocationServerPath( $job_id );
        $ftpObj                 =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
        
        $host                   =       $getlocationftp['HOST'];
       
        $ftp_path               =       $getlocationftp['HOST_PATH'];
        
        $artPath                =       \Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
        $roundname              =       $round_arr[$round];
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname     ,
                                            '{BID}'         =>      $book_id ,   '{RID}'         =>      $roundname   ,      
                                            '{CID}'         =>      $chapter_name
                                        );

        $pdfPath             =        $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $ftp_path.$artPath )  );
        
        $filtered_input      =       array();
        $prepararr           =       array();
        $inputarr            =       array();
         
        foreach( $taskart_arr as $key  => $inputmeta ){
            
            $prepararr              =       array();
            $dummyfilename_arr      =       explode( '.' , $inputmeta->FILE_NAME  );
            $dummyfilename          =       implode( '_' , $dummyfilename_arr );
            $dummyfilename          =       $inputmeta->FILE_NAME;
        
            if( in_array( $dummyfilename , $file_arr ) ){
                
                $prepararr['artmetaid']         =       $inputmeta->ART_METADATA_ID;
                $prepararr['artFileName']       =       $inputmeta->FILE_NAME;
                $prepararr['remarks']           =       $arra_remarks[$dummyfilename];
                $inputarr[]                     =       $prepararr;
                
            }
            
            
            
        }
        
        $response['status']     =           0;
        $response['msg']        =           'Failed';
        $response['errMsg']     =           'art stage rollback got failed.';
        
        $jbs_obj                =           new jobStage();
        $checkoutObj            =           new checkoutModel();
        $onetime	=	false;
        $copydone	=	false;
		
        if( !empty( $inputarr )){
            
            foreach( $inputarr as $key => $input ){
               
                extract( $input );
                try{
                    
                    $artManupulationStageid     =       \Config::get( 'constants.STAGE_COLLEECTION.ART_MANIPULATION' );
                    $jobstage               =           $jbs_obj->getJobStageInfoByArtMetaIdStageId( $artmetaid , $artManupulationStageid );
					
                    $jobStageId             =        $jobstage[0]->JOB_STAGE_ID;
                    $stageDetails           =        $checkoutObj->getArtStageInfo($jobStageId);
                    $stageData              =        $stageDetails['0'] ;
                    $bookid                 =        $stageData->BOOK_ID;
                    $nwChp                  =        $stageData->CHAPTER_NO;
					
                    $nwChp                  =        explode( '_' , $nwChp );
                    $chapno                 =        implode( '_' , array_reverse( $nwChp ) );
					$fileName               =        $bookid.'_'.$chapno;
                    
					if(!$onetime){
						$checkoutObj->artStageRollBack(  $artmetaid , $stageData->METADATA_STATUS_ID , $stageData->JOB_ROUND_ID  , $stageData->WORKFLOW_ID , $stageData->ROUND_ID , $stageData->ITERATION_ID , $stageData );
						$onetime	=	true;
					}
					
                    $statusenumid			=	46;
                    $artstartstageid		=	\Config::get( 'constants.STAGE_COLLEECTION.ART_MANIPULATION' );
					$iterationCount			=	$stageData->ITERATION_ID;
					$nextiterationCount		=	$iterationCount +1;
					$currround				=	$stageData->JOB_ROUND_ID;
                    
					//$update_qry             =       "UPDATE task_level_art_metadata SET REMARKS='".$remarks."' AND STATUS_ENUM_ID='".$statusenumid."' WHERE ART_METADATA_ID =".$artmetaid;
                    //DB::update( $update_qry );
					
					$sql5  = "update task_level_art_metadata set REMARKS='".$remarks."',CURRENT_ROUND='".$currround."',CURRENT_STAGE='".$artstartstageid."',STATUS_ENUM_ID=46,FIGURE_STATUS=0,CURRENT_ITERATION='".$nextiterationCount."' where ART_METADATA_ID IN(".$artmetaid.") ";
					DB::update( $sql5 );
					
					if(!$copydone){	
						//art annotated pdf file copy to Qc folder
						$temppath                    =       $host.'/'.\Config::get( 'serverconstants.FILE_SERVER_FTP_PATH' ).\Config::get( 'serverconstants.TEMP_PATH' );    
						$sourcePath                  =       $getlocationftp['FTP_PATH_CREDENTIAL'].$temppath.'TAPS/'.$fileName;            
						$descPath                    =       $getlocationftp['FTP_PATH_CREDENTIAL'].$host.$pdfPath.$fileName;
						$fileExistPath               =       $pdfPath.$fileName;
						
						$fileExistPath               =       str_replace( '\\' , '/'  , $fileExistPath );
						$fileExist                   =       $ftpObj->ftpFileExist( $fileExistPath );
						if( !$fileExist  ){
							$content                     =       file_get_contents($sourcePath);
							if(!empty($content)) {
								$descPath                =       str_replace( '\\' , '/'  , $descPath );
								$response_file           =       file_put_contents($descPath,$content);
							}
						}
						
						$copydone	=	true;
						
                    }
					
                    $response['status']     =       '1';
                    $response['msg']        =       'Success';
                    $response['errMsg']     =       'Successfully completed';

                }catch( \Exception $ex ){
                    
                    $response['errMsg']  = $ex->getMessage();
                    $response['reason']  = $ex->getTraceAsString();
                    
                }

            }
            
        }else{
            
            $samples                =       json_encode( $inputarr );//'{"metaid":"12345","artCollection":{"artMetaid":325,"artFilename":"RBL_c25"}}';
            $sminp                  =       'Sample input format is : '.$samples;
            $response['errMsg']     =       'Invalid input given.'.$sminp;
            
        }        
        return response()->json( $response );
    }
    
    public function sendArtCompletedSignaltoTaps( $metaid = null , $round = null ){
    
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Signal trigger got failed.';
       
        
        $whereMetaCond      =       array( 'METADATA_ID' => $metaid , 'CURRENT_ROUND' => $round );
        $artCompletion      =       \Config::get( 'constants.ART_STATUS.ART_COMPLETED' );
        $taskart_arr        =       DB::table('task_level_art_metadata')
                                        ->where( $whereMetaCond )
                                        ->whereNotIn( 'STATUS_ENUM_ID' , array( $artCompletion ) )
                                        ->get();
        $tlm                =       new taskLevelMetadataModel();
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $chapter_name       =       $chapterlist[0];
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
         if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                 =       $bookinfo[0]->BOOK_ID;
        $newChpname              =       explode( '_' , $chapter_name ); 
        
        $newChpname_arr              =      ( array_reverse( $newChpname ) );
        $nechp_name                  =        implode('_', $newChpname_arr);
        if( count( $taskart_arr ) == 0 ){
            
            $tlm        =       new taskLevelMetadataModel();
            $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
            $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
         
            $postData                       =       array();
            $postData['status']             =       'S';    
            $postData['chapter_id']         =       $metaid;
            $postData['chap_name']          =       $book_id.'_'.$nechp_name;
            $postData['client_name']        =       'springer';
            $postData['process_name']       =       'artwork';
            $postData['PackagePath']        =       '';
            $postData['queries']            =       '';
             $curl       =           \Config::get( 'constants.TAPS.ART_COMPLETION_SIGNAL_URL' );

            $cmn_obj                 =       new  CommonMethodsController();
            $returns_response        =       $cmn_obj->PostcUrlExecution( $postData , $curl );
            
            $res_arr                 =       json_encode( $returns_response );
            
            $response['errMsg']             =       'Api request processed successfully'; 
           
                $response['msg']    =       'success';
                $response['errMsg'] =       'Successfully send signal to taps';                
            
        }else{
            $response['errMsg']     =   'Art is still not yet completed.';
        }
        
        return response()->json( $response );
    }
    
    public function doTapscompletion(Request $request){
        
        ini_set ( 'max_execution_time', 0); 
        
        $requestid      =   $request->get('RequestID');
        $requesttype    =   $request->get('RequestType');
        $chapteerid     =   $request->get('ChapterID');
        $status         =   $request->get('RequestStatus');
        
        $validation     =   Validator::make($request->all(), [
                                                                'RequestID' => 'required',
                                                                'RequestType' => 'required',
                                                                'ChapterID' => 'required|numeric',
                                                                'RequestStatus' => 'required|numeric'
                                                            ]);

        if ($validation->fails())
        {
            $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>$validation->errors());
            return response()->json($result);
        }
        
        $logfilename	=	's200_closure_from_taps';
        Log::useDailyFiles(storage_path().'/Api/'.$logfilename);
        Log::info( json_encode( $request->all() ) );
        
        $getapitaps     =   apitapsModel::where('TOKEN',$requestid)->first();    
        
        if(count($getapitaps)>=1)
        {
            $updatedata     =   ['TAPSCOMPLETION_STATUS'=>$status];
            //$updateapitaps  =   apitapsModel::doupdate($requestid,$updatedata);  
            
            if($updatedata)
            {
                $metaid     =   $getapitaps->METADATA_ID;
                $round      =   $getapitaps->ROUND;
                
                
                $updateData['IS_ACTIVE']  = '1';
                       
                $updateQry  =   DB::table( 'report_wip_art' )
                                     ->where('METADATA_ID', $metaid)
                                     ->where('ROUND', $round )
                                     ->where('SYNC_STATUS', '0' )
                                     ->where('IS_ACTIVE', '0' )
                                     ->update( $updateData );
                
                $pcgCnt     =       new packageController();
                $pcgCnt->getPageCountInformation( $metaid, $round );
                
                return app('App\Http\Controllers\Api\autostageController')->stageCompletionProcess($metaid,$round);
                
                //$result         =   array(  'status'=>1   ,  'msg'=>'Success','errMsg'=>'Response received Successfully');
                //return response()->json($result);
            }
            $result         =   array('status'=>0,'msg'=>'Invalid request Id','errMsg'=>'Response received  not updated Successfully');
            return response()->json($result);
        }
        $result         =   array('status'=>0,'msg'=>'Invalid request Id','errMsg'=>'Response received  not updated Successfully');
        return response()->json($result);
    }
    
    public function doTapsCeCompletion( Request $request ){
        
        ini_set ( 'max_execution_time', 0); 
        $response       =   array();
        
        $logfilename	=	'taps_Ce_completion';
        Log::useDailyFiles(storage_path().'/Api/'.$logfilename);
        Log::info( json_encode( $request->all() ) );
        	

        $validation     =   Validator::make( $request->all() , [
                                                                'RequestID' => 'required',
                                                                'RequestType' => 'required',
                                                                'ChapterID' => 'required|numeric',
                                                                'RequestCeStatus' => 'required|numeric'
                                                            ]);

        if ($validation->fails()){
            $result         =   array(  'status'    =>  0,  'msg'   => 'Error', 'errMsg'=>$validation->errors() );
            return response()->json($result);
        }
        
        $requestid      =   $request->get('RequestID');
        $requesttype    =   $request->get('RequestType');
        $chapteerid     =   $request->get('ChapterID');
        $status         =   $request->get('RequestCeStatus');
        $getapitaps     =   apitapsModel::where('TOKEN',$requestid)->where('TAPS_CE_STATUS' , '=' ,  '1.5' )->first();    
        
        
        if(count($getapitaps)>=1){
            
            $updatedata     =   [ 'TAPS_CE_STATUS' => $status ];
            
            $updateapitaps  =   apitapsModel::doupdate($requestid,$updatedata);  
            
			try{
				
				if( $updateapitaps ){
					
					$metaid     =       $getapitaps->METADATA_ID;
					$round      =       $getapitaps->ROUND;
				   
					//update the receipient mail id
					$lwres_obj              =       new lowResController();
					$return_receipt         =       $lwres_obj->getRecipientEmailID( $metaid , $round );
					
					@$lwres_obj->lowResCreationBgProcessInitialize( $metaid , $round );
					
					$result         =   array(  'status'=>1 , 'msg'=>'Success','errMsg'=>'Response received Successfully');
					return response()->json($result);
					
				}
				
            }catch(Exception $e){
				
				$updatedata     =   [ 'TAPS_CE_STATUS' => 3 ];
				
				$updateapitaps  =   apitapsModel::doupdate($requestid,$updatedata);  
				
			}
			
            $result         =   array('status'=>0,'msg'=>'Invalid request Id','errMsg'=>'response log not received');
            return response()->json($result);
            
        }
        
        $result         =   array('status'=>0,'msg'=>'Invalid request Id','errMsg'=>'Response received  not updated Successfully');
        return response()->json($result);
        
    }
    
    public function tapssignaltest(){
        $this->tapsSignal('6927');
    }
    public function tapsSignal($jstageid){
        
         $checkoutObj                =       new checkoutModel();
         $stageDetails               =       $checkoutObj->getStageInfo( $jstageid );
         $stageDetailsObj            =       $stageDetails[0];
         $stageName                  =       '';
         if(!empty($jstageid)){
                $workflowPath                       =   new workflowServerMapPathModel();
                $serverMapPath                      =   $workflowPath->getWorkflowServerMapPath($jstageid);
                if(!empty($serverMapPath['detail']['src'])){
                    $srcPath        =   array_filter(explode('/',$serverMapPath['detail']['src']));
                    array_pop($srcPath);
                    $stageName      =   end($srcPath);
                }
                
            }
         
        
         $logfilename	=	's200_taps_signal';
        Log::useDailyFiles(storage_path().'/Api/'.$logfilename);
        Log::info( json_encode( $stageDetailsObj ) );
        
        if( count($stageDetails)>=1){
            
                $jobsheetmove       =   app('App\Http\Controllers\artProcess\artProcessController')->dosfiftyJobsheetmove($stageDetailsObj->METADATA_ID,$stageName);
                $tapsxml            =   app('App\Http\Controllers\artProcess\artProcessController')->doTapssupportingxml($stageDetailsObj->METADATA_ID,$stageName);
                $chapartmetaxml     =   app('App\Http\Controllers\artProcess\artProcessController')->doChapterartmetaxml($stageDetailsObj->METADATA_ID,$stageName);
                $chapmetaxml        =   app('App\Http\Controllers\artProcess\artProcessController')->doChaptermetaxml($stageDetailsObj->METADATA_ID,$stageName);
                $ChapterNo          =   (count($stageDetails)>=1?$stageDetailsObj->CHAPTER_NO:'');
                $ChapterTitle       =   (count($stageDetails)>=1?$stageDetailsObj->CHAPTER_NAME:'');
                $jobId              =   (count($stageDetails)>=1?$stageDetailsObj->JOB_ID:'');
                $roundID            =   Config::get('constants.ROUND_NAME.S200');
                
                $getToolresponse    =   app('App\Http\Controllers\Api\tapsController')->domoveTaps($jobId,$stageDetailsObj->METADATA_ID,$roundID,$ChapterNo,$ChapterTitle,$jstageid);
                
            }
    }
    
     public function artSourceRename($metaId){
         
         $result            =   array('status'=>0,'msg'=>'Invalid request Id');
         if(empty($metaId))
             return $result;
         
            $taskMetaObj       =   new taskLevelMetadataModel();
            $locationObj       =   new productionLocationModel();
            $jobObj            =   new jobModel();
            
            $roundID           =   116;
            $roundName         =   'S200';
            $artQcPath         =   Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
            
            $metaDetails        =   $taskMetaObj->getMetadatadetailsChapter($metaId);
            $jobDetails         =   $jobObj->getjobInfodetails($metaDetails['0']->JOB_ID);
            $bookId             =   $jobDetails->BOOK_ID;
            $serverDetail       =    $locationObj->getJobLocationServerPath($metaDetails['0']->JOB_ID);
            
            $inp_rep_arr    =       array( 
                                        '{CID}'       =>      $metaDetails['0']->CHAPTER_NO ,
                                        '{BID}'       =>      $bookId ,
                                        '{RID}'     =>      $roundName
                                    );
            
             $inp_rep_arr2    =       array( 
                                        '{CID}'       =>      $metaDetails['0']->CHAPTER_NO.'_taps_backup' ,
                                        '{BID}'       =>      $bookId ,
                                        '{RID}'     =>      $roundName
                                    );
            
            $cmn_obj            =   new CommonMethodsController();
            $artQcPath1         =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $artQcPath );
            $artQcPathSrc       =   $serverDetail['HOST_PATH'].$artQcPath1;
            
            $artQcPath2          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr2 , $artQcPath );
            $artQcPathSrc2       =   $serverDetail['HOST_PATH'].$artQcPath2;
           
            $fileHandlerObj   =   new ftpFileHandlerController($serverDetail['HOST'],$serverDetail['FTP_USERNAME'],$serverDetail['FTP_PASSWORD']);
            $response         =   $fileHandlerObj->ftp_is_dir($artQcPathSrc);
           
            if($response == true){
                
               $response2         =   $fileHandlerObj->ftpRename($artQcPathSrc,$artQcPathSrc2); 
               $result            =   array('status'=>1,'msg'=>'Success');
            }else{
                 $result            =   array('status'=>1,'msg'=>'Folder not exist');
            }
            
              return response()->json($result);
     }
    
}
