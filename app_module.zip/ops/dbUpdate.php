<?php
include("config.php");
$action     =       $_REQUEST['action'];

if($action=="stageUpdate"){
    
    $articleId      =       $_REQUEST['articleid'];
    
    $updateQuery    =       "UPDATE api_ops_status SET FINALIZE_STATUS=1,FINALIZE_TIME=now() where ID=".$articleId;
    $resp           =       mysqli_query( $con , $updateQuery );
    
    $sql_stmt       =       "SELECT * FROM api_ops_status where ID=".$articleId." ORDER BY ID DESC LIMIT 1";
    $result         =       $con->query( $sql_stmt );

    if( $result->num_rows > 0 && $resp) {

        while( $row = $result->fetch_assoc() ){
           
            $insQuery   =       "INSERT INTO ops_proofout_mail_to_pm_status( OPS_PROOF_ID,METADATA_ID,ROUND,STATUS ) "
                                . " VALUES ( ".$row['ID']." , ".$row['METADATA_ID']." , ".$row['ROUND'] ." ,1 )";
            
            mysqli_query( $con , $insQuery );
            
        }
        
    } 

    if($resp){
        echo "success";
    }else{
        echo "failure";
    }
    
    exit;
    
    
}

?>