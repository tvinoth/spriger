<?PHP

/*
 *  Created By Maharajan.P
 *  Database Configuration Details.
 * 
 */

$hostname 		= 		"172.24.191.58";    //  Host name of the Server
$username1 		= 		"developer";        //  User Name of the Server
$password1 		= 		"developer@58";     //  Password of the Server
$dbname 		= 		"springer";

$con 			= 		mysqli_connect( "$hostname" , "$username1" , "$password1" ) or die("Unable to connect to Database server");

@mysqli_select_db( $con , $dbname ) or die("Unable to select database");


?>