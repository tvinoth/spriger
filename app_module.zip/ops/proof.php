<?php
session_start();
ob_start();

include("config.php");
$val = 1;

//  Redirecting to Proofbox.php with encoding values in URL

$type 			= 		$_REQUEST['type'];
$fileName 		= 		$_REQUEST['filename'];
$articleID 		= 		$_REQUEST['articleid'];

$status			=		false;

if( isset( $_REQUEST['ver'] ) ){    
    $articleID          =               base64_decode( $articleID );
    $fileName           =               base64_decode( $fileName );    
}

$hostip					=		$_SERVER['SERVER_NAME'];
 
$isMailSent             = 		"";
$journalCode            = 		"";
$paths					=		"";
$selQuery 				= 		mysqli_query( $con , "select * from api_ops_status where ID=" . $articleID );
$resultRs				=		false;

if( $selQuery ) {
	
	$resultRs	=	true;
	
	if( mysqli_num_rows( $selQuery ) ){
		
		while($rs_get = mysqli_fetch_array( $selQuery ) ) {
		
			$paths 			= 		trim($rs_get['INPUT_PDF_PATH']);
			$articleName    = 		trim($rs_get['META_VALUE']);
			$paths 			= 		str_replace(	".pdf"	,	"_review.pdf"	,	$paths );
			$paths 			= 		str_replace(	"\\\\$hostip"	,	""	,	$paths );
			$len			=		strlen( $paths );
			$status 		= 		$rs_get['FINALIZE_STATUS'];
			
		}
		
	}
	
}else{
	$resultRs	=	false;
}

$paths 				= 		"..\\public".$paths;

if( $status == "1" || $status == "2" ){
	$status 	=		"2";
	$paths		=		"";
	echo "<script>alert('Chapter Finalized.');
                window.open('', '_self', '');
                window.close();
              </script>";
	
}

//}
//  End of the code 
?>
<html>
    <head>
        <style>
            .buttonStyle {
                font-weight: bold;
                font-size: 10px;
                color: teal;
                border: 1px solid CornflowerBlue;
                font-family: Verdana;
                height: 15px;
                background-color: white;
                cursor: pointer;
            }
        </style>
       
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" type="text/javascript"></script>
        <title>Online Proofing System - Proof</title>
        <script type="text/javascript">
            
            function finalizeProofCorr(coverId) {
                if (confirm("Are you sure you want to finalize your stage?")) {
                    $.ajax({
                        url: 'dbUpdate.php?action=stageUpdate&articleid=' + coverId,
                        dataType: 'text',
                        cache: false,
                        contentType: false,
                        processData: false,
                        type: 'post',
                        success: function (d) {
                            if (d == "success") {
                                alert("Chapter finalized.");
                                //window.close();
                                window.open('', '_self', '');
                                window.close();
                            } else {
                                alert("Chapter not finalized..Please try again after sometime..");
                            }
                        },
                        error: function (d) {
                            alert("Error in Cover details Update..!");
                        }
                    });
                }
            }
        </script>
    </head>
	
    <body>
       
            <table align=center border=0 width=100% height="30px"  style="border:1px solid black;">
                <tr>
                    <td width="0%" style='font-family:verdana;font-size:18px;font-weight:bold;text-align:center;'></td>
                    <td width="46%">
						<span style='font-family:verdana;font-size:16px;font-weight:bold;text-align:center;'>Filename : <?php echo $fileName; ?></span>
					</td>
                    <?php if ($type == "proof" ) { ?>
                        <td width="29%" align=right>
						<?php if($status!="2" && $resultRs	){ ?>
                            <input type='button'  align='center' class='ButtonStyle' id='FinalizedButton' value='Finalize/Complete Proof Review' style='cursor:pointer;color:green;' title='Finalize your corrections/approval. Once you do this, you will not be able to revise your corrections ' onclick= "finalizeProofCorr(<?php echo $articleID; ?>);"  />
						<?php }else{
								
						} ?>
                        </td>
                    <?php } ?>
                </tr>
            </table>
			
            <div  id='DivProof' style='border:1px solid black;position:relative;width:100%;height:95%;visibility:visible;display:block;'>
			<?php if( $resultRs	){ ?>
                <iframe class=dragme src="<?php echo $paths; ?>" id='FrmProof' marginheight=0 marginwidth=0 border=1 vspace=0 hspace=0 allowtransparency='true' frameborder='0'  scrolling='no' height=100% width=100% align=center>
                </iframe>
			<?php }else{
					echo 'Invalid try..';
			} ?>	
            </div>    
       
    </body>
	
</html>