-- --------------------------------------------------------
-- Host:                         172.24.191.58
-- Server version:               5.7.12 - MySQL Community Server (GPL)
-- Server OS:                    Linux
-- HeidiSQL Version:             9.5.0.5280
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table springer.correction_file_upload
CREATE TABLE IF NOT EXISTS `correction_file_upload` (
  `UPLOAD_ID` int(11) NOT NULL AUTO_INCREMENT,
  `TYPE` varchar(500) NOT NULL,
  `MAPPINGTYPE` varchar(500) NOT NULL,
  `BOOK_ID` varchar(500) NOT NULL,
  `JOB_ID` varchar(500) NOT NULL,
  `ROUND_ID` varchar(500) NOT NULL,
  `ROUND_NAME` varchar(500) NOT NULL,
  `STAGE_ID` varchar(500) NOT NULL,
  `STAGE_NAME` varchar(500) NOT NULL,
  `WORKFLOW_ID` varchar(500) NOT NULL,
  `WORKFLOW_MASTER_ID` varchar(500) NOT NULL,
  `WORKFLOW_TYPE` varchar(500) NOT NULL,
  `PROCESS_ID` int(11) DEFAULT NULL,
  `REMARKS` text,
  `IS_ACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `CREATED_DATE` datetime NOT NULL,
  `CREATED_BY` int(11) NOT NULL,
  `LAST_MOD_DATE` datetime DEFAULT NULL,
  `LAST_MOD_BY` int(11) DEFAULT NULL,
  PRIMARY KEY (`UPLOAD_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
-- Dumping structure for table springer.correction_upload_chapter
CREATE TABLE IF NOT EXISTS `correction_upload_chapter` (
  `UPLOAD_CHAPTER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `UPLOAD_ID` int(11) NOT NULL,
  `CHAPTER_NO` varchar(500) NOT NULL,
  `CHAPTER_TITLE` varchar(500) NOT NULL,
  `SOURCE_PATH` varchar(1000) NOT NULL,
  `DESTINATION_PATH` varchar(1000) NOT NULL,
  `REMARKS` text,
  `IS_ACTIVE` tinyint(1) NOT NULL DEFAULT '1',
  `CREATED_DATE` datetime NOT NULL,
  `CREATED_BY` int(11) NOT NULL,
  `LAST_MOD_DATE` datetime DEFAULT NULL,
  `LAST_MOD_BY` int(11) DEFAULT NULL,
  PRIMARY KEY (`UPLOAD_CHAPTER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=latin1;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
