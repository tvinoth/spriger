<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class Jobdownloadfailed extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    protected $data;
    public function __construct($maildata)
    {
        $this->data     =   $maildata;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('Magnus Notification@SPI')->subject('Download failed')->view('emailtemplate.download.jobfailedNotification') ->with([
                        'Title'         =>  $this->data['Title'],
                        'ToName'        =>  $this->data['ToName'],
                        'mailcontent'   =>  $this->data['mailcontent'],
                        'BookId'        =>  $this->data['BookId'],
                        'filename'      =>  $this->data['FileName']
                    ]);
    }
}
