<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Auth;
use App\Models\userdefinedmenuModel;
use DB;
use Session;

class MenuServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        View::composer('*', function($view) {
            $data   = array();
            $userid = Session::get('users')['user_id'];
            $roleid = Session::get('users')['role_id'];
            $mastermenu = userdefinedmenuModel::getmainmenu($roleid);
            $menutransaction = userdefinedmenuModel::getmainmenuchild($roleid);
            $childtype  =   2;
            $subchildtype  =   3;
            $menuArray  =   [];
            if (!empty($mastermenu) && count($mastermenu) >= 1) {
                foreach ($mastermenu as $menukey => $menuvalue) {
                    $menuArray[$menukey]['TRANSACTION_NAME']    =   $menuvalue->TRANSACTION_NAME;
                    $menuArray[$menukey]['URL']    =   $menuvalue->URL;
                    $menuArray[$menukey]['MENU_ICON']    =   $menuvalue->MENU_ICON;
                    $menuArray[$menukey]['IS_CHECK_ACTIVE_NAME']    =   $menuvalue->IS_CHECK_ACTIVE_NAME;
                    $getSubMenuList = userdefinedmenuModel::getmainmenusubchild($menuvalue->TRANSACTION_NAME, $roleid,$childtype);
                    $dataofchild = [];
                    $childname = [];
                    if (!empty($getSubMenuList) && count($getSubMenuList) >= 1) {
                        foreach ($getSubMenuList as $key => $value) {
                            if (strpos($value->TRANSACTION_NAME, '>>') !== false) {
                                $childname = explode('>>', $value->TRANSACTION_NAME);
                                $dataofchild[$key]['TRANSACTION_NAME'] = $childname[0];
                                $dataofchild[$key]['NAME'] = $childname[1];
                                $dataofchild[$key]['PACKAGE_DISPLAY_ORDER'] = $value->PACKAGE_DISPLAY_ORDER;
                                $dataofchild[$key]['CODE'] = $value->CODE;
                                $dataofchild[$key]['CHILD_NAME'] = $value->IS_CHECK_ACTIVE_NAME;
                                $dataofchild[$key]['URL'] = $value->URL;
                                $getSubchildMenuList = userdefinedmenuModel::getmainmenusubchild($dataofchild[$key]['TRANSACTION_NAME'] . '>>' . $dataofchild[$key]['NAME'] . '>>', $roleid,$subchildtype);
                                $subMenuListArr = [];
                                $subMenuName = [];
                                if (!empty($getSubchildMenuList) && count($getSubchildMenuList) > 0) {
                                    $dataofchild[$key]['SUBCHILDNAMEAVAILABLE'] = true;
                                    foreach ($getSubchildMenuList as $sMKey => $sMValue) {
                                        if (strpos($sMValue->TRANSACTION_NAME, '>>') !== false) {
                                            $subMenuName = explode('>>', $sMValue->TRANSACTION_NAME);
                                            $subMenuListArr[$sMKey]['sMTRANSACTION_NAME'] = $subMenuName[0];
                                            $subMenuListArr[$sMKey]['sMNAME'] = $subMenuName[1];
                                            $subMenuListArr[$sMKey]['SUBCHILDNAME'] = $subMenuName[2];
                                            $subMenuListArr[$sMKey]['sMPACKAGE_DISPLAY_ORDER'] = $sMValue->PACKAGE_DISPLAY_ORDER;
                                            $subMenuListArr[$sMKey]['sMCODE'] = $sMValue->CODE;
                                            $subMenuListArr[$sMKey]['sMCHILD_NAME'] = $sMValue->IS_CHECK_ACTIVE_NAME;
                                            $subMenuListArr[$sMKey]['sMURL'] = $sMValue->URL;
                                        }
                                    }
                                }
                                $dataofchild[$key]['SUBCHILDNAMEARR'] = $subMenuListArr;
                            } else {
                                $dataofchild[$key]['TRANSACTION_NAME'] = $value->TRANSACTION_NAME;
                                $dataofchild[$key]['NAME'] = $value->TRANSACTION_NAME;
                                $dataofchild[$key]['PACKAGE_DISPLAY_ORDER'] = $value->PACKAGE_DISPLAY_ORDER;
                                $dataofchild[$key]['CODE'] = $value->CODE;
                                $dataofchild[$key]['CHILD_NAME'] = $value->IS_CHECK_ACTIVE_NAME;
                                $dataofchild[$key]['URL'] = $value->URL;
                                $dataofchild[$key]['SUBCHILDNAMEAVAILABLE'] = false;
                            }
                            $menuArray[$menukey]['CHILDMENU']   =   $dataofchild;
                        }
                    }else{
                        $menuArray[$menukey]['CHILDMENU']   =   '';
                    }
                }
            }
            $menudecode     =   json_encode($menuArray);
            $menu           =   json_decode($menudecode);
            $view->with('layouts.sidemenu')->with(compact('menu'));
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register() {
        //
    }

}
