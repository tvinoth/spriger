<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\correction\correctionController;
use App\Models\jobModel;
use Carbon\Carbon;
use DB;
use Log;
use Config;

class correctionDownloadCron extends Command{
	
    protected $signature    =   'correctionDownloadCron:data';
    protected $description  =   'S650 correction download ';

    public function __construct(){
		parent::__construct();
    }
    
    public function handle(){
		
		//Log::useDailyFiles(storage_path().'/Api/correctiondownloads650.log');
		//Log::info( "S650 correction download initiation" );
		
		$cdownObj     		 =   	new correctionController();
		$cdownObj 			 =	 	$cdownObj->handleS650CorrectionDownload();
        
    }
	
}