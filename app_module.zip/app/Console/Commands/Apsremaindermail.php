<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel;
use App\Models\emailRemainderLogModel;
use App\Models\CountriesModel;
use App\Models\apsProofingStatusModel;
use App\Models\apiFtpUpload;
use App\Models\remainderEmailTemplateModel;
use App\Models\jobModel;
use App\Mail\Remaindereproofsendmail;
use Carbon\Carbon;
use DB;
use Log;
use Config;

class Apsremaindermail extends Command
{
    protected $signature    =   'apsremainder:mailsend';
    protected $description  =   'Send an email of registered users';

    public function __construct()
    {
        parent::__construct();
    }
    
    public function handle()
    {
        $getremainderchapterlist    =   apsProofingStatusModel::getapsremaindermaillist();
        Log::useDailyFiles(storage_path().'/Api/apsemailremainder.log');
        Log::info( json_encode( $getremainderchapterlist ) );
        if(count($getremainderchapterlist)>=1)
        {
            foreach($getremainderchapterlist as $key=>$remaindervalue)
            {
                $metadataid         =   $remaindervalue->METADATA_ID;
                $jobid              =   $remaindervalue->JOB_ID;
                $round              =   $remaindervalue->ROUND;
                $PROOFING_URL       =   $remaindervalue->PROOFING_URL;
                $correction_date    =   $remaindervalue->CORRECTION_DUE;
                $mailArray          =   $mailData   =   [];
                $job_info           =   jobModel::getJobdetails($jobid);
                $getrecipientmail   =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
                $getemailcontent    =   remainderEmailTemplateModel::where('TEMP_TYPE',2)->first();
                if(count($job_info)>=1 && count($getrecipientmail)>=1 && count($getemailcontent)>=1)
                {
                    $mailsendFlag               =   false;
                    $mailtoAmFlag               =   false;
                    $mailtoPmFlag               =   false;
                    $pm_userid                  =   $job_info->PM;
                    $am_userid                  =   $job_info->AM;
                    $jobId                      =   $job_info->JOB_ID;
                    $mailArray['JOB_ID']        =   $jobId;
                    $mailArray['METADATA_ID']   =   $metadataid;
                    $mailArray['ROUND_ID']      =   $remaindervalue->ROUND;
                    $usrC_obj                   =   new usersController();
                    $mailArray['ToMail']        =   $remaindervalue->TO_EMAIL;
                    $mailData['ToName']         =   $remaindervalue->NAME;
                    
                    $mailData['BookId']         =   $job_info->BOOK_ID;
                    $mailData['Title']          =   $remaindervalue->SUBJECT_LINE;
                    $mailData['authorname']     =   $job_info->AUTHOR_NAME;
                    $mailData['editorname']     =   $job_info->EDITOR_NAME;
                    $mailData['BookIsbn']       =   $job_info->ISSN_ONLINE;
                    $mailData['ReceivedDate']   =   $job_info->JOB_ASSIGNED_DATE;
                    $mailData['AUTHORNAME']     =   $job_info->AUTHOR_NAME;
                    $mailData['BOOK_TITLE']     =   $job_info->JOB_TITLE;
                    $mailData['BookTitle']      =   $job_info->JOB_TITLE;
                    //get proof sent data
                    $whereproof                 =   ['PROCESS_TYPE'=>Config::get('constants.REMINDER_PROCESS_TYPE.E_PROOF'),'ROUND'=>Config::get('constants.ROUND_ID.S300'),'METADATA_ID'=>$metadataid];
                    $proofData                  =   apiFtpUpload::select(DB::Raw('END_TIME'))->where($whereproof)->orderBy('ID','desc')->first();
        //            echo Carbon::parse($mailData['INSERT_DATE'])->format('l jS \\of F Y h:i:s A');
                    $proofdate                  =   ($proofData != null?$proofData->END_TIME:$correction_date);  
                    $mailData['INSERT_DATE']    =   Carbon::parse($proofdate)->format('jS F Y');
                    
                    $mailData["IMPRINT_NAME"]   =   $job_info->PUBLISHER_IMPRINT_NAME;
                    $usrC_obj                   =   new usersController();
                    $currentuser_id             =   $job_info->PM;
                    $user_arr                   =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
                    $mailData['ToName']         =   (count($user_arr)>=1?$user_arr->LAST_NAME:'').' '.(count($user_arr)>=1?$user_arr->FIRST_NAME:'');
                    $mailData['PMNAME']         =   $mailData['ToName'];
                    $mailData['FAX']            =   (count($user_arr)>=1?$user_arr->FAX:''); 
                    $mailData['T_ADDRESS']      =   (count($user_arr)>=1?$user_arr->T_ADDRESS:''); 
                    $mailData['T_CITY']         =   (count($user_arr)>=1?$user_arr->T_CITY:''); 
                    $mailData['T_STATE']        =   (count($user_arr)>=1?$user_arr->T_STATE:''); 
                    $mailData['T_ZIP']          =   (count($user_arr)>=1?$user_arr->T_ZIP:''); 
                    $mailData['P_COUNTRY']      =   (count($user_arr)>=1?$user_arr->P_COUNTRY:''); 
                    $mailData['EMAIL']          =   (count($user_arr)>=1?$user_arr->EMAIL:''); 
                    $mailData['WORK_PHONE']     =   (count($user_arr)>=1?$user_arr->WORK_PHONE:''); 
                    $mailData['PERSONAL_PHONE'] =   (count($user_arr)>=1?$user_arr->PERSONAL_PHONE:''); 
                    $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
                    $titlewordname              =   $job_info->JOB_TITLE;
                    if(is_array($findwordcount) && isset($findwordcount[2]))
                    {
                        $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
                    }
                    //get  country name
                    $countryname                =   CountriesModel::find($mailData['P_COUNTRY']);
                    $countryname                =   (count($countryname)>=1?$countryname->name:'');
                    $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_PRINT.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
                    $mailArray['Subject']       =   $remaindervalue->SUBJECT_LINE;
                    $emailbodycontent           =   $remaindervalue->EMAIL_CONTENT;
                    $firstrememailbodycontent   =   $getemailcontent->FIRST_REMAINDER;
                    $secondrememailbodycontent  =   $getemailcontent->SECOND_REMAINDER;
                    $thirdrememailbodycontent   =   $getemailcontent->THIRD_REMAINDER;
                    $forwardbodycontent         =   $getemailcontent->FORWARD_TEMP;
                    $emailtextreplace           =   array(
                                                        '[BOOK_TITLE]'      =>  $mailData['BookTitle'],
                                                        '<surname>'         =>  $mailData['ToName'],
                                                        '<signature>'       =>  $mailData['ToName'] ,
                                                        '[AUTHORNAME]'      =>  ($mailData['authorname']    ==  ''?$mailData['editorname']:$mailData['authorname']),
                                                        '<link1>'           =>  $PROOFING_URL,
                                                        '<link>'            =>  $PROOFING_URL,
                                                        '<ProofDate>'       =>  $mailData['INSERT_DATE'],
                                                        '<SentDate>'        =>  $proofdate,
                                                        '[PMNAME]'          =>  $mailData['PMNAME'],
                                                        '[IMPRINT_NAME]'    =>  $mailData["IMPRINT_NAME"],
                                                        '[T_ADDRESS]'       =>  ($mailData['T_ADDRESS']     ==  ''?'':"<p>".$mailData['T_ADDRESS']."</p>"),
                                                        '[T_CITY]'          =>  ($mailData['T_CITY']        ==  ''?'':"<p>".$mailData['T_CITY']."</p>"),
                                                        '[T_STATE]'         =>  ($mailData['T_STATE']       ==  ''?'':"<p>".$mailData['T_STATE']."</p>"),
                                                        '[T_ZIP]'           =>  ($mailData['T_ZIP']         ==  ''?'':"<p>".$mailData['T_ZIP']."</p>"),
                                                        '[P_COUNTRY]'       =>  ($countryname               ==  ''?'':"<p>".$countryname."</p>"),
                                                        '[WORK_PHONE]'      =>  ($mailData['WORK_PHONE']    ==  ''?'':"<p>T: ".$mailData['WORK_PHONE']."</p>"),
                                                        '[FAX]'             =>  ($mailData['FAX']           ==  ''?'':"<p>F: ".$mailData['FAX']."</p>"),
                                                        '[TOEMAIL]'         =>  $mailData['EMAIL'],
                                                        '<email>'       =>      $mailData['EMAIL'] 
                                                     );
                    $emailforwardtextreplace        =   array(
                                                        '[SUBJECT_EMAIL]'   =>  $mailArray['Subject'],
                                                        '[FROM_EMAIL]'      =>  Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL'),
                                                        '[TIME_SENT_EMAIL]' =>  Carbon::parse($remaindervalue->START_TIME)->format('l jS \\of F Y'),
                                                        '[TO_EMAIL]'        =>  $remaindervalue->TO_EMAIL,
                                                        '[CC_EMAIL]'        =>  $remaindervalue->CC_EMAIL
                                                     );

                    $cmn_obj                    =   new CommonMethodsController();
                    $emailbodyoriginalcontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $emailbodycontent , true );
                    $firstremainderemailbodycontent =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $firstrememailbodycontent , true );
                    $secondrememailbodycontent  =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $secondrememailbodycontent , true );
                    $thirdrememailbodycontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $thirdrememailbodycontent , true );
                    $forwardbodycontent         =   $cmn_obj->arr_key_value_replace( $emailforwardtextreplace , $forwardbodycontent , true );
                    $checkexistemailid          =   $remaindervalue->APSEMAILLOG_ID;
                    $firstremainderalreadysent  =   $remaindervalue->FIRST_REMAINDER;
                    $secondremainderalreadysent =   $remaindervalue->SECOND_REMAINDER;
                    $thirdremainderalreadysent  =   $remaindervalue->THIRD_REMAINDER;
                    $firsttyperemainderemail    =   "";
                    $secondtyperemainderemail   =   "";
                    $thirdtyperemainderemail    =   "";
                    $emailsplithrline           =   '<div class="hr" style="height:2px;border-bottom:2px solid #afa7a7;clear: both;">&nbsp;</div><br><br>';
                    $bodywholecontent           =   "";
                    //mail data build
                    $mailArray['TemplateName']  =   'emailtemplate.apsmailsetupalert.aps-emailalert';
                    $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                    $mailArray['FromName']      =   $remaindervalue->FROM_NAME;
                    $mailArray['Title']         =   $remaindervalue->SUBJECT_LINE;
                    $mailArray['ToMail']        =   "ananth.b@spi-global.com";
                    $mailArray['CcMail']        =   "ananth.b@spi-global.com,vinoth.t@spi-global.com,$job_info->PE_MAIL"; 
                    if(strpos($mailArray['ToMail'],',') !== false)
                    {
                        $toemailarray           =   explode(',',$mailArray['ToMail']);
                        $mailArray['ToMail']    =   array_unique($toemailarray);
                    }
                    
                    if(strpos($mailArray['CcMail'],',') !==  false)
                    {
                        $toemailarray           =   explode(',',$mailArray['CcMail']);
                        if(in_array('',$toemailarray)){
                            foreach($toemailarray as $invaliemailkey=>$value){
                                if(empty($value)){
                                    unset($toemailarray[$invaliemailkey]);
                                }
                            }
                        }
                        $mailArray['CcMail']    =   array_unique($toemailarray);
                    }else{
                        $mailArray['CcMail']    =   $mailArray['CcMail'];
                    }
                    
                    // mail send
                    $mailattachtarget               =   public_path().'/apsAttachmentfile/';
                    $mailattachfilename             =   $remaindervalue->MAIL_ATTACHMENT_URL;
                    $getfileofattachmentloc         =   $mailattachtarget.$mailattachfilename;
                    if(file_exists($getfileofattachmentloc))
                    {
                        $mailArray['file']          =   $getfileofattachmentloc;
                        $mailArray['attachfile']    =   array('as' => $mailattachfilename, 'mime' => 'text/plain');
                    }
                    
                    $mailArray['EMAIL_LOG_ID']  =   $checkexistemailid;
                    // if correction is exist don't send mail
                    if(empty($remaindervalue->CRCRECIVEDORNOT)){
                        if($remaindervalue->REM1    ==  1  && $remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1  && $firstremainderalreadysent   !=  1)
                        {
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['SECONDMAIL']     =   "";
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                            $mailData['FORWARDMAIL']    =   "";
                            $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                            $bodywholecontent           .=   $firstremainderemailbodycontent;
                            $bodywholecontent           .=   $forwardbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['FIRST_REMAINDER']   =   '1';
                            $mailArray['Data']          =   $mailData;
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            if(count($getapslogemail)>=1)
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
                            $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }
                        
                        if($remaindervalue->REM2    ==  1  && $remaindervalue->SECOND_REMAINDER_EMAIL_STATUS  ==  1 && $secondremainderalreadysent   !=  1)
                        {
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['FORWARDMAIL']    =   "";
                            if($remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $firstremainderemailbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            
                            $mailData['SECONDMAIL']     =   "";
                            $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                            $bodywholecontent           .=   $secondrememailbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['SECOND_REMAINDER']  =   '1';
                            $mailArray['Data']          =   $mailData;
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            if(count($getapslogemail)>=1)
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
                            $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }

                        if($remaindervalue->REM3    ==  1 && $remaindervalue->THIRD_REMAINDER_EMAIL_STATUS  ==  1 &&  $thirdremainderalreadysent   !=   1)
                        {   
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['SECONDMAIL']     =   "";
                            
                            if($remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                                $bodywholecontent           .=   $firstremainderemailbodycontent;
                                $mailData['FORWARDMAIL']    =   "";
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            
                            if($remaindervalue->SECOND_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                                $bodywholecontent           .=   $secondrememailbodycontent;
                                $mailData['FORWARDMAIL']    =   "";
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['THIRDMAIL']      .=  $thirdrememailbodycontent;                            
                            $bodywholecontent           .=   $thirdrememailbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['THIRD_REMAINDER']   =   '1';
                            $mailArray['Data']          =   $mailData;
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            if(count($getapslogemail)>=1)
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
                            $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }
                    }
                }
            }
        }
    }
    
    public function sendMailBladeTemplate($mailArray) {
        try {
            if (is_array($mailArray)) {
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '3';
                        emailRemainderLogModel::where($wheredatamail)->update($updatedata);
                    }
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                        emailRemainderLogModel::where($wheredatamail)->update($updatedata);
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/apsfailedemailremainder.log');
            Log::info( json_encode( $exception->getMessage() ) );
        }        
    }
    
    public function doProcessMaillog($checkexistemailid,$bodywholecontent = null,$mailArray)
    {
        $firsttyperemainderemail            =   (isset($mailArray['FIRST_REMAINDER'])?$mailArray['FIRST_REMAINDER']:0);
        $secondtyperemainderemail           =   (isset($mailArray['SECOND_REMAINDER'])?$mailArray['SECOND_REMAINDER']:0);
        $thirdtyperemainderemail            =   (isset($mailArray['THIRD_REMAINDER'])?$mailArray['THIRD_REMAINDER']:0);
        if(!empty($checkexistemailid)>=1)
        {
            $updatedata                         =   [];
            $updatedata['BODY_OF_MAIL']         =   $bodywholecontent;
            $updatedata['TO_EMAIL']             =   $mailArray['ToMail'];    
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $updatedata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else{
                $updatedata['CC_EMAIL']         =   $mailArray['CcMail'];
            }
            if(!empty($firsttyperemainderemail))
            {
                $updatedata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $updatedata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $updatedata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            emailRemainderLogModel::where('ID',$checkexistemailid)->update($updatedata);
            $lastemaillogid                     =   $checkexistemailid;
        }else{
            $insertdata                         =   [];
            $insertdata['JOB_ID']               =   $mailArray['JOB_ID'];
            $insertdata['METADATA_ID']          =   $mailArray['METADATA_ID'];
            $insertdata['ROUND']                =   $mailArray['ROUND_ID'];
            $insertdata['STATUS']               =   Config::get('constants.STATUS_ENUM.INPROGRESS');
            $insertdata['BODY_OF_MAIL']         =   $bodywholecontent;
            $insertdata['TO_EMAIL']             =   $mailArray['ToMail'];
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $insertdata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else
            {
                $insertdata['CC_EMAIL']         =   $mailArray['CcMail'];   
            }
            if(!empty($firsttyperemainderemail))
            {
                $insertdata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $insertdata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $insertdata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            $insertdata['CREATED_DATE']         =   Carbon::now();
            $insertdata['REMAINDER_TYPE']       =   Config::get('constants.REMAINDER_TYPE.APS');
            $lastemaillogid                     =   emailRemainderLogModel::insertGetId($insertdata);
            $mailArray['EMAIL_LOG_ID']          =   $lastemaillogid;
        }
        return $mailArray;
    }
}