<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\reports\wipreportsController;
use App\Models\jobModel;
use Carbon\Carbon;
use DB;
use Log;
use Config;

class WipReportSyn extends Command
{
    protected $signature    =   'WipReportSyn:data';
    protected $description  =   'Send daily wip related information';

    public function __construct()
    {
        parent::__construct();
    }
    
    public function handle()
    {
		Log::useDailyFiles(storage_path().'/Api/syn.log');
		Log::info( "Syn call" );
       $wipObj     =   new wipreportsController();
        
       $jobresponse      =   $wipObj->jobSync();
       $artresponse      =   $wipObj->artSync();
       $processresponse  =   $wipObj->procesSync();
        
    }
    public function cronJob(){
        
        
    }
}