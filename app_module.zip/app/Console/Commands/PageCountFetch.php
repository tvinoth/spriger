<?php
namespace App\Console\Commands;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\Api\schedulers\pageCountPaginationController;
use App\Models\jobModel;
use Carbon\Carbon;
use DB;
use Log;
use Config;

class PageCountFetch extends Command
{
    protected $signature    =   'PageCountFetch:data';
    protected $description  =   'Fetching Page Count Information after s300 , s600 , s650';

    public function __construct(){
		parent::__construct();
    }
    
    public function handle(){
		
		//Log::useDailyFiles(storage_path().'/Api/pageFetch.log');
		//Log::info( "Gathering information of pagination page count" );
		
		$pgeCountObj     		 =   new pageCountPaginationController();
		$pgeCountObj 			 =	 $pgeCountObj->fetchPageCountShedule();
		
        
    }
	
}