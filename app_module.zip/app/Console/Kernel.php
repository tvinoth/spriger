<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Log;
use Carbon\Carbon;
use App\Http\Controllers\Api\schedulers\pageCountPaginationController;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
		'App\Console\Commands\Eproofremaindermail' ,
		'App\Console\Commands\Apsremaindermail' ,
		'App\Console\Commands\WipReportSyn' ,
		'App\Console\Commands\PageCountFetch' ,
		'App\Console\Commands\correctionDownloadCron' 
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();
		
		Log::useDailyFiles(storage_path().'/Api/syn.log');
		//Log::info( "kkkk" );
		//$schedule->command('WipReportSyn:data')->daily();
		//$schedule->command('eproofremainder:mailsend')->daily();
		//$schedule->command('apsremainder:mailsend')->daily();
		$schedule->command('correctionDownloadCron:data')->cron('* * * * *');		
		$schedule->command('PageCountFetch:data')->cron('*/1 * * * *');

		$schedule->call(function () use ($schedule) {
			
			$seconds = 15;
			$dt = Carbon::now();

			$x=60/$seconds;

			do{
				
				$pgeCountObj     		 =   new pageCountPaginationController();
				$pgeCountObj 			 =	 $pgeCountObj->fetchPageCountShedule();
				
				// do your function here that takes between 3 and 4 seconds
				//$schedule->command('PageCountFetch:data');
				time_sleep_until($dt->addSeconds($seconds)->timestamp);

			} while($x-- > 0);

		})->everyMinute();

    }

    /**
     * Register the Closure based commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        require base_path('routes/console.php');
    }
}
