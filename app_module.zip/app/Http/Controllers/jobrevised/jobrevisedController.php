<?php
namespace App\Http\Controllers\jobrevised;
use App\Http\Controllers\Controller;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobsheetViewpathModel;
use App\Models\roundModel;
use App\Models\stageModel;
use App\Models\bookinfoModel;
use App\Models\downloadModel;
use App\Models\jobRevisedModel;
use App\Models\apiPrrreportModel;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Mail;
use DB; 
class jobrevisedController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request){
        $data               = 	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.REVISED_JOB'),$data);
        $roundinfo          =   roundModel::getAllRoundInfo();
        $roundOpt           =   '';
        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=       '<option value="'.($value['ID']).'">';
            $roundOpt      .=       $value['DESCRIPTION'];
            $roundOpt      .=       '</option>';
        }

//        $stage_collect      =   stageModel::getAllStageInfo();
//        $stageOpt           =   '';
//        foreach ( $stage_collect as $key => $value ){
//            $stageOpt      .=  '<option value="'.($value['STAGE_ID']).'">';
//            $stageOpt      .=  $value['STAGE_NAME'];
//            $stageOpt      .=  '</option>';
//        }

        $projectCollect     =   array();
        $projectOpt         =   '';
        $projectCollect     =   bookinfoModel::getBookinfo();
        $jobid              =   "";
        foreach( $projectCollect as $key => $value ){
            $selec_opt      =   '';
            if( !is_null( $jobid ) ){
                if( $value['JOB_ID'] == $jobid ){
                   $selec_opt   =   'selected';
                }
            }
               
            $projectOpt     .=  '<option  value="'.($value['JOB_ID']).'" '.$selec_opt.'>';
            $projectOpt     .=  $value['BOOK_ID'];
            $projectOpt     .=  '</option>';
        }
        
        $data['roundCollect']   =   $roundOpt;
//        $data['stageCollect']   =   $stageOpt;
        $data['projectCollect'] =   $projectOpt;
        return view('jobrevised.jobrevised-tab')->with($data);
    }
    
    public function getroundlist(Request $request){
        
	$data               =   roundModel::active()->get();
	$response["prr"]    =   $data;
	return response()->json($response);
        
    }
    
    public function getjoblist(Request $request){
        
	$data               =   jobModel::where('IS_ACTIVE',true)->get();
	$response["book"]   =   $data;
        
	return response()->json( $response );
        
    }
    
    public function getBookChapterList(Request $request){
        
        $job_id         =   trim($request->input('jobId'));
        
	$data               =   taskLevelMetadataModel::where('JOB_ID',$job_id)->get();
	$response["chapter"]   =   $data;
        
	return response()->json( $response );
        
    }
    
    public function jobrevisedlist(Request $request)
    {
        try{
            $bookID         =   "";
            $chapterID      =   "";
            $roundID        =   "";
            $stageID        =   "";
            if($request->has('bookid')) {
                $bookID     =   $request->input('bookid');
            }
            if($request->has('metadataid')) {
                $chapterID  =   $request->input('metadataid');
            }
            if($request->has('roundid')) {
                $roundID    =   $request->input('roundid');
            }
            
            $arrData        =   array();
            $data           =   downloadModel::getJobreviseddetails($bookID,$chapterID,$roundID); 
            $datanew        =   [];
            $downloadType   =   "";
            foreach($data   as $key=>$value)
            {
                $datanew[$key]['JOB_ID']        =   $value->JOB_ID;
                $datanew[$key]['BOOK_ID']       =   $value->BOOK_ID;
                $datanew[$key]['ROUND_ID']      =   $value->ROUND_ID;
                $datanew[$key]['ROUND_NAME']    =   $value->ROUND_NAME;
                $datanew[$key]['ACTIVE']        =   $value->ACTIVE;
                $datanew[$key]['JOB_TITLE']     =   $value->JOB_TITLE;
                $datanew[$key]['CHAPTER_NO']    =   $value->CHAPTER_NO;
                $datanew[$key]['METADATA_ID']   =   $value->METADATA_ID;
                $datanew[$key]['LOCATION']      =   $value->LOCATION;
                $datanew[$key]['JOB_ASSIGNED_DATE']     =   $value->JOB_ASSIGNED_DATE;
                $datanew[$key]['receivedDate']  =   $value->receivedDate;
                $datanew[$key]['CLIACKID']      =   $value->CLIACKID;
                $datanew[$key]['ISSN_PRINT']    =   $value->ISSN_PRINT;
                $datanew[$key]['PMname']        =   $value->PMname;
                $datanew[$key]['PM']            =   $value->PM;
                $datanew[$key]['JOB_TYPE']      =   $value->JOB_TYPE;
                if(!empty($value->deadline)){
                    $deadData       =   (array)json_decode($value->deadline);
                    $deadKey        =   array_keys($deadData);

                    $downloadType   =   'regular';

                    if($deadKey['0'] == 'S5' && $deadKey['1'] == 'S50' && $deadKey['2'] == 'S600'){
                        $downloadType = 'fasttrack';
                    }
                }
                $datanew[$key]['downloadType']  =   $downloadType;

                if (is_numeric($value->AM)){
                    $datanew[$key]['AM']        =   (string)($value->AM ==  0?'':$value->AM);
                }else{
                    $datanew[$key]['AM']        =   '';
                }

                $datanew[$key]['AM_NAME']       =   $value->AM_NAME;
                $datanew[$key]['JOB_SHEET_UPDATE']  =   $value->JOB_SHEET_UPDATE;
                $datanew[$key]['UPDATE_REMARKS']    =   $value->UPDATE_REMARKS;
                $datanew[$key]['JOB_SHEET_UPLOAD']  =   $value->JOB_SHEET_UPLOAD;
                $datanew[$key]['UPLOAD_REMARKS']    =   $value->UPLOAD_REMARKS;
                $datanew[$key]['SUCCESS_REDO']      =   $value->SUCCESS_REDO;
                $datanew[$key]['SR_REMARKS']        =   $value->SR_REMARKS;
            }
        } catch (Exception $ex) {
            return $e->getMessage();
        }
        $response["jobassigned"]    = 	$datanew;
        $response["chapterlist"]    =   taskLevelMetadataModel::getDownloadedChapterdetails($bookID);
        return response()->json($response);
    }
    
    public function doJobrevised(Request $request)
    {      
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $response['validation']     =   "";
            if($request->method()   ==  "POST")
            {
                $validation 	= 	Validator::make($request->all(), [
                                                                            'jobId' => 'required',
                                                                            'roundId' => 'required'
//                                                                            'jobsheetfile' => 'required|file|mimes:xml'
                                                                    ]);
                
                $requestData       =    $request->all();
                if ($validation->fails())
                {
                    $response   =   $this->validationResponse;
                    $response['validation']     =   $validation->errors();
                    return response()->json($response);
                }
                            
                $jobsheetfile   =   $request->file('jobsheetfile');
                $filename       =   $jobsheetfile->getClientOriginalName();
                $fileexetention =   $jobsheetfile->getClientOriginalExtension();
                if($fileexetention  !=  'xml')
                {
                    $response['errMsg']     =   'Invalid, Kindly Upload xml file';
                    return response()->json($response);
                }
                
                $datetime       =   date('Y-m-d H-i-s');                
                $job_id         =   trim($request->input('jobId'));
                $roundName        =   trim($request->input('roundId'));
                
                //$chaperId       =   trim($request->input('chapterId'));
                $chaperId    = '';
                if(isset($requestData['chapterId']) && $requestData['chapterId'] != 'undefined' && !empty($requestData['chapterId']) ){
                    $chaperId       =   $requestData['chapterId'];
                }else{
                    $chaperId    = '';
                }
                
                $getroundinfo   =   roundModel::where('ID',$roundName)->first();
                if(count($getroundinfo)>=1)
                {
                    $roundid    =      $getroundinfo->NAME;
                }
                
                $chapterNo      =   '';
                if(!empty($chaperId)){
                    $metadataObj        =   new taskLevelMetadataModel();
                    $data               =   $metadataObj->getMetadatadetailsChapter($chaperId);
                    $chapterNo          =   (count($data)>=1?$data['0']->CHAPTER_NO:'');
                }
                
                $getbook        =   jobModel::getJobdetails($job_id);
                $bookid         =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                if(strpos($filename,$bookid) !==    false)
                {
                }
                else
                {
                    $response['errMsg']     =   'Invalid Job Sheet name';
                    return response()->json($response);
                }
                $getlocationftp =   productionLocationModel::doGetLocationname( $job_id );      
                if(count($getlocationftp)>=1 && $bookid !=  "")
                {
                    $hostserver     =   $getlocationftp->FTP_HOST;
                    $hostusername   =   $getlocationftp->FTP_USER_NAME;
                    $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    $hostpath       =   $getlocationftp->FTP_PATH;
                    // Do the FTP connection
                    $ftpObj         =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
                    $getuserid      =   Session::get('users')['user_id'];
                    
                    $jobfiles       =   Config::get('constants.RAW_JOBSHEET_PATH');
                    
                    $jobfiles       =   str_replace( 'BOOK_ID' ,$bookid, $jobfiles );
                    $jobfiles       =   str_replace( 'ROUND_NAME' ,$roundid, $jobfiles );
                    
                    $wheredata          =   ['ROUND_ID'=>$roundName];
           
                    $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
                  
                    if(count($getjobsheetpath)>=1)
                    {
                        $jobsheetPath      =   $getjobsheetpath->JOBSHEET_PATH; 
                       
                        $jobsheetPath       =   str_replace( 'BOOK_ID' ,$bookid, $jobsheetPath );
                        $jobsheetPath       =   str_replace( 'ROUND_NAME' ,$roundid, $jobsheetPath );
                    }   
                    
                    
                    if(!empty($chapterNo)){
                        $jobfiles       .= $chapterNo.'/';
                        $jobsheetPath    =   str_replace( 'CID' ,$chapterNo, $jobsheetPath );
                    }
                   $jobsheetPath         =  '/'.$jobsheetPath;
                    $rawpath     =   $hostpath.$jobfiles;
                    
                    //echo $jobsheetPath;
                    //echo $sourcefile;exit;
                    
                    
                    $xmlFilePath    =   "";
                    //get all files from ftp based on given folder name
                    $serverDirFiles     =   $ftpObj->allFiles($jobsheetPath);
                    
                   
                    foreach($serverDirFiles as $value)
                    {
                        if(pathinfo($value)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $value;
                        }
                    }
                    if(!empty($xmlFilePath)) 
                    {
                        //check directory exist or not
                        $checkdirexistchapter   =   $ftpObj->has($xmlFilePath);
                        $backupfile         =   Config::get('constants.JOBSHEET_BACKUP_FOLDER');
                        $createbackup       =   $jobsheetPath.$backupfile.$datetime;
                        if($ftpObj->has($createbackup))
                        {
                            
                        }
                        else
                        {
                            $cucDirFiles=   $ftpObj->makeDirectory($createbackup,0777);
                        }
                        if(strpos($xmlFilePath,'/') !== 	false)
                        {
                            $filename       =   substr(strrchr($xmlFilePath, "/"), 1);
                        }
                        
                        if($ftpObj->has($createbackup))
                        {
                            $putfile        =   $ftpObj->copy($xmlFilePath,$createbackup.'/'.$filename,0777);
                        }
                        if($ftpObj->has($xmlFilePath))
                        {
                            $ftpObj->delete($xmlFilePath);
                        }
                    }
                    
//                    $fileupload         =   $ftpObj->put($sourcefile.$filename,$jobsheetfile->getClientOriginalName());    
                    $fileupload         =   $ftpObj->put($rawpath.$jobsheetfile->getClientOriginalName(),  File::get($jobsheetfile)); 
                    $fileupload2         =   $ftpObj->put($jobsheetPath.$jobsheetfile->getClientOriginalName(),  File::get($jobsheetfile));   
                    
                    $remarks            =   "";
                    $remarks            =   ($fileupload  ==  true?"Job Sheet copied successfully":"Job Sheet copied failed try again");
                    $datainsert         =   [];
                    $datainsert['JOB_ID']   =   $job_id;
                    $datainsert['ROUND']    =   $roundid;
                    $datainsert['CREATED_BY']   =   $getuserid;
                    $datainsert['REMARKS']      =   $remarks;
                    $datainsert['CREATED_DATE'] =   Carbon::now();
                    $storeresponse      =   jobRevisedModel::store($datainsert);
                    if($storeresponse>=1)
                    {
                        $response       =   $this->successResponse;
                        $response['errMsg'] =   'Job Sheet uploaded successfully';
                        return response()->json($response);
                    }
                    $response['errMsg'] =   'Job Sheet uploaded failed try again';
                    return response()->json($response);
                }
                return response()->json($response);
            }
        }
        catch(\Exception $e )
        {
            $response['errMsg'] =   $e->getMessage();
            return response()->json($response);
        }
    }    
    public function viewJobSheet(Request $request){
        $this->displayMenuName(Config::get('menuconstants.MENU.REVISED_JOB'),$data);
        $data['user_name'] 	=  	Session::get('users')['user_name'];
        $data['role_name'] 	=  	Session::get('users')['role_name'];
        
        $letterFormat_arr       =       \Config::get('constants.INTRODUCTORY.LETTER_FORMAT');
        
        $booksinfo              =       bookinfoModel::getBookinfo();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'DESCRIPTION' ) ); 
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        //$roundinfo              =       $roundinfo->whereNotIn('ID',[$round_arr['S5']]);
        $booksOpt               =       '';
        $roundOpt               =       '';
       
        foreach ( $booksinfo as $key => $value ){
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
        }
        
        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=  '<option value="'.($value['ID']).'">';
            $roundOpt      .=  $value['DESCRIPTION'];
            $roundOpt      .=  '</option>';
        }
        
        $data['roundCollect']            =      $roundOpt;
        
        $data['bookidCollect']           =      $booksOpt;
        return view( 'jobrevised.jobsheetview' )->with( $data );
    }
    
    /*public function doPrrReportSend(Request $request)
    {
        if($request->method()   ==  "POST")
        {
            $validation 	= 	Validator::make($request->all(), [
                                                                        'jobId' => 'required|numeric',
                                                                        'Mailid' => 'required',
                                                                        'file' => 'required|file'
                                                                ]);

            if ($validation->fails())
            {
                $result         =   array('result'=>0,'errMsg'=>'all fields are required','validationerror'=>$validation->errors());   
                return response()->json($result,401);
            }
            $jobId              =   $request->input('jobId');
            $getftpfile         =   $request->file('file');
            $bookexist          =   jobInfoModel::checkExistbookjob($jobId);
            if(count($bookexist)>=1)
            {
//                //echo $bookexist->PE_MAIL;exit;
//                if (!file_exists(public_path('prrreportemailtemp/'))) 
//                {
//                    File::makeDirectory(public_path('prrreportemailtemp/'), $mode = 0777, true, true);
//                }
//                $putfile        =   file_put_contents(public_path('prrreportemailtemp/'.$getftpfile->getClientOriginalName()), $getftpfile->getClientOriginalName());
                $mailData       =   array();
                $mailArray      =   array();
                $mailData['Title']      =   'PRR Report';
                $mailData['HeadLine']   =   'PRR Report';
                $mailData['ToName']     =   (count($bookexist)>=1?$bookexist->PE_NAME:'');
                $mailData['username']   =   Session::get('users')['user_name'];
                $mailArray['Data']      =   $mailData;
//                $mailArray['file']      =   file_get_contents(public_path('prrreportemailtemp/'.$getftpfile->getClientOriginalName()));
                $mailArray['file']      =   $getftpfile->getRealPath();
                $mailArray['attachfile']    =   array('as' => 'PRR Report.' . $getftpfile->getClientOriginalExtension(), 'mime' => $getftpfile->getMimeType());
                $mailArray['TemplateName']  =   'emailtemplate.download.prrNotification';
                $mailArray['Subject']   =   'PRR Activity/S5 Notification';
                $mailArray['FromMail']  =   'no-reply@spi-global.com';
                $mailArray['FromName']  =   'PRR Activity/S5 Notification';
//                $mailArray['ToMail']    =   $bookexist->PE_MAIL;
                $mailArray['ToMail']    =   'mohan.m@spi-global.com';
                $userid                 =   Session::get('users')['user_id'];
                $getusermailid          =   DB::table('user')->where('USER_ID',$userid)->first();
                
                if(count($getusermailid)>=1)
                {
                    if(!empty($getusermailid->EMAIL))
                    {
                        $mailArray['CcMail']    =   $getusermailid->EMAIL;
                    }
                }
                //$mailArray['CcMail']    =   array('vinoth.t@spi-global.com','ananth.b@spi-global.com');
                if (is_array($mailArray)) 
                {
                    Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) 
                    {
                        $message->subject($mailArray['Subject']);
                        $message->from($mailArray['FromMail'], $mailArray['FromName']);
                        $message->to($mailArray['ToMail']);
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                        if (array_key_exists('CcMail', $mailArray)) 
                        {
                            $message->cc($mailArray['CcMail']);
                        }
                        $message->getSwiftMessage();
                    });

                    if (Mail::failures()) 
                    {
                        $Response['Status']     =   2;
                        $Response['Msg']        =   'Failure';
                        $Response['MsgText']    =   Mail::failures();
                        $result             =   array('result'=>404,'errMsg'=>'Mail not has been sent');   
                        return response()->json($result,401);
                    } 
                    else 
                    {
                        $Response['Status']     =   1;
                        $Response['Msg']        =   'Success';
                        $jobdata                =   [];
                        $jobdata['PRR_REPORT_STATUS']   =   "1";
                        $jobdata['LAST_MOD_DATE']   =   Carbon::now();
                        $jobdata['LAST_MOD_BY']     =   Session::get('users')['user_id'];
                        $bookexist  =   jobInfoModel::updateJobdata($jobId,$jobdata);
                        //$success    =   File::cleanDirectory(public_path('prrreportemailtemp/'));
                        $result         =   array('result'=>200,'errMsg'=>'Email has been sent successfully!','response'=>$Response);   
                        return response()->json($result);
                    }
                }
                $result             =   array('result'=>404,'errMsg'=>'Mail not has been sent');   
                return response()->json($result,401);
            }
            $result             =   array('result'=>404,'errMsg'=>'Bad request sending');   
            return response()->json($result,401);
        }
        $result         =   array('result'=>0,'errMsg'=>'Invalid Access');   
        return response()->json($result,401);
    }*/
    
    
    
    public function jobSheetReturn($jobid, $metaId, $stageDetails, $metaDetails, &$metainfo) {
        $cmn_obj      =       new CommonMethodsController();
        $jbstg_rec = $stageDetails;
        $getlocationftp = productionLocationModel::doGetLocationname($jbstg_rec->JOB_ID);
        if (empty($getlocationftp))
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
        $getlocationftp->FTP_PASSWORD = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);

        $wheredata = ['ROUND_ID' => $this->round_ID_200];
        $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
        $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];

        $inp_rep_arr = array(
            'BOOK_ID' => $jbstg_rec->BOOK_ID,
            'ROUND_NAME' => $this->round_NAME_S200,
            'CID' => $metaDetails->CHAPTER_NO
        );
        
      
        $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
        //  echo "<pre>";print_r($serverDir);exit;
        $ftpObj = \Storage::createFtpDriver([
                    'host' => $getlocationftp->FTP_HOST,
                    'username' => $getlocationftp->FTP_USER_NAME,
                    'password' => $getlocationftp->FTP_PASSWORD, // 
                    'port' => '21',
                    'timeout' => '30',
        ]);
        
        $metainfo['jobSheetPath']   =   "";
        $serverDirFiles = $ftpObj->allFiles($serverDir);
        
        $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        
        // if S200 jobsheet not found job sheet get s50 job sheet
        if (empty($metainfo['jobSheetPath'])) {
            $wheredata = ['ROUND_ID' => $this->round_ID_50];
            $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
            $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
            $inp_rep_arr = array('BOOK_ID' => $jbstg_rec->BOOK_ID,'ROUND_NAME' => $this->round_NAME_S50);
            
            $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
           
            $serverDirFiles = $ftpObj->allFiles($serverDir);
            $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        }
        
        // if not found job sheet get s5 job sheet
        if (empty($metainfo['jobSheetPath'])) {
            $wheredata = ['ROUND_ID' => $this->round_ID_5];
            $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
            $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
            $inp_rep_arr = array('BOOK_ID' => $jbstg_rec->BOOK_ID,'ROUND_NAME' => $this->round_NAME_S5);
            $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
            $serverDirFiles = $ftpObj->allFiles($serverDir);
            $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        }
        return $metainfo;
    }
    
    
    public function getjobSheetReturn($jobid,$bookId, $metaId, $chapterNumber) {
        $cmn_obj      =       new CommonMethodsController();
       // $jbstg_rec = $stageDetails;
        $getlocationftp = productionLocationModel::doGetLocationname($jobid);
        if (empty($getlocationftp))
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
        $getlocationftp->FTP_PASSWORD = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);

        $wheredata = ['ROUND_ID' => $this->round_ID_200];
        $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
        $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];

        $inp_rep_arr = array(
            'BOOK_ID' => $bookId,
            'ROUND_NAME' => $this->round_NAME_S200,
            'CID' => $chapterNumber
        );
        
      
        $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
        //  echo "<pre>";print_r($serverDir);exit;
        $ftpObj = \Storage::createFtpDriver([
                    'host' => $getlocationftp->FTP_HOST,
                    'username' => $getlocationftp->FTP_USER_NAME,
                    'password' => $getlocationftp->FTP_PASSWORD, // 
                    'port' => '21',
                    'timeout' => '30',
        ]);
        
        $metainfo['jobSheetPath']   =   "";
        $serverDirFiles = $ftpObj->allFiles($serverDir);
        
        $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        
        // if S200 jobsheet not found job sheet get s50 job sheet
        if (empty($metainfo['jobSheetPath'])) {
            $wheredata = ['ROUND_ID' => $this->round_ID_50];
            $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
            $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
            $inp_rep_arr = array('BOOK_ID' => $bookId,'ROUND_NAME' => $this->round_NAME_S50);
            
            $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
           
            $serverDirFiles = $ftpObj->allFiles($serverDir);
            $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        }
        
        // if not found job sheet get s5 job sheet
        if (empty($metainfo['jobSheetPath'])) {
            $wheredata = ['ROUND_ID' => $this->round_ID_5];
            $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
            $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
            $inp_rep_arr = array('BOOK_ID' => $bookId,'ROUND_NAME' => $this->round_NAME_S5);
            $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
            $serverDirFiles = $ftpObj->allFiles($serverDir);
            $metainfo['jobSheetPath']   =   $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
        }
        return $metainfo;
    }
    
    public function productionJobSheetPathReturn($serverDirFiles,$getlocationftp){
        $xmlFilePath    =   "";
        if (!empty($serverDirFiles)) {
            if (!empty($serverDirFiles)) {
                foreach ($serverDirFiles as $serverDirFile) {
                    $jobsheetpath = substr(strrchr($serverDirFile, "/"), 1);
                    if (pathinfo($serverDirFile)['extension'] == 'xml' && strpos(strtolower($jobsheetpath), 'jobsheet') !== false) {
                        $xmlFilePath = $serverDirFile;
                    }
                }
            }

            if (!empty($xmlFilePath)) {
                $xmlFilePath = str_ireplace($getlocationftp->FTP_PATH, '', '/' . $xmlFilePath);
                $xmlFilePath = '////' . $getlocationftp->FTP_HOST . '/' . $getlocationftp->FILE_SERVER_PATH . '/' . $xmlFilePath;
            }
            $xmlFilePath    =   str_replace("//", "/", $xmlFilePath);
        }
        return $xmlFilePath;
    }
}
    
