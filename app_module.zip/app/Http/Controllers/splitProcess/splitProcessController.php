<?php

    namespace App\Http\Controllers\splitProcess;
    
    use App\Http\Controllers\Controller;
    use App\Models\downloadModel;
    use App\Models\bookinfoModel;
    use App\Models\apiProductionFileTransfer;
    use App\Models\jobModel;
    use App\Models\jobTimeSheet;
    use App\Models\productionLocationModel;    
    use Illuminate\Http\Request;
    use App\Http\Controllers\fileHandler\ftpFileHandlerController;
    use App\Http\Controllers\Api\productionFileTransferController;
    use App\Http\Controllers\taskLevelMeatadata\taskLevelMetadataController;
    use Illuminate\Support\Facades\Redirect;
    use App\Http\Controllers\CommonMethodsController;
    use Session;
    use Validator;
    use PDF;
    use DB; 
    use Illuminate\Http\Response;
    use Excel;
    use Mail;
    use Config;
    use Carbon\Carbon;
    use Illuminate\Support\Facades\Crypt;
   
    
    class splitProcessController extends Controller
    {   
        protected $splitstageName;
        protected $rootdir;
        public function __construct() {
            parent::__construct();
            $this->splitstageName   =   Config::get('constants.STAGE_NAME.SPLIT');
            $this->rootdir          =   Config::get('constants.FILE_SERVER_ROOT_DIR');
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
    
        
        public function index(){
             
            $data= array();
            $data['pageTitle'] = 'Production Location';
            $data['pageName']  = 'Production Location Information';
            $data['user_name'] =  $this->userName;
            $data['role_name'] =  $this->roleName;
            
            //echo 'View not defined ';
            //return view('location.location-list')->with($data);
            
        }
        
        public function projectList(){
                
            $data= array();
            $this->displayMenuName(Config::get('menuconstants.MENU.PRE_SPLIT_LIST'),$data);
            $data['user_name'] =  $this->userName;
            $data['role_name'] =  $this->roleName;
            $data['userId']    =  $this->loginUserId;
            
            return view('project.split-project-list')->with($data);
        }
        
        public function splitCompletedList(){
                
            $data= array();
            $this->displayMenuName(Config::get('menuconstants.MENU.PRE_SPLIT_COMPLIST'),$data);
            $data['user_name'] =  $this->userName;
            $data['role_name'] =  $this->roleName;
            $data['userId']    =  $this->loginUserId;
            
            return view('project.split-completed-project-list')->with($data);
            
        }
        
        
        public function getJobInfoForSplit( Request $request ){
            
            $response_out   =   array();
            $lo_userid      =   $this->loginUserId;
            $completedJob   =   0;
            if(!empty($request->input('status')))
                 $completedJob   =   1;
           
            $jb_obj         =   new jobModel();
            
            if($completedJob == '1'){
                $response_out['data']   = $jb_obj->getSplitCompletedProcessJobList($lo_userid);
            }else{
                $response_out['data']   =   $jb_obj->getSplitProcessJobList( $lo_userid );
            }                

            $response_out["user_id"] 	=   $this->loginUserId;
            $response_out["team_id"]    =   $this->teamId;
         
            return response()->json( $response_out );
            
        }
        
        public function checkout( Request $request , $jobId , $round ,$splitype, $token = null ){
            $data               =   array();
            if($splitype == "split")
            $this->displayMenuName(Config::get('menuconstants.MENU.PRE_SPLIT_LIST'),$data);
            else
            $this->displayMenuName(Config::get('menuconstants.MENU.PRE_SPLIT_COMPLIST'),$data);    
            $data['pageTitle']  =   'Checkout';
            $data['pageName']   =   'Split Process';
            $spliarray          =   ["split","resplit"];
            if(in_array($splitype,$spliarray)   ==  true){

                $bookdetails    =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                        ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                        ->where('job.JOB_ID',$jobId)
                                        ->get()->first();            

                $book_id        =   $data['book_id']    =   $bookdetails['BOOK_ID'];
                $roundId            =   $round;
                $data['job_title']  =    $bookdetails['JOB_TITLE'];
                $data['job_id']     =   $bookdetails['JOB_ID'];
                $round_arr          =   Config::get('constants.ROUND_ID');
                $round              =   'S5';            
                $data['due_date']   =   '';
                $data['stage']      =   $round;
                $data['activity']   =   'Chapter Spliting';
                $getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );
                //need to dynamicaly bind the production location based on table location
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   ($getlocationftp->FTP_PATH);

                $production_file_server_ip  =   $hostserver.$hostpath;
                $cn_user            =   $hostusername;
                $cn_pass            =   $hostpassword;
                $domainuser         =   Config::get('serverconstants.MAGNUS_DOMAIN_USERNAME');
                $domainpass         =   Config::get('serverconstants.MAGNUS_DOMAIN_PASSWORD');
                $credentials        =   '<>'.$domainuser.'<>'.$domainpass;
                $userWorkDir        =   Config::get('constants.USER_WORK_PATH');
                $userTempDir        =   Config::get('constants.USER_WORK_TEMP_PATH');
                $user_id            =   $this->loginUserId;
                $emp_id             =   $this->empId;
                $is_partial         =   false;
                $split_stage        =   Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS');
                $conditions         =   array( 'JOB_ID' =>  $jobId , 'ROUND_ID' => $round_arr['S5'] , 'STAGE' => $split_stage , 'CREATED_BY' => $user_id );
                $jts_obj            =   new jobTimeSheet();
                $records_of_tst     =   $jts_obj->getRecordsOfPartialCheckin( $conditions );
                $jst_obj            =   DB::table( 'job_time_sheet' )->select()
                                                ->where( 'JOB_ID', '=', $conditions['JOB_ID'] )
                                                ->where( 'ROUND_ID', '=', $conditions['ROUND_ID'] )
                                                ->where( 'STAGE', '=',  $conditions['STAGE'] )
                                                ->where( 'STATUS', '=',  1 )
                                                ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                                ->get()->first();
               $job_timesheet_id    =   '';
                if( !empty( $jst_obj ) ){
                   $job_timesheet_id2   =   $jst_obj->JOB_TIME_SHEET_ID; 
                }

                if( count( $records_of_tst ) > 0 ){
                    $is_partial         =   true;
                    $job_timesheet_id   =   $records_of_tst->JOB_TIME_SHEET_ID;
                }

                $const_replace          =   array(  
                                                    'USER_DIR' => $emp_id , 
                                                    'ROUND_NAME' => 'S5' , 
                                                    'STAGE_NAME' => Config::get('constants.STAGE_NAME.SPLIT') ,
                                                    'BOOK_ID' => $book_id , 
                                                    'JOB_TIME_SHEET_ID' => $job_timesheet_id
                                            );

                $split_dest_dir         =   Config::get('constants.SPLIT_DESTINATION_PATH');
                $split_src_dir          =   Config::get('constants.SPLIT_SOURCE_PATH').'/';
                if($splitype    ==  "split"){
                    $download_path          =   $production_file_server_ip.$split_src_dir.$book_id.'/';
                    $checkinTempSrcPath     =   $production_file_server_ip.$userWorkDir.$book_id.'/';

                    $checkinTempDestPath    =   $production_file_server_ip.$userTempDir;
                    if( !empty( $job_timesheet_id2 ) ){
                        $checkinTempDestPath    =   str_replace( 'JOB_TIME_SHEET_ID' , $job_timesheet_id2 , $checkinTempDestPath );
                    }
                    $checkinSrcPath         =   $production_file_server_ip.$userWorkDir.$book_id.'/';
                    $checkinDestPath        =   $production_file_server_ip.$split_dest_dir;
                    $checkoutSrcPath        =   $production_file_server_ip.$split_src_dir;

                    if( $is_partial ){
                        $checkoutSrcPath    =   $production_file_server_ip.$userTempDir; 
                    }
                    $openPath               =   $production_file_server_ip.$userWorkDir.$book_id.'/'.$credentials;
                    $root_dir               =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                    $openPath               =   $hostserver.$root_dir.$hostpath.$userWorkDir.$book_id.'/'.$credentials;
                    $openPath               =   str_replace( '//' , '/' , $openPath );
                    $checkoutDestPath       =   $production_file_server_ip.$userWorkDir.$book_id.'/';
                }else{
                    $bookidreplace          =   array(
                                                    'BOOK_ID'       =>  $book_id,
                                                    'STAGE_NAME'    =>  $this->splitstageName
                                                 );
                    
                    $cmn_obj                =   new CommonMethodsController();
                    $commonstagePath        =   $cmn_obj->arr_key_value_replace( $bookidreplace , $split_dest_dir , true );
                    
                    $download_path          =   $production_file_server_ip.$split_src_dir.$book_id.'/';
                    
                    $checkinTempSrcPath     =   $hostserver.$hostpath.$commonstagePath;
                    $checkinTempSrcPath     =   str_replace( '//' , '/' , $checkinTempSrcPath );
                    $checkinTempDestPath    =   $production_file_server_ip.$userTempDir;
                    if( !empty( $job_timesheet_id2 ) ){
                        $checkinTempDestPath    =   str_replace( 'JOB_TIME_SHEET_ID' , $job_timesheet_id2 , $checkinTempDestPath );
                    }
                    $checkinSrcPath         =   $production_file_server_ip.$userWorkDir.$book_id.'/';
                    $checkinDestPath        =   $production_file_server_ip.$split_dest_dir;
                    $checkoutSrcPath        =   $production_file_server_ip.$split_src_dir;

                    if( $is_partial ){
                        $checkoutSrcPath    =   $production_file_server_ip.$userTempDir; 
                    }
                    
                    $openPath               =   $hostserver.$this->rootdir.$hostpath.$commonstagePath.$credentials;                    
                    $openPath               =   str_replace( '//' , '/' , $openPath );
                    $checkoutDestPath       =   $production_file_server_ip.$userWorkDir.$book_id.'/';
                }
                
                foreach( $const_replace as $key => $value ){
                    $openPath               =   str_replace( $key , $value , $openPath );
                    $checkinTempSrcPath     =   str_replace( $key , $value , $checkinTempSrcPath );
                    $checkinTempDestPath    =   str_replace( $key , $value , $checkinTempDestPath );
                    $checkinSrcPath         =   str_replace( $key , $value , $checkinSrcPath );
                    $checkinDestPath        =   str_replace( $key , $value , $checkinDestPath );
                    $download_path          =   str_replace( $key , $value , $download_path );
                    $checkoutSrcPath        =   str_replace( $key , $value , $checkoutSrcPath );
                    $checkoutDestPath       =   str_replace( $key , $value , $checkoutDestPath );
                }
                
                $data['open_path']                      =   $openPath;
                $data['fhParam']['checkinTempSrcPath']  =   $checkinTempSrcPath;
                $data['fhParam']['checkinTempDestPath'] =   $checkinTempDestPath;
                $data['fhParam']['checkinSrcPath']      =   $checkinSrcPath;
                $data['fhParam']['checkinDestPath']     =   $checkinDestPath;
                $data['fhParam']['extension']           =   '';
                $data['fhParam']['methodName']          =   'fileServertoServer';
                $data['fhParam']['deleteFlag']          =   0;
                $data['fhParam']['download_path']       =   $download_path;
                $data['fhParam']['checkoutSrcPath']     =   $checkoutSrcPath;
                $data['fhParam']['checkoutDestPath']    =   $checkoutDestPath;
                $data['currentuserid']          =   $this->loginUserId;
                $api_rec        =       DB::table('api_production_file_transfer')->select()->where( 'TOKEN_KEY' , 'LIKE' , '%'.$token.'%')->get()->first();
                $data['isDownloaded']             =       0;
                if( !empty( $api_rec ) ){
                    if( $api_rec->STATUS == 2 ){
                       $data['isDownloaded']             =       2;
                    }
                }
                $data['backurl']        =   url('/').'/preproduction/split-job-list';
                
//                $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($job_id,$roundId,'insert','-'.Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'));
                
                return view('project.split-checkout')->with($data);
            }
            return redirect('preproduction/split-job-list');
        }
        
        public function startCheckOutProcess( Request $request ){
            $user_id    =   $this->loginUserId;
            $job_id     =   $request->input( 'job_id' );
            $inp_array  =   array();
            $round_arr      =       \Config::get('constants.ROUND_ID');
            $round  =    $round_arr['S5']; 
            
            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['errMsg']         =       'Invalid try , Try again after sometimes.';
                  
            $inp_arr['JOB_ID']        =     $job_id;
            $inp_arr['ROUND_ID']      =     $round_arr['S5'];  
            $inp_arr['STAGE']         =     \Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS');  //  FOR SPLIT PROCESS
            $inp_arr['TYPE']          =     3;  //  FOR SPLIT 
            $inp_arr['CHECK_OUT']     =     date( 'Y-m-d H:i:s' );  
            $inp_arr['CREATED_DATE']  =     date( 'Y-m-d H:i:s' );  
            $inp_arr['STATUS']        =     1;            
            $inp_arr['CREATED_BY']    =     $user_id;
            
            $jts_obj        =       new jobTimeSheet();
            
            //Check other jobs are handling by him
            $hasOtherJobInHand      =       $jts_obj->hasOtherJobCheckedOutEntry( $inp_arr );
            if( $hasOtherJobInHand ){
                
                $job_id =   $hasOtherJobInHand->JOB_ID;
                
                $bookdetails    =           bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                                ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                                ->where('job.JOB_ID',$job_id)
                                                ->get()->first();            
           
                $book_id     =       $data['book_id'] =      $bookdetails['BOOK_ID'];
            
                $response['errMsg']         =       'Invalid try , You had checked out this job already : [ '.$book_id.' ]';
                
                return response()->json( $response );
                
            }
            
            
            //Check already checkedout 
            $hasChecked     =       $jts_obj->hasCheckedoutEntry( $inp_arr );
            
            if( $hasChecked ){        
                
                $res_status     =   2;
                $response['msg']            =       'Success';
                $response['errMsg']         =       'Split process already in initialized mode.';      
                
            }else{   
                
                $res_status                 =       $jts_obj->insertNew($inp_arr);
                $response['msg']            =       'Success';
                $response['errMsg']         =       'Split process initialized..';     
                
            }
            
            if( $res_status == 2 ){
                
                $response['status']         =           1;
                $pft_obj                    =           new apiProductionFileTransfer();
                $inpArray['user_id']        =           $this->loginUserId;
                $rec_arr        =           array();
                
                $processtype    =       3;
                $process_list   =       \Config::get('constants.PRE_PRODUCTION_PROCESS_TYPE');
                $process_name   =       $process_list[$processtype];
        
                $condi_arr      =           array( 'USER_ID' => $inpArray['user_id'] , 'PROCESS_NAME' => $process_name );
                $rec_arr        =           $pft_obj->hasInProgressActivity( $job_id, $round , $condi_arr );
               
                if( count( $rec_arr )>=1 ){
                    $pft_token        =         $rec_arr->TOKEN_KEY;
                    $fileCopied       =         DB::table('api_production_file_transfer as pft')
                                                ->where( 'TOKEN_KEY' , 'LIKE' , '%'.$pft_token.'%' )                                            
                                                ->where('STATUS', '=', 2 )                                            
                    ->orderBy('pft.ID', 'desc')
                    ->get()->first();

                    if( !empty( $fileCopied )  ){
                        $rec_arr     =       $fileCopied;
                    }else{
                        unset( $rec_arr );
                    }
                    
                }
                
                if( !empty( $rec_arr ) ){
                    
                    $params     =       array(  'token_key' =>  $rec_arr->TOKEN_KEY );
                    $response['params'] =   $params;    
                
                }else{
                    try{
                        
                        $pft_cont       =       new productionFileTransferController();
                        $returns_stat   =       $pft_cont->fileTransferLog( $job_id , $round , $processtype , null );
                        
                        $params   =       !empty( $returns_stat['params'] ) ? $returns_stat['params'] : array();
                        $response['params'] =   $params;   
                        
                    }catch(\Exception $e){
                        
                        $response   =   array( 
                                'status' => 0, 
                                'msg'   => 'Failed' ,  
                                'errMsg'    => $e->getMessage()
                        );
                        return response()->json( $response,400 );
                        
                    }
                
                }
                
            }                   
            
            return response()->json( $response );
            
        }
       
        public function startCheckInProcess( Request $request ){
            
            $jobId		=	$job_id     =   $request->input( 'job_id' );
            $input_arr  =   $request->all();
            $inp_array  =   array();
            $round_arr      =       \Config::get('constants.ROUND_ID');
            
            
            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['errMsg']         =       'Invalid try , Try again after sometimes.';
            
            $inp_arr['CHECK_IN']    =       date('Y-m-d H:m:i');
            $job_id     =   $request->input( 'job_id' );
            $round      =    $round_arr['S5']; 
            $user_id    =   $this->loginUserId;
            $emp_id    =   $this->loginUserId;
            $stage      =     \Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS');  //  FOR SPLIT PROCESS
            
            $bookdetails    =       bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobId)
                                            ->get()->first();            
           
            $book_id     =       $data['book_id'] =      $bookdetails['BOOK_ID'];
            
            $sel_arr        =       array( 
                                            'JOB_ID'    =>      $job_id , 
                                            'ROUND_ID'  =>      $round  , 
                                            'ROUND_NAME' =>     'S5' , 
                                            'USER_ID'   =>      $emp_id , 
                                            'STAGE_NAME' => \Config::get('constants.STAGE_NAME.SPLIT') ,
                                            'STAGE'     =>      $stage  , 
                                            'BOOK_ID' => $book_id
                                            
                                    );
            
            $jts_obj            =           new jobTimeSheet();
            $record_info        =           $jts_obj->getCheckedOutRecords(  $sel_arr  );    
            
            $row_id             =           $record_info->JOB_TIME_SHEET_ID;
            
            $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id );
            
            $src_path           =       ( $input_arr['src_path'] ) ;
            $dest_path          =       ( $input_arr['dest_path'] ) ;
            
            
            //need to dynamicaly bind the production location based on table location
            
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ( $getlocationftp->FTP_PATH );
            
            $crd                =       Config::get('constants.FILE_SERVER_CREDENTIALS'); 
            
            try{
                // Production file transfer to temp directory
                
                $ftpObj         =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
                $response_copy       =       $ftpObj->ftp_dir_copy(  $crd.$src_path , $dest_path );
            
            }  catch (\Exception $e){
                
                $response   =   array(
                                'status' => 0, 
                                'msg'   => 'Failed' ,  
                                'errMsg'    => $e->getMessage()
                                );
                
               return response()->json( $response,400 );
            }
            
            if( in_array( 'failed' , $response_copy ) ){
            
                foreach ($response_copy as $key => $value ){
                    if( $value == 'success' ){
                        unset( $response[$key] );
                    }
                }
            
                $response_copy   =       array( 'status' => 'failed'  , $response_copy );

            }else{
                $response_copy    =       array( 'status' => 'success' , $response_copy );
            }
            
            $response   =       $response_copy;
            
            if( $response_copy['status'] == 'success' ){
                
                //update job time sheet check in time:
                $response       =   array();
                
                $array_jst['CHECK_IN']      =       date( 'Y-m-d H:i:s' ); 
                $update_res                 =       jobTimeSheet::updateIfExist( $array_jst ,  $row_id );
                $response['status']         =       1;
                $response['msg']            =       'Success';
                $response['errMsg']         =       'successfully transfered checkin files.';
                
            }else{
                
                //  $response   =       array( );
                
            }
                
            
            return response()->json( $response );
        }
        
        public function endSplitSubmit( Request $request ){
        
            $job_id     =   $request->input( 'job_id' );
            $input_arr  =   $request->all();
           // echo "<pre>";print_r($input_arr);exit;
            $inp_array  =   array();
            $round_arr      =       \Config::get('constants.ROUND_ID');            
            $response   =       array();
            $params     =       array();            
            
            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['msg']            =       'Invalid try , Try again after sometimes.';            
            
            $inp_arr['CHECK_IN']    =       date('Y-m-d H:m:i');
            $job_id         =       $request->input( 'job_id' );
            $round          =       $round_arr['S5']; 
            $round_name     =       $round_arr[$round];    
            
            $user_id    =       $this->loginUserId;
            $emp_id     =       $this->empId;
            $stage      =       \Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS');  //  FOR SPLIT PROCESS
            
            $bookdetails    =       bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID', $job_id )
                                            ->get()->first();            
           
            $book_id     =       $data['book_id'] =      $bookdetails['BOOK_ID'];
            $sel_arr     =       array( 
                                            'JOB_ID'    =>      $job_id , 
                                            'ROUND_ID'  =>      $round  ,
                                            'ROUND_NAME' =>     $round_name    ,   
                                            'USER_ID'   =>      $user_id , 
                                            'STAGE'     =>      $stage ,
                                            'BOOK_ID' => $book_id , 
                                            'STAGE_NAME' => \Config::get('constants.STAGE_NAME.SPLIT')
                                    );
            
            $jts_obj            =           new jobTimeSheet();
            $record_info        =           $jts_obj->getCheckedOutRecords(  $sel_arr  );  
            $row_id             =   '';
             
            if(count($record_info)>=1){
                $row_id         =           $record_info->JOB_TIME_SHEET_ID;
            }else{
                $response       =       array( 'result' => 404 , 'status' => '0' , 'msg' => 'Invalid Operation...!' );
                return response()->json( $response );
            }
                         
            $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id ); 
            
            $src_path           =           ( $input_arr['src_path'] ) ;
            $dest_path          =           ( $input_arr['dest_path'] ) ;
            $src_path           =   $src_path.'out/';
            //need to dynamicaly bind the production location based on table location
            
            $host   =   $hostserver     =       $getlocationftp->FTP_HOST;
            $usr    =   $hostusername   =       $getlocationftp->FTP_USER_NAME;
            $psw    =   $hostpassword   =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            
            $hostpath           =   ( $getlocationftp->FTP_PATH );
            
            $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
            $crd        =       'ftp://'.$usr.':'.$psw.'@'; 
           
            //call chapter open file method
            $tlmd                   =   new taskLevelMetadataController();
            $json_chapter_info      =   $tlmd->doChapterInfoOpen( $job_id , $crd.$src_path );
           
				return response()->json($json_chapter_info);
			}
		}