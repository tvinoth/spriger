<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\jobTimeSheet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class checkOutController extends Controller
{
    
    //Parameter would be jobid  , metaid , round id ,  jobstageid.
    
    public function checkOut( Request $request ){
       
        $data['pageTitle']      =       'CheckIn';
        $data['pageName']       =       'CheckIn';
        
       
        return view('checkout.checkout')->with($data);
        
    }
    
    public function checkIn(  Request $request ){
        
    }
}