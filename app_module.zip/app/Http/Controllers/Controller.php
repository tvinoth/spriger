<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Models\applicationMenuNameModel;
use App\Models\apiProductionFileTransfer;
use Session;
use Config;
use DB;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\dynamicConstantController;

class Controller extends BaseController {

    use AuthorizesRequests,
        DispatchesJobs,
        ValidatesRequests;

    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;
    protected $statusSuccess;
    protected $statusFailure;
    protected $statusInprogress;
    protected $statusEnumOne;
    protected $round_ID_5;
    protected $round_ID_50;
    protected $round_ID_200;
    protected $round_ID_300;
    protected $round_ID_600;
    protected $round_ID_650;
    protected $round_NAME_S5;
    protected $round_NAME_S50;
    protected $round_NAME_S200;
    protected $round_NAME_S650;
    protected $esm_FILE_FORMAT;
    protected $preProcessPath;
    protected $userWorkPath;
    protected $ftp_root_dir;
    protected $stagetypeEsm;
    protected $circleId;
    protected $manager;
    protected $statusCompleted;
    protected $successResponse;
    protected $insertedResponse;
    protected $insertedFailedResponse;
    protected $updatedResponse;
    protected $updatedFailedResponse;
    protected $deletedResponse;
    protected $deletedFailedResponse;
    protected $failedResponse;
    protected $notfoundResponse;
    protected $validationResponse;
    protected $nofileResponse;
    protected $fileNotCopiedResponse;
    protected $oopsErrorResponse;
    protected $mailSentResponse;

    public function __construct() {
        $dynmicConstObj  =   new dynamicConstantController();
        $this->loginUserId = Session::get('users')['user_id'];
        $this->teamId = Session::get('users')['team_id'];
        $this->roleId = Session::get('users')['role_id'];
        $this->empId = Session::get('users')['emp_id'];
        $this->circleId     =   Session::get('users')['circle_id'];
        $this->manager      =   Session::get('users')['manager'];
        $this->userName = Session::get('users')['user_name'];
        $this->roleName = Session::get('users')['role_name'];
        $this->statusSuccess = Config::get('constants.STATUS_ENUM.SUCCESS');
        $this->statusInprogress = Config::get('constants.STATUS_ENUM.INPROGRESS');
        $this->statusFailure = Config::get('constants.STATUS_ENUM.FAILURE');
        $this->statusEnumOne = Config::get('constants.STATUS_ENUM.ONE');
        $this->round_ID_5 = Config::get('constants.ROUND_NAME.S5');
        $this->round_ID_50 = Config::get('constants.ROUND_NAME.S50');
        $this->round_ID_200 = Config::get('constants.ROUND_NAME.S200');
        $this->round_ID_300 = Config::get('constants.ROUND_NAME.S300');
        $this->round_ID_600 = Config::get('constants.ROUND_NAME.S600');
        $this->round_ID_650 = Config::get('constants.ROUND_NAME.S650');
        $this->round_NAME_S5 = Config::get('constants.ROUND_NAME.104');
        $this->round_NAME_S50 = Config::get('constants.ROUND_NAME.114');
        $this->round_NAME_S200 = Config::get('constants.ROUND_NAME.116');
        $this->round_NAME_S650 = Config::get('constants.ROUND_NAME.120');
        $this->esm_FILE_FORMAT = ['.avi','.wmv','.mp4','.mov','.m2p','.mp2','.mpg','.mpeg','.flv','.mxf','.mts','.m4v','.3gp'];
        $this->preProcessPath = Config::get('serverconstants.PRE_PROCESSING_PATH');
        $this->userWorkPath   =   Config::get('serverconstants.USER_WORK_PATH');
        $this->statusCompleted  =   Config::get('constants.STATUS_ENUM_COLLEECTION.COMPLETED');
        $this->ftp_root_dir = Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
        $this->stagetypeEsm = Config::get('constants.STAGE_NAME.ESM');
        $this->insertedResponse     =   Config::get( 'errorconstants.201' );
        $this->insertedFailedResponse   =   Config::get( 'errorconstants.203' );
        $this->updatedResponse      =   Config::get( 'errorconstants.200' );
        $this->updatedFailedResponse    =   Config::get( 'errorconstants.205' );
        $this->deletedResponse      =   Config::get( 'errorconstants.204' );
        $this->deletedFailedResponse    =   Config::get( 'errorconstants.206' );
        $this->successResponse      =   Config::get( 'errorconstants.202' );
        $this->oopsErrorResponse    =   Config::get( 'errorconstants.400' );
        $this->validationResponse   =   Config::get( 'errorconstants.401' );
        $this->failedResponse   =   Config::get( 'errorconstants.402' );
        $this->notfoundResponse =   Config::get( 'errorconstants.404' );
        $this->nofileResponse   =   Config::get( 'errorconstants.101' );
        $this->fileNotCopiedResponse   =   Config::get( 'errorconstants.102' );
        $this->locationNotFoundResponse   =   Config::get( 'errorconstants.103' );
        $this->mailSentResponse     =   Config::get( 'errorconstants.104' );
        
    }
    
    public function displayMenuName( $ID =  null , &$data ){
        
        $where      =   [ 'application_menu_name.CODE' => $ID  ,   'transaction_menu.IS_ACTIVE' => 1 ];
        
        $getdata    =   applicationMenuNameModel::select( DB::Raw('application_menu_name.NAME,application_menu_name.SUBFIX_NAME,application_menu_name.PREFIX_NAME,'
                        . 'transaction_menu.TRANSACTION_NAME') )
                        ->join( 'transaction_menu' , 'transaction_menu.CODE', '=', 'application_menu_name.CODE')
                        ->Active()->where( $where )->first();
        
        if($getdata !=null ){
            
            if (strpos($getdata->TRANSACTION_NAME, '>>') !== false) {
                $childname = explode('>>', $getdata->TRANSACTION_NAME);
                $data['menuParent'] =   (isset($childname[0])?$childname[0]:'');
                $data['menuName']   =   (isset($childname[1])?$childname[1]:'');
                $data['subMenuChild']   =   (isset($childname[2])?$childname[2]:'');
                $data['pageTitle']      =   (isset($childname[1])?$childname[1]:'');
                $data['pageName']       =   $getdata->PREFIX_NAME.' '.$getdata->NAME.' '.$getdata->SUBFIX_NAME;
            }else{
                $data['menuParent'] =   '';
                $data['menuName']   =   $getdata->TRANSACTION_NAME;
                $data['subMenuChild']   =   '';
                $data['pageTitle']      =   $getdata->PREFIX_NAME.' '.$getdata->NAME.' '.$getdata->SUBFIX_NAME;
                $data['pageName']       =   $getdata->PREFIX_NAME.' '.$getdata->NAME.' '.$getdata->SUBFIX_NAME;
            }
            
        }else{
            
            $data['pageTitle']      =   'empty';
            $data['pageName']       =   'empty';
            $data['menuName']       =   'empty';
            $data['menuParent']     =   'empty';
            $data['subMenuChild']   =   'empty';
            
        }
        
    }

    public function displayRawfileButton($jobId =  null,&$data)
    {
        $where  =   ['USER_ID'=>$this->loginUserId,'JOB_ID'=>$jobId];
        $getrequestedraw    =   apiProductionFileTransfer::where($where)->orderBy('ID','desc')->first();
        if($getrequestedraw     !=  null){
            $data['rawbutton']  =   ($getrequestedraw->STATUS == 1?'NO':'YES');
            $data['rawbuttonrequestid']    =   ($getrequestedraw->STATUS == 1?$getrequestedraw->ID:0);
        }
        else{
            $data['rawbutton']    =   "YES";
            $data['rawbuttonrequestid']    =   "0";
        }
    }
	
	
    public function sendCmnMail( $mailArr ){
        
        $to     =   null;
        $cc     =   null ;
        $sub    =   null;
        $bdy    =   null;
        $bcc    =   null;
        
        $newCmc     =       new CommonMethodsController();
        extract( $mailArr );
        return $newCmc->sendMailNotify( $to , $cc , $sub , $bdy , $bcc , $attach );
        
        
    }
  

}
