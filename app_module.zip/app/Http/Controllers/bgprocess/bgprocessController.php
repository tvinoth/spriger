<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\bgprocess;
use App\Http\Controllers\Controller;
use App\Http\Controllers\users\usersController;
use App\Models\bgProcessModel;
use App\Models\jobModel;
use App\Models\jobStage;
use App\Models\stageModel;
use App\Models\checkoutModel;
use App\Models\eproofPackageModel;
use App\Models\bgprocessPathSetup;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\productionLocationModel;
use App\Models\bgprocessSubPathSetup;
use App\Models\bgprocessTagsSetup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\bgprocess\productionToolsController;
use App\Http\Controllers\Api\autostageController;
use App\Http\Controllers\contact\contactController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\Api\referencePdfController;
use App\Http\Controllers\Api\esmController;
use App\Http\Controllers\Api\esmFileNameController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\Api\packageController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\eproof\eproofController;
use App\Http\Controllers\Api\bookMergeController;
use App\Http\Controllers\Api\pitstopController;
use Session;
use Excel;
use Validator;
use Config;
use DB;
use Carbon\Carbon;
use Mail;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Log;
use App\Http\Controllers\bookinfo\bookinfoController;

class bgprocessController extends Controller
{ 
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public $packageinputfiles;
    
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
       
    public function index() {
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PRODUCTION_BG'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
	return view('bgprocess.bg-process')->with($data);	
    }
    
    public function bgprocessStatus() {
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PRODUCTION_BG'),$data);
        $data['pageTitle']  =   'BG Process Status';
        $data['pageName']   =   'BG Process Status';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
	return view('bgprocess.bg-process-status')->with($data);	
    }
    
    public function getBGTypes(){
        
        $arrData    =   array();
        
        $data       =   bgProcessModel::where('STATUS',true)->orderBy('ORDER_SEQ', 'ASC')->get();        
        $response   =   $this->successResponse;
        $response['bgtypes']    =   $data;
        return response()->json($response);
        
    }
    
    public function getRequiredReplacableConstantStringValue( $requirevarCollection = array(), $xmlStr ){
           
        $empid          =        \Session::get('users')['emp_id'];
        $username       =        \Session::get('users')['user_name'];
        
        try{
          
            extract( $requirevarCollection );
            
            $book_expo      =       explode(  '_' , $bookid );
            $bookid_no      =       $book_expo[0];
            $getlocationftp =        productionLocationModel::doGetLocationname( $jobid );
            
            //need to dynamicaly bind the production location based on table location
            $hostserver     =       $getlocationftp->FTP_HOST;
            $locationname   =       $getlocationftp->LOCATION_NAME;
            $rdir           =       str_replace( $getlocationftp->FTP_PATH , '' , $getlocationftp->FILE_SERVER_PATH );
            $lowrespath         =        null;
            $pagingfilnamingWithCno =    null;
            $pagingfilnaming    =        null;
            $componentattrname  =        '';

            if( !empty($metaid ) ){

                $chapterno3  =    $chapterno2         =        preg_replace( '/\D/', '', $chapterno );

			if( substr_count(strtoupper( $chapterno ) , 'CHAPTER' ) == 0){
				$chapterno2       =       ucfirst(strtolower(str_replace('_','',$chapterno)));
			}
			
                $ckey               =        preg_replace("/[0-9_]/", '', $chapterno);
			
                $chpatername        =        $chapterno;
                $revchpatername     =        $chapterno3.'_'.$ckey;
                $ucrevchpatername   =        $chapterno3.'_'.ucfirst( strtolower( $ckey ) );
            
           
                $rdir           =       substr( $rdir , 1);
                $rdir           =       str_replace(  '/' , '\\' ,  $rdir );

                $tsklvel        =       new taskLevelMetadataModel();
                $taskinfo       =       $tsklvel->getMetadatadetailsChapter( $metaid );
                $eproof         =   "";

                if( count( $taskinfo ) >= 1 ){
                    $eproof         =       ( $taskinfo[0]->EPROOFING_SYSTEM == 1 ) ? 'YES': 'NO';
                }

                $job_info       =       DB::table( 'job as j' )
                                            ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                            ->where( 'j.JOB_ID' , 'LIKE', '%'.$jobid.'%')
                                            ->select()
                                            ->get()->first();

                $round_arr      =       \Config::get( 'constants.ROUND_ID' );
                $roundname      =       $round_arr[$round];
                $rnoonly        =       preg_replace( '/\D/', '', $roundname );

                $publisher      =       $job_info->PUBLISHER_NAME;
                $issno          =       $job_info->ISSN_ONLINE;
                $issnp          =       $job_info->ISSN_PRINT;    
                $issnp          =       $job_info->ISSN_PRINT;    
                $platform2      =       $job_info->APPLICATION;
                $language       =       $job_info->LANGUAGE;
                $authorname     =       $job_info->AUTHOR_NAME;
                $trimsize       =       $job_info->FORMAT_TRIM_SIZE;
                $findlatestartround     =   'S200';
                $artmetatags    =       '';
                $pdfversionsetvalue     =   5;

                $pagObj             =       new autoPageController();
                $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chpatername , $metaid ); 
               
                extract( $paging_collect );
                $componentattrname      =       str_replace( "$bookid".'_' , '' , $pagingfilnaming );        

            }
            
            $artPCont           =       new artProcessController();           
            $availableJstag          =       strpos($xmlStr,"{AVAILABLEJOBSHEET}");
                        
            if(!empty($availableJstag)){
                $jobshhet_obj       =   new jobrevisedController();
                $metainfo           =   array();
                $sDetails           = (object) array('BOOK_ID' => $bookid, 'JOB_ID' => $jobid);
                $metaDetails        = (object) array('CHAPTER_NO' => $chpatername);
                $jobshhet_obj->jobSheetReturn($jobid , $metaid , $sDetails , $metaDetails,$metainfo);
               
                if(isset($metainfo['jobSheetPath'])){
                    $jobSheet   =   explode('/',$metainfo['jobSheetPath']);
                    $jobFilename = end($jobSheet);
                    
                    if(!empty($jobFilename)){
                        $metainfo['jobSheetPath']  = str_ireplace($jobFilename,'',$metainfo['jobSheetPath']);
                    }
                 
                    $availableJs  = $metainfo['jobSheetPath'];
                    if(!empty($availableJs))
                        $availableJs  = str_replace('/', '\\', $availableJs);
                }
            }
            
            if( isset( $arttags ) ){
                if($arttags == 1){
                    $artmetatags        =       $artPCont->getArtMetaDataTags($metaid);
                    
                }
            }
            
            if( strpos($xmlStr,"{FINDLATESTARTROUND}") ) {
                $gettinground       =       DB::select( 'select current_round from task_level_art_metadata where metadata_id  = '.$metaid.' limit 1' );
                if(count( $gettinground )){
                    if( isset( $gettinground[0] ) ){
                        $gettinground   =   $gettinground[0];
                    }
                    $findlatestartround     =   $round_arr[ $gettinground->current_round ];
                }
            }

            if( strpos($xmlStr,"{LOWRESPATH}") ) {

                $tlam_obj          =       new taskLevelArtMetadataModel();
                $art_info          =       $tlam_obj->getArtChapterwisefigureInfo( $metaid );
                $countart          =       count( $art_info );

                $gettinground      =       DB::select( 'select current_round from task_level_art_metadata where metadata_id  = '.$metaid.' limit 1' );

                if(count( $gettinground )){

                    if( isset( $gettinground[0] ) ){
                        $gettinground   =   $gettinground[0];
                    }

                    $findlatestartround     =   $round_arr[ $gettinground->current_round ];


                 $lowrespath              =              "\\\\$hostserver\\$rdir\\SP_BOOKS\\PRODUCTION\\$bookid\\$findlatestartround\\LOW_RES\\$chapterno"; //\Config::get( 'constants.PACKAGE_PATH.LOWRESIMAGEFOLDER' );

                }   

            }
            
            $reference_pdf_source   =   "";
            $reference_pdf_dest     =   "";
           
            if( isset( $ref_pdf_tags ) ){
                if($ref_pdf_tags == 1){
                    $reference_pdfinit      =   new referencePdfController();
                    $reference_pdf_source   =   $reference_pdfinit->prepareSourceDestFileTags($requirevarCollection,'xml','source');
                    $reference_pdf_dest     =   $reference_pdfinit->prepareSourceDestFileTags($requirevarCollection,'xml','dest');
                }
            }
            
            if( isset( $emsval_tags ) ){
                if($emsval_tags == 1){
                    $reference_pdfinit      =   new esmController();
                    $reference_pdf_source   =   $reference_pdfinit->prepareSourceDestFileTags($requirevarCollection,'xml','source');
                    
                }
                if($emsval_tags == 2){
                    $reference_pdfinit      =   new esmFileNameController();
                    $reference_pdf_source   =   $reference_pdfinit->prepareSourceDestFileTags($requirevarCollection,'xml','source');
                    
                }
            }
            

            
            $contactinformtags      =       '';
            if( isset( $contactinform ) ){
                if($contactinform == 1){
                    //must set 1 for tags preparation
                    $contactContObj       =       new contactController();
                    $contactinformtags    =       $contactContObj->getContactInromationPm( $jobid  , $round , 'xml' );
                }
            }
            
            $dateTime       =       date('Y-m-d_h-i-s');
            $array          =       $this->hookingLoadDynamicTickets( get_defined_vars() );

            return $array;
        
        }catch( \Exception $e ){
            
            throw new \Exception( $e->getMessage() );
        }
        
    }
    
    
    public function hookingLoadDynamicTickets( $requiredVar = array() ){
        
        extract( $requiredVar );
        
        return array(
            
            '{EMPID}'           =>      isset( $empid  )    ? $empid : ''     , 
            '{UNAME}'           =>      isset( $username )  ? $username : '', 
            '{RNAME}'           =>      isset( $roundname ) ? $roundname : ''   , 
            '{CNAME}'           =>      isset( $chpatername ) ? $chpatername : '', 
            '{REVCNAME}'        =>      isset( $revchpatername ) ? $revchpatername : '', 
            '{RID}'             =>      isset( $round ) ? $round : '' ,
            '{CAMELCNAME}'      =>      isset( $chpatername ) ? ucfirst( strtolower( $chpatername ) ) : '', 
            '{REVCAMELCNAME}'   =>      isset( $ucrevchpatername ) ? $ucrevchpatername : '', 
            '{BID}'             =>      isset( $bookid ) ? $bookid : '', 
            '{BIDNO}'           =>      isset( $bookid_no ) ? $bookid_no : '', 
            '{ISSNO}'           =>      isset( $issno ) ? $issno : ''    , 
            '{ISSNP}'           =>      isset( $issnp ) ? $issnp : '' ,
            '{CID}'             =>      isset( $chapterno ) ? $chapterno : '' , 
            '{CNO}'             =>      isset( $chapterno2 ) ? $chapterno2 : '', 
            '{CKEY}'            =>      isset( $ckey )  ? $ckey : ''   ,   
            '{EPROF}'           =>      isset( $eproof ) ? $eproof : '' ,
            '{PUBLISHER}'       =>      isset( $publisher ) ? $publisher : '' , 
            '{SIP}'             =>      isset( $hostserver ) ? $hostserver : ''  , 
            '{RDIR}'            =>      isset( $rdir ) ? $rdir : ''  ,
            '{APPURL}'          =>      \Config('app.url') , 
            '{JOBID}'           =>      isset( $jobid ) ? $jobid : '' , 
            '{JBSTGID}'         =>      isset( $jobstgid ) ? $jobstgid : '' ,
            '{METAID}'          =>      isset( $metaid ) ? $metaid : '' , 
            '{DATETIME}'          =>      isset( $dateTime ) ? $dateTime : '' , 
            '{CAMELCKEY}'       =>      isset( $ckey ) ? ucfirst( strtolower( $ckey ) ) : ( isset( $ckey ) ? $ckey : '' ) ,
            '{TKEY}'            =>      isset( $tokenkey ) ? $tokenkey : ''  , 
            '{ARTMETADATATAG}'  =>      isset( $artmetatags ) ? $artmetatags : '' , 
            '{AVAILABLEJOBSHEET}' =>    isset( $availableJs ) ? $availableJs : ''  , 
            '{ALLCHAPTER_DOCUMENT_SRC}'     =>  $reference_pdf_source  , 
            '{ALLCHAPTER_DOCUMENT_DEST}'    =>  $reference_pdf_dest  , 
            '{PLATFORM}'        =>      isset( $platform ) ? $platform : '' , 
            '{JOBPLATFORM}'        =>      isset( $platform2 ) ? $platform2 : '' , 
            '{PDFVERSION}'      =>      isset( $pdfversionsetvalue ) ? $pdfversionsetvalue : '' , 
            '{PROJECT_NAME}'    =>      isset( $publisher ) ? $publisher : 'SpringerBWF'  ,
            '{MODE}'            =>      isset( $mode ) ? $mode : '' , 
            '{PITSTOP_SRC_EXT}' =>      isset( $pitstopsrcext ) ? $pitstopsrcext : '' ,
            '{AUTOPAGE_EXTENSION}'       =>  isset( $autopageext ) ? $autopageext : '' ,
            '{TOOLSMACHINE_NAME}'   	 =>  isset( $toolsmachine_name) ? $toolsmachine_name : '',
            '{DISTILLER_APPLN_PATH}'   	 =>  isset( $distillerapppath) ? $distillerapppath : '' , 
            '{DISTILLER_SUCCESS_PATH}'   =>  isset( $distillerapppathSuccess) ? $distillerapppathSuccess : '' , 
            '{DISTILLER_FAILURE_PATH}'   =>  isset( $distillerapppathFail) ? $distillerapppathFail : '' , 
            '{DISTILLER_LINENUM_PATH}'   =>  isset( $distillerapppathLine) ? $distillerapppathLine : '' , 
            '{DISTILLER_HIGHRES_PATH}'   =>  isset( $distillerapppathHighresin) ? $distillerapppathHighresin : '' , 
            '{DISTILLER_HIGHLIN_PATH}'   =>  isset( $distillerapppathHighresLine) ? $distillerapppathHighresLine : '' , 
            '{DISTILLER_XMPFILE_PATH}'   =>  isset( $distillerapppathXmpin) ? $distillerapppathXmpin : '' ,  
            '{PM_CONTACT}'      =>      isset( $contactinformtags ) ? $contactinformtags : '' ,
            '{CHAPTER_TYPE}'    =>      isset( $chaptertype ) ? $chaptertype : '' ,
            '{PACKAGE_OPERATION}' =>    isset( $packageoperation ) ? $packageoperation : 'package' ,
            '{PACKAGEZIPNAME}'     =>   isset( $packagzipname ) ? $packagzipname : '' , 
            '{PDF_COMPARE_FILE_SUFFIX_VALUE}'   => isset( $iterationMinusone ) ? $iterationMinusone : '' ,
            '{PAGING_FILENAMING}'   =>  isset( $pagingfilnaming ) ? $pagingfilnaming : '' ,
            '{PAGINATION_FOLDER_NAME}'   => isset( $paginationFoldername ) ? $paginationFoldername : '' ,
            '{DELIVERABLETYPE}'         =>  isset( $producttype ) ? '[@type=&#39;'.strtolower($producttype).'&#39;]' : '',
            '{WITHPRINT}'       =>      isset( $withprint ) ? ( $withprint == 1) ? 'YES' : 'NO' : '' ,
            '{PREPARE_INPUT_OF_ALL_CHAPTERS}'   =>  isset( $prepareinputofallchapters )  ? $prepareinputofallchapters : '' ,
            '{OBSERVE_XML_DESTINATION_PATH}'   =>  isset( $observeDestination )  ? $observeDestination : '' ,
            '{LOCATION_NAME}'   =>  isset( $locationname ) ? $locationname : '',
            '{PACKAGINGCOMPATTR}'  =>  isset( $packagingCompattr ) ? $packagingCompattr : '',
            '{FMBMPARTJOBSHEETNAME}'	=>	isset( $fmbmpartjobsheetname ) ? $fmbmpartjobsheetname : '',
            '{LOWRESPATH}'   =>  ( isset( $lowrespath ) && !is_null( $lowrespath ) ) ?  $lowrespath : '' , 
            '{TKEY_OLD}'     =>  isset( $tokenkey_old )    ? $tokenkey_old : '' ,
            '{PACKAGEZIPNAMEOLD}'     =>   isset( $packagename_old )    ? $packagename_old : isset( $packagzipname )    ? $packagzipname : '' ,
            '{PAGEINFORMATION}' => isset( $pageinformation ) ? $pageinformation : '' , 
            '{APN_CHAPTER_INFO}'    => isset( $apn_chapter_info ) ? $apn_chapter_info : '' ,
            '{APP_EXT}'    => isset( $apln_ext ) ? $apln_ext : '' , 
            '{PACKAGE_START_AT}'    => isset( $resumepackageat ) ? $resumepackageat : 0 , 
            '{AUTHORNAME}'  => isset( $authorname ) ? $authorname : '' , 
            '{TRIMSIZE}'    =>  isset( $trimsize ) ? $trimsize  : '' , 
            '{EDITION}'     =>  isset( $edition ) ? $edition  : '' , 
            '{PMNAME}'      => isset( $pmname ) ? $pmname : ''     , 
            '{LANGUAGE}'    => isset( $language ) ? $language : '' , 
            '{FINDLATESTARTROUND}' => isset($findlatestartround) ? $findlatestartround : '' , 
            '{RNO}'         => isset($rnoonly) ? $rnoonly : '' , 
            '{CURSTGCHAPTER_XML}' => isset( $curuserchpxml ) ? $curuserchpxml : 'curuserchpxml' ,
            '{JOBSHEET_PATH}' => isset( $jobsheetpath ) ? $jobsheetpath : '' ,             
            '{BOOK_ONLINE_PDF}' => isset( $online ) ? $online : '',
            '{BOOK_PRINT_PDF}' => isset( $print ) ? $print : '',
            '{BOOK_MYCOPY_PDF}' => isset( $mycopy ) ? $mycopy : '',
            '{BOOK_SCOPY_PDF}' => isset( $scopy ) ? $scopy : '',
            '{S600_COMPONENT_INFO}' => isset($S600packagedata) ? $S600packagedata : '',
            '{AllCOMPONENTEPROOF}'  =>  isset($allcomponenteproof) ? $allcomponenteproof : '' ,
            '{DESTINATIONPATH}'     =>  isset($destinationpath) ? $destinationpath : '' ,
            '{VENDORXMLPATH}'       =>  isset($vendorxmlpath) ? $vendorxmlpath : '',
            '{BOOKARTMETADATATAG}'  =>  isset($bookartdata) ? $bookartdata : '',
			'{ARTILLUSTRACTION}'  =>  isset($bookartillusdata) ? $bookartillusdata : '',
			'{CORRECTIONORINDEX}'  =>  isset($correctionorindex) ? $correctionorindex : '',
			'{INDEXCOMPONENT}'  	=>  isset($indexComponent) ? $indexComponent : '',
            '{AUTHORPDFSOURCE}'     =>  isset( $authorpdfComponentpaths ) ? $authorpdfComponentpaths : '',
			'{RESUMECOMPONENTAT}' 	=>  isset( $resumecompoat ) ? $resumecompoat : '' , 
			'{RESUMEPAGENOFROM}'   =>  isset( $resumepagenofrom ) ? $resumepagenofrom : '' , 
            '{COMPONENTATTRNAME}'    =>  isset( $componentattrname ) ? $componentattrname : '' , 
            '{WORKFLOWBASEDPAGINATIONPATH}'    =>  isset( $workflowPagintnpath ) ? $workflowPagintnpath : '' , 
            '{WORKFLOWBASEDCHAPTERXMLPATH}'    =>  isset( $workflowChapterpath ) ? $workflowChapterpath : '' , 
            '{WORKFLOWBASEDDELTAPDFPATH}'    =>  isset( $workflowDeltapath ) ? $workflowDeltapath : '' , 
            '{METAPDFREQUIRED}'    =>  isset( $metapdfrequired ) ? $metapdfrequired : 'N' ,  
       
        );
        
        
    }
         
    public function replaceRequireKeysToValues( $xmlStr , $metadatainfo ){
        
        $cmn_obj             =       new CommonMethodsController(); 
              
        $inp_rep_arr         =       $this->getRequiredReplacableConstantStringValue( $metadatainfo, $xmlStr );
        $xmlStr              =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlStr );
        
        return $xmlStr;
        
    }
    
    public function getFailedretry( Request $request) 
    {
        
        try{
            $response   =   $this->failedResponse;
            $validation         =   Validator::make($request->all(), [
                                                    'processid'     => 'required|numeric',
                                                    'status'        => 'required'
                                            ]);
            
            if($validation->fails()){
                $response['errMsg'] =   'BG Type is required';
                return response()->json($response);
            }
            
            $status     =   $request->input('status');
            $type       =   $request->input('processid');
            
            $data       =   bgProcessModel::getChapterlevelretry( $type , $status );  
            $response   =   $this->successResponse;
            $response['downloadfailed']   =   $data;
            return response()->json($response);  
            
        }catch( \Exception $e ){           
            return response()->json($this->locationNotFoundResponse,400);
        }
        
    }
     
    public function getToolsMachineInformation( $metainfo , $autopageinput ){
        
        $jobid                      =       $metainfo['jobid'];
        $getlocationftp             =       productionLocationModel::doGetLocationname( $jobid );
        
        $locationid                 =       $getlocationftp->PRODUCTION_LOCATION;
        $output_arr                 =       array();  
        
        if( isset( $autopageinput['platform'] ) ){

            $platformoption             =       $autopageinput['platform'];

            $prdToolCont        =       new productionToolsController();
            
            $mode_opt           =       $autopageinput['mode'];
            
            switch( $platformoption ){

                case 'ADOBE INDESIGN' : 
                    $output_arr['toolsmachine_name']  =     $prdToolCont->getLocationAplicationBasedToolsMachineName( $platformoption , $locationid , $mode_opt );
                        break;

                case '3B2' :  
                    $output_arr['toolsmachine_name']  =     $prdToolCont->getLocationAplicationBasedToolsMachineName( $platformoption , $locationid , $mode_opt );
                        break;
                
                case 'LATEX' :  
                    $output_arr['toolsmachine_name']  =     $prdToolCont->getLocationAplicationBasedToolsMachineName( $platformoption , $locationid , $mode_opt );
                        break;

                default:  
                    $output_arr['toolsmachine_name']  =     $prdToolCont->getLocationAplicationBasedToolsMachineName( $platformoption , $locationid );
                        break;

            }

        }
        
        return $output_arr;
    }
    
    public function getDistillerPathInformation( $metainfo , $autopageinput ){
        
        $jobid                      =       $metainfo['jobid'];
        $getlocationftp             =       productionLocationModel::doGetLocationname( $jobid );
        
        $locationid                 =       $getlocationftp->PRODUCTION_LOCATION;
        $output_arr                 =       false;  
        
        if( isset( $autopageinput['platform'] ) ){

            $platformoption     =       $autopageinput['platform'];
            $prdToolCont        =       new productionToolsController();
            $mode_opt           =       $autopageinput['mode'];
            $producttype        =       $autopageinput['producttype'];
            $round              =       $autopageinput['roundidinfo'];
                    
            switch( $platformoption ){

                case 'ADOBE INDESIGN' : 
                    $output_arr  =     $prdToolCont->getLocationAplicationBasedToolsPathInfo( $mode_opt , $locationid , $platformoption , $round , $producttype );
                    break;
                case '3B2' :  
                    $output_arr  =     $prdToolCont->getLocationAplicationBasedToolsPathInfo( $mode_opt , $locationid , $platformoption , $round , $producttype);
                    break;
                case 'LATEX' :  
                    $output_arr  =     $prdToolCont->getLocationAplicationBasedToolsPathInfo( $mode_opt , $locationid , $platformoption , $round , $producttype);
                    break;
                default:  
                    $output_arr  =     $prdToolCont->getLocationAplicationBasedToolsMachineName( $mode_opt , $locationid );
                    break;

            }

        }
        
        return $output_arr;
    }
    
	public function pitstopResponseSignalReceive( $inputarr ){
        
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        
        $response                   =   $this->failedResponse;
        $atstgContr                 =           new autostageController();
        $controllername             =           'pitstopController';
        //$controllername             =           $atstgContr->getContorllerNameOfTheSignal( $inputarr );   
        
        if( isset( $controllername ) && !is_null( $controllername ) ){
        
            $controllerPath             =           'App\\Http\\Controllers\\Api\\'.$controllername;        
            $rules                      =           app($controllerPath)->validationRuleForResponseSignal(); 
            $validator                  =           Validator::make( $inputarr , $rules );
            
                if ($validator->fails()) {                           
                    $response['errMsg']      =        json_encode( $validator->errors()->all() );               
                }else{ 
                   
                    $token_key              =      $inputarr['tokenkey'];
                    $modelname              =      isset( app($controllerPath)->apiModel ) ? app($controllerPath)->apiModel : 'apiFigureValidation';                
                    $sigModel_obj           =      app( "App\\Models\\$modelname" );           
                    
                    $getRec                 =      $sigModel_obj->getApiRequestByTokenKey( $token_key );
                    
                        if(!empty( $getRec )){

                            $insertArr      =       array();
                            $this->prepareUpdationValues( $inputarr , $insertArr );

                            $rowid              =           $getRec->ID;
                            $_status            =           $sigModel_obj->updateIfExist( $insertArr , $rowid ); 
                            
                            if( $_status ){
                                $response                   =   $this->successResponse;
                                $response['errMsg']         =       'Signal Received Successfully';

                            }else{
                                $response['errMsg']         =       "Signal Received Successfully ";
                            }

                        }else{
                            
                            $response['errMsg']         =       'Invalid try , [ Reason : Invalid tokenkey or Signal already received for this tokenkey ]';
                            
                        }                
                }
        }else{   
            
            $response['errMsg']     =       ' Reason  : Controller element vaule is missing.';           
            
        }
        
        return $response;
        
    }
	
    public function bgprocessResponseSignalReceive( $inputarr ){
        
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        
        $response                   =   $this->failedResponse;
        $atstgContr                 =           new autostageController();
        //$controllername             =           'autoPageController';
        $controllername             =           $atstgContr->getContorllerNameOfTheSignal( $inputarr );   
        
        if( isset( $controllername ) && !is_null( $controllername ) ){
        
            $controllerPath             =           'App\\Http\\Controllers\\Api\\'.$controllername;        
            $rules                      =           app($controllerPath)->validationRuleForResponseSignal(); 
            $validator                  =           Validator::make( $inputarr , $rules );
            
                if ($validator->fails()) {                           
                    $response['errMsg']      =        json_encode( $validator->errors()->all() );               
                }else{ 
                   
                    $token_key              =      $inputarr['tokenkey'];
                    $modelname              =      isset( app($controllerPath)->apiModel ) ? app($controllerPath)->apiModel : 'apiFigureValidation';                
                    $sigModel_obj           =      app( "App\\Models\\$modelname" );           
                    
                    $getRec                 =      $sigModel_obj->getApiRequestByTokenKey( $token_key );
                    
                        if(!empty( $getRec )){

                            $insertArr      =       array();
                            $this->prepareUpdationValues( $inputarr , $insertArr );

                            $rowid              =           $getRec->ID;
                            $_status            =           $sigModel_obj->updateIfExist( $insertArr , $rowid ); 
                            
                            if( $_status ){
                                $response                   =   $this->successResponse;
                                $response['errMsg']         =       'Signal Received Successfully';

                            }else{
                                $response['errMsg']         =       "Signal Received Successfully ";
                            }

                        }else{
                            
                            $response['errMsg']         =       'Invalid try , [ Reason : Invalid tokenkey or Signal already received for this tokenkey ]';
                            
                        }                
                }
        }else{   
            
            $response['errMsg']     =       ' Reason  : Controller element vaule is missing.';           
            
        }
        
        return $response;
        
    }
       
    public function prepareUpdationValues( $inputarr , &$output ){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        if( isset( $inputarr['startprocess'] ) ){
            $output['PACKAGE_RESUME_AT']           =        $inputarr['startprocess'];
        }
        if( isset( $inputarr['finalZipName'] ) ){
            $output['NEW_PACKAGE_NAME']           =        $inputarr['finalZipName'];
        }
        
        return $output;
    }
   
    public function bgprocessSignalLogging( $receive_arr , $given_array ){
        
        $insert_arr     =       array();
            
            if( isset( $receive_arr['process'] ) )
                $insert_arr['PROCESS_NAME']         =       $receive_arr['process'];
            
            if( isset( $receive_arr['tokenkey'] ) )
                $insert_arr['TOKEN_KEY']            =       $receive_arr['tokenkey'];
            
            if( isset( $receive_arr['ERROR_ID'] ) )                
                $insert_arr['ERROR_ID']             =       $receive_arr['ERROR_ID'];
            
            if( !empty( $receive_arr ) )
                $insert_arr['SIGNAL_RECEIVED']      =       json_encode( $receive_arr );
            
            if( !empty( $given_array ) )
                $insert_arr['RESPONSE_GIVEN']       =      json_encode( $given_array );
            
            
        return DB::table('bgprocess_signal_log')->insertGetId( $insert_arr );
        
    }
    
    public function jobassigned(){
        
        $arrData    			=   array();
        $data                    	=   downloadModel::getJobassigned(); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45'); 
        $datanew                        =   [];
        foreach($data   as $key=>$value)
        {
            $datanew[$key]['JOB_ID']    =   $value->JOB_ID;
            $datanew[$key]['BOOK_ID']   =   $value->BOOK_ID;
            $datanew[$key]['ROUND_ID']  =   $value->ROUND_ID;
            $datanew[$key]['ROUND']     =   $value->ROUND;
            $datanew[$key]['ROUND_NAME']    =   $value->ROUND_NAME;
            $datanew[$key]['ACTIVE']    =   $value->ACTIVE;
            $datanew[$key]['JOB_TITLE'] =   $value->JOB_TITLE;
            $datanew[$key]['LOCATION']  =   $value->LOCATION;
            $datanew[$key]['JOB_ASSIGNED_DATE']     =   $value->JOB_ASSIGNED_DATE;
            $datanew[$key]['receivedDate']  =   $value->receivedDate;
            $datanew[$key]['ISSN_ONLINE']   =   $value->ISSN_ONLINE;
            $datanew[$key]['PMname']    =   $value->PMname;
            $datanew[$key]['PM']        =   $value->PM;
            if (is_numeric($value->AM)) 
            {
                $datanew[$key]['AM']    =   (string)$value->AM;
            }
            else
            {
                $datanew[$key]['AM']    =   '';
            }
            
            $datanew[$key]['AM_NAME']   =   $value->AM_NAME;
            $datanew[$key]['JOB_SHEET_UPDATE']  =   $value->JOB_SHEET_UPDATE;
            $datanew[$key]['UPDATE_REMARKS']    =   $value->UPDATE_REMARKS;
            $datanew[$key]['JOB_SHEET_UPLOAD']  =   $value->JOB_SHEET_UPLOAD;
            $datanew[$key]['UPLOAD_REMARKS']    =   $value->UPLOAD_REMARKS;
            $datanew[$key]['SUCCESS_REDO']      =   $value->SUCCESS_REDO;
            $datanew[$key]['SR_REMARKS']        =   $value->SR_REMARKS;
            $datanew[$key]['SHEET_FLAG']        =   $value->SHEET_FLAG;
        }
        $response["jobassigned"] 	= 	$datanew;
        $response['amUserList']  	= 	$getuserListByRole;	
        return response()->json($response);
    }
	
    public function getJobXMLInfo( $jobId = 0 , $round ) {
        
            $jobXMLInfo = downloadModel::getJobXMLInfo($jobId);
            
            
            $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
            
            if( empty( $getlocationftp ) )            
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            
            // Do the FTP connection
            
	    $ftpObj = \Storage::createFtpDriver([
		'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
		'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
		'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
		'port'     => '21',
		'timeout'  => '30',
            ]);  
             
                $round_arr      =       \Config::get('constants.ROUND_NAME');
                $round_name     =       $round_arr[$round];
		$xmlFilePath = '';
                $replace_bf =       array( '' );
                $jobAssignedConst   =       \Config::get('constants.JOB_ASSIGNED_CONST');
                $book_id            =       $jobXMLInfo->BOOK_ID;
		$serverDir = $hostpath.\Config::get('constants.UPDATED_JOBSHEET_PATH'); 
                
                $inp_rep_arr    =   array( 
                   'BOOK_ID'       =>      $book_id , 
                   'ROUND_NAME'    =>      $round_name                        
                );
                 
                $cmn_obj            =       new CommonMethodsController();
                $serverDir  =  $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
                $serverDirFiles = $ftpObj->allFiles($serverDir);
		
                if(!empty($serverDirFiles)) {
                    foreach($serverDirFiles as $serverDirFile) {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') {
                            $xmlFilePath = $serverDirFile;
                        }
                    }
		}
		
		if($xmlFilePath == '') {
                     return '<p class="text-center"> Required jobsheet xml files is not available.</p>';
		}
                
                try{
                $filePath = '/' . $xmlFilePath;
            	$filecontent = $ftpObj->get($filePath); // read file content
		
		$xmlPath = base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
		$xslFilePath = base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
		
		// LOAD XML FILE CONTENT
		$XML = new \DOMDocument(); 
		$XML->loadXML($filecontent);

		// START XSLT 
		$xslt = new \XSLTProcessor(); 

		// IMPORT STYLESHEET
		$XSL = new \DOMDocument(); 
		$XSL->load( $xslFilePath ); 
		$xslt->importStylesheet( $XSL ); 

		echo $xslt->transformToXML( $XML );
                
                }catch( \Exception $e ){
                    
                    echo '<code> Invalid xml</code><br/>';  
                    echo $e->getMessage();
                }
                
		exit();

	}
    
    //redo view 
    public function getRedoview(Request $request){
        
        $jobRedoview 	= 	downloadModel::getRedoview($request->input('ID'));
        if(count($jobRedoview)>=1)
        {
                // Do the FTP connection
            
                $ftpObj 	= 	\Storage::createFtpDriver([
                        'host'     => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST'), 
                        'username' => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME'),
                        'password' => Crypt::decryptString(\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD')), // 
                        'port'     => '21',
                        'timeout'  => '30',
                  ]);

                $xmlFilePath 		= 	'';
                $jobAssignedConst 	= 	\Config::get('constants.JOB_ASSIGNED_CONST');
                
                $bookid 			=	$request->input('BOOK_ID');
                $serverDir 			= 	\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PATH') . $bookid . '/'.$jobAssignedConst;			
                $serverDirFiles 	=	 $ftpObj->allFiles($serverDir);
                if(!empty($serverDirFiles)) 
                {
                        $filePath 		= 	$serverDir.'/test.txt';
                        $filecontent 	= 	$ftpObj->get($filePath); // read file content
                        echo $filecontent;exit;
                }
                else
                {
                        echo '<p class="text-center">No Data found.</p>';
                        exit();
                }
        }

    }
        
    public function JobassignedtoAmUser(Request $request){
       
        if ($request->input('user_id') > 0) {
            
            $Req = (object) $request->input();
            $arrData    =   array();
            $arrData['user_id']       =    $request->input('user_id');
            $arrData['book_id']       =    $request->input('book_id');
            $bookDetails              =    downloadModel::getBookDetails($arrData['book_id']);
            $jobId                    =     '';
            
            if(!empty($bookDetails)){
              $arrData['BookTitle']   =  $bookDetails->JOB_TITLE;
              $jobId    =   $bookDetails->JOB_ID;
              $arrData['ISSN_PRINT']        =   $bookDetails->ISSN_PRINT;
              $arrData['receivedDate']      =   $bookDetails->CREATED_DATE;
              $arrData['AUTHOR_NAME']       =   $bookDetails->AUTHOR_NAME;
            }
            
            $userDetails              =    downloadModel::getUserDetails($arrData['user_id']);
            $arrData['AM_Mail']       =     $userDetails->EMAIL;
            $arrData['AM_name']       =     $userDetails->userName;
            $assignedJob              =     downloadModel::JobAssignedToAmUserMod($arrData,$jobId);
            
            if($assignedJob['0']    ==  'success' ){
                $this->newJobNotificationMail($arrData);
            }
            
            /*  
             *  $this->assignPEmail($arrData);
                $this->assignPMmail($arrData);
            */
            
            $response   =   $this->failedResponse;
            $response['msg'] = "Assigning process failed.";
            $response['errMsg'] = "Try again, after sometimes.";
            if($assignedJob['0'] == 'success'){                
                $response['msg'] = "Successfuly Assigned to new Account Manager";
                $response['errMsg'] = 'Successfully Assigned.';
                $response['status'] = 1;
            }
            
            return response()->json($response);
            
        }
        
    }
    
    public function getCucJobXMLInfo(Request $request) 
    {
        $response   =   $this->locationNotFoundResponse;
        $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
        if(count($getlocationftp)>=1)
        {
            $roundid        =   $request->input('roundid');
            $stageid        =   $request->input('stageid');
            $roundname      =   $request->input('roundname');
            $stagename      =   $request->input('stagename');
            $metaid         =   $request->input('metadataid');
            $jobId          =   $request->input('jobId');
            $Chapter        =   $request->input('Chapter');
            $bookid         =   $request->input('bookid');
            
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            // Do the FTP connection
            $ftpObj         =   \Storage::createFtpDriver([
                                                'host'     => $hostserver, 
                                                'username' => $hostusername,
                                                'password' => $hostpassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
            $getuserid          =   Session::get('users')['emp_id'];
            $cucuserworkfolder  =   Config::get('constants.WATCH_CE_ESTIMATION_FOLDER');
            $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
            if(!empty($cucDirFiles)) 
            {
                 foreach($cucDirFiles as $serverDirFile) 
                 {
                    if(pathinfo($serverDirFile)['extension'] == 'xml') 
                    {
                        $xmlFilePath    =   $serverDirFile;
                    }
                }
                if($xmlFilePath == '') 
                {
                    $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                    return response()->json($response);
                }
                
                $filePath       =   '/' . $xmlFilePath;
                // $filecontent = self::xmlSampleContent();
                $filecontent    =   $ftpObj->get($filePath); // read file content
                $xmlPath        =   base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
                $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';

                // LOAD XML FILE CONTENT
                $XML = new \DOMDocument(); 
                $XML->loadXML($filecontent);

                // START XSLT 
                $xslt = new \XSLTProcessor(); 

                // IMPORT STYLESHEET
                $XSL = new \DOMDocument(); 
                $XSL->load( $xslFilePath ); 
                $xslt->importStylesheet( $XSL ); 
                $response       =   $this->successResponse;
                $response['errMsg']     =   $xslt->transformToXML( $XML );
                $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                return response()->json($response);
            }
            $response   =   $this->nofileResponse;
            return response()->json($response);
        }
        return response()->json($response);
    }
    
    public function getCucXMLInfo(Request $request) 
    {
        $response   =   $this->locationNotFoundResponse;
        
        try
        {
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $roundid        =   $request->input('roundid');
                $stageid        =   $request->input('stageid');
                $roundname      =   $request->input('roundname');
                $stagename      =   $request->input('stagename');
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');

                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $cucuserworkfolder  =   $hostpath.Config::get('constants.CUC_CHECKOUT_FOLDER').$bookid.'/'.$Chapter;
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }

                    if($xmlFilePath == '') 
                    {
                        $response['errMsg']   =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'cucview.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $response   =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                $response   =   $this->nofileResponse;
                $response['xmlcount']   =   $xslt->transformToXML( $XML );
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            return response()->json($response);
        }
    }
    
    public function newJobNotificationMail($amDetails){
        
        $mailArray = $mailData = array();

        $mailData['Title']      = 'Acknowledgement';
        $mailData['HeadLine']   = 'New Title has arrived';
        $mailData['ToName']     = $amDetails['AM_name'];
        $mailData['authorname'] = $amDetails['AUTHOR_NAME'];
        $mailData['BookId']     = $amDetails['book_id'];
        $mailData['BookTitle']  = $amDetails['BookTitle'];
        $mailData['BookIsbn']   = $amDetails['ISSN_ONLINE'];
        $mailData['ReceivedDate']   = $amDetails['receivedDate'];
        $mailArray['Data']       = $mailData;
        $mailArray['TemplateName'] = 'emailtemplate.download.newjobAssign';
       // $mailData['Title'] = 'New Quote Created';
      
        $mailArray['Subject'] = 'New Title Arrival Alert - '.$amDetails['book_id'];
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']    =   $amDetails['AM_Mail'];
        $mailArray['CcMail']    =   Config::get('constants.CC_EMAIL_LIST');
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
         
    public function sendMailBladeTemplate($mailArray) {
        
        if (is_array($mailArray)) {
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }

                $message->getSwiftMessage();
            });

            if (Mail::failures()) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['MsgText'] = Mail::failures();
            } else {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }

            return $Response;
        }

    }
    
    public function sendMailNofity(  $purpose  ,  $template_name  , $info_arr ){
        
       switch( $purpose )
       {
           case 'productionLocationChange':
                //send to pm , related am alert mail notification for location change
                //re send job assigned notificaiton mail
           
               break;
           case 'newJobAssignment':
                
               break;
           
           default:
               break;
           
       }  
    }
        
    //chapter download 
    public function chapterdownloadList() 
    {   
        $data['pageTitle']  =   Config::get('constants.ROUND_NAME.116').' Download';
        $data['pageName']   =   Config::get('constants.ROUND_NAME.116').' Download';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data['role_id']    =   Session::get('users')['role_id'];
	return view('download.chapter-download')->with($data);	
    }
    
    public function getChapterdownloadFailedList() 
    {	
        $data       =   downloadModel::getChapterdownoadlist();           
        $response["downloadfailed"]     =   $data;
        return response()->json($response);   
    }
    
    public function doChapterlevelassignedlist(){
        
        $arrData    			=   array();
        $data                    	=   downloadModel::getChapterlevelassigned(); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45'); 
        $response["jobassigned"] 	=   $data;
        $response['amUserList']  	=   $getuserListByRole;	
        return response()->json($response);
    }
    
    public function getChapterjobsheetview(Request $request) 
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric',
                                                'metadataid' 	=> 'required',
                                                'Chapter' 	=> 'required',
                                                'bookid' 	=> 'required',
                                                'roundid' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId          =   $request->input('jobId');
            $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $roundid        =   $request->input('roundid');
                $roundname      =   Config::get('constants.ROUND_NAME.116');
                $hostserver     =   $getlocationftp['HOST'];
                $hostusername   =   $getlocationftp['FTP_USERNAME'];
                $hostpassword   =   $getlocationftp['FTP_PASSWORD'];
                $hostpath       =   $getlocationftp['HOST_PATH'];
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $getjobsheetfile    =   Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    $roundname,
                                            '{CID}' =>    $Chapter
                                         );

                $cmn_obj            =   new CommonMethodsController();
                $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $getjobsheetfile );
                $cucuserworkfolder  =   $hostpath.$rawpath;                    
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    $xmlFilePath    =   "";
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }

                    if($xmlFilePath == '') 
                    {
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 

                    $response       =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                $response['errMsg']     =   'XML file is not found';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            return response()->json($response);
        }
    }
    
    public function doPackaging( $jobstgid , $packge_type = null ){
        
        try{
        
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   array();
        $stageDetails       =   $checkoutObj->getStageInfo($jobstgid);
		
        $stageDetails       =   $stageDetails[0];
        $jobId				=	$stageDetails->JOB_ID;
        $metaid             =  $stageDetails->METADATA_ID;
        $round              =  $stageDetails->ROUND_ID;
        
            if( is_null( $packge_type ) ){
                return $this->preparebgProcessCommonMetaXmlFormat(  $metaid , $round , $jobstgid ,  'package' , $jobId  );
            }
            if( !is_null( $packge_type ) ){
                 return $this->preparebgProcessCommonMetaXmlFormat(  $metaid , $round , $jobstgid ,  'package' , $jobId  );
            }
            
        }catch( \Exception $e ){
           
        }
        
    }
    
    public function preparebgProcessCommonMetaXmlFormat(  $metaid , $round , $jobstgid ,  $processname , $jobid = null , $optional = array(  'level' => 1 , 'metacollect' => array() ) ){
        
        try{
            
        $xml_string         =           $this->getCommonMetaXmlFormat();
        $xmlForm            =           simplexml_load_string( $xml_string );
        $input_arr_xml      =           array();
        $jb_obj             =           new jobModel();
        $jbs_obj            =           new jobStage();
        $tlm_obj            =           new taskLevelMetadataModel();
        $cmn_obj            =           new CommonMethodsController();
        $pckg_Cont_obj      =       	new packageController();
        $packageInfo        =       	$pckg_Cont_obj->getLastPackageInfo( $metaid , $round );
                
        if( $xmlForm ){
           
            $process_collection     =       array( 
                                                    'ArtworkMetadata' ,  'pagination' , 'PSMeta' , 'pitstop' , 'pdfcompare' , 'pdfcommentenable' , 'pdfmerge' , 'package' , 'upload'  
                                            );
            
            $open_sec                   =       array( 'MetaData' , 'ArtMetaData' , 'package'  );
            $optional['processname']    =       $processname;
            
            unset( $process_collection[array_search( 'package' ,$process_collection)] );
           
            $api_table_name     =       array( 'package'    =>  'api_dataset' , 'upload' => 'api_file_upload' );
            $api_table_id       =       array( 'package'    =>  'DATASET_ID'  , 'upload' => 'TOKEN_KEY' );
            
            $watchPatharr       =       array( 
                                                'package'    =>  \Config::get( 'constants.PRODUCTION_TOOLS_SETUP.EPROOF_PACKAGE_FOLDER' ) , 
                                                're-package'    =>  \Config::get( 'constants.PRODUCTION_TOOLS_SETUP.EPROOF_PACKAGE_FOLDER' ) , 
                                                'upload'     =>  \Config::get( 'constants.PRODUCTION_TOOLS_SETUP.PACKAGE_WATCH_FOLDER' ) 
                                        );
            
                
            $watchpath          =       $watchPatharr[ $processname ];
            $cmn_obj            =       new CommonMethodsController();
            $tokenkey           =       $cmn_obj->generateRandomString( 16 ,  'api_dataset' , 'TOKEN_KEY'  ); 
            $optional['tokenkey']   =      $tokenkey;
            
            $filename           =       '{BID}_{CID}_{TKEY}.xml';
            
            $round_arr          =       \Config::get('constants.ROUND_ID');
            $return_arr         =           array();
        
            $taskLevelInfo      =       $tlm_obj->getTaskLevelDetails( $metaid );
            $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
            $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
            $chapterid          =       '';

            if(empty( $jobinfo ))  
                throw new \Exception( 'job table information is not found' );
            
            $job_id             =       $jobinfo[0];
            if( !empty( $chapterlist ) ){
                $chapterid      =   $chapterlist[0];
            }
                
            $bookInfo           =       jobModel::getJobdetails( $job_id );
            $book_id            =       $bookInfo->BOOK_ID;

            $js_cpy_const       =      \ Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
            $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundname          =       $round_arr[$round];
            $rpl_array          =       array( '{BID}' => $book_id , '{CID}' => $chapterid , '{RID}' => $round_arr[$round] , '{TKEY}' => $tokenkey );
            
            $metainfor          =       array( 
                                            'metaid'  => $metaid , 'bookid'  => $book_id , 
                                            'roundname' => $roundname  ,
                                            'chapterno' =>  $chapterid ,
                                            'tokenkey' => $tokenkey 
                                        );
            
            $obj                =       new packageController();
            $filename           =       $obj->getMetafilename( $metainfor, $defaultCopyPath );
            $filename           =       $cmn_obj->arr_key_value_replace( $rpl_array  , $filename  );
            
                $xml            = 	new \XMLWriter();
                $xml->openMemory();
                $xml->startDocument();
                $xml->startElement('MagnusMetadata');
                $xml->setIndent(true);
                
                foreach( $xmlForm as $index_parent => $value ){
                    
                    $arr_in         =      $value;
                    if( count( $arr_in ) && in_array( $index_parent , $open_sec ) ) {
                        //$this->writingElementAndAttributeOfXml( $arr_in , $index_parent , $input_arr_xml , $xml , $xmlForm );
                        $method_name        =           'get'.ucwords($index_parent).'Info';
                        $data_collect       =           $this->$method_name( $metaid , $round ,$jobstgid , $jobid , $optional );
                        $xml->startElement($index_parent);
                        $xml->setIndent(true);
                        $xml->writeAttribute( 'stage' , $roundname );
                        $this->writingElementAndAttributeOfXml( $data_collect , $xml );
                        $xml->endElement();     
                       
                    }else{
                        if( in_array(  $index_parent , $process_collection ) ){
                            $xml->startElement($index_parent);
                            $xml->setIndent(true); 
                            $xml->endElement();  
                        }
                    }                    
                }
                
                $startProcess       =       0;
                if( $packageInfo ){

                    $tokenkeyold	=	$packageInfo->TOKEN_KEY;
                    $packagename        =       $packageInfo->DATASET_ID;
                    $packagename	=	str_replace( '.zip' , '' , $packagename );
                    $packagename_old    =       $packagename;
                    $startProcess   =           isset( $packageInfo->PACKAGE_RESUME_AT ) ? $packageInfo->PACKAGE_RESUME_AT : 0;
                }
				
		if( $startProcess == 10 || $startProcess == '10' ){ 
			$startProcess	=	6;
		}
					
                $this->getWorkflowAPIInfo( $metaid ,  $round , $jobstgid ,  $jobid  , $xml , 'package' , $tokenkey , $startProcess );
                $xml->endElement();
                $xml->endDocument();
                $content 	= 	$xml->outputMemory();
                
                $getlocationftp         =        productionLocationModel::doGetLocationname( $jobid );
                if( empty( $getlocationftp ) )
                 $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
                //need to dynamicaly bind the production location based on table location
                $ftpInfo['HOST']                  =       $getlocationftp->FTP_HOST;
                $ftpInfo['FTP_USERNAME']          =       $getlocationftp->FTP_USER_NAME;
                $ftpInfo['FTP_PASSWORD']          =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
                
                $packageinfiles     =   $this->packageinputfiles;
                $obj    =   new packageController();
                $return_valiation        =       $obj->inputfilePresentValidation( $packageinfiles , $getlocationftp );
                
                if( !$return_valiation['status'] ){
                    return json_encode( $return_valiation );
                }
                
                $atstgContr                 =           new autostageController();
                $successfileresponse        =           $atstgContr->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );
                
                if( !$successfileresponse ){
                    
                    $tablename          =       'api_dataset';
                    $erortxtprint       =       "Packaging BG - process initiation got failed!";
                    DB::update( 'update '.$tablename.' set status = 0 , remarks = "'.$erortxtprint.'" where token_key = "'.$tokenkey.'" limit 1' );
                    return json_encode( array( 'status' => 0 , 'msg' => 'failed' , 'errMsg' => $erortxtprint ) );
                    
                }
                
                $tablename          =       'api_dataset';
                
                return json_encode( array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Packaging BG - process Initialized.!' , 'params' => array( 'tokenkey' => $tokenkey , 'table' => $tablename ))  );
                
        }else{
            
            return json_encode( array( 'status' => 0 , 'msg' => 'failed' , 'errMsg' => 'Sample meta format xml is missing in public source path!' ) );
            
        }
        
    }catch( \Exception $e ){
        
        return response()->json( array( 'status' => 0 , 'msg' => 'failed' , 'errMsg' => 'Oops Something went wrong... ' , 
            'reason' => $e->getTraceAsString() ) );
        
    }
        
    }
    
    public function writingElementAndAttributeOfXml( $data_collect , &$xml ){
	 
        try{ 
		
           if( !empty( $data_collect ) )    {
			   
			   if( gettype( $data_collect ) == 'array' ) {
               
                foreach( $data_collect as $index_of_arr => $value_arr ){
					
					
                    if( ( is_array( $value_arr ) && gettype( $value_arr ) == 'string' ) || ( is_array( $value_arr ) && !in_array( '@attributes' , array_keys( $value_arr ) ) )  ){
						$xml->startElement($index_of_arr);
						$this->writingElementAndAttributeOfXml(  $value_arr , $xml );
						$xml->endElement();
                    }else if( count( $value_arr ) > 1 && is_array( $value_arr ) ){
                        
                        $first_val          =       $value_arr['tagtext'];
                        $second_attr        =       $value_arr['@attributes'];
                       
                        if( is_array( $value_arr ) ){
                           
                            $xml->startElement($index_of_arr);
							
                                foreach( $second_attr as $ind_atr => $atr_val ){
                                    $xml->writeAttribute( $ind_atr , $atr_val );
                                }
                                $xml->endAttribute();

                                if(isset( $value_arr['tagCollect'] )){
                                    
                                    $third_val          =       $value_arr['tagCollect'][0];      
                                    
                                    foreach( $third_val as $indxkey => $valueofin ){
                                        $xml->startElement($indxkey);
                                            if( gettype( $valueofin ) ==  'array') {
                                                    $first_val          =       (isset($valueofin['tagtext'])?$valueofin['tagtext']:'');
                                                    $second_attr        =       (isset($valueofin['@attributes'])?$valueofin['@attributes']:'');
                                                    if($second_attr !=  '' && count($second_attr) >= 1){
                                                        foreach( $second_attr as $ind_atr => $atr_val ){
                                                                $xml->writeAttribute( $ind_atr , $atr_val );
                                                                $xml->endAttribute();
                                                        }
                                                    }
                                                    
                                                    $xml->text( $first_val ); 
                                                    $getchildarray      =       array_column($valueofin, 'File');
                                                    if(count($getchildarray)>=1)
                                                    {
                                                        foreach( $getchildarray as $childkey => $childelement ){
                                                            $xml->startElement('File');
                                                            if( gettype( $childelement ) ==  'array' && count($childelement)>=1) {
                                                                foreach( $childelement as $childrow => $childrowelement ){
                                                                    if( gettype( $childrowelement ) ==  'array' && count($childrowelement)>=1) {
                                                                        foreach( $childrowelement as $childattr => $childattrelement ){
                                                                            $xml->writeAttribute( $childattr , $childattrelement );
                                                                            $xml->endAttribute();
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                            $xml->endElement();
                                                        }
                                                    }

                                            }
                                            
                                            if(  gettype( $valueofin ) ==  'string' )
                                                $xml->text( $valueofin );   

                                        $xml->endElement();
										
                                    }
                                    
                                }
								
                                $xml->text( $first_val );   
                            $xml->endElement();
                            
                        }
                        
                    }elseif( ( is_array( $value_arr ) && gettype( $value_arr) == 'array' ) || ( is_array( $value_arr ) && !in_array( '@attributes' , array_keys( $value_arr ) ))   ){
                        $xml->startElement($index_of_arr);
                            foreach( $value_arr as $indxkey => $valueofin ){
                                $this->writingElementAndAttributeOfXml( $valueofin  , $xml );
                            }
                        $xml->endElement();
                    }else{
                        $xml->startElement($index_of_arr);
                        $xml->text( $value_arr );
                        $xml->endElement();
                    }
                    
                }
			   }else{
				   $xml->writeRaw( $data_collect );
			   }
            }
			
        }catch( \Exception $e ){
           return response()->json( $e->getMessage() );
        }             
        
    }
    
    public function getCommonMetaXmlFormatInput(  $metaid , $round , $jobstgid ,  $processname , $jobid , $optional , &$input_arr_xml  ){
        
        $input_arr_xml['MetaData']          =       $this->getMetaDataInfo( $metaid , $round , $jobstgid , $jobid  );
        
        switch( $processname ){
            case 'pagination':
                $input_arr_xml['pagination']        =       array();
                break;
            case 'ArtworkMetadata':
                $input_arr_xml['ArtworkMetadata']   =       array();
                break;
            case 'S100PSMeta':
                $input_arr_xml['S100PSMeta']        =       array();
                break;
            case 'pitstop':
                $input_arr_xml['pitstop']           =       array();
                break;
            case 'pdfcompare':
                $input_arr_xml['pdfcompare']        =       array();
                break;
            case 'pdfcommentenable':
                $input_arr_xml['pdfcommentenable']  =       array();
                break;
            case 'pdfmerge':
                 $input_arr_xml['pdfmerge']          =       array();
                break;
            case 'package':
                $input_arr_xml['package']           =       $this->getPackageInfo( $metaid , $round , $jobstgid ,$jobid );
                break;
             case 'upload':
                $input_arr_xml['upload']            =       array();
                break;
        }
        
        $input_arr_xml['WorkflowAPI']               =       $this->getWorkflowAPIInfo( $metaid , $round , $jobstgid , $jobid );
        
        return $input_arr_xml;
        
    }
    
    public function getCommonMetaXmlFormat(){        
        $fileContent        =       file_get_contents( public_path('/').'{BID}_{CID}_{TKEY}.xml' );        
        return $fileContent;        
    }
    
    public function random_number($size = 7){
        
        $random_number='';
        $count=0;
        
        while ($count < $size ){
            $random_digit = mt_rand(0, 7);
            $random_number .= $random_digit;
            $count++;
        }
        
        return $random_number;  
        
    }

    public function prepareDatasetId( $bookid , $roundname ){
        
	$dId                =       '';
	
        $for_name_chg       =       array ( 
                                            'S5'    => 'M000H',
                                            'S100'	=> 'M000E',
                                            'S200'	=> 'M000U',
                                            'S250'  => 'M000P', 'S200_CVTNL'=>'M000Z' , 
                                            'S350'  => 'M000Q', 'S300'=>      'M000R' , 
                                            'S650'  => 'M000S', 'S600'=>      'M000T' 
                                    );
		
	$dId                =       $bookid.'_'.$for_name_chg[$roundname].$this->random_number().'.zip';
        
        return $dId;
        
    }
	
    public function getPackageInfo( $metaid , $round , $jobstgid , $jobid , $optional = array() ){
        
        try{
        $return_arr =       array();
        $jb_obj     =       new jobModel();
        $jbs_obj    =       new jobStage();
        $tlm_obj    =       new taskLevelMetadataModel();
        $cmn_obj    =       new CommonMethodsController();
        
        $taskLevelInfo      =       $tlm_obj->getTaskLevelDetails( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        $preparedDatasetid_new      =   '';
        $token_key_failed           =   '';
        $without_zip_datasetid      =   '';
        $failure_package_path2      =   '';
        $folernaming_chp            =   '';
        
        extract( $optional );
        
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
       
        $job_id             =       $jobinfo[0];
        $jobDetai           =       $jb_obj->getJobdetails( $job_id );
        $book_id            =       $jobDetai->BOOK_ID;
       
        $js_cpy_const       =       \Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $roundname          =       $round_arr[$round];
        
        $bookinfoCont       =       new bookinfoController();
        $preparedDatasetid_new  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round  );
        $ChapterNo          =       $chapterlist[0];
        
        if(strpos(strtoupper($ChapterNo),Config::get('constants.CHECK_PART')) !== false){
            $chapterno          =   $ChapterNo;
        }else{
            $chapterno          =   (strpos($ChapterNo,'_') !== false?substr(strrchr($ChapterNo, "_"), 1):$ChapterNo);
        }

        $onlychapno         =       str_replace( 'chapter_' , '' , $chapterno );
        $fm_bm_chp          =       $onlychapno.'_Chapter';
        
        $fm_bm              =       $taskLevelInfo->pluck('FM_ARTICLE_BM')->toArray();
        $fmBm               =       ( $fm_bm[0] );
             
        $package_type       =       'books';
        $process_type       =       $processname;
        
        $recordCheck        =       DB::table('api_dataset')->select()
                                        ->where('METADATA_ID' , '=' , $metaid)
                                        ->where('ROUND' , '=' , $round )
                                        ->orderBy('ID','DESC')
                                        ->get()->first();    

        
        
       if( !empty( $recordCheck ) ){           
            //Submission checker//           
            $clearedSt   =       $cmn_obj->filterAlphanumeric( $recordCheck->REMARKS  );
            //if( stripos( $clearedSt , 'ReadMetaChk' ) >= 0 &&  ( stripos( $clearedSt , 'ReadMetaChk' ) !== false ) ){
                $process_type       =       'package';
            // }
            //Submission checker//            
       }
       
       if( $process_type == 'package' ){            
            $preparedDatasetid  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round , true , true );            
        }
        
       if( $process_type == 're-package' ){
            
            $getpackname_rec        =       $recordCheck;
            $getpackname            =       $getpackname_rec->DATASET_ID;
            $preparedDatasetid      =       $getpackname;
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY.'\\';
            
        }
        
        $without_zip_datasetid        =     str_replace( '.zip' , '' , $preparedDatasetid.'\\' );
        $without_zip_datasetid        =     $without_zip_datasetid;
        //$without_zip_datasetid        =     $token_key_failed.$without_zip_datasetid;
        
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapterlist[0] , $metaid ); 
        extract( $paging_collect );
        
        $compattr_name      =       str_replace( "$book_id".'_' , '' , $pagingfilnaming );
        
        if( $fmBm == 1 || $fmBm == 3 ){
            $compattr_name  =   $fm_bm_chp;
        }
        
        $empid              =        Session::get('users')['emp_id'];
        
        $inp_rep_arr        =       array(
                                            'BOOK_ID'       =>  $book_id,
                                            '{BID}'         =>  $book_id,
                                            '{CID}'         =>  $chapterlist[0],
                                            '{CNO}'         =>  $onlychapno,
                                            '{DID}'         =>  $preparedDatasetid_new ,
                                            '{RID}'         =>  $roundname,
                                            'ROUND_NAME'    =>  $roundname,
                                            'STAGE_NAME'    =>  $roundname ,
                                            '{EMPID}'       =>  $empid , 
                                            '{PAGING_FILENAMING}' => $pagingfilnaming
                                        );
        
       $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
        
       $return_arr['packagetype']['tagtext']           =           '';
       $return_arr['packagetype']['@attributes']       =           array( 'type' => $package_type );
       $return_arr['processtype']['tagtext']           =           '';
       $return_arr['processtype']['@attributes']       =           array( 'type' => $process_type );
        
        $js_cpy_const   =       Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
        
        $defaultCopyPath        =       $cmn_obj->backslashPathPrepare($js_cpy_const, true);
		
        $chap_no_test           =   str_replace( 'CHAPTER_', '' , strtoupper( $chapterlist[0] ) );
        $chap_no_test           =   str_replace( 'PART_', '' , strtoupper( $chap_no_test ) );
		
        $inp_rep_arr            =       array(  
                                            '{BID}' => $book_id , '{RID}' => $roundname , '{CID}' => $chapterlist[0] ,
                                            '{CNO}' => $chap_no_test , '{DID}'         =>  $preparedDatasetid_new ,
                                            '{PAGING_FILENAMING}' => $pagingfilnaming , '{EMPID}'       =>  $empid 
                                        );
        
        $default_jobsheet_path  =       $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
        $naming             =       \config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $namin_convention   =       $naming[$round_arr[$round]];
        
        $getlocationftp         =        productionLocationModel::doGetLocationname( $job_id );
        if( empty( $getlocationftp ) )
        $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
        
        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostpath               =   $getlocationftp->FTP_PATH;
       
        $addeftpath             =   Config::get( 'constants.FILE_SERVER_ROOT_DIR');
        $artimages              =   $hostserver.$addeftpath.$hostpath.config::get('constants.ART_DESTINATION_PATH').$book_id.'/'.$chapterlist[0].'/';
	
        $esmpath               =      DB::table('metadata_info')->select()->where( 'METADATA_ID'  ,  '=' , $metaid )->get()->first();
        $esmpath               =      ($esmpath->TYPE_OF_CONTAINESM == 'YES')? 1: 0;
        
       $inputfilepath      =   array( 
                                       'bookprintpdf'   =>  '' , 'bookprintpdfpitstoplog'   =>  '' , 'bookmycopypdf'   =>   '',
                                       'bookmycopypdfpitstoplog'   =>  '' , 'bookcoverprintpdf'   =>  '' ,'bookprintcoverpdfpitstoplog' => '',
                                       'bookcoverimage'   =>  ''  , 'bookmycopycoverpdf'   =>  '' , 'bookmycopycoverpdfpitstoplog'   =>  '' ,
                                       'bookepsilonpdf'   =>   '' , 'bookchecklist'   =>   '' , 
                                       'xmlfile'   =>   '', 'pdffile'   =>  '' , 'pitstopstopfile'   =>   '', 'refpdffile'   =>   '', 'deltapdffile' => '',
                                       'textfile'   =>   '', 'proofpdffile'   =>  '' , 'lowresimagefolder'   =>  '' , 'highresimagefolder'   =>     ''   ,                                     
                                       'highresimagefolder'   =>     '' , 'stripinsfolder'       =>  '' , 'destinationPath' => '' , 
                                       'esmdetails' => '' ,     'destinationPath' => '' , 'failure_package_path2' => '' , 'failure_package_path' => ''
                                );
        
       	
        foreach( $inputfilepath as $key_in  => $value ){
            $lastpath              =        $hostserver.'/'.$addeftpath.\Config::get( 'constants.PACKAGE_PATH.'.strtoupper( $key_in ) );
            $lastpath              =        $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lastpath , true );
            $lastpath              =        $cmn_obj->backslashPathPrepare( $lastpath , true );
            $inputfilepath[$key_in]     =   $lastpath;
        }
       
	   //art image path changes
        $artimagepath           =   $cmn_obj->backslashPathPrepare( $artimages , true );
        
        extract( $inputfilepath );
        
        if( $esmpath == 0 ){
            $esmdetails = '';
        }
        //extract( $optional );
        if( $optional['level'] == 3 ){
            $return_arr['bookprintpdf']                 =           $bookprintpdf;
            $return_arr['bookprintpdfpitstoplog']       =           $bookprintpdfpitstoplog;
            $return_arr['bookmycopypdf']                =           $bookmycopypdf;
            $return_arr['bookmycopypdfpitstoplog']      =           $bookmycopypdfpitstoplog;
            $return_arr['bookcoverprintpdf']            =           $bookcoverprintpdf;
            $return_arr['bookprintcoverpdfpitstoplog']  =           $bookprintcoverpdfpitstoplog;
            $return_arr['bookcoverimage']               =           $bookcoverimage;
            $return_arr['bookmycopycoverpdf']           =           $bookmycopycoverpdf;
            $return_arr['bookmycopycoverpdfpitstoplog'] =           $bookmycopycoverpdfpitstoplog;
            $return_arr['bookepsilonpdf']               =           $bookepsilonpdf;
            $return_arr['bookchecklist']                =           $bookchecklist;
        }
        
        if( count( $optional['metacollect'] ) == 0){
            $array_of_meta      =       array( $metaid );
        }
        
        $tlam_obj               =       new taskLevelArtMetadataModel();
		
		$art_info				=		$tlam_obj->getArtChapterwisefigureInfo( $metaid );
		$countart				=		count( $art_info );
		
        $preparedCompo      =       array();
        
        foreach( $array_of_meta as $iterate => $prepareMetaid )     {
            
           $component_arr                  =           array();
           
                $component_arr['xmlfile']['tagtext']               =   $xmlfile;
                $xmlfile_name       =       explode( '\\' , $xmlfile );
                $xmlfile_name       =       $xmlfile_name[count( $xmlfile_name ) - 1];
                $component_arr['xmlfile']['@attributes']           =   array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$xmlfile_name );
            
                $component_arr['pdffile']['tagtext']               =   $pdffile;
            $pdffile_name       =       explode( '\\' , $pdffile );
            $pdffile_name       =       $pdffile_name[count( $pdffile_name ) - 1];            
            $component_arr['pdffile']['@attributes']               =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$pdffile_name );
            
            $component_arr['pitstopstopfile']['tagtext']   =           $pitstopstopfile;
            $pitstopstopfile_name       =       explode( '\\' , $pitstopstopfile );
            $pitstopstopfile_name       =       $pitstopstopfile_name[count( $pitstopstopfile_name ) - 1];            
            $component_arr['pitstopstopfile']['@attributes']          =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$pitstopstopfile_name );
            
            //$component_arr['refpdffile']            =           $refpdffile;
            $component_arr['refpdffile']['tagtext']   =           $refpdffile;
            $refpdffile_name       =       explode( '\\' , $refpdffile );
            $refpdffile_name       =       $refpdffile_name[count( $refpdffile_name ) - 1];            
            $component_arr['refpdffile']['@attributes']          =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$refpdffile_name );
            
            $component_arr['deltapdffile']['tagtext']   =           $deltapdffile;
            $deltapdffile_name       =       explode( '\\' , $deltapdffile );
            $deltapdffile_name       =       $deltapdffile_name[count( $deltapdffile_name ) - 1];            
            $component_arr['deltapdffile']['@attributes']          =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$deltapdffile_name );
            
                //esm file path get data start
                $initEsmObj     =   new esmController();
                $esmDedatils        =   $initEsmObj->getMetaEsmDetails($jobid, $prepareMetaid);
                
                if(count($esmDedatils)>=1){
                    
                    $esmfiletype = Config::get('constants.ESM_FILE_TYPE');
                    foreach( $esmDedatils as $key => $value ){
                        $replaceslash   =   $cmn_obj->backslashPathPrepare($value['filepath'],true);
                        if (in_array($value['FILE_FORMAT'], $esmfiletype)) {
                            $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'ESM','name'=>$replaceslash,'videoID'=>$value['clientid']];
                           }else{
                              $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'other','name'=>$replaceslash,'videoID'=>$value['clientid']];  
                           }
                    }
                    
                }
                //esm file path get data end
                $component_arr['textfile']              =           '';$textfile;
                $component_arr['proofpdffile']          =           '';$proofpdffile;
                 
            if( $countart ){
                $component_arr['lowresimagefolder']['tagtext']     =           $lowresimagefolder;
                $lowresimagefolder_name       =       explode( '\\' , $lowresimagefolder );
                $lowresimagefolder_name       =       $lowresimagefolder_name[count( $lowresimagefolder_name ) - 1];           
                $component_arr['lowresimagefolder']['@attributes']     =            array(  'userbin' =>  $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$lowresimagefolder_name );
            }else{
                $component_arr['lowresimagefolder'] =   '';
            }
            
            
                //$component_arr['highresimagefolder']    =           $artimagepath;//$highresimagefolder;
                $component_arr['stripinsfolder']        =           '';$stripinsfolder;
            $preparedCompo[]          =                 $component_arr;
        }    
        
        $return_arr['component']['tagCollect']        =           $preparedCompo;
        $return_arr['component']['tagtext']           =           '';
        $return_arr['component']['@attributes']       =           array( 'name' => $compattr_name );
        
        //$return_arr['jobsheetfile']           =           $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention;
        //$preparedCompo[]['jobsheetfile']      =           $return_arr['jobsheetfile'];
        
        $return_arr['jobsheetfile']['tagtext']      =       $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention;
        $jobsheetfile_name                          =       explode( '\\' , $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention );
        $jobsheetfile_name                          =       $jobsheetfile_name[count( $jobsheetfile_name ) - 1];        
        $return_arr['jobsheetfile']['@attributes']  =       array( 'userbin' =>  $failure_package_path2.$without_zip_datasetid.$jobsheetfile_name );

        $this->packageinputfiles            =           $preparedCompo;
        
        $return_arr['destinationpath']['tagtext']       =       $destinationPath;
        $destinationPath_name                           =       explode( '\\' , $destinationPath );
        unset($destinationPath_name[count( $destinationPath_name ) - 1]);
        $destinationPath_name           =       implode( '\\' , $destinationPath_name );
        //$destinationPath_name                           =       $destinationPath_name[count( $destinationPath_name ) - 1];
        $return_arr['destinationpath']['tagtext']       =       $destinationPath_name.'\\'.$preparedDatasetid_new;
        $return_arr['destinationpath']['@attributes']   =   array( 'userbin' =>  $failure_package_path2.$preparedDatasetid_new );
             
        //$return_arr['destinationpath']      =           $destinationPath;
        DB::table( 'api_dataset' )->insert( array( 
                                                   'DATASET_ID'  =>     $preparedDatasetid_new , 
                                                   'TOKEN_KEY'   =>     $optional['tokenkey'] , 
                                                   'METADATA_ID' =>     $metaid  , 
                                                   'ROUND'       =>     $round , 
                                                   'START_TIME'  =>     date('Y-m-d H:i:s'), 
                                                   'STATUS'     =>     '1.5' 
                                                ) );
        return $return_arr;
        }
        catch( \Exception $e ){
            throw new \Exception( $e->getTraceAsString() );
        }
    }
    
    public function getUploadInfo( $metaid , $round , $jobstgid , $jobid , $optional ){
        
        $return_arr                     =           array();
        $jb_obj     =       new jobModel();
        $jbs_obj    =       new jobStage();
        $tlm_obj    =       new taskLevelMetadataModel();
        $cmn_obj    =       new CommonMethodsController();
        $chapid     =       '';
        
        $taskLevelInfo      =       $tlm_obj->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        
        if(!empty( $chapterlist )){
            $chapid     =       $chapterlist[0];
        }  
            
        $jobDetai           =       $jb_obj->getJobdetails( $job_id );
        $book_id            =       $jb_obj->BOOK_ID;
        
        $js_cpy_const       =      \ Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $roundname          =       $round_arr[$round];
        
        $inp_rep_arr        =       array(
                                            'BOOK_ID'       =>  $book_id,
                                            'ROUND_NAME'    =>  $roundname,
                                            'STAGE_NAME'    =>  $roundname
                                         );
        
        $jobsheet_file_path =        '';
        $ftp_host           =        '';
        $jobsheet_upload_path   =    '';
        $ftp_username           =    '';
        $ftp_password           =    '';
        
        
        $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
            
        $return_arr['sourceFile']       =       array( 'filepath' => $jobsheet_file_path );            
        $return_arr['destPath']         =       array(  
                                                        'ftpType'  => 'ftp', 'ftpSite' => $ftp_host , 
                                                        'path'  => $jobsheet_upload_path , 
                                                        'username'  => $ftp_username , 
                                                        'password'  => $ftp_password 
                                                );            
        
        return $return_arr;
        
    }
    
    public function getMetaDataInfo( $metaid ,  $round , $jobstgid , $jobid ){
        
        $return_arr                     =           array();
        
        $userid     =       Session::get('users')['user_id'];
        $username   =       Session::get('users')['user_name'];
        $tokenkey   =       '';
        
        $jb_obj     =       new jobModel();
        $jbs_obj    =       new jobStage();
        $tlm_obj    =       new taskLevelMetadataModel();
        $cmn_obj    =       new CommonMethodsController();
        $usrC_obj           =   new usersController();
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $round_name         =   $round_arr[$round];
        
        $taskLevelInfo      =   $tlm_obj->getTaskLevelDetails( $metaid );
        $chapterlist        =   $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $jobinfo            =   $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        //$tokenkey           =       $cmn_obj->generateRandomString( 16 , $table_name , 'DATASET_ID'  ); 
            
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        $jobDetail          =       $jb_obj->getJobdetails( $job_id );
        
        if(empty( $chapterlist ))  
            throw new \Exception( 'chapter level information is not found' );
        
        $currentuser_id     =   session::get('users')['user_id'];
        $user_arr           =   $usrC_obj->getUserInfoByUserId($jobDetail->PM); 
        
        $chapter_name            =       $chapterlist[0];
        
        $return_arr['Current_User']     =           $userid;
        $return_arr['Actual_Name']      =           $username; 
        $return_arr['Location']         =           '';
        $return_arr['ContactPerson']    =           array();
        $return_arr['ContactPerson']['ContactPersonName']['GivenName']   =   $user_arr->FIRST_NAME;
        $return_arr['ContactPerson']['ContactPersonName']['FamilyName']  =   $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
        $return_arr['ContactPerson']['Contact']['Street']            =   $user_arr->P_ADDRESS;
        $return_arr['ContactPerson']['Contact']['City']              =   $user_arr->P_CITY;
        $return_arr['ContactPerson']['Contact']['Postcode']          =   $user_arr->P_ZIP;
        $return_arr['ContactPerson']['Contact']['Country']           =   $user_arr->P_COUNTRY;
        $return_arr['ContactPerson']['Contact']['Phone']             =   $user_arr->PERSONAL_PHONE;
        $return_arr['ContactPerson']['Contact']['Email']             =   $user_arr->EMAIL;
        $return_arr['Stage']            =           $round;
        $return_arr['ChapterID']        =           $chapter_name;
        $return_arr['BookID']           =           $jobDetail->BOOK_ID;
        $return_arr['Isbn_Number']      =           $jobDetail->ISSN_ONLINE;
        $return_arr['ChapterType']      =           'C';
        $return_arr['Publisher']        =           'Springer';//$jobDetai->PUBLISHER_IMPRINT_NAME;
        $return_arr['ProjectName']      =           'SpringerNature';
        $return_arr['ChapterNumber']    =           $chapter_name;
        $return_arr['EProofing']        =           ($jobDetail->EPROOFING_SYSTEM ==  '1'?'Yes':'No');
        //$return_arr['tokenkey']         =           $tokenkey;
        return $return_arr;
        
    } 
    
    public function getWorkflowAPIInfo( $metaid ,  $round , $jobstgid ,  $jobid , &$xml  , $processname , $tokenkey , $startProcess = 0 ){
        
        $return_arr             =    array();
        $baseUrl                =    \Config('app.url').'api/';
        if($processname         ==   "EproofPackage"){
            $callbackarr        =    array( 'EproofPackage' => $baseUrl.'eproofpackagingCallback' , 'upload' => $baseUrl.'eproofpackagingCallback' );
        }else{
            $callbackarr        =    array( 'package' => $baseUrl.'packagingCallback' , 'upload' => $baseUrl.'packagingUploadCallback' );
        }
        $xml->startElement( 'workflow' );
        
        $xml->startElement( 'WorkflowAPI' );
            $xml->startElement('Url' );
                $xml->writeAttribute( 'value' , $callbackarr[$processname] );
                $xml->endAttribute();
            $xml->endElement();
            
            $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'process' );
                $xml->writeAttribute( 'value' , $processname );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
            $xml->endElement();
            
            $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'startprocess' );
                $xml->writeAttribute( 'value' , $startProcess );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
            $xml->endElement();
            
            $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'finalZipName' );
                $xml->writeAttribute( 'value' , '' );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
            $xml->endElement();
            
            if( isset( $metaid ) ){
                $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'metaid' );
                $xml->writeAttribute( 'value' , $metaid );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
                $xml->endElement();
            }
             
            if( isset( $round ) ){
                $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'round' );
                $xml->writeAttribute( 'value' , $round );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
                $xml->endElement();
            }
             
            if( isset( $jobstgid ) ){
                $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'jobstageid' );
                $xml->writeAttribute( 'value' , $jobstgid );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
                $xml->endElement();
            }
             
            if( isset( $jobid ) ){
                $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'jobid' );
                $xml->writeAttribute( 'value' , $jobid );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
                $xml->endElement();
            }
            
            if( isset( $bookid ) ){
                $xml->startElement( 'parameter' );
                $xml->writeAttribute( 'key' , 'bookid' );
                $xml->writeAttribute( 'value' , $bookid );
                $xml->writeAttribute( 'type' , 'fixed' );
                $xml->endAttribute();
                $xml->endElement();
            }
            
            $xml->startElement( 'parameter' );
            $xml->writeAttribute( 'key' , 'tokenkey' );
            $xml->writeAttribute( 'value' , $tokenkey );
            $xml->writeAttribute( 'type' , 'fixed' );
            $xml->endAttribute();
            $xml->endElement();

            $xml->startElement( 'parameter' );
            $xml->writeAttribute( 'key' , 'status' );
            $xml->writeAttribute( 'value' , '' );
            $xml->writeAttribute( 'type' , 'boolean' );
            $xml->endAttribute();
            $xml->endElement();
            
            $xml->startElement( 'parameter' );
            $xml->writeAttribute( 'key' , 'endtime' );
            $xml->writeAttribute( 'value' , '{0:yyyy-MM-dd HH-mm-ss}' );
            $xml->writeAttribute( 'type' , 'data-time' );
            $xml->endAttribute();
            $xml->endElement();

            $xml->startElement( 'parameter' );
            $xml->writeAttribute( 'key' , 'remarks' );
            $xml->writeAttribute( 'value' , '' );
            $xml->writeAttribute( 'type' , 'string' );
            $xml->endAttribute();
            $xml->endElement();
            
            $xml->endElement();
        $xml->endElement();
        return $return_arr;
        
    }
    
    public function doPrepareeproofpackageMetaXmlFormat(  $metaid , $round , $processname , $jobid = null , $optional = array(  'level' => 1 , 'metacollect' => array() ),$typeofpprcoess ){
        
        try{
        
        $xml_string             =   $this->getCommonMetaXmlFormat();
        $xmlForm                =   simplexml_load_string( $xml_string );
        $input_arr_xml          =   array();
        $response               =   $this->failedResponse;
        if( $xmlForm ){
            
            $process_collection =   array( 'package', 'WorkflowAPI');
            $open_sec           =   array( 'MetaData' , 'ArtMetaData' , $processname  );
            unset( $process_collection[array_search( $processname ,$process_collection)] );
            $api_table_name     =   array( 'package'    =>  'api_eproof_packaging');
            $api_table_id       =   array( 'package'    =>  'PACKAGE_ID');
            $watchPatharr       =   array( 
                                            'package'    =>  \Config::get( 'constants.PRODUCTION_TOOLS_SETUP.EPROOF_PACKAGE_FOLDER' ) , 
                                            'upload'     =>  \Config::get( 'constants.PRODUCTION_TOOLS_SETUP.PACKAGE_WATCH_FOLDER' ) 
                                        );
            
            $watchpath          =   $watchPatharr[ $processname ];
            $cmn_obj            =   new CommonMethodsController();
            $tokenkey           =   $cmn_obj->generateRandomString( 16 , $api_table_name[$processname] , $api_table_id[$processname]  ); 
            $optional['tokenkey']   =      $tokenkey;
            
            $filename           =   '{BID}_{CID}_{TKEY}';
            $round_arr          =   \Config::get('constants.ROUND_ID');
            $return_arr         =   array();
            $jb_obj             =   new jobModel();
            $jbs_obj            =   new jobStage();
            $tlm_obj            =   new taskLevelMetadataModel();
            $cmn_obj            =   new CommonMethodsController();
            $taskLevelInfo      =   $tlm_obj->getTaskLevelDetails( $metaid );
            $chapterlist        =   $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
            $jobinfo            =   $taskLevelInfo->pluck('JOB_ID')->toArray(); 
            $chapterid          =   '';

            if(empty( $jobinfo ))  
                throw new \Exception( 'job table information is not found' );
            
            $job_id             =       $jobinfo[0];
            if( !empty( $chapterlist ) ){
                $chapterid      =   $chapterlist[0];
            }
            
            $bookInfo           =   jobModel::getJobdetails( $job_id );
            $book_id            =   $bookInfo->BOOK_ID;
            $js_cpy_const       =   Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
            $defaultCopyPath    =   $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
            $round_arr          =   Config::get('constants.ROUND_NAME');
            $roundname          =   $round_arr[$round];
            $rpl_array          =   array( '{BID}' => $book_id , '{CID}' => $chapterid , '{RID}' => $round_arr[$round] , '{TKEY}' => $tokenkey );
           
            $apc_obj            =       new autoPageController();
            $paging_collect     =       $apc_obj->getPagingFileNameing( $book_id , $chapterid ,  $metaid );
            extract( $paging_collect );
            
            $startProcess       =       0;
            $pckg_Cont_obj      =       new eproofController();
            $packageInfo        =       $pckg_Cont_obj->getLastPackageInfo( $metaid , $round );
           
            if( $packageInfo ){
                $tokenkeyold        =       $packageInfo->TOKEN_KEY;
                $packagename        =       $packageInfo->PACKAGE_ID;
                $packagename        =       str_replace( '.zip' , '' , $packagename );
                $packagename_old    =       $packagename;
                $startProcess       =       isset( $packageInfo->PACKAGE_RESUME_AT ) ? $packageInfo->PACKAGE_RESUME_AT : 0;
            }
            
	    if( $startProcess == 10 || $startProcess == '10' ){
		$startProcess	=	6;
	    }
		 
				
            $inp_rep_arr    =       array( 
                                            '{CNAME}'       =>      $chapterid , 
                                            '{TKEY}'        =>      $tokenkey ,
                                        );

            $chapterno2         =        preg_replace( '/\D/', '', $chapterid );
            $filename           =        $pagingfilnaming.'@'.$roundname.'_eproof_'.$tokenkey.".xml";
            $filename           =        $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
            $xml                =   new \XMLWriter();
            $xml->openMemory();
            $xml->startDocument();
            $xml->startElement('MagnusMetadata');
            $xml->setIndent(true);
            
            foreach( $xmlForm as $index_parent => $value ){
                $arr_in         =      $value;
                if( count( $arr_in ) && in_array( $index_parent , $open_sec ) ) {
					
                    $method_name        =   ($index_parent  ==  "package"?'getEproofPackageInfo':'get'.ucwords($index_parent).'Info');
                    $data_collect       =   $this->$method_name( $metaid , $round , $jobid , $optional ,$typeofpprcoess );
					
                    $xml->startElement($index_parent);
                    $xml->setIndent(true);
                    $xml->writeAttribute( 'stage' , $roundname );
                    $this->writingElementAndAttributeOfXml( $data_collect , $xml );
                    $xml->endElement();   
                }
                else{
                    
                    if( !in_array(  $index_parent , $process_collection ) ){
                        $xml->startElement($index_parent);
                        $xml->setIndent(true); 
                        $xml->endElement();  
                    }
                    
                }  
                
            }
            
            $this->getWorkflowAPIInfo( $metaid ,  $round , null ,  $jobid  , $xml , 'EproofPackage' , $tokenkey , $startProcess );

            $xml->endElement();
            $xml->endDocument();
            $content                    =   $xml->outputMemory();
            
            $getlocationftp             =   productionLocationModel::doGetLocationname( $jobid );
            
            if( empty( $getlocationftp ) )
                $getlocationftp            =   productionLocationModel::getDefaultProductionLocationInfo();
            
            //need to dynamicaly bind the production location based on table location
            $ftpInfo['HOST']            =   $getlocationftp->FTP_HOST;
            $ftpInfo['FTP_USERNAME']    =   $getlocationftp->FTP_USER_NAME;
            $ftpInfo['FTP_PASSWORD']    =   \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
            
            $atstgContr                 =           new autostageController();
            $successfileresponse        =           $atstgContr->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );

            if( !$successfileresponse ){
                
                $tablename              =       $api_table_name[$processname];
                DB::update( 'update '.$tablename.' set status = 0 , remarks = "Meta file is not posted , check network for production file server." where token_key = "'.$tokenkey.'" limit 1' );
                $response['errMsg']     =       'Meta post got failed' ;
                return $response;
            }
			
            $tablename          =       $api_table_name[$processname];
            $response   		=   	$this->successResponse;
            $response['errMsg']     =   'Eproof Packaging process initiated.' ;
            $response['params']     =   array( 'tokenkey' => $tokenkey , 'table' => $tablename );
            return $response;

        }else{
            
            $response['errMsg']     =   'Sample meta format xml is missing' ;
            return $response;
            
        }
        
    }catch( \Exception $e ){
        
        $response['errMsg']     =   'Oops Something went wrong. ';
        $response['reason']     =   'Oops Something went wrong. '.$e->getTraceAsString();
        
        return response()->json( $response);
    }
        
    }
    
    public function getArtMetadataInfo( $metaid , $round , $jobid , $optional , $typeofpprcoess ){
    
        $artPCont           =       new artProcessController();
        $artmetatags        =       $artPCont->getArtMetaDataTags($metaid , 'xml');
        return $artmetatags;
		
    }
    
    public function getEproofPackageInfo( $metaid , $round , $jobid , $optional,$typeofpprcoess ){
        
        $return_arr         =   array();
        $jb_obj             =   new jobModel();
        $jbs_obj            =   new jobStage();
        $tlm_obj            =   new taskLevelMetadataModel();
        $cmn_obj            =   new CommonMethodsController();
        $taskLevelInfo      =   $tlm_obj->getTaskLevelDetails( $metaid );
        $chapterlist        =   $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $jobinfo            =   $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        $token_key_failed   =   '';
        
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
       
        $job_id             =   $jobinfo[0];
        $jobDetai           =   $jb_obj->getJobdetails( $job_id );
        $book_id            =   $jobDetai->BOOK_ID;
        $js_cpy_const       =   Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
        $defaultCopyPath    =   $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $conventional_roundname =   (isset($taskLevelInfo[0]->PRODUCTION_SYSTEM) && $taskLevelInfo[0]->PRODUCTION_SYSTEM == 1?$round_arr[$round]:$round_arr[Config::get('constants.ROUND_NAME.S200')]);
        $roundname          =   $round_arr[$round];
        
        $preparedDatasetid      =       '';
        $bookinfoCont           =       new bookinfoController();
        $preparedDatasetid_new  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round , true , true );
        
        if( $typeofpprcoess == 're-package' ){
            
            $getpackname_rec        =       DB::table('api_eproof_packaging')->select()
                                                ->where( 'METADATA_ID'  , '=' , $metaid )
                                                ->where( 'ROUND'  , '=' , $round )->orderBy( 'ID' , 'desc' )->get()->first();
            
            $getpackname            =       $getpackname_rec->PACKAGE_ID;
            $preparedDatasetid      =       $getpackname;
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY.'\\';
            
        }
        
        if( $typeofpprcoess == 'package' ){
            $preparedDatasetid  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round , true , true );
        }
        
        $without_zip_datasetid        =     str_replace( '.zip' , '' , $preparedDatasetid.'\\' );
        //$without_zip_datasetid        =     $token_key_failed.$without_zip_datasetid;
        $without_zip_datasetid        =     $without_zip_datasetid;
        $typeofpprcoess     =   'package';
        $onlychapno         =   str_replace( 'chapter_' , '' , strtolower( $chapterlist[0] ) );
        $fm_bm_chp          =   $onlychapno.'_Chapter';
        $fm_bm              =   $taskLevelInfo->pluck('FM_ARTICLE_BM')->toArray();
        $fmBm               =   $fm_bm[0];
        
        if( $fmBm == 1 )
            $fm_bm_chp      =   'bookfrontmatter';
        if( $fmBm == 3 )
            $fm_bm_chp      =   'backbackmatter';  
        
        $empid              =        Session::get('users')['emp_id'];
        
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapterlist[0] , $metaid ); 
        extract( $paging_collect );
        
        $inp_rep_arr        =   array(
                                        'BOOK_ID'       =>  $book_id,
                                        '{BID}'         =>  $book_id,
                                        '{CID}'         =>  $chapterlist[0],
                                        '{CNO}'         =>  $onlychapno,
                                        '{DID}'         =>  $preparedDatasetid ,
                                        '{RID}'         =>  $roundname,
                                        'ROUND_NAME'    =>  $roundname,
                                        'STAGE_NAME'    =>  $roundname ,
                                        '{EMPID}'       =>  $empid , 
                                        '{PAGING_FILENAMING}' => $pagingfilnaming
                                     );
        
        $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $defaultCopyPath );
        
         $tlam_obj               =       new taskLevelArtMetadataModel();
         $art_info				=		$tlam_obj->getArtChapterwisefigureInfo( $metaid );
         $countart				=		count( $art_info );
		
        $package_type       =   'chapter';
        $process_type       =   'Regular';
        
        if( strpos( 'Regular' , $jobDetai->JOB_TYPE ) ){
            $package_type   =       'chapter';
            $process_type   =       'Regular';
        }else if( strpos( 'Series' , $jobDetai->JOB_TYPE )  ) {
            $package_type   =       'Series';
            $process_type   =       'Regular';
        }else{
            
        }
        
        $package_type       =   'eproof';       
        $process_type       =   '';   
        
        if( $typeofpprcoess == 'package' )
             $process_type   =   'package';
        
        
        if( $typeofpprcoess == 're-package' )
            $process_type   =   're-package';
        
        if( $typeofpprcoess == 'submissionchecker' )
             $process_type   =   're-package';
        
       
        $return_arr['packagetype']['tagtext']       =   '';
        $return_arr['packagetype']['@attributes']   =   array( 'type' => $package_type );
        
        $return_arr['processtype']['tagtext']       =   '';
        $return_arr['processtype']['@attributes']   =   array( 'type' => $process_type );
        
        $return_arr['applicationplatform']['tagtext']       =   '';
        $return_arr['applicationplatform']['@attributes']   =   array( 'type' => '3B2' );
        
        $js_cpy_const           =   Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
        $cmn_obj                =   new CommonMethodsController();
        $defaultCopyPath        =   $cmn_obj->backslashPathPrepare($defaultCopyPath, true);
        $chap_no_test           =   str_replace( 'CHAPTER_', '' , strtoupper( $chapterlist[0] ) );
        $chap_no_test           =   str_replace( 'PART_', '' , strtoupper( $chap_no_test ) );
        
        $inp_rep_arr            =   array(  
                                            '{BID}' => $book_id ,
                                            'BOOK_ID'       =>  $book_id ,
                                            'ROUND_NAME'    =>  $roundname ,
                                            'STAGE_NAME'    =>  $roundname , 
					    '{RID}' => $roundname,
					    '{CRID}' => $conventional_roundname , 
					    '{CID}' => $chapterlist[0] , 
                                            '{CNO}' => $chap_no_test ,  '{DID}' =>  $preparedDatasetid , 
					    '{EMPID}'   => $empid ,
                                            '{PAGING_FILENAMING}' => $pagingfilnaming , 
				            '{CNAME}' => $chapterlist[0] , 
					    '{RNAME}' => $roundname , 
                                    );
        
        $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
        $naming                 =   config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        
        $namin_convention       =   $naming[$round_arr[$round]];
         
        $getlocationftp         =   productionLocationModel::doGetLocationname( $job_id );
        if( empty( $getlocationftp ) )
        $getlocationftp         =   productionLocationModel::getDefaultProductionLocationInfo();
        
        //need to dynamicaly bind the production location based on table location
        $hostserver             =   $getlocationftp->FTP_HOST;
        $hostpath               =   $getlocationftp->FTP_PATH;
        $addeftpath             =   Config::get( 'constants.FILE_SERVER_ROOT_DIR');
        $artimages              =   $hostserver.$addeftpath.$hostpath.config::get('constants.ART_DESTINATION_PATH').$book_id.'/'.$chapterlist[0].'/';
        
        $esmpath               =      DB::table('metadata_info')->select()->where( 'METADATA_ID'  ,  '=' , $metaid )->get()->first();
        $esmpath               =      ($esmpath->TYPE_OF_CONTAINESM == 'YES')? 1: 0;
        
        $inputfilepath          =   array( 
                                       'bookprintpdf'   =>  '' , 'bookprintpdfpitstoplog'   =>  '' , 'bookmycopypdf'   =>   '',
                                       'bookmycopypdfpitstoplog'   =>  '' , 'bookcoverprintpdf'   =>  '' ,'bookprintcoverpdfpitstoplog' => '',
                                       'bookcoverimage'   =>  ''  , 'bookmycopycoverpdf'   =>  '' , 'bookmycopycoverpdfpitstoplog'   =>  '' ,
                                       'bookepsilonpdf'   =>   '' , 'bookchecklist'   =>   '' , 
                                       'xmlfile'   =>   '', 'pdffile'   =>  '' , 'pitstopstopfile'   =>   '', 'refpdffile'   =>   '', 'deltapdffile' => '',
                                       'epsilonpdffile' => '' ,
                                       'textfile'   =>   '', 'proofpdffile'   =>  '' , 'lowresimagefolder'   =>  '' , 'highresimagefolder'   =>     ''   ,                                     
                                       'highresimagefolder'   =>     '' , 'stripinsfolder'       =>  '' , 'esmdetails' => '' ,'destinationPath' => '' , 
                                       'authorpdflocation'  => '' , 'failure_package_path' => '', 'failure_package_path2' => ''
                                );
        
        // check taps or conventional chapter
        $packagepathreplace     =   (isset($taskLevelInfo[0]->PRODUCTION_SYSTEM) && $taskLevelInfo[0]->PRODUCTION_SYSTEM == 1?Config::get( 'constants.PACKAGE_PATH'):Config::get( 'constants.CONVENTIONAL_PACKAGE_PATH'));
        
        foreach( $inputfilepath as $key_in  => $value ){
            $findkeyindex       =   strtoupper( $key_in );
            $lastpath           =   $hostserver.'/'.$addeftpath.(isset($packagepathreplace[$findkeyindex])?$packagepathreplace[$findkeyindex]:'');
            $lastpath           =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lastpath , true );
            $lastpath           =   $cmn_obj->backslashPathPrepare( $lastpath , true );
            
            $inputfilepath[$key_in]     =   $lastpath;
            
        }
        
        //art image path changes
        $artimagepath           =   $cmn_obj->backslashPathPrepare( $artimages , true );
        
        //vendor xml path preparation
        $bookidreplace          =   array(
                                        'BOOK_ID'       =>  $book_id
                                     );
        
        $vendorxmlpath          =   \Config::get( 'constants.VENDORXML_FILE');        
        $vendorxmlpath          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $vendorxmlpath , true );
        $vendorxmlpath          =   $hostserver.'/'.$addeftpath.$vendorxmlpath;
        $vendorxmlpath          =   $cmn_obj->backslashPathPrepare( $vendorxmlpath , true );
        extract( $inputfilepath );
        
        if( $esmpath == 0 ){
            $esmdetails = '';
        }
        //extract( $optional );
        if( $optional['level'] == 3 ){
            
            $return_arr['bookprintpdf']                 =       $bookprintpdf;
            $return_arr['bookprintpdfpitstoplog']       =       $bookprintpdfpitstoplog;
            $return_arr['bookmycopypdf']                =       $bookmycopypdf;
            $return_arr['bookmycopypdfpitstoplog']      =       $bookmycopypdfpitstoplog;
            $return_arr['bookcoverprintpdf']            =       $bookcoverprintpdf;
            $return_arr['bookprintcoverpdfpitstoplog']  =       $bookprintcoverpdfpitstoplog;
            $return_arr['bookcoverimage']               =       $bookcoverimage;
            $return_arr['bookmycopycoverpdf']           =       $bookmycopycoverpdf;
            $return_arr['bookmycopycoverpdfpitstoplog'] =       $bookmycopycoverpdfpitstoplog;
            $return_arr['bookepsilonpdf']               =       $bookepsilonpdf;
            $return_arr['bookchecklist']                =       $bookchecklist;
            $return_arr['authorpdflocation']            =       $authorpdflocation;
            
        }
        
        if( count( $optional['metacollect'] ) == 0){
            $array_of_meta      =       array( $metaid );
        }
        
        $preparedCompo      =       array();
        $folernaming_chp        =       $fm_bm_chp.'\\';
        
        foreach( $array_of_meta as $iterate => $prepareMetaid ){
            
            $component_arr                          =   array();
            $component_arr['xmlfile']['tagtext']               =   $xmlfile;
            $xmlfile_name       =       explode( '\\' , $xmlfile );
            $xmlfile_name       =       $xmlfile_name[count( $xmlfile_name ) - 1];
            $component_arr['xmlfile']['@attributes']           =   array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$xmlfile_name );
            
            $component_arr['pdffile']['tagtext']               =   $pdffile;
            $pdffile_name       =       explode( '\\' , $pdffile );
            $pdffile_name       =       $pdffile_name[count( $pdffile_name ) - 1];            
            $component_arr['pdffile']['@attributes']               =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$pdffile_name );
            
            $component_arr['deltapdffile']['tagtext']          =   $deltapdffile;
            $deltapdffile_name       =       explode( '\\' , $deltapdffile );
            $deltapdffile_name       =       $deltapdffile_name[count( $deltapdffile_name ) - 1];            
            $component_arr['deltapdffile']['@attributes']          =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$deltapdffile_name );
            
            $component_arr['EsmDetails']['tagtext']            =   $esmdetails;
            $esmdetails_name       =       explode( '\\' , $esmdetails );
            $esmdetails_name       =       $esmdetails_name[count( $esmdetails_name ) - 1];           
            $component_arr['EsmDetails']['@attributes']            =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$esmdetails_name );
            $component_arr['EsmDetails']    =   '';
            
            //esm file path get data start
            $initEsmObj     =   new esmController();
            $esmDedatils        =   $initEsmObj->getMetaEsmDetails($jobid, $metaid);
            
            if(count($esmDedatils)>=1){
                $esmfiletype = Config::get('constants.ESM_FILE_TYPE');
                foreach( $esmDedatils as $key => $value ){
                    $replaceslash   =   $cmn_obj->backslashPathPrepare($value['filepath'],true);
                   if (in_array($value['FILE_FORMAT'], $esmfiletype)) {
                    $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'ESM','name'=>$replaceslash,'videoID'=>$value['clientid']];
                   }else{
                      $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'Other','name'=>$replaceslash,'videoID'=>$value['clientid']];  
                   }
                }
            }
            //esm file path get data end
            
            $component_arr['authorpdflocation']['tagtext']            =   $authorpdflocation;
            $authorpdflocation_name       =       explode( '\\' , $authorpdflocation );
            $authorpdflocation_name       =       $authorpdflocation_name[count( $authorpdflocation_name ) - 1];           
            $component_arr['authorpdflocation']['@attributes']            =    array(  'userbin'=> $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$authorpdflocation_name );
            
            $component_arr['pitstopstopfile']['tagtext']              =       '';
            $component_arr['pitstopstopfile']['@attributes']              =        array(  'userbin' => '' );
            
            $component_arr['refpdffile']['tagtext']                   =       '';
            $component_arr['refpdffile']['@attributes']                   =        array(  'userbin' => '');
            
            $component_arr['textfile']['tagtext']                     =       '';
            $component_arr['textfile']['@attributes']                     =        array(  'userbin'=>'');
            
            $component_arr['proofpdffile']['tagtext']                 =       '';
            $component_arr['proofpdffile']['@attributes']                 =        array(  'userbin' => '');
            
            $component_arr['highresimagefolder']['tagtext']           =       '';
            $component_arr['highresimagefolder']['@attributes']           =        array(  'userbin' => '');
            
            if( $countart ){
                $component_arr['lowresimagefolder']['tagtext']     =           $lowresimagefolder;
                $lowresimagefolder_name       =       explode( '\\' , $lowresimagefolder );
                $lowresimagefolder_name       =       $lowresimagefolder_name[count( $lowresimagefolder_name ) - 1];           
                $component_arr['lowresimagefolder']['@attributes']     =            array(  'userbin' =>  $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$lowresimagefolder_name );
            }else{
                $component_arr['lowresimagefolder'] =   '';
            }
            
            $component_arr['stripinsfolder']['tagtext']        =           '';
            $component_arr['stripinsfolder']['@attributes']        =            array(  'userbin' =>  '' );
            
            $component_arr['epsilonpdffile']['tagtext']     =   '';
            $component_arr['epsilonpdffile']['@attributes']        =            array(  'userbin' =>  '' );
            $preparedCompo[]                        =   $component_arr;
            
        }    
        
            $return_arr['vendorxmlfile']['tagtext']                    =       $vendorxmlpath.'\\VendorDetails.xml';
            $vendorxmlpath_name                       =       explode( '\\' , $vendorxmlpath.'\\VendorDetails.xml' );
            $vendorxmlpath_name                       =       $vendorxmlpath_name[count( $vendorxmlpath_name ) - 1];
            $return_arr['vendorxmlfile']['@attributes']                =      array( 'userbin' =>  $failure_package_path2.$without_zip_datasetid.$vendorxmlpath_name );

            $return_arr['component']['tagCollect']      =   $preparedCompo;
            $return_arr['component']['tagtext']         =   '';
            $return_arr['component']['@attributes']     =   array( 'name' => $fm_bm_chp );
            
            $return_arr['jobsheetfile']['tagtext']                 =   $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention;
            $jobsheetfile_name                       =       explode( '\\' , $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention );
            $jobsheetfile_name                       =       $jobsheetfile_name[count( $jobsheetfile_name ) - 1];        
            $return_arr['jobsheetfile']['@attributes']                 =    array( 'userbin' =>  $failure_package_path2.$without_zip_datasetid.$jobsheetfile_name );

            $destinationPath                            =   str_replace( 'PACKAGING' , 'EPROOF_PACKAGING' , $destinationPath );
            
            $return_arr['destinationpath']['tagtext']       =       $destinationPath;
            $destinationPath_name                           =       explode( '\\' , $destinationPath );
            unset($destinationPath_name[count( $destinationPath_name ) - 1]);
            $destinationPath_name           =       implode( '\\' , $destinationPath_name );
            //$destinationPath_name                           =       $destinationPath_name[count( $destinationPath_name ) - 1];
            $return_arr['destinationpath']['tagtext']       =       $destinationPath_name.'\\'.$preparedDatasetid_new;
            $return_arr['destinationpath']['@attributes']   =   array( 'userbin' =>  $failure_package_path2.$preparedDatasetid_new );
            
            eproofPackageModel::insert( array( 
                                                'PACKAGE_ID'  =>     $preparedDatasetid_new , 
                                                'TOKEN_KEY'   =>     $optional['tokenkey'] , 
                                                'METADATA_ID' =>     $metaid  , 
                                                'PROCESS_TYPE'=>     ( $typeofpprcoess ==  'package'  ? '1' : '2' ) ,
                                                'ROUND'       =>     $round , 
                                                'START_TIME'  =>     date('Y-m-d H:i:s'), 
                                                'STATUS'     =>     '1.5' 
                                             ) );

        return $return_arr;
    }
    
    public function getEproofPackageInfos650( $metaid = null , $round  , $jobid , $optional , $typeofpprcoess ){
        
        $return_arr         =   array();
        $jb_obj             =   new jobModel();
        $jbs_obj            =   new jobStage();
        $tlm_obj            =   new taskLevelMetadataModel();
        $cmn_obj            =   new CommonMethodsController();
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $roundname          =   $round_arr[$round];
        
        $token_key_failed   =   '';
        
        $jobDetai           =   $jb_obj->getJobdetails( $jobid );
        $book_id            =   $jobDetai->BOOK_ID;
        $job_id             =   $jobid;
        
        $js_cpy_const       =   \Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $defaultCopyPath    =   $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        
        $preparedDatasetid      =       '';
        $bookinfoCont           =       new bookinfoController();
        $preparedDatasetid_new  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round , true , true );
        
        if( $typeofpprcoess == 're-package' ){
            
            $getpackname_rec        =       DB::table('api_eproof_packaging')->select()
                                                ->where( 'JOB_ID'  , '=' , $jobid )
                                                ->where( 'ROUND'  , '=' , $round )->orderBy( 'ID' , 'desc' )->get()->first();
            
            $getpackname            =       $getpackname_rec->PACKAGE_ID;
            $preparedDatasetid      =       $getpackname;
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY.'\\';
            
        }
        
        if( $typeofpprcoess == 'package' ){
            
            $preparedDatasetid  =       $bookinfoCont->prepareSpringerNamingConvention( $job_id , $metaid , $round , true , true );
            
        }
        
        $without_zip_datasetid        =     str_replace( '.zip' , '' , $preparedDatasetid.'\\' );
        $without_zip_datasetid        =     $without_zip_datasetid;
        $typeofpprcoess     =   'package';
        
        
        //$onlychapno         =   str_replace( 'chapter_' , '' , strtolower( $chapterlist[0] ) );
        //$fm_bm_chp          =   $onlychapno.'_Chapter';
        //$fm_bm              =   $taskLevelInfo->pluck('FM_ARTICLE_BM')->toArray();
        //$fmBm               =   $fm_bm[0];
        
        //if( $fmBm == 1 )
        //    $fm_bm_chp      =   'bookfrontmatter';
        //if( $fmBm == 3 )
        //   $fm_bm_chp      =   'backbackmatter';  
        
        $empid              =        \Session::get('users')['emp_id'];
        
        //$pagObj             =       new autoPageController();
        //$paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapterlist[0] , $metaid ); 
        //extract( $paging_collect );
        
        $inp_rep_arr        =   array(
                                        'BOOK_ID'       =>  $book_id,
                                        '{BID}'         =>  $book_id,
                                        //'{CID}'         =>  $chapterlist[0],
                                        //'{CNO}'         =>  $onlychapno,
                                        '{DID}'         =>  $preparedDatasetid ,
                                        '{RID}'         =>  $roundname,
                                        'ROUND_NAME'    =>  $roundname,
                                        'STAGE_NAME'    =>  $roundname ,
                                        '{EMPID}'       =>  $empid , 
                                        '{PAGING_FILENAMING}' => $pagingfilnaming
                                     );
        
        $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $defaultCopyPath );
        
         //$tlam_obj  =    new taskLevelArtMetadataModel();
         //$art_info  =    $tlam_obj->getArtChapterwisefigureInfo( $metaid );
         //$countart  =	 count( $art_info );
		
        $package_type       =   'chapter';
        $process_type       =   'Regular';
        
        if( strpos( 'Regular' , $jobDetai->JOB_TYPE ) ){
            $package_type   =       'chapter';
            $process_type   =       'Regular';
        }else if( strpos( 'Series' , $jobDetai->JOB_TYPE )  ) {
            $package_type   =       'Series';
            $process_type   =       'Regular';
        }else{
            
        }
        
        $package_type       =   'eproof';       
        $process_type       =   '';   
        
        if( $typeofpprcoess == 'package' )
             $process_type   =   'package';
        
        
        if( $typeofpprcoess == 're-package' )
            $process_type   =   're-package';
        
        if( $typeofpprcoess == 'submissionchecker' )
             $process_type   =   're-package';
        
       
        $return_arr['packagetype']['tagtext']       =   '';
        $return_arr['packagetype']['@attributes']   =   array( 'type' => $package_type );
        
        $return_arr['processtype']['tagtext']       =   '';
        $return_arr['processtype']['@attributes']   =   array( 'type' => $process_type );
        
        $return_arr['applicationplatform']['tagtext']       =   '';
        $return_arr['applicationplatform']['@attributes']   =   array( 'type' => '3B2' );
        
        $js_cpy_const           =       \Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
        $cmn_obj                =       new CommonMethodsController();
        $defaultCopyPath        =       $cmn_obj->backslashPathPrepare($defaultCopyPath, true);
        //$chap_no_test           =       str_replace( 'CHAPTER_', '' , strtoupper( $chapterlist[0] ) );
        //$chap_no_test           =       str_replace( 'PART_', '' , strtoupper( $chap_no_test ) );
        
        $inp_rep_arr            =   array(  
                                            '{BID}' => $book_id ,
                                            'BOOK_ID'       =>  $book_id ,
                                            'ROUND_NAME'    =>  $roundname ,
                                            'STAGE_NAME'    =>  $roundname , '{RID}' => $roundname , 
                                            //'{CID}' => $chapterlist[0] , 
                                            //'{CNO}' => $chap_no_test , 
                                            '{DID}' =>  $preparedDatasetid , 
                                            '{EMPID}'   => $empid ,
                                            '{PAGING_FILENAMING}' => $pagingfilnaming , 
                                            //'{CNAME}' => $chapterlist[0] ,  
                                            '{RNAME}' => $roundname , 
                                    );
        
        $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
        $naming                 =   config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        
        $namin_convention       =   $naming[$round_arr[$round]];
         
        $getlocationftp         =   productionLocationModel::doGetLocationname( $job_id );
        if( empty( $getlocationftp ) )
        $getlocationftp         =   productionLocationModel::getDefaultProductionLocationInfo();
        
        //need to dynamicaly bind the production location based on table location
        $hostserver             =   $getlocationftp->FTP_HOST;
        $hostpath               =   $getlocationftp->FTP_PATH;
        $addeftpath             =   Config::get( 'constants.FILE_SERVER_ROOT_DIR');
        $artimages              =   $hostserver.$addeftpath.$hostpath.config::get('constants.ART_DESTINATION_PATH').$book_id.'/'.$chapterlist[0].'/';
        
        $esmpath               =      DB::table('metadata_info')->select()->where( 'METADATA_ID'  ,  '=' , $metaid )->get()->first();
        $esmpath               =      ($esmpath->TYPE_OF_CONTAINESM == 'YES')? 1: 0;
        
        $inputfilepath          =   array( 
                                       'bookprintpdf'   =>  '' , 'bookprintpdfpitstoplog'   =>  '' , 'bookmycopypdf'   =>   '',
                                       'bookmycopypdfpitstoplog'   =>  '' , 'bookcoverprintpdf'   =>  '' ,'bookprintcoverpdfpitstoplog' => '',
                                       'bookcoverimage'   =>  ''  , 'bookmycopycoverpdf'   =>  '' , 'bookmycopycoverpdfpitstoplog'   =>  '' ,
                                       'bookepsilonpdf'   =>   '' , 'bookchecklist'   =>   '' , 
                                       'xmlfile'   =>   '', 'pdffile'   =>  '' , 'pitstopstopfile'   =>   '', 'refpdffile'   =>   '', 'deltapdffile' => '',
                                       'epsilonpdffile' => '' ,
                                       'textfile'   =>   '', 'proofpdffile'   =>  '' , 'lowresimagefolder'   =>  '' , 'highresimagefolder'   =>     ''   ,                                     
                                       'highresimagefolder'   =>     '' , 'stripinsfolder'       =>  '' , 'esmdetails' => '' ,'destinationPath' => '' , 
                                       'authorpdflocation'  => '' , 'failure_package_path' => '', 'failure_package_path2' => ''
                                );
        
       
        foreach( $inputfilepath as $key_in  => $value ){
            
            $lastpath           =   $hostserver.'/'.$addeftpath.Config::get( 'constants.PACKAGE_PATH.'.strtoupper( $key_in ) );
            $lastpath           =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lastpath , true );
            $lastpath           =   $cmn_obj->backslashPathPrepare( $lastpath , true );
            
            $inputfilepath[$key_in]     =   $lastpath;
            
        }
        
        //art image path changes
        $artimagepath           =   $cmn_obj->backslashPathPrepare( $artimages , true );
        
        //vendor xml path preparation
        $bookidreplace          =   array(
                                        'BOOK_ID'       =>  $book_id
                                     );
        
        $vendorxmlpath          =   \Config::get( 'constants.VENDORXML_FILE');
        
        $vendorxmlpath          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $vendorxmlpath , true );
        $vendorxmlpath          =   $hostserver.'/'.$addeftpath.$vendorxmlpath;
        $vendorxmlpath          =   $cmn_obj->backslashPathPrepare( $vendorxmlpath , true );
        extract( $inputfilepath );
        
        if( $esmpath == 0 ){
            $esmdetails = '';
        }
        //extract( $optional );
        if( $optional['level'] == 3 ){
            
            $return_arr['bookprintpdf']                 =       $bookprintpdf;
            $return_arr['bookprintpdfpitstoplog']       =       $bookprintpdfpitstoplog;
            $return_arr['bookmycopypdf']                =       $bookmycopypdf;
            $return_arr['bookmycopypdfpitstoplog']      =       $bookmycopypdfpitstoplog;
            $return_arr['bookcoverprintpdf']            =       $bookcoverprintpdf;
            $return_arr['bookprintcoverpdfpitstoplog']  =       $bookprintcoverpdfpitstoplog;
            $return_arr['bookcoverimage']               =       $bookcoverimage;
            $return_arr['bookmycopycoverpdf']           =       $bookmycopycoverpdf;
            $return_arr['bookmycopycoverpdfpitstoplog'] =       $bookmycopycoverpdfpitstoplog;
            $return_arr['bookepsilonpdf']               =       $bookepsilonpdf;
            $return_arr['bookchecklist']                =       $bookchecklist;
            $return_arr['authorpdflocation']            =       $authorpdflocation;
            
        }
        
        if( count( $optional['metacollect'] ) == 0){
            $array_of_meta      =       array( $metaid );
        }
        
        $preparedCompo      =       array();
        $folernaming_chp        =       $fm_bm_chp.'\\';
        
        foreach( $array_of_meta as $iterate => $prepareMetaid ){
            
            $component_arr                          =   array();
            $component_arr['xmlfile']['tagtext']               =   $xmlfile;
            $xmlfile_name       =       explode( '\\' , $xmlfile );
            $xmlfile_name       =       $xmlfile_name[count( $xmlfile_name ) - 1];
            $component_arr['xmlfile']['@attributes']           =   array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$xmlfile_name );
            
            $component_arr['pdffile']['tagtext']               =   $pdffile;
            $pdffile_name       =       explode( '\\' , $pdffile );
            $pdffile_name       =       $pdffile_name[count( $pdffile_name ) - 1];            
            $component_arr['pdffile']['@attributes']               =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$pdffile_name );
            
            $component_arr['deltapdffile']['tagtext']          =   $deltapdffile;
            $deltapdffile_name       =       explode( '\\' , $deltapdffile );
            $deltapdffile_name       =       $deltapdffile_name[count( $deltapdffile_name ) - 1];            
            $component_arr['deltapdffile']['@attributes']          =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$deltapdffile_name );
            
            $component_arr['EsmDetails']['tagtext']            =   $esmdetails;
            $esmdetails_name       =       explode( '\\' , $esmdetails );
            $esmdetails_name       =       $esmdetails_name[count( $esmdetails_name ) - 1];           
            $component_arr['EsmDetails']['@attributes']            =    array(  'userbin' => $failure_package_path2.$without_zip_datasetid.$esmdetails_name );
            $component_arr['EsmDetails']    =   '';
            
            //esm file path get data start
            $initEsmObj     =   new esmController();
            $esmDedatils        =   $initEsmObj->getMetaEsmDetails($jobid, $metaid);
            
            if(count($esmDedatils)>=1){
                $esmfiletype = Config::get('constants.ESM_FILE_TYPE');
                foreach( $esmDedatils as $key => $value ){
                    $replaceslash   =   $cmn_obj->backslashPathPrepare($value['filepath'],true);
                   if (in_array($value['FILE_FORMAT'], $esmfiletype)) {
                    $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'ESM','name'=>$replaceslash,'videoID'=>$value['clientid']];
                   }else{
                      $component_arr['EsmDetails'][]['File']['@attributes']     =   ['type'=>'Other','name'=>$replaceslash,'videoID'=>$value['clientid']];  
                   }
                }
            }
            //esm file path get data end
            
            $component_arr['authorpdflocation']['tagtext']            =   $authorpdflocation;
            $authorpdflocation_name       =       explode( '\\' , $authorpdflocation );
            $authorpdflocation_name       =       $authorpdflocation_name[count( $authorpdflocation_name ) - 1];           
            $component_arr['authorpdflocation']['@attributes']            =    array(  'userbin'=> $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$authorpdflocation_name );
            
            $component_arr['pitstopstopfile']['tagtext']              =       '';
            $component_arr['pitstopstopfile']['@attributes']              =        array(  'userbin' => '' );
            
            $component_arr['refpdffile']['tagtext']                   =       '';
            $component_arr['refpdffile']['@attributes']                   =        array(  'userbin' => '');
            
            $component_arr['textfile']['tagtext']                     =       '';
            $component_arr['textfile']['@attributes']                     =        array(  'userbin'=>'');
            
            $component_arr['proofpdffile']['tagtext']                 =       '';
            $component_arr['proofpdffile']['@attributes']                 =        array(  'userbin' => '');
            
            $component_arr['highresimagefolder']['tagtext']           =       '';
            $component_arr['highresimagefolder']['@attributes']           =        array(  'userbin' => '');
            
            if( $countart ){
                $component_arr['lowresimagefolder']['tagtext']     =           $lowresimagefolder;
                $lowresimagefolder_name       =       explode( '\\' , $lowresimagefolder );
                $lowresimagefolder_name       =       $lowresimagefolder_name[count( $lowresimagefolder_name ) - 1];           
                $component_arr['lowresimagefolder']['@attributes']     =            array(  'userbin' =>  $failure_package_path2.$without_zip_datasetid.$folernaming_chp.$lowresimagefolder_name );
            }else{
                $component_arr['lowresimagefolder'] =   '';
            }
            
            $component_arr['stripinsfolder']['tagtext']        =           '';
            $component_arr['stripinsfolder']['@attributes']        =            array(  'userbin' =>  '' );
            
            $component_arr['epsilonpdffile']['tagtext']     =   '';
            $component_arr['epsilonpdffile']['@attributes']        =            array(  'userbin' =>  '' );
            $preparedCompo[]                        =   $component_arr;
            
        }    
        
            $return_arr['vendorxmlfile']['tagtext']                    =       $vendorxmlpath.'\\VendorDetails.xml';
            $vendorxmlpath_name                       =       explode( '\\' , $vendorxmlpath.'\\VendorDetails.xml' );
            $vendorxmlpath_name                       =       $vendorxmlpath_name[count( $vendorxmlpath_name ) - 1];
            $return_arr['vendorxmlfile']['@attributes']                =      array( 'userbin' =>  $failure_package_path2.$without_zip_datasetid.$vendorxmlpath_name );

            $return_arr['component']['tagCollect']      =   $preparedCompo;
            $return_arr['component']['tagtext']         =   '';
            $return_arr['component']['@attributes']     =   array( 'name' => $fm_bm_chp );
            
            $return_arr['jobsheetfile']['tagtext']                 =   $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention;
            $jobsheetfile_name                       =       explode( '\\' , $default_jobsheet_path.$book_id.'_'.$chap_no_test.$namin_convention );
            $jobsheetfile_name                       =       $jobsheetfile_name[count( $jobsheetfile_name ) - 1];        
            $return_arr['jobsheetfile']['@attributes']                 =    array( 'userbin' =>  $failure_package_path2.$without_zip_datasetid.$jobsheetfile_name );

            $destinationPath                            =   str_replace( 'PACKAGING' , 'EPROOF_PACKAGING' , $destinationPath );
            
            $return_arr['destinationpath']['tagtext']       =       $destinationPath;
            $destinationPath_name                           =       explode( '\\' , $destinationPath );
            unset($destinationPath_name[count( $destinationPath_name ) - 1]);
            $destinationPath_name           =       implode( '\\' , $destinationPath_name );
            //$destinationPath_name                           =       $destinationPath_name[count( $destinationPath_name ) - 1];
            $return_arr['destinationpath']['tagtext']       =       $destinationPath_name.'\\'.$preparedDatasetid_new;
            $return_arr['destinationpath']['@attributes']   =   array( 'userbin' =>  $failure_package_path2.$preparedDatasetid_new );
            
            eproofPackageModel::insert( array( 
                                                'PACKAGE_ID'  =>     $preparedDatasetid_new , 
                                                'TOKEN_KEY'   =>     $optional['tokenkey'] , 
                                                'METADATA_ID' =>     $metaid  , 
                                                'PROCESS_TYPE'=>     ( $typeofpprcoess ==  'package'  ? '1' : '2' ) ,
                                                'ROUND'       =>     $round , 
                                                'START_TIME'  =>     date('Y-m-d H:i:s'), 
                                                'STATUS'     =>     '1.5' 
                                             ) );

        return $return_arr;
    }
    
    public function configurationIndex( $stageid , $round , $wmid , $wfid ='' , $bgtype = '' , $mode = '' ){
       
        $data                   =       array();
            $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
            $data['pageTitle']  = 	'bg Setup';
            $stage_info         =       DB::table('stage')->select()->where('STAGE_ID' , '=' , $stageid )->get()->first();
            
            $data['pageName']   =       'BgProcess Configuration ';

            $data['user_name']  =       Session::get('users')['user_name'];
            $data['role_name']  =       Session::get('users')['role_name'];
            $data["userId"]     =       Session::get('users')['user_id'];
            
            $stageCollection    =       array();
            $where_condition    =       array( 'IS_AUTO' => 1 );
            
            $stage_obj          =       new stageModel();
            //$stageCollection    =       $stage_obj->getAllStageInfo( array() , $where_condition );
            $stageoption        =       '';
            
            foreach( $stageCollection as $keyindex => $valuearr ){
                $stageoption    .= "<option value='$valuearr->STAGE_ID'>$valuearr->STAGE_NAME</option>";  
            }
            
            $data['stageOption']        =       $stageoption;
            $data['stageid']            =       $stageid;
            $data['round']              =       $round;
            $data['wmid']               =       $wmid;
            $data['wfid']               =       $wfid;
            $data['bgtype']             =       $bgtype;
            $data['modetype']           =       $mode;
            $data['stagename']          =       $stage_info->STAGE_NAME;
            
            
        return view('bgprocess.configurationIndex')->with( $data );
        
    }
    
    public function storenNewChunk( Request $request ){
        
        $chnkarr        =       array();
        
        $chnkarr['ROUND']       =   $request->input('round');
        $response               =   $this->oopsErrorResponse;
        //try{
        
            $stageid =  $request->input('stageid');
            $round   =  $request->input('round');
            $wmid    =  $request->input('wmid');
            $wfid    =  $request->input('wfid');
            $type    =  $request->input('type');
            
            if( !isset( $type ) ){
                $type   =   1;
            }
            $chnkarr['WORKFLOW_MASTER_ID']  =       $request->input('wmid');
            $chnkarr['WORKFLOW_ID']         =       $request->input('wfid');
            $chnkarr['PROCESS_NAME']        =       strtoupper($request->input('tagname'));
            $chnkarr['TYPE']                =       $type;
            $chnkarr['STAGE_ID']            =       $request->input('stageid');
            $chnkarr['TAG_NAME']            =       $request->input('tagname');
            $chnkarr['created_by']          =       Session::get('users')['user_id'];
            
            //getOrder
            $ExistingRec        =   DB::table('bgprocess_path_setup')->select()
                    ->where( 'STAGE_ID' , '='  , $stageid )
                    ->where( 'ROUND' , '='  , $round )
                    ->where( 'WORKFLOW_MASTER_ID' , '='  , $wmid )
                    ->where( 'WORKFLOW_ID' , '='  , $wfid )
                    ->where( 'TYPE' , '='  , $type )
                    ->orderBy('ORDER' , 'DESC')
                    ->get()->first();
            
            if( count( $ExistingRec )  > 0  ){
                $chnkarr['ORDER']      =       intval($ExistingRec->ORDER)+1 ; 
            }
            
            $bgps       =       new bgprocessPathSetup();
            $bgps->insertNew($chnkarr);

            $response               =   $this->insertedResponse;
            
        //}catch( \Exception $e ){
            
        //}
        
        return response()->json( $response );
        
    }
    
    public function storeBgSetupXml( Request $request ){
        
        $xmldoc     =       $request->xmlFormat;
        $response               =   $this->oopsErrorResponse;
        try{

            $bgtags                 =           array( );
            $parent_id              =           $request->input('chunkid');
            $bgtags['PARENT_ID']    =           $parent_id;
            $bgtags['TAG_FORMAT']   =           $request->input( 'xmlFormat' );

            $bgtags_obj     =       new bgprocessTagsSetup();
            $hasRecord      =       $bgtags_obj->getBgProcessTags( $parent_id );
            
            if( $hasRecord->count() ){
                //do update 
                $inp_arr['MODIFIED_BY'] = Session::get('users')['user_id'];
                $bgtags_obj->updateIfExist($bgtags, $hasRecord[0]->ID );
                $response               =   $this->updatedResponse; 
                
            }else{
                $bgtags['STATUS']  =   1 ; 
                $bgtags['CREATED_BY'] = Session::get('users')['user_id'];
                //insert 
                $bgtags_obj->insertNew($bgtags);
                $response               =   $this->insertedResponse;   
            }
            
            
        } catch (Exception $ex) {
             
        }
        
        return response()->json( $response );
        
    }
    
    public function validateFormatXml( Request $request ){
     
        $xmldoc     =       $request->xmlFormat;
        
        // LOAD XML FILE CONTENT
        $XML    =   new \DOMDocument(); 
        $XML->loadXML($xmldoc);
        
        $dom    =   new \DOMDocument;
        $dom->preserveWhiteSpace = FALSE;
        $error  =   'Tag syntax error ';   
        $dom->loadXML( trim( $xmldoc ) );
        $dom->formatOutput  =   TRUE;
        $var_cpy    =       $dom->saveXml();
        $var_cpy  = str_replace( '<?xml version="1.0"?>' ,  '' , $var_cpy);
        
        if( trim( $var_cpy ) !== '<?xml version="1.0"?>' ){
            echo $var_cpy;			
        }else{
            echo $var_cpy;            
        }
        
    }
    
    public function getBgSetupStructure(  $stageid  , $round , $wmid  , $wfid , $bgtype = null , $mode = null ){
        
        $dataColl        =   array();
        
        if( !is_null( $mode ) ){
            
            switch($mode){
               case 'autoserver': 
                   $mode    =   'autopage';
                   break;
            }
            
            $bgtype =   $bgtype.'_'.$mode;
        }
        
        $bgprocesPath        =       new bgprocessPathSetup();
        $stage_id            =       $stageid;
        $parent_info         =       $bgprocesPath->getSetup(  $stageid  , $round  , $wmid  , $wfid , $bgtype );
           
        $return_val     =   array();
        $subtbl_obj         =       new bgprocessTagsSetup( ); 
       
        foreach( $parent_info as $index => $value ){
             
            $innerTags      =       $subtbl_obj->getBgProcessTags( $value->ID );
            $taginfo        =       '';
            
            if( isset( $innerTags[0] ) ){
                $taginfo    =       ( $innerTags[0]->TAG_FORMAT );
            }
            
            $return_val[$value->TAG_NAME]   =   array( 'ID' => $value->ID  ,  'TAG_TEXT'  => $taginfo );
        }

        $dataColl['WorkflowMetadata']   =   $return_val;
            
        return response()->json( $dataColl );    
        
    }
    
    public function triggerCommonWayBgProcess( Request $request ){
        
        $request_input      =   $request->all();
        
        $response               =   $this->oopsErrorResponse;
        extract( $request_input );
       
        try{
			
        $jbstg          =       new jobStage();
        $statusI        =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
   
        $curStgInfo     =       $jbstg->getCurrentJobStageInfo( $metaid , $round  , $statusI );
     
            if( count( $curStgInfo ) ){

                $curStgInfo         =   $curStgInfo[0];
                $optionparamjson    =   null;
                $packagestageid     =	\Config::get( 'constants.STAGE_COLLEECTION.PACKAGE' );
                
                $this->buildOptionalParamIfRequired(  $curStgInfo->STAGE_ID , $optionparamjson , $curStgInfo );
				
                if( count( $curStgInfo ) ){

                    $stgmnger           =       new stageMangerController();
                    $trigJbstgid        =       $curStgInfo->JOB_STAGE_ID;
                    $trigstgid          =       $curStgInfo->STAGE_ID;

                    //yet to do trigger autostage
                    $response   =       $stgmnger->handlingAutoStages($trigstgid, $trigJbstgid , $optionparamjson );

                }

            }else{
                $reason	=	'Not able to get CurrentStage information ';
                throw new \Exception( $reason );

            }
        
	}catch(\Exception $ex ){
			
            $response['reason'] =   $ex->getTraceAsString();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';               
			
        }
        
        return response()->json( $response);
    }
    
    
     public function retryBookMergeProcess( Request $request ){
        
        $request_input      =   $request->all();
       
        $bData['jobId']     = $request_input['job_id'];
        $bData['roundid']   = $request_input['round'];
             
       
        
        $response               =   $this->oopsErrorResponse;
       // extract( $request_input );
        
        try{
            
            $response           = app('App\Http\Controllers\checkout\stageManagerCustomController')->triggerBookBuldingProcess((object)$bData);
	
            
        }catch(\Exception $ex ){
			
            $response['reason'] =   $ex->getTraceAsString();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';               
			
        }
        
        return response()->json( $response);
    }
    
    public function buildOptionalParamIfRequired( $stageid , &$return_array , &$additionalinput  ){
     
	 try{
		 
        if( !is_null( $stageid ) ){
            
            $return_array   =       array();
             
            switch( $stageid ){
                
                case \Config::get( 'constants.STAGE_COLLEECTION.PACKAGE' ):                    
                        $array_input        =   array( 'contactinform' => 1 , 'packageoperation' => 're-package' );
                       // $return_array       =   (object)array( 'optionalParamJson' => json_encode( $array_input ) );
                        $return_array       =    (object)array( 'optionalParamJson' => json_encode( $array_input ) );
                    break;
                
                case \Config::get( 'constants.STAGE_COLLEECTION.PACKAGING' ):                    
                        $array_input        =   array( 'contactinform' => 1 , 'packageoperation' => 're-package' );
                       // $return_array       =   (object)array( 'optionalParamJson' => json_encode( $array_input ) );
                        $return_array       =    (object)array( 'optionalParamJson' => json_encode( $array_input ) );
                    break;	
                case \Config::get( 'constants.STAGE_COLLEECTION.SUCCESS_REDO' ):     
					
					$succesredostg	=	\Config::get( 'constants.STAGE_COLLEECTION.SUCCESS_REDO' );	
					$stgMgObj       =       new stageMangerController();
					$curStgInfo     =       $additionalinput;
					
					$jobStageId		=		$curStgInfo->JOB_STAGE_ID;
					$metaid         =		$curStgInfo->METADATA_ID;
					$round          =		$curStgInfo->ROUND_ID;
					$array_input    =   	array( 'contactinform' => 1 , 'packageoperation' => 're-package' );
					
					if($round == '119' || $round == '120' ){
						$gotostage      =   	\Config::get( 'constants.STAGE_COLLEECTION.RE_PACKAGE' );
					}else{
						$gotostage      =   	\Config::get( 'constants.STAGE_COLLEECTION.PACKAGING' );
					}
					
					$remarks        =   	'client acknowledgement failure case ';
			
					$returns 		=		$stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );  
					$iteration_	= 0;
					
					//$returns['status'] = 1;
					sleep(3);
					
					if( intval( $returns['status'] ) == 1 ){
						
						if( false ){
							refindresumestage:
						}
						
						$jbstg          =   	new jobStage();
						$statusI        =   	\Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
						$responseData     =   	$jbstg->getCurrentJobStageInfo( $metaid , $round  , $statusI );
						$curStgInfo        = $responseData['0'];
												
						$additionalinput		=		$curStgInfo;
												
						$iteration_++;
						if( ( $iteration_ < 10 && $curStgInfo->STAGE_ID == $succesredostg ) || empty ( $curStgInfo ) )
							goto refindresumestage;
					
						
					}else{
						
						$iteration_++;
						if( ( $iteration_ < 10 && $curStgInfo->STAGE_ID == $succesredostg ) || empty ( $curStgInfo ) )
							goto refindresumestage;
					
					}
					
                    break;	 
                
            }
        
            return $return_array;
			
			
            
        }
        
        return $processid;
		
		}catch(\Exception $ex ){
			
			echo $ex->getTraceAsString();;exit;
            $response['reason'] =   $ex->getTraceAsString();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';               
			
        }
    }
    
    public function bgsettingindex(){
        
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        
        $data['pageTitle']  =   'BG Setting';
        $data['pageName']   =   'BG Setting';
        
        if( Session::has('users')=='' ){
            return redirect('/');
        }
                  
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data['role_id']    =   Session::get('users')['role_id'];
        
        $data['stageid']    =   '';
        $data['round']      =   '';
        $data['wmid']       =   '';
        $data['wfid']       =   '';
        $data['bgtype']     =   '';
        $data['modetype']   =   '';
        $data['caption']    =   '';
        $data['stagename']  =   '';
	
        
        return view('bgprocess.bg-setting')->with($data);	
        
    }
    
    public function getBgProcessConfiguredList(){
            
        
        
    }
    
    public function triggerBgProcessApnPdf( Request $request ){
         
        $request_input      =   $request->all();
        
        $response               =   $this->oopsErrorResponse;
        extract( $request_input );
        
        try{
			
            $jbstg          =       new jobStage();
            $statusI        =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
            $curStgInfo     =       $jbstg->getCurrentJobStageInfo( $metaid , $round  , $statusI );
            $pitsObj        =       new pitstopController();
            
            if( $producttype  == 'online' ){
                $pitsObj->startOnlineProcessComponentwise( $metaid , $round   );
            }
            if( $producttype  == 'print' ){
                $pitsObj->startPrintProcessComponentwise( $metaid , $round  );
            }
            
	}catch(\Exception $ex ){
			
            $response['reason'] =   $ex->getTraceAsString();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';               
			
        }
        
        return response()->json( $response);
        
    }
    
}
