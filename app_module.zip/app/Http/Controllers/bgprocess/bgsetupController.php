<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\bgprocess;
use App\Http\Controllers\Controller;
use App\Http\Controllers\users\usersController;
use App\Models\bgProcessModel;
use App\Models\jobModel;
use App\Models\jobStage;
use App\Models\stageModel;
use App\Models\checkoutModel;
use App\Models\eproofPackageModel;
use App\Models\bgprocessPathSetup;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\workflowMasterModel;
use App\Models\productionLocationModel;
use App\Models\bgprocessSubPathSetup;
use App\Models\bgprocessTagsSetup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\bgprocess\productionToolsController;
use App\Http\Controllers\Api\autostageController;
use App\Http\Controllers\contact\contactController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\Api\referencePdfController;
use App\Http\Controllers\Api\esmController;
use App\Http\Controllers\Api\esmFileNameController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\Api\packageController;
use App\Http\Controllers\custom\errorController;
use Session;
use Excel;
use Validator;
use Config;
use DB;
use Carbon\Carbon;
use Mail;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Log;
use App\Http\Controllers\bookinfo\bookinfoController;

class bgsetupController extends Controller
{ 
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
       
    public function index() {
    
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW') ,  $data);
        
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
        
        $subcircle      =       \Config::get( 'constants.CIRCLE.SUBCIRCLEID' );    
        $circle         =       null;
        
        $wflwMstrObj        =       new workflowMasterModel(  );
        $getWorkflowrec     =       $wflwMstrObj->getProjectWorkflows( $circle ,  $subcircle ); 
        $wrflwbuidedarr     =       array();
        $workflowlistoptions        =   array();
        $workflowlistoptionsstr        =   '';
        
        if( count( $getWorkflowrec ) ){
            
            foreach( $getWorkflowrec as $key => $getrec ){
                
                $workflowlistoptions["$getrec->WORKFLOW_MASTER_ID"]  =     $getrec->WORKFLOW_MASTER_NAME;      
                
            }
            
            foreach( $workflowlistoptions as $key => $value ){
                
                $workflowlistoptionsstr.=  "<option value='$key' data-count='' >$value</option>";
                
            }
            
            
        }
        
        
        $data['workflowmasterlist']   =       $workflowlistoptionsstr;
        //$data['workflowlist']          =       $workflowlistoptionsstr;
        
        return view('bgprocess.bg-index')->with($data);	
        
    }
    
}
