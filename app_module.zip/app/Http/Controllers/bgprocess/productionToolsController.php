<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\bgprocess;
use App\Http\Controllers\Controller;
use App\Http\Controllers\users\usersController;
use App\Models\productionApplicationList;
use App\Models\toolsServerLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Excel;
use Validator;
use Config;
use DB;
use Carbon\Carbon;
use Mail;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Log;

class productionToolsController extends Controller
{
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function getLocationAplicationBasedToolsMachineName( $application , $locaitonid , $mode_opt = null){
        
        $returnVal      =       '';
        
        $toolrec        =       productionApplicationList::select()
                                    ->where( 'TOOLS_NAME' , '=' , strtoupper( $application ) )
                                    ->where( 'STATUS' , '=' , 'Y' );
        
            if( !is_null( $mode_opt ) ){
                $toolrec->where( 'MODE' , '=' , $mode_opt );
            }
        
        $toolrec        =       $toolrec->orderBy( 'ID' , 'desc' )
                                    ->get()->first();
        
       
        if(count( $toolrec )){
            
            $appln_id           =       $toolrec->ID;
            
            $applicationinfo    =       toolsServerLocation::select()
                                            ->where( 'PRODUCTION_AREA' , '=' , $locaitonid )
                                            ->where( 'APPLN_NAME_ID' , '=' , $appln_id)
                                            ->where( 'STATUS' , '=' , 'ACTIVE' )
                                            ->orderBy( 'ID' , 'desc' )
                                            ->get()
                                            ->first();
            
            if( count( $applicationinfo ) ){
                
                $returnVal          =       $applicationinfo->SERVER_IP;
            
            }
            
        }
        
        return $returnVal;
        
    }
    
    public function getLocationAplicationBasedToolsPathInfo( $application , $locaitonid , $mode_opt = null , $round = 118  , $producttype = 'ONLINE' ){
        
        $returnVal      =       '';
        $applicationinfo    =       false;
       
        $toolrec        =       productionApplicationList::select()
                                    ->where( 'TOOLS_NAME' , '=' , strtoupper( $application ) )
                                    ->where( 'STATUS' , '=' , 'Y' );
        
        if( !is_null( $mode_opt ) ){
            $toolrec->where( 'MODE' , '=' , $mode_opt );
        }
        
        $toolrec        =       $toolrec->orderBy( 'ID' , 'desc' )
                                    ->get()->first();
        
       
        if(count( $toolrec )){
            
            $appln_id           =       $toolrec->ID;
            $applicationinfo    =       toolsServerLocation::select()
                                            ->where( 'PRODUCTION_AREA' , '=' , $locaitonid )
                                            ->where( 'APPLN_NAME_ID' , '=' , $appln_id)
                                            ->where( 'STATUS' , '=' , 'ACTIVE' );
            
            if( !is_null( $round ) ){
                $applicationinfo->where( 'ROUND' , '=' , $round );
            }

            if( !is_null( $mode_opt ) ){
                $applicationinfo->where( 'PRODUCT_TYPE' , '=' , $producttype );
            }
        
        
            $applicationinfo    =   $applicationinfo->orderBy( 'ID' , 'desc' )
                ->get()
                ->first();
            
            if( count( $applicationinfo ) ){
                $returnVal          =       $applicationinfo;
            }
            
        }

        return $returnVal;
        
    }
    
    
}