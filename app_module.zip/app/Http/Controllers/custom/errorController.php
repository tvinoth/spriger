<?php
namespace App\Http\Controllers\custom;
use App\Http\Controllers\Controller;
use App\Jobs\StageemailAlert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;
use Illuminate\Support\Facades\Mail;

class errorController extends Controller
{        
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        
        parent::__construct();
        
            $this->loginUserId  =   Session::get('users')['user_id'];
            $this->teamId       =   Session::get('users')['team_id'];
            $this->roleId       =   Session::get('users')['role_id'];
            $this->empId        =   Session::get('users')['emp_id'];
            $this->userName     =   Session::get('users')['user_name'];
            $this->roleName     =   Session::get('users')['role_name'];
            
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
        
    }
    
    public function getErrorMsg( Request $request ){

        $msg		=	'';
        
        $data           =       array();
        $cntlr          =       $request->input('cntlr');			
        $code           =       $request->input('code');
        $dt             =       '.';
        
        $const_var_key  =       'customError.Controller.'.$cntlr.$dt.$code;
        $config_var     =       (  \Config::get( $const_var_key) );
        
        $msg            =       $config_var['msg'];
        $errorAt        =       $config_var['coding_in'];
        $errorAtN        =       $config_var['notify'];

        $data['errStr']     =       $msg;
        $data['lineno']     =       $errorAt;
        $data['notify']     =       $errorAtN;

        return $data;

    }
    
    public function handleApplicationErrors( $e ){
        
        $errorMsg   =      '<div class="col-md-12 row">'
                                .'Error on line '.$e->getLine()
                                .' in '.$e->getFile()
                                .' : <br/> <h4>'.$e->getMessage()
                                .'</h4><br/><br/><p>'
                                .$e->getTraceAsString()
                                .'</p></div>';
            
        $userid     =       '';

        if(Session::has('users'))
            $userid         =       $username       =        Session::get('users')['user_id'];;

        return DB::table('magnus_error_log')->insertGetId(
            ['EXCEPTION' => $errorMsg , 'USERID' => $userid ]
        );

        //$this->sendMailNotification($errorMsg );    
        
    } 
	
    public function sendMailNotification( $errorMsg  ){
     
        $mailArr                    =       array();
        $data['bodycontent']        =       '';
        $data['Title']              =       'Magnus Log';
        
        $filepathloc                =       'customError/appErrTemplate.txt';
        
        if(file_exists(public_path().'/'.$filepathloc)){
            $logfiles               =        file_get_contents(public_path().'/'.$filepathloc );
            $contenttowrite         =        ($logfiles);
            $contenttowrite         =        str_replace( '{ERR_LOG}' , $errorMsg , $contenttowrite );
            $data['bodycontent']    =        nl2br( strip_tags( $contenttowrite , '<br/>' ) ) ;
            
        }
        
        $mailArr['Data']            =       $data;
        $mailArr['TemplateName']    =       'emailtemplate.customError.emailalert';
        $mailArr['Subject']         =       'Magnus Springer Application Log';
        $mailArr['FromMail']        =       \Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArr['FromName']        =       'Magnus Log';
        
        $mailArr['ToMail']          =       \Config::get('dynamicConstant.MAGNUSALERTMAILID.DEVELOPER2');
       
        $return     =   StageemailAlert::dispatch($mailArr)->onQueue('emails');        
    
    }
    
  
}

 