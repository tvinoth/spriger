<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\download;
use App\Http\Controllers\Controller;
use App\Models\downloadModel;
use App\Models\checkItemsModel;
use App\Models\productionLocationModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiClientAcknowledgement;
use App\Models\jobsheetViewpathModel;
use App\Models\jobModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Models\projectModel;
use Session;
use Excel;
use Storage;
use Validator;
use Config;
use DB; 
use Mail;
use Illuminate\Support\Facades\Crypt;
ini_set( 'max_execution_time' , 0 );
class downloadController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    public function __construct()
    {  
       if(Session::has('users')==''){
           return redirect('/');
       }
    }
       
    public function downloadList() {
       
        $data['pageTitle']  =   Config::get('constants.ROUND_NAME.104').'/'.Config::get('constants.ROUND_NAME.114').' Download';
        $data['pageName']   =   Config::get('constants.ROUND_NAME.104').'/'.Config::get('constants.ROUND_NAME.114').' Download';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data['role_id']    =   Session::get('users')['role_id'];
        $rolenames          =   ['Project Manager','Account Manager'];
        $data['assigneditemshow']   =   ((in_array($data['role_name'],$rolenames)  ==  true)?1:0);
	return view('download.download')->with($data);	
    }
    
    
    public function getDownloadFailedList() {
	
        $arrData    =   array();
        $wherein    =   [Config::get('constants.ROUND_ID.S5'),Config::get('constants.ROUND_ID.S50')];
        $data       =   downloadModel::getDownloadFailedList($wherein);           
        $response["downloadfailed"] = $data;
        return response()->json($response);   
    }
    
    public function jobassigned(){
        try{
        $arrData    			=   array();
        $data                    	=   downloadModel::getJobassigned(); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45'); 
        $datanew                        =   [];
        foreach($data   as $key=>$value)
        {
            $datanew[$key]['JOB_ID']    =   $value->JOB_ID;
            $datanew[$key]['BOOK_ID']   =   $value->BOOK_ID;
            $datanew[$key]['ROUND_ID']  =   $value->ROUND_ID;
            $datanew[$key]['ROUND']     =   $value->ROUND;
            $datanew[$key]['ROUND_NAME']    =   $value->ROUND_NAME;
            $datanew[$key]['ACTIVE']    =   $value->ACTIVE;
            $datanew[$key]['JOB_TITLE'] =   $value->JOB_TITLE;
            $datanew[$key]['AUTHOR_NAME']   =   $value->AUTHOR_NAME;
            $datanew[$key]['EDITOR_NAME']   =   $value->EDITOR_NAME;
            $datanew[$key]['LOCATION']  =   $value->LOCATION;
            $datanew[$key]['JOB_ASSIGNED_DATE']     =   $value->JOB_ASSIGNED_DATE;
            $datanew[$key]['receivedDate']  =   $value->receivedDate;
            $datanew[$key]['CLIACKID']      =   $value->CLIACKID;
            $datanew[$key]['ISSN_ONLINE']   =   $value->ISSN_ONLINE;
            $datanew[$key]['PMname']    =   $value->PMname;
            $datanew[$key]['PM']        =   $value->PM;
            if(!empty($value->deadline)){
                $deadData       =   (array)json_decode($value->deadline);
                $deadKey        =   array_keys($deadData);
                
                $downloadType   =   'regular';
                
                if($deadKey['0'] == 'S5' && $deadKey['1'] == 'S50' && $deadKey['2'] == 'S600'){
                    $downloadType = 'fasttrack';
                }
              
            }
            $datanew[$key]['downloadType']        =   $downloadType;
           
            if (is_numeric($value->AM)) 
            {
                $datanew[$key]['AM']    =   (string)($value->AM ==  0?'':$value->AM);
            }
            else
            {
                $datanew[$key]['AM']    =   '';
            }
            
            $datanew[$key]['AM_NAME']   =   $value->AM_NAME;
            $datanew[$key]['JOB_SHEET_UPDATE']  =   $value->JOB_SHEET_UPDATE;
            $datanew[$key]['UPDATE_REMARKS']    =   $value->UPDATE_REMARKS;
            $datanew[$key]['JOB_SHEET_UPLOAD']  =   $value->JOB_SHEET_UPLOAD;
            $datanew[$key]['UPLOAD_REMARKS']    =   $value->UPLOAD_REMARKS;
            $datanew[$key]['SUCCESS_REDO']      =   $value->SUCCESS_REDO;
            $datanew[$key]['SR_REMARKS']        =   $value->SR_REMARKS;
            $datanew[$key]['SHEET_FLAG']        =   $value->SHEET_FLAG;
        }
        
            
        } catch (Exception $ex) {
        return $e->getMessage();
        }
        $response["jobassigned"] 	= 	$datanew;
        $response['amUserList']  	= 	$getuserListByRole;
        return response()->json($response);
    }
	
    public function getJobXMLInfo( $jobId = 0 , $round , $cid) {
       
            $jobXMLInfo = downloadModel::getJobXMLInfo($jobId);
          
            $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
            
            if( empty( $getlocationftp ) )            
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            
            // Do the FTP connection
            
	    $ftpObj = \Storage::createFtpDriver([
		'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
		'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
		'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
		'port'     => '21',
		'timeout'  => '30',
            ]);  
                $chapterId         =    '';
                if($cid != ''){
                    $tasklevelMetaObj  = new taskLevelMetadataModel();
                    $metaDataDetails   =    $tasklevelMetaObj->getMetadatadetailsChapter($cid);
                    if(!empty($metaDataDetails)){
                        $chapterId      =   $metaDataDetails['0']->CHAPTER_NO;
                    }
                } 
                $round_arr      =   \Config::get('constants.ROUND_NAME');
                $round_name     =   $round_arr[$round];
		$xmlFilePath    =   '';
                $replace_bf     =   array( '' );
                $jobAssignedConst   =   \Config::get('constants.JOB_ASSIGNED_CONST');
                $stageName          =   \Config::get('constants.STAGE_NAME.COPY_EDITING');
                $book_id            =   $jobXMLInfo->BOOK_ID;
                $wheredata          =   ['ROUND_ID'=>$round];
               
                $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
                
                if(count($getjobsheetpath)>=1)
                {
                    $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 
                   
                    $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $book_id , 
                                            'ROUND_NAME' =>  $round_name,
                                            'STAGE_NAME' =>  $stageName,
                                            'CID'        =>  $chapterId
                                         );
                    
                   
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
                    //echo "<pre>";print_r($serverDir);
                    $serverDirFiles =   $ftpObj->allFiles($serverDir);
                   // echo "<pre>";print_r($serverDirFiles);exit;
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                            if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos($jobsheetpath,$book_id) !==   false) {
                                $xmlFilePath = $serverDirFile;
                            }
                        }
                    }
                }
		
		if($xmlFilePath == '') {
                     return '<p class="text-center"> Required jobsheet xml files is not available.</p>';
		}
                
                try{
                $filePath = '/' . $xmlFilePath;
               
            	$filecontent = $ftpObj->get($filePath); // read file content
               
		$xmlPath = base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
		$xslFilePath = base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
		
		// LOAD XML FILE CONTENT
		$XML = new \DOMDocument(); 
		$XML->loadXML($filecontent);

		// START XSLT 
		$xslt = new \XSLTProcessor(); 

		// IMPORT STYLESHEET
		$XSL = new \DOMDocument(); 
		$XSL->load( $xslFilePath ); 
		$xslt->importStylesheet( $XSL ); 

		echo $xslt->transformToXML( $XML );
                
                }catch( \Exception $e ){
                    
                    echo '<code> Invalid xml</code><br/>';  
                    echo $e->getMessage();
                }
                
		exit();

	}
    
    public function downloadPackageZip( Request $request ) {
        
        $needfield      =       array(     
                                    'job_id'    =>      'required|numeric',
                                    'round'     =>      'required|numeric',
                                    'metaid'    =>      'required|numeric',
                                    'type'      =>      'required|string'                   
                                );
        
        $validator      =       Validator::make( $request->all() , $needfield );
        
        $response['status']         =       0;
        $response['Msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try, Try again after sometimes.';
        
        if($validator->fails()){
            $response['errMsg']  = json_encode( $validator->errors() );
            return response()->json( $response );
        }
        
        $jobId              =       $request->input( 'job_id' );
        $round              =       $request->input( 'round' );
        $metaid             =       $request->input( 'metaid' );
        $type               =       $request->input( 'type' );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $getpackname        =       '';
        
        $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
            // Do the FTP connection
            $ftpObj             =       \Storage::createFtpDriver([
                                            'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
                                            'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
                                            'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
                                            'port'     => '21',
                                            'timeout'  => '30',
                                        ]);  

            if( isset( $metaid ) && !is_null( $metaid )){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $jbst_path      =       \Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                $tsklMeta       =       new taskLevelMetadataModel();
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                $metadata       =       $meta_info->toArray();
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =	explode('_' , $chapter_name );   
                
                if(count($chp_arr)>=2){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }                
                
            }
            
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $xmlFilePath    =       '';
            $replace_bf     =       array( '' );
            $book_id        =       $jobXMLInfo->BOOK_ID;
            
            $serverDir      =       \Config::get('constants.PACKAGE_PATH.FAILURE_PACKAGE_PATH'); 
            $packDestiDir   =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH'); 
            
            $inp_rep_arr    =   array( 
                                        'BOOK_ID'       =>      $book_id , 
                                        'ROUND_NAME'    =>      $round_name ,
                                        '{CID}'         =>      $chapter_name , 
                                        '{BID}'         =>      $book_id , 
                                        '{RID}'         =>      $round_name ,
                                        '{DID}'         =>      ''
                                );
           
            $getpackname_rec        =   DB::table('api_eproof_packaging')->select()
                                    ->where( 'METADATA_ID'  , '=' , $metaid )
                                    ->where( 'ROUND'  , '=' , $round )->orderBy( 'ID' , 'desc' )->get()->first();
            $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->PACKAGE_ID );
            
            if( $type == 'eproof' && $round == $round_arr['S300'] ){
                $inp_rep_arr['PACKAGING']   =   'EPROOF_PACKAGING';
            }
            
            //copy the failure pack files to user bin
            $cmn_obj            =       new CommonMethodsController();
            $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
            $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir ).'Package/';
            
            $open_path          =       $hostserver.$filedir.'/'.$serverDir;
            
            //copy the failure pack files to user bin    
            try{
                
                if($ftpObj->has($serverDir.$getpackname)){
                    
                    $ftpObj->deleteDirectory($serverDir.$getpackname);
                    
                }else{
                    
                }
                
                $crd                =      "ftp://$hostusername:$hostpassword@"; 
                $ftp_obj            =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $response_copy      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path , $serverDir.$getpackname );
                
                if( in_array( 'failed' , $response_copy ) ){
            
                foreach ($response_copy as $key => $value ){
                    if( $value == 'success' ){
                        unset( $response[$key] );
                    }
                }
            
                $response_copy   =       array( 'status' => 'failed'  , $response_copy );

            }else{
                $response_copy    =       array( 'status' => 'success' , $response_copy );
            }
            
            if( $response_copy['status'] == 'success' ){
            
                $postdata                   =       [];
                $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;
                
                $postdata['file_path']      =       $open_path.$getpackname.'/<>'.$domuser.'<>'.$domPass;
                $postdata['system_ip']      =       $request->ip();
                $postdata['method_name']    =       "doOpenDriveServer";
                $postdata['processname']    =       "checkout";
                $insertfilehandler          =       fileHandler::insertNew($postdata);   
                
                if( $insertfilehandler ){
                
                    $response['status']         =   1;
                    $response['Msg']            =   'Success';
                    $response['errMsg']         =   'File open initialized..';

                    $response['rmiId']          =   $insertfilehandler;
                
                }
           
            }
            
            }catch(\Exception $e){
                $response['errMsg'] =   'file download got failed, try once again';
                return response()->json( $response );
            }
            
          
            
            
            return response()->json( $response );
            
    }
        
        
    //redo view 
    public function getRedoview(Request $request){
        
        $jobRedoview 	= 	downloadModel::getRedoview($request->input('ID'));
        if(count($jobRedoview)>=1)
        {
                // Do the FTP connection
            
                $ftpObj 	= 	\Storage::createFtpDriver([
                        'host'     => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST'), 
                        'username' => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME'),
                        'password' => Crypt::decryptString(\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD')), // 
                        'port'     => '21',
                        'timeout'  => '30',
                  ]);

                $xmlFilePath 		= 	'';
                $jobAssignedConst 	= 	\Config::get('constants.JOB_ASSIGNED_CONST');
                
                $bookid 			=	$request->input('BOOK_ID');
                $serverDir 			= 	\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PATH') . $bookid . '/'.$jobAssignedConst;			
                $serverDirFiles 	=	 $ftpObj->allFiles($serverDir);
                if(!empty($serverDirFiles)) 
                {
                        $filePath 		= 	$serverDir.'/test.txt';
                        $filecontent 	= 	$ftpObj->get($filePath); // read file content
                        echo $filecontent;exit;
                }
                else
                {
                        echo '<p class="text-center">No Data found.</p>';
                        exit();
                }
        }

    }
        
    public function JobassignedtoAmUser(Request $request){
        if ($request->input('user_id') > 0) {
            
            $Req = (object) $request->input();
            $arrData    =   array();
            $arrData['user_id']         =   $request->input('user_id');
            $arrData['book_id']         =   $request->input('book_id');
            $bookDetails                =   downloadModel::getBookDetails($arrData['book_id']);
            $jobId                      =   '';
            if(!empty($bookDetails)){
                $arrData['BookTitle']   =  $bookDetails->JOB_TITLE;
                $jobId    =   $bookDetails->JOB_ID;
                $arrData['ISSN_PRINT']  =   $bookDetails->ISSN_ONLINE;
                $arrData['receivedDate']=   $bookDetails->CREATED_DATE;
                $arrData['AUTHOR_NAME'] =   $bookDetails->AUTHOR_NAME;
                $arrData['editorname']  =   $bookDetails->EDITOR_NAME;
                $arrData['PublisherName']   =   $bookDetails->PUBLISHER_NAME;
                $arrData['ContactPersonName']       =   $bookDetails->PE_NAME;
                $arrData['ProductionClassification']=   $bookDetails->PRODUCTION_CLASSIFICATION;
            }
            $userDetails                =   downloadModel::getUserDetails($arrData['user_id']);
            $arrData['AM_Mail']         =   $userDetails->EMAIL;
            $arrData['AM_name']         =   $userDetails->userName;
            $assignedJob                =   downloadModel::JobAssignedToAmUserMod($arrData,$jobId);
            
            if($assignedJob['0']    ==  'success' ){
                $this->newJobNotificationMail($arrData);
            }
            
            /*  
             *  $this->assignPEmail($arrData);
                $this->assignPMmail($arrData);
            */
            
            $response['msg'] = "Assigning process failed.";
            $response['errMsg'] = "Try again, after sometimes.";
            $response['status'] = 0;
            
            
            if($assignedJob['0'] == 'success'){                
                $message = "Successfuly Assigned to new Account Manager";
                $response['msg'] = $message;
                $response['errMsg'] = 'Successfully Assigned.';
                $response['status'] = 1;
                
            }
            
            return response()->json($response);
            
        }
        
    }
    
    public function getCucJobXMLInfo(Request $request) 
    {
        $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
        if(count($getlocationftp)>=1)
        {
            $roundid        =   $request->input('roundid');
            $stageid        =   $request->input('stageid');
            $roundname      =   $request->input('roundname');
            $stagename      =   $request->input('stagename');
            $metaid         =   $request->input('metadataid');
            $jobId          =   $request->input('jobId');
            $Chapter        =   $request->input('Chapter');
            $bookid         =   $request->input('bookid');
            
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            // Do the FTP connection
            $ftpObj         =   \Storage::createFtpDriver([
                                                'host'     => $hostserver, 
                                                'username' => $hostusername,
                                                'password' => $hostpassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
            $getuserid          =   Session::get('users')['emp_id'];
            $cucuserworkfolder  =   Config::get('constants.WATCH_CE_ESTIMATION_FOLDER');
            $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
            if(!empty($cucDirFiles)) 
            {
                 foreach($cucDirFiles as $serverDirFile) 
                 {
                    if(pathinfo($serverDirFile)['extension'] == 'xml') 
                    {
                        $xmlFilePath    =   $serverDirFile;
                    }
                }
                if($xmlFilePath == '') 
                {
                    $result         =   array('result'=>404,'errMsg'=>'<p class="text-center">No XML found.</p>','xmlcount'=>'0');   
                    return response()->json($result);
                }
                
                $filePath       =   '/' . $xmlFilePath;
                // $filecontent = self::xmlSampleContent();
                $filecontent    =   $ftpObj->get($filePath); // read file content
                $xmlPath        =   base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
                $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';

                // LOAD XML FILE CONTENT
                $XML = new \DOMDocument(); 
                $XML->loadXML($filecontent);

                // START XSLT 
                $xslt = new \XSLTProcessor(); 

                // IMPORT STYLESHEET
                $XSL = new \DOMDocument(); 
                $XSL->load( $xslFilePath ); 
                $xslt->importStylesheet( $XSL ); 
                
                $result         =   array('result'=>200,'errMsg'=>$xslt->transformToXML( $XML ),'xmlcount'=>strlen($xslt->transformToXML( $XML )));   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'Directory is empty','xmlcount'=>0);   
            return response()->json($result);
        }
        $result         =   array('result'=>404,'errMsg'=>'Location not found is empty','xmlcount'=>0);   
        return response()->json($result);
    }
    
    public function getCucXMLInfo(Request $request) 
    {
        try
        {
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $roundid        =   $request->input('roundid');
                $stageid        =   $request->input('stageid');
                $roundname      =   $request->input('roundname');
                $stagename      =   $request->input('stagename');
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');

                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $cucuserworkfolder  =   $hostpath.Config::get('constants.CUC_CHECKOUT_FOLDER').$bookid.'/'.$Chapter;
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }

                    if($xmlFilePath == '') 
                    {
                        $result         =   array('result'=>404,'errMsg'=>'<p class="text-center">No XML found.</p>','xmlcount'=>'0');   
                        return response()->json($result);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'cucview.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 

                    $result         =   array('result'=>200,'errMsg'=>$xslt->transformToXML( $XML ),'xmlcount'=>strlen($xslt->transformToXML( $XML )));   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=>'Directory is empty','xmlcount'=>0);   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'Location not found is empty','xmlcount'=>0);   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>404,'errMsg'=>'Ftp connection Failed');   
            return response()->json($result);
        }
    }
    
    public function newJobNotificationMail($amDetails){
        $mailArray = $mailData = array();
        $mailData['Title']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
        $mailData['HeadLine']       =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_HEAD_TITLE');
        $mailData['ToName']         =   $amDetails['AM_name'];
        $mailData['authorname']     =   $amDetails['AUTHOR_NAME'];
        $mailData['BookId']         =   $amDetails['book_id'];
        $mailData['BookTitle']      =   $amDetails['BookTitle'];
        $mailData['BookIsbn']       =   $amDetails['ISSN_PRINT'];
        $mailData['ReceivedDate']   =   $amDetails['receivedDate'];
        $mailData['editorname']     =   $amDetails['editorname'];
        $mailData['PublisherName']  =   $amDetails['PublisherName'];
        $mailData['ContactPersonName']       =   $amDetails['ContactPersonName'];
        $mailData['ProductionClassification']=   $amDetails['ProductionClassification'];
        $mailData['mailcontent']    =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ARRIVED_CONTENT');
        $mailArray['Data']          =   $mailData;
        $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_JOB_ASSIGN_TEMP');
       // $mailData['Title'] = 'New Quote Created';
      
        $mailArray['Subject']       =   'New Title Arrival Alert - '.$amDetails['book_id'];
        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']        =   $amDetails['AM_Mail'];
        $mailArray['CcMail']        =   Config::get('constants.CC_EMAIL_LIST');
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
         
    public function sendMailBladeTemplate($mailArray) {
        if (is_array($mailArray)) {
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }

                $message->getSwiftMessage();
            });

            if (Mail::failures()) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['MsgText'] = Mail::failures();
            } else {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }

            return $Response;
        }

    }
    
    public function sendMailNofity(  $purpose  ,  $template_name  , $info_arr ){
        
       switch( $purpose )
       {
           case 'productionLocationChange':
                //send to pm , related am alert mail notification for location change
                //re send job assigned notificaiton mail
           
               break;
           case 'newJobAssignment':
                
               break;
           
           default:
               break;
           
       }  
    }
    
    public function doSuccessredologview(Request $request) 
    {
        try{
            $validation     =   Validator::make($request->all(), [
                                                    'clientid'  => 'required|numeric',
                                                    'jobID' 	=> 'required|numeric',
                                                    'roundID' 	=> 'required|numeric',
                                                    'typeoflog' => 'required'
                                                ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                return response()->json($result);
            }
            $jobId              =   $request->input('jobID');
            $round              =   $request->input('roundID');
            $clientid           =   $request->input('clientid');
            $typeoflog          =   $request->input('typeoflog');
            
            $jobXMLInfo         =   downloadModel::getJobXMLInfo($jobId);
           
            $getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );
            $getlogfiles        =   [];
            
            if( empty( $getlocationftp ) )            
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            if(count($getlocationftp)>=1)
            {
                //need to dynamicaly bind the production location based on table location
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   ($getlocationftp->FTP_PATH);
                // Do the FTP connection

                $ftpObj             =   \Storage::createFtpDriver([
                        'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
                        'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
                        'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
                        'port'     => '21',
                        'timeout'  => '30',
                    ]);  

                $round_arr          =   \Config::get('constants.ROUND_NAME');
                $round_name         =   $round_arr[$round];
                $book_id            =   $jobXMLInfo->BOOK_ID;
                $getclickentackfile =   apiClientAcknowledgement::find($clientid);
                $serverDir          =   ($typeoflog     ==  "success"?Config::get('constants.COPY_CLIENT_ACK_FOLDER_SUCCESS'):Config::get('constants.COPY_CLIENT_ACK_FOLDER_FAILED'));
                $type_of_ack        =    $getclickentackfile->PROCESS_TYPE_DIFF;
                
                if(count($getclickentackfile)>=1){
                    
                    $acklogfile     =   $getclickentackfile->FILE_NAME;
                    if(strpos($acklogfile,'.') !== 	false){
                        $getlogfiles=   explode('.',$acklogfile);
                    }
                    
                    $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver; 
                    $roundname              =   Config::get('constants.ROUND_NAME')[$round];
                    $jobsheetlocationpath   =   $crd.$serverDir.$getlogfiles[0].'.log';
                    
                    if( $type_of_ack == 'PACKAGING' ){
                       $serverDir       =       \Config::get('constants.EPROOF_CLIENT_ACK_PRODUCTION_STORAGE_LOCATION');
                       $jobsheetlocationpath   =   $crd.$serverDir.$acklogfile;
                    }
                    
                    $inp_rep_arr            =   array( 
                                                'BOOK_ID' =>    $book_id , 
                                                'ROUND_NAME' =>    $roundname ,
                                                '{BID}' => $book_id , 
                                                '{RID}' => $roundname
                                             );
                    
                    $cmn_obj                =   new CommonMethodsController();
                    
                    $jobsheetlocationpath   =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobsheetlocationpath );
                    $logfiles       =   file_get_contents( $jobsheetlocationpath );
                    
                    $result         =   array('result'=>200,'status'=>1,'errMsg'=>nl2br($logfiles));   
                    return response()->json($result);
                }
                $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Production location not found for this job');   
                return response()->json($result);
            }
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Production location not found for this job');   
            return response()->json($result);
        }catch( \Exception $e ){
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Log file is not found');   
//            $result         =   array('result'=>401,'status'=>0,'errMsg'=>$e->getMessage());   
            return response()->json($result);
        }
    }
        
    //chapter download 
    public function chapterdownloadList( $round ) 
        {   
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $roundid            =   isset( $round ) ? $round  : Config::get('constants.ROUND_NAME.116');
        $roundname          =   $round_arr[$roundid];
        
        $data['pageTitle']  =   $roundname.' Download';
        $data['pageName']   =   $roundname.' Download';
       
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data['role_id']    =   Session::get('users')['role_id'];
       
        //dummy blade condition for eproof
        if( 'S300' ==  $roundname  ){
            return view('download.eproof.chapter-download2')->with( $data );	
        }
        
	return view('download.chapter-download')->with( $data );	
        
    }
    
    
    public function getChapterdownloadFailedList( $round = 116 ) 
    {	
        $data       =   downloadModel::getChapterdownoadlist( $round );           
        $response["downloadfailed"]     =   $data;
        return response()->json($response);   
        
    }
    
    public function doChapterlevelassignedlist( $round = 116 ){
        
        $user     =       Session::get('users');
        $arrData    			=   array();
        
        $data                    	=   downloadModel::getChapterlevelassigned( $round ); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =   projectModel::getUserListByTeam($user['team_id']);
        
        $response["jobassigned"] 	=   $data;
        $response['amUserList']  	=   $getuserListByRole;	
        $response['pmUserList']  	=   $getPmuserListByRole;
        
        return response()->json($response);
    }
    
    public function doChapterlevelassignedlisteproof( $round = 118 ){
        
        $user     =       Session::get('users');
        $arrData    			=   array();
        
        $data                    	=   downloadModel::getChapterlevelassignedForEproof( $round ); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =   projectModel::getUserListByTeam($user['team_id']);
        
        $response["jobassigned"] 	=   $data;
        $response['amUserList']  	=   $getuserListByRole;	
        $response['pmUserList']  	=   $getPmuserListByRole;
        
        return response()->json($response);
    }
    
    public function getChapterjobsheetview(Request $request) 
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric',
                                                'metadataid' 	=> 'required',
                                                'Chapter' 	=> 'required',
                                                'bookid' 	=> 'required',
                                                'roundid' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                return response()->json($result);
            }
            $jobId          =   $request->input('jobId');
            $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $chapterno      =   $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $roundid        =   $request->input('roundid');
                $roundname      =   Config::get('constants.ROUND_NAME')[$roundid];
                $hostserver     =   $getlocationftp['HOST'];
                $hostusername   =   $getlocationftp['FTP_USERNAME'];
                $hostpassword   =   $getlocationftp['FTP_PASSWORD'];
                $hostpath       =   $getlocationftp['HOST_PATH'];
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $wheredata          =   ['ROUND_ID'=>$roundid];
                $xmlFilePath        =   "";
                $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
                if(count($getjobsheetpath)>=1) 
                {
//                    if(strpos(strtoupper($Chapter),Config::get('constants.CHECK_PART')) !== false)
//                    {
//                        $chapterno  =   $Chapter;
//                    }else
//                    {
//                        $chapterno  =   (strpos($Chapter,'_') !== false?substr(strrchr($Chapter, "_"), 1):$Chapter);
//                    }
                    
                    $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 
                    switch($getjobsheetpath->ROUND_ID)
                    {
                        case 116:
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname,                        
                                            'STAGE_NAME' =>  Config::get('constants.STAGE_NAME.COPY_EDITING'),                        
                                            'CID' =>  $chapterno                       
                                         );
                        break;
                        case 118:
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname,                        
                                            'CID' =>  $chapterno                       
                                         );
                        break;
                        case (104 || 114):
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname                
                                         );
                        break;
                    }
                    
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
                    $serverDirFiles =   $ftpObj->allFiles($serverDir);
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                            if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos(strtolower($jobsheetpath),'jobsheet') !==   false) {
                                $xmlFilePath = $serverDirFile;
                            }
                        }
                    }
                    
                    if($xmlFilePath == '') 
                    {
                        $result         =   array('result'=>404,'errMsg'=>'<p class="text-center">No XML found.</p>','xmlcount'=>'0');   
                        return response()->json($result);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 

                    $result         =   array('result'=>200,'errMsg'=>$xslt->transformToXML( $XML ),'xmlcount'=>strlen($xslt->transformToXML( $XML )));   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=>'Job sheet path is not found','xmlcount'=>0);   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=> 'No files found in the Production Location...' ,'xmlcount'=>0);   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>404,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
    
    public function doOpenrawfile(Request $request)
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>1,'errMsg'=>$validation->errors());   
                return response()->json($result,404);
            }
            $jobId              =   $request->input('jobId');
            $bookdata           =   jobModel::where('JOB_ID',$jobId)->first();
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            if($bookid  ==  "")
            {
                $result         =   array('result'=>1,'errMsg'=>"No data found");   
                return response()->json($result,404);
            }
            $typeofseries       =   $bookdata->JOB_TYPE;
            $checktypeofseries  =   Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES');
            $rawpath            =   ($checktypeofseries   ==  $typeofseries?Config::get('serverconstants.S50_COPY_EDITING_PATH'):Config::get('serverconstants.RAW_PATH'));
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                switch($checktypeofseries)
                {
                    case 'S200 Of Series':
                    $inp_rep_arr    =   array( 
                                            '{BID}'     =>  $bookid , 
                                            '{CID}/'    =>  ''
                                         );
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$serverDir;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    //check directory is exist or not
                    $checkSourceexist   =   $hostpath.$serverDir;
                    break;
                    case ('Regular title' || 'Regular title'):
                    $sfifty             =   Config::get('constants.ROUND_OF_NAME.S5');
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$rawpath.$bookid.'/'.$sfifty;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    //check directory is exist or not
                    $checkSourceexist   =   $hostpath.$rawpath.$bookid.'/'.$sfifty;
                    break;
                }
                
                $checkfileDirexist  =   $ftpObj->allFiles($checkSourceexist);
                if(!empty($checkfileDirexist)) 
                {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    $result         =   array('result'=>200,'errMsg'=>'Searching folder Please wait','rmID'=>$insertfilehandler);   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=> 'Directory is empty...' );   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
    
    public static function jobcontactImportTemplateDownload( Request $request ) {
           
            if(Session::has('users')== ''){
                return redirect('/');
            }
            
            $jobID          =       '';
            $columnArr      =       array();
            
            Excel::create( 'contactTemplate_'.date('Ymd') , function($excel) use ($jobID) {

		$numberArray        =       array("Numeric", "Alphanumeric", "RomanLC", "RomanUC");
                //$indesignArray      =       projectModel::getInDesignVersion(array());
                $indesignArray      =       array();
                $touchedArray       =       array("Yes", "No");
                $excel->setTitle('ContactDetailsImport');
                $excel->setCreator('Ananth B - ')
                      ->setCompany('SPi Global');
                $excel->setDescription('Magnus - Workflow System');
                $numberCol      =       "AH"; 
                $indesignCol        =       "AI"; 
                $touchedCol         =       "AJ";
                $counter            =       1;
                $rowCnt             =       10;
                
                $excel->sheet('contactImport_'.date('Ymd'), function($sheet) use($counter,$rowCnt,$numberCol, $indesignCol, $touchedCol, $numberArray, $indesignArray, $touchedArray)  {
                
                $sheet->setWidth(   array(
                        			'A'     =>  25,
						'B'     =>  45,
						'C'     =>  25,
						
					)   );
                
                $sheet->setHeight(  array(    1     =>  25    )   );
                
                $sheet->cells('A1:C1', function($cells) {
                    $cells->setBackground('#6fb3e0');	
                    $cells->setFontSize(13);	
                    $cells->setFontWeight('bold');	
                    $cells->setBorder('solid', 'solid', 'solid', 'solid');
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                });
                
                $sheet->getColumnDimension($numberCol)->setVisible(false);
                $sheet->getColumnDimension($indesignCol)->setVisible(false);
                $sheet->getColumnDimension($touchedCol)->setVisible(false);
                
                for($r = 0; $r<count($numberArray); $r++) {
                    $sheet->setCellValue($numberCol.($r+1), $numberArray[$r]);
                }
                for($r = 0; $r<count($indesignArray); $r++) {
                    $sheet->setCellValue($indesignCol.($r+1), $indesignArray[$r]->version);
                }
                for($r = 0; $r<count($touchedArray); $r++) {
                    $sheet->setCellValue($touchedCol.($r+1), $touchedArray[$r]);
                }
                
                $data = array(
                            array(  'Name', 'Email' , 'Location' ),
                        );
                
		$sheet->fromArray($data, null, 'A1', false, false);				
                });
                                     
            })->export('xlsx');
                
	}
	/*intake items report download*/
    public static function checkitemsDownload(Request $request, $projectID = null) 
    {

            Excel::create('Intake Report_'.date('Ymd'), function($excel) use ($projectID) 
            {
                    $intakeitems 	= 	array(); 
                    $projecttitle 	= 	checkItemsModel::getProject($projectID);
                    $jobTitle 		=	(count($projecttitle)>=1?$projecttitle->JOB_TITLE:'');
                    $jobisbn 		=	(count($projecttitle)>=1?$projecttitle->ISSN_ONLINE:'');
                    $jobproduct 	=	'';
                    $intakeitems 	= 	checkItemsModel::getCheckItemsList($projectID);
                    $getparentsdata = 	checkItemsModel::getCheckItemsParent($projectID);
                    $projectcheckitems 			=	array();
                    if(!empty($getparentsdata)) 
                    {
                            foreach($getparentsdata as $key => $checkItemParent) 
                            {
                                    $projectcheckitems[$key] 	=	$checkItemParent;
                                    $getchild			= 	checkItemsModel::getCheckItemsChildren($checkItemParent['ID'],$projectID);
                                    if(count($getchild)>=1)
                                    {
                                            $data['parents'] 	=	$checkItemParent;
                                            foreach($getchild as $ckey=>$child)
                                            {
                                                    $projectcheckitems[$key]['checkItemsChildren'][] 	=	$child;
                                            }
                                    }
                                    else{
                                            $projectcheckitems[$key]['checkItemsChildren'] 	=	[];
                                    }
                            }
                    }
                    $excel->setTitle('Intake Reports_'.date('Y-m-d'));
                    $excel->setCreator('vinoth')->setCompany('SPi Global');
                    $excel->setDescription('Magnus Springer - Intake reports');

                    $excel->sheet($jobisbn, function($sheet) use ($projectcheckitems,$jobTitle,$jobisbn,$jobproduct,$projectID) 
                    {				
                            $data 	= 	array(
                                                                    array( 'Title: '.$jobTitle, 
                                                                                    'ISBN: '.$jobisbn,'','', 
                                                                                    'Production Category: '.$jobproduct
                                                                            )
                                                            );
                            $sheet->fromArray($data, null, 'A1', false, false);
                            $sheet->setWidth(array(
                                                    'A'     =>  75,
                                                    'B'     =>  5,
                                                    'C'     =>  5,
                                                    'D'     =>  30,
                                                    'E'     =>  40,
                                            ));
                            $sheet->setHeight(array(
                                                    1     =>  30,
                                            ));			
                            $sheet->cells("A1:A1", function($cells) {
                            $cells->setBorder('', 'thin', '', '');
                            });
                            $sheet->cells('A1:E1', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(12);	
                                    $cells->setFontWeight('bold');	
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });

                            $sheet->mergeCells('B1:D1');
                            //$sheet->setFreeze('A2');
                            $sheet->row('A2', array( '','', 
                                                                            '','', ''));
                            $sheet->row(3, array( 'Check Item', 
                                                                            'OK','','Problem', 
                                                                            'Quick Info to the Item'
                                                                    ));

                            $sheet->cells("A3:E3",function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thin', 'none', 'none', 'none');
                                    $row->setAlignment('left');
                                    $row->setValignment('top');
                                    $row->setBackground('#bfbcbc');
                            });
                            $sheet->cell("B3:B3", function($cells) {
                            $cells->setBorder('thin', 'solid', 'thin', 'thin');
                            });
                            $sheet->cell("C3:C3", function($cells) {
                            $cells->setBorder('thin', 'thin', 'thin', 'solid');
                            });
                            $sheet->row(4, array( '', 
                                                                            'Yes','No','', 
                                                                            ''
                                                                    ));
                            $sheet->cells("A4:E4",function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('solid', 'thin', 'thick', 'solid');
                                    $row->setAlignment('left');
                                    $row->setValignment('top');
                                    $row->setBackground('#bfbcbc');
                            });

            $t 		= 	5;
                            if(count($projectcheckitems)>=1)
                            {
                                    $c1 	=	1;
                                    foreach($projectcheckitems as $key=>$intakes)
                                    {
                                            if($intakes['TITLE'] !=	"Others")
                                            {
                                                    $sheet->getStyle('A'.$t)->getAlignment()->setWrapText(true);	
                                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                                    $sheet->cells("A".$t.":E".$t,function($row)
                                                    {
                                                            $row->setFontFamily('Arial');
                                                            $row->setFontSize(10);	
                                                            $row->setFontWeight('bold');	
                                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                            $row->setAlignment('left');
                                                            $row->setValignment('left');
                                                    });
                                                    $sheet->row($t, array( $c1.' '.$intakes['TITLE'], 
                                                                            '','','', 
                                                                            ''
                                                                    ));

                                                    if(count($intakes['checkItemsChildren'])>=1) 
                                                    {
                                                            $c2 	= 	1;	
                                                            foreach($intakes['checkItemsChildren'] as $checkItemsChildrenRec) 
                                                            {	
                                                                    ++$t;
                                                                    $sheet->getStyle('A'.$t)->getAlignment()->setWrapText(true);	
                                                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                                                            $sheet->cells("A".$t.":E".$t,function($row)
                                                                            {
                                                                                    $row->setFontFamily('Arial');
                                                                                    $row->setFontSize(10);	
                                                                                    $row->setFontWeight('none');	
                                                                                    $row->setBorder('solid', 'solid', 'dotted', 'solid');
                                                                                    $row->setAlignment('left');
                                                                                    $row->setValignment('left');
                                                                            });
                                                                            $okdata 	=	($checkItemsChildrenRec['OK_DATA'] == 1?'Yes':'');
                                                                            $nodata 	=	($checkItemsChildrenRec['OK_DATA'] == 0?'No':'');
                                                                            $sheet->row($t, array( $c1.'.'.$c2.' '.$checkItemsChildrenRec['TITLE'], 
                                                                                                    $okdata,$nodata,$checkItemsChildrenRec['PROBLEM_DATA'], 
                                                                                                    $checkItemsChildrenRec['QUICK_INFO_DATA']
                                                                                            ));
                                                                    ++$c2;
                                                            }

                                                            $sheet->cells('A'.$t.':E'.$t, function($row)
                                                            {
                                                                    $row->setFontFamily('Arial');
                                                                    $row->setFontSize(10);	
                                                                    $row->setFontWeight('none');	
                                                                    $row->setBorder('solid', 'solid', 'thick', 'solid');
                                                                    $row->setAlignment('left');
                                                                    $row->setValignment('left');
                                                            });
                                                    }
                                                    $t++;
                                                    ++$c1;
                                            }
                                    }
                                    if(!isset($_COOKIE['springer_'.$projectID])) 
                                    {
                                            $probleminfo 	=	"";
                                            $quickinfo 		=	"";
                                    } 
                                    else 
                                    {
                                            $getcookies 	=	json_decode($_COOKIE['springer_'.$projectID]);
                                            if(count($getcookies)>=1)
                                            {
                                                    if($getcookies->checkjob 	==	$projectID)
                                                    {
                                                            $probleminfo 	=	$getcookies->problemcheck;
                                                            $quickinfo 		=	$getcookies->quickinfocheck;
                                                    }
                                            }else{
                                                    $probleminfo 	=	"";
                                                    $quickinfo 		=	"";
                                            }
                                    }
                                    //OTHERS PROBLEM
                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                    $sheet->cells("A".$t.":A".$t,function($row)
                                    {
                                            $row->setFontFamily('Arial');
                                            $row->setFontSize(10);	
                                            $row->setFontWeight('bold');	
                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                            $row->setAlignment('left');
                                            $row->setValignment('left');
                                    });
                                    $sheet->cells("B".$t.":E".$t,function($row)
                                    {
                                            $row->setFontFamily('Arial');
                                            $row->setFontSize(10);	
                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                            $row->setAlignment('left');
                                            $row->setValignment('left');
                                    });
                                    $sheet->row($t, array( $c1.' '.'Other Problems', 
                                                                            '','',$probleminfo, 
                                                                            $quickinfo));
                                    //horizontal line
                                    $range 	= 	"A3:A".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"B4:B".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"C3:C".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"D3:D".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"E3:E".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                            }
                            $t 	= 	$t+1;	
                            $datenow 	=	date('d-M-Y');
                            $username 	=	Session::get('users')['user_name'];
                            $username 	=	(!empty($username)?$username:'');
                            $companyname 	=	"SPi Pondicherry";
                            $sheet->row($t, array( '','', 
                                                                            '','', ''));
                            $t 	=	$t+1;

                            $sheet->cells("A".$t.":A".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thick', 'thin', 'thin', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->cells("B".$t.":E".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thick', 'thin', '', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->mergeCells('B'.$t.':E'.$t);
                            $sheet->row($t, array( 'Date : '.$datenow, 
                                                                            '','','', 
                                                                            ''
                                                                    ));
                            $sheet->mergeCells('B'.$t.':E'.$t);
                            $t 		=	$t+1;
                            $sheet->cells("A".$t.":A".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thin', 'thin', 'thick', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->cells("B".$t.":E".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('', 'thin', 'thick', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->mergeCells('B'.$t.':E'.$t);

                            $sheet->row($t, array( 'Name : '.$username, 
                                                                            'Company Name / Location: '.$companyname,'No','', 
                                                                            ''
                                                                    ));
                            /*$sheet->setMergeColumn(array(
                                                    'columns' => ['B','C','D','E'],
                                                    'rows' => [
                                                            [$t-1,$t]
                                                    ]
                                            ));*/

                    });			

            })->download('xlsx');
    }

    /* PAR REPORTS download*/
    public static function parreportDownload(Request $request, $projectID = null) 
    {
            Excel::create('Par Report_'.date('Ymd'), function($excel) use ($projectID) 
            {
                    $parreportsitems        = 	array(); 
                    $checkpartavailable     =   taskLevelMetadataModel::getreportofconsolidate("","",Config::get('constants.CHECK_PART'),$projectID);
                    if(count($checkpartavailable)>=1)
                    {
                        $partresult     =   [];
                        $partincrement  =   0;
                        //get fm record 
                        $getfrontmatter =   taskLevelMetadataModel::getreportofconsolidate(Config::get('constants.FRONT_MATTER')[0],"","",$projectID);
                        if(count($getfrontmatter)>=1)
                        {
                            foreach($getfrontmatter     as     $frontdata)
                            {
                                $partresult[$partincrement]  =   $frontdata;
                                $partincrement++;
                            }
                        }
                        $partincrement  =   $partincrement;
                        //get part then chapter record 
                        foreach($checkpartavailable     as $partidvalue)
                        {
                            $partresult[$partincrement]     =   $partidvalue;
                            $chapterdataresult  =   taskLevelMetadataModel::getchapterlistagainpart($partidvalue->METADATA_ID,$projectID);
                            if(count($chapterdataresult)>=1)
                            {
                                foreach($chapterdataresult  as  $chapterdatavalue)
                                {
                                    ++$partincrement;
                                    $partresult[$partincrement]     =   $chapterdatavalue;
                                }
                                $partincrement      =   $partincrement+1;
                            }
                        }
                        //get bm then chapter record 
                        $getbackmatter      =   taskLevelMetadataModel::getreportofconsolidate("",Config::get('constants.BACK_MATTER')[0],"",$projectID);
                        if(count($getbackmatter)>=1)
                        {
                            $partincrement  =   $partincrement+1;
                            foreach($getbackmatter  as     $backdata)
                            {
                                $partresult[$partincrement]  =   $backdata;
                            }
                        }
                        $parreports         =   collect($partresult);
                    }
                    else
                    {
                        $parreports         = 	downloadModel::getParreportDownload($projectID);
                    }
                    $getjobinfo             =   jobModel::where('JOB_ID',$projectID)->first();
                    $bookid                 =   (count($getjobinfo)>=1?$getjobinfo->BOOK_ID:'');
                    $excel->setTitle('Par Reports_'.$bookid);
                    $excel->setCreator('vinoth')->setCompany('SPi Global');
                    $excel->setDescription('Magnus Springer - Par reports');

                    $excel->sheet('Par Reports_'.$bookid, function($sheet) use ($parreports,$projectID,$bookid) 
                    {	
                            $sheet->mergeCells('A1:F1');
                            $data 	= 	array(
                                                                    array('PAR Report - '.$bookid.''
                                                                    )
                                                            );
                            $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                            $sheet->fromArray($data, null, 'A1', false, false);
                            $sheet->setWidth(array(
                                                    'A'     =>  15,
                                                    'B'     =>  10,
                                                    'C'     =>  10,
                                                    'D'     =>  15,
                                                    'E'     =>  15,
                                                    'F' 	=>  15
                                            ));

                            $sheet->cells('A1:F1', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);	
                                    $cells->setFontWeight('bold');	
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#7bb193');
                            });

                            $sheet->mergeCells('C2:D2');
                            $sheet->mergeCells('E2:F2');
                            $sheet->cells('A2:A2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('B2:C2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('D2:D2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('E2:F2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->row(2, array( 'Chapter','','Table','','Equations'));
                            $sheet->cells('A3:F3', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#bada87');
                            });
                            $sheet->row(3, array( 'Chapter','Total (MS) Pages', 
                                                                            'Tables','Unnumbered Tables','Equations', 
                                                                            'No.of Equations'));
                            $t 		= 	4;
                            if(count($parreports)>=1)
                            {
                                    foreach($parreports as $key=>$parvalue)
                                    {
                                            $sheet->cells("A".$t.":F".$t,function($row)
                                            {
                                                    $row->setFontFamily('Arial');
                                                    $row->setFontSize(10);	
                                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                    $row->setAlignment('center');
                                                    $row->setValignment('center');
                                            });	
                                            $sheet->row($t, array(
                                                                                    $parvalue->CHAPTER_NO,
                                                                                    $parvalue->NO_MSP,
                                                                                    $parvalue->NO_TABLES,
                                                                                    $parvalue->NO_TABLES_UNNUMBERED,
                                                                                    $parvalue->NO_EQUATION,
                                                                                    $parvalue->NO_EQUATION_UNNUMBERED
                                                            ));

                                            $t++;
                                    }
                                    $t 		=	$t-1;
                                    $range 	= 	"F1:F".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('', 'thin', 'thin', '');
                                                            });
                                    $range 	= 	"A3:A".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"B3:B".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"C3:C".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"D3:D".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"E3:E".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"F3:F".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                            }					
                    });			

            })->download('xlsx');
    }     
}