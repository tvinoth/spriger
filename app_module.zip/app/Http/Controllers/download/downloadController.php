<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\download;
use App\Http\Controllers\Controller;
use App\Models\downloadModel;
use App\Models\checkItemsModel;
use App\Models\productionLocationModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiClientAcknowledgement;
use App\Models\jobsheetViewpathModel;
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\checkoutModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Models\projectModel;
use App\Models\apiDataset;
use App\Models\requiredConstants;
use App\Http\Controllers\dynamicConstantController;
use App\Models\workflowServerMapPathModel;
use App\Models\workflowMasterModel;
use App\Models\jobStage;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\custom\errorController;
use Session;
use Excel;   
use Storage;
use Validator;
use Config;
use DB; 
#use Request;
use Mail;
use Illuminate\Support\Facades\Crypt;

ini_set( 'max_execution_time' , 0 );
class downloadController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
	$this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
        
        $options            =   roundModel::Active()->whereNotIn('ID',[$this->round_ID_5,$this->round_ID_50])->get();
        $booksOpt           =   '<option value="">--Select Stage--</option>';
        if($options !=  ''){
            $booksOpt .= '<option data-roundid="'.$this->round_ID_5.'" value="'.$this->round_ID_5.'">'.$this->round_NAME_S5.'/'.$this->round_NAME_S50.'</option>';
            foreach ($options as $key => $value) {
                $booksOpt .= '<option data-bookid="'.$value['ID'].'" value="'.$value['ID'].'">';
                $booksOpt .= $value['NAME'];
                $booksOpt .= '</option>';
            }
        }
        
        $this->rounddownload   =   $booksOpt;
    }
       
    public function downloadListDemo() {
        
        $data   =   [];
        $this->displayMenuName(Config::get('menuconstants.MENU.DOWNLOAD_INDEX'),$data);
        $data['pageTitle']  =  ' - '.Config::get('constants.ROUND_NAME.104').'/'.Config::get('constants.ROUND_NAME.114').' Download';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
        $rolenames          =   ['Project Manager','Account Manager'];
        $data['assigneditemshow']   =   ((in_array($data['role_name'],$rolenames)  ==  true)?1:0);
        $data['optiondata']     =   $this->rounddownload;
        $data['optionenable']   =   true;
	return view('download.downloadDemo')->with($data);
        
    }
    
    public function downloadList( $roundid = null ) {
        
        $data   =   [];
        $this->displayMenuName(Config::get('menuconstants.MENU.DOWNLOAD_INDEX'),$data);
        $data['pageTitle']  =  ' - '.Config::get('constants.ROUND_NAME.104').'/'.Config::get('constants.ROUND_NAME.114').' Download';
        $data['roundname']         =   null;
         
        if( !is_null( $roundid ) ){
            $round_arr      =   \Config::get('constants.ROUND_NAME');
			if( !in_array( $roundid,$round_arr ) ){
				return redirect('download-index');
			}
            $data['pageTitle']  =  ' - '.$round_arr[$roundid].' Download';
            $data['roundname'] =  $round_arr[$roundid];
        }
        
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
        $rolenames          =   ['Project Manager','Account Manager'];
        $data['assigneditemshow']   =   ((in_array($data['role_name'],$rolenames)  ==  true)?1:0);
        $data['optiondata']     =   $this->rounddownload;
        $data['optionenable']   =   true;
        
        if(  $data['roundname'] == 'S600' )
            return view('download.s600.download')->with($data);
        
        if(  $data['roundname'] == 'S650' )
            return view('download.eproof.s650-book-download')->with($data);
        
	return view('download.download')->with($data);	
        
    }
    
    public function index( ){   
        $data   =   [];
        $this->displayMenuName(Config::get('menuconstants.MENU.DOWNLOAD_INDEX'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;        
        $data['optiondata']     =   $this->rounddownload;
        $data['optionenable']   =   true;
	return view('download.index')->with( $data );	
        
    }
    
    public function getDownloadFailedList( $roundid = null ) {
	
        $arrData    =   array();
        $wherein    =   [Config::get('constants.ROUND_ID.S5'),Config::get('constants.ROUND_ID.S50')];
        if( !is_null( $roundid ) ){
          $wherein    =   [$roundid];
        }
        $data       =   downloadModel::getDownloadFailedList($wherein);           
        $response["downloadfailed"] = $data;
        return response()->json($response);   
    }
    
    public function jobassigned( Request $request , $roundid = null ){
        
        try{
        
        $arrData    			=   array();
        
        if( !is_null( $roundid ) && $roundid == 119 ){
            $data                    	=       downloadModel::getJobAssignedS600(); 
        }else{
            $data                    	=       downloadModel::getJobassigned(); 
        }
       //echo "<pre>";print_r($data);exit;
        $getuserListByRole       	=   downloadModel::getUserListByRole('45'); 
        $datanew                        =   [];
        $downloadType                   =   "";
        
            foreach($data as $key=>$value){

                $datanew[$key]['JOB_ID']    =   $value->JOB_ID;
                $datanew[$key]['BOOK_ID']   =   $value->BOOK_ID;
                $datanew[$key]['ROUND_ID']  =   $value->ROUND_ID;
                $datanew[$key]['ROUND']     =   (isset( $value->ROUND ) ? $value->ROUND : $value->ROUND_ID);
                $datanew[$key]['ROUND_NAME']=   $value->ROUND_NAME;
                $datanew[$key]['ACTIVE']    =   $value->ACTIVE;
                $datanew[$key]['JOB_TITLE'] =   $value->JOB_TITLE;
                $datanew[$key]['AUTHOR_NAME']   =   $value->AUTHOR_NAME;
                $datanew[$key]['EDITOR_NAME']   =   $value->EDITOR_NAME;
                $datanew[$key]['LOCATION']      =   $value->LOCATION;
                $datanew[$key]['JOB_ASSIGNED_DATE']     =   $value->JOB_ASSIGNED_DATE;
                $datanew[$key]['receivedDate']  =   $value->receivedDate;
                $datanew[$key]['CLIACKID']      =   $value->CLIACKID;
                $datanew[$key]['ISSN_ONLINE']   =   (isset( $value->ISSN_ONLINE ) ? $value->ISSN_ONLINE : '--');
                $datanew[$key]['PMname']    =   $value->PMname;
                $datanew[$key]['PM']        =   $value->PM;

                if(!empty($value->deadline) ){
                    $deadData       =   (array)json_decode($value->deadline);
                    $deadKey        =   array_keys($deadData);
                    $downloadType   =   'regular';
                    if($deadKey['0'] == 'S5' && $deadKey['1'] == 'S50' && $deadKey['2'] == 'S600'){
                        $downloadType = 'fasttrack';
                    } 
                }
                
                
                $datanew[$key]['downloadType']        =   $downloadType;
                
                if (is_numeric($value->AM)){
                    $datanew[$key]['AM']    =   (string)($value->AM ==  0?'':$value->AM);
                }else{
                    $datanew[$key]['AM']    =   '';
                }

                $datanew[$key]['AM_NAME']           =   $value->AM_NAME;
                $datanew[$key]['JOB_SHEET_UPDATE']  =   $value->JOB_SHEET_UPDATE;
                $datanew[$key]['UPDATE_REMARKS']    =   $value->UPDATE_REMARKS;
                $datanew[$key]['JOB_SHEET_UPLOAD']  =   $value->JOB_SHEET_UPLOAD;
                $datanew[$key]['UPLOAD_REMARKS']    =   $value->UPLOAD_REMARKS;
                $datanew[$key]['SUCCESS_REDO']      =   $value->SUCCESS_REDO;
                $datanew[$key]['SR_REMARKS']        =   $value->SR_REMARKS;
                $datanew[$key]['SHEET_FLAG']        =   (isset( $value->SHEET_FLAG ) ? $value->SHEET_FLAG : '--');
                $datanew[$key]['APFT_SUCCESS_REDO'] =   (isset($value->APFT_SUCCESS_REDO)?$value->APFT_SUCCESS_REDO:"");
                $datanew[$key]['APFTID']            =   (isset($value->APFTID)?$value->APFTID:"");
                $datanew[$key]['APFT_REMARKS']      =   (isset($value->APFT_REMARKS)?$value->APFT_REMARKS:"");

            }
            
        } catch (Exception $ex) {
            return $e->getMessage();
        }
        
        $response["jobassigned"]                =   $datanew;
        $response['amUserList']                 =   $getuserListByRole;
        return response()->json($response);
    }
	
    public function lateCorrectionDownload( Request $request , $roundid = null ){
        
        try{
        
        $arrData    			=   array();
        $data                    	=   downloadModel::getLateCorrectionDownload( $roundid );
        $getuserListByRole       	=   downloadModel::getUserListByRole('45'); 
        $datanew                        =   [];
        $downloadType                   =   "";
        
            foreach($data as $key=>$value){

                $datanew[$key]['JOB_ID']    =   $value->JOB_ID;
                $datanew[$key]['BOOK_ID']   =   $value->BOOK_ID;
                $datanew[$key]['ROUND_ID']  =   $value->ROUND_ID;
                $datanew[$key]['ROUND']     =   isset( $value->ROUND ) ? $value->ROUND : $value->ROUND_ID;
                $datanew[$key]['ROUND_NAME']=   $value->ROUND_NAME;
                $datanew[$key]['ACTIVE']    =   $value->ACTIVE;
                $datanew[$key]['CD_STATUS']    =   $value->CD_STATUS;
                $datanew[$key]['JOB_TITLE'] =   $value->JOB_TITLE;
                $datanew[$key]['CHAPTER_NO'] =   $value->CHAPTER_NO;
                $datanew[$key]['METADATA_ID'] =   $value->METADATA_ID;
                $datanew[$key]['AUTHOR_NAME']   =   $value->AUTHOR_NAME;
                $datanew[$key]['EDITOR_NAME']   =   $value->EDITOR_NAME;
                $datanew[$key]['LOCATION']      =   $value->LOCATION;
                $datanew[$key]['JOB_ASSIGNED_DATE']     =   $value->JOB_ASSIGNED_DATE;
                $datanew[$key]['receivedDate']  =   $value->receivedDate;
                $datanew[$key]['CLIACKID']      =   $value->CLIACKID;
                $datanew[$key]['ISSN_ONLINE']   =   isset( $value->ISSN_ONLINE ) ? $value->ISSN_ONLINE : '--';
                $datanew[$key]['PMname']    =   $value->PMname;
                $datanew[$key]['PM']        =   $value->PM;

                if(!empty($value->deadline) ){
                    $deadData       =   (array)json_decode($value->deadline);
                    $deadKey        =   array_keys($deadData);
                    $downloadType   =   'regular';
                    if($deadKey['0'] == 'S5' && $deadKey['1'] == 'S50' && $deadKey['2'] == 'S600'){
                        $downloadType = 'fasttrack';
                    } 
                }
                
                
                $datanew[$key]['downloadType']        =   $downloadType;
                
                if (is_numeric($value->AM)){
                    $datanew[$key]['AM']    =   (string)($value->AM ==  0?'':$value->AM);
                }else{
                    $datanew[$key]['AM']    =   '';
                }

                $datanew[$key]['AM_NAME']           =   $value->AM_NAME;
                $datanew[$key]['JOB_SHEET_UPDATE']  =   $value->JOB_SHEET_UPDATE;
                $datanew[$key]['UPDATE_REMARKS']    =   $value->UPDATE_REMARKS;
                $datanew[$key]['JOB_SHEET_UPLOAD']  =   $value->JOB_SHEET_UPLOAD;
                $datanew[$key]['UPLOAD_REMARKS']    =   $value->UPLOAD_REMARKS;
                $datanew[$key]['SUCCESS_REDO']      =   $value->SUCCESS_REDO;
                $datanew[$key]['SR_REMARKS']        =   $value->SR_REMARKS;
                $datanew[$key]['SHEET_FLAG']        =   isset( $value->SHEET_FLAG ) ? $value->SHEET_FLAG : '--';
                $datanew[$key]['APFT_SUCCESS_REDO'] =   (isset($value->APFT_SUCCESS_REDO)?$value->APFT_SUCCESS_REDO:"");
                $datanew[$key]['APFTID']            =   (isset($value->APFTID)?$value->APFTID:"");
                $datanew[$key]['APFT_REMARKS']      =   (isset($value->APFT_REMARKS)?$value->APFT_REMARKS:"");

            }
            
        } catch (Exception $ex) {
            return $e->getMessage();
        }
        
        $response["jobassigned"]                =   $datanew;
        $response['amUserList']                 =   $getuserListByRole;
        return response()->json($response);
        
        
    }
    
    public function getJobXMLInfo( $jobId = 0 , $round , $cid = null) {
       
            $jobXMLInfo = downloadModel::getJobXMLInfo($jobId);
          
            $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
            if(empty($jobXMLInfo)){
                echo "No data found..!";
                exit;
            }
            if( empty( $getlocationftp ) )            
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            
            // Do the FTP connection
            
	    $ftpObj = \Storage::createFtpDriver([
		'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
		'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
		'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
		'port'     => '21',
		'timeout'  => '30',
            ]);  
                $chapterId         =    '';
                if($cid != '' && $cid !=null){
                    $tasklevelMetaObj  = new taskLevelMetadataModel();
                    $metaDataDetails   =    $tasklevelMetaObj->getMetadatadetailsChapter($cid);
                    if(!empty($metaDataDetails)){
                        $chapterId      =   $metaDataDetails['0']->CHAPTER_NO;
                    }
                } 
                $round_arr      =   \Config::get('constants.ROUND_NAME');
                $round_name     =   $round_arr[$round];
		$xmlFilePath    =   '';
                $replace_bf     =   array( '' );
                $jobAssignedConst   =   \Config::get('constants.JOB_ASSIGNED_CONST');
                $stageName          =   \Config::get('constants.STAGE_NAME.COPY_EDITING');
              //  echo $stageName;exit;
                $book_id            =   $jobXMLInfo->BOOK_ID;
                $wheredata          =   ['ROUND_ID'=>$round];
               
                $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
                
                if(count($getjobsheetpath)>=1)
                {
                    $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 
                   
                    $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $book_id , 
                                            'ROUND_NAME' =>  $round_name,
                                            'STAGE_NAME' =>  $stageName,
                                            'CID'        =>  $chapterId
                                         );
                    
                   
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
                   
                    $serverDirFiles =   $ftpObj->allFiles($serverDir);
                   
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                            if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos($jobsheetpath,$book_id) !==   false) {
                                $xmlFilePath = $serverDirFile;
                            }
                        }
                    }
                }
		
		if($xmlFilePath == '') {
                     return '<p class="text-center"> Required jobsheet xml files is not available.</p>';
		}
                
                try{
                $filePath = '/' . $xmlFilePath;
               
            	$filecontent = $ftpObj->get($filePath); // read file content
               
		$xmlPath = base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
		$xslFilePath = base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
		
		// LOAD XML FILE CONTENT
		$XML = new \DOMDocument(); 
		$XML->loadXML($filecontent);

		// START XSLT 
		$xslt = new \XSLTProcessor(); 

		// IMPORT STYLESHEET
		$XSL = new \DOMDocument(); 
		$XSL->load( $xslFilePath ); 
		$xslt->importStylesheet( $XSL ); 

		echo $xslt->transformToXML( $XML );
                
                }catch( \Exception $e ){
                    
                    echo '<code> Invalid xml</code><br/>';  
                    echo $e->getMessage();
                }
                
		exit();

    }
	
   public function packageFileTransferS650Eproof( Request $request ){

    $response           =	array('status' => 1 , 'msg' =>  'success' , 'errMsg' => 'File successfully copied' );

    $jobId              =       $request->input( 'JOB_ID' );
    $round              =       $request->input( 'ROUND_ID' );
    $metaid             =       null;
    $type               =       $request->input( 'type' );
    
    $round_arr          =       \Config::get('constants.ROUND_NAME');
    $getpackname        =       '';
    
    $chapDownFlag 		= 		false;
    $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
    $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
	$chapter_name		=		'';
	
    if( empty( $getlocationftp ) )            
        $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 

        // Do the FTP connection
        $ftpObj             =       \Storage::createFtpDriver([
                                        'host'     => $hostserver , 
                                        'username' => $hostusername , 
                                        'password' => $hostpassword , 
                                        'port'     => '21',
                                        'timeout'  => '30',
                                    ]);  

        if( isset( $metaid ) && !is_null( $metaid )){

            $api_tbl_input['METADATA_ID']  =   $metaid;
            $tsklMeta       =       new taskLevelMetadataModel();
            $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
            $metadata       =       $meta_info->toArray();
            $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
            $chp_arr        =	explode('_' , $chapter_name );   

            if(count($chp_arr)>=2){
                $chap_id        =       '_'.$chp_arr[1];
            }else{
                $chap_id        =       '_'.$chp_arr[0];
            }                

        }

        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $round_name     =       $round_arr[$round];
        $xmlFilePath    =       '';
        $response_copy	=       array();
        $replace_bf     =       array( '' );
        $book_id        =       $jobXMLInfo->BOOK_ID;
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
        extract( $paging_collect );
            
		$serverDir      =       \Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.FAILURE_PACKAGE_PATH'); 
		$packDestiDir       =       \Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.DESTINATION_PATH');
		$chapSrc	    =       \Config::get('constants.PACKAGE_PATH.XMLFILE'); 
		
        $getpackname_rec    =   DB::table('api_dataset')->select()
                                        ->where( 'JOB_ID'  , '=' , $jobId )
                                        ->where( 'ROUND'  , '=' , $round )
                                        ->where( 'STATUS'  , '>' , '1.5' )
                                        ->orderBy( 'ID' , 'desc' )->get()->first();
        
        if( count( $getpackname_rec ) ){
            $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->DATASET_ID );
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
        }else if( !count( $getpackname_rec ) && $type == 'eproof' ){

        }else{
            $response['errMsg']         =       'Requested Package information not available. try to start from the packaging process';                
        }

        if( $type == 'eproof' && $round == $round_arr['S650'] ){ 

            $inp_rep_arr['PACKAGING']   =   'EPROOF_PACKAGING';

            $getpackname_rec        =   DB::table('api_eproof_packaging')->select()
                                            ->where( 'JOB_ID'  , '=' , $jobId )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get()->first();

            $getpackname_count      =   DB::table('api_eproof_packaging')->select()
                                            ->where( 'JOB_ID'  , '=' , $jobId )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get();

            $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->PACKAGE_ID );
            $packDestiDir           =       str_replace( 'PACKAGING' , 'EPROOF' , $packDestiDir );
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY;

        }
        
        $empid                  =       Session::get('users')['emp_id'];

        $inp_rep_arr            =       $inp_rep_arr2            =       array( 
                                                'BOOK_ID'       =>      $book_id , 
                                                'ROUND_NAME'    =>      $round_name ,
                                                '{CID}'         =>      $chapter_name , 
                                                '{BID}'         =>      $book_id , 
                                                '{RID}'         =>      $round_name ,
                                                '{CNAME}'       =>      $chapter_name , 
                                                '{EMPID}'       =>      $empid , 
                                                '{TKEY}'        =>      $token_key_failed ,
                                                '{PAGING_FILENAMING}'   => $pagingfilnaming , 
                                                '{PACKAGEZIPNAME}'   =>  ''
                                        );

        //copy the failure pack files to user bin
        $cmn_obj            =       new CommonMethodsController();
        $inp_rep_arr2['{DID}']  =       str_replace(  '.zip' , '' , $getpackname  );
        $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr2 , $serverDir );
		$closefolder 		=	rtrim(str_replace($chapter_name,'',$serverDir),'/');
        $packagefolder_find			=	'Package';
		
        if( $type == 'eproof' && $round == $round_arr['S300'] ){

            $inp_rep_arr['{ DID}']   =   str_replace(  '.zip' , '' , $getpackname  );
            $packDestiDir       	=       \Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.DESTINATION_PATH');     
            $fromSrcPackge			=	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $packdesti_path     	=       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
            $packdesti_path2    	=       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Re_Package/" );
            $chapSrc            	=	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
            
            if( intval( $getpackname_rec->PACKAGE_RESUME_AT ) <= 1  ){ 
                
                $response['status']     =  1;
                $response['msg']        =  'Success';
                $response['errMsg']     =  'File transfer not required';
                
                //return $response;
                
            }
            
        }else{
            
            $inp_rep_arr['{DID}']   	=               '';
            $fromSrcPackge				=		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $packdesti_path             =               $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
            $packdesti_path2            =               $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Re_Package/" );
            $chapSrc                    =		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
            
            if( intval( $getpackname_rec->PACKAGE_RESUME_AT ) <= 1  ){
                
                $response['status']     =  1;
                $response['msg']        =  'Success';
                $response['errMsg']     =  'File transfer not required';
                
                //return $response;
                
            }

        }
        
        $get_folder_list    =       $ftpObj->directories($packdesti_path);
        $open_path          =       $hostserver.$filedir.'/'.$serverDir;
        $deletepath			=		$hostserver.$filedir.'/'.$serverDir."<>$hostusername<>$hostpassword";
		
        $getFilesCount      =       $ftpObj->allFiles( $serverDir ); 
        $getFolderCount     =       $ftpObj->allDirectories( $serverDir );
        
        if( count( $getFilesCount ) == 0 && count( $getFolderCount ) == 0){
            goto throwEmptyFolderError;
        }
                
        //copy the failure pack files to user bin    
        if( !$ftpObj->has( $packdesti_path ) ){

            $inputDownArr		=	array( 
                                                    'metaid' => $metaid	, 'round' => $round , 'type' => $type , 
                                                    'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path , 
                                                    'type' => $type , 'chapSrc' => $chapSrc , 'ftpObj'  => $ftpObj ,
                                                    'getlocationftp' => $getlocationftp
                                            );
            
            $chapDownSts 		=	$this->uploadChapterFileForPackageUser( $inputDownArr );

            if( $chapDownSts['status'] == 'success' ){
                $chapDownFlag = true;
                $response_copy['status'] = 'success'; 
            }

        }else if( count( $get_folder_list ) == 0 ){

            $inputDownArr		=	array( 
                                                    'metaid' => $metaid	, 'round' => $round , 'type' => $type , 
                                                    'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path , 
                                                    'type' => $type , 'chapSrc' => $chapSrc , 'ftpObj'  => $ftpObj ,
                                                    'getlocationftp' => $getlocationftp
                                                );
            
            
            $chapDownSts 		=	$this->uploadChapterFileForPackageUser( $inputDownArr );

            if( $chapDownSts['status'] == 'success' ){
                $chapDownFlag = true;
                $response_copy['status'] = 'success'; 
            }

        }else if($ftpObj->has($serverDir)){
            
        }

        if(($ftpObj->has( $packdesti_path ) || $ftpObj->has( $packdesti_path2 )) && !$chapDownFlag ){
           
            $dirpath_cut        =       explode( '/' , $packdesti_path );
            $uptochapter        =       $dirpath_cut[count( $dirpath_cut )-3];
            $dirpath_cut        =       array_slice($dirpath_cut, 0, -3);
            $literpath          =       implode('/', $dirpath_cut ); 
            $packbckfolder      =       'PACKAGE_BACKUP';
            
            $ftpObj->makeDirectory( $literpath."/$packbckfolder" );
            $preparedRename     =       $literpath."/$packbckfolder/".$uptochapter."_".date('Y_m_d_H_i_s');
            
            try{
                
                $ftpObj->move( $packdesti_path , $preparedRename ); 
            
            }catch( \Exception $e ){
                
                $response['status']  = 0;
                $response['msg']     = 'Failed';
                $response['errMsg']  = 'Access Denied : Another person accessing files or folder from production server';
                //.str_replace( 'ftp_delete()' , '' ,  $e->getMessage() );
                return $response;
                
            }
            
            
            $ftp_obj             =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
            $crd                 =      "ftp://$hostusername:$hostpassword@"; 
            $response_copy1      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$serverDir , $packdesti_path  );
			
        }
        
        if( false ){
            
            throwEmptyFolderError:
            $response['status']     =  0;
            $response['msg']        =  'Failed';
            $response['errMsg']     =  'Invalid try , Userwork folder is empty / root folder files are missing.';
            
        }
        
        if( $response['status'] == 1 ){
            try{
				$closefolder 	=	config::get('constants.FILE_SERVER_WITH_ROOT_DIR').$closefolder."/<>$hostusername<>$hostpassword";
				$this->closeFolderCall($closefolder);
                $deleteflag  = $ftpObj->deleteDirectory( $serverDir );
				
            }catch( \Exception $e ){
				
				$err_handle             =       new errorController();
				$err_handle->handleApplicationErrors( $e );
				
				$cmn_obj->deletefilesInproduction( $deletepath );
				
                $response['status']  = 1;
                $response['msg']     = 'Success';				
                $response['errMsg']  = 'Access Denied : Kindly close the folder or files from your desktop';
				
				
                return $response;
				
            }
            
        }
        
        return $response;

    }
    
    
    public function packageFileTransfer( Request $request ){

    $response           =	array('status' => 1 , 'msg' =>  'success' , 'errMsg' => 'File successfully copied' );

    $jobId              =       $request->input( 'JOB_ID' );
    $round              =       $request->input( 'ROUND_ID' );
    $metaid             =       $request->input( 'METADATA_ID' );
    $type               =       $request->input( 'type' );
    
    $round_arr          =       \Config::get('constants.ROUND_NAME');
    $getpackname        =       '';
    
    $chapDownFlag 		= 		false;
    $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
    $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );

    if( empty( $getlocationftp ) )            
        $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 

        // Do the FTP connection
        $ftpObj             =       \Storage::createFtpDriver([
                                        'host'     => $hostserver , 
                                        'username' => $hostusername , 
                                        'password' => $hostpassword , 
                                        'port'     => '21',
                                        'timeout'  => '30',
                                    ]);  

        if( isset( $metaid ) && !is_null( $metaid )){

            $api_tbl_input['METADATA_ID']  =   $metaid;
            $tsklMeta       =       new taskLevelMetadataModel();
			if($round  == '119' || $round == '120'){
					
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapterwithbook( $metaid );
					
            }else{
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                }
			
        
			
			
            $metadata       =       $meta_info->toArray();
            $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
            $chp_arr        =	explode('_' , $chapter_name );   

            if(count($chp_arr)>=2){
                $chap_id        =       '_'.$chp_arr[1];
            }else{
                $chap_id        =       '_'.$chp_arr[0];
            }                

        }

        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $round_name     =       $round_arr[$round];
        $xmlFilePath    =       '';
        $response_copy	=       array();
        $replace_bf     =       array( '' );
        $book_id        =       $jobXMLInfo->BOOK_ID;
        $pagObj             =       new autoPageController();
		$ccerror				=  '';
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
        extract( $paging_collect );

        $serverDir      =       \Config::get('constants.PACKAGE_PATH.FAILURE_PACKAGE_PATH'); 
        $packDestiDir   =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH'); 
        $chapSrc	=       \Config::get('constants.PACKAGE_PATH.XMLFILE'); 

        $getpackname_rec    =   DB::table('api_dataset')->select()
                                        ->where( 'METADATA_ID'  , '=' , $metaid )
                                        ->where( 'ROUND'  , '=' , $round )
                                        ->where( 'STATUS'  , '>' , '1.5' )
                                        ->orderBy( 'ID' , 'desc' )->get()->first();
										
		if(!empty($getpackname_rec->ERROR)){
			$ccerror				=       json_decode($getpackname_rec->ERROR);
		}
										
		

        /*$getpackname_count  =   DB::table('api_dataset')->select()
                                        ->where( 'METADATA_ID'  , '=' , $metaid )
                                        ->where( 'ROUND'  , '=' , $round )
                                        ->where( 'STATUS'  , '>' , '1.5' )
                                        ->orderBy( 'ID' , 'desc' )->get();*/
        
        if( count( $getpackname_rec ) ){
            $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->DATASET_ID );
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
        }else if( !count( $getpackname_rec ) && $type == 'eproof' ){

        }else{
            $response['errMsg']         =       'Requested Package information not available. try to start from the packaging process';                
        }

        if( $type == 'eproof' && $round == $round_arr['S300'] ){ 

            $inp_rep_arr['PACKAGING']   =   'EPROOF_PACKAGING';

            $getpackname_rec        =   DB::table('api_eproof_packaging')->select()
                                            ->where( 'METADATA_ID'  , '=' , $metaid )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get()->first();

            $getpackname_count      =   DB::table('api_eproof_packaging')->select()
                                            ->where( 'METADATA_ID'  , '=' , $metaid )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get();

            $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->PACKAGE_ID );
            $packDestiDir           =       str_replace( 'PACKAGING' , 'EPROOF_PACKAGING' , $packDestiDir );
            $token_key_failed       =       $getpackname_rec->TOKEN_KEY;

        }
        
        $empid                  =       Session::get('users')['emp_id'];

        $inp_rep_arr            =       $inp_rep_arr2            =       array( 
                                                'BOOK_ID'       =>      $book_id , 
                                                'ROUND_NAME'    =>      $round_name ,
                                                '{CID}'         =>      $chapter_name , 
                                                '{BID}'         =>      $book_id , 
                                                '{RID}'         =>      $round_name ,
                                                '{CNAME}'       =>      $chapter_name , 
                                                '{EMPID}'       =>      $empid , 
                                                '{TKEY}'        =>      $token_key_failed ,
                                                '{PAGING_FILENAMING}'   => $pagingfilnaming
                                        );

        //copy the failure pack files to user bin
        $cmn_obj            =       new CommonMethodsController();
        $inp_rep_arr2['{DID}']  =       str_replace(  '.zip' , '' , $getpackname  );
        $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr2 , $serverDir );
		$closefolder 		=	rtrim(str_replace($chapter_name,'',$serverDir),'/');
        $packagefolder_find			=	'Package';

        if( $type !== 'eproof' && $round == $round_arr['S300'] ){

            $inp_rep_arr['{ DID}']   =   str_replace(  '.zip' , '' , $getpackname  );
            $packDestiDir       =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH_S300');   
            $fromSrcPackge	=	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
            $packdesti_path2    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Re_Package/" );
            $chapSrc            =	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
            
            if( intval( $getpackname_rec->PACKAGE_RESUME_AT ) <= 1  ){ 
                
                $response['status']     =  1;
                $response['msg']        =  'Success';
                $response['errMsg']     =  'File transfer not required';
                
                return $response;
                
            }
            
        }else{
            
            $inp_rep_arr['{DID}']   	=               '';
            $fromSrcPackge		=		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $packdesti_path             =               $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
            $packdesti_path2            =               $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Re_Package/" );
            $chapSrc                    =		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
            
            if( intval( $getpackname_rec->PACKAGE_RESUME_AT ) <= 1  ){
                
                $response['status']     =  1;
                $response['msg']        =  'Success';
                $response['errMsg']     =  'File transfer not required';
                
                return $response;
                
            }

        }
        
        $get_folder_list    =       $ftpObj->directories($packdesti_path);
        $open_path          =       $hostserver.$filedir.'/'.$serverDir;
        $deletepath			=		$hostserver.$filedir.'/'.$serverDir."<>$hostusername<>$hostpassword";
		
        $getFilesCount      =       $ftpObj->allFiles( $serverDir ); 
        $getFolderCount     =       $ftpObj->allDirectories( $serverDir );
        
        if( count( $getFilesCount ) == 0 && count( $getFolderCount ) == 0){
            goto throwEmptyFolderError;
        }
                
        //copy the failure pack files to user bin    
        if( !$ftpObj->has( $packdesti_path ) ){

            $inputDownArr		=	array( 
                                                    'metaid' => $metaid	, 'round' => $round , 'type' => $type , 
                                                    'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path , 
                                                    'type' => $type , 'chapSrc' => $chapSrc , 'ftpObj'  => $ftpObj ,
                                                    'getlocationftp' => $getlocationftp,
													'error' => $ccerror
                                            );
											
			if( $round == '119' || $round == '120'){
				$chapDownSts 		=   $this->uploadBookChapterFileForPackageUser($inputDownArr,$getlocationftp);
			}else{
				$chapDownSts 		=	$this->uploadChapterFileForPackageUser( $inputDownArr );
			}

            if( $chapDownSts['status'] == 'success' ){
                $chapDownFlag = true;
                $response_copy['status'] = 'success'; 
            }

        }else if( count( $get_folder_list ) == 0 ){

            $inputDownArr		=	array( 
                                                    'metaid' => $metaid	, 'round' => $round , 'type' => $type , 
                                                    'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path , 
                                                    'type' => $type , 'chapSrc' => $chapSrc , 'ftpObj'  => $ftpObj ,
                                                    'getlocationftp' => $getlocationftp,
													'error' => $ccerror
                                                );
            
            
            if( $round == '119' || $round == '120'){
				$chapDownSts 		=   $this->uploadBookChapterFileForPackageUser($inputDownArr,$getlocationftp);
			}else{
				$chapDownSts 		=	$this->uploadChapterFileForPackageUser( $inputDownArr );
			}

            if( $chapDownSts['status'] == 'success' ){
                $chapDownFlag = true;
                $response_copy['status'] = 'success'; 
            }

        }else if($ftpObj->has($serverDir)){
            
        }

        if(($ftpObj->has( $packdesti_path ) || $ftpObj->has( $packdesti_path2 )) && !$chapDownFlag ){
           
            $dirpath_cut        =       explode( '/' , $packdesti_path );
            $uptochapter        =       $dirpath_cut[count( $dirpath_cut )-3];
            $dirpath_cut        =       array_slice($dirpath_cut, 0, -3);
            $literpath          =       implode('/', $dirpath_cut ); 
            $packbckfolder      =       'PACKAGE_BACKUP';
            
            $ftpObj->makeDirectory( $literpath."/$packbckfolder" );
            $preparedRename     =       $literpath."/$packbckfolder/".$uptochapter."_".date('Y_m_d_H_i_s');
            
            try{
                
                $ftpObj->move( $packdesti_path , $preparedRename ); 
            
            }catch( \Exception $e ){
                
                $response['status']  = 0;
                $response['msg']     = 'Failed';
                $response['errMsg']  = 'Access Denied : Another person accessing files or folder from production server';
                //.str_replace( 'ftp_delete()' , '' ,  $e->getMessage() );
                return $response;
                
            }
            
            
            $ftp_obj             =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
            $crd                 =      "ftp://$hostusername:$hostpassword@"; 
            $response_copy1      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$serverDir , $packdesti_path  );

        }
        
        if( false ){
            
            throwEmptyFolderError:
            $response['status']     =  0;
            $response['msg']        =  'Failed';
            $response['errMsg']     =  'Invalid try , Userwork folder is empty / root folder files are missing.';
            
        }
        
        if( $response['status'] == 1 ){
            try{
				$closefolder 	=	config::get('constants.FILE_SERVER_WITH_ROOT_DIR').$closefolder."/<>$hostusername<>$hostpassword";
				$this->closeFolderCall($closefolder);
                $deleteflag  = $ftpObj->deleteDirectory( $serverDir );
				
            }catch( \Exception $e ){
				
				$err_handle             =       new errorController();
				$err_handle->handleApplicationErrors( $e );
				
				$cmn_obj->deletefilesInproduction( $deletepath );
				
                $response['status']  = 1;
                $response['msg']     = 'Success';				
                $response['errMsg']  = 'Access Denied : Kindly close the folder or files from your desktop';
				
				
                return $response;
				
            }
            
        }
        
        return $response;

    }
	
	public function closeFolderCall($closefolder){
		$inpArray['method_name']	=  	"closeFolderServer";
		$inpArray['file_path']		=  	$closefolder;
		$inpArray['system_ip']   	=   fileHandlerController::get_ip_address();
		fileHandler::insertNew($inpArray);
	}
    
    public function downloadPackageZip( Request $request ) {
        
        $needfield      =       array(     
                                    'job_id'    =>      'required|numeric',
                                    'round'     =>      'required|numeric',
                                    'metaid'    =>      'required|numeric',
                                    'type'      =>      'required|string'                   
                                );
		
        $inp_rep_arr    =       array();
        
        $validator      =       Validator::make( $request->all() , $needfield );
        $response       =   $this->oopsErrorResponse;
        
        if( $validator->fails() ){
            
            $response['errMsg']  = json_encode( $validator->errors() );
            return response()->json( $response );
            
        }
        
        $jobId              =       $request->input( 'job_id' );
        $round              =       $request->input( 'round' );
        $metaid             =       $request->input( 'metaid' );
        $type               =       $request->input( 'type' );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $getpackname        =       '';
        $chapDownFlag       =       false;
        $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
            // Do the FTP connection
            $ftpObj             =       \Storage::createFtpDriver([
                                            'host'     => $hostserver , 
                                            'username' => $hostusername , 
                                            'password' => $hostpassword , 
                                            'port'     => '21',
                                            'timeout'  => '30',
											'passive'  => true,
                                        ]);  

            if( isset( $metaid ) && !is_null( $metaid )){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $tsklMeta       =       new taskLevelMetadataModel();
                if($round  == '119' || $round == '120'){
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapterwithbook( $metaid );
                }else{
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                }
                $metadata       =       $meta_info->toArray();
				
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =	explode('_' , $chapter_name );   
                
                if(count($chp_arr)>=2){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }                
                
            }
           
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $xmlFilePath    =       '';
            $response_copy	=		array();
			
            $replace_bf     =       array( '' );
            $book_id        =       $jobXMLInfo->BOOK_ID;
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
            extract( $paging_collect );
            
            $serverDir      =       \Config::get('constants.PACKAGE_PATH.FAILURE_PACKAGE_PATH'); 
            $packDestiDir   =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH'); 
            $chapSrc	    =       \Config::get('constants.PACKAGE_PATH.XMLFILE'); 
            
            $getpackname_rec        =   DB::table('api_dataset')->select()
                                            ->where( 'METADATA_ID'  , '=' , $metaid )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get()->first();
            
            $getpackname_count      =   DB::table('api_dataset')->select()
                                            ->where( 'METADATA_ID'  , '=' , $metaid )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get();
            
            if( count( $getpackname_rec ) ){
                $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->DATASET_ID );
                $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
            }else if( count( $getpackname_rec ) && $type == 'eproof' ){
              
            }else{
                $response['errMsg']         =       'Requested Package information not available. try to start from the packaging process';                
            }
            
            if( $type == 'eproof' && $round == $round_arr['S300'] ){ 
                
                $inp_rep_arr['PACKAGING']   =   'EPROOF_PACKAGING';
                
                $getpackname_rec        =   DB::table('api_eproof_packaging')->select()
                                                ->where( 'METADATA_ID'  , '=' , $metaid )
                                                ->where( 'ROUND'  , '=' , $round )
                                                ->where( 'STATUS'  , '>' , '1.5' )
                                                ->orderBy( 'ID' , 'desc' )->get()->first();
                
				$getpackname_count        =   DB::table('api_eproof_packaging')->select()
                                                ->where( 'METADATA_ID'  , '=' , $metaid )
                                                ->where( 'ROUND'  , '=' , $round )
                                                ->where( 'STATUS'  , '>' , '1.5' )
                                                ->orderBy( 'ID' , 'desc' )->get();
                
                $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->PACKAGE_ID );
                $packDestiDir			=		str_replace( 'PACKAGING' , 'EPROOF_PACKAGING' , $packDestiDir );
                $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
				
            }
			$ccerror 	=	"";
			if(!empty($getpackname_rec->ERROR)){
				$ccerror				=       json_decode($getpackname_rec->ERROR);
			}
            $empid                  =       Session::get('users')['emp_id'];
            
            $inp_rep_arr            =       $inp_rep_arr2            =       array( 
                                                    'BOOK_ID'       =>      $book_id , 
                                                    'ROUND_NAME'    =>      $round_name ,
                                                    '{CID}'         =>      $chapter_name , 
                                                    '{BID}'         =>      $book_id , 
                                                    '{RID}'         =>      $round_name ,
                                                    '{CNAME}'       =>      $chapter_name , 
                                                    '{EMPID}'       =>      $empid , 
                                                    '{TKEY}'        =>      $token_key_failed ,
                                                    '{PAGING_FILENAMING}'   => $pagingfilnaming
                                            );
           
            
            //copy the failure pack files to user bin
            $cmn_obj            =       new CommonMethodsController();
            $inp_rep_arr2['{DID}']  =       str_replace(  '.zip' , '' , $getpackname  );
            $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr2 , $serverDir );
            $packagefolder_find			=	'Package';
						
            if( $type !== 'eproof' && $round == $round_arr['S300'] ){
			   
                $inp_rep_arr['{ DID}']   =   str_replace(  '.zip' , '' , $getpackname  );
                $packDestiDir       =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH_S300');   
                $fromSrcPackge		=		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
                $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
                $packdesti_path2    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Package/" );
                $chapSrc            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
				
            }else{
				
                $inp_rep_arr['{DID}']   	=   	'';
                $fromSrcPackge      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
                $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
                $packdesti_path2    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Package/" );
                $chapSrc            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
				
            }
           
            $open_path              =       $hostserver.$filedir.'/'.$serverDir;
            $serverDir_rename_array		=		explode( '/'  , $serverDir );
            unset( $serverDir_rename_array[count($serverDir_rename_array)-1]); 
            $serverDir_rename_str		=		 implode( '/' , $serverDir_rename_array  );
            $response_copy['status']    =        'failed';
            $get_folder_list			=		$ftpObj->directories($packdesti_path);
         
            //copy the failure pack files to user bin    
            try{
			 
                if($ftpObj->has( $serverDir )){
                    
                    //already_open check
                    $serverDir2		=	$serverDir_rename_str.'_temp_'.date('Y_m_d_H_i_s');
                    $status_rename      =	@$ftpObj->move($serverDir, $serverDir2 );

                    if( $status_rename ){
                        
                        //deletion logic
                        //$status_rename 	=	$ftpObj->move($serverDir2 , $serverDir);
                        $return_del		=	$ftpObj->deleteDirectory($serverDir2);

                    }else if(!$status_rename){

                        $return_del		=	@$ftpObj->deleteDirectory($serverDir);

                    }else{

                        $response['status']         =   0;
                        $response['Msg']            =   'Failed';
                        $response['errMsg']         =   'Kindly Close the already opened files/folders and Try again !';	
                        return response()->json( $response );

                    }		
                   
                }
				
                if( !$ftpObj->has( $packdesti_path ) ){
				
                    $inputDownArr		=	array(  
                                                            'metaid'    => $metaid	, 'round' => $round , 'type' => $type , 
                                                            'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path ,
                                                            'type'      => $type , 'chapSrc'    => $chapSrc , 'ftpObj' => $ftpObj,'error' => $ccerror
                                                        );
                    
                    //@$ftpObj->makeDirectory( $serverDir );
					
					
					if( $round == '119' || $round == '120'){
						
						$chapDownSts 		=	$this->downloadBookChapterFileForPackageUser($inputDownArr,$getlocationftp);
					}else{
						$chapDownSts 		=	$this->downloadChapterFileForPackageUser( $inputDownArr );
					}
					
                    if( $chapDownSts['status'] == 'success' ){
                        $chapDownFlag            =   true;
                        $response_copy['status'] =  'success';
                    }

                }else if( count( $get_folder_list ) == 0 ){
					
                    $inputDownArr		=	array(  
                                                            'metaid'    => $metaid	, 'round' => $round , 'type' => $type , 
                                                            'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path ,
                                                            'type'      => $type , 'chapSrc'    => $chapSrc  , 'ftpObj' => $ftpObj,'error' => $ccerror
                                                        );
                    
                    //@$ftpObj->makeDirectory( $serverDir );
                    if( $round == '119' || $round == '120'){
						
						$chapDownSts 		=   $this->downloadBookChapterFileForPackageUser($inputDownArr,$getlocationftp);
					}else{
						$chapDownSts 		=	$this->downloadChapterFileForPackageUser( $inputDownArr );
					}
                    if( $chapDownSts['status'] == 'success' ){
                        $chapDownFlag            =   true;
                        $response_copy['status'] =  'success';
                    }

                } 
				
                if(( $ftpObj->has( $packdesti_path ) || $ftpObj->has( $packdesti_path2 ) ) && !$chapDownFlag ){

                    $ftpObj->makeDirectory( $serverDir );
					
                    $crd                 =      "ftp://$hostusername:$hostpassword@"; 
                    $ftp_obj             =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response_copy1      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path , $serverDir );
                    $response_copy2      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path2 , $serverDir );

                    if( in_array( 'success' , $response_copy1 ) || in_array( 'success' , $response_copy2 ) ){

                        foreach ($response_copy1 as $key => $value ){
                            if( $value == 'Success' ){
                                $response_copy    =       array( 'status' => 'success' , $response_copy1 );
                            }
                        }

                        foreach ($response_copy2 as $key => $value ){
                            if( $value == 'Success' ){
                                $response_copy    =       array( 'status' => 'success' , $response_copy2  );
                            }
                        }

                    }else{

                        $response_copy    =       array( 'status' => 'success' , $response_copy2 , $response_copy1 );

                    }

                }else if( $chapDownFlag ){	
                    
                }else{
                    $response['status']         =   0;
                    $response['Msg']            =   'Failed';
                    $response['errMsg']         =   'Source folder not exist to download';					
                }
			
            if( $response_copy['status'] == 'success' ){
            
                $postdata       =       [];
                $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;
                
                $postdata['file_path']      =       $open_path.'/<>'.$domuser.'<>'.$domPass;
                $postdata['system_ip']      =       $request->ip();
                $postdata['method_name']    =       "doOpenDriveServer";
                $postdata['processname']    =       "checkout";
                $insertfilehandler          =       fileHandler::insertNew($postdata);   
                
                if( $insertfilehandler ){
                    $response       =   $this->successResponse;
                    $response['rmiId']          =   $insertfilehandler;
                }
           
            }else{
                
                //$response    =   $response_copy[0];
                //  Trying to download it from source paths [taps final output consider as input ]
                //return false;
				
                $jobStg =   new jobStage();
                $getRecords     =       $jobStg->getCurrentJobStageInfo( $metaid , $round , 23 );
                
                if( count( $getRecords ) ){
                    
                    $rec_obj        =       $getRecords[0];
                    $jobStageId    =   $rec_obj->JOB_STAGE_ID;
                            
                    $workflowPath                       =   new workflowServerMapPathModel();
                    $serverMapPath                      =   $workflowPath->getWorkflowServerMapPath( $jobStageId );
                  
                    if( $serverMapPath['status'] ){
                        $serverMapPath['detail']['work']    =   $hostserver.'/'.$serverDir.'/';
						
						                      
                        $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath);
                        
                        $postdata       =       [];
                        $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                        $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;

                        $postdata['file_path']      =       $open_path.'/<>'.$domuser.'<>'.$domPass;
                        $postdata['system_ip']      =       $request->ip();
                        $postdata['method_name']    =       "doOpenDriveServer";
                        $postdata['processname']    =       "checkout";
                        $insertfilehandler          =       fileHandler::insertNew($postdata);   

                        if( $insertfilehandler ){
                            $response       =   $this->successResponse;
                            $response['rmiId']          =   $insertfilehandler;
                        }   
                    }   
                }
            }
           
        }catch(\Exception $e){
			
            $response           =   $this->oopsErrorResponse;
			$error				=	$e->getTraceAsString();
            $response['reason'] =   $packdesti_path.$error;
			
            if( strpos( $error , 'Access is denied' ) ){
                    $response['errMsg']		=	'Kindly Close the already opened files/folders and Try again ';
            }
			
            return response()->json( $response );
            
        }
	
        return response()->json( $response );
        
    }
	    public function downloadChapterFileForPackageUser( $inputarr ){

            extract( $inputarr );

            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $fileStatus['status']   =   'failed';
            
            if( $type == 'package'){

                $jbstgObj                   =           new jobStage();
                $getCurrnt_stage            =           $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 23  );						
                
                if( count( $getCurrnt_stage ) ){

                    $checkoutObj            =       new checkoutModel();
                    $stageDetails           =       $checkoutObj->getStageInfo( $getCurrnt_stage[0]->JOB_STAGE_ID );
                    $stageData              =       $stageDetails[0];
                    $jobRoundId             =       $stageData->JOB_ROUND_ID;
                    $roundId                =       $stageData->ROUND_ID;
                    $workflowId             =       $stageData->WORKFLOW_ID;  
                    $jobStageId             =       $stageData->JOB_STAGE_ID;
                    $workflowPath           =       new workflowServerMapPathModel();
                    $serverMapPath          =       $workflowPath->getWorkflowServerMapPath( $jobStageId );
					
                    $serverMapPath['detail']['work'] 	=	$serverDir;
		    $pathcheck			=       explode( '/' , $serverMapPath['detail']['src'] );
		    unset( $pathcheck[0] );
		    $pathstr			=	implode( '/' , $pathcheck );
		    $findPathstatus		=	$ftpObj->has( $pathstr );
					
		    $fileStatus['status']	=	0;
		    $fileStatus['msg']		=	'failed';
		    $fileStatus['errorMsg']	=	'Invalid workflow path setup not done.';
					
                    if( $findPathstatus ){
                        $fileStatus             =   	checkOutController::fileMoveMent( $serverMapPath ,$jobStageId , 0 );
                    }else{

                    }
					
                    $fileStatus['downpath']     =       $serverMapPath['detail']['work']; 	
					
                    return $fileStatus;

                }

            }

            if( $type == 'eproof' ){
                
                $arrayExp           =   explode( '/' , $chapSrc );
                $chapterfilename    =   $arrayExp[count($arrayExp)-1];
				$userbindel			=	$serverDir;
                $serverDir  		=   $serverDir.$chapterfilename;
				
				$resultResp =    $ftpObj->copy( $chapSrc , $serverDir  );
				
                if( $resultResp )
                    $fileStatus['status']   =   'success';
                return $fileStatus;
                
            }
            
            return $fileStatus;
            
    }
	
    
    public function downloadBookChapterFileForPackageUser( $inputarr, $getlocationftp ){

		
            extract( $inputarr );
 
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $fileStatus['status']   =   'failed';
            
            if( $type == 'package'){

                $jbstgObj                   =           new jobStage();
                $getCurrnt_stage            =           $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 23  );						
                
                if( count( $getCurrnt_stage ) ){

                    $checkoutObj            =       new checkoutModel();
                    $stageDetails           =       $checkoutObj->getStageInfo( $getCurrnt_stage[0]->JOB_STAGE_ID );
                    $stageData              =       $stageDetails[0];
                    $jobRoundId             =       $stageData->JOB_ROUND_ID;
                    $roundId                =       $stageData->ROUND_ID;
                    $workflowId             =       $stageData->WORKFLOW_ID;  
                    $jobStageId             =       $stageData->JOB_STAGE_ID;
                    $workflowPath           =       new workflowServerMapPathModel();
                    $serverMapPath          =       $workflowPath->getWorkflowServerMapPath( $jobStageId );
				
                    $serverMapPath['detail']['work'] 	=	$serverDir;
					
					
					foreach($inputarr['error']  as $key => $data){
						
						$errfilePath	=  $data->Filepath;
						$errfilePath = str_ireplace ('\\\\','',$errfilePath);
						$errfilePath = str_ireplace ('\\','/',$errfilePath);
						$errfilePath = $getlocationftp->FTP_HOST.$getlocationftp->FTP_PATH.str_ireplace ($getlocationftp->FTP_HOST.$getlocationftp->FILE_SERVER_PATH,'',$errfilePath);
						
						$hostserver         =       $getlocationftp->FTP_HOST;
						$hostusername       =       $getlocationftp->FTP_USER_NAME;
						$hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
					    $crd                =      "ftp://$hostusername:$hostpassword@"; 
						
						$destpath			=	$crd.$getlocationftp->FTP_HOST.'/'.$serverDir.$data->Filename.'.xml';
						$ftp_obj             =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
						
						$fileMoveStatus     =   $ftp_obj->ftpSingleFileCopyOrMove($crd.$errfilePath,$destpath);
						
					}
					
				
					//$fileMoveStatus     =   $ftpObj->ftp_dir_copy($crd.$src,$serverDir);
					
				$fileStatus['status']   =   'success';		
					
				return $fileStatus;	
					
					
			
                }

            }

            
            
            return $fileStatus;
            
    }
	
	
	

    public function uploadChapterFileForPackageUser( $inputarr ){

        extract( $inputarr );
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $round_name     =       $round_arr[$round];

        if( $type == 'package'){

            $jbstgObj		=			new jobStage();
            $getCurrnt_stage        =			$jbstgObj->getCurrentJobStageInfo( $metaid , $round , 23  );						

            if( count( $getCurrnt_stage ) ){

                $checkoutObj            =       new checkoutModel();
                $stageDetails           =       $checkoutObj->getStageInfo( $getCurrnt_stage[0]->JOB_STAGE_ID );

                $stageData              =       $stageDetails[0];

                $jobRoundId             =       $stageData->JOB_ROUND_ID;
                $roundId                =       $stageData->ROUND_ID;
                $workflowId             =       $stageData->WORKFLOW_ID;  
                $jobStageId             =       $stageData->JOB_STAGE_ID;
                $workflowPath           =   	new workflowServerMapPathModel();
                $serverMapPath          =   	$workflowPath->getWorkflowServerMapPath( $jobStageId );
                
                //upload swap logic apply
                $serverMapPath['detail']['work'] 	=	$serverMapPath['detail']['src'];
                $serverMapPath['detail']['src'] 	=	$getlocationftp->FTP_HOST.'/'.$serverDir;

                $fileStatus             =   checkOutController::fileMoveMent( $serverMapPath ,$jobStageId , 0 );
                $fileStatus['downpath']	=	$serverMapPath['detail']['work']; 	
				
                return $fileStatus;

            }

        }

        if( $type == 'eproof' ){
            
            $arrayExp           =   explode( '/' , $chapSrc );
            $chapterfilename    =   $arrayExp[count($arrayExp)-1];
            $chapterfilename_ar	=	explode( '.' , $chapterfilename );
            unset( $arrayExp[count($arrayExp)-1]);
            $newfilename = implode( '/' , $arrayExp );
            $userbindel	=	$serverDir;
            $serverDir      =       $serverDir.$chapterfilename;
            $serverDir2	=	$serverDir;
            $newfilename	=	 $newfilename.'/'.$chapterfilename_ar[0].'_bckup_'.date('Y-m-d H_i_s').'.xml';

            if( $ftpObj->has( $serverDir ) ){
                    $ftpObj->move( $chapSrc , $newfilename ); 
                    sleep(2);
                    $resultResp 	=    @$ftpObj->copy( $serverDir , $chapSrc );
                    if( $resultResp ){
                        $ftpObj->deleteDirectory( $userbindel );
                    }
            } 
			
            $fileStatus['status']   =   'success';
            return $fileStatus;
            
        }
        
        
    }
	
	public function uploadBookChapterFileForPackageUser( $inputarr, $getlocationftp){

       extract( $inputarr );
 
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $fileStatus['status']   =   'failed';
            
            if( $type == 'package'){

                $jbstgObj                   =           new jobStage();
                $getCurrnt_stage            =           $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 23  );						
                
                if( count( $getCurrnt_stage ) ){

                    $checkoutObj            =       new checkoutModel();
                    $stageDetails           =       $checkoutObj->getStageInfo( $getCurrnt_stage[0]->JOB_STAGE_ID );
                    $stageData              =       $stageDetails[0];
                    $jobRoundId             =       $stageData->JOB_ROUND_ID;
                    $roundId                =       $stageData->ROUND_ID;
                    $workflowId             =       $stageData->WORKFLOW_ID;  
                    $jobStageId             =       $stageData->JOB_STAGE_ID;
                    $workflowPath           =       new workflowServerMapPathModel();
                    $serverMapPath          =       $workflowPath->getWorkflowServerMapPath( $jobStageId );
				
                    $serverMapPath['detail']['work'] 	=	$serverDir;
				
					
					foreach($inputarr['error']  as $key => $data){
						
						$errfilePath	=  $data->Filepath;
						$errfilePath = str_ireplace ('\\\\','',$errfilePath);
						$errfilePath = str_ireplace ('\\','/',$errfilePath);
						$errfilePath = $getlocationftp->FTP_HOST.$getlocationftp->FTP_PATH.str_ireplace ($getlocationftp->FTP_HOST.$getlocationftp->FILE_SERVER_PATH,'',$errfilePath);
						
						$hostserver         =       $getlocationftp->FTP_HOST;
						$hostusername       =       $getlocationftp->FTP_USER_NAME;
						$hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
					    $crd                =      "ftp://$hostusername:$hostpassword@"; 
						
						$destpath			=		$crd.$getlocationftp->FTP_HOST.'/'.$serverDir.$data->Filename.'.xml';
						$ftp_obj            =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
						
						$fileMoveStatus     =   $ftp_obj->ftpSingleFileCopyOrMove($destpath,$crd.$errfilePath);
						
						if($fileMoveStatus == false || $fileMoveStatus == 0){
							
							return $fileStatus;		
						}
					}
					
				
					//$fileMoveStatus     =   $ftpObj->ftp_dir_copy($crd.$src,$serverDir);
					
				$fileStatus['status']   =   'success';		
					
				return $fileStatus;	
					
					
			
                }

            }

            
            
            return $fileStatus;
        
        
    }

    public function downloadClientAckFailureRetryFiles( Request $request ) {
        
        $needfield      =       array(     
                                    'job_id'    =>      'required|numeric',
                                    'round'     =>      'required|numeric',
                                    'metaid'    =>      'required|numeric'                   
                                );
        
        $validator      =       Validator::make( $request->all() , $needfield );
        $response   =   $this->oopsErrorResponse;
        
        if($validator->fails()){
            $response['errMsg']  = json_encode( $validator->errors() );
            return response()->json( $response );
        }
        
        $jobId              =       $request->input( 'job_id' );
        $round              =       $request->input( 'round' );
        $metaid             =       $request->input( 'metaid' );
        $type               =       $request->input( 'type' );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $getpackname        =       '';
        
        $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
            // Do the FTP connection
            $ftpObj             =       \Storage::createFtpDriver([
                                            'host'     => $hostserver , 
                                            'username' => $hostusername , 
                                            'password' => $hostpassword , 
                                            'port'     => '21',
                                            'timeout'  => '30',
                                        ]);  
   
            if( isset( $metaid ) && !is_null( $metaid )){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $tsklMeta       =       new taskLevelMetadataModel();
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                $metadata       =       $meta_info->toArray();
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =	explode('_' , $chapter_name );   
                
                if( count( $chp_arr ) >= 2 ){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }                
                
            }
                   
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $xmlFilePath    =       '';
            $replace_bf     =       array( '' );
            $book_id        =       $jobXMLInfo->BOOK_ID;
            
            //$serverDir      =       \Config::get('constants.CLIENT_ACK_DOWNLOADPATH'); 
            //$packDestiDir   =       \Config::get('constants.CLIENT_ACK_USERWORK'); 
            $serverDir      =       \Config::get('dynamicConstant.CLIENT_ACK_DOWNLOADPATH'); 
            $packDestiDir   =       \Config::get('dynamicConstant.CLIENT_ACK_USERWORK'); 
            
            $empid                  =       Session::get('users')['emp_id'];
            
            $inp_rep_arr            =       array( 
                                                    'BOOK_ID'       =>      $book_id , 
                                                    'ROUND_NAME'    =>      $round_name ,
                                                    '{CID}'         =>      $chapter_name , 
                                                    '{BID}'         =>      $book_id , 
                                                    '{RID}'         =>      $round_name ,
                                                    '{CNAME}'       =>      $chapter_name , 
                                                    '{EMPID}'       =>      $empid
                                            );
           
            //copy the failure pack files to user bin
            $cmn_obj            =       new CommonMethodsController();
            $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
            $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $open_path          =       $hostserver.$filedir.'/'.$packdesti_path;
            
            //copy the failure pack files to user bin    
            try{
                
                $crd                =      "ftp://$hostusername:$hostpassword@"; 
                $ftp_obj            =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $response_copy      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$serverDir , $packdesti_path );
                
                if( in_array( 'failed' , $response_copy ) ){
            
                    foreach ($response_copy as $key => $value ){
                        if( $value == 'success' ){
                            unset( $response[$key] );
                        }
                    }

                    $response_copy   =       array( 'status' => 'failed'  , $response_copy );

                }else{
                    $response_copy    =       array( 'status' => 'success' , $response_copy );
                }
            
                if( $response_copy['status'] == 'success' ){    

                    $postdata                   =       [];
                    $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                    $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;

                    $postdata['file_path']      =       $open_path.'/<>'.$domuser.'<>'.$domPass;
                    $postdata['system_ip']      =       $request->ip();
                    $postdata['method_name']    =       "doOpenDriveServer";
                    $postdata['processname']    =       "checkout";
                    $insertfilehandler          =       fileHandler::insertNew($postdata);   

                    if( $insertfilehandler ){
                        $response   =   $this->successResponse;
                        $response['rmiId']          =   $insertfilehandler;
                    }
           
                }else{
                    $response    =   $response_copy[0] ;
                }
            
            }catch(\Exception $e){
                
                $response['errMsg'] =   'file download got failed, try once again';
                $response['reason'] =   $e->getMessage();
                return response()->json( $response );
            }
            
            return response()->json( $response );
            
    }
        
    public function backupAndUpdatedFileMoveForRetry( $input_arr = array() ){
        
        $response   =   $this->oopsErrorResponse;
        
        $jobId              =       isset( $input_arr['jobid'] ) ? $input_arr['jobid'] : null;
        $round              =       $input_arr['round'];
        $metaid             =       $input_arr['metaid'];
        $type               =       $input_arr['processtype'];
        
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $getpackname        =       '';
        
        $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        $locationflag       =       1;
        if( empty( $getlocationftp ) )   {         
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            $locationflag       =       0;
        }
            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            if($locationflag    ==  1){
                $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            }else{
                $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            }
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
            // Do the FTP connection
            $ftpObj             =       \Storage::createFtpDriver([
                                            'host'     => $hostserver , 
                                            'username' => $hostusername , 
                                            'password' => $hostpassword , 
                                            'port'     => '21',
                                            'timeout'  => '30',
                                        ]);  
            
            if( isset( $metaid ) && !is_null( $metaid )){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $tsklMeta       =       new taskLevelMetadataModel();
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                $metadata       =       $meta_info->toArray();
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =	explode('_' , $chapter_name );   
                
                if(count($chp_arr)>=2){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }                
                
            }
            
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $xmlFilePath    =       '';
            $replace_bf     =       array( '' );
            $book_id        =       $jobXMLInfo->BOOK_ID;
            
            $serverDir      =       \Config::get('dynamicConstant.CLIENT_ACK_DOWNLOADPATH'); 
            $packDestiDir   =       \Config::get('dynamicConstant.CLIENT_ACK_USERWORK'); 
            
            $empid                  =       Session::get('users')['emp_id'];
            
            $inp_rep_arr            =       array( 
                                                    'BOOK_ID'       =>      $book_id , 
                                                    'ROUND_NAME'    =>      $round_name ,
                                                    '{CID}'         =>      $chapter_name , 
                                                    '{BID}'         =>      $book_id , 
                                                    '{RID}'         =>      $round_name ,
                                                    '{CNAME}'       =>      $chapter_name , 
                                                    '{EMPID}'       =>      $empid
                                            );
           
            //copy the failure pack files to user bin
            $cmn_obj            =       new CommonMethodsController();
            $fileName           =       "$book_id".'_'.$chapter_name."_$round_name.xml";
            $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
            $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
            $open_path          =       $hostserver.$filedir.'/'.$packdesti_path;
            $dest_bck_path      =       $serverDir.'RETRY_BACKUP/'.$fileName;
                    
            //copy the failure pack files to user bin    
            try{
                
                $crd                =      "ftp://$hostusername:$hostpassword@"; 
                $ftp_obj            =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                
                //$response         =       $ftpObj->ftpSingleFileCopyOrMove(  $crd.$hostserver.'/'.$serverDir , $crd.$hostserver.'/'.$dest_bck_path , false );
                $response_copy      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path , $serverDir );
                
                if( in_array( 'failed' , $response_copy ) ){
            
                    foreach ($response_copy as $key => $value ){
                        if( $value == 'success' ){
                            unset( $response[$key] );
                        }
                    }

                    $response_copy   =       array( 'status' => 'failed'  , $response_copy );

                }else{
                    $response_copy    =       array( 'status' => 'success' , $response_copy );
                }
              
                if( $response_copy['status'] == 'success' ){    
                    return true;
                }
                
            }catch(\Exception $e){
                
                $response['errMsg'] =   'file download got failed, try once again';
                $response['reason'] =   $e->getMessage();
                return response()->json( $response );
                
            }
            
            return false;
          
    }
    
	public function downloadPackageZipS650( Request $request ) {
        
        $needfield      =       array(     
                                    'job_id'    =>      'required|numeric',
                                    'round'     =>      'required|numeric',
                                    //'metaid'    =>      'required|numeric',
                                    'type'      =>      'required|string'                   
                                );
								
        $inp_rep_arr    =       array();
        $validator      =       Validator::make( $request->all() , $needfield );
        $response       =   	$this->oopsErrorResponse;
        
        if( $validator->fails() ){
            $response['errMsg']  = json_encode( $validator->errors() );
            return response()->json( $response );
        }
        
        $jobId              =       $request->input( 'job_id' );
        $round              =       $request->input( 'round' );
		$metaid				= 		null;
		
        //$metaid             =       $request->input( 'metaid' );
        $type               =       $request->input( 'type' );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $getpackname        =       '';
        $chapDownFlag       =       false;
        $jobXMLInfo         =       downloadModel::getJobXMLInfo($jobId);
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        $chapter_name		=		'';
		
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
            // Do the FTP connection
            $ftpObj             =       \Storage::createFtpDriver([
                                            'host'     => $hostserver , 
                                            'username' => $hostusername , 
                                            'password' => $hostpassword , 
                                            'port'     => '21',
                                            'timeout'  => '30',
											'passive'  => true,
                                        ]);  

            if( isset( $metaid ) && !is_null( $metaid )){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $tsklMeta       =       new taskLevelMetadataModel();
                if($round  == '119'){
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapterwithbook( $metaid );
                }else{
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                }
                $metadata       =       $meta_info->toArray();
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =	explode('_' , $chapter_name );   
                
                if(count($chp_arr)>=2){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }                
                
            }
           
            $round_arr      =       \Config::get('constants.ROUND_NAME');
            $round_name     =       $round_arr[$round];
            $xmlFilePath    =       '';
            $response_copy	=		array();
			
            $replace_bf     =       array( '' );
            $book_id        =       $jobXMLInfo->BOOK_ID;
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
            extract( $paging_collect );
            
            $serverDir      =       \Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.FAILURE_PACKAGE_PATH'); 
            $packDestiDir   =       \Config::get('constants.PACKAGE_PATH.DESTINATIONPATH'); 
            $chapSrc	    =       \Config::get('constants.PACKAGE_PATH.XMLFILE'); 
            
            $getpackname_rec        =   DB::table('api_dataset')->select()
                                            ->where( 'JOB_ID'  , '=' , $jobId )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get()->first();
            
            $getpackname_count      =   DB::table('api_dataset')->select()
                                            ->where( 'JOB_ID'  , '=' , $jobId )
                                            ->where( 'ROUND'  , '=' , $round )
                                            ->where( 'STATUS'  , '>' , '1.5' )
                                            ->orderBy( 'ID' , 'desc' )->get();
            
            if( count( $getpackname_rec ) ){
                $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->DATASET_ID );
                $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
            }else if( count( $getpackname_rec ) && $type == 'eproof' ){
              
            }else{
                $response['errMsg']         =       'Requested Package information not available. try to start from the packaging process';                
            }
            
            if( $type == 'eproof' && $round == $round_arr['S650'] ){ 
                
                $inp_rep_arr['PACKAGING']   =   'EPROOF_PACKAGING';
                
                $getpackname_rec        =   DB::table('api_eproof_packaging')->select()
                                                ->where( 'JOB_ID'  , '=' , $jobId )
                                                ->where( 'ROUND'  , '=' , $round )
                                                ->where( 'STATUS'  , '>' , '1.5' )
                                                ->orderBy( 'ID' , 'desc' )->get()->first();
                
				$getpackname_count        =   DB::table('api_eproof_packaging')->select()
                                                ->where( 'JOB_ID'  , '=' , $jobId )
                                                ->where( 'ROUND'  , '=' , $round )
                                                ->where( 'STATUS'  , '>' , '1.5' )
                                                ->orderBy( 'ID' , 'desc' )->get();
                
                $getpackname            =       str_replace( '.zip' , '' , $getpackname_rec->PACKAGE_ID );
                $packDestiDir			=		str_replace( 'PACKAGING' , 'EPROOF' , $packDestiDir );
                $token_key_failed       =       $getpackname_rec->TOKEN_KEY;
            
            }
            
            $empid                  =       Session::get('users')['emp_id'];
            
            $inp_rep_arr            =       $inp_rep_arr2            =       array( 
                                                    'BOOK_ID'       =>      $book_id , 
                                                    'ROUND_NAME'    =>      $round_name ,
                                                    '{CID}'         =>      $chapter_name , 
                                                    '{BID}'         =>      $book_id , 
                                                    '{RID}'         =>      $round_name ,
                                                    '{CNAME}'       =>      $chapter_name , 
                                                    '{EMPID}'       =>      $empid , 
                                                    '{TKEY}'        =>      $token_key_failed ,
                                                    '{PAGING_FILENAMING}'   => $pagingfilnaming
                                            );
           
            
            //copy the failure pack files to user bin
            $cmn_obj            =       new CommonMethodsController();
            $inp_rep_arr2['{DID}']  =       str_replace(  '.zip' , '' , $getpackname  );
            $serverDir          =       $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr2 , $serverDir );
            $packagefolder_find			=	'Package';
						
            if( $type !== 'eproof' && $round == $round_arr['S650'] ){
			   
                $inp_rep_arr['{ DID}']   =   str_replace(  '.zip' , '' , $getpackname  );
                $packDestiDir       =       \Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.DESTINATION_PATH');   
                $fromSrcPackge		=		$cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
                $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
                $packdesti_path2    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Re_Package/" );
                $chapSrc            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
				
            }else{
				
                $inp_rep_arr['{DID}']   	=   	'';
                $fromSrcPackge      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir );
                $packdesti_path     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."$packagefolder_find/" );
                $packdesti_path2    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $packDestiDir."Package/" );
                $chapSrc            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapSrc );
				
            }
            
            $open_path              	=       $hostserver.$filedir.'/'.$serverDir;
            $serverDir_rename_array		=		explode( '/'  , $serverDir );
            unset( $serverDir_rename_array[count($serverDir_rename_array)-1]); 
            $serverDir_rename_str		=		 implode( '/' , $serverDir_rename_array  );
            $response_copy['status']    =        'failed';
            $get_folder_list			=		$ftpObj->directories($packdesti_path);
            
			//copy the failure pack files to user bin    
            //try{
			  
                if($ftpObj->has( $serverDir ) && false ){
                    
                    //already_open check
                    $serverDir2		=	$serverDir_rename_str.'_temp_'.date('Y_m_d_H_i_s');
                    $status_rename      =	@$ftpObj->move($serverDir, $serverDir2 );

                    if( $status_rename ){
                        
                        //deletion logic
                        //$status_rename 	=	$ftpObj->move($serverDir2 , $serverDir);
                        $return_del		=	$ftpObj->deleteDirectory($serverDir2);

                    }else if(!$status_rename){

                        $return_del		=	@$ftpObj->deleteDirectory($serverDir);

                    }else{

                        $response['status']         =   0;
                        $response['Msg']            =   'Failed';
                        $response['errMsg']         =   'Kindly Close the already opened files/folders and Try again !';	
                        return response()->json( $response );

                    }		
                   
                }
				
                if( !$ftpObj->has( $packdesti_path ) ){
					
                    $inputDownArr		=	array(  
                                                            'metaid'    => $metaid	, 'round' => $round , 'type' => $type , 
                                                            'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path ,
                                                            'type'      => $type , 'chapSrc'    => $chapSrc , 'ftpObj' => $ftpObj
                                                        );
                    
                    //@$ftpObj->makeDirectory( $serverDir );
                    $chapDownSts 		=	$this->downloadChapterFileForPackageUser( $inputDownArr );
					
                    if( $chapDownSts['status'] == 'success' ){
                        $chapDownFlag            =   true;
                        $response_copy['status'] =  'success';
                    }

                }else if( count( $get_folder_list ) == 0 ){
						
                    $inputDownArr		=	array(  
                                                            'metaid'    => $metaid	, 'round' => $round , 'type' => $type , 
                                                            'serverDir' => $serverDir , 'packdesti_path' => $packdesti_path ,
                                                            'type'      => $type , 'chapSrc'    => $chapSrc  , 'ftpObj' => $ftpObj
                                                        );
				
                    //@$ftpObj->makeDirectory( $serverDir );
                    $chapDownSts 		=	$this->downloadChapterFileForPackageUser( $inputDownArr );
					
                    if( $chapDownSts['status'] == 'success' ){
                        $chapDownFlag            =   true;
                        $response_copy['status'] =  'success';
                    }

                } 
			
                if(( $ftpObj->has( $packdesti_path ) || $ftpObj->has( $packdesti_path2 ) ) && !$chapDownFlag ){
					
                    $ftpObj->makeDirectory( $serverDir );
					
                    $crd                 =      "ftp://$hostusername:$hostpassword@"; 
                    $ftp_obj             =       new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response_copy1      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path , $serverDir );
                    $response_copy2      =       $ftp_obj->ftp_dir_copy( $crd.$hostserver.'/'.$packdesti_path2 , $serverDir );
					
                    if( in_array( 'success' , $response_copy1 ) || in_array( 'success' , $response_copy2 ) ){

                        foreach ($response_copy1 as $key => $value ){
                            if( $value == 'Success' || $value == 'success' ){
                                $response_copy    =       array( 'status' => 'success' , $response_copy1 );
                            }
                        }

                        foreach ($response_copy2 as $key => $value ){
                            if( $value == 'Success' || $value == 'success' ){
                                $response_copy    =       array( 'status' => 'success' , $response_copy2  );
                            }
                        }

                    }else{

                        $response_copy    =       array( 'status' => 'success' , $response_copy2 , $response_copy1 );

                    }

                }else if( $chapDownFlag ){	
                    
                }else{
                    $response['status']         =   0;
                    $response['Msg']            =   'Failed';
                    $response['errMsg']         =   'Source folder not exist to download';					
                }
			
            if( $response_copy['status'] == 'success' ){
            
                $postdata       =       [];
                $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;
                
                $postdata['file_path']      =       $open_path.'/<>'.$domuser.'<>'.$domPass;
                $postdata['system_ip']      =       $request->ip();
                $postdata['method_name']    =       "doOpenDriveServer";
                $postdata['processname']    =       "checkout";
                $insertfilehandler          =       fileHandler::insertNew($postdata);   
                
                if( $insertfilehandler ){
                    $response       =   $this->successResponse;
                    $response['rmiId']          =   $insertfilehandler;
                }
           
            }else{
                
                //$response    =   $response_copy[0];
                //  Trying to download it from source paths [taps final output consider as input ]
                //return false;
				
                $jobStg =   new jobStage();
                $getRecords     =       $jobStg->getCurrentJobStageInfo( $metaid , $round , 23 );
                
                if( count( $getRecords ) ){
                    
                    $rec_obj        =       $getRecords[0];
                    $jobStageId    =   $rec_obj->JOB_STAGE_ID;
                            
                    $workflowPath                       =   new workflowServerMapPathModel();
                    $serverMapPath                      =   $workflowPath->getWorkflowServerMapPath( $jobStageId );
                   
                    if( $serverMapPath['status'] ){
                        $serverMapPath['detail']['work']    =   $hostserver.'/'.$serverDir.'/';                         
                        $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath);
                        
                        $postdata       =       [];
                        $domuser        =       $getlocationftp->FILE_SERVER_USER_NAME;
                        $domPass        =       $getlocationftp->FILE_SERVER_PASSWORD;

                        $postdata['file_path']      =       $open_path.'/<>'.$domuser.'<>'.$domPass;
                        $postdata['system_ip']      =       $request->ip();
                        $postdata['method_name']    =       "doOpenDriveServer";
                        $postdata['processname']    =       "checkout";
                        $insertfilehandler          =       fileHandler::insertNew($postdata);   

                        if( $insertfilehandler ){
                            $response       =   $this->successResponse;
                            $response['rmiId']          =   $insertfilehandler;
                        }   
                    }   
                }
            }
           /*
        }catch(\Exception $e){
			
            $response           =   $this->oopsErrorResponse;
			$error				=	$e->getTraceAsString();
            $response['reason'] =   $packdesti_path.$error;
			
            if( strpos( $error , 'Access is denied' ) ){
                    $response['errMsg']		=	'Kindly Close the already opened files/folders and Try again ';
            }
			
            return response()->json( $response );
            
        }
		*/
        return response()->json( $response );
        
    }
    
    //redo view 
    public function getRedoview(Request $request){
        
        $jobRedoview 	= 	downloadModel::getRedoview($request->input('ID'));
        
        if(count($jobRedoview)>=1){
                // Do the FTP connection
            
                $ftpObj 	= 	\Storage::createFtpDriver([
                                            'host'     => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST'), 
                                            'username' => \Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME'),
                                            'password' => Crypt::decryptString(\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD')), // 
                                            'port'     => '21',
                                            'timeout'  => '30',
                                        ]);

                $xmlFilePath 		= 	'';
                $jobAssignedConst 	= 	\Config::get('constants.JOB_ASSIGNED_CONST');
                
                $bookid 		=       $request->input('BOOK_ID');
                $serverDir 		= 	\Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PATH') . $bookid . '/'.$jobAssignedConst;			
                $serverDirFiles 	=	 $ftpObj->allFiles($serverDir);
                if(!empty($serverDirFiles)) 
                {
                        $filePath 		= 	$serverDir.'/test.txt';
                        $filecontent 	= 	$ftpObj->get($filePath); // read file content
                        echo $filecontent;exit;
                }
                else
                {
                        echo '<p class="text-center">No Data found.</p>';
                        exit();
                }
        }

    }
        
    public function JobassignedtoAmUser(Request $request){
        $response   =   $this->oopsErrorResponse;
        if ($request->input('user_id') > 0) {
            
            $Req = (object) $request->input();
            $arrData    =   array();
            $arrData['user_id']         =   $request->input('user_id');
            $arrData['book_id']         =   $request->input('book_id');
            $bookDetails                =   downloadModel::getBookDetails($arrData['book_id']);
            $jobId                      =   '';
            if(!empty($bookDetails)){
                $arrData['BookTitle']   =  $bookDetails->JOB_TITLE;
                $jobId    =   $bookDetails->JOB_ID;
                $arrData['ISSN_ONLINE'] =   $bookDetails->ISSN_ONLINE;
                $arrData['ISSN_PRINT']  =   $bookDetails->ISSN_PRINT;
                $arrData['receivedDate']=   $bookDetails->CREATED_DATE;
                $arrData['AUTHOR_NAME'] =   $bookDetails->AUTHOR_NAME;
                $arrData['editorname']  =   $bookDetails->EDITOR_NAME;
                $arrData['PublisherName']   =   $bookDetails->PUBLISHER_NAME;
                $arrData['ContactPersonName']       =   $bookDetails->PE_NAME;
                $arrData['ProductionClassification']=   $bookDetails->PRODUCTION_CLASSIFICATION;
            }
            $userDetails                =   downloadModel::getUserDetails($arrData['user_id']);
            $arrData['AM_Mail']         =   $userDetails->EMAIL;
            $arrData['AM_name']         =   $userDetails->userName;
            $assignedJob                =   downloadModel::JobAssignedToAmUserMod($arrData,$jobId);
            
            if($assignedJob['0']    ==  'success' ){
                $this->newJobNotificationMail($arrData);
            }
            
            /*  
             *  $this->assignPEmail($arrData);
                $this->assignPMmail($arrData);
            */
            
            $response['msg'] = "Assigning process failed.";
            if($assignedJob['0'] == 'success'){  
                $response   =   $this->successResponse;
                $response['msg']    =   "Successfuly Assigned to new Account Manager";
                $response['errMsg'] =   'Successfully Assigned.';
            }
            
            return response()->json($response);
            
        }
        
    }
    
    public function getCucJobXMLInfo(Request $request) 
    {
        $response   =   $this->locationNotFoundResponse;
        $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
        if(count($getlocationftp)>=1)
        {
            $roundid        =   $request->input('roundid');
            $stageid        =   $request->input('stageid');
            $roundname      =   $request->input('roundname');
            $stagename      =   $request->input('stagename');
            $metaid         =   $request->input('metadataid');
            $jobId          =   $request->input('jobId');
            $Chapter        =   $request->input('Chapter');
            $bookid         =   $request->input('bookid');
            
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            // Do the FTP connection
            $ftpObj         =   \Storage::createFtpDriver([
                                                'host'     => $hostserver, 
                                                'username' => $hostusername,
                                                'password' => $hostpassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
            $getuserid          =   $this->empId;
            $cucuserworkfolder  =   Config::get('constants.WATCH_CE_ESTIMATION_FOLDER');
            $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
            if(!empty($cucDirFiles)) 
            {
                 foreach($cucDirFiles as $serverDirFile) 
                 {
                    if(pathinfo($serverDirFile)['extension'] == 'xml') 
                    {
                        $xmlFilePath    =   $serverDirFile;
                    }
                }
                if($xmlFilePath == '') 
                {
                    $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                    return response()->json($response);
                }
                
                $filePath       =   '/' . $xmlFilePath;
                // $filecontent = self::xmlSampleContent();
                $filecontent    =   $ftpObj->get($filePath); // read file content
                $xmlPath        =   base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
                $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';

                // LOAD XML FILE CONTENT
                $XML = new \DOMDocument(); 
                $XML->loadXML($filecontent);

                // START XSLT 
                $xslt = new \XSLTProcessor(); 

                // IMPORT STYLESHEET
                $XSL = new \DOMDocument(); 
                $XSL->load( $xslFilePath ); 
                $xslt->importStylesheet( $XSL ); 
                $response       =   $this->successResponse;
                $response['errMsg']     =   $xslt->transformToXML( $XML );
                $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                return response()->json($response);
            }
            return response()->json($this->nofileResponse);
        }
        return response()->json($response);
    }
    
    public function getCucXMLInfo(Request $request) 
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $roundid        =   $request->input('roundid');
                $stageid        =   $request->input('stageid');
                $roundname      =   $request->input('roundname');
                $stagename      =   $request->input('stagename');
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');

                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $cucuserworkfolder  =   $hostpath.Config::get('constants.CUC_CHECKOUT_FOLDER').$bookid.'/'.$Chapter;
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }

                    if($xmlFilePath == '') 
                    {
                        $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'cucview.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $response       =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                return response()->json($this->nofileResponse);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            return response()->json($response);
        }
    }
    
    public function newJobNotificationMail($amDetails){
        $mailArray = $mailData = array();
        $mailData['Title']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
        $mailData['HeadLine']       =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_HEAD_TITLE');
        $mailData['ToName']         =   $amDetails['AM_name'];
        $mailData['authorname']     =   $amDetails['AUTHOR_NAME'];
        $mailData['BookId']         =   $amDetails['book_id'];
        $mailData['BookTitle']      =   $amDetails['BookTitle'];
        $mailData['BookIsbn']       =   $amDetails['ISSN_ONLINE'];
        $mailData['PrintIsbn']      =   $amDetails['ISSN_PRINT'];
        $mailData['ReceivedDate']   =   $amDetails['receivedDate'];
        $mailData['editorname']     =   $amDetails['editorname'];
        $mailData['PublisherName']  =   $amDetails['PublisherName'];
        $mailData['ContactPersonName']       =   $amDetails['ContactPersonName'];
        $mailData['ProductionClassification']=   $amDetails['ProductionClassification'];
        $mailData['mailcontent']    =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ARRIVED_CONTENT');
        $mailArray['Data']          =   $mailData;
        $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_JOB_ASSIGN_TEMP');
       // $mailData['Title'] = 'New Quote Created';
      
        $mailArray['Subject']       =   'New Title Arrival Alert - '.$amDetails['book_id'];
        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']        =   $amDetails['AM_Mail'];
        $mailArray['CcMail']        =   Config::get('constants.CC_EMAIL_LIST');
		
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
         
    public function sendMailBladeTemplate($mailArray) {
        if (is_array($mailArray)) {
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }

                $message->getSwiftMessage();
            });

            if (Mail::failures()) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['MsgText'] = Mail::failures();
            } else {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }

            return $Response;
        }

    }
    
    public function sendMailNofity(  $purpose  ,  $template_name  , $info_arr ){
        
       switch( $purpose )
       {
           case 'productionLocationChange':
                //send to pm , related am alert mail notification for location change
                //re send job assigned notificaiton mail
           
               break;
           case 'newJobAssignment':
                
               break;
           
           default:
               break;
           
       }  
    }
    
    public function doSuccessredologview(Request $request) 
    {
        try{
			
            $response       =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'clientid'  => 'required|numeric',
                                                    'jobID' 	=> 'required|numeric',
                                                    'roundID' 	=> 'required|numeric',
                                                    'typeoflog' => 'required'
                                                ]);
            if ($validation->fails())
            {
                $response       =   $this->validationResponse;
                $response['errMsg']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId              =   $request->input('jobID');
            $round              =   $request->input('roundID');
            $clientid           =   $request->input('clientid');
            $typeoflog          =   $request->input('typeoflog');
            
            $jobXMLInfo         =   downloadModel::getJobXMLInfo($jobId);
           
            $getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );
            $getlogfiles        =   [];
            
            if( empty( $getlocationftp ) )            
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            if(count($getlocationftp)>=1)
            {
                //need to dynamicaly bind the production location based on table location
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   ($getlocationftp->FTP_PATH);
                // Do the FTP connection

                $ftpObj             =   \Storage::createFtpDriver([
                        'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
                        'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
                        'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
                        'port'     => '21',
                        'timeout'  => '30',
                    ]);  

                $round_arr          =   \Config::get('constants.ROUND_NAME');
                $round_name         =   $round_arr[$round];
                $book_id            =   $jobXMLInfo->BOOK_ID;
                
                $getclickentackfile =   apiClientAcknowledgement::find($clientid);
                $serverDir          =   ($typeoflog     ==  "success"?Config::get('constants.COPY_CLIENT_ACK_FOLDER_SUCCESS'):Config::get('constants.COPY_CLIENT_ACK_FOLDER_FAILED'));
                $type_of_ack        =    $getclickentackfile->PROCESS_TYPE_DIFF;
                $filenameconsist    =    $getclickentackfile->FILE_NAME_IN_LOG;
                
                if(count($getclickentackfile)>=1){
                    
                    $acklogfile     =   $getclickentackfile->FILE_NAME;
                    if(strpos($acklogfile,'.') !== 	false){
                        $getlogfiles=   explode('.',$acklogfile);
                    }
                    
                    $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver; 
                    $roundname              =   Config::get('constants.ROUND_NAME')[$round];
                    $jobsheetlocationpath   =   $crd.$serverDir.$getlogfiles[0].'.log';
                    
                    if( strpos( $filenameconsist , 'eProof' ) ){
                       $serverDir       =       \Config::get('constants.EPROOF_CLIENT_ACK_PRODUCTION_STORAGE_LOCATION');
                       $jobsheetlocationpath   =   $crd.$serverDir.$acklogfile;
                    }
                    
                    $inp_rep_arr            =   array( 
                                                'BOOK_ID' =>    $book_id , 
                                                'ROUND_NAME' =>    $roundname ,
                                                '{BID}' => $book_id , 
                                                '{RID}' => $roundname
                                             );
                    
                    $cmn_obj                =  		new CommonMethodsController();                    
                    $jobsheetlocationpath   =   	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobsheetlocationpath );
                    
                    $logfiles       		=   	file_get_contents( $jobsheetlocationpath );
                    
                    $response        =   $this->successResponse;
                    if( $type_of_ack == 'PACKAGING' ){ 
                       $results         =       htmlentities( $logfiles , ENT_COMPAT, 'UTF-8');
                       $response['errMsg']  =   nl2br( $results );
                    }else{
                        $response['errMsg']  =   nl2br( $logfiles );
                    }
                    return response()->json($response);
                }
                return response()->json($this->locationNotFoundResponse);
            }
            return response()->json($this->locationNotFoundResponse);
        }catch( \Exception $e ){
            $response['errMsg']  =   'Log file is not found';
            $response['reason']  =   $e->getMessage();
            return response()->json($response);
        }
    }
        
    //chapter download 
    public function chapterdownloadList( $round ){   
        $data   =   [];
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $roundid            =   isset( $round ) ? $round  : Config::get('constants.ROUND_NAME.116');
		if( !in_array( $roundid,$round_arr ) ){
			return redirect('download-index');
		}
        $roundname          =   $round_arr[$roundid];
        $this->displayMenuName(Config::get('menuconstants.MENU.DOWNLOAD_INDEX'),$data);
        $data['pageTitle']  =   $roundname.' Download';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;        
        $data['optiondata']     =   $this->rounddownload;
        $data['optionenable']   =   true;
        
        //dummy blade condition for eproof
        if( 'S300' ==  $roundname  ){
            return view('download.eproof.chapter-download2')->with( $data );	
        }
        
	return view('download.chapter-download')->with( $data );	
        
    }
    
    
    public function getChapterdownloadFailedList( $round = 116 ) 
    {	
        $data       =   downloadModel::getChapterdownoadlist( $round );           
        $response["downloadfailed"]     =   $data;
        return response()->json($response);   
        
    }
    
    public function doChapterlevelassignedlist( $round = 116 ){
        $arrData    			=   array();
        $data                    	=   downloadModel::getChapterlevelassigned( $round ); 
        $getuserListByRole       	=   downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =   projectModel::getUserListByTeam($this->teamId);
        
        $response["jobassigned"] 	=   $data;
        $response['amUserList']  	=   $getuserListByRole;	
        $response['pmUserList']  	=   $getPmuserListByRole;
        
        return response()->json($response);
    }
    
    public function doChapterlevelassignedlisteproof( $round = 118 ){
        
        $arrData    			=   array();
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        
        if( 'S650' == $round_arr[$round] ){
            $data                    	=   downloadModel::getBooklevelassignedForEproof( $round ); 
        }else{
            $data                    	=   downloadModel::getChapterlevelassignedForEproof( $round ); 
        }
        
        $getuserListByRole       	=   downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =   projectModel::getUserListByTeam($this->teamId);
        
        $response["jobassigned"] 	=   $data;
        $response['amUserList']  	=   $getuserListByRole;	
        $response['pmUserList']  	=   $getPmuserListByRole;
        
        return response()->json($response);
    }
    
    public function getS650DownloadedJobs( Request $request , $round = 120 ){
        
        $arrData    			=       array();
        $round_arr                      =       \Config::get('constants.ROUND_NAME');
        $data                    	=       downloadModel::getBooklevelassignedForEproof( $round ); 
        
       
        $getuserListByRole       	=       downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =       projectModel::getUserListByTeam( $this->teamId );
        
        $response["jobassigned"] 	=       $data;
        $response['amUserList']  	=       $getuserListByRole;	
        $response['pmUserList']  	=       $getPmuserListByRole;
        
        return response()->json($response);
        
    }
    
    public function getS650CorrectionDownloadlist( Request $request , $round = null , $jobid = null ){
        
        $arrData    			=       array();
        $round_arr                      =       \Config::get('constants.ROUND_NAME');
        $userid                         =       $this->loginUserId;
        $data                    	=       downloadModel::getChapterlevelCorrectionDownload650( $round , 2 , $userid ); 
        $getuserListByRole       	=       downloadModel::getUserListByRole('45');
        $getPmuserListByRole            =       projectModel::getUserListByTeam( $this->teamId );
        
        $response["jobassigned"] 	=       $data;
        $response['amUserList']  	=       $getuserListByRole;	
        $response['pmUserList']  	=       $getPmuserListByRole;
        
        return response()->json($response);
        
        
    }
    
    public function getChapterjobsheetview(Request $request) 
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric',
                                                'metadataid' 	=> 'required',
                                                'Chapter' 	=> 'required',
                                                'bookid' 	=> 'required',
                                                'roundid' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId          =   $request->input('jobId');
            $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $chapterno      =   $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $roundid        =   $request->input('roundid');
                $roundname      =   Config::get('constants.ROUND_NAME')[$roundid];
                $hostserver     =   $getlocationftp['HOST'];
                $hostusername   =   $getlocationftp['FTP_USERNAME'];
                $hostpassword   =   $getlocationftp['FTP_PASSWORD'];
                $hostpath       =   $getlocationftp['HOST_PATH'];
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $wheredata          =   ['ROUND_ID'=>$roundid];
                $xmlFilePath        =   "";
                $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
			
                if($getjobsheetpath !=  null) 
                {
//                    if(strpos(strtoupper($Chapter),Config::get('constants.CHECK_PART')) !== false)
//                    {
//                        $chapterno  =   $Chapter;
//                    }else
//                    {
//                        $chapterno  =   (strpos($Chapter,'_') !== false?substr(strrchr($Chapter, "_"), 1):$Chapter);
//                    }
                    
                    $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 
                    if( $roundname == 'S300' ){
                       // $jbstsrawpath   =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S300'); 
                       // $serverDir        =        $jbstsrawpath;
                    }
                   
                    switch($getjobsheetpath->ROUND_ID){
                        case 116:
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname,                        
                                            'STAGE_NAME' =>  Config::get('constants.STAGE_NAME.COPY_EDITING'),                        
                                            'CID' =>  $chapterno                       
                                         );
                        break;
                        case 118:
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname,                        
                                            'CID' =>  $chapterno                       
                                         );
                        break;
                        case (104 || 114):
                        $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname                
                                         );
                        break;
                        case (120):
                            //$roundname  =   'S650';
                            $inp_rep_arr    =   array( 
                                                'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $roundname                
                                         );
                        break;
                    
                    }
                    
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
					//echo $serverDir;exit;
                    
                    $serverDirFiles =   $ftpObj->allFiles( $serverDir );
                    
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                            if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos(strtolower($jobsheetpath),'jobsheet') !==   false) {
                                $xmlFilePath = $serverDirFile;
                            }
                        }
                    }
                    
                    if($xmlFilePath == '') 
                    {
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 

                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $response       =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                $response['errMsg']     =   'Job sheet path is not found';
                return response()->json($response);
            }
            return response()->json($response);
            
        }
        catch( \Exception $e )
        {           
            return response()->json($response);
        }
    }
    
    public function doOpenrawfile(Request $request)
    {
        try
        {
            $response   =   $this->notfoundResponse;
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId              =   $request->input('jobId');
            $bookdata           =   jobModel::where('JOB_ID',$jobId)->first();
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            if($bookid  ==  "")
            {
                return response()->json($response);
            }
            $typeofseries       =   $bookdata->JOB_TYPE;
            $checktypeofseries  =   Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES');
            $rawpath            =   ($checktypeofseries   ==  $typeofseries?Config::get('serverconstants.S50_COPY_EDITING_PATH'):Config::get('serverconstants.RAW_PATH'));
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                switch($checktypeofseries)
                {
                    case 'S200 Of Series':
                    $inp_rep_arr    =   array( 
                                            '{BID}'     =>  $bookid , 
                                            '{CID}/'    =>  ''
                                         );
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$serverDir;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    //check directory is exist or not
                    $checkSourceexist   =   $hostpath.$serverDir;
                    $checkfileDirexist  =   $ftpObj->allDirectories($checkSourceexist);
                    break;
                    case ('Regular title' || 'Regular title'):
                    $sfifty             =   Config::get('constants.ROUND_OF_NAME.S5');
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$rawpath.$bookid.'/'.$sfifty;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    //check directory is exist or not
                    $checkSourceexist   =   $hostpath.$rawpath.$bookid.'/'.$sfifty;
                    $checkfileDirexist  =   $ftpObj->allFiles($checkSourceexist);
                    break;
                }
                
                if(!empty($checkfileDirexist)) 
                {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    $response       =   $this->successResponse;
                    $response['rmID']   =   $insertfilehandler;
                    return response()->json($response);
                }
                return response()->json($this->nofileResponse);
            }
            $response         =   $this->locationNotFoundResponse;   
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response         =   $this->locationNotFoundResponse;   
            return response()->json($response);
        }
    }
    
    public static function jobcontactImportTemplateDownload( Request $request ) {
           
            if(Session::has('users')== ''){
                return redirect('/');
            }
            
            $jobID          =       '';
            $columnArr      =       array();
            
            Excel::create( 'contactTemplate_'.date('Ymd') , function($excel) use ($jobID) {

		$numberArray        =       array("Numeric", "Alphanumeric", "RomanLC", "RomanUC");
                //$indesignArray      =       projectModel::getInDesignVersion(array());
                $indesignArray      =       array();
                $touchedArray       =       array("Yes", "No");
                $excel->setTitle('ContactDetailsImport');
                $excel->setCreator('Ananth B - ')
                      ->setCompany('SPi Global');
                $excel->setDescription('Magnus - Workflow System');
                $numberCol      =       "AH"; 
                $indesignCol        =       "AI"; 
                $touchedCol         =       "AJ";
                $counter            =       1;
                $rowCnt             =       10;
                
                $excel->sheet('contactImport_'.date('Ymd'), function($sheet) use($counter,$rowCnt,$numberCol, $indesignCol, $touchedCol, $numberArray, $indesignArray, $touchedArray)  {
                
                $sheet->setWidth(   array(
                        			'A'     =>  25,
						'B'     =>  45,
						'C'     =>  25,
						
					)   );
                
                $sheet->setHeight(  array(    1     =>  25    )   );
                
                $sheet->cells('A1:C1', function($cells) {
                    $cells->setBackground('#6fb3e0');	
                    $cells->setFontSize(13);	
                    $cells->setFontWeight('bold');	
                    $cells->setBorder('solid', 'solid', 'solid', 'solid');
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                });
                
                $sheet->getColumnDimension($numberCol)->setVisible(false);
                $sheet->getColumnDimension($indesignCol)->setVisible(false);
                $sheet->getColumnDimension($touchedCol)->setVisible(false);
                
                for($r = 0; $r<count($numberArray); $r++) {
                    $sheet->setCellValue($numberCol.($r+1), $numberArray[$r]);
                }
                for($r = 0; $r<count($indesignArray); $r++) {
                    $sheet->setCellValue($indesignCol.($r+1), $indesignArray[$r]->version);
                }
                for($r = 0; $r<count($touchedArray); $r++) {
                    $sheet->setCellValue($touchedCol.($r+1), $touchedArray[$r]);
                }
                
                $data = array(
                            array(  'Name', 'Email' , 'Location' ),
                        );
                
		$sheet->fromArray($data, null, 'A1', false, false);				
                });
                                     
            })->export('xlsx');
                
	}
	/*intake items report download*/
    public static function checkitemsDownload(Request $request, $projectID = null) 
    {

            Excel::create('Intake Report_'.date('Ymd'), function($excel) use ($projectID) 
            {
                    $intakeitems 	= 	array(); 
                    $projecttitle 	= 	checkItemsModel::getProject($projectID);
                    $jobTitle 		=	(count($projecttitle)>=1?$projecttitle->JOB_TITLE:'');
                    $jobisbn 		=	(count($projecttitle)>=1?$projecttitle->ISSN_ONLINE:'');
                    $jobproduct 	=	'';
                    $intakeitems 	= 	checkItemsModel::getCheckItemsList($projectID);
                    $getparentsdata = 	checkItemsModel::getCheckItemsParent($projectID);
                    $projectcheckitems 			=	array();
                    if(!empty($getparentsdata)) 
                    {
                            foreach($getparentsdata as $key => $checkItemParent) 
                            {
                                    $projectcheckitems[$key] 	=	$checkItemParent;
                                    $getchild			= 	checkItemsModel::getCheckItemsChildren($checkItemParent['ID'],$projectID);
                                    if(count($getchild)>=1)
                                    {
                                            $data['parents'] 	=	$checkItemParent;
                                            foreach($getchild as $ckey=>$child)
                                            {
                                                    $projectcheckitems[$key]['checkItemsChildren'][] 	=	$child;
                                            }
                                    }
                                    else{
                                            $projectcheckitems[$key]['checkItemsChildren'] 	=	[];
                                    }
                            }
                    }
                    $excel->setTitle('Intake Reports_'.date('Y-m-d'));
                    $excel->setCreator('vinoth')->setCompany('SPi Global');
                    $excel->setDescription('Magnus Springer - Intake reports');

                    $excel->sheet($jobisbn, function($sheet) use ($projectcheckitems,$jobTitle,$jobisbn,$jobproduct,$projectID) 
                    {				
                            $data 	= 	array(
                                                                    array( 'Title: '.$jobTitle, 
                                                                                    'ISBN: '.$jobisbn,'','', 
                                                                                    'Production Category: '.$jobproduct
                                                                            )
                                                            );
                            $sheet->fromArray($data, null, 'A1', false, false);
                            $sheet->setWidth(array(
                                                    'A'     =>  75,
                                                    'B'     =>  5,
                                                    'C'     =>  5,
                                                    'D'     =>  30,
                                                    'E'     =>  40,
                                            ));
                            $sheet->setHeight(array(
                                                    1     =>  30,
                                            ));			
                            $sheet->cells("A1:A1", function($cells) {
                            $cells->setBorder('', 'thin', '', '');
                            });
                            $sheet->cells('A1:E1', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(12);	
                                    $cells->setFontWeight('bold');	
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });

                            $sheet->mergeCells('B1:D1');
                            //$sheet->setFreeze('A2');
                            $sheet->row('A2', array( '','', 
                                                                            '','', ''));
                            $sheet->row(3, array( 'Check Item', 
                                                                            'OK','','Problem', 
                                                                            'Quick Info to the Item'
                                                                    ));

                            $sheet->cells("A3:E3",function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thin', 'none', 'none', 'none');
                                    $row->setAlignment('left');
                                    $row->setValignment('top');
                                    $row->setBackground('#bfbcbc');
                            });
                            $sheet->cell("B3:B3", function($cells) {
                            $cells->setBorder('thin', 'solid', 'thin', 'thin');
                            });
                            $sheet->cell("C3:C3", function($cells) {
                            $cells->setBorder('thin', 'thin', 'thin', 'solid');
                            });
                            $sheet->row(4, array( '', 
                                                                            'Yes','No','', 
                                                                            ''
                                                                    ));
                            $sheet->cells("A4:E4",function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('solid', 'thin', 'thick', 'solid');
                                    $row->setAlignment('left');
                                    $row->setValignment('top');
                                    $row->setBackground('#bfbcbc');
                            });

            $t 		= 	5;
                            if(count($projectcheckitems)>=1)
                            {
                                    $c1 	=	1;
                                    foreach($projectcheckitems as $key=>$intakes)
                                    {
                                            if($intakes['TITLE'] !=	"Others")
                                            {
                                                    $sheet->getStyle('A'.$t)->getAlignment()->setWrapText(true);	
                                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                                    $sheet->cells("A".$t.":E".$t,function($row)
                                                    {
                                                            $row->setFontFamily('Arial');
                                                            $row->setFontSize(10);	
                                                            $row->setFontWeight('bold');	
                                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                            $row->setAlignment('left');
                                                            $row->setValignment('left');
                                                    });
                                                    $sheet->row($t, array( $c1.' '.$intakes['TITLE'], 
                                                                            '','','', 
                                                                            ''
                                                                    ));

                                                    if(count($intakes['checkItemsChildren'])>=1) 
                                                    {
                                                            $c2 	= 	1;	
                                                            foreach($intakes['checkItemsChildren'] as $checkItemsChildrenRec) 
                                                            {	
                                                                    ++$t;
                                                                    $sheet->getStyle('A'.$t)->getAlignment()->setWrapText(true);	
                                                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                                                            $sheet->cells("A".$t.":E".$t,function($row)
                                                                            {
                                                                                    $row->setFontFamily('Arial');
                                                                                    $row->setFontSize(10);	
                                                                                    $row->setFontWeight('none');	
                                                                                    $row->setBorder('solid', 'solid', 'dotted', 'solid');
                                                                                    $row->setAlignment('left');
                                                                                    $row->setValignment('left');
                                                                            });
                                                                            $okdata 	=	($checkItemsChildrenRec['OK_DATA'] == 1?'Yes':'');
                                                                            $nodata 	=	($checkItemsChildrenRec['OK_DATA'] == 0?'No':'');
                                                                            $sheet->row($t, array( $c1.'.'.$c2.' '.$checkItemsChildrenRec['TITLE'], 
                                                                                                    $okdata,$nodata,$checkItemsChildrenRec['PROBLEM_DATA'], 
                                                                                                    $checkItemsChildrenRec['QUICK_INFO_DATA']
                                                                                            ));
                                                                    ++$c2;
                                                            }

                                                            $sheet->cells('A'.$t.':E'.$t, function($row)
                                                            {
                                                                    $row->setFontFamily('Arial');
                                                                    $row->setFontSize(10);	
                                                                    $row->setFontWeight('none');	
                                                                    $row->setBorder('solid', 'solid', 'thick', 'solid');
                                                                    $row->setAlignment('left');
                                                                    $row->setValignment('left');
                                                            });
                                                    }
                                                    $t++;
                                                    ++$c1;
                                            }
                                    }
                                    if(!isset($_COOKIE['springer_'.$projectID])) 
                                    {
                                            $probleminfo 	=	"";
                                            $quickinfo 		=	"";
                                    } 
                                    else 
                                    {
                                            $getcookies 	=	json_decode($_COOKIE['springer_'.$projectID]);
                                            if(count($getcookies)>=1)
                                            {
                                                    if($getcookies->checkjob 	==	$projectID)
                                                    {
                                                            $probleminfo 	=	$getcookies->problemcheck;
                                                            $quickinfo 		=	$getcookies->quickinfocheck;
                                                    }
                                            }else{
                                                    $probleminfo 	=	"";
                                                    $quickinfo 		=	"";
                                            }
                                    }
                                    //OTHERS PROBLEM
                                    $sheet->getStyle('D'.$t)->getAlignment()->setWrapText(true);	
                                    $sheet->getStyle('E'.$t)->getAlignment()->setWrapText(true);
                                    $sheet->cells("A".$t.":A".$t,function($row)
                                    {
                                            $row->setFontFamily('Arial');
                                            $row->setFontSize(10);	
                                            $row->setFontWeight('bold');	
                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                            $row->setAlignment('left');
                                            $row->setValignment('left');
                                    });
                                    $sheet->cells("B".$t.":E".$t,function($row)
                                    {
                                            $row->setFontFamily('Arial');
                                            $row->setFontSize(10);	
                                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                                            $row->setAlignment('left');
                                            $row->setValignment('left');
                                    });
                                    $sheet->row($t, array( $c1.' '.'Other Problems', 
                                                                            '','',$probleminfo, 
                                                                            $quickinfo));
                                    //horizontal line
                                    $range 	= 	"A3:A".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"B4:B".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"C3:C".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"D3:D".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"E3:E".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                            }
                            $t 	= 	$t+1;	
                            $datenow 	=	date('d-M-Y');
                            $username 	=	$this->userName;
                            $username 	=	(!empty($username)?$username:'');
                            $companyname 	=	"SPi Pondicherry";
                            $sheet->row($t, array( '','', 
                                                                            '','', ''));
                            $t 	=	$t+1;

                            $sheet->cells("A".$t.":A".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thick', 'thin', 'thin', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->cells("B".$t.":E".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thick', 'thin', '', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->mergeCells('B'.$t.':E'.$t);
                            $sheet->row($t, array( 'Date : '.$datenow, 
                                                                            '','','', 
                                                                            ''
                                                                    ));
                            $sheet->mergeCells('B'.$t.':E'.$t);
                            $t 		=	$t+1;
                            $sheet->cells("A".$t.":A".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('thin', 'thin', 'thick', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->cells("B".$t.":E".$t,function($row)
                            {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setFontWeight('bold');	
                                    $row->setBorder('', 'thin', 'thick', 'thin');
                                    $row->setAlignment('left');
                                    $row->setValignment('bottom');
                            });
                            $sheet->mergeCells('B'.$t.':E'.$t);

                            $sheet->row($t, array( 'Name : '.$username, 
                                                                            'Company Name / Location: '.$companyname,'No','', 
                                                                            ''
                                                                    ));
                            /*$sheet->setMergeColumn(array(
                                                    'columns' => ['B','C','D','E'],
                                                    'rows' => [
                                                            [$t-1,$t]
                                                    ]
                                            ));*/

                    });			

            })->download('xlsx');
    }

    /* PAR REPORTS download*/
    public static function parreportDownload(Request $request, $projectID = null) 
    {
        $getjobinfo             =   jobModel::where('JOB_ID',$projectID)->first();
        if(count($getjobinfo)>=1)
        {
            $bookid                 =   $getjobinfo->BOOK_ID;
            Excel::create('Par Report_'.$bookid, function($excel) use ($projectID,$getjobinfo,$bookid) 
            {
                    $parreportsitems        = 	array(); 
                    $checkpartavailable     =   taskLevelMetadataModel::getreportofconsolidate("4",$projectID);
                    if(count($checkpartavailable)>=1)
                    {
                        $partresult     =   [];
                        $partincrement  =   0;
                        //get fm record 
                        $getfrontmatter =   taskLevelMetadataModel::getreportofconsolidate("1",$projectID);
                        if(count($getfrontmatter)>=1)
                        {
                            foreach($getfrontmatter     as     $frontdata)
                            {
                                $partresult[$partincrement]  =   $frontdata;
                                $partincrement++;
                            }
                        }
                        $partincrement  =   $partincrement;
                        
                        $onlyChapter    =   taskLevelMetadataModel::getChapterWithoutPart($projectID);
            
                        if(count($onlyChapter)>=1)
                        {
                            foreach($onlyChapter     as     $onlyChapters)
                            {
                                $partresult[$partincrement]  =   $onlyChapters;
                                $partincrement++;
                            }
                            $partincrement  =   $partincrement;
                        }
            
                        //get part then chapter record 
                        foreach($checkpartavailable     as $partidvalue)
                        {
                            ++$partincrement;
                            $partresult[$partincrement]     =   $partidvalue;
                            $chapterdataresult  =   taskLevelMetadataModel::getchapterlistagainpart($partidvalue->METADATA_ID,$projectID);
                            if(count($chapterdataresult)>=1)
                            {
                                foreach($chapterdataresult  as  $chapterdatavalue)
                                {
                                    ++$partincrement;
                                    $partresult[$partincrement]     =   $chapterdatavalue;
                                }
                            }
                        }
                        //get bm then chapter record 
                        $getbackmatter      =   taskLevelMetadataModel::getreportofconsolidate("3",$projectID);
                        if(count($getbackmatter)>=1)
                        {
                            ++$partincrement;
                            foreach($getbackmatter  as     $backdata)
                            {
                                $partresult[$partincrement]  =   $backdata;
                            }
                        }
                        $parreports         =   collect($partresult);
                    }
                    else
                    {
                        $parreports         = 	downloadModel::getParreportDownload($projectID);
                    }
                    $excel->setTitle('Par Reports_'.$bookid);
                    $excel->setCreator('vinoth')->setCompany('SPi Global');
                    $excel->setDescription('Magnus Springer - Par reports');

                    $excel->sheet('Par Reports_'.$bookid, function($sheet) use ($parreports,$projectID,$bookid) 
                    {	
                            $sheet->mergeCells('A1:F1');
                            $data 	= 	array(
                                                                    array('PAR Report - '.$bookid.''
                                                                    )
                                                            );
                            $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                            $sheet->fromArray($data, null, 'A1', false, false);
                            $sheet->setWidth(array(
                                                    'A'     =>  15,
                                                    'B'     =>  10,
                                                    'C'     =>  10,
                                                    'D'     =>  15,
                                                    'E'     =>  15,
                                                    'F' 	=>  15
                                            ));

                            $sheet->cells('A1:F1', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);	
                                    $cells->setFontWeight('bold');	
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#7bb193');
                            });

                            $sheet->mergeCells('C2:D2');
                            $sheet->mergeCells('E2:F2');
                            $sheet->cells('A2:A2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('B2:C2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('D2:D2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->cells('E2:F2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b5cabe');
                            });
                            $sheet->row(2, array( 'Chapter','','Table','','Equations'));
                            $sheet->cells('A3:F3', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#bada87');
                            });
                            $sheet->row(3, array( 'Chapter','Total (MS) Pages', 
                                                                            'Tables','Unnumbered Tables','Equations', 
                                                                            'No.of Equations'));
                            $t 		= 	4;
                            if(count($parreports)>=1)
                            {
                                    foreach($parreports as $key=>$parvalue)
                                    {
                                            $sheet->cells("A".$t.":F".$t,function($row)
                                            {
                                                    $row->setFontFamily('Arial');
                                                    $row->setFontSize(10);	
                                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                    $row->setAlignment('center');
                                                    $row->setValignment('center');
                                            });	
                                            $sheet->row($t, array(
                                                                                    $parvalue->CHAPTER_NO,
                                                                                    $parvalue->NO_MSP,
                                                                                    $parvalue->NO_TABLES,
                                                                                    $parvalue->NO_TABLES_UNNUMBERED,
                                                                                    $parvalue->NO_EQUATION,
                                                                                    $parvalue->NO_EQUATION_UNNUMBERED
                                                            ));

                                            $t++;
                                    }
                                    $t 		=	$t-1;
                                    $range 	= 	"F1:F".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('', 'thin', 'thin', '');
                                                            });
                                    $range 	= 	"A3:A".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"B3:B".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"C3:C".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"D3:D".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"E3:E".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                                    $range 	= 	"F3:F".$t;
                                                            $sheet->cells($range, function($cells) {
                                                                      $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                                            });
                            }					
                    });			

            })->download('xlsx');
        }
        return response()->json($this->notfoundResponse);
    }     
    
    //redo view 
    public function getworkflowname(Request $request){
        $validation = Validator::make($request->all(), [
                    'jobId' => 'required|numeric'
        ]);
        $response   =   $this->notfoundResponse;                                   
        if ($validation->fails()) {
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            return response()->json($response);
        }
        
        $jobID = $request->input('jobId');
        $bookdata   =   jobModel::select(DB::raw('job_info.WORKFLOW_TYPE,pal.LOCATION_NAME as LOCATIONJOBINFO,pal1.LOCATION_NAME as JOBLOCATION'))
                                           ->join(  'job_info'   ,  'job.JOB_ID' , '=' , 'job_info.JOB_ID' )
                                            ->leftjoin( 'production_area_location as pal' , 'pal.ID', '=', 'job_info.TAPS_LOCATION' ) 
->leftjoin( 'production_area_location as pal1' , 'pal1.ID', '=', 'job_info.LOCATION' )											
                                           ->where( 'job.JOB_ID' ,  $jobID)
                                           ->first();
        if($bookdata != null){
            if (empty($bookdata->WORKFLOW_TYPE)) {
                $response['errMsg']     =   'Workflow is not configured';
                return response()->json($response);
            }
            $getworkflowname    =   workflowMasterModel::where(['WORKFLOW_MASTER_ID'=>$bookdata->WORKFLOW_TYPE])->first();
            
            if($getworkflowname !=  null){
                $response       =   $this->successResponse;
                $response['errMsg']     =   $getworkflowname->WORKFLOW_MASTER_NAME;
                $response['locationname']   =   (empty($bookdata->LOCATIONJOBINFO)?$bookdata->JOBLOCATION:$bookdata->LOCATIONJOBINFO);
                return response()->json($response);
            }
            $response['errMsg']     =   'Invalid Workflow';
            return response()->json($response);
        }
        $response['errMsg']     =   'Invalid Job';
        return response()->json($response);
    }
	
	public function downloadRedo($jobId,$roundId,$metaid='',Request $request){
		
		if(empty($jobId) || empty($roundId) ){
			
			return false;
		}
	
		$getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
		 $getuserid         =   	Session::get('users')['emp_id'];
       
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
          										
			$ftpObj             =       new ftpFileHandlerController($hostserver,$hostusername,$hostpassword);
			$cid				=	'';							
			$rounname			=	\Config::get('constants.ROUND_NAME'); 
			if($metaid == ''){
				$serverDir      =   \Config::get('constants.SUCCESSREDO_DOWNLOAD_PATH'); 
				$jsDir      	=   \Config::get('constants.JOBSHEET_LOCATION_PATH').'RECEIPT/'; 
			}else{
				$serverDir      =    \Config::get('constants.SUCCESSREDO_CHAPTER_DOWNLOAD_PATH'); 
				$jsDir      	=   \Config::get('constants.CHAPTER_JOBSHEET_LOCATION_PATH').'RECEIPT/'; 
				
				$metadetails	=	new taskLevelMetadataModel();
				$metainfoDetails = $metadetails->getMetadatadetailsChapterwithjob($metaid);
				$cid			=	$metainfoDetails->CHAPTER_NO;
			
			}
			 $crd                =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
			$jobObj				=	new jobModel();
			$jobDetails			= 	$jobObj->getJobdetails($jobId);
			
			
			$inp_rep_arr    =   array( 
                                        'BOOK_ID'       =>      $jobDetails->BOOK_ID , 
                                        'ROUND_NAME'    =>      $rounname[$roundId] ,
                                        '{CID}'         =>      $cid , 
										'{EMPID}'       =>    	$getuserid, 
                                        '{BID}'         =>      $jobDetails->BOOK_ID, 
                                        '{RID}'         =>      $rounname[$roundId] ,
                                 
                                );
            $cmn_obj            =       new CommonMethodsController();
            $serverDir          =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
			
			$jsPath          	=       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jsDir );
			$fileExtension[]  = '.xml';
			$getinputchapters = array();
			$rootFolder			=	 $serverDir;
		
			$response			=	$ftpObj->ftp_make_dir($rootFolder);
			//echo $crd.$hostserver.'/'.$jsPath;exit;
			$response2 			=	$ftpObj->ftp_dir_copy_word_file_only( $crd.$hostserver.'/'.$jsPath, $hostserver.'/'.$serverDir,$getinputchapters,$fileExtension );
			$response					=		array();
			if(in_array('failed',$response2) || empty ($response2)){
				$response['status']         =   '0';
					$response['Msg']            =   'Failed';
					$response['errMsg']         =   'Not able to copy JS file';
					
			}else{
		
				$ftserverrootpath  			=	Config::get('constants.FILE_SERVER_ROOT_DIR'); 
				$postdata                   =    [];
				
				$postdata['file_path']      =       $hostserver.$ftserverrootpath.$serverDir.'/<>'.$hostusername.'<>'.$hostpassword;
				$postdata['system_ip']      =     $request->ip();
				$postdata['method_name']    =       "doOpenDriveServer";
				$postdata['processname']    =       "checkout";
				
				$insertfilehandler          =       fileHandler::insertNew($postdata);   
			    
				if( $insertfilehandler ){
			
					$response['status']         =   '1';
					$response['Msg']            =   'Success';
					$response['errMsg']         =   'File open initialized..';
					$response['rmiId']          =   $insertfilehandler;
					
				}
          
			}

			 return response()->json( $response );
	}	
	
	public function redojsRetry($jobId,$roundId,$metaid='',Request $request){
		if(empty($jobId) || empty($roundId) ){
			
			return false;
		}
	
		$getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
		 $getuserid         =   	Session::get('users')['emp_id'];
       
        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $filedir            =       str_replace( $getlocationftp->FTP_PATH ,  ''  , $getlocationftp->FILE_SERVER_PATH ); 
           
          										
			$ftpObj             =       new ftpFileHandlerController($hostserver,$hostusername,$hostpassword);
			$cid				=	'';								
			$rounname			=	\Config::get('constants.ROUND_NAME'); 
			if($metaid == ''){
				$serverDir      =   \Config::get('constants.SUCCESSREDO_DOWNLOAD_PATH'); 
				$jsDir      	=   \Config::get('constants.JOBSHEET_LOCATION_PATH'); 
			}else{
				
				$serverDir      =    \Config::get('constants.SUCCESSREDO_CHAPTER_DOWNLOAD_PATH'); 
				$jsDir      	=   \Config::get('constants.CHAPTER_JOBSHEET_LOCATION_PATH'); 
				
				$metadetails	=	new taskLevelMetadataModel();
				$metainfoDetails = $metadetails->getMetadatadetailsChapterwithjob($metaid);
				$cid			=	$metainfoDetails->CHAPTER_NO;
				
			}
			
			$jsDir  = $jsDir.'RECEIPT/';
			
			 $crd                =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
			$jobObj				=	new jobModel();
			$jobDetails			= 	$jobObj->getJobdetails($jobId);
			
			
			$inp_rep_arr    =   array( 
                                        'BOOK_ID'       =>      $jobDetails->BOOK_ID , 
                                        'ROUND_NAME'    =>      $rounname[$roundId] ,
                                        '{CID}'         =>      $cid , 
										'{EMPID}'       =>    	$getuserid, 
                                        '{BID}'         =>      $jobDetails->BOOK_ID, 
                                        '{RID}'         =>      $rounname[$roundId] ,
                                 
                                );
			$fileExtension[]  = '.xml';
			$getinputchapters = array();
            $cmn_obj            =       new CommonMethodsController();
            $serverDir          =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
			
			$jsPath          	=       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jsDir );
			
			$response2 			=	$ftpObj->ftp_dir_copy_word_file_only( $crd.$hostserver.'/'.$serverDir, $hostserver.'/'.$jsPath,$getinputchapters,$fileExtension );
			$response					=		array();
			if(in_array('failed',$response2) || empty ($response2)){
				$response['status']         =   '0';
				$response['Msg']            =   'Failed';
				$response['errMsg']         =   'Updated Js not found in working directory';
				
			}else{
				$ftserverrootpath  			=	Config::get('constants.FILE_SERVER_ROOT_DIR'); 
				$postdata                   =    [];
				
				$postdata['file_path']      =       $hostserver.$ftserverrootpath.$serverDir.'/<>'.$hostusername.'<>'.$hostpassword;
				$postdata['system_ip']      =     $request->ip();
				$postdata['method_name']    =       "deleteFileServer";
				$postdata['processname']    =       "deleteFileServer";
				
				$insertfilehandler          =       fileHandler::insertNew($postdata);   
			 			
				$response['status']         =   '1';
				$response['Msg']            =   'Success';
				$response['errMsg']         =   'Updated Js is moved success fully initialized..';
				
			}
			
			 return response()->json( $response );
			
	}
}