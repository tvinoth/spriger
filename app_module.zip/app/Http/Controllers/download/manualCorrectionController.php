<?php
/*Chapter download method start line from 500*/
namespace App\Http\Controllers\download;
use App\Http\Controllers\Controller;
use App\Models\downloadModel;
use App\Models\checkItemsModel;
use App\Models\productionLocationModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiClientAcknowledgement;
use App\Models\jobsheetViewpathModel;
use App\Models\jobModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\filemovementController;
use App\Http\Controllers\Api\clientAcknowledgementController;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Models\projectModel;
use Session;
use Excel;
use Storage;
use Validator;
use Config;
use DB; 
use Mail;
use Illuminate\Support\Facades\Crypt;

use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\workflowServerMapPathModel;
use App\Models\ManualFileCorrection as ManualFileCorrectionModel;
use File;
use App\Http\Controllers\production\movetoproductionController;
ini_set( 'max_execution_time' , 0 );
class manualCorrectionController extends Controller
{
	
	protected $moveToProdController;
	
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    public function __construct(movetoproductionController $moveToProdController)
    {  
        parent::__construct();
       if(Session::has('users')==''){
           return redirect('/');
       }
	   $this->moveToProdController = $moveToProdController;
    }
       
    public function getAllChapters(Request $request){
		$validator = Validator::make($request->all(), [
				"jobId" => "required|min:1",
				"roundid" => "required|min:1"
            ]);
        
		if ($validator->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
		} else {
                
            try {
				$jobId = $request->input('jobId');
				$roundid = $request->input('roundid');
				
				$getTaskLevelMetadataQuery = DB::table( 'task_level_metadata as tlm' )
                    ->where( 'tlm.JOB_ID' , '=' , $jobId )
                    //->where( 'tluw.ROUND' , '=' , $roundid )
                    ->where( 'tlm.IS_ACTIVE',  '=' , 1 )
                    ->select(array('tlm.CHAPTER_NO', 'tlm.CHAPTER_NAME', 'tlm.METADATA_ID'))
                    ->orderByRaw("tlm.CHAPTER_NO ASC");

				$getTaskLevelMetadataQueryCnt = $getTaskLevelMetadataQuery->count();
				$getTaskLevelMetadataQueryData = $getTaskLevelMetadataQuery->get();
				
				$chapterList = array();	
				if($getTaskLevelMetadataQueryCnt > 0){					
					foreach($getTaskLevelMetadataQueryData as $key => $data){
						$getChapterRow = array();
						$getChapterRow['METADATA_ID'] = $data->METADATA_ID;
						$getChapterRow['CHAPTER_NO'] = $data->CHAPTER_NO;
						$getChapterRow['CHAPTER_NAME'] = $data->CHAPTER_NAME;
						$getChapterRow['Selected'] = false;
						$chapterList[] = $getChapterRow;
					}
				}
				$response   =   $this->successResponse;
				$response['data'] = $chapterList;
				$response['jobId']  = $request->input('jobId');
				$response['roundid']  = $request->input('roundid');
			} catch (\Exception $e) {
                        $response['errMsg']     =   $e->getMessage();
			}
		}  
		return response()->json($response);
	}
	
	
	public function getProcessList(Request $request)
    {
		$response   =   $this->oopsErrorResponse;
		$validator = Validator::make($request->all(), [
			"jobId" => "required|min:1",
			"roundid" => "required|min:1"
        ]);
        
		if ($validator->fails()) {
                    $response   =   $this->validationResponse;
                    $response['validation']     =   $validation->errors();
		} else {
                
            try {
				$jobId = $request->input('jobId');
				$roundid = $request->input('roundid');
                                $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
                             
                                $hostserver         =       $getlocationftp['HOST'];
                                $fileServerPath     =       $getlocationftp['FILE_SERVER_PATH'];
                                $fileCredential     =       $getlocationftp['FILE_SERVER_USER_NAME'].'<>'.$getlocationftp['FILE_SERVER_PASSWORD'];
                                $filePath           =       $fileServerPath.\Config::get('constants.CORRECTTION_FILE_SOURCE_PATH');
                                $ftpfilePath        =       $getlocationftp['SERVER_PATH'].\Config::get('constants.CORRECTTION_FILE_SOURCE_PATH');
                                $jobDetails         =       jobModel::getJobdetailsRawQuery($jobId,'job_info.WORKFLOW_TYPE');
                                
                                $workflowId         =       \Config::get( 'constants.WORKFLOW.S300.MASTER_ID_ERR' );
                                $jobDetails['WORKFLOW_TYPE']  = $workflowId;
                               
                                if(empty($jobDetails['WORKFLOW_TYPE'])){
					$response['errMsg']     =   'Workflow not mapped to this job. Kindly assign and continue the process';
					return response()->json($response);
				}
			  
				$workflowMaster = DB::table('workflow')
									->where('WORKFLOW_MASTER_ID', '=', $jobDetails['WORKFLOW_TYPE'])
									->where('WORKFLOW_TYPE', '=', '0')
									->select(DB::raw('workflow.*'))
									->get();
				$workflowRec    =   $workflowMaster['0'];       
                                	
				$wftype     = 0;
				$wfid       = $workflowRec->WORKFLOW_ID;
				$wfMid      = $workflowRec->WORKFLOW_MASTER_ID;
				//DB::enableQueryLog();
					
				$getStageDetailsQuery = DB::table( 'task_level_userdefined_workflow as tluw' )
                                    ->join('workflow_master as wm' ,  'wm.WORKFLOW_MASTER_ID' , '=' , 'tluw.WORKFLOW_MASTER_ID' )
                                    ->join('workflow as wf' ,  'wf.WORKFLOW_ID' , '=' , 'tluw.WORKFLOW' )
                                    ->join( 'round_enum as re' , 're.ID' , '=' , 'tluw.ROUND' )
                                    ->join( 'stage as stg' , 'stg.STAGE_ID' , '=' , 'tluw.STAGE' )
                                    ->where( 'tluw.JOB_ID' , '=' , $jobId )
                                    ->where( 'tluw.ROUND' , '=' , $roundid )
                                    ->where( 'tluw.WORKFLOW_TYPE' , '=' , $wftype )
                                    ->where( 'tluw.WORKFLOW' , '=' , $wfid )
                                    ->where( 'tluw.IS_AUTO' , '=' , $wftype )
                                    ->where( 'tluw.WORKFLOW_MASTER_ID',  '=' , $wfMid )
                                    ->select(array('stg.STAGE_ID', 'stg.STAGE_NAME', 'wf.WORKFLOW_ID', 'tluw.WORKFLOW_TYPE', 'tluw.WORKFLOW_MASTER_ID'))
                                    ->orderByRaw("tluw.STAGE_SEQ ASC");

				$getStageDetailsQueryCnt = $getStageDetailsQuery->count();
				$getStageDetailsQueryData = $getStageDetailsQuery->get();
				//$queryChk = DB::getQueryLog();
				//print_r($queryChk);die;
				$srcType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.SRC_TYPE' );
				$wrkType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.WRK_TYPE' );
				$destType       =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.DEST_TYPE' );	
											
				$stageList = array();	
				if($getStageDetailsQueryCnt > 0){					
					foreach($getStageDetailsQueryData as $key => $data){
						$getStageRow = array();
						$getStageRow['StageId'] = $data->STAGE_ID;
						$getStageRow['StageDescription'] = $data->STAGE_NAME;
						$getStageRow['WORKFLOW_ID'] = $data->WORKFLOW_ID;
						$getStageRow['WORKFLOW_TYPE'] = $data->WORKFLOW_TYPE;
						$getStageRow['WORKFLOW_MASTER_ID'] = $data->WORKFLOW_MASTER_ID;
						
						$stageList[] =   $getStageRow;						 
					}
				}	
				
					
				$response   =   $this->successResponse;
				$response['data'] = $stageList;
				$response['jobId']  = $request->input('jobId');
				$response['roundid']  = $request->input('roundid');
				$userid = Session::get('users')['emp_id'];
				$response['userid']  = $userid;
				//$Response['path']  = Config::get('constants.CORRECTTION_FILE_SOURCE_PATH')."<>".Config::get('constants.FILE_SERVER_USER_NAME')."<>".Config::get('constants.FILE_SERVER_PASSWORD');
				$response['path']  = $filePath;
                                $response['ftpfilePath'] = $ftpfilePath;
                                $response['credential']  = $fileCredential;
				
				
			} catch (\Exception $e) {
                            $response['errMsg']     =   $e->getMessage();
			}
		}  
		return response()->json($response);
	}
	
	public function subArraysToString($ar, $sep = ', ') {
		$str = '';
		foreach ($ar as $val) {
			$str .= implode($sep, $val);
			$str .= $sep; // add separator between sub-arrays
		}
		$str = rtrim($str, $sep); // remove last separator
		return $str;
	}
	
	public function correctionFileUpload(Request $request)
    {
		//DB::beginTransaction();
		
                $response   =   $this->failedResponse;
		$method = $request->method();
		if ($request->isMethod('post')) {
			$getAllRequest = $request->all();
                       
			$validationArr = array(					
				"correctionRoundId" => "required|min:1",
				"correctionRoundName" => "required|min:1",	
				
				"correctionStageId" => "required|min:1",
				"correctionStageName" => "required|min:1",
				
				"correctionBookId" => "required|min:1",
				"correctionJobId" => "required|min:1",				
				
				"correctionWorkflowId" => "required|min:1",
				"correctionWorkflowMasterId" => "required|min:1",
				"correctionWorkflowType" => "required|min:1",			
				
				"correctionMappingID" => "required|min:1",
				
				
			);
			
			$dateTime = date('Y-m-d H:i:s');
			$loginUserId = Session::get('users')['emp_id'];
			if(isset($getAllRequest['titleWise']) && $getAllRequest['titleWise'] === "false" && isset($getAllRequest['chapterWise']) && $getAllRequest['chapterWise'] === "true"){
				$validationArr["correctionMetadataId"] = "required|min:1";	
				//$validationArr["correctionChapterNo"] = "required|min:1";								
				$validationArr["correctionChapterTitle"] = "required|min:1";					
			}
                        
                        if($getAllRequest['correctionMappingID'] == 'SetProcess'){
                            
                        }else{
                            $validationArr["correctionSourceFolderPath"] = "required|min:1";
                        }
			
			$validator = Validator::make($request->all(), $validationArr);			
        
			if ($validator->fails()) {
                              //$response           =   $this->validationResponse;
                            $response['status']         = 1;//400
                            $response['validation']     =   $validator->errors();
			} else {               
                try {
                    
					$roundId = $request->input('correctionRoundId');
					$roundName = $request->input('correctionRoundName');
					$stageId = $request->input('correctionStageId');
					$stageName = $request->input('correctionStageName');
					$bookId = $request->input('correctionBookId');
					$jobId = $request->input('correctionJobId');
					$workflowId = $request->input('correctionWorkflowId');
					$workflowMasterId = $request->input('correctionWorkflowMasterId');
					$workflowType = $request->input('correctionWorkflowType');
					$mappingID = $request->input('correctionMappingID');
					$sourceFolderPath = $request->input('correctionSourceFolderPath');
                                        $metaid           = $request->input('correctionMetadataId');
                                      
					$duedate = date('Y-m-d', strtotime("+7 day", strtotime(date('Y-m-d'))));
                                        
                                        $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
                                       
					$quantity = 10;					
                                        $wtyp = 0;
                                        
                                        if($mappingID === "ProcessMapping"){
                                            
                                            $eproofresponse['TextCorrection']['NumberOfCorrections']    = 1;
                                            $eproofresponse['ImageCorrection']   = 0;
                                            $eproofresponse['IndexCorrection']   = 0;
                                            $eproofresponse['NumberOfAuthorQueries'] = 1;
                                            
                                            $eproofr        =   (object)$eproofresponse;
                                           
                                            $clientAckObj       =   new clientAcknowledgementController();
                                            $response           =   array();
                                            
                                            $whereCondi         =    array( 'ROUND_ID' => $roundId,'METADATA_ID' => $metaid);
                                            $roundDetails       =    DB::table( 'job_round' )->select()->where( $whereCondi )->get()->toArray();
                                            
                                            if(empty($roundDetails)){
                                                $resp           =   $clientAckObj->correctionWorkflowMovetoProduction($jobId , $metaid , $roundId , $eproofr , $response);
                                            }                                             
                                        }
                                        
                                        if($mappingID === "SetProcess"){
                                            $whereCondi         =    array( 'ROUND_ID' => $roundId,'METADATA_ID' => $metaid);
                                            $roundDetails       =    DB::table( 'job_round' )->select()->where( $whereCondi )->get()->toArray();
                                            if(!empty($roundDetails)){
                                                
                                                $tableRoundId       =   $roundDetails['0']->JOB_ROUND_ID;
                                                $currentIteration   =   $roundDetails['0']->CURRENT_ITERATION_ID;
                                                
                                                $updateStageParam       =   array( 'STATUS'=>'25');
                                                $updateQry              =   DB::table('job_stage')
                                                                            ->where('JOB_ROUND_ID', $tableRoundId )
                                                                            ->where('ITERATION_ID', $currentIteration )
                                                                            ->update( $updateStageParam );
                                                
                                                $updateStageParam1       =   array('STATUS'=>'27');
                                                $updateQry2              =   DB::table('job_stage')
                                                                            ->where('JOB_ROUND_ID', $tableRoundId )
                                                                            ->where('ITERATION_ID', $currentIteration )
                                                                            ->where('STAGE_ID', $stageId )
                                                                            ->update( $updateStageParam1 );
                                                
                                                $updateStageParam3       =   array( 'CURRENT_STAGE'=>$stageId,'STATUS'=>'27');
                                                $updateQry3             =   DB::table('job_round')
                                                                            ->where('JOB_ROUND_ID', $tableRoundId )
                                                                            ->update( $updateStageParam3 );
                                               $response['status'] = 1;
                                               $response['msg']    = "Success";
                                               $response['errMsg'] = "Successfully process has changed.";
                                            }else{
                                               $response['status'] = 0;
                                               $response['msg']    = "Failed";
                                               $response['errMsg'] = " Move to production not done/File linking not done for this process"; 
                                            }
                                            
                                           return response()->json($response); 
                                            
                                        }
                                        
					
					$getFolderPathIp = Config::get('constants.CORRECTION_FILE_UPLOAD_IP');
					$getDefaultSourceFolderPath = Config::get('constants.CORRECTTION_FILE_SOURCE_PATH');//."<>".Config::get('constants.FILE_SERVER_USER_NAME')."<>".Config::get('constants.FILE_SERVER_PASSWORD');					
					
					$getDefDestinationFolderPath = Config::get('constants.CORRECTTION_FILE_DESTINATION_PATH').'<referenceTag>';//."<>".Config::get('constants.FILE_SERVER_USER_NAME')."<>".Config::get('constants.FILE_SERVER_PASSWORD');
					//$getDefaultDestinationFolderPath = str_replace("172.24.191.59/e/ftp/SP_BOOKS" , "Y:/ftp/SP_BOOKS", $getDefDestinationFolderPath);
					$getDefaultDestinationFolderPath = $getDefDestinationFolderPath;
                                        
					$splitChapter = explode("<##>", $sourceFolderPath);
					array_pop($splitChapter);
					if(count($splitChapter) > 0){
						$TotalChapterCount = count($splitChapter);
						$success = 0;
						$error = 0;
						foreach($splitChapter as $val){
							$splitChapterNoAndMetadata = explode("<#>", $val);
							
							$metaDataId = $splitChapterNoAndMetadata[0];
							$chapterNo = $splitChapterNoAndMetadata[1];							
                                                        
							if($mappingID === "ProcessMapping"){
                                                                $whereprocmappingpath   =   ['WORKFLOW_MASTER_ID'=>$workflowMasterId,'WORKFLOW_ID'=>$workflowId,'JOB_ID'=>$jobId,'ROUND_ID'=>$roundId,'STAGE_ID'=>$stageId,'FOLDER_TYPE'=>6];
                                                                $getdestwrkservermapapth    =   workflowServerMapPathModel::where($whereprocmappingpath)->first();
                                                                if($getdestwrkservermapapth !=  null){
                                                                    $inp_rep_arr    =   array( 
                                                                                                '{BID}'     =>  $bookId , 
                                                                                                '{RID}'     =>  $roundName,
                                                                                                '{CID}'     =>  $chapterNo

                                                                                             );
                                                                    $cmn_obj        =   new CommonMethodsController();
                                                                    $getDefaultDestinationFolderPath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $getdestwrkservermapapth->FOLDER_PATH );
                                                                }          
                                                                
								$getSFPath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/".$chapterNo, $getDefaultSourceFolderPath);
								$deletePath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/", $getDefaultSourceFolderPath);
                                                                $getDFPath = $getlocationftp['FTP_PATH'].$getDefaultDestinationFolderPath;
							
                                                        }else if($mappingID === "BookReference"){
								$getSFPath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/REFERENCE", $getDefaultSourceFolderPath);
                                                                $deletePath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/", $getDefaultSourceFolderPath);
								$getDFPath = str_replace("<referenceTag>", $bookId."/".$roundName."/"."REFERENCE", $getDefaultDestinationFolderPath);
							}else if($mappingID === "ChapterReference"){
								$getSFPath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/".$chapterNo."/REFERENCE", $getDefaultSourceFolderPath);
								$deletePath = str_replace("<referenceTag>", $loginUserId."/".$bookId."/", $getDefaultSourceFolderPath);
                                                                $getDFPath = str_replace("<referenceTag>", $bookId."/".$roundName."/".$chapterNo."/REFERENCE", $getDefaultDestinationFolderPath);
							}
                                                        
                            $deletePath     =   $getlocationftp['FILE_SERVER_PATH'].$deletePath.'<>'.$getlocationftp['FILE_SERVER_USER_NAME'].'<>'.$getlocationftp['FILE_SERVER_PASSWORD'];
							$closePath 		=	current(explode($bookId,rtrim($deletePath,"/")));
							$closePath 		=	$closePath.'<>'.$getlocationftp['FILE_SERVER_USER_NAME'].'<>'.$getlocationftp['FILE_SERVER_PASSWORD'];
							
                                                        $getSFPath      =   $getlocationftp['SERVER_PATH'].$getSFPath;
                                                        $getDFPath      =   $getlocationftp['HOST'].'/'.$getDFPath;
							$finalSourceFolderPath      = str_replace("\\", "/", $getSFPath);
							$finalDestinationFolderPath = str_replace("\\", "/", $getDFPath);							
							if(isset($getAllRequest['titleWise']) && $getAllRequest['titleWise'] === "true" && isset($getAllRequest['chapterWise']) && $getAllRequest['chapterWise'] === "false"){
								$type = 'Title';
								$chapterTile = $chapterNo;
							}else if(isset($getAllRequest['titleWise']) && $getAllRequest['titleWise'] === "false" && isset($getAllRequest['chapterWise']) && $getAllRequest['chapterWise'] === "true"){
								$type = 'Chapter';
								$chapterTile = $request->input('correctionChapterTitle');
							}
							
							$userid = Session::get('users')['user_id'];				
				
							$correctionFileUpload = new ManualFileCorrectionModel\CorrectionFileUploadModel();
							$correctionFileUpload->TYPE = $type;
							$correctionFileUpload->MAPPINGTYPE = $mappingID;
							$correctionFileUpload->BOOK_ID = $bookId;
							$correctionFileUpload->JOB_ID = $jobId;
							$correctionFileUpload->ROUND_ID = $roundId;
							$correctionFileUpload->ROUND_NAME = $roundName;
							$correctionFileUpload->STAGE_ID = $stageId;
							$correctionFileUpload->STAGE_NAME = $stageName;
							$correctionFileUpload->WORKFLOW_ID = $workflowId;
							$correctionFileUpload->WORKFLOW_MASTER_ID = $workflowMasterId;
							$correctionFileUpload->WORKFLOW_TYPE = $workflowType;
							$correctionFileUpload->CREATED_BY = $loginUserId;
							$correctionFileUpload->CREATED_DATE = $dateTime;
							$correctionFileUpload->save();
							$correctionFileUploadId = $correctionFileUpload->UPLOAD_ID;
							
							$correctionUploadChapter = new ManualFileCorrectionModel\CorrectionUploadChapterModel();
							$correctionUploadChapter->UPLOAD_ID = $correctionFileUploadId;
							$correctionUploadChapter->CHAPTER_NO = $chapterNo;
							$correctionUploadChapter->CHAPTER_TITLE = $chapterTile;
							$correctionUploadChapter->CREATED_BY = $loginUserId;
							$correctionUploadChapter->CREATED_DATE = $dateTime;
							$correctionUploadChapter->save();
							$correctionUploadChapterId = $correctionUploadChapter->UPLOAD_CHAPTER_ID;
							
							$apiParams = array();
							$apiParams['tokenKey'] = "aW1qHacErLrFquQfjoAuVIO0cWnlKNXM5LDhXjLi";
							
                                                        $apiParams['data'] = array(
								"srcPath" => $finalSourceFolderPath,
								"destPath" => $finalDestinationFolderPath,
								"isDelete" => "NO", 
								"extension" => "NA"
							);
                                                        //echo $getlocationftp['FTP_PATH_CREDENTIAL'].$finalSourceFolderPath ; echo $finalDestinationFolderPath;exit;
                                                        //echo "<pre>";print_r($getlocationftp);exit;
                                                        $ftpestablishconnection =   new ftpFileHandlerController($getlocationftp['HOST'], $getlocationftp['FTP_USERNAME'], $getlocationftp['FTP_PASSWORD']);
                                                        $resp                   =   $ftpestablishconnection->ftp_dir_copy( $getlocationftp['FTP_PATH_CREDENTIAL'].$finalSourceFolderPath , $finalDestinationFolderPath);
                                                       	
                                                       
                                                        if( in_array( 'failed' , $resp ) && false){

                                                            foreach($resp as $key => $value ){
                                                                if( $value == 'success' ){
                                                                    unset( $resp[$key] );
                                                                }
                                                            }
                                                            $response   =       array( 'status' => '0'  ,'errMsg'=> (isset($resp['errMsg'])?$resp['errMsg']:'Failed to move file'),'msg'=> (isset($resp['errMsg'])?$resp['errMsg']:'Failed to move file' ));
                                                            return response()->json($response);
                                                        }else{
                                                            $resp['status']  =   'success';
                                                            $resp['msg']     =   'Moved';
                                                        }	
                                                        
							$updateRemarks = '';
							$updateCorrectionFileUpload = ManualFileCorrectionModel\CorrectionFileUploadModel::find($correctionFileUploadId);
							
                                                        if(isset($resp['status']) && $resp['status'] == "success"){
								$updateRemarks .= "File movement status: ".$resp['status']."(".$resp['msg'].")";
								
								if(isset($resp['data']) && isset($resp['data']->processId)){
									$updateCorrectionFileUpload->PROCESS_ID = $resp['data']->processId;
								}//http_code
								
								if($mappingID === "ProcessMapping"){
									$getMoveToProdController = new movetoproductionController();
									//$getrespMoveToProd = $getMoveToProdController->taskLevelMoveToProductionProcedure($jobId , $roundId , $workflowId , $metaDataId , $quantity , $duedate , $wtyp , $userid);		
									//$respMoveToProd = $getrespMoveToProd->getData();
                                                                        
                                                                        $response['status'] = 1;
									$response['msg'] = "Success";
                                                                        $response['errMsg'] = "Successfully chapter moved to production.";
                                                                        return response()->json($response);
                                                                        
									if(isset($respMoveToProd->status) && $respMoveToProd->status == 0 && false){
										$response['status'] = 0;
										$response['msg'] = $respMoveToProd->msg;
										if(is_array($respMoveToProd->errMsg)){
											$response['errMsg'] = $respMoveToProd->errMsg[0]->errmsg;
											$updateRemarks .= "Move to production status: ".$respMoveToProd->msg."(".$respMoveToProd->errMsg[0]->errmsg.")";
										}else{
											$response['errMsg'] = $respMoveToProd->errMsg;							
											$updateRemarks .= "Move to production status: ".$respMoveToProd->msg."(".$respMoveToProd->errMsg.")";
										}	
										$error++;
									}else if(isset($respMoveToProd->status) && $respMoveToProd->status == 1){
										$success++;
										$response['status'] = 1;
										$response['msg'] = "Successfully chapter moved to production.";
                                                                                $respMoveToProd->errMsg = '';
										if(is_array($respMoveToProd->errMsg)){
											$response['errMsg'] = $respMoveToProd->errMsg[0]->errmsg;
											$updateRemarks .= "Move to production status: ".$respMoveToProd->msg."(".$respMoveToProd->errMsg[0]->errmsg.")";
										}else{
											$response['errMsg'] = $respMoveToProd->errMsg;							
											$updateRemarks .= "Move to production status: ".$respMoveToProd->msg."(".$respMoveToProd->errMsg.")";
										}							
									}
								}else{
									$success++;
									$response['status'] = 1;
									$response['msg'] = "Successfully upload correction file.";
								}								
							}							
							
							$updateCorrectionFileUpload->REMARKS = $updateCorrectionFileUpload->REMARKS . $updateRemarks;				
							$updateCorrectionFileUpload->LAST_MOD_BY = $loginUserId;
							$updateCorrectionFileUpload->LAST_MOD_DATE = $dateTime;
							$updateCorrectionFileUpload->save();
							
						}
						
						if($success == $TotalChapterCount){
                                                        //$deleteFile     =   new filemovementController();
                                                        //$deleteFile->deletefileinproduction($deletePath);
							$postdata['file_path']  =   $deletePath;
							$postdata['method_name']=   "deleteFileServer";
							$postdata['system_ip']  =   $request->ip();
							$postdata['processname']=   "deleteFileServer";
							$insertfilehandler      =   fileHandler::insertNew($postdata);
		
							$postdata['file_path']  =   $closePath;
							$postdata['method_name']=   "closeFolderServer";
							$postdata['system_ip']  =   $request->ip();
							$postdata['processname']=   "closeFolderServer";
							$insertfilehandler      =   fileHandler::insertNew($postdata);
                                                        
							$response   =   $this->successResponse;
							$response['errMsg']     =   'Successfully upload all correction files.';
						}else if($error == $TotalChapterCount){
                                                        $response['errMsg']     =   'All Chapter files are not uploaded.';
						}else{
							$response['errMsg'] = 'Some chapter files are not uploaded.';
						}
					}else{						
						$response['errMsg'] = 'Upload file path not found.';
					}				
					
				} catch (\Exception $e) {
                    $response['errMsg'] = $e->getMessage();
                }
			}
		} else {
			$response['errMsg'] = 'You are not allowed to perform this action';
        }
				
		/*if ($Response['Status'] == 1) {
			DB::rollback();            
        } else {
			DB::commit();
        } */     
		return response()->json($response);
	}
	
	public function PostcUrlExecution( $data  = array() , $curl = NULL ,$jsondecode=1){
        
        $comn_curl  =   '';//\Config::get('constants.WSDL_OF_METAEXTRACTOR');
        $url 		= 		( is_null( $curl ) ) ? $comn_curl  : $curl;	
		
		$returnArr 	=		array();
		
		if (!function_exists('curl_init')){
			
			$dataArr = array();
			$dataArr['status'] = 'failed';
			$dataArr['msg'] = 'Sorry cURL is not installed!';
			return $dataArr;
		}else{
			$curl = curl_init();
			
			if( !empty( $data ) ){
				$content		= 		json_encode( $data );			

				curl_setopt_array($curl, array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_ENCODING => "",
					CURLOPT_MAXREDIRS => 10,
					CURLOPT_TIMEOUT => 30,
					CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					CURLOPT_CUSTOMREQUEST => "POST",
					CURLOPT_POSTFIELDS => $content,
					CURLOPT_HTTPHEADER => array(
						"Cache-Control: no-cache",
						"Content-Type: application/json"
					),
				));
				
				$json_response = curl_exec( $curl );
				$status     = curl_getinfo( $curl , CURLINFO_HTTP_CODE );  
				//print_r($json_response);
				if($jsondecode == 1) {
					$json_response                   =       (array)json_decode( $json_response );
					$json_response['http_code']      =       $status;
				
					// Check for errors and display the error message       
					if( $status !== 200 ) {
						$errno = curl_errno( $curl );
						$error_message = curl_strerror($errno);
						$json_response['curl_err']     =    "http status code :  ({$status}), cURL error ({$errno}):\n {$error_message}";
						//$dataArr['status'] = 'failed';
						//$dataArr['msg'] = 'Sorry cURL is not installed!';
					}
				}
				
				curl_close( $curl );
				
				return $json_response;
			}else{
				curl_close( $curl );
				$dataArr = array();
				
				$dataArr['status'] = 'failed';
				$dataArr['msg'] = 'Post data is empty.';
				return $dataArr;
			}
        }
	}
   
   public function createWorkPath(Request $request){
       
        $ftpPath     =    $request->input('ftppath');
        $openPath    =    $request->input('openpath');
        $jobId       =    $request->input('jobID');
        $response       =   $this->failedResponse;
        $serverDetail =       productionLocationModel::getJobLocationServerPath( $jobId );
        $op           =    explode('USER-WORK',$openPath);
        $ft           =    explode('USER-WORK',$ftpPath);
		$root 	=	isset($ft['0'])?$ft['0']:'';
		$pathroot     =	isset($op['1'])?$op['1']:'';
        $workPath     =     $root.'USER-WORK'.$pathroot;
       
        $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['HOST'],$serverDetail['FTP_USERNAME'],$serverDetail['FTP_PASSWORD']);
            
        $destDirPath        =   str_ireplace($serverDetail['HOST'],'',$workPath);
        $directory          =   $fileHandlerObj->make_directory($destDirPath);
       
        if(!empty($directory))
            $response       =   $this->successResponse;
        
        return response()->json($response);
        
   }
   
   
}