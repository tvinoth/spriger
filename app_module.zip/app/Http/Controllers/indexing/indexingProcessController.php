<?php
namespace App\Http\Controllers\indexing;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\projectModel;
use App\Models\fileHandler;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\jobTimeSheet;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;

class indexingProcessController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function index()
    {
	$data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.INDEXING'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data["userId"]     =   $this->loginUserId;
        return view('indexing.indexing-index')->with($data);
    }
    
    public function getIndexinglist(Request $request,$jobID)
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.INDEXING'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $bookdata           =   jobModel::where('JOB_ID',$jobID)->first();
        $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
        $data['pageName']   =   'INDEXING - '.$bookid;
        $data['jobid']      =   $jobID;
        $data['backurl']        =   url('/').'/indexing-list';
        return view('indexing.indexing-checkout')->with($data);
    }
    
    public function getIndexingjoblist(Request $request)
    {
        $Req            =   (object) $request->input();
        $orderColumn    =   3; //created date column
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn=   $Req->order[0]['column'];
        }

        $sorting        =   'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting    =   $Req->order[0]['dir'];
        }
            
        $start  =   '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start      =   $Req->start;
        }

        $length     =   false;
        if (isset($Req->length) && $Req->length != -1) {
            $length =   $Req->length;
        }

        $searchStr  =   '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr  =   trim($Req->search['value']);
        }
        
        
        $data                   =   bookinfoModel::commonbookinfodetails($start,$length,$searchStr,$orderColumn,$sorting);
        $bookdata               =   array();
        if(isset($data['bookdetails']) && count($data['bookdetails'])>=1){
            foreach ($data['bookdetails'] as $row) {
                $tempArray      =   array();
                $tempArray['BOOK_ID']       =   $row->BOOK_ID;
                $showauthorname             =   ($row->AUTHOR_NAME   ==  ""?$row->EDITOR_NAME:$row->AUTHOR_NAME);
                $tempArray['JOB_TITLE']     =   '<span  class="pointer" ng-click="openchapterlistdetails('."'".$row->JOB_ID."'".')">'.$row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span></span>';
                $tempArray['PM_NAME']       =   $row->PM_NAME;
                $tempArray['CREATED_DATE']  =   $row->CREATED_DATE;
                array_push($bookdata, $tempArray);
            }
        }
            
        $Response                       =   array();
        $Response["draw"]               =   $Req->draw;
        $Response["recordsTotal"]       =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["recordsFiltered"]    =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["data"]               =   $bookdata;
        return response()->json($Response);
    }
    
    public function getjobChapterlist(Request $request)
    {
        $jobID                  =   $request->input('jodId');
        $response               =   [];
        $data                   =   taskLevelMetadataModel::getallIndexinglist($jobID);
        $response["cuclist"] 	=   $data;
        $response["user_id"] 	=   $this->loginUserId;
        return response()->json($response);
    }
    //check out process
    public function doIndexingCheckoutprocess(Request $request)
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $checkouttype       =   $request->input('checkouttype');
            $validation         =   Validator::make($request->all(), [
                                            'metadataid'=> 'required|numeric',
                                            'jobId' 	=> 'required|numeric',
                                            'Chapter' 	=> 'required',
                                            'bookid' 	=> 'required',
                                            'checkouttype'  =>  'required'
                                    ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response, 404);
            }
             
            $stagename          =   Config::get('constants.STAGE_NAME.INDEXING');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.INDEXING');      
            $roundid            =   Config::get('constants.ROUND_ID.S5');      
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            //check already exist have chapter or not
            $inp_array          =   array();
            $inp_arr['METADATA_ID']     =   $metaid;
            $inp_arr['ROUND_ID']        =   $roundid;  
            $inp_arr['STAGE']           =   $stageid;
            $getcurrentuserid 		=   $this->loginUserId;
            $jts_obj                    =   new jobTimeSheet();		
            $hasMetaid                  =   jobTimeSheet::where($inp_arr)->first();
			
            $inparray                   =   array();
            $inparray['METADATA_ID']    =   $metaid;
            $inparray['ROUND_ID']       =   $roundid;  
            $inparray['STAGE']          =   $stageid;
            $inparray['CREATED_BY']     =   $getcurrentuserid;
            $hasMyCheckoutentry         =   $jts_obj->hasChapterCheckedOutEntry($inparray);
            $hasMyCheckoutentryOfMe     =   $jts_obj->hasChapterCheckedOutOtherByMe($inparray);
            $hasOtherCheckoutentry      =   $jts_obj->hasOthersChapterCheckedOutEntry($inparray);


            if( count($hasOtherCheckoutentry) >= 1 && !empty( $hasOtherCheckoutentry ))
            {
                $response = array('result' => 401, 'errMsg' => 'Other User checkout this chapter. kindly refresh the page and proceed.');
                return response()->json($response);			
            }
				
            if( !empty( $hasMyCheckoutentryOfMe ))
            {
                $arrayinp                   =	[];
                $arrayinp['METADATA_ID']    =   (count($hasMyCheckoutentryOfMe)>=1?$hasMyCheckoutentryOfMe->METADATA_ID:'');
                $arrayinp['ROUND_ID']       =   $roundid;  
                $arrayinp['STAGE']          =   $stageid;
                $arrayinp['STATUS']         =   2;
                $arrayinp['CREATED_BY']     =   $getcurrentuserid;
                $checkexistcomplete         =	jobTimeSheet::where($arrayinp)->first();
                if(empty($checkexistcomplete))
                {
                    $getbookidexit          =   (count($hasMyCheckoutentryOfMe)>=1?$hasMyCheckoutentryOfMe->JOB_ID:'');

                    $bookdetails            =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                                                            ->where('job.JOB_ID',$getbookidexit)
                                                                            ->get()->first(); 	
                    //get chpter name       
                    $getchaptername         =   taskLevelMetadataModel::where('METADATA_ID',$arrayinp['METADATA_ID'])->first();   
                    $getcurrentchaptername  =   '';
                    if(count($getchaptername)>=1)
                    {
                        $getcurrentchaptername  =   $getchaptername->CHAPTER_NO;
                    }
                    $response = array('result' => 401, 'errMsg' => 'Kindly check-in the previous Chapter : ' . $bookdetails["BOOK_ID"] . ' - ' . $getcurrentchaptername);
                    return response()->json($response);
                }
            }
				
            if( !empty( $hasMyCheckoutentry )){

            }
            $response_copy      =   [];
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj         =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $userWork_for_const =   Config::get('serverconstants.USER_WORK_PATH');
                $serDir             =   Config::get('serverconstants.PRE_PROCESSING_PATH');
                $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                $alfreshcofullpath  =   "";
                $destinationpath    =   "";
                if($checkouttype    ==  "new")
                {
                    //CUC_CHECKOUT_FOLDER
                    
                    $splitround         =   Config::get('constants.STAGE_NAME.SPLIT'); 
                    $cucSourceCheckout  =   $hostpath.$serDir.$bookid.'/'.$splitround;
                    $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                    //get all files from ftp based on given folder name
                    $alfreshcofullpath  =   rtrim($ftp_root_dir,'/');
                    $alfreshcofullpath  =   $hostserver.$alfreshcofullpath.$cucSourceCheckout;
                    $cucDirFiles        =   $ftpObj->allFiles($cucSourceCheckout);
                    $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                    $currntfilename     =   '';
                    if(count($successfile) >= 1 && count($cucDirFiles) >= 1) 
                    {
                        $currntfilename     =   $successfile[0];
                        $sourcepath         =   $cucSourceCheckout.'/'.$currntfilename;
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        $open_path          =   str_replace( '//' , '/' , $open_path.'/'.$currntfilename);
                        $destinationpath    =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        $checkdirexistchapter   =   $ftpObj->has($destinationpath);
                        if(empty($checkdirexistchapter) && $checkdirexistchapter != 1){
                            $cucDirFiles    =   $ftpObj->makeDirectory($destinationpath,0777);
                        }
                        if($ftpObj->has($destinationpath.'/'.$currntfilename)){
                            $ftpObj->delete($destinationpath.'/'.$currntfilename);
                            $putfile    =	$ftpObj->copy($sourcepath,$destinationpath.'/'.$currntfilename,0777);
                        }
                        else{
                            $putfile    =	$ftpObj->copy($sourcepath,$destinationpath.'/'.$currntfilename,0777);
                        }
                        if($putfile !==     true){
                            $response['errMsg']     =   'File is not able to detect location try again';
                            return response()->json($response);
                        }
                    }
                    else{
                        $response['errMsg']     =   $Chapter . ' directory is not found...';
                        return response()->json($response);
                    }
                }
                else {
                    //move from temp to user user again checkout
                    $tempfolder         =   Config::get('serverconstants.TEMP_PATH');
                    $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$tempfolder.$stagename.'/'.$bookid.'/'.$Chapter;
                    $checkexistdirfile  =   $hostpath.$tempfolder.$stageid.'_'.$bookid.'_'.$Chapter;
                    $alfreshcofullpath  =   rtrim($ftp_root_dir,'/');
                    $alfreshcofullpath  =   $hostserver.$alfreshcofullpath.$checkexistdirfile;
                    $cucDirFiles        =   $ftpObj->allFiles($checkexistdirfile);
                    $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                    if(count($successfile) >= 1){
                        $destinationpath    =   $hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$userWork_for_const.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        $open_path          =   str_replace( '//' , '/' , $open_path.'/'.$successfile[0] );
                    }
                    if(count($cucDirFiles) == 0)
                    {
                        $cucSourceCheckout  =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;  
                        $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                        $destinationpath    =   $hostserver.$hostpath.$tempfolder.$stageid.'_'.$bookid.'_'.$Chapter;
                        $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        $alfreshcofullpath  =   rtrim($ftp_root_dir,'/');
                        $alfreshcofullpath  =   $hostserver.$alfreshcofullpath.$cucSourceCheckout;
                        $response_copy      =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                        $cucDirFiles        =   $ftpObj->allFiles($cucSourceCheckout);
                        $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$userWork_for_const.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        if(count($successfile) >= 1) 
                        {
                            $open_path      =   str_replace( '//' , '/' , $open_path.'/'.$successfile[0]  );
                        }else{
                            $response['errMsg']     =   $Chapter . ' directory is not found...';
                        return response()->json($response);
                        }
                    }
                    if(count($cucDirFiles) == 0)
                    {
                        $response['errMsg']     =   $Chapter . ' directory is not found...';
                        return response()->json($response);
                    }
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response_copy          =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                }
                
                if( in_array( 'failed' , $response_copy ) )
                {
                    foreach ($response_copy as $key => $value )
                    {
                        if($value == 'success' ){
                            unset( $response_copy[$key] );
                        }
                    }
                    $response           =   $response_copy;
                }else{
                    $response           =   $response_copy;
                }
                
                if( isset($response_copy['status']) && $response_copy['status'] != 'success' ){
                    $response['result']     =   401;
                    return response()->json($response);		
                }
                
                //alfresco request
                if(!empty($alfreshcofullpath)){
                    $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobId,$metaid,$roundid,$stageid,$alfreshcofullpath,'checkout');
                }
                        
                $postdata               =   [];
                $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                $postdata['system_ip']  =   $request->ip();
                $postdata['method_name']=   "doOpenDriveServer";
                $postdata['processname']=   "checkout";
                $insertfilehandler      =   fileHandler::insertNew($postdata);                    
//                $checkcomplete          =   $this->doCheckfilehasbeenopenornot($insertfilehandler);
//                sleep(6);
                if($insertfilehandler>=1)
                {
                    $jobtimedata                =   [];
                    $jobtimedata['JOB_ID']      =   $jobId; 
                    $jobtimedata['METADATA_ID'] =   $metaid;
//                    $jobtimedata['ROUND_ID']    =   Config::get('constants.ROUND_ID.CUC');
                    $jobtimedata['ROUND_ID']    =   $roundid;
                    $jobtimedata['STAGE']       =   $stageid;
                    $jobtimedata['TYPE']        =   1;
                    $jobtimedata['STATUS']      =   1;
                    $jobtimedata['CHECK_OUT']   =   Carbon::now();
                    $jobtimedata['CREATED_DATE']=   Carbon::now();
                    $jobtimedata['created_at']  =   Carbon::now();
                    $jobtimedata['updated_at']  =   Carbon::now();
                    $jobtimedata['CREATED_BY']  =   $this->loginUserId;
                    $timesheeid                 =   jobTimeSheet::doAddNewTime($jobtimedata);
                    $getrecords                 =   [];
                    if($timesheeid)
                    {
                        $getrecords             =   jobTimeSheet::getJimetimelastindexing($timesheeid);
                    }
                    $response   =   $this->insertedResponse;
                    $response['errMsg']     =   'Successfully checkout';
                    $response['records']    =   $getrecords;
                    $response['rmID']       =   $insertfilehandler;
                    return response()->json($response);
                }
                return response()->json($this->insertedFailedResponse);	
            }
            return response()->json($response);
	}
        catch( \Exception $e )
        {           
            $response['result']     =   500;
            $response['result']     =   $e->getLine();
            return response()->json($response);
        }
    }
	
    public function dogetdocumentfile($cucDirFiles,$Chapter)
    {
        $successfile        =   [];
        if(count($cucDirFiles)>=1) 
        {
            $readfileextenstion     =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
            foreach($cucDirFiles as $key=>$jsonvalue)
            {
                if(strpos($jsonvalue,'/') !== 	false)
                {
                    $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                    if(strpos($spiltchapter,'.') !== false)
                    {
                        $splitname          =   explode('.',$spiltchapter);
                        if(in_array(trim($splitname[1]),$readfileextenstion) && trim($splitname[0]) == $Chapter)
                        {
                            $successfile[]  =   $spiltchapter;
                        }
                    }
                }
            }
        }
        return $successfile;
    }
    
    public function doCheckfilehasbeenopenornot($insertfilehandler,$checkcount  =   0)
    {
        ini_set('max_execution_time',0);
        $completed 			=   Config::get('constants.FILE_HANDLER_ACTION.success');					
        $checkcomplete 			=   fileHandler::where('ID',$insertfilehandler)->where('status',1)->where('remarks',$completed)->first();
        if($checkcount>5 || count($checkcomplete)>=1)
        {
            return 1;
        }
        $this->doCheckfilehasbeenopenornot($insertfilehandler,++$checkcount);
    }
    //check in process
    public function doIndexingCheckinprocess(Request $request)
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $validation             =   Validator::make($request->all(), [
                                            'metadataid'=> 'required|numeric',
                                            'jobId' 	=> 'required|numeric',
                                            'Chapter' 	=> 'required',
                                            'bookid' 	=> 'required',
                                            'jobtimesheetid' => 'required|numeric'
                                    ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response, 404);
            }
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            $jobtimesheetid     =   $request->input('jobtimesheetid');
            $stagename          =   Config::get('constants.STAGE_NAME.INDEXING');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.INDEXING');  
            //get location 
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
                $getuserid          =   $this->empId;
                $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                $sourcepathuserwork =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $checkexistdirfile  =   $hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $cucDirFiles        =   $ftpObj->allFiles($checkexistdirfile);
                if(!empty($cucDirFiles)) 
                {
                    //$sourcepath           =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucSourceCheckout;
                    $destinationpath        =   $hostserver.$hostpath.Config::get('serverconstants.TEMP_PATH').$stageid.'_'.$bookid.'_'.$Chapter;
                    $sourcepath             =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.Config::get('serverconstants.TEMP_PATH');
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepathuserwork , $destinationpath);
                    $response_copy      =   array('success');
                    if( in_array( 'failed' , $response_copy ) )
                    {
                        foreach ($response_copy as $key => $value )
                        {
                                if( $value == 'success' ){
                                        unset( $response[$key] );
                                }
                        }
                        $response_copy   =       array( 'status' => 'failed'  , $response_copy );
                    }
                    else
                    {
                        $response_copy    =       array( 'status' => 'success' , $response_copy );
                    }
                    $response   =       $response_copy;
                    if( $response_copy['status'] != 'success' )
                    {
                        return response()->json($this->fileNotCopiedResponse);			
                    }
                    $datajob                =   [];
                    $datajob['CHECK_IN']    =   Carbon::now();
                    $doUpdatecheckin        =   jobTimeSheet::updateIfExist($datajob,$jobtimesheetid);
                    $response   =   $this->insertedResponse;
                    $response['errMsg']     =   'File Check-in Successful';
                    $response['desitinationpath']   =   $destinationpath;
                    return response()->json($response);
                }
                $response['errMsg']     =   $Chapter . ' directory is not found...';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    //Final submit process
    public function doIndexingCompleteprocess(Request $request)
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $validation             =   Validator::make($request->all(), [
                                             'metadataid'=> 'required|numeric',
                                             'jobId' 	=> 'required|numeric',
                                             'Chapter' 	=> 'required',
                                             'bookid' 	=> 'required',
                                             'jobtimesheetid' => 'required|numeric'
                                     ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response,404);
            } 
            $stagename          =   Config::get('constants.STAGE_NAME.INDEXING');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.INDEXING');   
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            $jobtimesheetid     =   $request->input('jobtimesheetid');
            $wheredata          =   [];
            $wheredata['METADATA_ID']   =   $metaid;
            $wheredata['JOB_ID']        =   $jobId;
            $wheredata['STAGE']         =   $stageid;
            $wheredata['METADATA_ID']   =   $metaid;
            $alfreshcofullpath  =   "";
            $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
            //check user access 
            $getmamtimesheetid  =   jobTimeSheet::getMaxoftimesheetrecords($wheredata);
            $jobtimesheetid     =   (count($getmamtimesheetid)>=1?$getmamtimesheetid->timesheetid:$jobtimesheetid);
            
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $cucSourceCheckout  =   $hostpath.Config::get('serverconstants.PRE_PROCESSING_PATH').$bookid.'/'.$stagename.'/'.$Chapter;                    
                $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                //check directory is exist or not
                $cucSourceexist     =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                //get all files from ftp based on given folder name
                $cucDirFiles        =   $ftpObj->allFiles($cucSourceexist);
                $alfreshcofullpath  =   rtrim($ftp_root_dir,'/');
                $alfreshcofullpath  =   $hostserver.$alfreshcofullpath.$cucSourceCheckout;
                    
                $destinationpath    =   $hostserver.$cucSourceCheckout;
                if(!empty($cucDirFiles)) 
                {
//                    $xmlFilePath    =   "";
//                    foreach($cucDirFiles as $checkxmlFile) 
//                    {
//                        if(pathinfo($checkxmlFile)['extension'] == 'xml') 
//                        {
//                            $xmlFilePath    =   $checkxmlFile;
//                        }
//                    }
//                    if($xmlFilePath == '') 
//                    {
//                        $result         =   array('result'=>404,'errMsg'=>'Indexing log file is not found');   
//                        return response()->json($result);
//                    }
                    
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                    $response_copy          =   array('success');
                    if( in_array( 'failed' , $response_copy ) )
                    {
                        foreach ($response_copy as $key => $value )
                        {
                            if( $value == 'success' ){
                                unset( $response[$key] );
                            }
                        }
                        $response_copy      =   array( 'status' => 'failed'  , $response_copy );
                    }
                    else
                    {
                        $response_copy      =   array( 'status' => 'success' , $response_copy );
                    }
                    $response               =   $response_copy;
                    if( $response_copy['status'] != 'success' )
                    {
                        return response()->json($this->fileNotCopiedResponse);	
                    }
                    
                    //alfresco request
                    if(!empty($alfreshcofullpath)){
                        $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobId,$metaid,Config::get('constants.ROUND_ID.104'),$stageid,$alfreshcofullpath,'submit');
                    }

                    //check exist meta id in job time sheet table
                    $jobtimedata            =   [];
                    $jobtimedata['STATUS']  =   2;
                    $jobtimedata['CHECK_IN']=   Carbon::now();
                    $updatemetasuccess      =   jobTimeSheet::updateIfExist($jobtimedata,$jobtimesheetid);
                    //insert record in filehandler table for delete ftp drive
//                    $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucSourceCheckout;
                    $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    $postdata               =   [];
                
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "deleteFileServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "deleteFileServer";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    $response   =   $this->insertedResponse;
                    $response['errMsg']     =   'File submitted Successfully...';
                    return response()->json($response);
                }
                $response['errMsg']     =   $Chapter.' directory is not found...';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response['result']     =   500;
            return response()->json($response);
        }
    }
        //Final submit process
    public function doIndexingOpenDrive(Request $request)
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $validation             =   Validator::make($request->all(), [
                                                'metadataid'=> 'required|numeric',
                                                'jobId' 	=> 'required|numeric',
                                                'Chapter' 	=> 'required',
                                                'bookid' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response,404);
            }
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            $stagename          =   Config::get('constants.STAGE_NAME.INDEXING');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.INDEXING');   
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $userWork_for_const =   Config::get('serverconstants.USER_WORK_PATH');
                
                $destinationpath    =   $hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$userWork_for_const.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                $open_path          =   str_replace( '//' , '/' , $open_path );
                //check directory is exist or not
                $cucSourceexist     =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                //get all files from ftp based on given folder name
                $cucDirFiles        =   $ftpObj->allFiles($cucSourceexist);
                $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                if(!empty($cucDirFiles) && count($successfile)>=1) 
                {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
					//$postdata['file_path']  =   $open_path.'/'.$successfile[0].'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    if($insertfilehandler>=1)
                    {
                        $response   =   $this->insertedResponse;
                        $response['errMsg']     =   'Folder Opened Successfully';
                        $response['rmID']       =   $insertfilehandler;
                        return response()->json($response);
                    }
                    return response()->json($this->insertedFailedResponse);
                }
                $response['errMsg']     =   $Chapter . ' directory is not found...';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    
    
    public function getIndexingJobXMLInfo(Request $request) 
    {
	try
        {
            $response   =   $this->locationNotFoundResponse;
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                                                        'host'     => $hostserver, 
                                                                                        'username' => $hostusername,
                                                                                        'password' => $hostpassword, // 
                                                                                        'port'     => '21',
                                                                                        'timeout'  => '30',
                                                                        ]);
                $getuserid          =   $this->empId;
                $roundname          =   Config::get('constants.ROUND_OF_NAME.S5');
                $cucuserworkfolder  =   Config::get('serverconstants.JOBSHEET_FULL_PATH');
                $inp_rep_arr        =   array( 
                                            'BOOK_ID'       =>      $bookid , 
                                            'ROUND_NAME'    =>      $roundname                        
                                         );
                 
                $cmn_obj            =   new CommonMethodsController();
                $serverDir          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , Config::get('serverconstants.JOBSHEET_FULL_PATH') );
                $cucuserworkfolder  =   $hostpath.$serverDir;
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }
                    if($xmlFilePath == '') 
                    {
                        $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xmlPath        =   base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';

                    // LOAD XML FILE CONTENT
                    $XML = new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt = new \XSLTProcessor(); 
                    // IMPORT STYLESHEET
                    $XSL = new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $response   =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                $response['errMsg']     =   'XML file is not found';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {       
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        }
    }
    
    public function getIndexingXMLInfo(Request $request) 
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $stagename      =   Config::get('constants.STAGE_NAME.INDEXING');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   $this->empId;
                $cucuserworkfolder  =   $hostpath.Config::get('serverconstants.PRE_PROCESSING_PATH').$bookid.'/'.$stagename.'/'.$Chapter;                    
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    $xmlFilePath    =   "";
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }

                    if($xmlFilePath == '') 
                    {
                        $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                        return response()->json($response);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'cucview.xsl';
                    // LOAD XML FILE CONTENT
                    $XML            =   new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt           =   new \XSLTProcessor(); 
                    // IMPORT STYLESHEET
                    $XSL            =   new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $response   =   $this->successResponse;
                    $response['errMsg']     =   $xslt->transformToXML( $XML );
                    $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                    return response()->json($response);
                }
                $response['errMsg']     =   'XML file is not found';
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        }
    }
    
        //Final submit process
    public function doindexingopenrawfile(Request $request)
    {
        try
        {
            $response   =   $this->locationNotFoundResponse;
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response, 404);
            }
            $jobId              =   $request->input('jobId');
            $bookdata           =   jobModel::where('JOB_ID',$jobId)->first();
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            if($bookid  ==  "")
            {
                return response()->json($this->notfoundResponse,404);
            }
            $rawpath            =   Config::get('serverconstants.RAW_PATH');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $sfifty             =   Config::get('constants.ROUND_OF_NAME.S5');
                $destinationpath    =   $hostserver.$hostpath.$rawpath.$bookid.'/'.$sfifty;                    
                $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$rawpath.$bookid.'/'.$sfifty;                    
                $open_path          =   str_replace( '//' , '/' , $open_path );
                //check directory is exist or not
                $cucSourceexist     =   $hostpath.$rawpath.$bookid.'/'.$sfifty;
                //get all files from ftp based on given folder name
                $cucDirFiles        =   $ftpObj->allFiles($cucSourceexist);
                if(!empty($cucDirFiles)) 
                {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    $checkcomplete          =	$this->doCheckfilehasbeenopenornot($insertfilehandler);
                    sleep(7);
                    $checkcompletefile      =   fileHandler::where('ID',$insertfilehandler)->where('status',1)->where('remarks','completed')->first();
                    if(count($checkcompletefile)>=1)
                    {
                        $response   =   $this->insertedResponse;
                        $response['errMsg']     =   'Folder Opened Successfully';
                        return response()->json($response);
                    }
                    $response['errMsg']     =   'File handler is not running. Kindly run the file handler.';
                    return response()->json($response);
                }
                return response()->json($this->nofileResponse);
            }
            return response()->json($response);
            }
        catch( \Exception $e )
        {           
            $response['result']     =   500;
            return response()->json($response);
        }
    }
}