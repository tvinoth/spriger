<?php

    namespace App\Http\Controllers\productionLocation;
    
    use App\Http\Controllers\Controller;    
    use App\Models\productionLocationModel;
    use App\Models\downloadModel;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Redirect;
    Use Illuminate\Support\Facades\Crypt;
    use App\Models\jobModel;
    use Session;
    use Validator;
    use Config;
    use PDF;
    use Carbon\Carbon;
    use DB; 
    use Illuminate\Http\Response;
    use Excel;
    use Mail;
    
    class productionLocationController extends Controller
    {
        public function __construct() {
            parent::__construct();
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
        
        public function index(){
             
            $data= array();
            $data['pageTitle'] = 'Production Location';
            $data['pageName']  = 'Production Location Information';
            $data['user_name'] =  Session::get('users')['user_name'];
            $data['role_name'] =  Session::get('users')['role_name'];
            echo 'View not defined ';
            //return view('location.location-list')->with($data);
            
        }
        
        public function getLocationInfo(){
            
            $getData      =       \App\Models\productionLocationModel::getProductionLocationName();
            $response       =       array();
           
            $i  =   1;
            
            foreach( $getData as $key => $value ){
                
                $response[$key]['LOCATION_NAME']       =   $value;
                $response[$key]['ID']       =       $i;
                $i++;
                
            }
            
            echo json_encode( array( 'locations' => $response ));            
            
        }
        
        public function getList(){
            
            $getInfo['locations']        = \App\Models\productionLocationModel::getProductionLocationList();
            
             echo json_encode( $getInfo , true);
            
        }
        
        public function insert( Request $request )
        {
            $rules['prdlid']        =   'required';
            $rules['ftphost']       =   'required';
            $rules['ftpusername']   =   'required';
            $rules['ftppassword']   =   'required';
            $rules['ftppath']       =   'required';
            $response               =   $this->oopsErrorResponse;
            $inpArray               =   [];
            $validator              =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
               $response['errMsg']  =   'Required field validation error occured.';
            }else{
                $inpArray['PRODUCTION_LOCATION']=   $request->input('prdlid');	
                $inpArray['FTP_HOST']           =   $request->input('ftphost');	
                $inpArray['FTP_USER_NAME']      =   $request->input('ftpusername');
                $inpArray['FTP_PASSWORD']       =   Crypt::encryptString(  $request->input('ftppassword'));
                $inpArray['FTP_PATH']           =   $request->input('ftppath');
                $user_info                      =   ( $request->session()->get('users') );
                $inpArray['FILE_SERVER_PATH']   =   Config::get('constants.FILE_SERVER_ROOT_DIR').'SP_BOOKS/';
                $inpArray['FILE_SERVER_USER_NAME']  =   Config::get('constants.FILE_SERVER_USER_NAME');
                $inpArray['FILE_SERVER_PASSWORD']   =   Config::get('constants.FILE_SERVER_PASSWORD');
                $inpArray['CREATED_BY']         =   $user_info['user_id'];
                $inpArray['STATUS']             =   'ACTIVE';
                $inpArray['CREATED_DATE']       =   Carbon::now();
                try{
                    $insertId                   =   productionLocationModel::insertGetId( $inpArray );
                    $response               =   $this->insertedResponse;
                }
                catch( \Exception $e ){                  
                    
                }
            }
            
            echo json_encode( $response );
        }
        
        public function update( Request $request ){
            
            $inpArray = array();
            
            $rules['prdlid']        =       'required';
            $rules['ftphost']      =       'required';
            $rules['ftpusername']     =       'required';
            $rules['ftppassword']       =       'required';
            $rules['ftppath']       =       'required';
            $response               =   $this->oopsErrorResponse;
            
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['errMsg']      =       'Required field validation error occured.';
                
            }else{
            
                $inpArray['ID']              =   $request->input('prdlid');	
                $inpArray['PRODUCTION_LOCATION']    =   $request->input('prdloc');	
                $inpArray['FTP_HOST']   =   $request->input('ftphost');	
                $inpArray['FTP_USER_NAME']     =   $request->input('ftpusername');
                $inpArray['FTP_PASSWORD']     =   $request->input('ftppassword');
                $inpArray['FTP_PATH']     =   $request->input('ftppath');
                $user_info                           =       ( $request->session()->get('users') );
                $inpArray['user_id']         =   $user_info['user_id'];
                
                $result     = \App\Models\productionLocationModel::updateLocation( $inpArray );     
                $response   =   $this->updatedResponse;
            }
            
            return response()->json($response); 		
                
        }
        
        public function delete( Request $request ){
            
            $rowid          =       $request->input( 'ID' );
            $response       =       false;
            
            if( !empty( $rowid ) ){
                $response   =       \App\Models\productionLocationModel::deletePrdLocation( $rowid );
            }
            
            echo $response;  
            
        }
        
        public function getListWithPmDetails( Request $request ){
            
            $response       =       array();
            $response['locationPm']     = \App\Models\productionLocationModel::getListWithPmDetails();
            echo json_encode( $response , true );
            
        }
        
        public function pmlocationset( Request $request ){
            
            $user_info      =       $request->session()->get('users');
            $userid         =       $user_info['user_id'];
            $prd_area_id    =       $request->input( 'prdl' );
            $table_name     =       'pm_location_mapping';
            
            $response       =   $this->oopsErrorResponse;
                
            $records =   $already_exist      = \App\Models\locationModel::getPmLocationInfo($userid);           
            
            if( count( $already_exist ) > 0 ){
                
                //do update
                $setArr     =       array(
                                        'PRODUCTION_AREA' => $prd_area_id , 
                                        'LAST_MOD_DATE' => date( 'Y-m-d H:i:s' ) , 
                                        'LAST_MOD_BY'   =>  $userid 
                                     );
                
                try{
                    
                    $updateQry  =   DB::table( $table_name )
			->where('ID', $records[0]->ID )
			->update( $setArr );
                    $response   =   $this->successResponse;
                    $response['errMsg']      =       'Location Mapped Successfully.';
                
                } catch (\Exception $ex) {
                        logger( $ex->getMessage() );
                }
                
            }else{
                
                //do insert
                $inp_arr    = array( 
                                'PROJECT_MANAGER_ID' =>  $userid  ,
                                'PRODUCTION_AREA' => $prd_area_id ,
                                'CREATED_DATE'      =>  date( 'Y-m-d H:i:s' ) , 
                                'CREATED_BY'    =>  $userid
                            );
                
                try{
                    
                    $insertConfirm      =        DB::table( $table_name )->insertGetId( $inp_arr );
                    $response   =   $this->successResponse;
                    $response['errMsg']      =       'Location Mapped Successfully';
                
                } catch (\Exception $ex) {                   
                    loggger( $ex->getMessage() );                   
                }                
                
            }
            
            return response()->json( $response );
            
        }
        
        public function changePrdLocation( Request $request ){
            try {
                $metaid = "";$roundid        =   '';
                $user_info      =   $request->session()->get('users');
                $userid         =   $user_info['user_id'];
                $prd_area_id    =   $request->input( 'location_id' );
                $job_id         =   $request->input( 'job_id' );
                $bookid         =   $request->input( 'book_id' );
                $roundid        =  $request->input( 'roundid' );
                $metaid         =  $request->input( 'metaid' );
                $table_name     =   'job_info';
               
                $response       =   $this->oopsErrorResponse;
                $setArr             =   array(
                                                'LOCATION' => $prd_area_id 
                                               );

                $query_stmt         =       'select * from job_info where JOB_ID='.$job_id;
                $return_res         =       DB::select($query_stmt);
                $location_val       =       $return_res[0]->LOCATION;
                $updateQry          =       DB::table( $table_name )->where('JOB_ID', $job_id )->update( $setArr );                    
                if( $updateQry )  {
                    $response   =   $this->successResponse;
                    $response['errMsg']      =       'Production Location Changed Successfully.';

                  $records                 =       $already_exist      =        \App\Models\locationModel::getPmLocationInfo($userid);           

                  $setArr           =       array(
                                            'PRODUCTION_AREA'   =>      $prd_area_id , 
                                            'LAST_MOD_DATE'     =>      date( 'Y-m-d H:i:s' ) , 
                                            'LAST_MOD_BY'       =>      $userid 
                                           );

                   $table_name      =   'pm_location_mapping';

                   if( !empty( $records[0]->ID ) ){
                        $updateQry  =   DB::table( $table_name )->where('ID', $records[0]->ID )->update( $setArr );
                   }else{
                        $table_name =   'pm_location_mapping';
                        $inp_arr    =   array( 
                                            'PROJECT_MANAGER_ID' =>  $userid  ,
                                            'PRODUCTION_AREA' => $prd_area_id ,
                                            'CREATED_DATE'      =>  date( 'Y-m-d H:i:s' ) , 
                                            'CREATED_BY'    =>  $userid
                                        );
                        $insertConfirm  =   DB::table( $table_name )->insertGetId( $inp_arr );
                   }

                   $obj_pfl         =   new \App\Http\Controllers\Api\productionFileTransferController();
                   $round_arr       =   \Config::get('constants.ROUND_ID');
                   
                   if($roundid != ''){
                      $round_          =   $roundid;
                   }else{
                      $round_          =   $round_arr['S5']; 
                   }
                   
                   $transApi        =   $obj_pfl->locationChangeRequest( $job_id , $round_,$metaid );
                   if( $transApi['status'] == 1 ){
                        $this->sendMailnotificationForPrdlChange( $bookid , $location_val );
                   }else{
                        $response               =   $this->failedResponse;
                        $response['errMsg']     =   $transApi['errMsg'];
                   }
                }
                return response()->json( $response );    
            } catch (\Exception $e ) {
                logger( $e->getMessage() );
                DB::rollback();
                return response()->json( $response );
            } 
        }  
        
        public function sendMailnotificationForPrdlChange( $bookid , $location_val ){
             
            $mailArray              =   $mailData = array();
            $amDetails              =   array();
            $user_info              =   Session::get('users');
            $userid                 =   $user_info['user_id'];
            $amDetails['user_id']   =   $userid;
            $amDetails['book_id']   =   $bookid;
            $bookDetails            =   downloadModel::getBookDetails($amDetails['book_id']);
            $jobId                  =   '';
           
            if(count($bookDetails)>=1){
                $amDetails['BookTitle']     =   $bookDetails->JOB_TITLE;
                $jobId                      =   $bookDetails->JOB_ID;
                $amDetails['ISSN_PRINT']    =   $bookDetails->ISSN_PRINT;
                $amDetails['ISSN_ONLINE']   =   $bookDetails->ISSN_ONLINE;
                $amDetails['receivedDate']  =   $bookDetails->CREATED_DATE;
                $amDetails['AUTHOR_NAME']   =   $bookDetails->AUTHOR_NAME;
                $amDetails['EDITOR_NAME']   =   $bookDetails->EDITOR_NAME;
                $amDetails['book_id']       =   $bookDetails->BOOK_ID;
            }
            
            $userDetails_am         =   downloadModel::getUserDetails($bookDetails->AM);
            $userDetails_pm         =   downloadModel::getUserDetails($userid);
            if(count($userDetails_am)>=1 && count($userDetails_pm)>=1)
            {
                $amDetails['AM_Mail']   =   $userDetails_am->EMAIL;
                $amDetails['AM_name']   =   $userDetails_am->userName;
                $amDetails['PM_Mail']   =   $userDetails_pm->EMAIL;
                $amDetails['PM_name']   =   $userDetails_pm->userName;
            }
            else
            {
                $Response['Status']     =   2;
                $Response['Msg']        =   'Failure';
                $Response['MsgText']    =   'Am user details not found';
                return $Response;
            }
            
            $tblname                =   'pm_location_mapping as pml';
            $select_field           =   array( 'pml.ID' , 'pml.PRODUCTION_AREA' , 
                                                DB::RAW( 'pml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 
                                                'pml.PROJECT_MANAGER_ID' , 
                                                'pml.STATUS' , 
                                                'usr.FIRST_NAME as MANAGER_NAME'
                                            );
                   
            $jb_obj                 =   jobModel::getJobdetails($jobId);
            $prdarea_code           =   $jb_obj->LOCATION;
            $getPrdlc               =   DB::table('production_area_location')->select()->where( 'ID' , $prdarea_code )->get()->first();
            $prdarea_code           =   $jobInfoData['LOCATION']    =  $getPrdlc->LOCATION_NAME; 
            $mailData['prdl']       =   $getPrdlc->LOCATION_NAME;
            $mailData['Title']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
            $mailData['HeadLine']   =   Config::get('constants.NEW_JOB_MAIL_CONTENT.PRODUCTION_LOCATION_CONTENT');
            $mailData['ToName']     =   $amDetails['AM_name'].' , '.$amDetails['PM_name'];
            $mailData['authorname'] =   $amDetails['AUTHOR_NAME'];
            $mailData['editorname'] =   $amDetails['EDITOR_NAME'];
            $mailData['BookId']     =   $amDetails['book_id'];
            $mailData['BookTitle']  =   $amDetails['BookTitle'];
            $mailData['BookIsbn']   =   $amDetails['ISSN_ONLINE'];
            $mailData['ReceivedDate']   =   $amDetails['receivedDate'];
            $mailArray['Data']      =   $mailData;
            if( empty( $location_val ) ){
                $mailArray['Subject']       =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_PRODUCTION_LOCATION_CONTENT').$amDetails['book_id'];      
                $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_PRODUCTION_LOCATION_TEMP');
            }
            if( !empty( $location_val ) ){
                $mailArray['Subject']       =   Config::get('constants.NEW_JOB_MAIL_CONTENT.PRODUCTION_LOCATION_CHANGES').$amDetails['book_id'];
                $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.PRODUCTION_LOCATION_CHANGE_TEMP');
            }
            $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
            $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
            $mailArray['ToMail']    =   $amDetails['AM_Mail'];
            //$mailArray['CcMail']    =   array('mohan.m@spi-global.com','shamu.shihabudeen@spi-global.com' , $amDetails['PM_Mail'] );
            
            $mailArray['BccMail']    =   Config::get('constants.BCC_EMAIL_LIST');
            return $Response        =   $this->sendMailBladeTemplate($mailArray);
        }
        
        public function sendMailBladeTemplate($mailArray) {
           
             if (is_array($mailArray)){ 
                 
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }

                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Success';
		    $Response['MsgText'] = Mail::failures();
                } else {
                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Success';
                }

                return $Response;
            }
        }
        
        public function sendMail(){
            $bookid =   '213341_1_En';
            $this->sendMailnotificationForPrdlChange($bookid);
        }
        
    
    }