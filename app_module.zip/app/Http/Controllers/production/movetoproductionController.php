<?php
/*
 *  Author : Ananth B
 *  Date : 06-04-2018
 *  move to production
 * 
 */

namespace App\Http\Controllers\production;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\apitapsModel;
use App\Models\tapsmetadataModel;
use App\Models\metadataInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\jobRound;
use App\Models\jobStage;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\workflowModel;
use App\Models\customizationModel;
use Illuminate\Http\Request;
use App\Http\Controllers\checkout\stageMangerController;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\tapsController;
use App\Http\Controllers\taskLevelMeatadata\taskLevelMetadataController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;
use App\Http\Controllers\taskLevelMeatadata\newComponentController;

class movetoproductionController extends Controller
{
    //This method is for future use [ to improve metadata_status table and grouping ]
    public function artMoveToProduction( $jobid , $roundid, $workflowid, $metaId, $duedate, $user , $is_group = 1  ){
        
        $datetime               =       date("Y-m-d H:i:s");
        $duedate                =       (!empty($duedate) ? date( 'Y-m-d', strtotime($duedate) ) : NULL );
        $mds_obj                =       new metaDataStatus();
        $tlam_obj               =       new taskLevelArtMetadataModel();
        $mds_id                 =       null;
        
        $response['status']     =       0;
        $response['msg']        =       'Failed';
        $response['errMsg']     =       'Art Move to Production got failed';
        
        $user_id                =       Session::get('users')['user_id'];     
        
        $where_conditon_tlam    =       array( 'METADATA_ID' => $metaId , 'STATUS_ENUM_ID' => 45 );
        $tdam_rec               =       $tlam_obj->getRecordByCustomCondition( $where_conditon_tlam );
        
        $whereCondition_mds     =       array( 
                                                'METADATA_ID'     =>     $metaId , 
                                                'CURRENT_ROUND'   =>     $roundid , 
                                                'IS_ART'          =>     1 
                                             );
        
        $mds_rec                =       $mds_obj->getRecordByCustomCondition( $whereCondition_mds );
        
        if( empty( $mds_rec ) && !empty( $tdam_rec ) ) {
            
            //metadata table insert 
            $insert_array_mds           =       array(  'JOB_ID'        =>      $jobid , 
                                                        'METADATA_ID'   =>      $metaId , 
                                                        'CURRENT_ROUND' =>      $roundid , 
                                                        'DUE_DATE'      =>      $duedate , 
                                                        'CURRENT_STATUS'    =>  46  ,  
                                                        'LAST_MOD_DATE'     =>  $datetime , 
                                                        'LAST_MOD_BY'       =>  $user_id , 
                                                        'IS_ART'        =>      1 , 
                                                        'RECEIVED_DATE' =>      $datetime , 
                                                        'CURRENT_ITERATION' =>  1 
                                                    );
            
            $mds_id     =       $mds_obj->insertRecordGetId( $insert_array_mds );
            
        }else{
            
            if( !empty( $mds_rec ) )
                $mds_id     =      $mds_rec->ID; 
            
        }

        if( !empty( $tdam_rec ) && isset( $mds_id ) ){
            $this->proceedJbRoundStageInsertForArt( $tdam_rec  , $jobid , $roundid , $workflowid , $metaId , $duedate , $user  , $mds_id , $datetime ,  $user_id  );
            
        }else{
            $response['errMsg']         =           'Invalid try!, art entry is not available';
        }
        
        
    }
    
    public function proceedJbRoundStageInsertForArt( $tdam_rec = array() , $jobid , $roundid, $workflowid, $metaId, $duedate, $user  ,$mds_id , $datetime ,  $user_id ){
        
        
        if( !empty( $tdam_rec ) ){
            
            $jbr_obj        =       new jobRound();
            $jbs_obj        =       new jobStage();
                      
            foreach( $tdam_rec as $key => $rec_obj ){
                
            $inp_arr_jbr    =       array( 'JOB_ID'  =>  $jobid  , 'ROUND_ID'   =>    $roundid , 'ART_METADATA_ID'  =>    $rec_obj->ART_METADATA_ID  , 
            'METADATA_STATUS_ID'    =>     $mds_id  ,    'DUE_DATE'  =>  $duedate ,     'STATUS'     =>  27     ,   'ROUND_SEQ'    =>     1  , 
            'IS_ART' => 1    ,      'CREATED_DATE' => $datetime     ,       $created_by => $user_id     );
            
            $jbr_id         =       $jbr_obj->insertRecordGetId( $inp_arr_jbr );

                if( $jbr_id ){
                    
                    //job stage for art round insert
                    
                    $query_stmt_jstg = "INSERT INTO job_stage (job_round_id, workflow_master_id, workflow_id, workflow_type, stage_id, 
							start_stage_id, end_stage_id, skip_enabled, STATUS, stage_seq)
							SELECT '.$jbr_id .', t.WORKFLOW_MASTER_ID, t.WORKFLOW, t.WORKFLOW_TYPE, t.STAGE, t.START_STAGE, t.END_STAGE, t.SKIP_STAGE, 25, t.STAGE_SEQ
							FROM task_level_userdefined_workflow t
							WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."' AND STAGE_SEQ=1";
                    
                    $insert_jstg_status     =    DB::select( $query_stmt_jstg );
                    
                    $enableStage    =   "UPDATE job_stage SET  STATUS = 27 WHERE JOB_ROUND_ID = '".$jbr_id."' AND STAGE_SEQ = 1";
                    $updateStatus   =   Db::select($enableStage);
                    
                    $stageSql = "SELECT t.STAGE FROM task_level_userdefined_workflow t WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."' AND STAGE_SEQ=1";
                    $stageQuery = DB::select($stageSql);
                    $stageId = $stageQuery->STAGE;
                    
                    if($stageId!=''){	
                        
                        $updateRound = "UPDATE job_round SET CURRENT_STAGE = '".$stageId."' WHERE JOB_ROUND_ID = '".$jbr_id."'";
                        Db::select($updateRound);

                        $updateMetaData = "UPDATE task_level_art_metadata
                            SET
                            CURRENT_ROUND           =       '".$roundid."',
                            STATUS_ENUM_ID          =       46,
                            CURRENT_ITERATION       =       1,
                            METADATA_STATUS_ID      =       '".$mds_id."',
                            CURRENT_STAGE           =       '".$stageId."'
                            WHERE METADATA_ID       =       '".$metaId."'";

                        $updateMetaStatus = DB::select( $updateMetaData );
                        

                    }
						
                    
                }else{
                    throw new Exception('Job round insert got failed.');
                }
            
            }
            
        }
        
        return false;
        
    }
    
    //This method is for to do old artmovetoproduction procedure , will not support grouping
    public function runArtMoveToProductionProcedure( $metadataid,$workflowId ){
        
        $tlam               =           new taskLevelArtMetadataModel();
        $jbr_obj            =           new jobRound();
        $artCreation        =           \Config::get( 'constants.ART_STATUS.ART_CREATED' );
        //$whereCondi         =           array( 'METADATA_ID' => $metadataid , 'STATUS_ENUM_ID' => $artCreation );
        $whereCondi         =           array( 'METADATA_ID' => $metadataid);
        $taskartInfo        =           DB::table( 'task_level_art_metadata' )->select()->where( $whereCondi )->get()->toArray();
       
        $time               =           date( 'Y-m-d H:i:s' );
         
        $userid             =           5556405;
        $artflag            =           1;
        $inputQty           =           1;
        $workflwid          =           $workflowId;    //artworkflow id , yet to do dynamic configuration
        $return_status      =           array();
        
        
        if( !empty( $taskartInfo ) ){ 
             $S200Id       =   Config::get('constants.ROUND_ID.S200');
            DB::table('task_level_art_metadata')->where($whereCondi)
                    ->update(array('CURRENT_ROUND' => $S200Id));
            
            $taskartInfo        =           DB::table( 'task_level_art_metadata' )->select()->where( $whereCondi )->get()->toArray();
            
            foreach( $taskartInfo as $key => $value ){
                
                $artmetaid      =       $value->ART_METADATA_ID;
                $artRoundRec    =       DB::table('job_round')->select()->where(array( 'ART_METADATA_ID' => $artmetaid ))->get();
                $jobid          =       $value->JOB_ID;
                $roundid        =       $value->CURRENT_ROUND;
                
                if( empty( $artRoundRec ) || true ){
                    
                    $prc_str            =       "CALL movetoproduction('$jobid', '$roundid', '$workflwid', '$metadataid', $artmetaid , '$inputQty', '$time', $artflag  ,'$userid')";
                    $return_status[]    =       DB::select( $prc_str );
                    
                }else{
                    
                    $return_s['status']     =   0;
                    $return_s['artMetaid']  =   $artmetaid;
                    $return_s['errMsg']     =   'Already persist job round entry.';     
                    $return_status[]        =   $return_s;
                    
                }
                
            }
            
        }
        
        return $return_status;
    }
	
	public function romanToNumeric( $roman ){
		
		$roman		=	strtoupper( $roman );	
		$romans = array(
			'M' => 1000,
			'CM' => 900,
			'D' => 500,
			'CD' => 400,
			'C' => 100,
			'XC' => 90,
			'L' => 50,
			'XL' => 40,
			'X' => 10,
			'IX' => 9,
			'V' => 5,
			'IV' => 4,
			'I' => 1,
		);
		
		$result = 0;
		
		foreach ($romans as $key => $value) {
			
			while (strpos($roman, $key) === 0) {
				$result += $value;
				$roman = substr($roman, strlen($key));
			}
			
		}
		
		return $result;
		
	}
    
    //This method is for to do old movetoproduction procedure , will not support parrallel
    public function taskLevelMoveToProductionProcedure( $jobId , $roundid , $workflowid , $metaid , $quanity , $duedate , $wrftype , $userid = '5556395'  ){
        
		if( gettype( $quanity ) == 'string' ){
			$quanity2 =  $this->romanToNumeric( $quanity );
			if( $quanity2 !== 0 )
				$quanity 	=	$quanity2;
		}
		
        $query_stmt =   "CALL movetoproduction('".$jobId."', '".$roundid."', '".$workflowid."', '".$metaid."', NULL, '".$quanity."', '".$duedate."', $wrftype ,'".$userid."')";
		
		       
        $moveDetails    =   DB::select( $query_stmt );  

        if(count($moveDetails)>=1){

            $updated    =   1;
            if($updated){
                $result         =   array( 'status'=>1 , 'msg' => 'success' , 'errMsg'=> $moveDetails );   
                return response()->json($result);
            }

        }

        $result         =   array( 'status'=>0 , 'msg' => 'failed' , 'errMsg'=>'Move to Production failed try again'.json_encode( $moveDetails ) );   
        return response()->json($result);

    }
	
    public function testingPurposeMoveToproduction(){

            $jobid 	= 	'6521';
            $round  	=  	'119';
            $workflowid =  	'61';
            $metaid  	= 	'4746';
            $quantity 	= 	'10';
            $duedate 	= 	'2019-10-25 19:03:17';
            $wrftype 	= 	'0';

            $response   = 	$this->taskLevelMoveToProductionProcedure( $jobid , $round , $workflowid , $metaid , $quantity , $duedate , $wrftype );

            var_dump( $response );

    }
    
    //to do all workflow type move to production from this method
    //it will auto support of below things :
    //parrallel move to production
    //art move to production
    //chapter level move to production
    
    public function ManualpreMovetoproduction(){
        $res   =    $this->triggerTasklevelMoveToproduction(6463,104);
    }
    
     public function triggerTasklevelMoveToproduction( $jobid , $round ){
        
        if( !is_null( $jobid ) && !is_null( $round ) ){
        
            $tlm        =       new taskLevelMetadataModel();
            $tlam       =       new taskLevelArtMetadataModel();
            $tluw       =       new taskLevelUserdefinedWorkflow();
            $jobM_obj   =       new jobModel();
            $quantity   =   '';
            $round_arr  =       \Config::get( 'constants.ROUND_ID' );
            
            //Finding workflow master id of last record in same round
            $workflowinfo       =       $tluw->getWorkflowMasterIdByJobidAndRound( $jobid , $round );
            $jobDetai           =       $jobM_obj->getJobdetails( $jobid );
            $duedate    =   "";
            if($jobDetai != null){
                
                $deadline_array     =   json_decode( $jobDetai->STAGE_DEADLINES_COLLECTION,true);
                
                if(count($deadline_array)>=1){

                    $getroundstage  =   \Config::get('constants.ROUND_NAME')[$round];
                    $duedate    =   $deadline_array[$getroundstage];
                }else{
                    $duedate    =   date("Y-m-d");
                }
                
            }else{
                
                $duedate    =   date("Y-m-d");
                
            }
            
            $duedate    =   (empty($duedate)?date("Y-m-d"):$duedate);
			
			
            $userid             =       Session::get('users')['user_id'];
            
            if( empty( $userid ) ){
                $userid         =       \Config::get( 'constants.ADMIN_USER_ID');
            }
            
            $return_arr         =       array();
            $bookid             =       $jobDetai->BOOK_ID;
            
            if( $jobDetai->count() ){
                
                $wmobj          =       $workflowinfo->pluck('WORKFLOW_MASTER_ID');
               
                $wmasterid      =       $jobDetai->WORKFLOW_TYPE;
                
                $wrkflow_obj    =       new workflowModel();
                
                $wrkflw_rec     =       $wrkflow_obj->getWorkflosByMasterId( $wmasterid );
				
				                
                $this->handleJoblevelPreproduction( $wrkflw_rec , $wmasterid , $jobid , $round  );
               
                $chp_obj        =       $tlm->getMetadatadetailsJobPreproduction( $jobid );
				
              
                $status_in_progress     = \Config::get( 'constants.STATUS_ENUM_COLLEECTION.JOB_LEVEL.JOB_INPROGRESS');
               
                if( $chp_obj->count() > 0 && $wrkflw_rec->count()){
                    $jobWorkFlow = array();  
                    foreach( $chp_obj as $index => $chpter_row ){
                        
                        foreach( $wrkflw_rec as $index => $wrkflw_row ){
                            
                            $wrkflwid           =       $wrkflw_row->WORKFLOW_ID;
                            $wtyp               =       $wrkflw_row->WORKFLOW_TYPE;
                            $metaid             =       $chpter_row->METADATA_ID;
                            $quantity           =       ($chpter_row->NO_MSP == 0 || $chpter_row->NO_MSP == '' || $chpter_row->NO_MSP == null?1:$chpter_row->NO_MSP);
                            
                            $record_of_job_level    =        DB::table('workflow_stage_activity')
                                                                    ->select()
                                                                    ->where( 'WORKFLOW' , '=' , $wrkflwid )
                                                                    ->where( 'PRODUCTION_LEVEL' , '=' , 2 )
                                                                    ->where( 'STAGE_SEQ' , '=' , 1 )
                                                                    ->get();
                            
                            if( $wtyp == 0 &&  $chpter_row->UNIT_OF_MEASURE != '556'){
								
                                $sta    =   $return_arr[$metaid.'_'.$index.'_'.$wtyp]           =       $this->taskLevelMoveToProductionProcedure( $jobid , $round , $wrkflwid , $metaid , $quantity , $duedate , $wtyp , $userid );
                                
                                $tasklevelModelObj  =   new taskLevelMetadataModel();
                                $stageDetails       =   $tasklevelModelObj->getCestimationStageID($jobid);
                                
                                if(!empty($stageDetails)){
                                    $ceStId        =   $stageDetails['0']->JOB_STAGE_ID;
                                    $roundId       =   $stageDetails['0']->JOB_ROUND_ID;
                                    $time          = 	date('Y-m-d H:i:s'); 
                                    $setArr        =   array( 'CHECK_IN'  => $time , 'STATUS' => '23');
                                    $updateQry     =   DB::table('job_stage')
                                                        ->where('JOB_STAGE_ID', $ceStId )
                                                        ->update( $setArr );
                                    
                                    $setArr2        =   array( 'STATUS' => '23');
                                    $updateQry2     =   DB::table('job_round')
                                                        ->where('JOB_ROUND_ID', $roundId )
                                                        ->update( $setArr2 );
                                    
                                }
                                
                            }
                           // echo $record_of_job_level->count();echo "<br>";
                            if( $record_of_job_level->count() > 0 || $chpter_row->STATUS_ENUM_ID == $status_in_progress ){
                                 
                                //avoid parallel for job work based on levels
                                if( $wtyp == 1 && $record_of_job_level->count() > 0 ){
                                    if($chpter_row->UNIT_OF_MEASURE == '556'){
                                        if(!in_array($wrkflwid,$jobWorkFlow)){
                                           $jobWorkFlow[] = $wrkflwid;
                                           $return_arr[$metaid.'_'.$index.'_'.$wtyp]       =       $this->parallelWorkflowMoveToproduction( $chpter_row , $jobid , $round , $wrkflwid , $userid , $duedate );
                                       }
                                    }									
                                }
                               
                            }else{
                                //Manual parralel wrkflow feed to table
                                if( $wtyp == 1 ){
                                    if($chpter_row->UNIT_OF_MEASURE !='556'){
                                        //echo "parall";
                                        //echo $chpter_row->UNIT_OF_MEASURE;echo "<br>";
                                        $return_arr[$metaid.'_'.$index.'_'.$wtyp]       =       $this->parallelWorkflowMoveToproduction( $chpter_row , $jobid , $round , $wrkflwid , $userid , $duedate );
                                    }
                                }
                            }
                            
                            if( $wtyp == 2 && false ){
                                $this->runArtMoveToProductionProcedure( $metaid , $wrkflwid );
                            }
                            
                        }
                    	
                    }
                  
                    return json_encode( $return_arr);
                     
                }else{                   
                    //chpter || metadata details are not available
                    return false;
                    
                }
            
            }else{
                //user defined entry is not available
                return false;
            }
        }
        
    }
    
    public function parallelWorkflowMoveToproduction( $tlm_rec , $jobid , $roundid , $workflowid , $userid , $duedate ){
      
        if( !empty( $tlm_rec ) ){
            
            $jbr_obj        =       new jobRound();
            $jbs_obj        =       new jobStage();
            $rec_obj        =       $tlm_rec;
            $datetime       =       date( 'Y-m-d H:i:s' );
            $metaId         =       $tlm_rec->METADATA_ID;
            
            $inp_arr_jbr    =       array( 
                'JOB_ID'        =>       $jobid      , 
                'ROUND_ID'      =>       $roundid    , 
                'METADATA_ID'   =>       $metaId     , 
                'DUE_DATE'      =>       $duedate    ,   
                'STATUS'        =>       27          ,   
                'ROUND_SEQ'     =>       1           , 
                'CURRENT_ITERATION_ID'     =>      1 , 
                'REVISION_NO'    =>      1          , 
                'CREATED_DATE'   =>      $datetime  ,  
                'FM_ARTICLE_BM'  =>      0          ,     
                'CREATED_BY'     =>      $userid
            );
            
            $jbr_id         =       $jbr_obj->insertRecordGetId( $inp_arr_jbr );
            
                $quantity           =       ($tlm_rec->NO_MSP == 0 || $tlm_rec->NO_MSP == '' || $tlm_rec->NO_MSP == null?1:$tlm_rec->NO_MSP);
                if( $jbr_id ){
                    //job stage for art round insert
                    
                    $query_stmt_jstg = "INSERT INTO job_stage (job_round_id,INPUT_QUANTITY, workflow_master_id, workflow_id, workflow_type, stage_id, 
							start_stage_id, end_stage_id, skip_enabled, STATUS, stage_seq)
                                                            SELECT $jbr_id,$quantity, t.WORKFLOW_MASTER_ID, t.WORKFLOW, t.WORKFLOW_TYPE, t.STAGE, t.START_STAGE, t.END_STAGE, t.SKIP_STAGE, 25, t.STAGE_SEQ
                                                            FROM task_level_userdefined_workflow t
                                                            WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."' ";
           
                    $insert_jstg_status     =    DB::insert( $query_stmt_jstg );
                    
                    $enableStage    =   "UPDATE job_stage SET  STATUS = 27 WHERE JOB_ROUND_ID = '".$jbr_id."' AND STAGE_SEQ = 1";
                    $updateStatus   =   DB::update($enableStage);
                    
                    $stageSql = "SELECT t.STAGE,t.IS_AUTO FROM task_level_userdefined_workflow t WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."' AND STAGE_SEQ=1";
                    $stageQuery = DB::select($stageSql);
                    
                    if( !empty( $stageQuery) ){
                        
                        $stageId = $stageQuery[0]->STAGE;
                    
                        if($stageId!=''){	

                            $updateRound = "UPDATE job_round SET CURRENT_STAGE = '".$stageId."' WHERE JOB_ROUND_ID = '".$jbr_id."'";
                            Db::update($updateRound);
                            $ceEstimation                 =       \Config::get( 'constants.STAGE_COLLEECTION.CE_ESTIMATION' );
                            if($stageQuery['0']->IS_AUTO == '1'){
                                if($ceEstimation == $stageId){
                                $enableStage    =   "UPDATE job_stage SET  STATUS = 23 WHERE JOB_ROUND_ID = '".$jbr_id."' AND STAGE_ID = $stageId";
                                }else{
                                    $enableStage    =   "UPDATE job_stage SET  STATUS = 68 WHERE JOB_ROUND_ID = '".$jbr_id."' AND STAGE_ID = $stageId";
                                }
                                $updateStatus   =   DB::update($enableStage);
                            }                            

                            $updateMetaData = "UPDATE task_level_metadata
                                SET
                                CURRENT_ROUND           =       '".$roundid."',
                                STATUS_ENUM_ID          =       42,
                                CURRENT_ITERATION       =       1,                            
                                CURRENT_STAGE           =       '".$stageId."'
                                WHERE METADATA_ID       =       '".$metaId."' and CURRENT_ROUND=".$roundid;

                                $updateMetaStatus       =       DB::update( $updateMetaData );

                                return 'movetoproduction got success';
                        }
                        
                    }else{
                        return 'current stage selection got failed...';
                    }
                    
                }else{
                    return ('Job round insert got failed.');
                }
           
                
        }
        
    }
    
    public function handleJoblevelPreproduction( $wrkflw_rec , $wmasterid , $jobid , $round ){
         
        $tlm        =       new taskLevelMetadataModel();
        
        $jobM_obj   =       new jobModel();
            
        $jobDetai   =       $jobM_obj->getJobdetails( $jobid );
        $book_id    =       $jobDetai->BOOK_ID;
       
        //Do the process for job level preproduction task insert.
        foreach( $wrkflw_rec as $ind_ => $wrkflw_rec ){

            $workflo_id_find            =       $wrkflw_rec->WORKFLOW_ID;
            
            //GETING JOB_LEVEL RECORDS
            $record_of_job_level    =        DB::table('workflow_stage_activity')
                                                    ->select()
                                                    ->where( 'WORKFLOW' , '=' , $workflo_id_find )
                                                    ->where( 'PRODUCTION_LEVEL' , '=' , 2 )
                                                    ->where( 'STAGE_SEQ' , '=' , 1 )
                                                    ->get();
            
            if( $record_of_job_level->count() > 0 ){

                $temp_check_avail_job       =       false;
                
                foreach(  $record_of_job_level as $index => $value ){

                    $stage_id           =       $value->STAGE;
                    $workflw_jl_id      =       $value->WORKFLOW;

                    //Find art or normal flow 
                    $getWfType          =       DB::table( 'task_level_userdefined_workflow' )
                                                    ->select()
                                                    ->where('WORKFLOW' , '=' , $workflw_jl_id )
                                                    ->where('WORKFLOW_MASTER_ID' , '=' , $wmasterid )
                                                    ->where('STAGE_SEQ' , '=' , 1 )
                                                    ->get();
                    $status_in_progress             =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.JOB_LEVEL.JOB_INPROGRESS');
                    
                    $job_table_check        =       DB::table( 'task_level_metadata' )
                                                                                   ->select(  )
                                                                                   ->where( 'JOB_ID' , '='  , $jobid )
                                                                                   ->where( 'STATUS_ENUM_ID' , '='  , $status_in_progress )
                                                                                   ->get();
                    $userdefineObj      =       $getWfType[0];
                    
                    
                    //check exist bookid is chapter no
                    $wherebookmeta  =   ['CHAPTER_NO'=>$book_id,'JOB_ID'=>$jobid,'UNIT_OF_MEASURE'=>\Config::get( 'constants.UNIT_OF_MEASURE')];
                    $existbookmeta  =   taskLevelMetadataModel::Active()->where($wherebookmeta)->first();
                    
                    $input_arr['job_id']            =       $jobid;
                    $input_arr['chapter_no']        =       $book_id;
                    $input_arr['chapter_name']      =       $book_id;
                    $input_arr['current_stage']     =       $userdefineObj->STAGE;
                    $input_arr['status_enum_id']     =      $status_in_progress;
                    $input_arr['unit_of_measure']    =      556;
                    
                    $inserted_meta_id           =       null;
                    
                    $job_table_check            =       DB::table( 'task_level_metadata' )
                                                                    ->select(  )
                                                                    ->where( 'JOB_ID' , '='  , $jobid )
                                                                    ->where( 'STATUS_ENUM_ID' , '='  , $status_in_progress )
                                                                    ->get();
                    if( $job_table_check->count() > 0 )        
                        $inserted_meta_id                 =        $job_table_check[0]->METADATA_ID ;
                    
                    //do for art [ task level art meta data ]
                    if( $existbookmeta == null ){
                        if( $userdefineObj->WORKFLOW_TYPE == 2 && false) {

                            $task_inp_arr   =       app('App\Http\Controllers\taskLevelMeatadata\taskLevelMetadataController')->buildTasklevelInsertData( $input_arr );

                            if( !$temp_check_avail_job && empty($inserted_meta_id) ){

                                try{
                                    $inserted_meta_id       =       DB::table( 'task_level_metadata' )
                                                                     ->insertGetId( $task_inp_arr );

                                    DB::insert( 'insert into metadata_info ( METADATA_ID , WORKFLOW_TYPE ) values ( '.$inserted_meta_id.' , '.$wmasterid.' )'  );
                                    $successfileresponse        =   app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobid,$this->round_ID_200,'insert','bookunitmeasurechapter','');
                                }catch(\Exception $e){

                                }
                            }

                            $task_inp_arr  = array();
                            $input_arr['metadata_id']       =       $inserted_meta_id;
                            $input_arr['figure_no']         =       $book_id;
                            $input_arr['file_name']         =       'ART';

                            $task_inp_arr                   =       app('App\Http\Controllers\artProcess\artProcessController')->buildArtTasklevelInsertData( $input_arr );
                            //$tlam           =       new taskLevelArtMetadataModel();
                            //do for normal tasklevel meta
                            try{
                                DB::table( 'task_level_art_metadata' )
                                       ->insertGetId( $task_inp_arr );
                             }catch( \Exception $e ){
                                 //return $e;
                             }
                            //$tlam->insertNew( $task_inp_arr );

                        }else{

                            $temp_check_avail_job           =       true;
                            $task_inp_arr                   =       app('App\Http\Controllers\taskLevelMeatadata\taskLevelMetadataController')->buildTasklevelInsertData( $input_arr );

                            //do for normal tasklevel meta
                            if( empty($inserted_meta_id) ){

                                try{
                                    $inserted_meta_id       =       DB::table( 'task_level_metadata' )
                                                                     ->insertGetId( $task_inp_arr );

                                    DB::insert( 'insert into metadata_info ( METADATA_ID , WORKFLOW_TYPE ) values ( '.$inserted_meta_id.' , '.$wmasterid.' )'  );
                                    $successfileresponse        =   app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobid,$this->round_ID_200,'insert','bookunitmeasurechapter','');
                                }catch( \Exception $e ){

                                }
                            }

                        }
                    }

                }

            }

        }
        
        
                
    }
        
    public function doArtMoveToProductionWithGrouping( $metaid , $round , $workflowid = null ){
        
        $tapscontroller     =       new tapsController();
        $duedate            =       date( 'Y-m-d H:i:s' );
        $user_info          =       Session::get('users');
        $userid             =       $user_info['user_id'];
        
        if( is_null( $workflowid ) )
            $workflowid         =       \Config::get('constants.S200_ART_WORKFLOWID');
        
            try{
                 
                $tskLevObj      =   new taskLevelMetadataModel();
                $metadatarec    =   $tskLevObj->getMetadatadetailsChapter( $metaid );
                if( count( $metadatarec ) )
                    $job_id                 =       $metadatarec[0]->JOB_ID;
                
                if(empty($userid)) {
                    $userid = Config::get('constants.ADMIN_USER_ID');
                }  
                
                $artMoveProduction      =       $tapscontroller->artMovetoProduction( $job_id , $round , $workflowid , $metaid , $duedate, $userid );
                
                $jbStgObj               =       new jobStage();
                $getjobstageInfo        =       $jbStgObj->getCurrentJobStageInfo( $metaid , $round , 27 );
                
                if( count( $getjobstageInfo ) ){
                    $stageinfo     =    $getjobstageInfo[0];
                    $jbstgId        =   $stageinfo->JOB_STAGE_ID;
                    $stgmgObj       =    new stageMangerController();
                    $stgmgObj->manageWaitngForParallelProcessUpdate( $jbstgId );
                }
                
                return $artMoveProduction;
                
            } catch (Exception $ex) {
               
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $ex );
        
                return false;
                
            }
            
            return false;
            
    }
    
    public function manualMovetoProduction(Request $request){
        
       $metadataID              =   $request->input('metaId');
		
		
        $masterId               =   $request->input('masterId');
		if($masterId =='? string:43 ?'){
			$masterId   = '';
		}
		
        $ceLevel                =   $request->input('categroy');
        if(empty($masterId)){
			$response['status'] = 0;
            $response['errMsg'] = 'Kindly select the Workflow';
            
            return response()->json($response);
		}

		if(empty($ceLevel)){
			$response['status'] = 0;
            $response['errMsg'] = 'Kindly select the CE Level';
            
            return response()->json($response);
		}
        
        
        
        $rounId                  =  !empty($request->input('rounId'))?$request->input('rounId'):'';
        $getchapters             =   taskLevelMetadataModel::getMetadatadetailsChapter($metadataID);
     
        $completedStatus         =   taskLevelMetadataModel::getCopyeditingcompletedByMetaidChpterNew($getchapters[0]->JOB_ID,$metadataID);
        $completedIndexStatus    =   taskLevelMetadataModel::getIndexingcompletedByMetaidChpterNew($getchapters[0]->JOB_ID,$metadataID);
         $completeartchapter     =   taskLevelMetadataModel::getArtcompletedChpterMetaid($getchapters[0]->JOB_ID,$metadataID);
       
        if(empty($completedStatus) && empty($completedIndexStatus) && count($completeartchapter) == 0){
            $response['status'] = 0;
            $response['errMsg'] = 'S5 CE, Art & INDEXING analysis not yet completed';
            
            return response()->json($response);
        }
        if(empty($completedStatus)){
            $response['status'] = 0;
            $response['errMsg'] = 'S5 CE input analysis not yet completed';
            
            return response()->json($response);
        }
        
        if(empty($completedIndexStatus)){
            $response['status'] = 0;
            $response['errMsg'] = 'S5 INDEXING analysis not yet completed';
            
            return response()->json($response);
        }
        
         if(count($completeartchapter) == 0){
            $response['status'] = 0;
            $response['errMsg'] = 'S5 ART analysis not yet completed';
            
            return response()->json($response);
        }
        
        if(!empty($masterId)) {
            $roundId                =    Config::get('constants.ROUND_NAME.S200');
            $jbr_obj             =   new jobRound();
            $roundInfo1          =   $jbr_obj->getjobRoundEntryExistByMetaId(  $metadataID , $roundId , null  );

            if( !empty( $roundInfo1 ) ){
               $response["status"]     =   0;
               $response['errMsg']     =  "Move to production already done.kindly conduct support team"; 
            }

           $updatedata         =   ["PRODUCTION_WORKFLOW"=>$masterId,"ARTICLE_CATEGORY"=>$ceLevel,"JOBSHEET_LESS"=>"1"];
           $wheredata          =   ['METADATA_ID'=>$metadataID];
           $updateeproof       =    DB::table('metadata_info')->where($wheredata)->update($updatedata);
        }
		$getchapters           = '';
		$getchapters             =   taskLevelMetadataModel::getMetadatadetailsChapter($metadataID);
        $noofquality             =   (count($getchapters)>=1?$getchapters[0]->NO_MSP:0);
        $chapRes                =   false; 
        
        $dataofproduction['JOB_ID']     =   (count($getchapters)>=1?$getchapters[0]->JOB_ID:0);
        $bookdata                       =   jobModel::getjobInfodetails($dataofproduction['JOB_ID']);
        
        if(empty($rounId))
            $dataofproduction['ROUND_ID']   =   Config::get('constants.ROUND_ID.S200');

        $metadataid =       $dataofproduction['META_ID']        =   $metadataID;
        
        $dataofproduction['QUANTITY']       =   $noofquality;
        $dataofproduction['WORKFLW_ID']     =   (empty($getchapters['0']->PRODUCTION_WORKFLOW)?Config::get('constants.S200_WORKFLOWID'):$getchapters['0']->PRODUCTION_WORKFLOW);
        $dataofproduction['USER_ID']        =   (count($bookdata)>=1?$bookdata->USER_ID:0);
       
        $jbr_obj             =   new jobRound();
      
        $roundInfo1          =           $jbr_obj->getjobRoundEntryExistByMetaId(  $metadataid , $dataofproduction['ROUND_ID']  , null  );
        $roundInfo2          =           $jbr_obj->getjobRoundEntryExistByMetaId(  $metadataid , $dataofproduction['ROUND_ID']  , 1  );
        $copyEditingLevel    =           $bookdata->COPY_EDITING_LEVEL;
        $embbedType          =           $bookdata->EMBBED_TYPE;
        $workflowMId         =           $bookdata->WORKFLOW_TYPE; 

        $parallelWorflowdata['parallelWrokflow']   =   array();

        if(!empty($getchapters['0']->PRODUCTION_WORKFLOW)){
            $workflowMId    =   $getchapters['0']->PRODUCTION_WORKFLOW;
        }
       
        if(!empty($workflowMId)){
            $customObj          =   new customizationModel();
            $workflowDetails    =   $customObj->getWorkflowAndStages($workflowMId);
            foreach($workflowDetails['workflow'] as $wfdata ){
                if($wfdata->WORKFLOW_TYPE == '0'){
                    $dataofproduction['WORKFLW_ID'] = $wfdata->WORKFLOW_ID;
                }elseif($wfdata->WORKFLOW_TYPE == '2'){
                    $parallelWorflowdata['parallelWrokflow'][]   =   $wfdata->WORKFLOW_ID;
                }
            }
        }
        
        

        if( empty( $roundInfo1 ) ){
            $chapRes            =   true;         
            $moveproductionurl  =   url('/').'/api/movetoproduction';
            $movepro            =   app('App\Http\Controllers\CommonMethodsController')->PostcUrlExecution( $dataofproduction , $moveproductionurl , 1 );
        }else{
            
            $response['status'] = 0;
            $response['errMsg'] = 'Already move to production done';
            
            return response()->json($response);
        }

         $whereCondi         =           array( 'METADATA_ID' => $metadataid);
         $taskartInfo        =           DB::table( 'task_level_art_metadata' )->select()->where( $whereCondi )->get()->toArray();
         $artRes             =          true;
        if( empty( $roundInfo2 ) && !empty($taskartInfo) ){

            $paralleWfid            =   Config::get('constants.S200_ART_WORKFLOWID');
            $roundNamearray         =   Config::get('constants.ROUND_NAME');
            $roundNamearray         =   Config::get('constants.ROUND_NAME');

            $roundName              =  $roundNamearray[$dataofproduction['ROUND_ID']];
            $dueDateDetais          =  json_decode($bookdata->STAGE_DEADLINES_COLLECTION);
            $duedate                =   date( 'Y-m-d H:i:s' );

           /* if(!empty($dueDateDetais->$roundName)){
                $duedate = str_ireplace('.','-',$dueDateDetais->$roundName);
                $duedate = date_format(date_create($duedate),"Y-m-d H:i:s");
            }*/

            if(!empty($parallelWorflowdata['parallelWrokflow'])){

                foreach($parallelWorflowdata['parallelWrokflow'] as $wfpId){
                    $paralleWfid        =   $wfpId;
                    $return_status      =   $this->artManualMovetoProduction( $dataofproduction['JOB_ID'], $dataofproduction['ROUND_ID'], $paralleWfid, $metadataid ,$duedate, $user='' );
                }

            }else{
               // echo $paralleWfid;exit;
                 $return_status      =   $this->artManualMovetoProduction( $dataofproduction['JOB_ID'], $dataofproduction['ROUND_ID'], $paralleWfid, $metadataid ,$duedate, $user=''  );
            } 
            
            if($return_status != true){
              $artRes       =   false;
            }
        }
        
        if($artRes == true && $chapRes == true){
            $response['status'] = 1;
            $response['errMsg'] = 'Successfully moved to production';
        }else{
            $response['status'] = 0;
            $response['errMsg'] = 'Unable to move production';
        }
        
            
            
            return response()->json($response);
    }
    
    public function artManualMovetoProduction($jobid, $roundid, $workflowid, $metaId, $duedate, $user ){
		
		$datetime 			= 	date("Y-m-d H:i:s"); 
		try {
                
                DB::beginTransaction();
                
		if(empty($user)) {
                   $user = Config::get('constants.ADMIN_USER_ID');
                }
		$sql1	 =  "SELECT 1 FROM metadata_status ms WHERE ms.metadata_id = $metaId AND ms.CURRENT_ROUND = $roundid AND ms.IS_ART=1";
                
                $metadata = DB::select( $sql1 );
                //echo "<pre>";print_r($metadata);exit;
		if(empty($metadata)){
		
			$metaTable      =   array('JOB_ID' => $jobid, 'METADATA_ID' => $metaId, 'CURRENT_ROUND' => $roundid,'DUE_DATE'=>$duedate, 'CURRENT_STATUS' => '46','LAST_MOD_DATE' => $datetime,'LAST_MOD_BY' =>$user,'IS_ART' => '1','RECEIVED_DATE'=>$datetime,'CURRENT_ITERATION'=>'1' );
                        $metaStatusId   =   DB::table('metadata_status')->insertGetId( $metaTable );
                       
			if($metaStatusId == ''){
                            DB::rollBack();
                            return false;
				//return 'Not able to store MetaData Status ';
			}
			
                        $metaTable      =   array('JOB_ID' => $jobid, 'METADATA_ID' => $metaId, 'METADATA_STATUS_ID'=>$metaStatusId,'DUE_DATE'=>$duedate,                            
                                                    'ROUND_ID' => $roundid, 'STATUS' => '27','ROUND_SEQ'=>'1','CREATED_DATE' => $datetime,'CREATED_BY' =>$user,'IS_ART' => '1');
			$autroundId   =   DB::table('job_round')->insertGetId( $metaTable );
			
			//$autroundId = mysql_insert_id();
		
			if($autroundId == ''){
				DB::rollBack();
				return false;
			}
			
			$sql3 = "INSERT INTO job_stage (job_round_id, workflow_master_id, workflow_id, workflow_type, stage_id, start_stage_id, end_stage_id, skip_enabled, STATUS, stage_seq)
									SELECT '.$autroundId.', t.WORKFLOW_MASTER_ID, t.WORKFLOW, t.WORKFLOW_TYPE, t.STAGE, t.START_STAGE, t.END_STAGE, t.SKIP_STAGE, 25, t.STAGE_SEQ
									FROM task_level_userdefined_workflow t
									WHERE t.JOB_ID = '".$jobid."' AND t.WORKFLOW = '".$workflowid."' AND t.ROUND = '".$roundid."'";
			DB::insert( $sql3 );
	
			$sql4           = "UPDATE job_stage s, job_round jr SET s.STATUS = 27, jr.CURRENT_STAGE = s.STAGE_ID WHERE jr.JOB_ROUND_ID = s.JOB_ROUND_ID AND s.JOB_ROUND_ID = '".$autroundId."' AND s.STAGE_SEQ = 1";
                        $updateTable2   = DB::update( $sql4 );
                        
                        $sql5           =   "select s.STAGE_ID from job_round as jr
                                                join job_stage as s ON jr.JOB_ROUND_ID = s.JOB_ROUND_ID
                                                WHERE jr.JOB_ROUND_ID = s.JOB_ROUND_ID AND s.JOB_ROUND_ID = '".$autroundId."' AND s.STAGE_SEQ = 1";
                        $stageRes       =   DB::select( $sql5 );
                       
			if(!empty($stageRes)){
				$currentStage	=   $stageRes['0']->STAGE_ID;
				$sql6           =   "update metadata_status as ms SET ms.CURRENT_STAGE = '".$currentStage."' where ms.CURRENT_ROUND = '".$roundid."' AND ms.METADATA_ID = '".$metaId."' AND ms.IS_ART=1";
                                DB::update( $sql6 );
			}
			
			$sql7   =   "update task_level_art_metadata as tam  SET tam.METADATA_STATUS_ID ='".$metaStatusId."',tam.CURRENT_STAGE ='".$currentStage."' ,tam.CURRENT_ROUND = '".$roundid."' where tam.METADATA_ID = '".$metaId."'";
			 DB::update( $sql7 );
		}else{
			  return false;
			
		}
			
		
		} catch (Exception $e) {
                    DB::rollBack();
                    echo "Have some error insterting to table";
                            echo $e->getMessage();
		
		}
                
		DB::commit();
                return true;
		
	}
    
    public function s600MoveToproduction( $jobId , $round = '119' , $metaid = null ){
        
        //S600 movetoproduction - art workflow yet to do
        
        $motoObj        =       new movetoproductionController();
        $jobM_obj       =       new jobModel();
        $tskLvlModel    =       new taskLevelMetadataModel();
        $jobDetai       =       $jobM_obj->getJobdetails( $jobId );
        $wfMdl          =       new workflowModel();
        
        //try{
        //covercreation 
        $duedate            =       date( 'Y-m-d H:i:s' );
        $metaid_arr         =       array();
        $workflowCoverid    =       \Config::get('constants.WORKFLOW.S600.MASTER_ID_COVER');
        $workflowfmcompo    =       \Config::get('constants.WORKFLOW.S600.MASTER_ID_FM');
        
        $user_info          =       Session::get('users');
        $userid             =       $user_info['user_id'];
        
        if(empty($userid)) {
            $userid         =       \Config::get('constants.ADMIN_USER_ID');
        }  
        
        $componentSupport   =       array( 
                                        \Config::get('constants.FM_ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_FM') , 
                                        \Config::get('constants.ARTICLE_CHAPTER') , 
                                        \Config::get('constants.ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_COVER') , 
                                    ); 
        
        if( !is_null( $metaid ) ){
            
            $metaid_arr     =       array( $metaid ); 
            
            //correction workflow
            $wfwmsrid       =       \Config::get('constants.WORKFLOW.S600.MASTER_ID_CORRECTION');
            
        }else{
            
            //need to enable s600 download based on chapters
            $chapter_enum     =       \Config::get( 'constants.CHAPTER_ENUM_ID' );
            $taskinfo         =       $tskLvlModel::where( 'JOB_ID' , '=' , $jobId  )
                                            ->where( 'UNIT_OF_MEASURE' , '=' , $chapter_enum )
                                            ->orderBy( 'CHAPTER_SEQ' , 'ASC' )->get();
            
            if( count( $taskinfo ) ){
                foreach( $taskinfo as $key => $metaobj ){
                    $metaid_arr[]   = ( $metaobj->METADATA_ID );
                }
            }
            //typesetting workflow
            $wfwmsrid       =       \Config::get('constants.WORKFLOW.S600.MASTER_ID_PAGINATION');        
            
        }
        
        //BASED ON CORRECTION FLAG NEED TO ENABLE
        $quanity         =       1;
        $wrftype         =       0;
        
        $worfkflow       =       $wfMdl->getWorkflosByMasterIdAndType( $wfwmsrid , $wrftype );
        $s600Workflow    =       $workflowid     =       $worfkflow->WORKFLOW_ID;
        
        $worfkflow2      =       $wfMdl->getWorkflosByMasterIdAndType( $workflowCoverid , $wrftype );
        $s600CvrWorkflow =       $workflowid2    =       $worfkflow2->WORKFLOW_ID;
        
        $worfkflow3      =       $wfMdl->getWorkflosByMasterIdAndType( $workflowfmcompo , $wrftype );
        $s600FmWorkflow =       $workflowid3    =       $worfkflow3->WORKFLOW_ID;
        
        $duedate         =       $this->getDueDate( $jobDetai , $round );
		
        $tsklvelCnt      =       new newComponentController();
        $newMetas        =       $tsklvelCnt->createDynamicComponents($jobId, $round);
        
        if( !empty( $newMetas ) ){
            $metaidCollect   =  array_merge( $metaid_arr , $newMetas );
        }else{
            $metaidCollect   =  $metaid_arr;
        }
        
        $metaidCollect      =       array_unique( $metaidCollect );
       
        foreach( $metaidCollect as $key => $value  ){
            
            $metaDetails       =       DB::table('metadata_info')->where( 'METADATA_ID' , '=' , $value  )->get();
            $workflowid        =       0;
            
            if( count( $metaDetails )){
                
                $metaDetails    =   $metaDetails[0];
                $quanity        =   isset( $metaDetails->END_PAGE ) ?  $metaDetails->END_PAGE  : 1;
                $covertype      =   \Config::get('constants.ARTICLE_COVER');
                $fmcomptyp      =   \Config::get('constants.ARTICLE_FM');
                
                if( $metaDetails->FM_ARTICLE_BM == $covertype || $metaDetails->FM_ARTICLE_BM == $covertype ){
                    $workflowid     =   $s600CvrWorkflow;
                }else if( $metaDetails->FM_ARTICLE_BM == $fmcomptyp || $metaDetails->FM_ARTICLE_BM == $fmcomptyp ){
                    $workflowid     =   $s600FmWorkflow;
                }else{
                    $workflowid     =   $s600Workflow;
                }

                if( in_array( $metaDetails->FM_ARTICLE_BM ,  $componentSupport ) ){
					
					
                    $response[]  =    $motoObj->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $value , $quanity , $duedate , $wrftype , $userid );
                }
            
            }else{
                
                $response[]     =   "This metaid ( $value ) skipped from movetoproduction process ";
                
            }
            
        }
        
        return $response;
        
    }
    
    public function getDueDate( $jobDetai , $round ){
        
        if( count( $jobDetai ) ){
            
            $deadline_array     =   json_decode( $jobDetai->STAGE_DEADLINES_COLLECTION , true );
            
            if(count($deadline_array)>=1){
                $getroundstage  =   \Config::get('constants.ROUND_NAME')[$round];
                $duedate    =       $deadline_array[$getroundstage];
            }else{
                $duedate    =       date("Y-m-d");
            }
            
        }else{
            $duedate        =       date("Y-m-d");     
        }
        if(empty( $duedate)){
			$duedate        =       date("Y-m-d");     
		}
        return $duedate;
    }
    
}