<?php
namespace App\Http\Controllers\production;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\projectModel;
use App\Models\productionLocationModel;
use App\Models\jobTimeSheet;
use App\Models\downloadModel;
use App\Models\bookinfoModel;
use App\Models\roundModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobStage;
use App\Models\jobRound;
use App\Models\jobResource;
use App\Models\jobWorkLogModel;
use App\Models\checkoutModel;
use App\Models\stageModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;

class projectBinController extends Controller
{   
    
    /**
     *  Create a new controller instance.
     *
     *  @return void
    */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }


    public function index(){

        $data               =   array();
        $data['pageTitle']  = 	'';
        $data['pageName']   =   '';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;

        // return view('project.-checkout')->with($data);

    }

    public function getProjectBinData( Request $request ){

        $data       =       array();
        $user_id    =       $this->loginUserId;
        $roleid     =       $this->roleId;
        $teamid     =       $this->teamId;
       
        $comp       =       0;
        $is_art     =       0;
        
        $is_manager =       (Session::get('users')['manager'] == ''?0:Session::get('users')['manager']);
        
        $teamUser   =       array();
        $teamid_arr =       explode( ',' , $teamid );
        $lo_operator        =        \Config::get('constants.LOGISTIC_OPERATOR');

        if( count( $teamid_arr > 1 ) )
            $teamid  = $teamid_arr;

        $jobid      =       $request->input('jobid');
        $round      =       $request->input('round');
        $stage      =       $request->input('stage');
        
        $other_operators    =       array(  
            \Config::get('constants.LOGISTIC_OPERATOR') , \Config::get('constants.COPY_EDITOR') 
        );
        
        $art_operators      =       array(
            \Config::get('constants.CREATIVE_ART') , \Config::get('constants.ART_REVIEWER') 
        );
        
        if( in_array( $roleid , $art_operators ) )
            $is_art = 1;
        
        $page_no    =       1;
        $limit      =       50;
        $stage      =   (empty($stage)?'null':$stage);
        $round      =   (empty($round)?'null':$round);
        if( $is_manager && false )
            $teamUser   =       projectModel::getUserListByTeam( $teamid  , 43 );
        if( (!empty( $round ) || !empty($stage)) && ($round != 'null' || $stage != 'null')){
            $proc_str   =       "call projectbin_with_filter( $jobid , $round  , $stage , $is_manager , $roleid  , $comp  , $is_art , $page_no , $limit )";
        }else{
            $proc_str   =       "call projectbin_new( $jobid , $is_manager , $roleid  , $comp  , $is_art , $page_no , $limit )";
        }
   
        $records['dt']          =       DB::select( $proc_str );
       
        $records['teamUser']    =       $teamUser;
        $records['is_manager']  =       $is_manager;
        
        return response()->json( $records );

    }

    public function projectBin( Request $request , $jobid = null , $statusCode  =   null ){
        $data       =       array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PRODUCTION_BIN'),$data);

        $roundinfo          =       roundModel::getAllRoundInfo();
        $roundOpt           =       '';

        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=       '<option value="'.($value['ID']).'">';
            $roundOpt      .=       $value['DESCRIPTION'];
            $roundOpt      .=       '</option>';
        }
        
        $stagequery         =   " select s.STAGE_ID,re.NAME as ROLENAME,s.STAGE_NAME from role_enum re join stage_role sr on sr.ROLE = re.ID join stage s on s.STAGE_ID = sr.STAGE where sr.ROLE = $this->roleId group by s.STAGE_ID order by  s.STAGE_NAME asc ";
        $stage_collect      =   DB::select( $stagequery );
        $stageOpt           =       '';
        foreach ( $stage_collect as $key => $value ){
            $stageOpt      .=  '<option  value="'.$value->STAGE_ID.'">';
            $stageOpt      .=  $value->STAGE_NAME;
            $stageOpt      .=  '</option>';
        }

        $projectCollect     =       array();
        $projectOpt         =       '';
        $projectCollect     =       bookinfoModel::getBookinfo();

        foreach( $projectCollect as $key => $value ){
            $projectOpt     .=      '<option  value="'.($value['JOB_ID']).'" >';
            $projectOpt     .=      $value['BOOK_ID'];
            $projectOpt     .=      '</option>';

        }
          
        $teamid     =       $teamid      =      $this->teamId;
        
        $operator_role                   =      \Config::get('constants.PM');
        $operator_role                   =       $this->roleId;
        
        $user_id        =       $this->loginUserId;
        
        $data['teamUser']                =      projectModel::getUserListByAssignedTeam( $teamid , $user_id );
        
        $data['roundCollect']            =      $roundOpt;
        $data['stageCollect']            =      $stageOpt;
        $data['projectCollect']          =      $projectOpt;
        
        
        if( !is_null( $jobid ) ){
            
            $data['redirectionProcess']['jobid']                    =       $jobid;
            
            if( !is_null( $statusCode ) ){
                //yet to convert status code to status message
                $data['redirectionProcess']['statusMsg']            =       $statusCode;
            }
        }
        
      
        $data['is_manager']         =       Session::get('users')['manager'] == ''?0:Session::get('users')['manager'];
        return view('projectbin.home')->with( $data );

    }
	public function processRollBack( Request $request ){
        $postData                   =       $request->all(); 
        extract( $postData );
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $errMsg                     =       '';
		$response['rollbacklist'] 	=  	[];

			try{
				$stageInfo        	=       projectModel::rollBackStages($JOB_STAGE_ID, $response);
				$response['rollbacklist'] 	=  	$stageInfo;
			} catch (\Exception $ex) {
				$response['errMsg']     =       $ex->getMessage();
				return response()->json( $response , 401 );
			}
			
			return response()->json( $response );

    }
	
	public function skipStage( Request $request ){
        $postData                   =       $request->all(); 
        extract( $postData );
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $errMsg                     =       '';

			try{
            $returns        =       projectModel::skipStage($STAGE_SEQ, $JOB_STAGE_ID, $INPUT_QUANTITY, $JOB_ROUND_ID,$ITERATION_ID, $response );
            if( $returns ){
                $response['status']     =       1;
                $response['msg']        =       'Process skipped successfully!';
            }

        } catch (\Exception $ex) {
            $response['errMsg']     =       $ex->getMessage();
            return response()->json( $response , 401 );
        }

        return response()->json( $response );

    }
	
    public function unlock( Request $request ){

        $postData                   =       $request->all(); 
        extract( $postData );
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );

        $response['errMsg']         =       'Failed to Unlock the '.strtolower( $metanaming );

        $user_id                    =       $this->loginUserId;
        $errMsg                     =       '';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );

        try{

            //try to check wheather it should be in manual stage.
            
            $returns        =       $this->unclockQueryStepbyStepExecution( $jobstageid  , $metaid ,  $response );
            
            if( $returns ){
                $response['status']     =       1;
                $response['msg']        =       'success';
                $response['errMsg']     =       'Successfully unlocked';
            }

        } catch (\Exception $ex) {
            $response['errMsg']     =       $ex->getMessage();
            return response()->json( $response , 401 );
        }

        return response()->json( $response );

    }

    public function unclockQueryStepbyStepExecution( $jbstg_id , $meta_id  , &$response ){
            
            //steps learned from old code 
            //step 1  :     delete jobstage entry
            //step 2  :     job stage available update
            //step 3  :     job round available update
            //step 4  :     get jobstage checkin time
            //step 5  :     get worklog entry
            //step 6  :     update worklog check in time
            //step 7  :     update_job_wrk_log By metaid
            //step 8  :     update task_level_metadata by metaid [ purpose is update current stage ]
            
            $available     =        \Config::get('constants.STATUS_ENUM_COLLEECTION.AVAILABLE');
            $time          =        date( 'Y-m-d H:i:s' );
            $jbRes_obj     =        new jobResource();
               
            $entryExist    =        $jbRes_obj->getJobResourceEntryByJobStageId( $jbstg_id );
            
            if( empty( $entryExist ) ){
                return false;
            }
                
            try{
                
                DB::beginTransaction();
                
                /* step 1 */
                $jbRes_obj->deleteByJobStageId( $jbstg_id );
                
                /* step 2 */
                $jbStg_obj     =        new jobStage();
                $setArr        =        array( 'STATUS' => $available );
                $jbStg_obj->updateIfExist(  $setArr , $jbstg_id  );
                   
                
                $recordof_js  = $jbStg_obj->getJobStageInfoByJobStageId(  $jbstg_id );
                
                /* step 3 */
                $jbRnd_obj         =        new jobRound();
                $setArr            =        array( 'STATUS' => $available );
                $jbRnd_obj->updateIfExist(  $setArr , $recordof_js->JOB_ROUND_ID  );
               
                /* step 4 */
                $jbstage_info       =       $jbStg_obj->getJobStageInfoByJobStageId( $jbstg_id , 'array' );
                $js_check_in        =       $jbstage_info['CHECK_IN'];

                /* step 5 */
                $jbwrkLog           =       new   jobWorkLogModel();
                $cusomCondition     =       array( 'CHECK_IN' => NULL );
                $jbwrkLogInfo       =       $jbwrkLog->getRecordsByJobStageId( $jbstg_id  , $cusomCondition );
               
                if( !empty( $jbwrkLogInfo ) ){
                    $jbwrkLogInfo = (array)$jbwrkLogInfo;
                    $pending            =       $jbwrkLogInfo['INPUT_QUANTITY'];
                    $batch_id_work_log  =       $jbwrkLogInfo['BATCH_ID'];
                    $check_out          =       $jbwrkLogInfo['CHECK_OUT'];
                    $worklog_id         =       $jbwrkLogInfo['JOB_WORK_LOG_ID'];

                    if( $js_check_in != '' && $batch_id_work_log != 0 ){
                        $check_in       =       $js_check_in;
                    }else if($batch_id_work_log != 0){
                        $check_in       =       $time;
                    }else{
                        $check_in       =       $check_out;
                    }

                    $update_Query         =        " UPDATE job_work_log SET CHECK_IN='".$check_in."' ";
                    $update_Query        .=        " , OUTPUT_QUANTITY='0',PENDING_QUANTITY='".$pending."'";
                    $update_Query        .=        " , REMARKS='Closed by CL~TL' where JOB_WORK_LOG_ID=".$worklog_id;

                    /* step 6 */
                    $update_workLog       =        DB::select( $update_Query );
                }
                
                /* step 7 */
               //if multi we need to update worklog with batch condition

                /* step 8 */
                $tsklev                  =        new taskLevelMetadataModel();
                $tsklev->updateCurrentStageColumfromJobRound( $meta_id );
                DB::commit();
                
                return true;

            }catch(\Exception $e){
                $response['errMsg']     =       $e->getMessage();
                DB::rollBack();
            }
            
            return false;
            
        }
   
    public function skiptheAssignedTask(  ){
        
    }
    
    public function assigningTaskToUser( Request $request ){
        
        $postData                   =      $request->all(); 
        extract( $postData );
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );
        $response['errMsg']         =       'Failed to assign '.strtolower( $metanaming );
        
        $user_id                    =       $this->loginUserId;
        $errMsg                     =       '';
        $time                       =       date("Y-m-d H:i:s");
        
         try{
             
             if( isset( $assign_to ) ){
                $postData['userTo']          =       $assign_to;
            }else{
                throw new Exception( 'Select user to assign a '.strtolower( $metanaming ) );
            }

            $jbr_obj                =       new jobResource();
            $stage_obj              =       new jobStage();
            $round_obj              =       new jobRound();
            $checkout_m             =       new checkoutModel();
            $isArtFlag              =       isset( $artMetaid ) ? 1 : 0;
            
            
            $resourceData           =       $jbr_obj->getJobResourceEntryByJobStageId( $jobstageid );
            $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $jobstageid );
           
            if( empty( $resourceData ) ){
                
                if( $isArtFlag ){
                    //insert batch table record
                    $batch_id       =       DB::table('batch')->insertGetId( array(   'CREATED_DATE' => $time , 'CREATED_BY' => $user_id ));
                    $postData['batchid']     =       $batch_id;
                }
            
                //Custom data feed for insert start               
                $postData['userBy']              =       $user_id;
                $postData['is_art']              =       $isArtFlag;
                $postData['time']                =       date('Y-m-d H:i:s');
                $teams                           =       explode( ',' ,  $this->teamId );
                $postData['team_id']             =       $teams[0];                
                //End Custom feed
                
                DB::beginTransaction();  
                
                $returns_jbre    =     $jbr_obj->buildInputAndinsertNewRecord( $postData );       
              
                if( $returns_jbre == 2 ){
                  
                  $in_progress      =     \Config::get('constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS');  
                  //update jobstage to inprogress : 23
                  $returns_jbs      =     $stage_obj->updateIfExist( array( 'STATUS' => $in_progress ) , $jobstageid );
                  $job_round_id     =     $jobStage_rec->JOB_ROUND_ID;
                  //update round to inprogress : 23 
                  $returns_jbr      =     $round_obj->updateIfExist( array( 'STATUS' => $in_progress ) , $job_round_id );

                }
                
              if( $returns_jbre && $returns_jbs && $returns_jbr ){
                DB::commit();
                $response['status']     =       1;
                $response['Msg']        =       'Success';
                $response['errMsg']     =       'Successfully assigned';
              }else{
                DB::rollback();
              }
              
            }else if( !empty( $resourceData ) ){
                
                $resourceid         =       $resourceData->JOB_RESOURCE_ID;
                $arr_update         =       array( 'ASSIGNED_TO' =>  $assign_to );
                
                if( !empty( $resourceid ) ){
                    
                    $returns        =       $jbr_obj->updateIfExist( $arr_update , $resourceid );
                    
                    if( $returns ){
                        
                        $response['status']     =       1;
                        $response['Msg']        =       'Success';
                        $response['errMsg']     =       'Successfully assigned , resource already exist.';
                    }
                    
                }else{
                    $response['errMsg']     =   'Resource assign primary key fetch failed';
                }
                
            }
            
         }catch(\Exception $e){
             
             $response['errMsg']        =       $e->getMessage();
             
             return response()->json( $response , 401 );
         }
         
         return response()->json( $response );
         
    }
    
    public function assigningMultipleTaskToUser( Request $request ){
        
        $requestData                =     json_decode( $request->getContent()); 
        $artMetaid                  =       1;
       
        $data                       =       array_filter($requestData->data);
       $assign_to                  =       $requestData->userid;
        $postData                   =       array();
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );
        $response['errMsg']         =       'Failed to assign '.strtolower( $metanaming );
        //echo "<pre>";print_r( Session::get('users'));exit;
        $user_id                    =       $this->loginUserId;
        $teamId                     =       $this->teamId;
        $errMsg                     =       '';
        $time                       =       date("Y-m-d H:i:s");
       // $assign_to                  =       $user_id;
         try{
             
             if( isset( $assign_to ) && $assign_to != '0' ){
                $postData['userTo']          =       $assign_to;
            }else{
                $response['errMsg']  = 'Select user to assign a '.strtolower( $metanaming );
                  return response()->json( $response );
                //throw new Exception( 'Select user to assign a '.strtolower( $metanaming ) );
            }

            $jbr_obj                =       new jobResource();
            $stage_obj              =       new jobStage();
            $round_obj              =       new jobRound();
            $checkout_m             =       new checkoutModel();
            $isArtFlag              =       isset( $artMetaid ) ? 1 : 0;
            $infoExit               =       array();
            $infoNew                =       array();
            $infoData               =       array();
            
           if(!empty($data)){
            foreach($data  as $key => $info){
                $splitArray     =   explode('_',$info);
               
                $infoData['job_id']        =   $splitArray['0'];
                $infoData['metadata_id']   =   $splitArray['1'];
                $infoData['round_id']      =   $splitArray['2'];
                $infoData['stage_id']      =   $splitArray['3'];
                $infoData['job_stage_id']  =   $splitArray['4'];
                $infoData['art_meta_id']   =   $splitArray['5'];
                
                $resourceData           =       $jbr_obj->getJobResourceEntryByJobStageId( $infoData['job_stage_id'] );
                
                if(!empty($resourceData)){
                    $infoExit[]        =   $resourceData->JOB_RESOURCE_ID;
                }else{
                    $infoNew[]          =   $infoData;
                }
            }
          $response['jobId']     =     $infoData['job_id'];
            if(!empty($infoNew)){
                
                
                 
                 $insertData              =     array();
                 $job_stageList           =     array();
                 $job_roundList           =     array();
                 foreach($infoNew as $key2=>$newData){
                    $batch_id                =       DB::table('batch')->insertGetId( array(   'CREATED_DATE' => $time , 'CREATED_BY' => $user_id ));
                    $res_ins_arr                    =   array();
                    $res_ins_arr['METADATA_ID']     =       $newData['metadata_id'];
                    $res_ins_arr['IS_ART']          =       '1';
                    $res_ins_arr['JOB_ID']          =       $newData['job_id'];
                    $res_ins_arr['ASSIGNED_TO']     =       $assign_to;
                    $res_ins_arr['TEAM_ID']         =       $teamId;
                    $res_ins_arr['JOB_STAGE_ID']    =       $newData['job_stage_id'];
                    $res_ins_arr['CREATED_BY']      =       $user_id;
                    $res_ins_arr['CREATED_DATE']    =       $time;  //date('Y-m-d H:i:s');
                    $res_ins_arr['ART_METADATA_ID'] =       $newData['art_meta_id'];
                    $res_ins_arr['METADATA_STATUS'] =       $newData['art_meta_id'];
                    $res_ins_arr['BATCH_ID']        =       $batch_id;
                    $insertData[]   =   $res_ins_arr;
                    
                    $job_stageList[]  =   $newData['job_stage_id'];
                    
                    $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $newData['job_stage_id'] );
                    $job_round_id           =       $jobStage_rec->JOB_ROUND_ID;
                    $job_roundList[]    =   $job_round_id;
                    
                 }
                
                 
                $res    =    DB::table('job_resource')->insert($insertData);
                $jobStageup['STATUS']       = '23';
                DB::table('job_stage')->whereIn('JOB_STAGE_ID',$job_stageList)->update($jobStageup);
                DB::table('job_round')->whereIn('JOB_ROUND_ID',$job_roundList)->update($jobStageup);
                
            }
            
            if(!empty($infoExit)){
                $resourceUp['ASSIGNED_TO']       = $assign_to;
                $res                             = DB::table('job_resource')->whereIn('JOB_RESOURCE_ID',$infoExit)->update($resourceUp);
            }
            
             $response['status']     =       1;
             $response['Msg']        =       'Success';
             $response['errMsg']     =       'Successfully assigned';
           }
            
        }catch(\Exception $e){
             
             $response['errMsg']        =       $e->getMessage();
             
             return response()->json( $response , 401 );
         }
         
         return response()->json( $response );
         
    }
	
	 public function assigningChaptersTaskToUser( Request $request ){
        
        $requestData                =     json_decode( $request->getContent()); 
        $artMetaid                  =       1;
        
        $data                       =       array_filter($requestData->data);
		$assign_to                  =       $requestData->userid;
        $postData                   =       array();
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );
        $response['errMsg']         =       'Failed to assign '.strtolower( $metanaming );
        //echo "<pre>";print_r( Session::get('users'));exit;
        $user_id                    =       $this->loginUserId;
        $teamId                     =       $this->teamId;
        $errMsg                     =       '';
        $time                       =       date("Y-m-d H:i:s");
       // $assign_to                  =       $user_id;
         try{
             
             if( isset( $assign_to ) && $assign_to != '0' ){
                $postData['userTo']          =       $assign_to;
            }else{
                $response['errMsg']  = 'Select user to assign a '.strtolower( $metanaming );
                  return response()->json( $response );
                //throw new Exception( 'Select user to assign a '.strtolower( $metanaming ) );
            }

            $jbr_obj                =       new jobResource();
            $stage_obj              =       new jobStage();
            $round_obj              =       new jobRound();
            $checkout_m             =       new checkoutModel();
            $isArtFlag              =       isset( $artMetaid ) ? 1 : 0;
            $infoExit               =       array();
            $infoNew                =       array();
            $infoData               =       array();
         
           if(!empty($data)){
            foreach($data  as $key => $info){
                $splitArray     =   explode('_',$info);
               
                $infoData['job_id']        =   $splitArray['0'];
                $infoData['metadata_id']   =   $splitArray['1'];
                $infoData['round_id']      =   $splitArray['2'];
                $infoData['stage_id']      =   $splitArray['3'];
                $infoData['job_stage_id']  =   $splitArray['4'];
                               
                $resourceData           =       $jbr_obj->getJobResourceEntryByJobStageId( $infoData['job_stage_id'] );
                
                if(!empty($resourceData)){
                    $infoExit[]        =   $resourceData->JOB_RESOURCE_ID;
                }else{
                    $infoNew[]          =   $infoData;
                }
            }
          $response['jobId']     =     $infoData['job_id'];
            if(!empty($infoNew)){
                // $batch_id                =       DB::table('batch')->insertGetId( array(   'CREATED_DATE' => $time , 'CREATED_BY' => $user_id ));
                
                 
                 $insertData              =     array();
                 $job_stageList           =     array();
                 $job_roundList           =     array();
                 foreach($infoNew as $key2=>$newData){
                    $res_ins_arr                    =   array();
                    $res_ins_arr['METADATA_ID']     =       $newData['metadata_id'];
                  //  $res_ins_arr['IS_ART']          =       '1';
                    $res_ins_arr['JOB_ID']          =       $newData['job_id'];
                    $res_ins_arr['ASSIGNED_TO']     =       $assign_to;
                    $res_ins_arr['TEAM_ID']         =       $teamId;
                    $res_ins_arr['JOB_STAGE_ID']    =       $newData['job_stage_id'];
                    $res_ins_arr['CREATED_BY']      =       $user_id;
                    $res_ins_arr['CREATED_DATE']    =       $time;  //date('Y-m-d H:i:s');
                    //$res_ins_arr['ART_METADATA_ID'] =       $newData['art_meta_id'];
                    //$res_ins_arr['BATCH_ID']        =       $batch_id;
                    $insertData[]   =   $res_ins_arr;
                    
                    $job_stageList[]  =   $newData['job_stage_id'];
                    
                    $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $newData['job_stage_id'] );
                    $job_round_id           =       $jobStage_rec->JOB_ROUND_ID;
                    $job_roundList[]    =   $job_round_id;
                    
                 }
                
                 
                $res    =    DB::table('job_resource')->insert($insertData);
                $jobStageup['STATUS']       = '23';
                DB::table('job_stage')->whereIn('JOB_STAGE_ID',$job_stageList)->update($jobStageup);
                DB::table('job_round')->whereIn('JOB_ROUND_ID',$job_roundList)->update($jobStageup);
                
            }
            
            if(!empty($infoExit)){
                $resourceUp['ASSIGNED_TO']       = $assign_to;
                $res                             = DB::table('job_resource')->whereIn('JOB_RESOURCE_ID',$infoExit)->update($resourceUp);
            }
            
             $response['status']     =       1;
             $response['Msg']        =       'Success';
             $response['errMsg']     =       'Successfully assigned';
           }
            
        }catch(\Exception $e){
             
             $response['errMsg']        =       $e->getMessage();
             
             return response()->json( $response , 401 );
         }
         
         return response()->json( $response );
         
    }
        
}