<?php
namespace App\Http\Controllers\checklist;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\stageModel;
use App\Models\instructionModel;
use App\Models\instructionLevelModel;
use App\Models\instructionEnumModel;
use App\Models\instructionAcceptStatementModel;
use App\Models\checkoutModel;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use App\Models\bookinfoModel;
use \App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\Api\autostageController;
use App\Models\productionLocationModel;
use Session;
use Config;
use Storage;
use Mail;
use Excel;
use Log;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
class checklistController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function index(Request $request){
        
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_CHECKLIST'),$data);
        $data['user_name']      =   $this->userName;
        $data['role_name']      =   $this->roleName;
        
        return view('checklist.checklist-setup-index')->with($data);
        
    }
    
    public function exIndex( Request $request , $jobid = null ){
        
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_CHECKLIST'),$data);
        $data['user_name']      =   $this->userName;
        $data['role_name']      =   $this->roleName;
         
        $booksinfo              =       bookinfoModel::getBookinfo();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'DESCRIPTION' ) ); 
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        $roundinfo              =       $roundinfo->whereNotIn('ID',[$round_arr['S5']]);
        $booksOpt               =       '';
        $roundOpt               =       '';
       
        $data['jobid']          =       $jobid;
        
        foreach ( $booksinfo as $key => $value ){
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
        }
        
        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=  '<option value="'.($value['ID']).'">';
            $roundOpt      .=  $value['DESCRIPTION'];
            $roundOpt      .=  '</option>';
        }
        
        $data['roundCollect']            =      $roundOpt;
        $data['bookidCollect']           =      $booksOpt;
        
        return view('checklist.client_list.index')->with($data);
        
    }
    
    public function getAllChecklistItem( Request $request ){
        
        $Req            =   (object) $request->input();
        
        $orderColumn    =   3;
        
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn    =   $Req->order[0]['column'];
        }

        $sorting        =   'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting    =   $Req->order[0]['dir'];
        }
            
        $start  =   '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start      =   $Req->start;
        }

        $length     =   false;
        if (isset($Req->length) && $Req->length != -1) {
            $length =   $Req->length;
        }

        $searchStr  =   '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr  =   trim($Req->search['value']);
        }
        
        $output  = array( 'ROUND' => '' , 'STAGE'  => '',  'COPYEDITING_LEVEL' => ''  , 'INSTRUCTIONLIST' => '' , 'MANDATORY'  => '', 'ACTION'  => '' );
        
        $returnarr  = array( $output );
        
       //return response()->json( $returnarr );
        
        $data                   =       instructionModel::showAllCheckListInstructions( $start , $length , $searchStr , $orderColumn , $sorting );
        
        $bookdata               =       array();
        $editdata               =       array();
        
        if(isset($data['checklistDetails']) && count($data['checklistDetails'])>=1){
            
            foreach ($data['checklistDetails'] as $key=>$row) {
                
                $tempArray                      =       array();
                
                $tempArray['STAGE_NAME']        =       $row->STAGE_NAME;
                $showauthorname                 =       ( $row->STAGE_NAME ==  "" ) ? $row->STAGE_NAME : $row->STAGE_NAME;
                $tempArray['ROUND_NAME']        =       $row->ROUND_NAME;
                $tempArray['LEVEL_NAME']        =       $row->LEVEL_NAME;
                $tempArray['INSTRUCTION']       =       $row->INSTRUCTION;
                $tempArray['MANDATORY_TYPE']    =       $row->MANDATORY_TYPE;
                
                $tempArray['ACTION']            =       '<div class="hidden-sm hidden-xs action-buttons">
                    
                                                            &nbsp;&nbsp;
                                                            <a class="green" style="cursor:pointer" ng-click="editChecklistItem( '.$row->INSTRUCTIONLEVEL_ID.' , '.$row->INSTRUCTION_ID.' , editobj )">
                                                                <i class="ace-icon fa fa-pencil bigger-130"></i>
                                                            </a> &nbsp;&nbsp;
                                                            
                                                            <a class="red" style="cursor:pointer" ng-click="removechecklistItem('.$row->INSTRUCTIONLEVEL_ID.' , '.$row->INSTRUCTION_ID.' )">
                                                                <i class="ace-icon fa fa-trash-o bigger-130"></i>
                                                            </a>'
                        
//                                                            <input type="hidden" id="editroundid_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->ROUND_ID.'" name="editroundid[]" ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'"/>
//                                                            <input type="hidden" id="editroundname_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->ROUND_NAME.'" name="editroundname[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'" />
//                                                            <input type="hidden" id="editstageid_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->STAGE_ID.'" name="editstageid[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'"/>
//                                                            <input type="hidden" id="editstagename_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->STAGE_NAME.'" name="editstagename[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'" />
//                                                            <input type="hidden" id="editinsCaptionTxt_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->STAGE_NAME.'" name="editinscaption[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'" />
//                                                            <input type="hidden" id="editinsCaptionid_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->STAGE_NAME.'" name="editinscaptionid[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'"/>
//                                                            <input type="hidden" id="editinslevelitem_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->INSTRUCTION.'" name="editinslevelite[]"  ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'"/>
//                                                            <input type="hidden" id="editmandatorytype_'.$row->INSTRUCTIONLEVEL_ID.'" value="'.$row->MANDATORY_TYPE.'" name="editmandatorytype[]" ng-model="editobj.editroundid_'.$row->INSTRUCTIONLEVEL_ID.'" />
                                                                

                                                        .'</div>';
                $temparra2[$row->INSTRUCTIONLEVEL_ID]      =       array(
                    'roundid'           =>  $row->ROUND_ID , 
                    'roundname'         =>  $row->ROUND_NAME , 
                    'roundstageid'      =>  $row->STAGE_ID , 
                    'roundstagename'    =>  $row->STAGE_NAME , 
                    'editinscaption'    =>  '' , 
                    'editinscaptionid'  =>  '' , 
                    'editinslevelite'   =>  $row->INSTRUCTION , 
                    'editmandatorytype' =>  $row->MANDATORY_TYPE , 
                );
                array_push( $bookdata , $tempArray );
                //array_push( $editdata , $temparra2 );
                
            }
            
        }
            
        $Response                       =   array();
        $Response["draw"]               =   $Req->draw;
        
        $Response["recordsTotal"]       =   ( isset( $data['checklistCount'] ) ? $data['checklistCount'] :  0 );
        $Response["recordsFiltered"]    =   ( isset( $data['checklistCount'] ) ? $data['checklistCount'] :  0 );
        
        $Response["data"]               =   $bookdata;
        //$Response["editdata"]               =  $editdata;
        
        return response()->json( $Response );
        
    }
    
    //establish laravel ftp connection
    public function dogetRoundstagelist(){
        
        $roundstage             =   app('App\Library\Services\RoundStageProcess')->dogetroundandstagedetails();
        $response               =   [];
        
        $data                   =   instructionModel::getInsructionitem();
        $response["stgaelist"]  =   $roundstage['stgaelist'];
        $response["roundlist"]  =   $roundstage['roundlist'];
        
        $response["levellist"]  =   instructionEnumModel::Active()->get();
        //$response["checklist"]  =   $data;
        
        $response["userId"]     =   Session::get('users')['user_id'];
        
        return response()->json($response);
        
    }
    
    public function doStorechecklist(Request $request)
    {      
    //try
    //{
            $validation     =   Validator::make($request->all(), [
                                                                        'roundmodel' => 'required|numeric' ,
                                                                        'stagemodel' => 'required|numeric' ,
                                                                        'levelmodel' => 'required|numeric' ,
                                                                        //'instruct_caption' => 'required'
                                                                ]);
            
            if( $validation->fails() ){
                
                $showerror          =   [];
                
                foreach ( $validation->messages()->all('<li>:message</li>' ) as $message ){
                    $showerror[]    =   $message;
                }
                $response   =   $this->validationResponse;
                $response['validation']     =   $showerror;
                return response()->json($response);
                
            }
            
            $roundid        =   trim( $request->input('roundmodel') );
            $stageid        =   trim( $request->input('stagemodel') );
            $levelid        =   trim( $request->input('levelmodel') );
            
            $checkIteminfo  =   $request->input( 'checkIteminfo' );
            $mandatorymodel =   $request->input( 'mandatorymodel' );
            
            $instructionCaption     =    $request->input( 'instruct_caption' );
            
            if( in_array( '' , $checkIteminfo) ) {
                $response   =   $this->validationResponse;
                return response()->json( $response );
                
            }
            
            //check round,stage and instruction level
            $getinstruction     =   instructionEnumModel::find( $levelid );
            $getrounddetails    =   roundModel::find( $roundid );
            $getstagedetails    =   stageModel::find( $stageid );
            
            if( count( $getinstruction ) >= 1 && count( $getrounddetails ) >= 1 && count( $getstagedetails ) >= 1 ){
                
                $wheredata      =   [ 
                    'STAGE_ID'          =>  $stageid , 
                    'ROUND_ENUM_ID'     =>  $roundid , 
                    'INSTRUCTION_TITLE'     => $instructionCaption 
                ];
                
                //check exist round,stage and level
                $existchecklistinfo     =   instructionModel::Active()->where( $wheredata )->first();
                
                if( count( $existchecklistinfo ) >= 1 ){
                    
                    DB::beginTransaction();
                    
                    foreach($checkIteminfo as $key => $valofitem)
                    {
                        
                        //check exist instruction
                        $checkexistinst     =   instructionModel::getreadInsructionroundstage($roundid,$stageid,$levelid,$valofitem);
                        
                        if( count( $checkexistinst ) >= 1 ){
                            
                            DB::rollback();
                            $response   =   $this->validationResponse;
                            $response['errMsg']   =   'Instruction is already exist '.$valofitem.' !';
                            $response['validation']     =   [];
                            return response()->json( $response );
                            
                        }
                        
                        $insertdata['INSTRUCTION_ID']       =   $existchecklistinfo->INSTRUCTION_ID;
                        $insertdata['INSTRUCTION_TYPE_ENUM_ID'] =   $levelid;
                        $insertdata['INSTRUCTION']          =   $valofitem;
                        $insertdata['MANDATORY_TYPE']       =   $mandatorymodel[$key];
                        $insertdata['CREATED_BY']           =   $this->loginUserId;
                        
                        $storehistory                       =   instructionLevelModel::insertGetId( $insertdata );
                        
                    }
                    
                    DB::commit();
                    
                    $data                   =   instructionModel::getInsructionitem();
                    
                    $response   =   $this->successResponse;
                    $response['checklist']   =   $data;
                    return response()->json($response);
                    
                }
                
                //new insert data
                DB::beginTransaction();
                
                $datainsert                     =   [];
                $datainsert['CUSTOMER_ID']      =   $this->loginUserId;
                $datainsert['ROUND_ENUM_ID']    =   $roundid;
                $datainsert['STAGE_ID']         =   $stageid;
                $datainsert['INSTRUCTION_TITLE']=   $instructionCaption;
                $datainsert['CREATED_DATE']     =   Carbon::now();
                $datainsert['CREATED_BY']       =   $this->loginUserId;
                
                $storeresponse                  =   instructionModel::insertGetId($datainsert);
                
                if( $storeresponse >= 1 ){
                    
                    foreach( $checkIteminfo as $key => $valofitem ){
                       
                        //check exist instruction
                        $checkexistinst     =   instructionModel::getreadInsructionroundstage($roundid,$stageid,$levelid,$valofitem);
                       
                        if(count($checkexistinst) >= 1 ){
                            
                            DB::rollback();
                            $response   =   $this->validationResponse;
                            $response['errMsg']   =   'Instruction is already exist '.$valofitem.' !';
                            $response['validation']     =   [];
                            return response()->json( $response );
                            
                        }
                        
                        $insertdata['INSTRUCTION_ID']       =   $storeresponse;
                        $insertdata['INSTRUCTION_TYPE_ENUM_ID'] =   $levelid;
                        $insertdata['INSTRUCTION']          =   $valofitem;
                        $insertdata['MANDATORY_TYPE']       =   $mandatorymodel[$key];
                        $insertdata['CREATED_BY']           =   $this->loginUserId;
                        $storehistory                       =   instructionLevelModel::insertGetId($insertdata);
                        
                    }
                    
                    DB::commit();
                }
                
                $data                   =   instructionModel::getInsructionitem();
                //$response["checklist"]  =   $data;
                $response   =   $this->successResponse;
                $response['checklist']   =   $data;
                return response()->json($response);
            }
            
            $response   =   $this->oopsErrorResponse;
            $response['validation']     =   [];
            return response()->json( $response );
//        }
//        catch(\Exception $e )
//        {
//            DB::rollback();
//            $response 	=	array('result'=>400,'errMsg'=>'Invalid data sending','validation'=>[]);
//            return response()->json($response);
//        }
    }
    
    public function doUpdateChecklist( Request $request ){
        
        try{
            $validation             =   Validator::make($request->all(), [
                                                    'instructionid'=> 'required' ,
                                                    'instructionlevelid'   => 'required' ,
                                                    'instruct_caption'     => 'required'  ,
                                                    'levelmodel'   => 'required' ,
                                                    'roundmodel' => 'required',
                                                    'stagemodel' => 'required' ,
                                                    'checkEditIteminfo' => 'required' 
                                                ]);
            
            if ($validation->fails())
            {
                $showerror          =   [];
                foreach ($validation->messages()->all('<li>:message</li>') as $message)
                {
                    $showerror[]    =   $message;
                }
                $response   =   $this->validationResponse;
                $response['validation']     =   $showerror;
                return response()->json($response);
            }
            
            $checklistId            =   $request->input('instructionlevelid');
            
            //check round,stage and instruction level
            $getinstruction         =   instructionLevelModel::getInsructionleveldata( $checklistId );
            
            if(count($getinstruction)>=1)
            {
                $instruction        =   trim($request->input('checkEditIteminfo'));
                $mandatorytype      =   trim($request->input('mandatorymodel'));
                $leveltype          =   trim($request->input('levelmodel'));
                $instruct_caption   =   trim($request->input('instruct_caption'));
                
                //check exist instruction
                $checkexistinst     =   instructionModel::getnotreadInsructionroundstage($getinstruction->ROUND_ENUM_ID,$getinstruction->STAGE_ID,$leveltype,$instruction,$checklistId);
                if(count($checkexistinst)>=1){
                    DB::rollback();
                    $response   =   $this->validationResponse;
                    $response['errMsg']   =   'Instruction is already exist '.$instruction.' !';
                    $response['validation']     =   [];
                    return response()->json( $response );
                }
                        
                //insert data
                DB::beginTransaction();
                $dataupdate                     =   [];
                $dataupdate['CUSTOMER_ID']      =   $this->loginUserId;
                $dataupdate['INSTRUCTION_TITLE']=   $instruct_caption;
                //$dataupdate['ROUND_ENUM_ID']    =   $roundid;
                //$dataupdate['STAGE_ID']         =   $stageid;
                $dataupdate['LAST_MOD_DATE']    =   Carbon::now();
                $dataupdate['LAST_MOD_BY']      =   $this->loginUserId;
                
                $updatechecklist                =   instructionModel::where('INSTRUCTION_ID',$getinstruction->INSTRUCTION_ID)->update($dataupdate);
                
                //update in instruction level table
                if($updatechecklist)
                {
                    $updatedata['INSTRUCTION']              =   $instruction;
                    $updatedata['INSTRUCTION_TYPE_ENUM_ID'] =   $leveltype;
                    $updatedata['MANDATORY_TYPE']           =   $mandatorytype;
                    $updatedata['UPDATED_BY']               =   $this->loginUserId;
                    instructionLevelModel::where('ID',$checklistId)->update($updatedata);
                    DB::commit();
//                    $proofrec   =   instructionModel::getInsructionIndividualItem($checklistId);
                    $response   =   $this->updatedResponse;
                    $response['validation']     =   [];
//                    $response['checklistitem']  =   $proofrec;
                    return response()->json($response);
                }
            }
            $response   =   $this->notfoundResponse;
            $response['validation']     =   [];
            $response['checklistitem']  =   "";
            return response()->json($response,400);
            
        }catch( \Exception $e ){
            DB::rollback();
            $response   =   $this->oopsErrorResponse;
            $response['validation']     =   [];
            return response()->json($response);
        }		
    }
    
    public function doChecklistReportDownload() 
    {
        $getinstruction             =   instructionModel::getdownloadInsructionitem();
        Excel::create('Checklist Reports', function($excel) use ($getinstruction) 
        {   $excel->setTitle('Checklist Reports');
            $excel->setCreator('vinoth')->setCompany('SPi Global');
            $excel->setDescription('Magnus Springer - Checklist Reports');
            $excel->sheet(date('Y-m-d').' Checklist Reports', function($sheet) use ($getinstruction) 
            {	
                $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                $sheet->setWidth(array(
                                        'A'     =>  15,
                                        'B'     =>  20,
                                        'C'     =>  20,
                                        'D'     =>  40,
                                        'E'     =>  20
                                ));
                $sheet->mergeCells('A1:E1');
                $sheet->cells('A1:E1', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#CACFD2');
                });
                $sheet->row(1, array('Checklist Reports'));
                //second row start 
                $sheet->cells('A2:E2', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontWeight('bold');	
                        $cells->setFontSize(10);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#CACFD2');
                });
                
                
                $sheet->row(2, array('Stage','Process','Level Type','Check list','Mandatory Type'));
                $t  = 	3;
                if(count($getinstruction)>=1)
                {
                    foreach($getinstruction as $key=>$parvalue)
                    {
                        $sheet->cells("A".$t.":A".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("B".$t.":B".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("C".$t.":C".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("D".$t.":D".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("E".$t.":E".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        
                        $sheet->row($t, array(
                                        $parvalue->ROUND_NAME,
                                        $parvalue->STAGE_NAME, 
                                        $parvalue->LEVEL_NAME,
                                        $parvalue->INSTRUCTION,
                                        $parvalue->MANDATORY_TYPE
                                    ));
                        $t++;
                        $avoidduplicatechapter  =   "";
                    }
                }					
            });			
        })->download('xlsx');
    }
    
    public function dogetundochecklist(Request $request){
       
        try{
            $response   =   $this->notfoundResponse;
            $response['checklistitem']  =   [];
            $validation     =   Validator::make($request->all(), [
                                                    'checklistid'   => 'required|numeric'
                                                ]);
            if ($validation->fails()){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $checklistid    =   $request->input('checklistid');
            $proofrec       =   instructionModel::getInsructionIndividualItem($checklistid);
           
            if($proofrec){
                $response   =   $this->successResponse;
                $response['errMsg']     =   'Undo';
                $response['checklistitem']     =   $proofrec;
                return response()->json($response);
                
            }
            return response()->json($response);
            
        }catch( \Exception $e ){
            return response()->json($this->oopsErrorResponse);
        }
        
    }
    
    public function doDelete(Request $request){
        
        try{
            $response   =   $this->notfoundResponse;
            $validation         =   Validator::make(  $request->all() , [
                                                        'checkitemid'   =>  'required|numeric' , 
                                                        'instrucitonid' =>  'required|numeric'
                                                ] );
            
            if ( $validation->fails() ){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
                
            }
            
            $getId              =       $request->input('checkitemid');
            $instrucitonid      =       $request->input('instrucitonid');
            
            $checklistcontent   =       instructionLevelModel::where('ID',$getId)->first();
            
            if( count( $checklistcontent ) >= 1 ){
                $deletesublevel     =   instructionLevelModel::where( 'ID' , $getId )->delete();
                //delete main instruction
                $maininstruction    =   instructionLevelModel::where('INSTRUCTION_ID',$instrucitonid)->get();
                
                if( count( $maininstruction )  ==  0 ){                    
                    instructionModel::where( 'INSTRUCTION_ID' , $instrucitonid )->delete();                    
                }
                return response()->json( $this->deletedResponse );
                
            }
            return response()->json($response);
            
            
        }catch( \Exception $e ){
            return response()->json($response);
            
        }
    }
    
    public function doReadChecklistReport(Request $request){
        
        //try{
            $response   =   $this->notfoundResponse;
            
           
            $validation         =   Validator::make($request->all(), [
                                                    'roundID'  => 'required|numeric',
                                                    'stageID'  => 'required|numeric',
                                                    'jobID'    => 'required|numeric',
                                                    'copylevel' => 'required',
                                                    'readtype' => 'required'
                                                ]);
            $jbstgid = null;
            $jobstg     =   $request->input( 'jbstgid' );
            
            if( isset( $jobstg ) ){
                
                $jbstgid    =   $request->input( 'jbstgid' );
                
            }
            
            if ($validation->fails() && is_null( $jbstgid )){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
                
            }
            
            if( is_null( $jbstgid ) ){
                
                $roundID            =   $request->input('roundID');
                $stageID            =   $request->input('stageID');
                $readtype           =   $request->input('readtype');
                $jobID              =   $request->input('jobID');
                $metadataID         =   $request->input('metadataID');
                $copylevel          =   $request->input('copylevel');
                
            }else{
                
                $chkOt_obj          =       new checkoutModel();
                $stageData          =       $chkOt_obj->getStageInfo( $jbstgid );
               
                if( count( $stageData ) ){
                    
                    $jbstg_rec          =       $stageData[0];
                    $roundID            =       $jbstg_rec->ROUND_ID;
                    $stageID            =       $jbstg_rec->STAGE_ID;
                    $readtype           =       2;
                    $jobID              =       $jbstg_rec->JOB_ID;
                    $metadataID         =       $jbstg_rec->METADATA_ID;
                    $jobData            =       jobModel::getJobdetails($jobID);
       
                    $copylevel          =       $jobData->COPY_EDITING_LEVEL;;
                    
                }else{
                    $response['errMsg'] =   'Invalid input given.';
                    return response()->json($response);
                }
                
            }
           
            $inputanaylsisvalidate  =   "NO";

            if( $stageID     ==  Config::get('constants.STAGE_COLLEECTION.CE_INPUT_ANALYSIS') ){
                
                $inputanaylsisvalidate              =       "YES";
                $cmn_obj                            =       new CommonMethodsController();
                $jb_object                          =       jobModel::getJobdetails( $jobID );
                $titleacronym                       =       ( count($jb_object) >=1 ? $jb_object->JOURNAL_ACRONYM : '' );

                //$queriesurl                         =   Config::get( 'constants.QMS_QUERIES_URL')."?TItleAcronym=".$titleacronym."&ChapterNo=".$chapterno;
                //$getqueriescount                    =   $cmn_obj->getcUrlExecution($queriesurl);
                //if(is_array($getqueriescount) && isset($getqueriescount[0])){
                //$queriescount                   =   $getqueriescount[0];
                //}
			}
			
            if(true){
                
                $inputanaylsisvalidate              =   "YES";
               
                $cmn_obj                            =   new CommonMethodsController();
                $jb_object                          =   jobModel::getJobdetails( $jobID );
                
                $titleacronym                       =   (count($jb_object)>=1?$jb_object->BOOK_ID:'');
                
                $metaModelObj                       =   new taskLevelMetadataModel();
                $chapterData                        =   $metaModelObj->getMetadatadetailsChapter($metadataID);
               
                if(count($chapterData) == 0){
                     $chapterData                        =   $metaModelObj->getMetadatadetailsChapterBook($metadataID);
                }    
                
                $chapterno                          =   $chapterData[0]->CHAPTER_NO; 
                
                $queriesurl                         =   Config::get( 'constants.QMS_QUERIES_URL')."?TItleAcronym=".$titleacronym."&ChapterNo=".$chapterno;
              
               $getqueriescount                    =   $cmn_obj->getcUrlExecution($queriesurl);
              
                if(is_array($getqueriescount) && isset($getqueriescount[0])){
                    $queriescount                   =   $getqueriescount[0];
                }

            }
            
            $instObj                    =       new instructionModel();
            
            $getinstruction             =       instructionModel::getInsructionroundstage( $roundID,$stageID,$copylevel );
            $getinstructionTitle        =       $instObj->getInsructionIdAndTitle( $roundID , $stageID , $copylevel );
            $getinstructionElemet       =       $this->getInsructionLevelInputsDesign( $roundID , $stageID , $copylevel );
            
            if( count( $getinstruction ) >=1 ){
                
                $mandatoryinstruction       =   [];
                $getmandatoryinstruction    =   $getinstruction->where('MANDATORY',1)->all();
                if(count($getmandatoryinstruction)>=1){
                    foreach($getmandatoryinstruction as $val){
                        $mandatoryinstruction[]  =   $val->ID;
                    }
                }
                
                $stagename      =   (isset($getinstruction[0]->STAGE_NAME)?$getinstruction[0]->STAGE_NAME:'');
                $roundname      =   (isset($getinstruction[0]->ROUND_NAME)?$getinstruction[0]->ROUND_NAME:'');
                $levelname      =   (isset($getinstruction[0]->LEVEL_NAME)?$getinstruction[0]->LEVEL_NAME:'');
                $levelid        =   (isset($getinstruction[0]->INSTRUCTION_TYPE_ENUM_ID)?$getinstruction[0]->INSTRUCTION_TYPE_ENUM_ID:'');
                
                $names          =   [
                                        'stagename'=>$stagename ,
                                        'roundname'=>$roundname , 
                                        'levelname'=>$levelname,
                                        'stageid'=>$stageID,
                                        'roundid'=>$roundID,
                                        'jobid'=>$jobID,
                                        'metadata'=>$metadataID,
                                        'levelid'=>$levelid
                                    ];
                
                $response       =   $this->successResponse;
                $response['errMsg']     =   'Read Instruction successfully';
                
                $response['instructionLevelArr']    =   $getinstructionElemet;
                $response['instructionarr']         =   $getinstructionTitle;
                $response['readinstruction']        =   $getinstruction;
                $response['readname']               =   $names;
                $response['mandatoryid']            =   $mandatoryinstruction;
                $response['inputanaylsisvalidate']  =   $inputanaylsisvalidate;
                $response['errMsg']     =   'Read Instruction successfully';
                
                
                return response()->json($response);
                
            }
            
            $names          =   ['stagename'=>'','roundname'=>'','levelname'=>'','stageid'=>'','roundid'=>'','jobid'=>'','metadata'=>'','levelid'=>''];
            $response       =   $this->successResponse;
            $response['errMsg']     =   'No Instruction found';
            $response['instructionLevelArr']    =   $getinstructionElemet;
            $response['instructionarr']         =   $getinstructionTitle;
            $response['readinstruction']        =   $getinstruction;
            $response['readname']               =   $names;
            $response['mandatoryid']            =   [];
            $response['inputanaylsisvalidate']  =   $inputanaylsisvalidate;
            return response()->json($response);
            
            //}catch( \Exception $e ){
              //  $result             =   array('result'=>401,'status'=>0,'errMsg'=>'Invalid data sending');   
              //  return response()->json($result);
            //}
    }
    
    public function getInsructionLevelInputsDesign( $roundid , $stageid, $copylevel ){ 
        
        $insobj                         =       new instructionModel();
        $getinstructionElemet           =       $insobj->getInstructionLevelInputs( $roundid , $stageid , $copylevel );
        
        $resultArr                      =       array();
        
        if( !empty( $getinstructionElemet ) ){
            
            foreach( $getinstructionElemet as $index => $value ){
                
                $designsec          =           '';
                $designsec          =           $this->designElements( $value );
                
                $resultArr["$value->INSTRUCTION_LEVEL_ID"]['design']      =           $designsec;
                $resultArr["$value->INSTRUCTION_LEVEL_ID"]['instid']         =           $value->INSTRUCTION_ID;
                $resultArr["$value->INSTRUCTION_LEVEL_ID"]['instlid']         =           $value->INSTRUCTION_LEVEL_ID;
                
            }
            
        }
        
        return $resultArr;
    }
    
    public function designElements( $value ){
    
        $elemetnDesign  =   '';
        
        switch( strtolower( $value->INPUT_ELEMENT ) ){
            
            case 'select' :
                
                $elemetnDesign   =   "<select name='$value->INSTRUCTION_LEVEL_ID'>";
                    $elemetnDesign  .=  '<option value="Y">Yes</option>';
                    $elemetnDesign  .=  '<option value="N" selected>No</option>';
                $elemetnDesign  .=   "</select>";
                
                break;
            
            case 'text' :
                
                $elemetnDesign        =     '<input type="text" value="" name="'.$value->INSTRUCTION_LEVEL_ID.'"/>';
                
                break;
                
        }
        
        return $elemetnDesign;
    }
    
    public function doSubmitChecklistValidate(Request $request) 
    {
        try{
            $response   =   $this->validationResponse;
            $validation         =   Validator::make($request->all(), [
                                                    'roundID'  => 'required|numeric',
                                                    'stageID'  => 'required|numeric',
                                                    'jobID'    => 'required|numeric',
                                                    'typeofinstruction'    => 'required',
                                                    'readtype' => 'required'
                                                ]);
            if ($validation->fails())
            {
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $wheredata          =   [];
            $roundID            =   $request->input('roundID');
            $stageID            =   $request->input('stageID');
            $readtype           =   $request->input('readtype');
            $jobID              =   $request->input('jobID');
            $typeofinstruction  =   $request->input('typeofinstruction');
            $instructionID      =   $request->input('instructionID');
            if(in_array('',$instructionID)) {
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $metadataID         =   "";
            if (Input::has('readtype') && $readtype     ==  "2")
            {
                if(empty($request->input('metadataID')))
                {
                    $response['errMsg'] =   'Metadata ID field is required';
                    return response()->json($response);
                }
                $metadataID         =   $request->input('metadataID');
                $wheredata['METADATA_ID']   =   $metadataID;
            }
            
            //check exist record 
            $wheredata['JOB_ID']    =   $jobID;
            $wheredata['ROUND_ID']  =   $roundID;
            $wheredata['STAGE_ID']  =   $stageID;
            $wheredata['USER_ID']   =   $this->loginUserId;
            $checkexistinstruction  =   instructionAcceptStatementModel::Active()->where($wheredata)->get();
            if(count($checkexistinstruction)>=1)
            {
                $updatedata         =   ['IS_ACTIVE'=>'0'];
                $where              =   ['JOB_ID'=>$jobID,'ROUND_ID'=>$roundID,'STAGE_ID'=>$stageID,'USER_ID'=>$this->loginUserId,'METADATA_ID'=>$metadataID];
                instructionAcceptStatementModel::where($where)->update($updatedata);
            }
            
            //insert data
            $insertinst             =   "";
            DB::beginTransaction();
            if(count($instructionID)>=1)
            {
                foreach($instructionID as $key=>$insID)
                {
                    $datainsert                     =   [];
                    $datainsert['JOB_ID']           =   $jobID;
                    $datainsert['ROUND_ID']         =   $roundID;
                    $datainsert['STAGE_ID']         =   $stageID;
                    $datainsert['USER_ID']          =   $this->loginUserId;
                    $datainsert['TYPE_OF_LEVEL']    =   ($readtype     ==  1?'1':'2');
                    $datainsert['INSTRUCTION__LEVEL_ID']    =   $insID;
                    if(!empty($metadataID)){
                        $datainsert['METADATA_ID']      =   $metadataID;
                    }
                    $datainsert['CREATED_BY']       =   $this->loginUserId;
                    $insertinst                     =   instructionAcceptStatementModel::insertGetId($datainsert);
                }
            }
            DB::commit();
            if($insertinst)
            {
                $response   =   $this->successResponse;
                $response['errMsg'] =   'Check list Readed successfully';
                return response()->json($response);
            }
            return response()->json($this->oopsErrorResponse);
        }catch( \Exception $e ){
            DB::rollback();
            return response()->json($this->oopsErrorResponse);
        }
    }
    
    public function getChecklistInstructionById( Request $request ){
        $response       =   $this->oopsErrorResponse;
        $validation     =   Validator::make(
                                $request->all() , [
                                'ilid'    =>    'required|numeric' ,
                                'insid'   =>    'required|numeric'
                            ]);
        
        if ($validation->fails()){
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            return response()->json($response);
        }
               
        $fetchrec       =       instructionLevelModel::getInsructionlevelChecklistById( $request->input( 'ilid' ) );
        
        if( count( $fetchrec ) ){
            
            $buildData['stageid']           =   $fetchrec->STAGE_ID;
            $buildData['stagename']         =   $fetchrec->STAGE_NAME;
            $buildData['roundid']           =   $fetchrec->ROUND_ID;
            $buildData['roundname']         =   $fetchrec->ROUND_NAME;
            $buildData['instruction']       =   $fetchrec->INSTRUCTION;
            
            $buildData['instructionlevelid']     =       $fetchrec->INSTRUCTIONLEVEL_ID;
            $buildData['instructionCaption']     =       $fetchrec->INSTRUCTION_TITLE;
            $buildData['instructionid']          =       $fetchrec->INSTRUCTION_ID;
            $buildData['copylevel']              =       $fetchrec->LEVEL_NAME;
            $buildData['mandatory']              =       $fetchrec->MANDATORY_TYPE_VALUE;
            $response       =   $this->successResponse;
            $response['errMsg']       =     'Record Found';
            $response['data']         =     $buildData;
            
        }
        
        return response()->json( $response );
        
    }
    
    public function getjoblevelExterchecklist( $jobid = null ){
        
        $result_arr         =       array( 'status' => 0 , 'msg' => 'Failed' , 'errMsg' => 'invalid try' );
            
        if( !is_null($jobid) ){
            
            $jobcategory        =       1;
            $result_arr2        =       array();
            $getCheckhead       =       DB::select( 'select ID  , CAPTION from external_checklist WHERE BOOKTYPE = '.$jobcategory.' AND IS_ACTIVE =1' );
            
            if( !empty( $getCheckhead ) ){
                
                foreach( $getCheckhead as $key => $value ){
                    
                    $chckgetid              =   $value->ID;
                    $getCheckQuery          =       DB::select( 'select ID, QUERIES , MANDATORY from external_checklist_queries WHERE CHECKLISTID = '.$chckgetid.' AND IS_ACTIVE =1' );
                    //$getCheckAnswe        =       DB::select( 'select *from external_answer WHERE BOOKTYPE = '.$jobcategory.' AND IS_ACTIVE =1' );
                    $result_arr2[$chckgetid]  =  array( 'caption' => $value->CAPTION , 'sub_queries' => array( 'list' => $getCheckQuery ) );
                    
                }
               
                $result_arr         =       array( 'status' => 1 , 'msg' => 'Success' , 'errMsg' => 'Success' , 'data' => $result_arr2 );
            }
            
        }
        
        return response()->json( $result_arr );
        
    }
    
    public function storeExternalChecklist( Request $request ){
        
        $checkedVal      =   $request->input( 'chckOpt' );
        $queryVal        =   $request->input( 'chkqryid' );
        $commentsVal     =   $request->input( 'coments' );
        $corrtnyn        =   $request->input( 'corrctn' );
        $madatoryfield   =   $request->input( 'chkoptmanda' );
        $jobid           =   $request->input( 'jobId' );
        $tbl             =      'external_checklist_answer';
        $round_arr       =       \Config::get('constants.ROUND_NAME');
        $roundid         =       $round_arr['S600'];
        $iteration       =      1;
        
        //step 1
        //do validation
        //step 2
        //check already present set us deactive
        //step 3
        //insert new record
        
        try{
            
        
            $recordsets    =       DB::select( "select count( JOB_ID ) , MAX( iteration ) as iteration from $tbl where JOB_ID=$jobid and ROUND_ID=$roundid group by job_id,round_id"  );
            
            
            if( count( $recordsets ) > 0 ){
                $iteration =   $recordsets[0]->iteration+1;
                DB::update( "update $tbl set is_active=0 where JOB_ID=$jobid and ROUND_ID=$roundid" );
            }

            $userid  = Session::get('users')['user_id'];
            $inser_array    =       array();
            $fieldValue     =       '';

            foreach( $corrtnyn as $key => $value ){

                $temp_prep       =    $inser_array[]        =   array(  
                                                                    'CHK_QS_ID' =>  $queryVal[$key], 'JOB_ID' => $jobid , 'ROUND_ID' => $roundid ,
                                                                    'IS_CHK' => $checkedVal[$key] , 'COMMENTS' => $commentsVal[$key] ,
                                                                    'CORRECTION' => $corrtnyn[$key] , 'CREATED_BY' => $userid, 
                                                                    'MODIFIED_BY' => $userid , 'created_at' => date('Y-m-d H:i:s') , 'updated_at' =>  date('Y-m-d H:i:s'), 
                                                                    'IS_ACTIVE' =>  1 , 'ITERATION' =>  $iteration
                                                                );

                $arr_val                     =		array_values( $temp_prep );
                $fieldValue                 .=          '(';
                $fieldValue                 .= 		"'".implode( "','" , $arr_val )."'";
                $fieldValue                 .=          ')';

                if( ( count( $corrtnyn ) - 1 ) !== $key ){
                    $fieldValue                 .=               ', ';
                }

            }

            $arr_key			=		array_keys( $temp_prep );
            $fieldName			= 		implode( "," , $arr_key );

            $queryStmt                  = 		"INSERT INTO $tbl ( $fieldName )  VALUES  $fieldValue ";	

            $returns                    =               DB::insert( $queryStmt );
            
            if( $returns ){
                
                $response['status']     =       1;
                $response['Msg']        =       'Success';
                $response['errMsg']     =       'Checklist information Successfully saved';
            
            }else{
                
                $response['status']     =       0;
                $response['Msg']        =       'failed';
                $response['errMsg']     =       'Insertion got failed';
            
            }
                
            $this->initiateChecklistPdfCreation( $request );
            
            return response()->json( $response );
            
        } catch (Exception $ex) {
            
            //print_r($e->getMessage());
           $response['status']     =       0;
           $response['Msg']        =       'failed';
           $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
           $err_handle     =       new errorController();
           //$err_handle->handleApplicationErrors( $e );
           
           return response()->json( $response );
            
        }
            
    }
    
    public function initiateChecklistPdfCreation( Request $request ){
    
        $checkedVal      =      $request->input( 'chckOpt' );
        $queryVal        =      $request->input( 'chkqryid' );
        $commentsVal     =      $request->input( 'coments' );
        $corrtnyn        =      $request->input( 'corrctn' );
        $madatoryfield   =      $request->input( 'chkoptmanda' );
        $jobid           =      $request->input( 'jobId' );
        $tbl             =      'external_checklist_answer';
        $round_arr       =       \Config::get('constants.ROUND_NAME');
        $roundid         =       $round_arr['S600'];
        $roundname       =       $round_arr[$roundid];
        $iteration       =      1;
              
        $response['status']     =       0;
        $response['Msg']        =       'failed';
        $response['errMsg']     =       '';
              
        try{
            
            $fileContent        =       $this->getTemplateStringOfCheckList(); 
            $xmlStr             =       $this->getTemplateStringOfCheckList(); 
            //$xmlStr           =       simplexml_load_string( $fileContent );
            
            $bookInfo           =       jobModel::getJobdetails( $jobid );
            $getlocationftp     =       productionLocationModel::doGetLocationname($jobid);
            $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostserver         =       $ftpInfo['HOST']            =       $getlocationftp->FTP_HOST;
            $ftpInfo['FTP_USERNAME']    =       $getlocationftp->FTP_USER_NAME;
            $ftpInfo['FTP_PASSWORD']    =       $hostpassword;

            $book_title       =       $bookInfo->JOB_TITLE;
            $isbn             =       $bookInfo->ISSN_ONLINE;
            $book_id          =       $bkid             =       $bookInfo->BOOK_ID;
         
        
            $select_query   =       "SELECT ecq.ID ,eca.ID as ansChkId , eca.JOB_ID , ecq.CHECKLISTID, eca.ROUND_ID ,ecq.QUERIES , eca.CHK_QS_ID , eca.IS_CHK , eca.CORRECTION , eca.COMMENTS , "
                    . " eca.APROVED_BY , concat( u.LAST_NAME ,'' , u.FIRST_NAME ) AS username , eca.updated_at from "
                    . " external_checklist_answer eca left join external_checklist_queries ecq on eca.CHK_QS_ID = ecq.ID"
                    . " left join user u on u.USER_ID = eca.CREATED_BY "
                    . " WHERE eca.JOB_ID=$jobid and eca.ROUND_ID=$roundid AND eca.IS_ACTIVE = 1 and eca.ITERATION IN ("
                    . "  select max( eca.ITERATION ) from external_checklist_answer ac2 where ac2.JOB_ID = eca.JOB_ID AND ac2.ROUND_ID = eca.ROUND_ID  order by ac2.ID desc "
                    . ")";
            
            $corrtnarray     =       DB::select( $select_query  );
            
            if( count( $corrtnarray ) > 0 ){
                //$iteration =   $recordsets[0]->iteration+1;
                //DB::update( "update $tbl set is_active=0 where JOB_ID=$jobid and ROUND_ID=$roundid" );
            }

            $userid         =       Session::get('users')['user_id'];
            $inser_array    =       array();
            $fieldValue     =       '';
            
            $replace_arr        =       array(  
                                                '{BTITLE}'  => $book_title, '{ISBN0}' => $isbn , '{DD}'  => date( 'd' ) , 
                                                '{MONTH}'   => date( 'M' ) , ', {YEAR}' => ' '.date('Y') 
                                        );
            
            $autoincG   =   0;
            $autoincQ   =   0;
            $autoincP   =   0;
            $autoincC   =   0;
            $autoincE   =   0;
            $autoincM   =   0;
            $autoincCon =   0;
            
            foreach( $corrtnarray as $key => $value ){

                $checkedopt     =       ( $value->IS_CHK == 0 ) ? 'No' : 'Yes' ;
                
                if( $value->CORRECTION == 'Y' ){
                    $correction = 'YES';
                }else if( $value->CORRECTION == 'N' ){
                    $correction = 'NO';
                }else{
                    $correction = 'N/A';
                }
                
                $comments       =       addslashes( $value->COMMENTS );
                $username       =       $value->username;
                $queryid        =       $value->CHK_QS_ID; 
                $checkPid       =       $value->CHECKLISTID;
                $queries        =       $value->QUERIES;
                
                if( $checkPid == 1 ){
                    $autoincG++;
                    $autoincPrint  = $autoincG;  
                }if( $checkPid == 2 ){
                    $autoincQ++;
                    $autoincPrint  = $autoincQ;  
                }if( $checkPid == 3 ){
                    $autoincP++;
                    $autoincPrint  = $autoincP;  
                }if( $checkPid == 4 ){
                    $autoincC++;
                    $autoincPrint  = $autoincC;  
                }if( $checkPid == 5 ){
                    $autoincE++;
                    $autoincPrint  = $autoincE;  
                }if( $checkPid == 6 ){
                    $autoincM++;
                    $autoincPrint  = $autoincM;  
                }if( $checkPid == 7 ){
                    $autoincCon++;
                    $autoincPrint  = $autoincCon;  
                }
                
                $date           =       date_create("$value->updated_at");
                $datetimeformat =       date_format(  $date , "d/m/Y H:i:s"  );
                $replace_arr[ "{CHKQRY_$checkPid"."_$autoincPrint}" ] =   $queries;
                $replace_arr[ "{LOCATION}" ] =   'pondicherry';
                $replace_arr[ "{ANWERATTRIBUTE_$checkPid"."_$autoincPrint}" ] = ' ckvalue="'.$checkedopt.'" date="'.$datetimeformat.'" nameofapprover="'.$username.'" correct="'.$correction.'" ';
                   
            }
            
            $cmn_obj             =       new CommonMethodsController(); 
            $bg_Obj              =       new bgprocessController();    
            //$xmlStr            =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $replace_arr );
            $xmlStr              =       $cmn_obj->arr_key_value_replace( $replace_arr , $xmlStr );
            $xmlStr		 =	 str_replace( '&' , '&amp;' , $xmlStr ); 
            $autoStgObj          =       new autostageController();
            $filename            =       $bkid.'_ChecklistMeta.xml';
            
            $whereToWrite        =       \Config::get( 'constants.CHECKLISTXML_PATH' );
            $checkTempath        =       \Config::get( 'constants.CHECKLISTTEMP_PATH' );
            $checkPDFpath        =       \Config::get( 'constants.CHECKLISTPDF_PATH' );
            
            $errorstr            =       '';
            $inp_rep_arr            =       array( 
                                'BOOK_ID'       =>      $book_id  ,   'RNAME'    =>      $roundname   ,
                                '{BID}'         =>      $book_id  ,   '{RID}'         =>      $roundname   ,
                            );
            
            $whereToWrite       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $whereToWrite );
            
            $whereToWrite2      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$whereToWrite.'{BID}_ChecklistMeta.xml' );
            $checkPDFpath       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$checkPDFpath );
            $checkTempath       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$checkTempath );
            $whereToWrite2      =       $cmn_obj->backslashPathPrepare( $whereToWrite2 , true );
            $checkPDFpath       =       $cmn_obj->backslashPathPrepare( $checkPDFpath , true );
            $checkTempath       =       $cmn_obj->backslashPathPrepare( $checkTempath , true );
            
            $postMetaStatus     =       $autoStgObj->writeMetafiletoWatchFolder( $filename , $xmlStr , $ftpInfo , $whereToWrite , $errorstr );
        
            if( $postMetaStatus ){
                
                $templatename               =       $checkTempath."FSV_Book_PDF_Quality_checklist.pdf";
                
                $inputforService['input']   =       array(  
                                                        'PdfChecklistInFile' =>  $checkTempath , 
                                                        'PdfChecklistOutputFile' =>  $checkPDFpath,
                                                        'MetadataXMLFile' =>  $whereToWrite2
                                                    );
                
                //$response_res       =       $this->executeCheckListPDFWebservice( $inputforService );
                
                $response['status']     =       1;
                $response['Msg']        =       'Success';
                $response['errMsg']     =       'Information saved successfully';
                
                return response()->json( $response );
                
            }else{
                
                $response['errMsg'] =   'checklist Meta xml creation got failed';
                
            }
            
            return response()->json( $response );
            
        } catch (Exception $ex) {
            
            //print_r($e->getMessage());
           $response['status']     =       0;
           $response['Msg']        =       'failed';
           $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
           $err_handle     =       new errorController();
           $err_handle->handleApplicationErrors( $e );
           
           return response()->json( $response );
            
        }
        
    }
    
    public function previewChecklistpdf( Request $request ){
        
        $jobid      =       $request->input( 'jobId' );
        
        $checkedVal      =      $request->input( 'chckOpt' );
        $queryVal        =      $request->input( 'chkqryid' );
        $commentsVal     =      $request->input( 'coments' );
        $corrtnyn        =      $request->input( 'corrctn' );
        $madatoryfield   =      $request->input( 'chkoptmanda' );
        
        $jobid           =      $request->input( 'jobId' );
        $tbl             =      'external_checklist_answer';
        $round_arr       =       \Config::get('constants.ROUND_NAME');
        
        $roundid         =       $round_arr['S600'];
        $roundname       =       $round_arr[$roundid];
        $iteration       =      1;
              
        $response['status']     =       0;
        $response['Msg']        =       'failed';
        $response['errMsg']     =       '';
              
        try{
            
            $fileContent        =       $this->getTemplateStringOfCheckList(); 
            $xmlStr             =       $this->getTemplateStringOfCheckList(); 
            //$xmlStr           =       simplexml_load_string( $fileContent );
            
            $bookInfo         =       jobModel::getJobdetails( $jobid );
            $getlocationftp   =       productionLocationModel::doGetLocationname($jobid);
            $hostpassword     =       Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
            
            $hostserver                 =       $ftpInfo['HOST']            =       $getlocationftp->FTP_HOST;
            $ftpInfo['FTP_USERNAME']    =       $getlocationftp->FTP_USER_NAME;
            $ftpInfo['FTP_PASSWORD']    =       $hostpassword;

            $book_title       =       $bookInfo->JOB_TITLE;
            $isbn             =       $bookInfo->ISSN_ONLINE;
            $book_id          =       $bkid             =       $bookInfo->BOOK_ID;
         
        
            $select_query   =       "SELECT ecq.ID ,eca.ID as ansChkId , eca.JOB_ID , ecq.CHECKLISTID, eca.ROUND_ID ,ecq.QUERIES , eca.CHK_QS_ID , eca.IS_CHK , eca.CORRECTION , eca.COMMENTS , "
                    . " eca.APROVED_BY , concat( u.LAST_NAME ,'' , u.FIRST_NAME ) AS username , eca.updated_at from "
                    . " external_checklist_answer eca left join external_checklist_queries ecq on eca.CHK_QS_ID = ecq.ID"
                    . " left join user u on u.USER_ID = eca.CREATED_BY "
                    . " WHERE eca.JOB_ID = $jobid and eca.ROUND_ID = $roundid AND eca.IS_ACTIVE = 1 and eca.ITERATION IN ("
                    . "  select max( eca.ITERATION ) from external_checklist_answer ac2 where ac2.JOB_ID = eca.JOB_ID AND ac2.ROUND_ID = eca.ROUND_ID  order by ac2.ID desc "
                    . ")";
            
            $corrtnarray     =       DB::select( $select_query  );
            
            
            if( count( $corrtnarray ) > 0 ){

            $userid         =       Session::get('users')['user_id'];
            $inser_array    =       array();
            $fieldValue     =       '';
            
            $replace_arr        =       array(  
                                            '{BTITLE}'  => $book_title, '{ISBN0}' => $isbn , '{DD}'  => date( 'd' ) , 
                                            '{MONTH}'   => date( 'M' ) , ', {YEAR}' => ' '.date('Y') 
                                        );
            
            $autoincG   =   0;
            $autoincQ   =   0;
            $autoincP   =   0;
            $autoincC   =   0;
            $autoincE   =   0;
            $autoincM   =   0;
            $autoincCon =   0;
            
                foreach( $corrtnarray as $key => $value ){

                    $checkedopt     =       ( $value->IS_CHK == 0 ) ? 'No' : 'Yes' ;

                    if( $value->CORRECTION == 'Y' ){
                        $correction = 'YES';
                    }else if( $value->CORRECTION == 'Y' ){
                        $correction = 'NO';
                    }else{
                        $correction = 'N/A';
                    }

                    $comments       =       addslashes( $value->COMMENTS );
                    $username       =       $value->username;
                    $queryid        =       $value->CHK_QS_ID; 
                    $checkPid       =       $value->CHECKLISTID;
                    $queries        =       $value->QUERIES;

                    if( $checkPid == 1 ){
                        $autoincG++;
                        $autoincPrint  = $autoincG;  
                    }if( $checkPid == 2 ){
                        $autoincQ++;
                        $autoincPrint  = $autoincQ;  
                    }if( $checkPid == 3 ){
                        $autoincP++;
                        $autoincPrint  = $autoincP;  
                    }if( $checkPid == 4 ){
                        $autoincC++;
                        $autoincPrint  = $autoincC;  
                    }if( $checkPid == 5 ){
                        $autoincE++;
                        $autoincPrint  = $autoincE;  
                    }if( $checkPid == 6 ){
                        $autoincM++;
                        $autoincPrint  = $autoincM;  
                    }if( $checkPid == 7 ){
                        $autoincCon++;
                        $autoincPrint  = $autoincCon;  
                    }

                    $date           =       date_create("$value->updated_at");
                    $datetimeformat =       date_format(  $date , "d/m/Y H:i:s"  );
                    $replace_arr[ "{CHKQRY_$checkPid"."_$autoincPrint}" ] =   $queries;
                    $replace_arr[ "{LOCATION}" ] =   'pondicherry';
                    $replace_arr[ "{ANWERATTRIBUTE_$checkPid"."_$autoincPrint}" ] = ' ckvalue="'.$checkedopt.'" date="'.$datetimeformat.'" nameofapprover="'.$username.'" correct="'.$correction.'" ';

                }

                $cmn_obj             =       new CommonMethodsController(); 
                $bg_Obj              =       new bgprocessController();    
                $xmlStr              =       $cmn_obj->arr_key_value_replace( $replace_arr , $xmlStr );
                $xmlStr              =       str_replace( '&' , '&amp;' , $xmlStr ); 
                
                $autoStgObj          =       new autostageController();
                $filename            =       $bkid.'_ChecklistMeta.xml';

                $whereToWrite        =       \Config::get( 'constants.CHECKLISTXML_PATH' );
                $checkTempath        =       \Config::get( 'constants.CHECKLISTTEMP_PATH' );
                $checkPDFpath        =       \Config::get( 'constants.CHECKLISTPDF_PATH' );

                $errorstr            =       '';
                $inp_rep_arr         =       array( 
                                                    'BOOK_ID'       =>      $book_id  ,   'RNAME'    =>      $roundname   ,
                                                    '{BID}'         =>      $book_id  ,   '{RID}'         =>      $roundname   ,
                                             );

                $whereToWrite        =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $whereToWrite );

                $whereToWrite2       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$whereToWrite.'{BID}_ChecklistMeta.xml' );
                $checkPDFpath        =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$checkPDFpath );
                $checkTempath        =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').$checkTempath );

                $whereToWrite2       =       $cmn_obj->backslashPathPrepare( $whereToWrite2 , true );
                $checkPDFpath        =       $cmn_obj->backslashPathPrepare( $checkPDFpath , true );
                $checkTempath        =       $cmn_obj->backslashPathPrepare( $checkTempath , true );
                //$postMetaStatus      =       $autoStgObj->writeMetafiletoWatchFolder( $filename , $xmlStr , $ftpInfo , $whereToWrite , $errorstr );

                if( true ){

                    $templatename               =       $checkTempath."FSV_Book_PDF_Quality_checklist.pdf";
                    $inputforService['input']   =       array(  'PdfChecklistInFile' =>  $checkTempath , 'PdfChecklistOutputFile' =>  $checkPDFpath, 'MetadataXMLFile' =>  $whereToWrite2 );
                    
                    //dd( $inputforService );

                    $response_res       =       $this->executeCheckListPDFWebservice( $inputforService );

                    $response['status']     =       1;
                    $response['Msg']        =       'Success';
                    
                    if( $response_res['status'] == 1 ){                        
                        $response['errMsg']     =    'Pdf created successfully';                        
                    }
                    
                    if( $response_res['status'] == 0 ){                        
                        $response_res['status'] =       0;
                        $response['Msg']        =       'failed';
                        $response['errMsg']     =       'Pdf creation got failed';                        
                    }
                    
                    return response()->json( $response );
                    
                }else{

                    $response['errMsg'] =   'checklist Meta xml creation got failed';

                }

            }else{
                
                $response['errMsg']  = 'Records not found to initiate pdf creation';
            }
            
            return response()->json( $response );
            
            
        } catch (Exception $ex) {
            
           $response['status']     =       0;
           $response['Msg']        =       'failed';
           $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
           $err_handle     =       new errorController();
           $err_handle->handleApplicationErrors( $e );
           
           return response()->json( $response );
            
        }
        
        
        
    }
    
    public function executeCheckListPDFWebservice( $serviceinfo ){
        
          
        $methodname         =       'PdfCheckListXML';
        $outputparameter    =       'PdfCheckListXMLResult';
        
        
        $inputData          =       array( 'data' => $serviceinfo );
        
        $urlpath            =       \Config::get( 'constants.PSTVTWINOVER_SOAP_SERVER_PATH' );
        $urlpath            =       explode( '?' , $urlpath );
        
        $serviceurl         =       $urlpath[0];
        $cmnobj             =       new CommonMethodsController();
        echo $callurl            =       $serviceurl.'/'.$methodname;
        exit;
        $returcurl          =       $cmnobj->callService( $serviceinfo['input'] ,  $callurl , 'json' );
        //$returcurl        =       json_decode( $returcurl , TRUE);
        //$response['inputgiven']     =   $serviceinfo['input'];

        if( !empty($returcurl) ){

            $response['status']     =   1;
            $response['msg']        =   'success';
            $statustext             =   $returcurl["$outputparameter"];

            if( !empty( $statustext ) ){
                $response['errMsg']     =   $returcurl["$outputparameter"];
                if( strtolower( $statustext ) !== 'success' ) {
                   $response['status']     =   0; 
                   $response['msg']        =   'failed';
                }
            }else{
                $response['errMsg'] =   '';
            }

        }else{
            $response['status']         =       0;
            $response['msg']            =       'failed';
            $response['errMsg']         =       'Webservice execution got failed';
        }

        return $response;
        
    }
    
    public function getTemplateStringOfCheckList(){
        
        $xmlstring  = '<PdfCheckList>
                <BookTitle title="{BTITLE}" id="Text Field 2" />
                <ISBN isbn="{ISBN0}" id="Text Field 3" />
                <General id="C4,Combo Box 103,Text Field 107,Text Field 108" info="{CHKQRY_1_1}" {ANWERATTRIBUTE_1_1}/>
                <General id="C5,Combo Box 104,Text Field 109,Text Field 1010" info="{CHKQRY_1_2}" {ANWERATTRIBUTE_1_2}/>
                <General id="C6,Combo Box 105,Text Field 1011,Text Field 1012" info="{CHKQRY_1_3}" {ANWERATTRIBUTE_1_3}/>
                <QualityOfFigure id="C8,Combo Box 107,Text Field 1015,Text Field 1016" info="{CHKQRY_2_1}" {ANWERATTRIBUTE_2_1}/>
                <QualityOfFigure id="C9,Combo Box 108,Text Field 1017,Text Field 1018" info="{CHKQRY_2_2}" {ANWERATTRIBUTE_2_2}/>
                <QualityOfFigure id="C10,Combo Box 109,Text Field 1019,Text Field 1020" info="{CHKQRY_2_3}" {ANWERATTRIBUTE_2_3}/>
                <QualityOfFigure id="C11,Combo Box 1010,Text Field 1021,Text Field 1022" info="{CHKQRY_2_4}" {ANWERATTRIBUTE_2_4} />
                <QualityOfFigure id="C12,Combo Box 1011,Text Field 1023,Text Field 1024" info="{CHKQRY_2_5}" {ANWERATTRIBUTE_2_5}/>
                <QualityOfFigure id="C13,Combo Box 1012,Text Field 1025,Text Field 1026" info="{CHKQRY_2_6}" {ANWERATTRIBUTE_2_6}/>
                <QualityOfFigure id="C14,Combo Box 1013,Text Field 1027,Text Field 1028" info="{CHKQRY_2_7}" {ANWERATTRIBUTE_2_7}/>
                <QualityOfFigure id="C15,Combo Box 1014,Text Field 1029,Text Field 1030" info="{CHKQRY_2_8}" {ANWERATTRIBUTE_2_8}/>
                <QualityOfFigure id="C16,Combo Box 1015,Text Field 1031,Text Field 1032" info="{CHKQRY_2_9}" {ANWERATTRIBUTE_2_9}/>
                <QualityOfFigure id="C17,Combo Box 1016,Text Field 1033,Text Field 1034" info="{CHKQRY_2_10}" {ANWERATTRIBUTE_2_10}/>
                <QualityOfFigure id="C18,Combo Box 1017,Text Field 1035,Text Field 1036" info="{CHKQRY_2_11}" {ANWERATTRIBUTE_2_11}/>
                <QualityOfFigure id="C19,Combo Box 1018,Text Field 1037,Text Field 1038" info="{CHKQRY_2_12}" {ANWERATTRIBUTE_2_12}/>
                <PrintPDF id="C20,Combo Box 1019,Text Field 1039,Text Field 1040" info="{CHKQRY_3_1}" {ANWERATTRIBUTE_3_1}/>
                <PrintPDF id="C21,Combo Box 1020,Text Field 1041,Text Field 1042" info="{CHKQRY_3_2}" {ANWERATTRIBUTE_3_2}/>
                <PrintPDF id="C22,Combo Box 1021,Text Field 1043,Text Field 1044" info="{CHKQRY_3_3}" {ANWERATTRIBUTE_3_3}/>
                <PrintPDF id="C23,Combo Box 1022,Text Field 1045,Text Field 1046" info="{CHKQRY_3_4}" {ANWERATTRIBUTE_3_4}/>
                <PrintPDF id="C24,Combo Box 1023,Text Field 1047,Text Field 1048" info="{CHKQRY_3_5}" {ANWERATTRIBUTE_3_5}/>
                <PrintPDF id="C25,Combo Box 1024,Text Field 1049,Text Field 1050" info="{CHKQRY_3_6}" {ANWERATTRIBUTE_3_6}/>
                <PrintPDF id="C26,Combo Box 1025,Text Field 1051,Text Field 1052" info="{CHKQRY_3_7}" {ANWERATTRIBUTE_3_7}/>
                <PrintPDF id="C27,Combo Box 1026,Text Field 1053,Text Field 1054" info="{CHKQRY_3_8}" {ANWERATTRIBUTE_3_8}/>
                <PrintPDF id="C28,Combo Box 1027,Text Field 1055,Text Field 1056" info="{CHKQRY_3_9}" {ANWERATTRIBUTE_3_9}/>
                <PrintPDF id="C29,Combo Box 1028,Text Field 1057,Text Field 1058" info="{CHKQRY_3_10}" {ANWERATTRIBUTE_3_10}/>
                <PrintPDF id="C30,Combo Box 1029,Text Field 1059,Text Field 1060" info="{CHKQRY_3_11}" {ANWERATTRIBUTE_3_11}/>
                <PrintPDF id="C31,Combo Box 1030,Text Field 1061,Text Field 1062" info="{CHKQRY_3_12}" {ANWERATTRIBUTE_3_12}/>
                <PrintPDF id="C32,Combo Box 1031,Text Field 1063,Text Field 1064" info="{CHKQRY_3_13}" {ANWERATTRIBUTE_3_13}/>
                <CoverPDF id="C33,Combo Box 1032,Text Field 1065,Text Field 1066" info="{CHKQRY_4_1}" {ANWERATTRIBUTE_4_1}/>
                <CoverPDF id="C34,Combo Box 1033,Text Field 1067,Text Field 1068" info="{CHKQRY_4_2}" {ANWERATTRIBUTE_4_2}/>
                <CoverPDF id="C35,Combo Box 1034,Text Field 1069,Text Field 1070" info="{CHKQRY_4_3}" {ANWERATTRIBUTE_4_3}/>
                <CoverPDF id="C36,Combo Box 1035,Text Field 1071,Text Field 1072" info="{CHKQRY_4_4}" {ANWERATTRIBUTE_4_4}/>
                <CoverPDF id="C37,Combo Box 1036,Text Field 1073,Text Field 1074" info="{CHKQRY_4_5}" {ANWERATTRIBUTE_4_5}/>
                <eBookPDF id="C38,Combo Box 1037,Text Field 1075,Text Field 1076" info="{CHKQRY_5_1}" {ANWERATTRIBUTE_5_1}/>
                <eBookPDF id="C39,Combo Box 1038,Text Field 1077,Text Field 1078" info="{CHKQRY_5_2}" {ANWERATTRIBUTE_5_2}/>
                <eBookPDF id="C40,Combo Box 1039,Text Field 1079,Text Field 1080" info="{CHKQRY_5_3}" {ANWERATTRIBUTE_5_3}/>
                <eBookPDF id="C41,Combo Box 1040,Text Field 1081,Text Field 1082" info="{CHKQRY_5_4}" {ANWERATTRIBUTE_5_4}/>
                <eBookPDF id="C42,Combo Box 1041,Text Field 1083,Text Field 1084" info="{CHKQRY_5_5}" {ANWERATTRIBUTE_5_5}/>
                <eBookPDF id="C43,Combo Box 1042,Text Field 1085,Text Field 1086" info="{CHKQRY_5_6}" {ANWERATTRIBUTE_5_6}/>
                <eBookPDF id="C44,Combo Box 1043,Text Field 1087,Text Field 1088" info="{CHKQRY_5_7}" {ANWERATTRIBUTE_5_7}/>
                <eBookPDF id="C45,Combo Box 1044,Text Field 1089,Text Field 1090" info="{CHKQRY_5_8}" {ANWERATTRIBUTE_5_8}/>
                <eBookPDF id="C46,Combo Box 1045,Text Field 1091,Text Field 1092" info="{CHKQRY_5_9}" {ANWERATTRIBUTE_5_9}/>
                <eBookPDF id="C47,Combo Box 1046,Text Field 1093,Text Field 1094" info="{CHKQRY_5_10}" {ANWERATTRIBUTE_5_10}/>
                <eBookPDF id="C48,Combo Box 1047,Text Field 1095,Text Field 1096" info="{CHKQRY_5_11}" {ANWERATTRIBUTE_5_11}/>
                <eBookPDF id="C49,Combo Box 1048,Text Field 1097,Text Field 1098" info="{CHKQRY_5_12}" {ANWERATTRIBUTE_5_12}/>
                <eBookPDF id="C50,Combo Box 1049,Text Field 1099,Text Field 10100" info="{CHKQRY_5_13}" {ANWERATTRIBUTE_5_13}/>
                <MyCopy id="C51,Combo Box 1050,Text Field 10101,Text Field 10102" info="{CHKQRY_6_1}" {ANWERATTRIBUTE_6_1}/>
                <MyCopy id="C52,Combo Box 1051,Text Field 10103,Text Field 10104" info="{CHKQRY_6_2}" {ANWERATTRIBUTE_6_2}/>
                <MyCopy id="C53,Combo Box 1052,Text Field 10105,Text Field 10106" info="{CHKQRY_6_3}" {ANWERATTRIBUTE_6_3}/>
                <MyCopy id="C54,Combo Box 1053,Text Field 10107,Text Field 10108" info="{CHKQRY_6_4}" {ANWERATTRIBUTE_6_4}/>
                <MyCopy id="C55,Combo Box 1054,Text Field 10109,Text Field 101010" info="{CHKQRY_6_5}" {ANWERATTRIBUTE_6_5}/>
                <ConversionTitles id="C56,Combo Box 1055,Text Field 101011,Text Field 101012" info="{CHKQRY_7_1}" {ANWERATTRIBUTE_7_1}/>
                <ConversionTitles id="C57,Combo Box 1056,Text Field 101013,Text Field 101014" info="{CHKQRY_7_2}" {ANWERATTRIBUTE_7_1}/>
                <Signature id="Text Field 101015" name=""/>
                <Date id="Text Field 101016" date="{DD} {MONTH}, {YEAR}"/>
                <Location id="Text Field 101017" location="{LOCATION}"/>
                </PdfCheckList>';
        
        return $xmlstring;
        
    }
    
    
}