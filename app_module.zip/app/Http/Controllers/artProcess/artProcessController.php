<?php
namespace App\Http\Controllers\artProcess;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\cucProcessModel;
use App\Models\projectModel;
use App\Models\bookinfoModel;
use App\Models\apipdfcreationModel;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\taskLevelMetadataModel;
use App\Models\workflowServerMapPathModel;
use App\Models\metadataInfoModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\checkoutModel;
use App\Models\jobResource;
use App\Models\artCategoryLog;
use App\Models\jobTimeSheet;
use App\Models\productionLocationModel;
use App\Models\apiFigureValidation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\autostageController;
use App\Models\apiProductionFileTransfer;
use App\Http\Controllers\Api\productionFileTransferController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;

class artProcessController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
		
        parent::__construct();
		$this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
		
    }
    
    public function index(){
        
	$data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.ART_WORK'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('artProcess.art-project-list')->with($data);
    }
    
    public function getChapterList( Request $request ){
   
        $response           =   $this->failedResponse;
        $jobid              =       ( $request->input('jobid') ); 
        $task_obj           =       new taskLevelMetadataModel();
        $chapterlist        =       $task_obj->getChapterListByJobid( $jobid  , 'S5' );
       
        if( !empty( $chapterlist ) ){
            $response           =   $this->successResponse;
            $response['data']       =       $chapterlist;
        }
        return response()->json( $response );
    }
    
    public function getChapterListOf( $jobid ){
   
	$data               =   array();
        if( !empty( $jobid ) ){
            
        }else{
            return redirect('/artprocess-booklist')->with('errMsg', 'Invalid try.!');            
        }
        
        $data['pageTitle']  = 	'Art Work';
        $bookdetails    =       bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobid)
                                            ->get()->first();      
       
        $book_id        =       $data[ 'book_id' ]  =       $bookdetails['BOOK_ID'];
        $this->displayMenuName(Config::get('menuconstants.MENU.ART_WORK'),$data);
        $data['pageName']   =   'Art Work - '.$book_id;
        $data['jobID']      =   $jobid;
        $data['backurl']    =   url('/').'/artprocess-booklist';
        return view('artProcess.book-chapter-list')->with($data);
        
    }

    public function startCheckOutProcess( Request $request){
        
        $user_id    =   $this->loginUserId;
        $job_id     =   $request->input( 'job_id' );
        $meta_id    =   $request->input( 'meta_id' );
	
        $inp_array  =   array();
        $task_obj           =       new taskLevelMetadataModel();
        $metaDataDetails    =   $task_obj->getMetadatadetailsChapter($meta_id);
    
        if($metaDataDetails['0']->CURRENT_ROUND == '116'){
            $round_arr      =       \Config::get('constants.ROUND_ID');
            $round          =       $round_arr['S200']; 
        }else{
            $round_arr      =       \Config::get('constants.ROUND_ID');
            $round          =       $round_arr['S5']; 
        }
        
        $response           =   $this->oopsErrorResponse;
        
        $inp_arr['JOB_ID']        =     $job_id;
        $inp_arr['METADATA_ID']   =     $meta_id;
        $inp_arr['ROUND_ID']      =     $round;  
        $inp_arr['STAGE']         =     \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');  //  FOR SPLIT PROCESS
        $inp_arr['TYPE']          =     2;  //  FOR Art 
        $inp_arr['CHECK_OUT']     =     date( 'Y-m-d H:i:s' );  
        $inp_arr['CREATED_DATE']  =     date( 'Y-m-d H:i:s' );  
        $inp_arr['STATUS']        =     1;            
        $inp_arr['CREATED_BY']    =     $user_id;            
        $jts_obj        =       new jobTimeSheet();        
            
        //Check other jobs are handling by him
        $hasOtherJobInHand      =       $jts_obj->hasOtherJobCheckedOutEntry( $inp_arr );
        
        if( $hasOtherJobInHand ){
            
            $job_id         =       $hasOtherJobInHand->JOB_ID;
            $meta_id        =       $hasOtherJobInHand->METADATA_ID;
            $taskObj        =       new taskLevelMetadataModel();         
            $chapterInfo    =       $taskObj->getTaskLevelDetails( $meta_id , array()  , array(  ) );
            $chapterno      =       $chapterInfo[0]->CHAPTER_NO;
            $bookdata       =       jobModel::getJobdetails($job_id);
            $existbookid    =       (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $chapterno      =       $data['chapter_no'] =      $chapterInfo[0]->CHAPTER_NO;
            
            $response['errMsg']         =       'You had checked out this job already : [ '.$chapterno.' ] from '.$existbookid;
            
            return response()->json( $response );
        }
        
        //Check already checkedout 
        
        $hasChecked     =       $jts_obj->hasCheckedoutEntry( $inp_arr );
 
        if( $hasChecked ){        
            $res_status     =   2;
            $response['msg']            =       'Success';
            $response['errMsg']         =       'Art creation process already in initialized mode.';      
        }else{   
        
            $res_status                 =       $jts_obj->insertNew($inp_arr);
            $response['msg']            =       'Success';
            $response['errMsg']         =       'Art Creation process initialized..';     
        }
            
            if( $res_status == 2 ){
              
                $response['status']         =           1;
                $pft_obj                    =           new apiProductionFileTransfer();
                $inpArray['user_id']        =           $this->loginUserId;
                $rec_arr        =           array();
                $processName        =       \Config::get('constants.PRE_PRODUCTION_PROCESS_TYPE');
                $condi_arr      =           array( 'USER_ID' => $inpArray['user_id'] , 'PROCESS_NAME' =>  $processName[2] , 'METADATA_ID' => $meta_id );
                $rec_arr        =           $pft_obj->hasInProgressActivity( $job_id , $round , $condi_arr );
                
                if( !empty( $rec_arr ) ){
                    
                    $params     =       array(  'token_key' =>  $rec_arr->TOKEN_KEY );
                    $response['params'] =   $params;    
                    
                }else{
                    
                    try{
                        
                        $pft_cont       =       new productionFileTransferController();
                        $returns_stat   =       $pft_cont->fileTransferLog( $job_id , $round , 2 , $meta_id );
                        $params         =       !empty( $returns_stat['params'] ) ? $returns_stat['params'] : array();
                        $response['params'] =   $params;   
                        
                    }catch(\Exception $e){
                        $response   =   $this->failedResponse;
                        $response['errMsg'] =   $e->getMessage();
                    }
                
                }
                
            } 
            
            return response()->json( $response );
            
    }
   
    public function jobList( ){        
        $jb_obj         =       new jobModel();
        $jobList        =       $jb_obj->getJobListForArtWork();
        $response['data']        =       $jobList;
        $response['userId']     =       $this->loginUserId;
        return response()->json( $response );        
    }
    
    public function checkout( Request $request , $meta_id , $round , $token = null ){
        
            $data   =   array();
            $this->displayMenuName(Config::get('menuconstants.MENU.ART_WORK'),$data);
            $data['pageTitle'] = 'Checkout';
            $data['pageName']  = ' Art work Process';
            
            $taskObj            =       new taskLevelMetadataModel();         
            $chapterInfo        =       $taskObj->getTaskLevelDetails( $meta_id , array()  , array(  ) );
            $chapterInfo        =       $chapterInfo[0];
            $chapterno          =       $chapterInfo->CHAPTER_NO;
           
            $jobId              =       $chapterInfo->JOB_ID;
            $chapterno          =       $data['chapter_no'] =      $chapterInfo->CHAPTER_NO;
            $chp_foldername     =       ( str_replace( '' , '_'  ,  $chapterno ) );
            $data['chpater_name']  =    $chapterInfo->CHAPTER_NAME;
            $data['job_id']     =       $chapterInfo->JOB_ID;
            $data['meta_id']     =      $meta_id;
            $roundID            =   $round;
            $round_arr          =       \Config::get('constants.ROUND_ID');
            if($round == '116'){
                $round              =       'S200';    
            }else{
                $round              =       'S5';
            }
            $data['due_date']   =       $chapterInfo->DUE_DATE;
            $data['stage']      =       $round;
            $data['activity']   =       'Art work processing ';
            $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
            
            //need to dynamicaly bind the production location based on table location
            
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            
            $production_file_server_ip  =   $hostserver.$hostpath;
            $cn_user        =       $hostusername;
            $cn_pass        =       $hostpassword;
            $credentials    =       '<>'.$cn_user.'<>'.$cn_pass;
            
            $domainuser     =        \Config::get('serverconstants.MAGNUS_DOMAIN_USERNAME');
            $domainpass     =        \Config::get('serverconstants.MAGNUS_DOMAIN_PASSWORD');
            $credentials    =       '<>'.$domainuser.'<>'.$domainpass;
              
            $bookdetails    =       bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobId)
                                            ->get()->first();            
           
            $book_id        =       $data['book_id'] =      $bookdetails['BOOK_ID'];
            $data['job_title']     =       $bookdetails->JOB_TITLE;
            if($bookdetails->JOB_TYPE == 'S200 Of Series'){
                $data['job_title']     =  '';
            }
            $userWorkDir        =        \Config::get('constants.USER_WORK_PATH');
            $userTempDir        =        \Config::get('serverconstants.TEMP_PATH');
            $user_id            =        $this->loginUserId;
            $emp_id             =        $this->empId;
            
            $is_partial         =       false;
            $artwork_stage      =       \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');
            $conditions         =       array( 'JOB_ID' =>  $jobId , 'METADATA_ID' => $meta_id ,  'ROUND_ID' => $round_arr['S5'] , 'STAGE' => $artwork_stage , 'CREATED_BY' => $user_id );
            $jts_obj            =       new jobTimeSheet();
            $records_of_tst     =   $jts_obj->getRecordsOfPartialCheckin( $conditions );
            
            if( count( $records_of_tst ) > 0 ){
                $is_partial         =       true;
            }
            
            $locStage           =       \Config::get('constants.PRE_PRODUCTION_PROCESS_TYPE');
            $const_replace      =       array(  
                                                'USER_DIR'      =>      $emp_id,
                                                'STAGE_NAME'    =>      $locStage[2] ,
                                                'BOOK_ID'       =>      $book_id,
                                                'ROUND_NAME'    =>      Config::get('constants.ROUND_OF_NAME.S5')
                                        );
            if($round == 'S200') {
              $const_replace      =       array(  
                                                'USER_DIR'      =>      $emp_id,
                                                'STAGE_NAME'    =>      $locStage[2] ,
                                                'BOOK_ID'       =>      $book_id,
                                                'ROUND_NAME'    =>      $round
                                        );
            }
                       
            $art_dir                =       \Config::get('constants.STAGE_NAME.ART_FILES');
            $split_dest_dir         =       \Config::get('constants.ART_DESTINATION_PATH');
            $split_src_dir          =       \Config::get('constants.ART_SOURCE_PATHS').$book_id.'/'.$chp_foldername.'/';
            
            $artsplitsrcdir         =       \Config::get('constants.SPLIT_SOURCE_PATH');
            
            if($round == 'S200' && false ){
                  $artsplitsrcdir         =       \Config::get('serverconstants.S50_COPY_EDITING_PATH');
            }
            
            $artStageid             =       Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');
            
            $download_path          =       $production_file_server_ip.$artsplitsrcdir;
            $checkinTempSrcPath     =       $production_file_server_ip.$userWorkDir.$art_dir.'/'.$book_id.'/'.$chp_foldername.'/';
            $checkinTempDestPath    =       $production_file_server_ip.$userTempDir.$artStageid.'_'.$book_id.'_'.$chp_foldername.'/';
            
            $checkinSrcPath         =       $production_file_server_ip.$userWorkDir.$art_dir.'/'.$book_id.'/'.$chp_foldername.'/';
            $checkinDestPath        =       $production_file_server_ip.$userTempDir.$artStageid.'_'.$book_id.'_'.$chp_foldername.'/';
            $checkoutSrcPath        =       $production_file_server_ip.$artsplitsrcdir;
            
           /* if( $is_partial ){
                
                $checkoutSrcPath    =       $production_file_server_ip.$userTempDir.$artStageid.'_'.$book_id.'_'.$chp_foldername.'/'; 
                
            }*/
         
            $openPath               =       $production_file_server_ip.$userWorkDir.$book_id.'/'.$chp_foldername.'/'.$credentials;
                    
            $root_dir               =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
            $openPath               =       $hostserver.$root_dir.$hostpath.$userWorkDir.$art_dir.'/'.$book_id.'/'.$chp_foldername.'/'.$credentials;
            $openPath               =       str_replace( '//' , '/' , $openPath );
            $checkoutDestPath       =       $production_file_server_ip.$userWorkDir.$art_dir.'/'.$book_id.'/'.$chp_foldername.'/';
			
            foreach( $const_replace as $key => $value ){
                
              $openPath                     =           str_replace( $key , $value , $openPath );
              $checkinTempSrcPath           =           str_replace( $key , $value , $checkinTempSrcPath );
              $checkinTempDestPath          =           str_replace( $key , $value , $checkinTempDestPath );
              $checkinSrcPath               =           str_replace( $key , $value , $checkinSrcPath );
              $checkinDestPath              =           str_replace( $key , $value , $checkinDestPath );
              $download_path                =           str_replace( $key , $value , $download_path );
              $checkoutSrcPath              =           str_replace( $key , $value , $checkoutSrcPath );
              $checkoutDestPath             =           str_replace( $key , $value , $checkoutDestPath );
              
            }
            if($round == 'S200'){
                $checkoutSrcPath        =   str_replace('{BID}',$book_id,$checkoutSrcPath); 
                $checkoutSrcPath        =   str_replace('{CID}',$chapterno,$checkoutSrcPath); 
                $checkoutSrcPath        =   str_replace('{RID}',$round,$checkoutSrcPath); 
				
				$download_path			=	str_replace('{BID}',$book_id,$download_path); 
				$download_path			=	str_replace('{CID}',$chapterno,$download_path); 
				$download_path			=	str_replace('{RID}',$round,$download_path); 
            }
            
            $checkinDestPath				=	       	$production_file_server_ip.$split_dest_dir.$book_id.'/ARTFILES/'.$chp_foldername.'/';
           
            $data['open_path']                         =       $openPath;
            $data['fhParam']['checkinTempSrcPath']     =       $checkinTempSrcPath;
            $data['fhParam']['checkinTempDestPath']    =       $checkinTempDestPath;
            $data['fhParam']['checkinSrcPath']         =       $checkinSrcPath;
            $data['fhParam']['checkinDestPath']        =       $checkinDestPath;
            $data['fhParam']['extension']              =       '';
            $data['fhParam']['methodName']             =       'fileServertoServer';
            $data['fhParam']['deleteFlag']             =       0;
            $data['fhParam']['download_path']          =       $download_path;
            $data['fhParam']['checkoutSrcPath']        =       $checkoutSrcPath;
            
            $data['fhParam']['checkoutDestPath']       =       $checkoutDestPath;
         
           
            $data['currentuserid']                      =   $this->loginUserId;
            $api_rec        =       DB::table('api_production_file_transfer')->select()->where( 'TOKEN_KEY' , 'LIKE' , '%'.$token.'%')->get()->first();
            $data['isDownloaded']             =       0;
            if( !empty( $api_rec ) ){
                if( $api_rec->STATUS == 2 ){
                   $data['isDownloaded']             =       2;
                }
            }
            
            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($data['job_id'],$roundID,'insert',$meta_id.'-'.Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'));
            
            $data['typefmbm']   =   Config::get('constants.READ_TYPEOF_PM_FM_EXTENSTION');
            $data['backurl']    =   url('/').'/getChapterInfo/'.$data['job_id'];
            return view('artProcess.art-checkout')->with($data);
            
    }

    public function startCheckInProcess( Request $request ){
        //$job_id     =   $request->input( 'job_id' );
        $meta_id     =   $request->input( 'meta_id' );
        $input_arr  =   $request->all();
        $inp_array  =   array();
        $round_arr      =       \Config::get('constants.ROUND_ID');
        $response   =   $this->oopsErrorResponse;
        $inp_arr['CHECK_IN']    =       date('Y-m-d H:m:i');
        //$job_id     =   $request->input( 'job_id' );
        
        $taskObj            =       new taskLevelMetadataModel();         
        $chapterInfo        =       $taskObj->getTaskLevelDetails( $meta_id , array()  , array(  ) );
        $chapterInfo        =       $chapterInfo[0];
        $chapterno          =       $chapterInfo->CHAPTER_NO;
           
        $job_id     =       $jobId              =       $chapterInfo->JOB_ID;
            
        $round      =    $round_arr['S5']; 
        $user_id    =   $this->loginUserId;
        $stage      =     \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');  //  FOR SPLIT PROCESS

        $sel_arr        =       array( 
                                        'JOB_ID'    =>      $job_id , 
                                        'METADATA_ID'   =>  $meta_id , 
                                        'ROUND_ID'  =>      $round  , 
                                        'USER_ID'   =>      $user_id , 
                                        'STAGE'     =>      $stage 
                                );

        $jts_obj            =           new jobTimeSheet();
        $record_info        =           $jts_obj->getCheckedOutRecords(  $sel_arr  );    

        $row_id             =           $record_info->JOB_TIME_SHEET_ID;

        $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id );

        $src_path           =       ( $input_arr['src_path'] ) ;
        $dest_path          =       ( $input_arr['dest_path'] ) ;


        //need to dynamicaly bind the production location based on table location

        $hostserver         =       $getlocationftp->FTP_HOST;
        $usd        =       $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $psw        =       $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ( $getlocationftp->FTP_PATH );

        //$crd                =       Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $crd    =   'ftp://'.$usd.':'.$psw.'@';   
        
        try{
            // Production file transfer to temp directory

            $ftpObj         =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $response_copy       =       $ftpObj->ftp_dir_copy(  $crd.$src_path , $dest_path );

        }  catch (\Exception $e){
            $response   =   $this->failedResponse;
            $response['errMsg']     =   $e->getMessage();
            $response['msg']        =   "Failed";
           return response()->json( $response );
        }

        if( in_array( 'failed' , $response_copy ) ){

            foreach ($response_copy as $key => $value ){
                if( $value == 'success' ){
                    unset( $response_copy[$key] );
                }
            }

            $response_copy   =       array( 'status' => 'failed'  , $response_copy );

        }else{
            $response_copy    =       array( 'status' => 'success' , $response_copy );
        }

        $response   =       $response_copy;

        if( $response_copy['status'] == 'success' ){

            //update job time sheet check in time:
            $response       =   array();

            $array_jst['CHECK_IN']      =       date( 'Y-m-d H:i:s' ); 
            $update_res                 =       jobTimeSheet::updateIfExist( $array_jst ,  $row_id );
            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($job_id,$round,'update',$meta_id.'-'.Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'));
            $response   =   $this->successResponse;
            $response['errMsg']         =       'successfully transfered checkin files.';

        }else{

            //$response   =       array( );

        }


        return response()->json( $response );
    }

    public function endArtSubmit( Request $request )
    {
        try{
        $meta_id            =   $request->input( 'meta_id' );
        $taskObj            =   new taskLevelMetadataModel();         
        $chapterInfo        =   $taskObj->getTaskLevelDetails( $meta_id , array()  , array() );
        $chapterInfo        =   $chapterInfo[0];
        $chapterno          =   $chapterInfo->CHAPTER_NO;
        $job_id             =   $jobId  =   $chapterInfo->JOB_ID;
        $chp_foldername     =   ( str_replace( '' , '_'  , ( $chapterno ) ) );

        $input_arr          =   $request->all();
        
        $inp_array          =   array();
        $round_arr          =   \Config::get('constants.ROUND_ID');
        $response           =   array();
        $params             =   array();
        $bookdetails        =   bookinfoModel::select(DB::raw('job.BOOK_ID'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobId)
                                            ->get()->first();      
        $response   =   $this->oopsErrorResponse;

        $inp_arr['CHECK_IN']    =       date('Y-m-d H:m:i');
  
        $book_id    =   $inarr['Book_id']        =      $bookdetails['BOOK_ID'];
        $inarr['chaptername']    =      $chapterno;
        $inarr['jobID']          =      $job_id;
        
            $round      =       $round_arr['S5']; 
            $user_id    =       $this->loginUserId;
            $stage      =       \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');  //  FOR ART PROCESS
            
            $sel_arr        =       array( 
                                            'JOB_ID'    =>      $job_id , 
                                            'METADATA_ID'   =>  $meta_id , 
                                            'ROUND_ID'  =>      $round  , 
                                            'USER_ID'   =>      $user_id , 
                                            'STAGE'     =>      $stage 
                                    );
            
            $jts_obj            =           new jobTimeSheet();
            $record_info        =           $jts_obj->getCheckedOutRecords(  $sel_arr  );  
            $row_id             =   '';
            
            if(count($record_info)>=1){
                $row_id         =           $record_info->JOB_TIME_SHEET_ID;
            }
            
            $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id );            
            $src_path           =           ( $input_arr['src_path'] ) ;
            $dest_path          =           ( $input_arr['dest_path'] ) ;
            
            //need to dynamicaly bind the production location based on table location
            $hostserver         =   $getlocationftp->FTP_HOST;
            $usn    =    $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $psw    =   $hostpassword        =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   ( $getlocationftp->FTP_PATH );
            $crd    =   'ftp://'.$usn.':'.$psw.'@';   
           
            // Production file transfer to temp directory
            $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
           // $response_copy      =   $ftpObj->ftp_dir_copy(  $crd.$src_path , $dest_path );
          
            $response_copy      =   array('success');
            
            if( in_array( 'failed' , $response_copy ) ){
            
                foreach ($response_copy as $key => $value ){
                    if( $value == 'success' ){
                        unset( $response[$key] );
                    }
                }
            
                $response_copy   =       array( 'status' => 'failed'  , $response_copy );

            }else{
                $response_copy    =       array( 'status' => 'success' , $response_copy );
            }
            
            $artfilename            =       '/'.\Config::get('constants.ART_METADATA_FILE');
            $file_path              =   $crd.$hostserver.$getlocationftp->FTP_PATH.\Config::get('constants.ART_DESTINATION_PATH').$book_id.'/ARTFILES/'.$chapterno;
            $file_path              =   $crd.$src_path;
           
            $full_file_path         =   $hostserver.$getlocationftp->FTP_PATH.\Config::get('constants.ART_DESTINATION_PATH').$book_id.'/ARTFILES/'.$chapterno.$artfilename;
            $full_file_path         =   $src_path.$artfilename;     
            $readfiledirectory      =   $ftpObj->getDirectoryFiles($file_path);
            
            $get_information['art']             =        $this->readArtmetaXml( $full_file_path , $jobId );
            $get_information['jobID']           =        $job_id;
            $get_information['Book_id']         =        $book_id;
            $get_information['chaptername']     =        $chapterno;
            $get_information['meta_id']         =        $meta_id;
            $get_information['status']          =       1;
            
            $response   =       $response_copy;

            $array_jst              =   array();
            $response               =   array();

            $book_id     =       $data['book_id'] =      $bookdetails['BOOK_ID'];

            $array_jst['CHECK_IN']  =   date( 'Y-m-d H:i:s' );
            $array_jst['STATUS']    =   1;
            $wheredata              =   array('JOB_TIME_SHEET_ID'=>$row_id,'STATUS'=>1);
            $checkstatustimesheet   =   $jts_obj->doCheckexistTimeSheetId($wheredata);

            if(count($checkstatustimesheet)>=1){
                $update_res         =   $jts_obj->updateIfExist( $array_jst , $row_id );
            }
            
            $response   =   $this->successResponse;
            $response['errMsg']     =   'successfully transfered checkin files.';

            return response()->json( $get_information );
        }catch( \Exception $e )
        {   
            $response   =   $this->failedResponse;
            if($e->getMessage()     ==  "Undefined index: @attributes");
            {
                $response['errMsg'] =   "Unsupported figure file format, Kindly check the art file(s)";
                return response()->json($response);
            }
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        }
    }
    
    public function readArtmetaXml( $filePath  , $job_id ) {
        
        $artData					=	array();
        
        if(empty($filePath)){
            return $artData;
        }
        
        $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id );            
        //need to dynamicaly bind the production location based on table location
        $hostserver         =   $getlocationftp->FTP_HOST;
        $usn        =       $hostusername       =   $getlocationftp->FTP_USER_NAME;
        $psw        =       $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =   ( $getlocationftp->FTP_PATH );
        $crd    =   'ftp://'.$usn.':'.$psw.'@';   
        $metadataXml			=	file_get_contents( $crd.$filePath );
        
        $xml                            =       simplexml_load_string(  $metadataXml , 'SimpleXMLElement' , LIBXML_NOCDATA );
        $metadataDetails		= 	json_decode( json_encode((array)$xml ), TRUE );
        if(count($metadataDetails)>=1){
        if(count($metadataDetails['Figure'])!='0'){

                if(count($metadataDetails['Figure']) == '1'){
                        $artData[] =  $metadataDetails['Figure']['@attributes'];
                } else {
                        if(!empty($metadataDetails))	{
                                foreach($metadataDetails['Figure'] as $key => $data){
                                        $artData[] = $data['@attributes'];
                                }
                        }
                }
            }
        }

        return $artData;
    }
    
    public function testArtDetails( Request $request ,$jobId = null){
        
        $test   =   app('App\Http\Controllers\spicast\spicastController')->spicastBackgroundProcess($jobId);
        
    }
    
    public function insertNoArtData(Request $request){
       $artInfo      =   ( $request->all() );
     
       if(!empty($artInfo['job_id']) && !empty($artInfo['meta_id'])){
           
            $jobId                    =    $artInfo['job_id'];
            $meta_id                  =    $artInfo['meta_id'];  
            $round                    =    $artInfo['meta_round'];
            $user_id                  =    $this->loginUserId; 
            
             $bookdetails        =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobId)
                                            ->get()->first(); 
            $bookid                   =    $bookdetails['BOOK_ID'];
            
            $inp_arr['JOB_ID']        =     $jobId;
            $inp_arr['METADATA_ID']   =     $meta_id;
            $inp_arr['ROUND_ID']      =     $round;  
            $inp_arr['STAGE']         =     \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');  //  FOR SPLIT PROCESS
            $inp_arr['TYPE']          =     2;  //  FOR Art 
            $inp_arr['CHECK_OUT']     =     date( 'Y-m-d H:i:s' );  
            $inp_arr['CHECK_IN']      =     date( 'Y-m-d H:i:s' );  
            $inp_arr['CREATED_DATE']  =     date( 'Y-m-d H:i:s' );  
            $inp_arr['STATUS']        =     2;            
            $inp_arr['CREATED_BY']    =     $user_id;            
            $jts_obj                  =      new jobTimeSheet();
        
            //Check already checkedout 

            $hasChecked     =       $jts_obj->hasCheckedoutEntry( $inp_arr );

            if( $hasChecked ){        
                $res_status                 =       2;
                $response['status']         =       'failed';
                $response['job_id']         =       $jobId;
                $response['artMsg']         =       'Art creation process already in initialized mode.';      
            }else{   
               $res_status                 =       $jts_obj->insertNew($inp_arr);
                $response['status']         =       'success';
                $response['job_id']         =       $jobId;
                $response['artMsg']         =       'Art process completed';     
            }
         
            $wheredata                          =   [['JOB_ID',$jobId],['UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE')]];
            $getartchapters                     =   taskLevelMetadataModel::where($wheredata)->get();    
            $completeartchapter                 =   taskLevelMetadataModel::getArtcompletedChpter($jobId);
            $completecopyediting                =   taskLevelMetadataModel::getCopyeditingcompletedChpterNew($jobId);
            $copyeditingAvaliable               =   taskLevelMetadataModel::getCopyeditingStageAvailable($jobId);
            
            //check art is complete then send email
            if(count($getartchapters)   ==  count($completeartchapter)){
                $mailresponse           =   $this->doSendArtcompletedemail($jobId,$bookid);
            }
            
            if(count($copyeditingAvaliable) == 0){
                if(count($getartchapters)   ==  count($completeartchapter) ){
                    $updatespicastdata      =   array('SPICAST_STATUS'=>'1');
                    $updatejobinfo          =   jobInfoModel::where('JOB_ID',$jobId)->update($updatespicastdata);
                    $copyEditingLevel       =   1;
                    $spicastbackresponse    =   app('App\Http\Controllers\spicast\spicastController')->spicastBackgroundProcess($jobId,$copyEditingLevel);
                }
            }    
            else if(count($getartchapters)   ==  count($completecopyediting) && count($getartchapters)   ==  count($completeartchapter))
            {
                 $copyEditingLevel       =   0;
                $updatespicastdata      =   array('SPICAST_STATUS'=>'1');
                $updatejobinfo          =   jobInfoModel::where('JOB_ID',$jobId)->update($updatespicastdata);
                $spicastbackresponse    =   app('App\Http\Controllers\spicast\spicastController')->spicastBackgroundProcess($jobId,$copyEditingLevel);
            }
        
       }
       
        return response()->json( $response );
        
    }
    
    public function array_icount_values($array,$nameofarray) {
        $ret_array = array();
        $duplicate_name = array();
        $datarray   =   ["firstindex"=>[],"secondindex"=>[]];
        foreach($array as $key=>$value) {
            foreach($ret_array as $key2 => $value2) {
                if(strtolower($key2) == strtolower($value)) {
                    $duplicate_name[]   =   (isset($nameofarray[$key])?$nameofarray[$key]:"");
                    $ret_array[$key2]++;
                    continue 2;
                }
            }
            $ret_array[$value] = 1;
        }
        $datarray["firstindex"]     =       $ret_array;
        $datarray["secondindex"]    =       $duplicate_name;
        return $datarray;
    }
   
    public function insertArtDetails( Request $request )
    {
        $art_informations       =   ( $request->all() );
        $metaid                 =   $art_informations['metaid'];
        unset( $art_informations['metaid'] );
       
        $response   =   $this->notfoundResponse;
        $wrkinv     =       $art_informations['workinvolved'];
        $mode       =       $art_informations['mode'];
        $complexity =       $art_informations['complexity'];
        $type       =       $art_informations['type'];
        $file       =       $art_informations['files'];
        $artName    =       $art_informations['artName'];
        $inputcolor =       $art_informations['inputcolor'];
        $outputcolor=       $art_informations['outputcolor'];
        $remarks    =       $art_informations['remarks'];
        $chaptername    =   $art_informations['chaptername'];
        $allinsertsuccess   =   array();
        $taskObj            =   new taskLevelMetadataModel();         
        $chapterInfo        =   $taskObj->getTaskLevelDetails( $metaid , array()  , array() );
        $chapterInfo        =   $chapterInfo[0];
        $chapterno          =   $chapterInfo->CHAPTER_NO;
        $job_id             =   $jobId     =    $chapterInfo->JOB_ID;
        $round_arr          =   \Config::get('constants.ROUND_ID');
        if($chapterInfo->CURRENT_ROUND == $round_arr['S200']){
            $round              =   $round_arr['S200'];
        }else{
             $round              =   $round_arr['S5'];
        }
        //get book id 
        $bookdetaills       =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid             =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $figurescount       =   [];
        $unnumfigurescount  =   [];
        $tablecount         =   [];
        $unnumtablecount    =   [];
        $schemescount       =   [];
        $unnumschemescount  =   [];
        $structurecount     =   [];
        $unnumstructurecount    =   [];
        $equtionscount      =   [];
        $unnumequtionscount =   [];
        $stage              =   \Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');
        $invalidimageformat =   "";
        $copyStatus         =   [];
       
        if(count($artName)>=1)
        {
            $copyStatus         =   $this->copyArtWorkingfilesToDestignation($art_informations,$jobId,$bookid,$metaid);
            $duplicateartname   =   $this->array_icount_values(array_column($copyStatus,"imagerename" ),array_column($copyStatus,"imageoriname" ));
            $checkduplicateentry    =   (count($duplicateartname['firstindex'])>0?true:false);
            if($checkduplicateentry){
                $getmaxvalue    =   max($duplicateartname['firstindex']);
                if($getmaxvalue > 1){
                    foreach($duplicateartname['secondindex'] as $value){
                        $invalidimageformat     .=   "Duplicate image name found like (01 or 1) (".$value.") ,";
                    }
                }
            }
            
            if(count($copyStatus)>=1){
                foreach($copyStatus as $value){
                    if(isset($value['invalid']))
                    {
                        $invalidimageformat     .=   "Invalid image name (".$value['invalid'].") ,";
                    }
                }
            }
        }
        
        $invalidimageformat     =   rtrim($invalidimageformat,',');
        if(!empty($invalidimageformat)){
            $response['msg']    =   'Invalid image name given below,Kindly check and retry again...';
            $response['jobId']  =   $job_id;
            $response['shownotavaiablechapter']  =   $invalidimageformat;
            $response['notexistdata']  =   count($invalidimageformat);
            return response()->json( $response );
        }
        
        if(count($copyStatus)>=1){
            foreach($copyStatus as $value){
                if($value['imagemsg']  ==  'failed')
                {
                    $responsemessge     =       'Not able to move the files some file name is invalid format, Kindly try again';
                    $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>$job_id  ,'artMsg'=>$responsemessge, $allinsertsuccess );
                    return response()->json( $allinsertsuccess );
                }
                if(strpos(substr($value['allimagecountoper'],0),Config::get('constants.ART_FIG_COUNT')) !== false)
                {   
                    if(ctype_digit(substr($value['allimagecountoper'],3,1)))
                    {
                        $figurescount[]         =   trim(substr($value['allimagecountoper'],1));
                    }

                    if(ctype_alpha(substr($value['allimagecountoper'],0,4)))
                    {
                        $unnumfigurescount[]    =   trim(substr($value['allimagecountoper'],1));
                    }
                }
                if(strpos(substr($value['allimagecountoper'],0),Config::get('constants.ART_TAB_COUNT')) !== false)
                {   
                    if(ctype_digit(substr($value['allimagecountoper'],3,1)))
                    {
                        $tablecount[]           =   trim(substr($value['allimagecountoper'],1));
                    }

                    if(ctype_alpha(substr($value['allimagecountoper'],0,4)))
                    {
                        $unnumtablecount[]      =   trim(substr($value['allimagecountoper'],1));
                    }
                }
                if(strpos(substr($value['allimagecountoper'],0),Config::get('constants.ART_SCHEMES_COUNT')) !== false)
                {   
                    if(ctype_digit(substr($value['allimagecountoper'],3,1)))
                    {
                        $schemescount[]         =   trim(substr($value['allimagecountoper'],1));
                    }

                    if(ctype_alpha(substr($value['allimagecountoper'],0,4)))
                    {
                        $unnumschemescount[]    =   trim(substr($value['allimagecountoper'],1));
                    }
                }
                if(strpos(substr($value['allimagecountoper'],0),Config::get('constants.ART_STRUCTURE_COUNT')) !== false)
                {   
                    if(ctype_digit(substr($value['allimagecountoper'],3,1)))
                    {
                        $structurecount[]       =   trim(substr($value['allimagecountoper'],1));
                    }

                    if(ctype_alpha(substr($value['allimagecountoper'],0,4)))
                    {
                        $unnumstructurecount[]  =   trim(substr($value['allimagecountoper'],1));
                    }
                }
                if(strpos(substr($value['allimagecountoper'],0),Config::get('constants.ART_EQAUTION_COUNT')) !== false)
                {   
                    if(ctype_digit(substr($value['allimagecountoper'],3,1)))
                    {
                        $equtionscount[]        =   trim(substr($value['allimagecountoper'],1));
                    }

                    if(ctype_alpha(substr($value['allimagecountoper'],0,4)))
                    {
                        $unnumequtionscount[]   =   trim(substr($value['allimagecountoper'],1));
                    }
                }
            }
        }
        $getlocationftp     =   productionLocationModel::doGetLocationname($job_id);
        if(count($getlocationftp)>=1)
        {
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            $driveUsername                =     $getlocationftp->FILE_SERVER_USER_NAME;
            $drivePassword                =     $getlocationftp->FILE_SERVER_PASSWORD;
                
            // Do the FTP connection
            $ftpObj         =   \Storage::createFtpDriver([
                                                'host'     => $hostserver, 
                                                'username' => $hostusername,
                                                'password' => $hostpassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
            $getuserid          =   $this->empId;
            $get_s5round        =   Config::get('constants.ROUND_NAME.114');
            $readartfile        =   $hostpath.Config::get('constants.ART_DESTINATION_PATH').$bookid."/".Config::get('serverconstants.ARTFILES_PATH').$chaptername;
          
        }
        try{
            $inserid        =   '';
            $insert_arr     =   [];
            // delete if record exist for this chap[ter level
            $checkexistartavaiableornot     =   taskLevelArtMetadataModel::where(["METADATA_ID"=>$metaid,"JOB_ID"=>$job_id])->get();
            if(count($checkexistartavaiableornot)>=1){
                taskLevelArtMetadataModel::where(["METADATA_ID"=>$metaid,"JOB_ID"=>$job_id])->delete();
            }
            foreach( $artName as $index => $value )
            {
                $filename   =   $insert_arr['FILE_NAME']    =   ($copyStatus[$index]['imageoriname'] == $value?$copyStatus[$index]['imagerename']:$value);    
                $insert_arr['METADATA_ID']      =   $metaid;    
                $insert_arr['JOB_ID']           =   $job_id;    
                $fig_no =   $insert_arr['FIGURE_NO']    =   ($index+1);    
                $insert_arr['FIGURE_ID']        =   ($copyStatus[$index]['imageoriname'] == $value?$copyStatus[$index]['figureid']:$value);    
                $insert_arr['COMPLEXITY']       =   $complexity[$index];    
                $insert_arr['CURRENT_ROUND']    =   $round;    
                $insert_arr['CURRENT_STAGE']    =   $stage;    
                $insert_arr['CURRENT_ITERATION']=   1;    
                $insert_arr['STATUS_ENUM_ID']   =   45;    
                $insert_arr['FIGURE_TYPE']      =   $type[$index];    
                $insert_arr['INPUTCOLOR']       =   $inputcolor[$index];    
                $insert_arr['OUTPUTCOLOR']      =   $outputcolor[$index];    
                $insert_arr['INPUT_MODE']       =   $mode[$index];    
                $insert_arr['FIGURE_FULL_MODE'] =   $this->changeartmodename($mode[$index]);    
                $insert_arr['INPUT_FILE']       =   $file[$index];    
                $insert_arr['WORK_INVOLVED']    =   $wrkinv[$index];    
                $insert_arr['REMARKS']          =   $remarks[$index];    
                $insert_arr['CREATED_DATE']     =   Carbon::now();    
                $insert_arr['CREATED_BY']       =   $this->loginUserId;
                $inserid                        =   DB::table('task_level_art_metadata')->insertGetId( $insert_arr );
                $response['msg']                =   'Record insert success';
                if( $inserid ){
                    $allinsertsuccess[$value]   =   'success';
                }else{
                    $allinsertsuccess[$value]   =   'failed';
                }              
            } 
            
            $wheredata      =   array('JOB_ID'=>$job_id,'CHAPTER_NO'=>$chaptername);
            $getmetadata    =   taskLevelMetadataModel::where($wheredata)->first();
            if(count($getmetadata)>=1)
            {
                $metadatid  =   $getmetadata->METADATA_ID;
                //update record in metadata info table 
                $updatedata =   array('FIGURE_COUNT'=>count($artName),'FIGURE_COUNT_NUMBERED'=>count($figurescount),'FIGURE_COUNT_UNNUMBERED'=>count($unnumfigurescount),'NO_ART_FIGURES'=>count($tablecount),'NO_ART_FIGURE_UNNUMBERED'=>count($unnumtablecount),'NO_SCHEMES'=>count($schemescount),'NO_SCHEME_UNNUMBERED'=>count($unnumschemescount),
                    'NO_ART_STRUCTURE'=>count($structurecount),'NO_ART_STRUCTURE_UNNUMBERED'=>count($unnumstructurecount),
                    'NO_ART_EQUATION'=>count($equtionscount),'NO_ART_UNNUMBERED_EQUATION'=>count($unnumequtionscount)); 
                $updatemeta =   metadataInfoModel::where('METADATA_ID',$metadatid)->update($updatedata);
            }
            //job time sheet
            $jobtimesheetid                     =   '';
            $wheredata                          =   [];
            $wheredata['METADATA_ID']           =   $metaid;
            $wheredata['JOB_ID']                =   $job_id;
            $wheredata['STAGE']                 =   Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION');
            //check user access 
            $getmamtimesheetid                  =   jobTimeSheet::getMaxoftimesheetrecords($wheredata);
            $jobtimesheetid                     =   (count($getmamtimesheetid)>=1?$getmamtimesheetid->timesheetid:$jobtimesheetid);
            //check exist meta id in job time sheet table
            $jobtimedata                        =   [];
            $jobtimedata['STATUS']              =   2;
            $jobtimedata['CHECK_IN']            =   Carbon::now();
            $updatemetasuccess                  =   jobTimeSheet::updateIfExist($jobtimedata,$jobtimesheetid);
            //check all art process is completed or not
            $wheredata                          =   [['JOB_ID',$jobId],['UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE')]];
            $getartchapters                     =   taskLevelMetadataModel::where($wheredata)->get();    
            $completeartchapter                 =   taskLevelMetadataModel::getArtcompletedChpter($jobId);
            $completecopyediting                =   taskLevelMetadataModel::getCopyeditingcompletedChpterNew($jobId);
            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($job_id,$round,'update',$metaid.'-'.Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'));
            //check art is complete then send email
            if(count($getartchapters)   ==  count($completeartchapter)){
                $mailresponse           =   $this->doSendArtcompletedemail($jobId,$bookid);
            }
            
            if(count($getartchapters)   ==  count($completecopyediting) && count($getartchapters)   ==  count($completeartchapter))
            {
                $updatespicastdata      =   array('SPICAST_STATUS'=>'1');
                $updatejobinfo          =   jobInfoModel::where('JOB_ID',$jobId)->update($updatespicastdata);
                $spicastbackresponse    =   app('App\Http\Controllers\spicast\spicastController')->spicastBackgroundProcess($jobId);
            }
            $responsemessge         =   (count($artName)  ==  0?'Submitted Successfully...':'Art information stored successfully...');
            if( in_array( 'failed' , $allinsertsuccess ) ){
                foreach ($allinsertsuccess as $key => $value ){
                    if( $value == 'success' ){
                        unset( $allinsertsuccess[$key] );
                    }
                }
                $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>$job_id  ,'artMsg'=>$responsemessge);
            }else{
                $allinsertsuccess    =       array( 'status' => 'success' ,'jobId'=>$job_id,'artMsg'=>$responsemessge);
            }
            
            if( $allinsertsuccess['status'] == 'failed' ){
//                DB::commit(); 
                DB::rollBack();  
            }else{
                
                $drivepath                  =         \Config::get( 'serverconstants.DRIVE_FILE_SERVER_PATH' );
                $userWrkPath                =         \Config::get( 'constants.USER_WORK_PATH' ).'ART_FILES/{BID}/{CID}/';
                $user_id                    =         $this->loginUserId;
                $emp_id                     =         $this->empId;
                
                $const_replace              =       array(  
                                                            'USER_DIR'      =>      $emp_id , 
                                                            'ROUND_NAME'    =>      'S5' , 
                                                            'STAGE_NAME'    =>      \Config::get('constants.STAGE_NAME.USER_DIR') ,
                                                            '{BID}'         =>      $bookid , 
                                                            '{CID}'         =>      $chaptername
                                                    );
                
                $deleteUserWorkPath           =         $hostserver.$hostpath.$userWrkPath;
                $commonObj                    =         new CommonMethodsController();
                $deleteUserWorkPath           =         $commonObj->arr_key_value_replace( $const_replace , $deleteUserWorkPath );
                $tempPath                     =         str_ireplace( $hostpath , $drivepath , $deleteUserWorkPath );
                $tempPath                     =         str_ireplace( '//' , '/' , $tempPath );
                $fileResponse['deletePath']   =         $tempPath.'<>'.$driveUsername.'<>'.$drivePassword;
                $commonObj->deletefilesInproduction($fileResponse['deletePath']);
                
                DB::commit();
                
            }   
          
            return response()->json( $allinsertsuccess );
            
        }catch( \Exception $e ){
			DB::rollBack();
            $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>$job_id  ,'artMsg'=>$e->getMessage());
            return response()->json( $allinsertsuccess );
            //DB::rollBack(); 
        }
    }
    
    public function changeartmodename($typename)
    {
        $artinputmode       =   "";
        if($typename != '')
        {
            $modename           =   explode('-',$typename);
            switch(strtolower($modename[1]))
            {
                case 'lt':
                $artinputmode   =   "LineTone";
                break;
                case 'ht':
                $artinputmode   =   "Halftone";
                break;
                case 'la':
                $artinputmode   =   "Lineart";
                break;
            }
        }
        return $artinputmode;
    }
    
    public function copyArtWorkingfilesToDestignation($inputData,$jobId,$bookid,$metaid)
    {    
        $getlocationftp     =   productionLocationModel::getJobLocationServerPath($jobId);
        $getuserid          =   $this->empId;
        $get_s5round        =   Config::get('constants.ROUND_NAME.114');
        $chaptername        =   $inputData['chaptername'];
        $finalimagecopy     =   $inputData['artName'];
        if(count($getlocationftp)>=1)
        {
            $userWorkDir        =  \Config::get('constants.USER_WORK_PATH');
            $userWorkDir        =   str_ireplace('USER_DIR', $getuserid, $userWorkDir);
            $art_dir            =  \Config::get('constants.STAGE_NAME.ART_FILES');
            $ftplarvelObj       =   Storage::createFtpDriver([
                                                        'host'     => $getlocationftp['HOST'], 
                                                        'username' => $getlocationftp['FTP_USERNAME'],
                                                        'password' => $getlocationftp['FTP_PASSWORD'], // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
            
            $src_path           =   $getlocationftp['HOST_PATH'].$userWorkDir.$art_dir.'/'.$bookid.'/'.$chaptername.'/';
            $dest_path          =   $getlocationftp['HOST_PATH'].Config::get('constants.ART_DESTINATION_PATH').$bookid."/".Config::get('serverconstants.ARTFILES_PATH').$chaptername;
            $readfiledir        =   $getlocationftp['HOST_PATH'].$userWorkDir.$art_dir.'/'.$bookid.'/'.$chaptername.'/';
            $imagerenme         =   $this->doArtimagerenameprocess($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD'],$bookid,$chaptername,$finalimagecopy,$src_path,$dest_path,$readfiledir);
            return $imagerenme;
        }
        $response_copy      =   array(['imagemsg' => 'failed','imagerename'=>'','imageoriname'=>'','allimagecountoper'=>'']);
        return $response_copy;
    }
    
    
    public function doArtimagerenameprocess($ftphost,$ftpusername,$ftppassword,$bookid,$chaptername,$finalimagecopy,$src_path,$dest_path,$readfiledir)
    {   
        $ftplarvelObj       =   Storage::createFtpDriver([
                                                'host'     => $ftphost, 
                                                'username' => $ftpusername,
                                                'password' => $ftppassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
        $allfiles           =   $ftplarvelObj->allFiles($readfiledir);
        $readimagesonly     =   Config::get('constants.ART_IMAGE_VALIDATION_FILEXTN');
        $artimagenameread   =   Config::get('constants.ART_IMAGE_NAME_CHECKWITHNUM');
        $artimagenamealpha  =   Config::get('constants.ART_IMAGE_NAME_CHECKWITHAALPHA');
        $artrenamechanges   =   Config::get('constants.ART_IMAGE_NAME_PROCESSING.PRINTNAME');
        $artnamerenamecoll  =   Config::get('constants.ART_IMAGE_NAME_COLLECTION');
        $artnamerenamealpha =   Config::get('constants.ART_IMAGE_NAME_COLLECTION_ALPHA');
        $fmname             =   Config::get('constants.ART_IMAGE_NAME_PROCESSING.FM');
        $bmname             =   Config::get('constants.ART_IMAGE_NAME_PROCESSING.BM');
        $changealpha        =   ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
        $artimagename       =   "";
        $namechange         =   "";
        $countimagename     =   "";
        $figureidname       =   "";
        $additionalimagenames   =   '';
        $imageerrorcopyresponsep    =   array(['imagemsg' => 'failed','imagerename'=>'','imageoriname'=>'','allimagecountoper'=>'']);
        $imagecopyresponsep         =	array();
        
        $renamedchapter     =   $chaptername;
        if(strpos($chaptername,'_') !== false)
        {
            $splitchaptername   =   explode('_',$chaptername);
            $renamedchapter     =   (!empty($splitchaptername[1])?$splitchaptername[1]:$chaptername);
        }
        try{
           
            if(count($allfiles)>=1)
            { 
                $key        =   0;
                $imagecopyresponsep     =   [];
                $docopyimageprocess     =   [];
                foreach($allfiles as $jsonvalue)
                {
                    $spiltchapter       =   substr(strrchr($jsonvalue, "/"), 1);
                    $originalchapter    =   substr(strrchr($spiltchapter, "."), 0);
                    if(strpos($spiltchapter,'.') !== false && in_array(strtoupper($originalchapter), $readimagesonly) && in_array($spiltchapter, $finalimagecopy))
                    {
                        $splitname  =   explode('.',$spiltchapter);
                      
                    //check file name is not contains underscore
                        if(strpos(substr($splitname[0],0),'_') !== true)
                        { 
                            if(ctype_alnum($splitname[0]) && $splitname[0] != ctype_alpha($splitname[0]))
                            {
                                $result         =   preg_split('/(?<=\d)(?=[a-z])|(?<=[a-z])(?=\d)/i', $splitname[0]);
                                $namechange     =   ucfirst(strtolower($result[0]));
                                $isvalidnumber  =   (isset($result[1])?$result[1]:1);
                                $additionalimagenames   =   (isset($result[2])?strtolower($result[2]):'');
                                $getcharacter   =   $this->dochangenumbertoalpha($isvalidnumber);
//                                //check alpha and number
                                if(strtoupper($chaptername)     ==  Config::get('constants.CHECK_FM')  && in_array(strtoupper($result[0]),$artimagenameread ))
                                {
                                    $namechange     =   $artnamerenamecoll[$namechange];
                                    $artimagename   =   $bookid.'_'.$fmname.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                }
                                if(strtoupper($chaptername)     ==  Config::get('constants.CHECK_BM')  && in_array(strtoupper($result[0]),$artimagenameread))
                                {
                                    $namechange     =   $artnamerenamecoll[$namechange];
                                    $artimagename   =   $bookid.'_'.$bmname.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                }
                                if(in_array(strtolower($chaptername),Config::get('constants.READ_BM_FM_EXTENSTION')) !=   true  && in_array(strtoupper($result[0]),$artimagenameread))
                                {
                                    $namechange     =   $artnamerenamecoll[$namechange];
                                    $artimagename   =   $bookid.'_'.$renamedchapter.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                }
                                //check add number instead alpha character
                                if(strtoupper($chaptername)     ==  Config::get('constants.CHECK_FM')  && in_array(strtoupper($result[0]),$artimagenamealpha ))
                                {
                                    if(in_array($namechange,$artnamerenamecoll)){
                                    $namechange     =   $artnamerenamecoll[$namechange];
                                    $artimagename   =   $bookid.'_'.$fmname.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                    }else{
                                    $namechange     =   $artnamerenamealpha[$namechange];
                                    $artimagename   =   $bookid.'_'.$fmname.'_'.$namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.$getcharacter;
                                    }
                                }
                                if(strtoupper($chaptername)     ==  Config::get('constants.CHECK_BM')  && in_array(strtoupper($result[0]),$artimagenamealpha))
                                {
                                    if(in_array($namechange,$artnamerenamecoll)){
                                    $namechange     =   $artnamerenamecoll[$namechange];
                                    $artimagename   =   $bookid.'_'.$bmname.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                    }else{
                                    $namechange     =   $artnamerenamealpha[$namechange];
                                    $artimagename   =   $bookid.'_'.$bmname.'_'.$namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.$getcharacter;
                                    }
                                }
                                if(in_array(strtolower($chaptername),Config::get('constants.READ_BM_FM_EXTENSTION')) !=   true  && in_array(strtoupper($result[0]),$artimagenamealpha))
                                {
                                    if(in_array($namechange,$artnamerenamecoll)){
                                       
                                    $namechange     =   $artnamerenamecoll[$namechange];
                               
                                    $artimagename   =   $bookid.'_'.$renamedchapter.'_'.$namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.intval($result[1]).$additionalimagenames.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.intval($result[1]).$additionalimagenames;
                                
                                    }else{
                               
                                    $namechange     =   $artnamerenamealpha[$namechange];
                                 
                                    $artimagename   =   $bookid.'_'.$renamedchapter.'_'.$namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $countimagename =   $namechange.$getcharacter.$artrenamechanges.$splitname[1];
                                    $figureidname   =   $namechange.' '.$getcharacter;
                                    }
                                }
                               
                                if(!empty($artimagename))
                                {
//                                    $imagecopy  =   $this->doImgecopying($ftphost,$ftpusername,$ftppassword,$bookid,$chaptername,$jsonvalue,$dest_path,$artimagename);
//                                    $docopyimageprocess[$key]['imagemsg']       =   $imagecopy;
                                    $docopyimageprocess[$key]['artimagerename']     =   $artimagename;
                                    $docopyimageprocess[$key]['artoriginalname']    =   $jsonvalue;
                                    $docopyimageprocess[$key]['imageoriname']       =   $spiltchapter;
                                    $docopyimageprocess[$key]['allimagecountoper']  =   $countimagename;
                                    $docopyimageprocess[$key]['figureid']           =   $figureidname;
                                }
                                else
                                {
                                    $imagecopyresponsep[$key]['invalid']        =   $spiltchapter;
                                }
                                $key++;
                                $artimagename       =   "";
                                $namechange         =   "";
                                $countimagename     =   "";
                                $originalchapter    =   "";
                                $spiltchapter       =   "";
                                $splitname[0]       =   "";
                                $splitname[1]       =   "";
                                $result[0]          =   "";
                                $result[1]          =   "";
                            }
                            else
                            {
                                $imagecopyresponsep[$key]['invalid']        =   $spiltchapter.' is invalid image format';
                                $key++;
                            }
                        }
                    }
                    
                }
                
                $messagestatus  =   "";
                if(count($imagecopyresponsep)>=1){
                    foreach($imagecopyresponsep as $value){
                        if(isset($value['invalid']))
                        {
                            $messagestatus  =   "failed";
                        }
                    }
                }
                if($messagestatus   ==  "failed")
                {
                    return $imagecopyresponsep;
                }
                else
                {
                   
                    if(count($docopyimageprocess)>=1)
                    {
                        foreach($docopyimageprocess as $key=>$value)
                        {
                            $imagecopy  =   $this->doImgecopying($ftphost,$ftpusername,$ftppassword,$bookid,$chaptername,$value['artoriginalname'],$dest_path,$value['artimagerename']);
                            $imagecopyresponsep[$key]['imagemsg']       =   $imagecopy;
                            $imagecopyresponsep[$key]['imagerename']    =   $value['artimagerename'];
                            $imagecopyresponsep[$key]['imageoriname']   =   $value['imageoriname'];
                            $imagecopyresponsep[$key]['allimagecountoper']  =   $value['allimagecountoper'];
                            $imagecopyresponsep[$key]['figureid']       =   $value['figureid'];
                        }
                        return $imagecopyresponsep;
                    }
                }
                return $imagecopyresponsep;
            }
        }
        catch(\Exception $e ){
            return $imageerrorcopyresponsep;
        }
        
        return $imageerrorcopyresponsep;
    }
    
    public function dochangenumbertoalpha($value)
    {
        $changealpha        =   ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
        if(intval($value)>=27)
        {
            $getmodval          =   intval($value)%26;
            $getdivval          =   floor(intval($value)/26);
            if($getmodval   ==  0){
                $getmodval          =   26;
                $getfirstcht        =   strtolower($changealpha[$getdivval-2]);
                $getsecondcht       =   strtolower($changealpha[$getmodval-1]);
            }
            else
            {
                $getfirstcht        =   strtolower($changealpha[$getdivval-1]);
                $getsecondcht       =   strtolower($changealpha[$getmodval-1]);
            }
            $getchacter         =   $getfirstcht.$getsecondcht;
        }
        else
        {
            $getchacter         =   strtolower($changealpha[intval($value)-1]);
        }
        return $getchacter;
    }
    
    public function doImgecopying($ftphost,$ftpusername,$ftppassword,$bookid,$chaptername,$src_path,$dest_path,$artimagename)
    {
        $ftplarvelObj       =   Storage::createFtpDriver([
                                                'host'     => $ftphost, 
                                                'username' => $ftpusername,
                                                'password' => $ftppassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                        ]);
        try{
            if(count($ftplarvelObj)>=1)
            {
                if($ftplarvelObj->has($dest_path))
                {
                    $ftplarvelObj->delete($dest_path.'/'.$artimagename);
                    $putfile    =	$ftplarvelObj->copy($src_path,$dest_path.'/'.$artimagename,0777);
                    return 'success';
                }
                else
                {
                    $putfile    =	$ftplarvelObj->copy($src_path,$dest_path.'/'.$artimagename,0777);
                    return 'success';
                }
            }
        }
        catch(\Exception $e ){
            return 'failed';
        }
        return 'failed';
    }
    
    public function insertArtCategory( $inp_arr ){
        
        $artmeta_id         =       '';
        $round              =       '';
        $metastatusid       =       '';
        $fig_name           =       $inp_arr;
        $imagetype          =       '';
        $worktype           =       '';
        $image_category     =       '';
        
        $response['status']     =   0;
        
        $color              =       $inp_arr;
        $complexity              =       $inp_arr;
        $inputfile              =       $inp_arr;
        $inputtype              =       $inp_arr;
        $inputmode              =       $inp_arr;
        $workinvolved              =       $inp_arr;
        
        $response['status']     =   0;
        
        $metainfo['CREATED_DATE']     =       Carbon::now();
        $metainfo['CREATED_BY']       =       $this->loginUserId;
        $metainfo['COLOR_INFO']   =   $color;
        $metainfo['INPUT_FILE']   =   $inputfile;
        $metainfo['INPUT_TYPE']   =   $inputtype;
        $metainfo['COMPLEXITY']   =   $complexity;
        $metainfo['INPUT_MODE']   =   $inputmode;
        $metainfo['WORK_INVOLVED']   =   $workinvolved;
        $metainfo['ART_METADATA_ID']   =   $workinvolved;
        $metainfo['ART_METADATA_ID']   =   $workinvolved;
        
        $insertid       =       DB::table('art_category_log')->insertGetId( $metainfo );
        
        if( $insertid ){
            
            $response['status'] = 1;
        }
        
        
        /*
         * 
            $artCategoryExist        =       DB::table('art_category_log')
                                        ->where( 'METADATA_ID' , $artmeta_id )
                                        ->where('ROUND_ID', $round );
         * 
        */
        
        
        
    }
    
    public function insertIntoTaskLevelArtMeta( $inp_arr ){
        
        $job_id     =       $inp_arr['JOB_ID'];
        $metaid     =       $inp_arr['METADATA_ID'];
        $round      =       $inp_arr['CURRENT_ROUND'];
        $stage      =       \Config::get('constants.S5_ART_CREATION');
        $response   =   $this->notfoundResponse;
        $filename           =       '';
        $fig_no             =       '';
        $metastatusid       =       '';        
        $metainfo[ 'JOB_ID' ]           =       $job_id;
        $metainfo[ 'METADATA_ID' ]      =       $metaid;
        $metainfo[ 'METADATA_STATUS_ID' ]   =   $metastatusid ;
        $metainfo[ 'FIGURE_NO' ]    =       $fig_no;
        $metainfo[ 'FILE_NAME' ]    =       $filename;
        $metainfo[ 'CREATED_DATE' ]     =       Carbon::now();
        $metainfo[ 'CREATED_BY' ]       =       $this->loginUserId;
        $metainfo[ 'CURRENT_ROUND' ]    =       $round;
        $metainfo[ 'CURRENT_STAGE' ]    =       $stage;
        $metainfo[ 'CURRENT_ITERATION' ]    =   1;
        $metainfo[ 'STATUS_ENUM_ID' ]       =     45;
        $metainfo[ 'FIGURE_TYPE' ]      =       1;
        
        //check exist chapter
        $checkexist             =       DB::table('task_level_art_metadata')
                                        ->where( 'METADATA_ID' , $metaid )
                                        ->where('CURRENT_ROUND', $round )
                                        ->where('JOB_ID', $jobid )
                                        ->where('CURRENT_STAGE', $stage )
                                        ->where('FIGURE_NO', $fig_no )
                                        ->where('FIGURE_NAME', $filename )
                                        ->where('IS_ACTIVE', true)->first();
        
        $countart       =       count( $checkexist );
        
        if( $countart ){
            
            $response['msg']    =       'art entry already exist';
            
        }else{
           $inserid     =       DB::table('task_level_art_metadata')->insertGetId( $metainfo );
           $response['msg']     =       'Record insert success';
        }
        
        return $response;
        
    }
    
    public function insertIntoMetadata_status( $inp_arr ){
        
        //metadata_status
        
        $round      =       $metadata['CURRENT_ROUND']  =   $inp_arr['ROUND'];//chapter unit_enum id
        $stage      =       $metadata['CURRENT_STAGE']  =   \Config::get('constants.S5_ART_CREATION');//chapter unit_enum id
        $jobid      =       $metadata['JOB_ID']         =   $inp_arr['JOB_ID'];
        $metaid     =       $metadata['METADATA_ID']    =   $inp_arr['METADATA_ID'];
        
        $metadata['IS_ACTIVE']      =   true;
        $metadata['CREATED_DATE']   =   Carbon::now();
        $metadata['CREATED_BY']     =   $this->loginUserId;
        $metadata['CURRENT_ITERATION']     =   1;
        $metadata['CURRENT_STATUS']         =   45;
        $metadata['IS_ART']         =   1;
        
        //$metadata['RECEIVED_DATE']        =   '';
        //$metadata['DUE_DATE']             =   '';
        
        $metadata['LAST_MOD_DATE']        =   Carbon::now();
        $metadata['LAST_MOD_BY']          =   $this->loginUserId;
        
        
        //check exist chapter
        $checkexist             =       DB::table('metadata_status')->where( 'METADATA_ID' , $metaid )
                                        ->where('CURRENT_ROUND', $round )
                                        ->where('JOB_ID', $jobid )
                                        ->where('CURRENT_STAGE', $stage )
                                        ->where('IS_ACTIVE', true)->first();
        $count_metastatus       =       count( $checkexist );
        
        if( $count_metastatus ){
           
            $chapterexist[]             =   'metavalue already exist .';	
            
        }else{
            
            $addresult                  =   DB::table('task_level_art_metadata')->insertGetId( $metadata );
            
        }
        
        /* 
            job_id 
            current_round 
            current_stage 
            current_iteration 
            revision_no 
            current_status
            received_date
            due_date , 
            is_art
            metadata_id 
            last_mod_date
            last_mode_by
         *         
       */
        
        
    }
   
    public function doSendArtcompletedemail($jobId, $bookId)
    {
        $bookexist          =   jobModel::getjobInfodetails($jobId);
        $mailData           =   array();
        $mailArray          =   array();
        $mailData['Title']      =   'Art Complete Notification';
        $mailData['HeadLine']   =   'Art Complete Notification';
        $mailData['Bookid']     =   $bookId;
        $mailData['ToName']     =   (count($bookexist)>=1?$bookexist->PM_NAME:'');
        $mailData['username']   =   $this->userName;
        $mailArray['Data']      =   $mailData;
        $mailArray['TemplateName']  =   'emailtemplate.download.ArtCompleteNotification';
        $mailArray['Subject']   =   'Art Complete Notification';
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
       // $mailArray['FromName']  =   'Art Complete Notification';
        $mailArray['ToMail']    =   (count($bookexist)>=1?$bookexist->PM_EMAIL:'');
        $userid                 =   $this->loginUserId;
        $emailvalidation        =   filter_var($bookexist->PM_EMAIL, FILTER_VALIDATE_EMAIL );
        if (is_array($mailArray) && !empty($emailvalidation)) 
        {
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) 
            {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);
                if (array_key_exists('CcMail', $mailArray)) 
                {
                    $message->cc($mailArray['CcMail']);
                }
              //  $message->getSwiftMessage();
            });

            if (Mail::failures()) 
            {
                $result     =   $this->failedResponse;
                return $result;
            } 
            else 
            {
                $result     =   $this->successResponse;
                $result['errMsg']   =   'Email has been sent successfully!';
                return $result;
            }
        }
        $result             =   $this->notfoundResponse;   
        return $result;
    }
    
    public function generateMetaxml(Request $request){
        
        $data               =   $request->all();
        $metadataId         =   $data['meta_id'];
        
        $commonObj          =   new CommonMethodsController();
        $taskObj            =   new taskLevelMetadataModel();
       
        
        $chapterInfo        =   $taskObj->getTaskLevelDetails( $metadataId , array()  , array() );
        $chapterInfo        =   $chapterInfo[0];
        $chapterno          =   $chapterInfo->CHAPTER_NO;
        $job_id             =   $jobId     =    $chapterInfo->JOB_ID;
       
        //get book id 
        $bookdetaills       =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid             =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        //echo "<pre>";print_r($chapterno);exit;
        $rootpath           =   Config::get('constants.FILE_SERVER_WITH_ROOT_DIR');
        $ip                 =   Config::get('constants.FILE_SERVER');
        $artWebUrl          =   Config::get('constants.GENERATE_ART_METAXML');
        $readvalidimages    =   Config::get('constants.ART_IMAGE_VALIDATION_FILEXTN');
        $readimageonly      =   Config::get('constants.SPICAST_IMAGE_FILEXTN');
        
        
        $srcpath            =   $data['src_path']; 
        $jobId              =   $data['job_id'];  
        
        
        $srcpath            =   '////'.$rootpath.str_replace($ip,'' , $srcpath);
        
        $srcpath            =   str_replace("/",'\\',$srcpath);
       
        $srcpath            =   str_replace( '//' , '\\' ,   $srcpath ); 
        $srcpath            =   str_replace( '\\\\' , '\\' ,   $srcpath ); 
        
        $input['BWFBookID']         =   $bookid;
        $input['Stage']             =   'S5';
        $input['ChapterID']         =   $chapterno;
        $input['FileServerPath']    =   $srcpath;
        $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
        if(count($getlocationftp)>=1)
        {
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            // Do the FTP connection
            $crd            =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
            $artsrcpath     =   $crd.$data['src_path'];  
            $ftpObj         =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $allfiles       =   $ftpObj->getDirectoryFiles( $artsrcpath );
            $imagecopyresponsep     =   [];
            if(count($allfiles)>=1)
            {   
                foreach($allfiles as $jsonvalue)
                {
                    $spiltchapter       =   substr(strrchr($jsonvalue, "/"), 1);
                    $originalchapter    =   substr(strrchr($spiltchapter, "."), 0);
                    if(strpos($spiltchapter,'.') !== false && in_array(strtoupper($originalchapter), $readimageonly)){
                        if(strpos($spiltchapter,'.') !== false && in_array(strtoupper($originalchapter), $readvalidimages) !==    false){
                        }
                        else{
                            $imagecopyresponsep[]   =   "Invalid image formet (".$spiltchapter.")";   
                        }
                    }
                    $spiltchapter       =   "";
                    $originalchapter    =   "";
                }
            }
            if(count($imagecopyresponsep)>=1)
            {
                $errorimagesres         =   (count($imagecopyresponsep)     ==  1?'image':'images');
                $returndata['Status']   =   404;
                $returndata['Book_id']  =   $bookid;
                $returndata['chaptername']  =   $chapterno;
                $returndata['Msg']      =   'Invalid Image found kindly remove below mentioned '.$errorimagesres;
                $returndata['artmeataimage']    =   $imagecopyresponsep;
                return $returndata;
            }
            
            $response  =    $commonObj->PostcUrlExecution($input,$artWebUrl,0);
            $returndata['Status']   =   '0';
            $returndata['Msg']      =   'Not able to generate Art metadata xml.';

            if($response != ''){

                $response               =   html_entity_decode($response);
                $response               =   str_ireplace( '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">', '',$response);
                $response               =   str_ireplace( '</string>','', $response);
                $productionLocation     =   new productionLocationModel();

                $location               =   $productionLocation->getJobLocationServerPath($jobId);
                $ftobj                  =   new ftpFileHandlerController($location['HOST'],$location['FTP_USERNAME'],$location['FTP_PASSWORD']);
                $savepath               =   $location['FTP_PATH_CREDENTIAL'].$data['src_path'].'ArtMetadata.xml';
                $putfiledirectory       =   $ftobj->ftp_file_put($savepath,$response);
                $returndata['Status']   =   '1';
                $returndata['Msg']      =   'Success';
            }
            return $returndata;
        }
        $returndata['Status']       =   '0';
        $returndata['Msg']          =   'Production location is not found for this job'; 
        return $returndata;
    }
        
    public function artValidation( $batchId, $metadataStatus,$metadataId, $roundId ){
        
        $response   =   $this->oopsErrorResponse;
        
        try{
            
            if( !is_null( $metadataStatus ) ){

                $artCategryLog          =       new artCategoryLog();
                $artCategryInfo         =       DB::table( 'task_level_art_metadata' )->where( array( 'METADATA_STATUS_ID' => $metadataStatus ) )
                    ->orderBy('ART_METADATA_ID','desc')
                    ->get();   
                
                if( !empty( $artCategryInfo ) ){
                    
                    $return_status      =       $this->artValidationBgProcessIntialize( $artCategryInfo , $metadataStatus , $response, $batchId );
                }else{
                    $response['errMsg']         =       'ART category log entry is not available.';
                }

            }else{
                $response['errMsg']         =       'Batch id : Required field validation error is occured.';
            }
        
        } catch (Exception $ex) {
            $response['errMsg']    = $ex->getMessage();
        }
        
        return response()->json( $response );
    }
    
    public function artValidationBgProcessIntialize( $recordInfo , $mdsid , &$response = array() , $metaStatusBatchid ){
        
        //yet to do already initialized this bg process validation.
        // Currently information not enough to do this
        
        if( !empty( $recordInfo ) ){
            
            $metaFileInput      =           $this->metaInputPrepareForArtValidation( $recordInfo , $mdsid , $metaStatusBatchid );
           
            $getMetaFormat      =           $this->artValidationMetaFileFormatPrepare( $metaFileInput );
            
            $filename           =           $metaFileInput['metafilename'];
            $ftpInfo            =           $metaFileInput['ftpInfo'];
            $whereToWrite       =           $metaFileInput['watch_folder'];
            $atStgObj           =           new autostageController();
            $postMetaStatus     =           $atStgObj->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite );
            
            if( !$postMetaStatus ){
                $response['errMsg']     =      'File posted to WatchFolder got Failed';
            }
            
            if( !empty( $postMetaStatus ) ){
                $metaFileInput['requestlog']    =   $getMetaFormat;
                $metaFileInput['createdBy']     =   $this->loginUserId;
                $afv_obj                =       new apiFigureValidation();
                $return_status          =       $afv_obj->buildInputAndStore( $metaFileInput );
                
                if( $return_status == 2 ){
                    $response   =   $this->successResponse;
                    $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
                }else{
                    $response['errMsg']             =       'api table Record insertion failed';
                }
                
            }
            
            return true;
            
        }else{
            $response['errMsg'] =   'Required informations are missing';
        }
        
        return false;
        
    }
    
    public function artValidationMetaFileFormatPrepare( $input_arr ){
        
        extract( $input_arr );
        $metaStr        =       '';
        
        $metaStr        .=      '<ArtworkMetadata figureLocation="'.$src_path.'">
        <BookID>'.$bookid.'</BookID>
        <round>'.$round.'</round>
        <stage>'.$stage.'</stage>
        <chapterid>'.$chapterid.'</chapterid>
        <metaid>'.$metaid.'</metaid>';
            $metaStr        .=   $figureTagsWithAttr;
            $metaStr        .=  '
            <WorkflowAPI>
                <Url value="'.url('/').'/api/autoStageCallback"/>
                <parameter key="process" value="figureValidation" type="fixed"/>
                <parameter key="controller" value="autostageController" type="fixed"/>
                <parameter key="methodname" value="figureValidation_callback" type="fixed"/>
                <parameter key="_callback" value="batchAutoStageMovement" type="fixed"/>
                <parameter key="jobstageid" value="'.$jobstageid.'" type="fixed"/>
                <parameter key="batchid" value="'.$batchid.'" type="fixed"/>
                <parameter key="round" value="'.$round.'" type="fixed"/>
                <parameter key="tokenkey" value="'.$tokenkey.'" type="fixed"/>
                <parameter key="status" type="boolean"/>
                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                <parameter key="remarks" type="string"/>
            </WorkflowAPI>
        </ArtworkMetadata>';
        
        return $metaStr;
        
    }
    
    public function lowResCreationMetaFilePreparationByStage( $input ){
      
        extract( $input );
        
        $upload_meta    =   '';
        $upload_meta    .=   '<ArtMeta figureLocation="'.$artQcPath.'">';
        $upload_meta    .=   '<BookID>'.$book_id.'</BookID>';
        $upload_meta    .=   '<chapterid>'.$chapter_name.'</chapterid>';
        $upload_meta    .=   '<metaid>'.$metaid.'</metaid>';
        $upload_meta    .=   '<round>'.$round.'</round>';
        $upload_meta    .=   '<stage>'.$roundname.'</stage>';
        $upload_meta    .=   '<xmlpath>'.$chpPath.'</xmlpath>';
        $upload_meta    .=   '<destpath>'.$destPath.'</destpath>';
        $upload_meta    .=   '<workflow>magnus</workflow>';
        $figure_str      =          ''; 
       
        $figure_str        =         $this->prepareFigureTagsForLowRes( $getartfigure , 'xml' , $artQcPath );
        
        $upload_meta    .=          $figure_str;
        
        $upload_meta    .=          '<WorkflowAPI>';
        $upload_meta    .=              '<Url value="'.url('/').'/api/autoStageCallback'.'"/>';
        $upload_meta    .=              '<parameter key="process" value="lowresconversion" type="fixed"/>';
        $upload_meta    .=              '<parameter key="jobid" value="'.$stageDetails->JOB_ID.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="bookid" value="'.$stageDetails->BOOK_ID.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="jobstageid" value="'.$stageDetails->JOB_STAGE_ID.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="metaid" value="'.$metaid.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="tokenkey" value="'.$token.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="round" value="'.$round.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="status" type="boolean"/>';
        $upload_meta    .=              '<parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="date-time"/>';
        $upload_meta    .=              '<parameter key="remarks" type="string"/>';
        $upload_meta    .=          '</WorkflowAPI>';
        $upload_meta    .=          '</ArtMeta>';
     
        return $upload_meta;
		
    }
    
    public function lowResCreationMetaFilePreparation( $input ){
        
        extract( $input );
        
        $upload_meta    =   '';
        $upload_meta    .=   '<ArtMeta figureLocation="'.$artQcPath.'">';
        $upload_meta    .=   '<BookID>'.$book_id.'</BookID>';
        $upload_meta    .=   '<chapterid>'.$chapter_name.'</chapterid>';
        $upload_meta    .=   '<metaid>'.$metaid.'</metaid>';
        $upload_meta    .=   '<round>'.$round.'</round>';
        $upload_meta    .=   '<stage>'.$roundname.'</stage>';
        $upload_meta    .=   '<xmlpath>'.$chpPath.'</xmlpath>';
        $upload_meta    .=   '<destpath>'.$destPath.'</destpath>';
        $upload_meta    .=   '<workflow>magnus</workflow>';
        $figure_str      =          ''; 
       
        $figure_str        =         $this->prepareFigureTagsForLowRes( $getartfigure , 'xml' , $artQcPath );
        
        $upload_meta    .=          $figure_str;
        
        $upload_meta    .=          '<WorkflowAPI>';
        $upload_meta    .=              '<Url value="'.url('/').'/api/toolsLowResCallback'.'"/>';
        $upload_meta    .=              '<parameter key="process" value="lowresconversion" type="fixed"/>';
        $upload_meta    .=              '<parameter key="metaid" value="'.$metaid.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="tokenkey" value="'.$token.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="round" value="'.$round.'" type="fixed"/>';
        $upload_meta    .=              '<parameter key="status" type="boolean"/>';
        $upload_meta    .=              '<parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="date-time"/>';
        $upload_meta    .=              '<parameter key="remarks" type="string"/>';
        $upload_meta    .=          '</WorkflowAPI>';
        $upload_meta    .=          '</ArtMeta>';
     
        return $upload_meta;
		
    }
    
    public function metaInputPrepareForArtValidation( $input_rec , $mdsid , $metaStatusBatchid ){
        
        $return_arr             =       array();
        $artCategryLog          =       new artCategoryLog();
        $artCategryInfo         =       $artCategryLog->getRecordByBatchId( $mdsid );
        
        $artMetaid              =       $artCategryInfo->ART_METADATA_ID;
        $tlam_obj               =       new taskLevelArtMetadataModel();
        $taskArtInfo            =       $tlam_obj->getRecordByCustomCondition( array( 'ART_METADATA_ID' => $artMetaid ) );
        $metaid                 =       $taskArtInfo->METADATA_ID;
      
        $tlm_obj                    =       new taskLevelMetadataModel();
        $basicInfo['metaid']        =       $metaid;        
        $taskInfo                   =       $tlm_obj->getMetadatadetailsChapter( $metaid );
        $chapter_name_arr           =       $taskInfo->pluck('CHAPTER_NO')->toArray();
        $chapter_name               =       $chapter_name_arr[0];
        
        $jobId_arr                  =       $taskInfo->pluck('JOB_ID')->toArray();
        $jobId                      =       $jobId_arr[0];
        
        $job_obj                    =       new jobModel( );
        $job_info                   =       $job_obj->getJobdetails( $jobId );
        $book_id                    =       ( $job_info->BOOK_ID );
        $roundid                    =       $taskArtInfo->CURRENT_ROUND;
        $round_arr                  =       \Config::get('constants.ROUND_ID');
        
        $basicInfo['bookid']        =       $book_id;
        $basicInfo['jobid']         =       $jobId;
        $basicInfo['stage']         =       $round_arr[$roundid];
        $basicInfo['round']         =       $roundid;
        $basicInfo['chapterid']     =       $chapter_name;
        $basicInfo['process']       =       'figureValidation';
        $basicInfo['batchid']       =       $metaStatusBatchid;
        $basicInfo['jobstageid']    =       '';
        
        $metadatstatus_id           =       $input_rec['0']->METADATA_STATUS_ID;
        
        $queryMds                   =       'select js.* from metadata_status mds left join job_round jr on mds.id = jr.METADATA_STATUS_ID '
                                            . 'LEFT JOIN job_stage js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID  and jr.CURRENT_ITERATION_ID = js.ITERATION_ID and js.STATUS = 23 WHERE mds.ID ='.$metadatstatus_id.' and js.STATUS = 23  LIMIT 1';
        $recJs                      =       DB::select($queryMds);
        
        if( count( $recJs ) ){
            $basicInfo['jobstageid']    =       $recJs[0]->JOB_STAGE_ID;
        }
        
        $cmn_obj                    =       new CommonMethodsController();
        $str_token                  =       $cmn_obj->generateRandomString( 16 , 'api_figurevalidation' );
        
        $basicInfo['tokenkey']      =       $str_token;
        $basicInfo['figureTagsWithAttr']        =       '';
        
        $artPrdLocation             =       \Config::get( 'serverconstants.ARTWORK_PRODUCTION_PATH' );
        if( $round_arr[$roundid] == 'S300' ){
            $artPrdLocation         =       \Config::get( 'serverconstants.ARTWORK_PRODUCTION_PATH_S300' );
        }
        
        $artPrdLocation             =       $cmn_obj->arr_key_value_replace( array('{BID}' => $book_id , '{CID}' => $chapter_name , '{RID}' => $round_arr[$roundid] ) , $artPrdLocation  );
        
        $basicInfo['src_path']      =       $cmn_obj->backslashPathPrepare(  $artPrdLocation , true );
        $basicInfo['watch_folder']  =       \Config::get( 'serverconstants.ARTWORK_VALIDATION_WATCH_PATH' );
        
        $prdLoc                     =       new productionLocationModel();
        $basicInfo['ftpInfo']       =       $prdLoc->getJobLocationServerPath( $jobId );
        $figure_str                 =       '';
        $figure_str                 =       $this->prepareFigureTags( $input_rec );
        $basicInfo['figureTagsWithAttr']        =       $figure_str;
        $basicInfo['metafilename']              =       $book_id.'_'.$chapter_name.'_'.$str_token.'.xml';
        
        return $basicInfo;
        
    }
    
    public function doArtfigurePdfCreationxml(Request $request)
    {
        try
        {
            $artmetaid          =   '';
            $metadataid         =   '';
            if ($request->has('artmetaid')) {
                $artmetaid      =   $request->input('artmetaid');
            }
            
            if ($request->has('metadataid')) {
                $metadataid     =   $request->input('metadataid');
            }
            
            $jobId              =   $request->input('jobId');
            $processtype        =   $request->input('processtype');
            $roundId            =   Config::get('constants.ROUND_ID.S200');
            $round_arr          =   Config::get('constants.ROUND_ID');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            
            $js_cpy_const       =       Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
            $cmn_obj            =       new CommonMethodsController();
            $defaultCopyPath    =       $cmn_obj->backslashPathPrepare($js_cpy_const, true);
            $host_rootdir       =       '';        
            $hostpath           =       '';
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            $wheredata          =   array('JOB_ID'=>$jobId,'METADATA_ID'=>$metadataid);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno   !=  '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $host_rootdir   =       '\\\\'.$getlocationftp->FTP_HOST.$getlocationftp->FILE_SERVER_PATH;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                $empid              =   $this->empId;
                $figurelocation     =   '';
                if($processtype     ==  1)
                {
                    $figurelocation     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.Config::get('constants.USER_WORK_PATH').$bookid.'/'.$chapterno;
                    $inp_rep_arr        =   array( 
                                                'USER_DIR' =>    $empid , 
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $figurelocation     =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $figurelocation );
                    $figurelocation     =   str_replace( '//' ,'/', $figurelocation );
                    if(!empty($figurelocation))
                    {
                        $figurelocation =   "\\\\".$figurelocation;
                        $figurelocation =   str_replace( '/' ,'\\', $figurelocation );
                    }
                    $destinationurl     =   $figurelocation;
                }
                else
                {
                    $spicepathreplce    =   Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
                    $inp_rep_arr        =   array( 
                                                '{BID}' =>    $bookid , 
                                                '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                                '{CID}' =>    $chapterno,
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                    $figurelocation     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.$rawpath;
                    $figurelocation     =   str_replace( '//' ,'/', $figurelocation );
                    if(!empty($figurelocation))
                    {
                        $figurelocation =   "\\\\".$figurelocation;
                        $figurelocation =   str_replace( '/' ,'\\', $figurelocation );
                    }
                    
                    $spicepathreplce    =   Config::get('serverconstants.ART_PDF_PRODUCTION_PATH');
                    $inp_rep_arr        =   array( 
                                                '{BID}' =>    $bookid , 
                                                '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                                '{CID}' =>    $chapterno,
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                    $destinationurl     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.$rawpath;
                    $destinationurl     =   str_replace( '//' ,'/', $destinationurl );
                    if(!empty($figurelocation))
                    {
                        $destinationurl =   "\\\\".$destinationurl;
                        $destinationurl =   str_replace( '/' ,'\\', $destinationurl );
                    }
                }
                $whereartmetaid     =   [];
                if($artmetaid !=    '')
                {
                    $whereartmetaid     =   explode(',',$artmetaid);
                }
                $getartfigure       =   taskLevelArtMetadataModel::getArtpdfcreationfigureInfo($whereartmetaid);
                if(count($getartfigure)>=1)
                {
                    $spicast                    =   [];
                    $spicast['JOB_ID']          =   $jobId;
                    $spicast['BATCH_ID']        =   '';
                    $spicast['ROUND']           =   $roundId;
                    $spicast['METADATA_ID']     =   $metadataID;
                    $spicast['PROCESS_TYPE']    =   $processtype;
                    $spicast['ART_METADATA_ID'] =   json_encode($whereartmetaid);
                    $spicast['START_TIME']      =   Carbon::now();
                    $spicast['CREATED_DATE']    =   Carbon::now();
                    $spicast['CREATED_BY']      =   $this->loginUserId;
                    $storespicast               =   apipdfcreationModel::store($spicast);
                    // check layout is have or not for current book
                    $getlayoutprofile           =   jobInfoModel::where('JOB_ID',$jobId)->first();
                    $layoutprofile              =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                        =   Config::get('constants.ROUTE_URL').'/api/artpdfcreationCallback';
                    
                         
                    $inp_rep_arr        =       array('{BID}' => $bookid , '{RID}' => $round_arr[116] , '{CID}' => $chapterno );
                    $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $defaultCopyPath );
                    $host_rootdir   =    str_replace( '/' , '\\' , $host_rootdir);
                    $sourcefile  =    str_replace( '/' , '\\' , $hostpath.str_replace( $host_rootdir , '' ,  $default_jobsheet_path ) );
                    $serverDirFiles     =   $ftpObj->allFiles($sourcefile);
                    
                    foreach($serverDirFiles as $value){
                        if(pathinfo($value)['extension'] == 'xml'){
                            $xmlFilePath    =   $value;
                        }
                    }
                    
                    $xmlFilePath                 =       substr( $xmlFilePath ,  strrpos ( $xmlFilePath , '/' )+1 ); 
                    $default_jobsheet_path       =       $default_jobsheet_path.$xmlFilePath;
                 
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('ArtMeta');
                    $xml->writeAttribute("figureLocation", $figurelocation); 
                    $xml->setIndent(true);
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('metaid');
                    $xml->text($metadataID);
                    $xml->endElement();
                    $xml->startElement('aid');
                    $xml->text($chapterno);
                    $xml->endElement();
                    $xml->startElement('round');
                    $xml->text($roundId);
                    $xml->endElement();
                    $xml->startElement('destpath');
                    $xml->text($destinationurl);
                    $xml->endElement();
                    $xml->startElement('jobsheet_location');
                    $xml->text($default_jobsheet_path);
                    $xml->endElement();
                    
                    //FIGURE DETAILS
                    if(count($getartfigure)>=1)
                    {
                        foreach($getartfigure as $key=>$value)
                        {
                            $xml->startElement('Figure');
                            $xml->writeAttribute("query", ""); 
                            $xml->writeAttribute("graphicalabstract", ""); 
                            $xml->writeAttribute("inputMode", $value->INPUT_MODE); 
                            $xml->writeAttribute("complexity", $value->COMPLEXITY); 
                            $xml->writeAttribute("printColor", $value->OUTPUTCOLOR); 
                            $xml->writeAttribute("webColor", ""); 
                            $xml->writeAttribute("inputColor", $value->INPUTCOLOR); 
                            $xml->writeAttribute("workInvolved", $value->WORK_INVOLVED); 
                            $xml->writeAttribute("figureType", $value->FIGURE_TYPE); 
                            $xml->writeAttribute("fileType", $value->INPUT_FILE); 
                            $xml->writeAttribute("remarks", ""); 
                            $xml->writeAttribute("inputDPI", ""); 
                            $xml->writeAttribute("name", $value->FILE_NAME); 
                            $xml->endElement();  
                        }
                    }
                    //work flow tag
                    $xml->startElement("WorkflowAPI"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "pdfcreation");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$metadataID);
                        $xml->writeAttribute('key', "metaid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$roundId);
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $storespicast->TOKEN_KEY);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "date-time");
                        $xml->writeAttribute('value', "{0:yyyy-MM-dd HH-mm-ss}");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();

                    $content 	=   $xml->outputMemory();
                    $filename 	=   $bookid.'_'.$storespicast->TOKEN_KEY.'_ArtPdf.xml';
                    $filepath   =   Config::get('serverconstants.ARTWORK_PDF_CREATION_WATCH_PATH');
                   
                    $successfileresponse 	=	$ftpObj->put($filepath.$filename, $content);
                    $response   =   $this->notfoundResponse;
                    if($successfileresponse ==     true)
                    {
                        $response['message']    =   'success';
                    }
                    else
                    {
                        $response['message']    =   'failed';
                    }
                    
                    $response   =   array('status'=>1,'errMsg' => ' [ ART PDF CREATION ] BG process initialized.' , 'params' => array( 'tokenkey' => $storespicast->TOKEN_KEY ) );   
                    return response()->json($response);
                }
                return response()->json($this->notfoundResponse);
            }
            $response   =   $this->notfoundResponse;
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
	
     public function doArtfigurePdfCreationxml2( $artmetaid = null, $metadataid = null , $jobId = null , $processtype = null , $metastatusid = null )
    {
        try
        {
            $response   =   $this->notfoundResponse;
            $roundId            =   Config::get('constants.ROUND_ID.S200');
            $round_arr          =   Config::get('constants.ROUND_ID');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            
            $js_cpy_const       =       Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
            $cmn_obj            =       new CommonMethodsController();
            $defaultCopyPath    =       $cmn_obj->backslashPathPrepare($js_cpy_const, true);
            $host_rootdir       =       '';        
            $hostpath           =       '';
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            $wheredata          =   array('JOB_ID'=>$jobId,'METADATA_ID'=>$metadataid);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $roundname          =   'S200';
            
            if( !is_null( $metastatusid ) ){
            
                $artCategryInfo         =       DB::select('select CURRENT_ROUND FROM metadata_status WHERE ID ='.$metastatusid.' ORDER BY ID DESC LIMIT 1');
                if( count( $artCategryInfo ) ){
					$art_obj            =   $artCategryInfo[0];
					$curroundid			=	($art_obj->CURRENT_ROUND  );
                    $dynamic_round      =   Config::get('constants.ROUND_NAME');
                    $roundname          =   $dynamic_round[$curroundid];
					$roundId			=	$curroundid;
                }
            }
            
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno   !=  '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $host_rootdir   =       '\\\\'.$getlocationftp->FTP_HOST.$getlocationftp->FILE_SERVER_PATH;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                $empid              =   $this->empId;
                $figurelocation     =   '';
                if($processtype     ==  1)
                {
                    $figurelocation     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.Config::get('constants.USER_WORK_PATH').$bookid.'/'.$chapterno;
                    $inp_rep_arr        =   array( 
                                                'USER_DIR' =>    $empid , 
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $figurelocation     =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $figurelocation );
                    $figurelocation     =   str_replace( '//' ,'/', $figurelocation );
                    if(!empty($figurelocation))
                    {
                        $figurelocation =   "\\\\".$figurelocation;
                        $figurelocation =   str_replace( '/' ,'\\', $figurelocation );
                    }
                    $destinationurl     =   $figurelocation;
                }
                else
                {
                    $spicepathreplce    =   Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
                    $inp_rep_arr        =   array( 
                                                '{BID}' =>    $bookid , 
                                                '{RID}' =>    $roundname ,
                                                '{CID}' =>    $chapterno,
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                    $figurelocation     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.$rawpath;
                    $figurelocation     =   str_replace( '//' ,'/', $figurelocation );
                    if(!empty($figurelocation))
                    {
                        $figurelocation =   "\\\\".$figurelocation;
                        $figurelocation =   str_replace( '/' ,'\\', $figurelocation );
                    }
                    
                    $spicepathreplce    =   Config::get('serverconstants.ART_PDF_PRODUCTION_PATH');
                    $inp_rep_arr        =   array( 
                                                '{BID}' =>    $bookid , 
                                                '{RID}' =>    $roundname ,
                                                '{CID}' =>    $chapterno,
                                             );
                    $cmn_obj            =   new CommonMethodsController();
                    $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                    $destinationurl     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.$rawpath;
                    $destinationurl     =   str_replace( '//' ,'/', $destinationurl );
                    if(!empty($figurelocation))
                    {
                        $destinationurl =   "\\\\".$destinationurl;
                        $destinationurl =   str_replace( '/' ,'\\', $destinationurl );
                    }
                }
                $whereartmetaid     =   [];
                if($artmetaid !=    '')
                {
                    $whereartmetaid     =   explode(',',$artmetaid);
                }
				
				$revised    = new jobrevisedController();
				$metainfo = '';
				
							
				$jobshetInfo   = $revised->getjobSheetReturn($jobId, $bookid,$metadataID,$chapterno );
				
				
                $getartfigure       =   taskLevelArtMetadataModel::getArtpdfcreationfigureInfo($whereartmetaid);
                if(count($getartfigure)>=1)
                {
                    $spicast                    =   [];
                    $spicast['JOB_ID']          =   $jobId;
                    $spicast['BATCH_ID']        =   '';
                    $spicast['ROUND']           =   $roundId;
                    $spicast['METADATA_ID']     =   $metadataID;
                    $spicast['PROCESS_TYPE']    =   $processtype;
                    $spicast['ART_METADATA_ID'] =   json_encode($whereartmetaid);
                    $spicast['START_TIME']      =   Carbon::now();
                    $spicast['CREATED_DATE']    =   Carbon::now();
                    $spicast['CREATED_BY']      =   $this->loginUserId;
                    $storespicast               =   apipdfcreationModel::store($spicast);
                    // check layout is have or not for current book
                    $getlayoutprofile           =   jobInfoModel::where('JOB_ID',$jobId)->first();
                    $layoutprofile              =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                        =   Config::get('constants.ROUTE_URL').'/api/artpdfcreationCallback';
                    $default_jobsheet_path		=	'';
                    if(!empty($jobshetInfo)){     
                       $default_jobsheet_path  	=    str_replace( '/' , '\\' , $jobshetInfo['jobSheetPath'] );
					}
				 /*
				   $inp_rep_arr        =       array('{BID}' => $bookid , '{RID}' => $round_arr[116] , '{CID}' => $chapterno );
                    $default_jobsheet_path  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $defaultCopyPath );
                    $host_rootdir   =    str_replace( '/' , '\\' , $host_rootdir);
                    $serverDirFiles     =   $ftpObj->allFiles($sourcefile);
                   
                    foreach($serverDirFiles as $value){
                        if(pathinfo($value)['extension'] == 'xml'){
                            $xmlFilePath    =   $value;
                        }
                    }
                    
                    $xmlFilePath                 =       substr( $xmlFilePath ,  strrpos ( $xmlFilePath , '/' )+1 ); 
					
                    $default_jobsheet_path       =       $jobshetInfo['jobSheetPath'];
					*/
                
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('ArtMeta');
                    $xml->writeAttribute("figureLocation", $figurelocation); 
                    $xml->setIndent(true);
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('metaid');
                    $xml->text($metadataID);
                    $xml->endElement();
                    $xml->startElement('aid');
                    $xml->text($chapterno);
                    $xml->endElement();
                    $xml->startElement('round');
                    $xml->text($roundId);
                    $xml->endElement();
                    $xml->startElement('destpath');
                    $xml->text($destinationurl);
                    $xml->endElement();
                    $xml->startElement('jobsheet_location');
                    $xml->text($default_jobsheet_path);
                    $xml->endElement();
                    
                    //FIGURE DETAILS
                    if(count($getartfigure)>=1)
                    {
                        foreach($getartfigure as $key=>$value)
                        {
                            $xml->startElement('Figure');
                            $xml->writeAttribute("query", ""); 
                            $xml->writeAttribute("graphicalabstract", ""); 
                            $xml->writeAttribute("inputMode", $value->INPUT_MODE); 
                            $xml->writeAttribute("complexity", $value->COMPLEXITY); 
                            $xml->writeAttribute("printColor", $value->OUTPUTCOLOR); 
                            $xml->writeAttribute("webColor", ""); 
                            $xml->writeAttribute("inputColor", $value->INPUTCOLOR); 
                            $xml->writeAttribute("workInvolved", $value->WORK_INVOLVED); 
                            $xml->writeAttribute("figureType", $value->FIGURE_TYPE); 
                            $xml->writeAttribute("fileType", $value->INPUT_FILE); 
                            $xml->writeAttribute("remarks", ""); 
                            $xml->writeAttribute("inputDPI", ""); 
                            $xml->writeAttribute("name", $value->FILE_NAME); 
                            $xml->endElement();  
                        }
                    }
                    //work flow tag
                    $xml->startElement("WorkflowAPI"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "pdfcreation");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$metadataID);
                        $xml->writeAttribute('key', "metaid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$roundId);
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $storespicast->TOKEN_KEY);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "date-time");
                        $xml->writeAttribute('value', "{0:yyyy-MM-dd HH-mm-ss}");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();

                    $content 	=   $xml->outputMemory();
					
					 $filename 	=   $bookid.'_'.$storespicast->TOKEN_KEY.'_ArtPdf.xml';
                    $filepath   =   Config::get('serverconstants.ARTWORK_PDF_CREATION_WATCH_PATH');
                   
                    $successfileresponse 	=	$ftpObj->put($filepath.$filename, $content);
                    $response   =   $this->notfoundResponse;
                    if($successfileresponse ==     true)
                    {
                        $response['message']    =   'success';
                    }
                    else
                    {
                        $response['message']    =   'failed';
                    }
                    $response         =   array('status'=>1,'errMsg' => ' [ ART PDF CREATION ] BG process initialized.' , 'params' => array( 'tokenkey' => $storespicast->TOKEN_KEY ) );   
                    return ($response);
                }
                return $response;
            }
            return ($response);
        }
        catch( \Exception $e ){      
	
            return $this->locationNotFoundResponse;
        }
    }
    
	
    public function dosfiftyJobsheetmove($metadataId)
    {
        $response   =   $this->failedResponse;
        try
        {
            $wheredata          =   array('METADATA_ID'=>$metadataId);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $jobId              =   (count($getmetadata)>=1?$getmetadata->JOB_ID:'');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $journalacroynm     =   (count($bookdata)>=1?$bookdata->JOURNAL_ACRONYM:'');
            $isbnprint          =   (count($bookdata)>=1?$bookdata->ISSN_PRINT:'');
            $spicepathreplce    =   Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
            
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                //art reject path
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                            '{CID}' =>    $chapterno,
                                         );
                
                $cmn_obj            =   new CommonMethodsController();
                $artsourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $artsourceqcpath    =   $hostpath.$artsourceqcpath;
                if(!empty($stageName)){
                     $spicepathdir       =   str_replace('ART_QC',$stageName,$artsourceqcpath);
                }else{
                    $spicepathdir       =   str_replace('ART_QC',Config::get('constants.STAGE_NAME.SPICE'),$artsourceqcpath);
                }
                //s50 jobsheet
                $jobsheetpath       =   Config::get('constants.UPDATED_JOBSHEET_PATH');
                $inp_rep_arr        =   array( 
                                            'BOOK_ID' =>    $bookid , 
                                            'ROUND_NAME' =>    Config::get('constants.ROUND_NAME.114')
                                         );
                
                $cmn_obj            =   new CommonMethodsController();
                $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobsheetpath );
                $jobsheetpath       =   $hostpath.$jobsheetpath;
                $jobsheetFiles      =   $ftpObj->allFiles($jobsheetpath);
                
                $ChapterartName     =   '';
                if(count($jobsheetFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    foreach($jobsheetFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if($nameofchapterextn   ==  'xml' && strpos($spiltchapter,Config::get('constants.JOBSHEET_SUFFIX_CONVENTION.S50')) !== false)
                                {
                                    $ChapterartName =   $spiltchapter;
                                }
                            }
                        }
                    }
                }
                
                $sourcepath     =   $jobsheetpath.$ChapterartName;
                $spicedirpath   =   $spicepathdir.$ChapterartName;
                if(empty($sourcepath))
                {
                    $response['errMsg']   =   'S50 jobsheet not found';
                    return $response;
                }
                if($ftpObj->has($spicedirpath))
                {
                    $ftpObj->delete($spicedirpath);
                }
                
                $putfile        =   $ftpObj->copy($sourcepath,$spicedirpath,0777);
                if($putfile ==     true)
                {
                    $response   =   $this->successResponse;
                    $response['errMsg']   =   'JobSheet moved successfully';
                    return $response;
                }
                else
                {
                    $response['errMsg']   =   'JobSheet moved failed';
                    return $response;
                }
            }
            $response['errMsg']   =   'Chapter or file not found';
            return $response;
        }
        catch( \Exception $e )
        {           
            $response   =   $this->locationNotFoundResponse;
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    
    public function doTapssupportingxml($metadataId,$stageName='')
    {
        try {
            $wheredata          =   array('METADATA_ID'=>$metadataId);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $jobId              =   (count($getmetadata)>=1?$getmetadata->JOB_ID:'');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $journalacroynm     =   (count($bookdata)>=1?$bookdata->JOURNAL_ACRONYM:'');
            $isbnprint          =   (count($bookdata)>=1?$bookdata->ISSN_PRINT:'');
            $spicepathreplce    =   Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($getmetadata)>=1)
            {
                
                $metadataID     =   $getmetadata->METADATA_ID;
                $chapterno      =   $getmetadata->CHAPTER_NO;
                $jobId          =   $getmetadata->JOB_ID;
                $eprooftype     =   ($getmetadata->EPROOFING_SYSTEM == '1'?'YES':'NO');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                //art PUT PATH path
                $inp_rep_arr_watch  =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                            '{CID}' =>    $chapterno,
                                         );
                //art reject path
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                            '{CID}' =>    '',
                                            'ART_QC/' =>    '',
                                         );
                $cmn_obj            =   new CommonMethodsController();
                $artsourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $watchpath          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr_watch , $spicepathreplce );
                $artsourceqcpath    =   $hostpath.$artsourceqcpath;
                $watchpath          =   $hostpath.$watchpath;
                
                if(!empty($stageName)){
                    $spicepathdir       =   str_replace('ART_QC',$stageName,$watchpath);
                }else{
                    $spicepathdir       =   str_replace('ART_QC',Config::get('constants.STAGE_NAME.SPICE'),$watchpath);
                }
                
             
//                $serverartqcFiles   =   $ftpObj->allFiles($artsourceqcpath);
                $artsourceqcpath    =   $hostserver.$rootdir.$artsourceqcpath;
                $artsourceqcpath    =   str_replace("//","/",$artsourceqcpath);
                if(!empty($artsourceqcpath))
                {
                    $artsourceqcpath    =   "\\\\".$artsourceqcpath;
                    $artsourceqcpath    =   str_replace( '/' ,'\\', $artsourceqcpath );
                }
                $currentstagename   =   Config::get('constants.ROUND_NAME.116');
                $stagereplacename   =   preg_replace("/[^0-9,.]/", "", $currentstagename);
                $xml                =   new \XMLWriter();
                $xml->openMemory();
                $xml->startDocument();
                $xml->startElement('Magnus');
                    $xml->setIndent(true);
                    $xml->startElement('Site');
                    $xml->text($getlocationftp->LOCATION_NAME);
                    $xml->endElement();
                    $xml->startElement('Location');
                    $xml->text($artsourceqcpath);
                    $xml->endElement();
                    $xml->startElement('Stage');
                    $xml->text($stagereplacename);
                    $xml->endElement();
                    $xml->startElement('Chapter_ID');
                    $xml->text($chapterno);
                    $xml->endElement();
                    $xml->startElement('Acronym');
                    $xml->text($journalacroynm);
                    $xml->endElement();
                    $xml->startElement('Isbn_Number');
                    $xml->text($isbnprint);
                    $xml->endElement();
                    $xml->startElement('EProofing');
                    $xml->text($eprooftype);
                    $xml->endElement();
                    $xml->startElement('BGProcess');
                    $xml->text('NO');
                    $xml->endElement();
                $xml->endElement();
                $xml->endDocument();
                $content        =   $xml->outputMemory();
                $filename       =   'CurrentUser.xml';
                $successfileresponse    =   $ftpObj->put($spicepathdir.$filename, $content);
                $response   =   $this->failedResponse;
                if($successfileresponse ==     true)
                {
                    $response['message']    =   "success";
                }else{
                    $response['message']    =   "failed";
                }
                $response['result'] =   200;
                $response['errMsg'] =   'Spice xml posted sucessfuly...';
                return response()->json($response);   
            }
            return response()->json($this->failedResponse,404);    
        }
        catch( \Exception $e )
        {           
            $response   =   $this->locationNotFoundResponse;
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    
    public function doChapterartmetaxml($metadataId,$stageName = '')
    {
        try
        {
            $wheredata          =   array('METADATA_ID'=>$metadataId);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $whereart           =   array('METADATA_ID'=>$metadataId,'IS_ACTIVE'=>1);
            $artmetaid          =   taskLevelArtMetadataModel::where($whereart)->get();
            $jobId              =   (count($getmetadata)>=1?$getmetadata->JOB_ID:'');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                //art reject path
                if(!empty($stageName)){
                    $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}' =>    $stageName,
                                            '{CID}' =>    $chapterno,
                                         );
                    
                }else{
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}' =>    Config::get('constants.STAGE_NAME.SPICE'),
                                            '{CID}' =>    $chapterno,
                                         );
                }
                $cmn_obj            =   new CommonMethodsController();
                $artsourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $artsourceqcpath    =   $hostpath.$artsourceqcpath;
                $ChapterartName     =   '';
                $serverDirallFiles  =   $ftpObj->allFiles($artsourceqcpath);
                if(count($serverDirallFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    foreach($serverDirallFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    $ChapterartName =   $splitname[0];
                                }
                            }
                        }
                    }
                }
                if(!empty($ChapterartName))
                {
                    $ChapterartName =   $ChapterartName."_Art_Meta.xml";
                }
                else
                {
                    $ChapterartName =   $bookid.'_'.$chapterno.'_Art_Meta.xml';
                }
                $xml                =   new \XMLWriter();
                $xml->openMemory();
                $xml->startDocument();
                $xml->startElement('ArtMetadata');
                    $xml->setIndent(true);
                    if(count($artmetaid)>=1)
                    {
                        foreach($artmetaid as $value)
                        {
                            $xml->startElement('Figureinfo');
                                $xml->startElement('FigureName');
                                $xml->text($value->FILE_NAME);
                                $xml->endElement();
                                $xml->startElement('Format');
                                $xml->text($value->INPUT_FILE);
                                $xml->endElement();
                                $xml->startElement('Color');
                                $xml->text($value->INPUTCOLOR);
                                $xml->endElement();
                                $xml->startElement('Type');
                                $xml->text($value->INPUT_MODE);
                                $xml->endElement();
                            $xml->endElement();
                        }
                    }
                $xml->endElement();
                $xml->endDocument();

                $content        =   $xml->outputMemory();
                $successfileresponse    =   $ftpObj->put($artsourceqcpath.$ChapterartName, $content);
                $response   =   $this->failedResponse;
                if($successfileresponse ==     true)
                {
                    $response['message']    =   "success";
                }else{
                    $response['message']    =   "failed";
                }
                $response['result'] =   200;
                $response['errMsg'] =   'Spice xml posted sucessfuly...';
                return response()->json($response); 
            }
            return response()->json($this->failedResponse,404);
        }
        catch( \Exception $e )
        {           
            $response   =   $this->locationNotFoundResponse;
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    
    public function doChaptermetaxml($metadataId,$stageName='')
    {
        try
        {
            $wheredata          =   array('METADATA_ID'=>$metadataId);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $jobId              =   (count($getmetadata)>=1?$getmetadata->JOB_ID:'');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $isbnprint          =   (count($bookdata)>=1?$bookdata->ISSN_PRINT:'');
            $doi                =   (count($bookdata)>=1?$bookdata->DOI:'');
            $publishername      =   (count($bookdata)>=1?$bookdata->PUBLISHER_NAME:'');
            $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                //art reject path
                if(!empty($stageName)){
                    $inp_rep_arr        =   array( 
                                            '{BID}'     =>    $bookid , 
                                            '{RID}'     =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}'   =>    $stageName,
                                            '{CID}'     =>    $chapterno,
                                         );
                    
                }else{
                $inp_rep_arr        =   array( 
                                            '{BID}'     =>    $bookid , 
                                            '{RID}'     =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}'   =>    Config::get('constants.STAGE_NAME.SPICE'),
                                            '{CID}'     =>    $chapterno,
                                         );
                }
                $cmn_obj            =   new CommonMethodsController();
                $artsourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $artsourceqcpath    =   $hostpath.$artsourceqcpath;
                $ChapterartName     =   '';
                $serverDirallFiles  =   $ftpObj->allFiles($artsourceqcpath);
                if(count($serverDirallFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    foreach($serverDirallFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    $ChapterartName =   $splitname[0];
                                }
                            }
                        }
                    }
                }
                if(!empty($ChapterartName))
                {
                    $ChapterartName =   $ChapterartName."_meta.xml";
                }
                else
                {
                    $ChapterartName =   $bookid.'_'.$chapterno.'_meta.xml';
                }
                $xml                =   new \XMLWriter();
                $xml->openMemory();
                $xml->startDocument();
                $xml->startElement('Metadata');
                $xml->setIndent(true);
                    $xml->startElement('aid');
                    $xml->text($metadataId);
                    $xml->endElement();
                    $xml->startElement('jid');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('pii');
                    $xml->text('');
                    $xml->endElement();
                    $xml->startElement('doi');
                    $xml->text($doi);
                    $xml->endElement();
                    $xml->startElement('pit');
                    $xml->text('NO');
                    $xml->endElement();
                    $xml->startElement('publisher');
                    $xml->text($publishername);
                    $xml->endElement();
                    $xml->startElement('isbn');
                    $xml->text($isbnprint);
                    $xml->endElement();
                    $xml->startElement('titlecategorization');
                    $xml->text('Books');
                    $xml->endElement();
                $xml->endElement();
                $xml->endDocument();

                $content        =   $xml->outputMemory();
                $successfileresponse    =   $ftpObj->put($artsourceqcpath.$ChapterartName, $content);
                $response   =   $this->failedResponse;
                if($successfileresponse ==     true)
                {
                    $response['message']    =   "success";
                }else{
                    $response['message']    =   "failed";
                }
                $response['result'] =   200;
                $response['errMsg'] =   'Spice xml posted sucessfuly...';
                return response()->json($response); 
            }
            return response()->json($this->failedResponse,404);
        }
        catch( \Exception $e )
        {   
            $response   =   $this->locationNotFoundResponse;
            $response['result']     =   500;
            return response()->json($response);
        }
    }
    
    
    public function buildArtTasklevelInsertData( $insertdata ){
    
        extract( $insertdata );

        $round_arr      =           \Config::get( 'constants.ROUND_ID');
        $insert_arr         =       array();

        $insert_arr['JOB_ID']           =       $job_id;
        $insert_arr['METADATA_ID']      =       $metadata_id;
        $insert_arr['FIGURE_NO']        =       $figure_no;
        $insert_arr['FILE_NAME']        =       $figure_no;
        $insert_arr['COMPLEXITY']       =       isset( $complexity ) ? $complexity : 1; 
        $insert_arr['IS_BILLABLE']      =       isset( $is_billable ) ? $is_billable :  1;
        $insert_arr['IS_NEW_FILE']      =       isset( $is_new_file ) ?  $is_new_file : 0;
        $insert_arr['IS_ACTIVE']        =       isset( $is_active ) ? $is_active : 1;
        $insert_arr['CREATED_DATE']     =       isset( $created_date ) ? $created_date : date( 'Y-m-d H:i:s' );
        $insert_arr['CURRENT_ROUND']    =       isset( $current_round ) ? $current_round : $round_arr['S5']; 
        $insert_arr['CURRENT_STAGE']    =       $current_stage;
        $insert_arr['STATUS_ENUM_ID']   =       isset( $status_enum_id ) ? $status_enum_id : 46;  
        $insert_arr['CURRENT_ITERATION']=       1;
        $insert_arr['REVISION_NO']      =       1;
           
        return $insert_arr;
        
    }
    
    public function isArtAllStagesCompleted( $jbstgid ){
        
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   array();
        $stageDetails       =   $checkoutObj->getStageInfo($jbstgid);
        $response   =   $this->failedResponse;
        if( !empty( $stageDetails[0] ) ){
            
            $stageDetails=  $stageDetails[0];
            
            $metaid  =  $stageDetails->METADATA_ID;
            $round   =  $stageDetails->ROUND_ID;
            
            $tlam_obj               =       new taskLevelArtMetadataModel();
            $isart_completed_rec    =       $tlam_obj->isAllartStagesCompleted( $metaid , $round );
           
            if( count( $isart_completed_rec ) ==  0 ) {   
                $response   =   $this->successResponse;
                $response['errMsg']   =   'Art already comleted';
                return  json_encode($response);               
            }
            $response['errMsg']     =   'Art Completed validation got failed';
            return  json_encode($response);
             
        }
        $response['errMsg']     =   'Jobstage information not found.';
        return  json_encode($response);
         
    }

    public function insertNewArtInProcess($artData,$artInfo){
        
        $jobId    = $artInfo['jobID'];
        $artName  = $artData['newfig'];
        $metaid   = $artInfo['metaid'];
        $metastatusId = $artInfo['metadataStatusId'];
        $allinsertsuccess = array();
        $roundId  = Config::get('constants.ROUND_ID.S200');
        $recordExit  =    DB::table('task_level_art_metadata')->select(DB::raw('task_level_art_metadata.FILE_NAME'))->whereIn('FILE_NAME',$artData['newfig'])->where('JOB_ID',$jobId)->where('METADATA_ID',$metaid)->where('CURRENT_ROUND',$roundId)->get();
        $userId      =   (!empty($this->loginUserId)?$this->loginUserId:'5556405');
        
        if(!empty($recordExit) && count($recordExit)!=0){
           $responseExit['newfileexist']    =   $recordExit;
           return $responseExit;
        }
       $figCount =  0; 
       //$figCount     =    DB::table('task_level_art_metadata')->where('JOB_ID',$jobId)->where('METADATA_ID',$metaid)->where('CURRENT_ROUND',$roundId)->count();
       $figCountNoDetails     =    DB::table('task_level_art_metadata')->where('JOB_ID',$jobId)->where('METADATA_ID',$metaid)->where('CURRENT_ROUND',$roundId)->orderBy('ART_METADATA_ID','desc')->first();
       if(!empty($figCountNoDetails)){
         $figCount =   $figCountNoDetails->FIGURE_NO;
       }
       
       $time         =    date( 'Y-m-d H:i:s' );
       $artDetail     =    DB::table('job_round')->where('JOB_ID',$jobId)->where('METADATA_ID',$metaid)->where('ROUND_ID',$roundId)->where('METADATA_STATUS_ID',$metastatusId)->first();
       
       $stageDetails =   array_unique($artInfo['jobStageId']);
       
       $stageDetails =  DB::table('job_stage')->where('JOB_STAGE_ID',$stageDetails['0'])->first();
       $workflwid    =  $stageDetails->WORKFLOW_ID;
       
        foreach( $artName as $index => $value ) {
                $insert_arr   =   array();
                $figCount     =   $figCount+1;
                
                //$filename   =   $insert_arr['FILE_NAME']    =   ($copyStatus[$index]['imageoriname'] == $value?$copyStatus[$index]['imagerename']:$value);    
                $insert_arr['FILE_NAME']        =   $value;  
                $insert_arr['METADATA_ID']      =   $metaid;    
                $insert_arr['JOB_ID']           =   $jobId;    
                $insert_arr['FIGURE_NO']        =   $figCount;
                $insert_arr['METADATA_STATUS_ID']        =   $metastatusId;
                $insert_arr['CURRENT_STAGE']        =   $artDetail->CURRENT_STAGE;
                
                $insert_arr['COMPLEXITY']       =   $artData['complexity'][$index];    
                $insert_arr['CURRENT_ROUND']    =   $roundId;    
                $insert_arr['CURRENT_ITERATION']=   $artDetail->CURRENT_ITERATION_ID;    
                $insert_arr['STATUS_ENUM_ID']   =   46;    
                $insert_arr['FIGURE_TYPE']      =   $artData['type'][$index];    
                $insert_arr['INPUTCOLOR']       =   $artData['inputcolor'][$index];   
                $insert_arr['OUTPUTCOLOR']      =   $artData['outputcolor'][$index];    
                $insert_arr['INPUT_MODE']       =   $artData['mode'][$index];    
                $insert_arr['FIGURE_FULL_MODE'] =   $this->changeartmodename($artData['mode'][$index]); 
                $insert_arr['INPUT_FILE']       =   $artData['files'][$index]; 
                $insert_arr['WORK_INVOLVED']    =   $artData['workinvolved'][$index]; 
                $insert_arr['REMARKS']          =   $artData['remarks'][$index];    
                $insert_arr['CREATED_DATE']     =   $time;
                $insert_arr['CREATED_BY']       =   $this->loginUserId;
                $inserid                        =   DB::table('task_level_art_metadata')->insertGetId( $insert_arr );
               
                $response['msg']                =   'Record insert success';
               
                if( $inserid ){
                   /* $prc_str            =       "CALL movetoproduction('$jobId', '$roundId', '$workflwid', '$metaid', $inserid , '1', '$time', '1'  , '$userId')";
                    $return_status    =       DB::select( $prc_str );
                    
                    $getjobstage        =       DB::table('job_resource')->where('BATCH_ID',$artInfo['batchId'])->first();
                    $manipulationStage  =       \Config::get( 'constants.STAGE_COLLEECTION.ART_MANIPULATION');
                    
                    $sqlData             = "select js.JOB_STAGE_ID from job_round as jr 
                                            join job_stage as js ON jr.JOB_ROUND_ID =  js.JOB_ROUND_ID and js.ITERATION_ID = jr.CURRENT_ITERATION_ID
                                            where jr.METADATA_ID = '$metaid' and jr.ART_METADATA_ID = '$inserid' and js.STAGE_ID = '$manipulationStage'";

                   $stage = DB::select( $sqlData );
                   
                   if(!empty($stage)){

                       $stageID  = $stage['0']->JOB_STAGE_ID;

                       $resource['BATCH_ID']        =   $artInfo['batchId'];
                       $resource['METADATA_ID']     =   $metaid;
                       $resource['ART_METADATA_ID'] =   $inserid;
                       $resource['IS_ART']          =   '1';
                       $resource['JOB_ID']          =   $jobId;
                       $resource['ASSIGNED_TO']     =   $getjobstage->ASSIGNED_TO;
                       $resource['JOB_STAGE_ID']    =   $stageID;
                       $resource['TEAM_ID']         =   $getjobstage->TEAM_ID;
                       $resource['CREATED_DATE']    =  $getjobstage->CREATED_DATE;
                       $resource['CREATED_BY']      =   $getjobstage->CREATED_BY;
                     
                       $resourceinserid                     =   DB::table('job_resource')->insertGetId( $resource );
                       $allinsertsuccess[$value]   =   'succes';
                   }*/
                   $allinsertsuccess[$value]   =   'succes';
                }else{
                    $allinsertsuccess[$value]   =   'failed';
                }              
        } 
        return $allinsertsuccess;
       
    }
    
    public function deleteArt(Request $request){
		
	 $data                         =        json_decode($request->getContent());
         $status = 1;
         
         if(!empty($data->artmetaId)){
             
            $artMetaId	=	$data->artmetaId;
            DB::table('art_category_log')->where('ART_METADATA_ID', '=', $artMetaId)->delete();
            DB::table('task_level_art_metadata')->where('ART_METADATA_ID', '=', $artMetaId)->delete();
            $result             =   array('status'=>2   ,  'msg'=>'Success'  , 'errMsg'=>'Successfully figure(s) deleted');
             
            return  json_encode($result);
            
         }
         
        $result             =   array('status'=>1   ,  'msg'=>'Failed'  , 'errMsg'=>'Unable to delete figure(s)');
        return  json_encode($result);
    }
    
    public function downloadWorkupFiles(Request $request){
        
        $data                         =        json_decode($request->getContent());
        
        if(!empty($data->batchId)){
            $getjobstage        =   jobResource::where('BATCH_ID',$data->batchId)->get();
            $getjobstage        =   $getjobstage->pluck('JOB_STAGE_ID');
            $jstageId           =   $getjobstage['0'];
             $workflowPath        =   new workflowServerMapPathModel();
             $pathDetails      =   $workflowPath->getWorkflowServerMapPath($jstageId);
           
            foreach($getjobstage as $k => $jsId){
                $stageIDs[] =   $jsId;
            }
            
            $jobStageIDs             =    implode(',',$stageIDs);
            $checkoutObj             =    new checkoutModel();
            $jstageInfo              =   $checkoutObj->getArtStageInfo($jobStageIDs);
            
             $workDir           =   $pathDetails['detail']['work'];
             
             $destDir           =   $pathDetails['detail']['artworkuppathwithHost'];
            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            $copyStatus         =   array();
            
            $destDirPath        =   str_ireplace($serverDetail['host'],'',$workDir);
            //$directory          =   $fileHandlerObj->make_directory($destDirPath);
           
            $data               =   $fileHandlerObj->getDirectoryFiles($destDir);
            
            if(!empty($data)){
                
                $listofFiles        =   array();
                foreach($data as $key => $datas){
                  $exp  =   explode('/',$datas);
                  $fileext =   explode('.',end($exp));
                  $listofFiles[$fileext['0']][] =  $fileext['1'];
                }
            }else{
               $result             =   array('status'=>1   ,  'msg'=>'Failed'  , 'errMsg'=>'Not available for checkout Figure(s)'); 
                return  json_encode($result); 
            }
            
            $fileAvailable   = '0';
            foreach($jstageInfo as $key => $stageinfo ){
                $filename           =   $stageinfo->FILE_NAME;
                $filearray          =   explode('.',$filename);
               
               // echo "<pre>";print_r($listofFiles);exit;
                if(array_key_exists($filearray['0'], $listofFiles)){
                  
                    foreach($listofFiles[$filearray['0']] as $key2 => $extension ){
                       
                        $filenamenew           =   $filearray['0'].'.'.$extension;
                        $fileNameWithPath      =   $destDir.'/'.$filearray['0'].'.'.$extension;
                      
                        $fileExistPath          =   str_ireplace($serverDetail['host'],'',$fileNameWithPath);
                        $status                 =    $fileHandlerObj->ftp_file_exist($fileExistPath);
                        if($status == true){
                            $fileAvailable      =   '2';
                            
                            $directory          =   $fileHandlerObj->make_directory($destDirPath.'WORK_UP');
                            $fileString         =   file_get_contents($crd.$fileNameWithPath);
                            $filenamewithpath   =   $crd.$workDir.'WORK_UP/'.$filenamenew;
                            $filecreate         =   @file_put_contents($filenamewithpath, $fileString);
                        }
                       
                    }
                }
            }
            
            if($fileAvailable == '2'){
                $result             =   array('status'=>2   ,  'msg'=>'Success'  , 'errMsg'=>'Successfully files are downloaded'); 
                return  json_encode($result); 
            }else{
                 $result             =   array('status'=>1   ,  'msg'=>'Failed'  , 'errMsg'=>'Not available for checkout Figure(s)'); 
                return  json_encode($result);
            }
              
            }
           
         
        }
       
    public function getArtMetaDataTags( $metaid , $returns = 'xml' ){
        
        $xmlStr     =   '';
        
        if( gettype( $metaid ) == 'array' ){
            $metaarr = $metaid;
        }else{
            $metaarr    =   array( $metaid );
        }
        
         //DB::enableQueryLog();
            $getartfigure       =       DB::table( 'task_level_art_metadata' )
                                            ->whereIn( 'task_level_art_metadata.METADATA_ID' , $metaarr )
                                            ->orderBy('task_level_art_metadata.ART_METADATA_ID','desc')
                                            ->get();  
         // $a  =   DB::getQueryLog($getartfigure);  
        
            if($returns == 'xml' ){
                $xmlStr         .=          $this->prepareFigureTags( $getartfigure , $returns );
                $xmlStr        .=          '';
            }if($returns == 'array' ){
                $xmlStr         =          $this->prepareFigureTags( $getartfigure , $returns );
                return $xmlStr;
            }else{
                $xmlStr =   $this->prepareFigureTags( $getartfigure , $returns );
            }
            
         
        return $xmlStr;
        
    }

    public function getChapterMetaDataTags( $metaid , $returns = 'xml' ){
        
        $xmlStr     =   '';
        DB::enableQueryLog();
            $getartfigure       =       DB::table( 'task_level_metadata' )
                                            ->whereIn( 'task_level_metadata.JOB_ID' , array( $metaid )  )
                                            ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                            ->groupBy('task_level_metadata.METADATA_ID')
                                            ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                            ->get();   
           
     //       $a  =   DB::getQueryLog($getartfigure);
       
            if($returns == 'xml' ){
                $xmlStr         .=          $this->prepareFigureTags( $getartfigure , $returns );
                $xmlStr        .=          '';
            }if($returns == 'array' ){
                $xmlStr         =          $this->prepareFigureTags( $getartfigure , $returns );
                return $xmlStr;
            }if($returns == 'json' ){
                $xmlStr         =          $getartfigure;
                return $xmlStr;
            }else{
                $xmlStr =   $this->prepareFigureTags( $getartfigure , $returns );
            }
         
        return $xmlStr;
        
    }
    
    //art category log table based preparation
    
    public function prepareFigureTags( $input_rec ,  $returns = 'xml'){
       
       
        $figure =   '';
        $figure_arr     =       array();
        $figure_str     =       '';
        
        if( $input_rec->count() ){         
            
            foreach( $input_rec as $key => $value ){
                
                extract((array)$value);
                
                $figname            =       isset( $FIGURE_NAME ) ? $FIGURE_NAME : $FILE_NAME;
                $inp_file_type      =       isset( $FILE_TYPE) ? $FILE_TYPE : $FIGURE_TYPE;
                $complexity         =       isset( $COMPLEXITY) ? $COMPLEXITY : $COMPLEXITY;
                $mode               =       isset( $MODE ) ? $MODE : $INPUT_MODE;
                $workinv            =       isset( $WORK_INVOLVED) ? $WORK_INVOLVED : $WORK_INVOLVED;
                $inpClr             =       isset( $INPUT_COLOR) ? $INPUT_COLOR : $INPUTCOLOR;
                $outClr             =       isset( $OUT_COLOR) ? $OUT_COLOR : $OUTPUTCOLOR;
                $remarks            =       isset( $REMARKS) ? $REMARKS: $REMARKS;
                
                if( $returns == 'xml' ){
                    $artMetaid       =       $value->ART_METADATA_ID;
                    $figure_str     .=      '<Figure artMetaId="'.$artMetaid.'"  name="'.$figname.'" inputFileType="'.$inp_file_type.'"  modeofReceipt="" ';
                    $figure_str     .=      ' complexity="'.$complexity.'"  mode="'.$mode.'"  workInvolved="'.$workinv.'" inputColor="'.$inpClr.'" ';
                    $figure_str     .=      ' outputColor="'.$outClr.'"  Remarks="" />'.PHP_EOL;
                }
                
                if( $returns !== 'xml' ){
                    $artMetaid       =       $value->ART_METADATA_ID;
                    $figure_arr[$key]['artmetaid']  =   $artMetaid;
                    $figure_arr[$key]['filename']  =   $figname;
                    $figure_arr[$key]['query']  =   '';
                    $figure_arr[$key]['graphicalabstract']  =   '';
                    $figure_arr[$key]['inputMode']  =   $mode;
                    $figure_arr[$key]['complexity']  =   $complexity;
                    $figure_arr[$key]['printColor']  =   $outClr;
                    $figure_arr[$key]['webColor']  =   '';
                    $figure_arr[$key]['inputColor']  =   $inpClr;
                    $figure_arr[$key]['workInvolved']  =   $workinv;
                    $figure_arr[$key]['figureType']  =   $inp_file_type;
                    //$figure_arr[$key]['fileType']  =   $value->INPUT_FILE;
                    $figure_arr[$key]['remarks']  =   '';
                    $figure_arr[$key]['inputDPI']  =   '';
                    
                }
                
            }
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;
            
            if( $returns == 'array' )
                $figure     =   $figure_arr;
            
            if( $returns == 'xml' )
                $figure     =   $figure_str;
                
            
         }else{
            //throw new \Exception( 'Art Data not Found for given metaid.' );
        }
        
       
        return $figure;
    }
    
    
    public function prepareFigureTagsForLowRes( $input_rec ,  $returns = 'xml' , $artQcPath ){
       
        $figure =   '';
        $figure_arr     =       array();
        $figure_str     =       '<figurelist>';
        
        if( $input_rec->count() ){         
            
            foreach( $input_rec as $key => $value ){
                
                extract((array)$value);
                
                $figname            =       isset( $FIGURE_NAME ) ? $FIGURE_NAME : $FILE_NAME;
                $inp_file_type      =       isset( $FILE_TYPE) ? $FILE_TYPE : $FIGURE_TYPE;
                $complexity         =       isset( $COMPLEXITY) ? $COMPLEXITY : $COMPLEXITY;
                $mode               =       isset( $MODE ) ? $MODE : $INPUT_MODE;
                $workinv            =       isset( $WORK_INVOLVED) ? $WORK_INVOLVED : $WORK_INVOLVED;
                $inpClr             =       isset( $INPUT_COLOR) ? $INPUT_COLOR : $INPUTCOLOR;
                $outClr             =       isset( $OUT_COLOR) ? $OUT_COLOR : $OUTPUTCOLOR;
                $remarks            =       isset( $REMARKS) ? $REMARKS: $REMARKS;
                
                if( $returns == 'xml' ){
                    $artMetaid       =       $value->ART_METADATA_ID;
                    $figure_str     .=      '<figure path="'.$artQcPath.$figname.'" type="'.$mode.'"/>'.PHP_EOL;
                }
                
                if( $returns !== 'xml' ){
                    $artMetaid       =       $value->ART_METADATA_ID;
                    $figure_arr[$key]['artmetaid']  =   $artMetaid;
                    $figure_arr[$key]['filename']  =   $figname;
                    $figure_arr[$key]['query']  =   '';
                    $figure_arr[$key]['graphicalabstract']  =   '';
                    $figure_arr[$key]['inputMode']  =   $mode;
                    $figure_arr[$key]['complexity']  =   $complexity;
                    $figure_arr[$key]['printColor']  =   $outClr;
                    $figure_arr[$key]['webColor']  =   '';
                    $figure_arr[$key]['inputColor']  =   $inpClr;
                    $figure_arr[$key]['workInvolved']  =   $workinv;
                    $figure_arr[$key]['figureType']  =   $inp_file_type;
                    //$figure_arr[$key]['fileType']  =   $value->INPUT_FILE;
                    $figure_arr[$key]['remarks']  =   '';
                    $figure_arr[$key]['inputDPI']  =   '';
                    
                }
                
            }
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;
            
            if( $returns == 'xml' )
                $figure     =   $figure_str;
                
            $figure		.=		'</figurelist>';
            
         }else{
            //throw new \Exception( 'Art Data not Found for given metaid.' );
        }
        
       
        return $figure;
    }
    
    public function getArtListDesign( $metaid ){
        
        //$metaid     =   $request->input( 'metaid' );
        
        $response   =   $this->oopsErrorResponse;
        $return_design          =     '';
        
        if( !empty( $metaid ) ){
          
            $records_arr        =       $this->getArtMetaDataTags( $metaid , 'json' );
             
                $return_design  .=    '<div class="form-group">'
                        . '<div class="col-md-2 col-sm-2 col-xs-2">Select Art files for Rejection : </div>';
					
					if( count( $records_arr ) && !empty( $records_arr ) && isset( $records_arr ) && ( gettype( $records_arr ) == 'array' ) ){
						
						$return_design  	.=	'<div class="col-md-10 col-sm-10 col-xs-10">';               
						$return_design      .=  '<select data-placeholder="Select art from list" multiple name="prqcArtRejectionSelection" class="prqcArtRejectionSelection chosen-select form-control" style="width="1139px">';
						$return_design      .=       $this->artListingDesign( $records_arr );
						$return_design      .=  '</select>';
						$return_design      .= '</div>';
			
					}else{
						
						$return_design  	.=	' -- ';
						
					}
					
				
				$return_design  	.= '</div><br/><br/>'
				. '<div class="space-2"></div>';
                
            return $return_design;
            
            //below code is valid but as of now not in use.
            
            $return_design  =   '
                    <hr/>
                    <div id="task-tab" class="tab-pane active text-center">
                            <h4 class="smaller lighter green">
                                <i class="ace-icon fa fa-list"></i>
                                Select Art For Rework
                        </h4>
                    </div>    
                    <div>     
                    <hr/>
                    <input type="hidden" name="metadataStatusId" ng-model="metadataStatusId" class="form-control" value=""  />
                    <input type="hidden" name="ChapterJobId" ng-model="ChapterJobId" class="form-control" value=""  />
                    <input type="hidden" name="metaid" ng-model="ChapterMetaid" class="form-control" value=""  />
                    <input type="hidden" name="CheckFlag" ng-model="CheckFlag" class="form-control" value="0"  />
                    <input type="hidden" name="chaptername" class="form-control" value="1"/>
                    <input type="hidden" id="srcFolder" value=""/>
				
		<table class="table table-bordered table-striped">  
                    <thead class="thin-border-bottom">
                        <tr>
                            <th>Reject</th>
                            <th>Art Name</th>                            
                            <th>File</th>
                            <th>Type</th>
                            <th>Complexity</th>
                            <th>Mode</th>                            
                            <th>Work Involved</th>
                            <th>Input Color Mode</th>
                            <th>Output Color Mode</th>
                            <th>Remarks</th>
                            </tr>
                    </thead>
                    <tbody>
                        '.$this->artListingDesign( $records_arr ).'
                    </tbody>
		</table>
                </div>';
            $response   =   $this->successResponse;
            $response['errMsg']     =     'Design of art available for rejection';
            $response['artTableDesign']   =     $return_design;

        }
        
        return response()->json( $response );
    }
    
    
     public function getChapterListDesign( $metaid ){
        
        //$metaid     =   $request->input( 'metaid' );
        
        $response   =   $this->oopsErrorResponse;
        $return_design          =     '';
        
        if( !empty( $metaid ) ){
            
            $records_arr        =       $this->getChapterMetaDataTags( $metaid , 'json' );
           
      
              $return_str  = '';  
            foreach( $records_arr as $key => $value ){

                                $return_str     .=   '<option value="'.$value->METADATA_ID.'">';
                                $return_str     .=   $value->CHAPTER_NO;
                                $return_str     .=   '</option>';

            }
           
            
                $return_design  .=    '<div class="form-group">'
                        . '<div class="col-md-2 col-sm-2 col-xs-2">Select Chapters for Rejection : </div>';
					
					if( count( $records_arr ) && !empty( $records_arr ) && isset( $records_arr )  ){
						
						$return_design  	.=	'<div class="col-md-10 col-sm-10 col-xs-10">';               
						$return_design      .=  '<select data-placeholder="Select art from list" multiple name="prqcArtRejectionSelection" class="prqcArtRejectionSelection chosen-select form-control" style="width="1139px">';
						$return_design      .=       $return_str;
						$return_design      .=  '</select>';
						$return_design      .= '</div>';
			
					}else{
						
						$return_design  	.=	' -- ';
						
					}
					
				
				$return_design  	.= '</div><br/><br/>'
				. '<div class="space-2"></div>';
                
            return $return_design;
            
          

        }
        
        return response()->json( $response );
    }
    
    public function artListingDesign( $records_arr , $returnformat = 'option' ){
        
        $return_str     =   '';
        if( !empty( $records_arr ) ){
            
            $yes    =   "'Y'";
            $no     =   "'N'";
            
            if( $returnformat == 'tablerow' ){
                
            foreach( $records_arr as $key => $value ){
                
                $return_str     .=  '<tr id="artmeta_'.$value['artmetaid'].'" class="clear">'
                        .'<td>'
                            .'<input id="'.$value['artmetaid'].'" type="checkbox" value="'.$value['artmetaid'].'" ng-checked="selectionPR_QC_art.indexOf('.$value['artmetaid'].') > -1" ng-click="toggleSelection( '.$value['artmetaid'].' )" />'
                        . '</td>'
                        .'<td>'
                            .'<input type="text" name="chapters[]" ng-init="prqcArt.figurename='."'".$value['filename']."'".'" class="form-control" value="'.$value['filename'].'" ng-model="prqcArt.figurename" required disabled/>
                            <input type="hidden" name="artmetaid[]" class="form-control" value="'.$value['artmetaid'].'" ng-model="prqcArt.ART_METADATA_ID" required/>'
                        . '</td>'
                        .'<td>'
                            .'<select class="form-control" name="file[]" ng-model="prqcArt.INPUT_FILE" required disabled>
                                <option value=""> -- Select -- </option>
                                <option ng-selected="true" value="">'.$value['filename'].'</option>
                            </select>'
                        .'</td>'
                        .'<td>
                            <select  class="form-control" name="type[]" ng-model="prqcArt.FIGURE_TYPE" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option value="" ng-selected="true">'.$value['figureType'].'</option>
                            </select>
                        </td>'
                         .'<td>
                            <select  class="form-control" name="complexity[]" ng-model="prqcArt.COMPLEXITY" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option value="" ng-selected="true"> '.$value['complexity'].' </option>
                            </select>
                        </td>'
                        .'<td>
                            <select  class="form-control" name="mode[]" ng-model="prqcArt.INPUT_MODE" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option  value="" ng-selected="true"> '.$value['inputMode'].'</option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="workinvolved[]" ng-model="prqcArt.WORK_INVOLVED" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option  value="" ng-selected="true"> '.$value['inputMode'].' </option>
                            </select>
                        </td>
                        <td>
                            <select  class="form-control" name="inputcolor[]" ng-model="prqcArt.INPUTCOLOR" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option  value="" ng-selected="true"> '.$value['inputColor'].' </option>
                            </select>
                        </td>
                        <td>
                            <select class="form-control" name="outputcolor[]" ng-model="prqcArt.OUTPUTCOLOR" required disabled>
                                <option  value=""> -- Select -- </option>
                                <option  value="" ng-selected="true"> '.$value['printColor'].'</option>
                            </select>
                        </td>'
                        .'  
                        <td>
                            <input type="text" class="form-control" id="required_'.$value['artmetaid'].'" name="art_remarks[]" value="" />
                        </td>'
                        . '</tr>';
                
            }
            
        }
        
        }
        
        if( $returnformat == 'option' ){
			
            if( !empty( $records_arr ) ){
				
				foreach( $records_arr as $key => $value ){
					
					$return_str     .=   '<option value="'.$value['artmetaid'].'">';
						$return_str     .=   $value['filename'];
					$return_str     .=   '</option>';
					
				}
            }
			
        }
        
        return $return_str;
        
    }
	
	public function doReferencePdfCopy($metaid){
      $data    =    $this->doReferencePdfFileCopy($metaid,'');
       echo "<pre>";print_r($data);exit;
    }
      public function doReferencePdfFileCopy($metadataId,$stageName='')
    {
        try
        {
            $wheredata          =   array('METADATA_ID'=>$metadataId);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $jobId              =   (count($getmetadata)>=1?$getmetadata->JOB_ID:'');
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            $isbnprint          =   (count($bookdata)>=1?$bookdata->ISSN_PRINT:'');
            $doi                =   (count($bookdata)>=1?$bookdata->DOI:'');
            $publishername      =   (count($bookdata)>=1?$bookdata->PUBLISHER_NAME:'');
            $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
           
            $referencePdf       =   Config::get('constants.REFERENCE_PDF_PATH');
                   
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                $crd                =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
               
                $rootdir            =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                //art reject path
                if(!empty($stageName)){
                    $inp_rep_arr        =   array( 
                                            '{BID}'     =>    $bookid , 
                                            '{RID}'     =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}'   =>    $stageName,
                                            '{CID}'     =>    $chapterno,
                                         );
                    
                }else{
                $inp_rep_arr        =   array( 
                                            '{BID}'     =>    $bookid , 
                                            '{RID}'     =>    Config::get('constants.ROUND_NAME.116'),
                                            '{STAGE}'   =>    Config::get('constants.STAGE_NAME.SPICE'),
                                            '{CID}'     =>    $chapterno,
                                         );
                }
                $cmn_obj                  =   new CommonMethodsController();
                $artsourceqcpath          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $referencesourceqcpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $referencePdf );
                
                $refdirectory             =   $ftpObj->allFiles($hostpath.$referencesourceqcpath);
                
                
                $ChapterartName     =   '';
				
                $serverDirallFiles  =   $ftpObj->allFiles($hostpath.$artsourceqcpath);
                if(count($serverDirallFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    foreach($serverDirallFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    $ChapterartName =   $splitname[0];
                                }
                            }
                        }
                    }
                }
                if(!empty($ChapterartName))
                {
                    $ChapterartName =   $ChapterartName."_Reference.pdf";
                }
                else
                {
                    $ChapterartName =   $bookid.'_'.$chapterno.'_Reference.pdf';
                }
                               
                if(!empty($refdirectory)){
                    $options  		= array('ftp' => array('overwrite' => true));
                    $stream   		= stream_context_create($options);
                    foreach($refdirectory as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                           
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                
                                if(!empty($splitname) && $splitname['1'] == 'pdf'){
                                  $srcfile          =   $crd.$hostserver.'/'.$jsonvalue; 
								 
                                  $destpath         =   $crd.$hostserver.$hostpath.$artsourceqcpath.$ChapterartName;
                                  $contetnt         =  file_get_contents($srcfile);
                                  $successfileresponse =  file_put_contents($destpath, $contetnt,0,$stream);
                                }
                               
                            }
                        }
                    }
                }
               //$successfileresponse    =   $ftpObj->put($artsourceqcpath.$ChapterartName, $content);
                $response   =   $this->successResponse;
                if(!empty($successfileresponse) ==     true)
                {
                    $response['message']    =   'success';
                }
                else
                {
                    $response['message']    =   'failed';
                }
                $response['errMsg']     =   'Spice xml posted sucessfuly...';
                return response()->json($response);
            }
            $response   =   $this->failedResponse;
            $response['errMsg']     =   'Chapter or Job Info data is missing';
            return response()->json($response,404);
        } catch( \Exception $e ) {          
            print_r($e->getMessage());
            $response   =   $this->locationNotFoundResponse;
            $response['result']     =   500;
            return response()->json($response);
        }
    }
	
	public function getfigurecountInfo($jobId)
    {
		
		$MetadataID 		=	$jobId;
        $getartinfo         =   taskLevelMetadataModel::getArtfigureInfo($MetadataID);
      
        $onlinetotalcolor   =   $getartinfo->pluck('INPUTCOLOR')->all();
        $printtotalcolor    =   $getartinfo->pluck('OUTPUTCOLOR')->all();
        $onlinebwcolor      =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
        $onlineillu         =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
        $printbwcolor       =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
        $printillu          =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
		$figure_str 		=	'';
		
		 $figure_str     .=      '<TotalOnLine>'.count($onlinetotalcolor).'</TotalOnLine>';
		 $figure_str     .=      '<TotalColorOnLine>'.count($onlineillu).'</TotalColorOnLine>';
		 $figure_str     .=      '<TotalBwOnLine>'.count($onlinebwcolor).'</TotalBwOnLine>';
		 $figure_str     .=      '<TotalPrint>'.count($printtotalcolor).'</TotalPrint>';
		 $figure_str     .=      '<TotalColorPrint>'.count($printillu).'</TotalColorPrint>';
		 $figure_str     .=      '<TotalBwPrint>'.count($printbwcolor).'</TotalBwPrint>';
		
       return $figure_str;
        
    }
    
    
    }
    