<?php
namespace App\Http\Controllers\emailsetup;
use App\Http\Controllers\Controller;
use App\Models\jobInfoModel;
use App\Models\jobModel;
use App\Models\CountriesModel;
use App\Models\taskLevelMetadataModel;
use App\Models\emailSetupStagewiseModel;
use App\Models\stageModel;
use App\Models\roundModel;
use App\Models\componentCategoryModel;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use Session;
use Mail;
use Storage;
use Carbon\Carbon;
use Validator;
use File;
use DB;
use Log;
use Config;

class emailsetupstagewiseController extends Controller
{    
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    //EMAIL REMAINDER SETUP PAGES
    public function index(Request $request){
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_EMAIL'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data["userId"]     =   $this->loginUserId;
        $getId              =   $request->input('emailstageid');
        return view('email_setup_stage.emailsetup-index')->with( $data );
    }
    
    public function dogetemailstagelist(Request $request)
    {
        $response               =   [];
        $data                   =   emailSetupStagewiseModel::select(DB::Raw('ID,ROUND_ID,STAGE_ID,COMPONENT_TYPE_ID,EMAIL_SUBJECT,TO_EMAIL,CC_EMAIL,BCC_EMAIL,SUBSTRING_INDEX(EMAIL_TEMP_PATH, "/",-1) as EMAIL_PATH,IS_ACTIVE'))->get();
        $response["stgaelist"]  =   stageModel::Active()->get();
        $response["component"]  =   componentCategoryModel::Active()->get();
        $response["roundlist"]  =   roundModel::Active()->get();
        $response["emaillist"]  =   $data;
        $response["userId"]     =   Session::get('users')['user_id'];
        return response()->json($response);
    }
    
    public function doAddnewemailsetupstage(Request $request)
    {      
        try
        {
            $response   =   $this->oopsErrorResponse;
            $response["validation"]  =   "";
            if($request->method()   ==  "POST")
            {
                $validation 	=   Validator::make($request->all(), [
                                                                            'roundId' => 'required|numeric',
                                                                            'stageId' => 'required|numeric',
                                                                            'emailsubject' => 'required',
                                                                            'toemail' => 'required',
//                                                                            'emailsetupfile' => 'required|file|mimes:txt',
                                                                            'Typeofrequest' => 'required'
                                                                    ]);
                if ($validation->fails())
                {
                    $response   =   $this->validationResponse;
                    $response['validation']     =   $validation->errors();
                    return response()->json($response,400);
                }
                $Typeofrequest  =   trim($request->input('Typeofrequest'));
                $roundid        =   trim($request->input('roundId'));
                $stageid        =   trim($request->input('stageId'));
                $componentId    =   trim($request->input('componentId'));
                $statusEnum     =   trim($request->input('statusEnum'));
                $subject        =   strtoupper(trim($request->input('emailsubject')));
                $toemail        =   rtrim(strtolower($request->input('toemail')),',');
                $ccemail        =   rtrim(strtolower($request->input('ccemail')),',');
                $getroundinfo   =   roundModel::where('ID',$roundid)->first();
                $stagename      =   stageModel::where('STAGE_ID',$stageid)->first();
                $roundname      =   "";
                $ccemail        =   ($ccemail   ==  "undefined"?'':$ccemail);
                if(count($getroundinfo)>=1 && count($stagename)>=1)
                {
                    $roundname  =   $getroundinfo->NAME;
                    $stagename  =   $stagename->STAGE_NAME;
                }
                $filenameshouldbe   =   $roundname.'_'.$stagename;
                $filename       =   "";
                $fileexetention =   "";
                $emailsetupfile =   $request->file('emailsetupfile');
                if(!empty($emailsetupfile))
                {
                    $filename       =   $emailsetupfile->getClientOriginalName();
                    $fileexetention =   $emailsetupfile->getClientOriginalExtension();
                }
                if(!empty($emailsetupfile)  && $fileexetention  !=  'txt')
                {
                    $response["errMsg"]  =   'Invalid, Kindly Upload valid text file';
                    return response()->json($response,400);
                }
                $getexistidofemailstageid   =   "";
                $componentname      =   "";
                $errorexistmsg      =   "";
                $wheredata              =   [];
                if($Typeofrequest   ==  "update")
                {
                    $getexistidofemailstageid   =   trim($request->input('existId'));
                    if (empty($getexistidofemailstageid))
                    {
                        return response()->json($response,400);
                    }
                    $wheredata['STAGE_ID']  =   $stageid;
                    $wheredata['ROUND_ID']  =   $roundid;
                    if($componentId     !=  0 || $componentId !=    ''){
                        $wheredata['COMPONENT_TYPE_ID']  =   $componentId;
                        $componentdata      =   componentCategoryModel::where('ID',$componentId)->first();
                        $componentname      =   ($componentdata !=  null?$componentdata->NAME:'');
                    }
                    $existupdateroundstage  =   emailSetupStagewiseModel::Active()->where($wheredata)->where('ID','<>',$getexistidofemailstageid)->first();
                    if(count($existupdateroundstage)>=1)
                    {
                        $errorexistmsg      .=   'Email template is already exists for this round '.$roundname.' and stage '.$stagename;
                        if($componentname !=  ''){
                            $errorexistmsg  .=  'and component type '.$componentname;
                        }
                        $response["errMsg"]  =   $errorexistmsg.'!';
                        return response()->json($response,400);
                    }
                }
//                if(!empty($emailsetupfile))
//                {
//                    if(strpos($filename,$roundname.'_'.$stagename) !==    false){
//                    }else{
//                        $response 	=	array('result'=>400,'errMsg'=>' Template file name should be '.$roundname.'_'.$stagename.', kindly retry! '.$filename,'validation'=>'');
//                        return response()->json($response,400);
//                    }
//                }
                
                if(ctype_space($emailsetupfile) || strpos($filename,' ') !==    false)
                {
                    $response["errMsg"]  =   ' Kindly remove white space in '.$filename;
                    return response()->json($response,400);
                }
                //check exist round and stage
                $wheredata          =   ['STAGE_ID'=>$stageid,'ROUND_ID'=>$roundid];
                $wheredata['STAGE_ID']  =   $stageid;
                $wheredata['ROUND_ID']  =   $roundid;
                if($componentId     !=  0 || $componentId !=    ''){
                    $wheredata['COMPONENT_TYPE_ID']  =   $componentId;
                    $componentdata      =   componentCategoryModel::where('ID',$componentId)->first();
                    $componentname      =   ($componentdata !=  null?$componentdata->NAME:'');
                }
                $existroundstage    =   emailSetupStagewiseModel::Active()->where($wheredata)->first();
                if(count($existroundstage)>=1 && $Typeofrequest     ==  "insert")
                {
                    $errorexistmsg      .=   'Email template is already exists for this round '.$roundname.' and stage '.$stagename;
                    if($componentname !=  ''){
                        $errorexistmsg  .=  'and component type '.$componentname;
                    }
                    $response["errMsg"]  =   $errorexistmsg.'!';
                    return response()->json($response,400);
                }
                
                if(!empty($stagename) && $Typeofrequest     ==  "insert")
                {
                    if(file_exists(public_path().'/EmailSetupStage/'.$filename))
                    {
                        $response["errMsg"]  =   'Email template is already exists '.$filename.', Kindly rename it.!';
                        return response()->json($response,400);
                    }
                    $targetdirectory    =   public_path().'/EmailSetupStage/';
                    $request->file('emailsetupfile')->move($targetdirectory, $filename);
                    $target_path        =   '/EmailSetupStage/'.$filename;
                    $datainsert         =   [];
                    $datainsert['ROUND_ID']         =   $roundid;
                    $datainsert['STAGE_ID']         =   $stageid;
                    $datainsert['COMPONENT_TYPE_ID']=   $componentId;
                    $datainsert['EMAIL_SUBJECT']    =   $subject;
                    $datainsert['EMAIL_TEMP_PATH']  =   $target_path;
                    $datainsert['TO_EMAIL']         =   $toemail;
                    $datainsert['CC_EMAIL']         =   $ccemail;
                    $datainsert['CREATED_BY']       =   $this->loginUserId;
                    $datainsert['CREATED_DATE']     =   Carbon::now();
                    $storeresponse      =   emailSetupStagewiseModel::insertGetId($datainsert);
                    if($storeresponse>=1)
                    {
                        $response 	=	$this->insertedResponse;
                        $response["validation"]     =   '';
                        return response()->json($response);
                    }
                    $response["errMsg"]  =   'Email template upload failed! try again';
                    return response()->json($response,400);
                }
                if(!empty($stagename) && $Typeofrequest     ==  "update")
                {
                    $emailcontent       =   emailSetupStagewiseModel::where('ID',$getexistidofemailstageid)->first();
                    if(count($emailcontent)>=1)
                    {
                        $updatedata         =   [];
                        $filepathloc    =   $emailcontent->EMAIL_TEMP_PATH;
                        if(!empty($request->file('emailsetupfile')))
                        {
                            if(file_exists(public_path().'/'.$filepathloc))
                            {
                                unlink(public_path().'/'.$filepathloc);
                            }
                            $targetdirectory    =   public_path().'/EmailSetupStage/';
                            $request->file('emailsetupfile')->move($targetdirectory, $filename);
                            $target_path        =   '/EmailSetupStage/'.$filename;
                            $updatedata['EMAIL_TEMP_PATH']  =   $target_path;
                        }
                        $updatedata['ROUND_ID']         =   $roundid;
                        $updatedata['STAGE_ID']         =   $stageid;
                        $updatedata['COMPONENT_TYPE_ID']=   $componentId;
                        $updatedata['EMAIL_SUBJECT']    =   $subject;
                        $updatedata['TO_EMAIL']         =   $toemail;
                        $updatedata['CC_EMAIL']         =   $ccemail;
                        $updatedata['UPDATED_BY']       =   $this->loginUserId;
                        $updatedata['UPDATED_DATE']     =   Carbon::now();
                        $updatedata['IS_ACTIVE']        =   $statusEnum;
                        $storeresponse      =   emailSetupStagewiseModel::where('ID',$getexistidofemailstageid)->update($updatedata);
                        if($storeresponse>=1)
                        {
                            $data       =   emailSetupStagewiseModel::select(DB::Raw('ID,ROUND_ID,STAGE_ID,COMPONENT_TYPE_ID,EMAIL_SUBJECT,TO_EMAIL,CC_EMAIL,BCC_EMAIL,SUBSTRING_INDEX(EMAIL_TEMP_PATH, "/",-1) as EMAIL_PATH,IS_ACTIVE'))->where('ID',$getexistidofemailstageid)->first();
                            $response   =   $this->updatedResponse;
                            $response['validation']     =   $data;
                            return response()->json($response);
                        }
                        $response 	=	$this->updatedFailedResponse;
                        $response['validation']     =   "";
                        return response()->json($response);
                    }
                    return response()->json($response,400);
                }
                return response()->json($response,400);
            }
            return response()->json($response,400);
        }
        catch(\Exception $e )
        {
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        }
    }
    
    public function dogetEmailcontentname(Request $request) 
    {
        try{
            $response   =   $this->notfoundResponse;
            $response['emailfilename']   =   "";
            $validation     =   Validator::make($request->all(), [
                                                    'emailstageid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $getId          =   $request->input('emailstageid');
            $data           =   emailSetupStagewiseModel::select(DB::Raw('ID,ROUND_ID,STAGE_ID,EMAIL_SUBJECT,TO_EMAIL,CC_EMAIL,BCC_EMAIL,SUBSTRING_INDEX(EMAIL_TEMP_PATH, "/",-1) as EMAIL_PATH,IS_ACTIVE'))->Active()->where('ID',$getId)->first();
            if(count($data)>=1)
            {
                $filepathloc    =   $data->EMAIL_PATH;
                $response   =   $this->successResponse;
                $response['emailfilename']   =   $filepathloc;
                return response()->json($response);
            }
            return response()->json($response,400);
        }catch( \Exception $e ){   
            return response()->json($response);
        }
    }
    
    public function doViewemailsetupcontent(Request $request) 
    {
        try{
            $response   =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'emailstageid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $getId              =   $request->input('emailstageid');
            $emailcontent       =   emailSetupStagewiseModel::where('ID',$getId)->first();
            if(count($emailcontent)>=1)
            {
                $filepathloc    =   $emailcontent->EMAIL_TEMP_PATH;
                if(file_exists(public_path().'/'.$filepathloc))
                {
                    $logfiles   =   file_get_contents(public_path().'/'.$filepathloc );
                    $response   =   $this->successResponse;
                    $response['errMsg']   =   nl2br($logfiles);
                    return response()->json($response);
                }
                $filename       =   substr(strrchr($filepathloc, "/"), 1);
                $response['errMsg']   =   $filename.' not found';
                return response()->json($response);
            }
            return response()->json($response);
        }catch( \Exception $e ){
            return response()->json($response);
        }
    }
    
    public function doDelete(Request $request) 
    {
        try{
            $response   =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'emailstageid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $getId              =   $request->input('emailstageid');
            $emailcontent       =   emailSetupStagewiseModel::where('ID',$getId)->first();
            if(count($emailcontent)>=1)
            {
                $response   =   $this->deletedResponse;
                $filepathloc    =   $emailcontent->EMAIL_TEMP_PATH;
                if(file_exists(public_path().'/'.$filepathloc))
                {
                    unlink(public_path().'/'.$filepathloc);
                    emailSetupStagewiseModel::where('ID',$getId)->delete();
                }else{
                    emailSetupStagewiseModel::where('ID',$getId)->delete();
                }
                return response()->json($response);
            }
            return response()->json($response);
        }catch( \Exception $e ){
            return response()->json($response);
        }
    }
    
}