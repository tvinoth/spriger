<?php
namespace App\Http\Controllers\reports;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use App\Models\taskLevelArtMetadataModel;
#use App\Http\Controllers\dynamicConstantController;
use App\Models\checkoutModel;
use App\Models\wipreportsModel;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Mail;
use DB;
use Log;

class wipreportsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
   
   
    public function wipReportData($data, $type){
        
        switch ($type) {
            case "job":
               $this->jobData($data);
               return true;
                break;
            case "art":
                $this->artData($data);
                return true;
                break;
            case "process":
                
                $checkoutObj        =   new checkoutModel();
                $stageDetails       =   array();
               
                $currentstageDetails =   $checkoutObj->getStageInfo($data->jbstgid);
                $stageId   =    '';
                if(!empty($currentstageDetails)){
                   $stageId    =   $currentstageDetails['0']->STAGE_ID;
                   $data->metadataid = $currentstageDetails['0']->METADATA_ID;
                   $data->roundid    = $currentstageDetails['0']->ROUND_ID;
				   $data->stageid    =  $stageId;
                }
             //   $repSuccess                 =      new dynamicConstantController();
                $processConst               =     \Config::get('constants.WIP_REPORT_STAGES');
               // $processConst               =     \Config::get('requiredconstants.REPORT_WIP_STAGE_PROCESS') ;
                $wipStage                   =      explode(',',$processConst);
              
                if(in_array($stageId,$wipStage) && $data->checkin == '0' && $data->roundid == '116' ){
					return true; // currently disabled
					$data->outputQuantity  	 = 	1;
					$getRecordForSeq        =   DB::select( 'select * from metadata_info where METADATA_ID = '.$data->metadataid );
					if(!empty($getRecordForSeq)){
						$qnty     = round( $getRecordForSeq['0']->SPICAST_TOTALPAGES);
						$data->outputQuantity  = $qnty;
					}
                  $this->StageProcess($data);
                }else{
                    return true;
                }
                break;
            default:
                Log::useDailyFiles(storage_path().'/Api/wipReportFailed.log');
                Log::info( $type );
                Log::info( json_encode( $data ) );
              
        }
        
    }
    
    public function jobData($jobData){
        if(empty($jobData))
            return false;
       
       $currentDate          =   date( 'Y-m-d H:i:s' );
       $data['JOB_ID']       =   $jobData['JOB_ID'];
       $data['ACTION']       =   $jobData['ACTION'];
       $data['CREATED_DATE'] =   $currentDate;
       
       $jobId                =   DB::table('report_wip_job')->insertGetId( $data );
       return true;
    }
    
    public function artData($jobData){
        
        $serArray             = array('ReLabel','Redraw');
        $complexity           =  array('1'=>'SIMPLE','2'=>'MEDIUM','3'=>'COMPLEX');
        $currentDate          =   date( 'Y-m-d H:i:s' );
        
        if(empty($jobData['METADATA_ID']))
            return false;
        
        $reportModel         =   new WipreportsModel();
        $wheredata           =   array('METADATA_ID'=>$jobData['METADATA_ID'],'IS_ACTIVE'=>1);
        $artmetaDetails      =   taskLevelArtMetadataModel::where($wheredata)->get();
        
        $figWork['RELABLE']       = 0;
        $figWork['REDRAW MEDIUM'] = 0;
        $figWork['REDRAW SIMPLE'] = 0;
        $figWork['REDRAW COMPLEX'] = 0;
      
         foreach($artmetaDetails as $key => $data){
           
             if($data->WORK_INVOLVED == 'ReLabel'){
                 $figWork['RELABLE'] = $figWork['RELABLE'] +1;
             }else if($data->WORK_INVOLVED == 'Redraw'){
                 $key2      =   strtoupper($data->WORK_INVOLVED).' '.$complexity[$data->COMPLEXITY];
                 $figWork[$key2] = $figWork[$key2] +1;
             }
         }
         
         if(!empty($figWork)) {
             foreach($figWork as $key3 => $worktype){
                 if($worktype != 0){
                    $info       =    $reportModel->getArtReportDetails($jobData['JOB_ID'] ,$jobData['METADATA_ID'],$jobData['ROUND_ID'],$key3);
                    
                    if(count($info)== 0){
                        $insertData['JOB_ID']                   =   $jobData['JOB_ID'];
                        $insertData['METADATA_ID']              =   $jobData['METADATA_ID'];
                        $insertData['ROUND']                    =   $jobData['ROUND_ID'];
                        $insertData['SERVICE_TYPE_NAME']        =   $key3;
                        $insertData['SERVICE_TYPE_QTY']         =   $worktype;
                        $insertData['CREATED_DATE']             =   $currentDate;
                        $insertData['IS_ACTIVE']                =   '1';
                        
                        
                        DB::table('report_wip_art')->insertGetId( $insertData );
                    }else{
                       $existingId      =   $info['0']->ID;
                       $updateData['SERVICE_TYPE_QTY']  = $worktype;
                       
                       $updateQry  =   DB::table( 'report_wip_art' )
                                            ->where('JOB_ID', $jobData['JOB_ID'] )
                                            ->where('METADATA_ID', $jobData['METADATA_ID'] )
                                            ->where('ROUND', $jobData['ROUND_ID'] )
                                            ->where('SYNC_STATUS', '0' )
                                            ->where('SERVICE_TYPE_NAME', $key3 )
                                            ->update( $updateData );
                    }
                 }
              
             }
         }
       
        return true;
    }
    
    public function StageProcess($jobData){
        
        $currentDate                            =   date( 'Y-m-d H:i:s' );
        $reportModel                            =   new WipreportsModel();
        $info                                   =   array();
        
        $info                                   =    $reportModel->getProcessDetails($jobData->jobId ,$jobData->metadataid,$jobData->roundid,$jobData->stageid);
       
        if(count($info) == '0'){
            $insertData['JOB_ID']                   =   $jobData->jobId;
            $insertData['METADATA_ID']              =   $jobData->metadataid;
            $insertData['ROUND_ID']                 =   $jobData->roundid;
            $insertData['STAGE_ID']                 =   $jobData->stageid;
            $insertData['JOB_STAGE_ID']             =   $jobData->jbstgid;
            $insertData['OUTPUT_QUANTITY']          =   $jobData->outputQuantity;
            $insertData['CREATED_DATE']             =   $currentDate;
           
            DB::table('report_wip_stageprocess')->insertGetId( $insertData );
        }
        
       return true;
        
    }
    //FSV_RCVD_DATE     - job received date
	//TRANSACTION_DATE  - last update date
    public function cronjob(){
		
	   
       $jobresponse      =   $this->jobSync();
       $artresponse      =   $this->artSync();
       $processresponse  =   $this->procesSync();
    }
    
    public function jobSync(){
        
        $reportModel                            =   new WipreportsModel();
        $info                                   =    $reportModel->getJobinfo();
        
        $currentDate                            =   date( 'Y-m-d H:i:s' );
        
        $repData                =   array();
        $insertData             =   array();
        $updateData             =   array();
        $infoData['insertData'] =   array();
        $infoData['updateData'] =   array();
        $infoData['SynData']    =   array();
        
        if(count($info)>=1){
          
            foreach($info as $key => $data){
                $repData[] =   $data->RID;

                $trim           =   $data->FORMAT_TRIM_SIZE;
				$trimValue 		=	'';
                if(!empty($trim)){
                    $trim           =   explode('/',$trim);
                    $trimValue      =   $trim['0'];
                    
                    if(!empty($trimValue)){
                       $data1    =    explode(':',$trimValue);
                       $data2    =    explode('-',$trimValue);
                       
                       if(count($data1) == 2){
                           $trimValue  = preg_replace('/\\s/','',$data1['1']);
                       }
                       
                       if(count($data2) == 2){
                           $trimValue  = preg_replace('/\\s/','',$data2['1']);
                       }
                    }
                }
                $receivedDate   = date('Y-m-d',strtotime($data->CREATED_DATE));
                $pmName =  '';
                if(!empty($data->PM )){
                  $pmName =  $data->PM_FIRST_NAME.' '.$data->PM_LAST_NAME;
                }
				
				if(strtoupper($data->RUNNING_HEAD) == 'STANDARD'){
					$complex    = 'STANDARD';
				}else{
					$complex    = 'COMPLEX';
				}
				
				
                $insData['ACCOUNT_ID']      =   '1';
                $insData['BOOK_ID']         =   $data->BOOK_ID;
                $insData['JOB_ID']          =   $data->JOB_CODE_ID;
                $insData['JOB_TITLE']       =   $data->JOB_TITLE;
                $insData['AM']              =   $data->AM_NAME;
                $insData['PM']              =   $pmName;
                $insData['TS_CATEGORY']     =   $data->PRODUCTION_CLASSIFICATION;
                $insData['CE_CATEGORY']     =   $data->COPY_EDITING_LEVEL;
                $insData['LOCATION']        =   $data->PE_LOCATION;
                $insData['TRIM_SIZE']       =   $trimValue;
                $insData['COMPLEXITY']      =   $complex;
                $insData['MS_PAGE']         =   $data->NO_PAGES;
                $insData['ESTD_TS_PAGE']    =   $data->NO_ARABIC_PAGES + $data->NO_ROMAN_PAGES;// castoff page
               // $insData['ACT_TS_PAGE']     =   $data->NO_PAGES; // 300 typesetting page
                $insData['DATA_SOURCE']     =   '2';
				$insData['FSV_RCVD_DATE']   =   $receivedDate;
				
				if($data->LAST_MOD_DATE == '0000-00-00 00:00:00' || $data->LAST_MOD_DATE == ''){
					$insData['TRANSACTION_DATE']    =  $receivedDate;
				}else{
					$insData['TRANSACTION_DATE']    =  date('Y-m-d',strtotime($data->LAST_MOD_DATE));
				}


                if($data->ACTION == '1'){
                   $insertData[$data->JOB_ID]  =   $insData;
                   $insData['CREATED_DATE']    =   $currentDate;
                   $insertedId                 =    DB::connection('mysql2')->table('wip_job')->insertGetId( $insData );
				    if(empty($insertedId)){
					   
					    Log::useDailyFiles(storage_path().'/Api/wipReportFaileddata.log');
						Log::info( json_encode($insData) );
				   }

                }

                if($data->ACTION == '2'){
                    if(!array_key_exists($data->BOOK_ID,$insertData)){

                       if(!array_key_exists($data->BOOK_ID,$updateData)){
                           $insData['LAST_MOD_DATE']   =   $currentDate;
                           $update =  DB::connection('mysql2')->table('wip_job')->where('JOB_ID',$data->JOB_CODE_ID)->where('DATA_SOURCE',2)->where('BOOK_ID',$data->BOOK_ID)->update( $insData );
                       }

                        $updateData[$data->JOB_ID]  =   $insData;
                    }
                }
            }

            $infoData['insertData']     =   array_keys($insertData);
            $infoData['updateData']     =   array_keys($updateData);
            $infoData['SynData']        =   $repData;

            if(!empty($repData)) {
                $syncUpdate['UPDATED_DATE']    =      $currentDate;
                $syncUpdate['SYNC_STATUS']     =      1;
                $syncUpdate['IS_ACTIVE']       =      0;
                DB::table('report_wip_job')->whereIn('ID',$repData)->update( $syncUpdate ); 
            }
        }
       
      return $infoData;
    }
    
    
    public function artSync(){
       $reportModel                            =   new WipreportsModel();
       $info                                   =   $reportModel->getArtinfo();
       $currentDate                            =   date( 'Y-m-d H:i:s' );
       $loadDate                               =    date( 'Y-m-d' );
	  $newdate 							   	  =    strtotime ( '-1 day' , strtotime ( $loadDate ) ) ;
	  $loadDate 							  =    date ( 'Y-m-j' , $newdate );
       $repData                                 =   array();
       if(count($info)>=1){
           $insertData          =   array();
          
           foreach($info as $key => $data){
                $repData[]                      =   $data->RID;
               // $insData['ACCOUNT_ID']          =   1;
                $insData['JOB_ID']              =   $data->JOB_CODE_ID;
                $insData['BOOK_ID']             =   $data->BOOK_ID;
                $insData['LOAD_DATE']           =   $loadDate;
				$insData['TRANSACTION_DATE']    =   $loadDate;
                $insData['ROUND_ID']            =   $data->ROUND_ID;
                $insData['ROUND_NAME']          =   $data->NAME;
                $insData['STAGE_NAME']          =   'Copyediting';
                $insData['WORKFLOW_NAME']       =   'WF1';
                $insData['SERVICE_TYPE_NAME']   =   $data->SERVICE_TYPE_NAME;
                $insData['SERVICE_TYPE_QTY']    =   $data->SERVICE_TYPE_QTY;
                $insData['DATA_SOURCE']         =   '2';
                $insData['CREATED_DATE']        =   $currentDate;
                $insData['LAST_MOD_DATE']       =   $currentDate;
                
                if($data->ACTION == '1'){
                   $insertData[$data->JOB_ID]  =   $insData;
                   $insertedId                 =    DB::connection('mysql2')->table('wip_service_qty')->insertGetId( $insData );
                }
           }
           
            if(!empty($repData)) {
                $syncUpdate['UPDATED_DATE']    =      $currentDate;
                $syncUpdate['SYNC_STATUS']     =      1;
                $syncUpdate['IS_ACTIVE']       =      0;
                DB::table('report_wip_art')->whereIn('ID',$repData)->update( $syncUpdate ); 
            }
           
       }
       return $repData;
        
    }
    
     public function procesSyncOld(){
        
       $reportModel                            =   new WipreportsModel();
       $info                                   =   $reportModel->getProcessinfo();
      
       $currentDate                            =   date( 'Y-m-d H:i:s' );
      
	  $loadDate                               =    date( 'Y-m-d' );
	  $newdate 							   	  =    strtotime ( '-1 day' , strtotime ( $loadDate ) ) ;
	  $loadDate 							  =    date ( 'Y-m-j' , $newdate );
	
       $repData                                 =   array();
       if(count($info)>=1){
           $insertData          =   array();
          
           foreach($info as $key => $data){
                $record                         =   explode(',',$data->ID);
                
                $repData =   array_merge($repData,$record);
                //$repData[]                      =   $data->RID;
              //  $insData['ACCOUNT_ID']          =   1;
                $insData['JOB_ID']              =   $data->JOB_CODE_ID;
                $insData['BOOK_ID']             =   $data->BOOK_ID;
                $insData['LOAD_DATE']           =   $loadDate;
                $insData['ROUND_ID']            =   $data->ROUND_ID;
                $insData['ROUND_NAME']          =   $data->NAME;
                $insData['STAGE_NAME']          =   'Copyediting';
                $insData['STAGE_COMPLETION_DATE']     =   date('Y-m-d',strtotime($data->STAGE_COMPLETED_DATE));
                $insData['STAGE_COMPLETED']     =   '1';
                $insData['WORKFLOW_NAME']       =   'WF1';
                $insData['QTY']                 =   $data->quantity;
                $insData['DATA_SOURCE']         =   '2';
                $insData['CREATED_DATE']        =   $currentDate;
                $insData['LAST_MOD_DATE']       =   $currentDate;
               
                if($data->ACTION == '1'){
                   $insertData[$data->JOB_ID]  =   $insData;
                   $insertedId                 =    DB::connection('mysql2')->table('wip_transaction_stage')->insertGetId( $insData );
                }
				
				
           }
           
            if(!empty($repData)) {
                $syncUpdate['UPDATED_DATE']    =      $currentDate;
                $syncUpdate['SYNC_STATUS']     =      1;
                $syncUpdate['IS_ACTIVE']       =      0;
               DB::table('report_wip_stageprocess')->whereIn('ID',$repData)->update( $syncUpdate ); 
            }
           
       }
       
       return $repData;
    }
	
	public function procesSync(){
        
       $reportModel                            =   new WipreportsModel();
       $info                                   =   $reportModel->getProcessinfo();
       $reportData   						   = array();
	   if(count($info)>=1){
              
		   foreach($info as $key=> $data){
                       $rid[]  = $data->RID;
                       if(array_key_exists($data->JOB_ID,$reportData)){
                        $reportData[$data->JOB_ID]['OUTPUT_QUANTITY']  = $reportData[$data->JOB_ID]['OUTPUT_QUANTITY'] + $data->OUTPUT_QUANTITY;
                       }else{
                           $reportData[$data->JOB_ID]['OUTPUT_QUANTITY']  = $data->OUTPUT_QUANTITY;
                           $reportData[$data->JOB_ID]['JOB_CODE_ID']  = $data->JOB_CODE_ID;
                           $reportData[$data->JOB_ID]['BOOK_ID']  = $data->BOOK_ID;
                           $reportData[$data->JOB_ID]['ROUND_ID']  = $data->ROUND_ID;
                           $reportData[$data->JOB_ID]['NAME']  = $data->NAME;
                           $reportData[$data->JOB_ID]['ROUND_ID']  = $data->ROUND_ID;
                           $reportData[$data->JOB_ID]['ACTION']  = $data->ACTION;
                           
                       }
		   } 
	   }
           
           if(!empty($reportData)){
               foreach($reportData as $key =>  $records){
                $datatotal		=	$reportModel->getStageCompletionDetails($key, '116');
				$reportData[$key]['completed'] = 0;
                    if(!empty($datatotal)){
                       if($datatotal[0]->tcnt <= $datatotal[0]->rcint){
                           $reportData[$key]['completed'] = 1;
                           $reportData[$key]['created_date'] = $datatotal[0]->created_date;

                       }else{
                            $reportData[$key]['completed'] = 0;
                       }
                    }
                }
           }
      
       $currentDate                            =   date( 'Y-m-d H:i:s' );
       $loadDate                               =    date( 'Y-m-d' );
	   
	   
	   $newdate 							   =    strtotime ( '-1 day' , strtotime ( $loadDate ) ) ;
	  $transDate 							  =    	date ( 'Y-m-d' , $newdate );
	   
	   
       $repData                                =   array();
      
       if(count($reportData)>=1){
           $insertData          =   array();
           $repData             =     $rid;   
           foreach($reportData as $key => $data){
              
              // $repData[]                      =   $data['RID'];
               // $insData['ACCOUNT_ID']          =   1;
                $insData['JOB_ID']              =   $data['JOB_CODE_ID'];
                $insData['BOOK_ID']             =   $data['BOOK_ID'];
                $insData['LOAD_DATE']           =   $loadDate;
                $insData['ROUND_ID']            =   $data['ROUND_ID'];
                $insData['ROUND_NAME']          =   $data['NAME'];
                $insData['STAGE_NAME']          =   'Copyediting';
				$insData['TRANSACTION_DATE']     =   $transDate;
                
                if($data['completed'] == 1){
                    $insData['STAGE_COMPLETION_DATE']     =   date('Y-m-d',strtotime($data['created_date']));
                    $insData['STAGE_COMPLETED']           =   '1';
                }
                $insData['WORKFLOW_NAME']       =   'WF1';
                $insData['QTY']                 =   $data['OUTPUT_QUANTITY'];
                $insData['DATA_SOURCE']         =   '2';
                $insData['CREATED_DATE']        =   $currentDate;
                $insData['LAST_MOD_DATE']       =   $currentDate;
             
                if($data['ACTION'] == '1'){
                   $insertData[$key]  =   $insData;
                   $insertedId                 =    DB::connection('mysql2')->table('wip_transaction_stage')->insertGetId( $insData );
                }
           }
          
            if(!empty($repData)) {
                $syncUpdate['UPDATED_DATE']    =      $currentDate;
                $syncUpdate['SYNC_STATUS']     =      1;
                $syncUpdate['IS_ACTIVE']       =      0;
                DB::table('report_wip_stageprocess')->whereIn('ID',$repData)->update( $syncUpdate ); 
            }
           
       }
       return $repData;
    }
	
	
	
	public function procesSyncManual(){
        
     $reportModel                            =   new WipreportsModel();
        $info                                   =    $reportModel->getJobinfo();
        
        $currentDate                            =   date( 'Y-m-d H:i:s' );
        
        $repData                =   array();
        $insertData             =   array();
        $updateData             =   array();
        $infoData['insertData'] =   array();
        $infoData['updateData'] =   array();
        $infoData['SynData']    =   array();
        
        if(count($info)>=1){
          
            foreach($info as $key => $data){
                $repData[] =   $data->RID;

                $trim           =   $data->FORMAT_TRIM_SIZE;
				$trimValue 		=	'';
                if(!empty($trim)){
                    $trim           =   explode('/',$trim);
                    $trimValue      =   $trim['0'];
                    
                    if(!empty($trimValue)){
                       $data1    =    explode(':',$trimValue);
                       $data2    =    explode('-',$trimValue);
                       
                       if(count($data1) == 2){
                           $trimValue  = preg_replace('/\\s/','',$data1['1']);
                       }
                       
                       if(count($data2) == 2){
                           $trimValue  = preg_replace('/\\s/','',$data2['1']);
                       }
                    }
                }
                $receivedDate   = date('Y-m-d',strtotime($data->CREATED_DATE));
                $pmName =  '';
                if(!empty($data->PM )){
                  $pmName =  $data->PM_FIRST_NAME.' '.$data->PM_LAST_NAME;
                }
                $insData['ACCOUNT_ID']      =   '1';
                $insData['BOOK_ID']         =   $data->BOOK_ID;
                $insData['JOB_ID']          =   $data->JOB_CODE_ID;
                $insData['JOB_TITLE']       =   $data->JOB_TITLE;
				$insData['FSV_RCVD_DATE']   =   $receivedDate;
				$insData['TRANSACTION_DATE']    =  date('Y-m-d',strtotime($data->LAST_MOD_DATE));
                $insData['AM']              =   $data->AM_NAME;
                $insData['PM']              =   $pmName;
                $insData['TS_CATEGORY']     =   $data->PRODUCTION_CLASSIFICATION;
                $insData['CE_CATEGORY']     =   $data->COPY_EDITING_LEVEL;
                $insData['LOCATION']        =   $data->PE_LOCATION;
                $insData['TRIM_SIZE']       =   $trimValue;
                $insData['COMPLEXITY']      =   'NORMAL';
                $insData['MS_PAGE']         =   $data->NO_PAGES;
                $insData['ESTD_TS_PAGE']    =   $data->NO_ARABIC_PAGES + $data->NO_ROMAN_PAGES;// castoff page
               // $insData['ACT_TS_PAGE']     =   $data->NO_PAGES; // 300 typesetting page
                $insData['DATA_SOURCE']     =   '2';
				

                if($data->ACTION == '1'){
                   $insertData[$data->JOB_ID]  =   $insData;
                   $insData['CREATED_DATE']    =   $currentDate;
                 //  $insertedId                 =    DB::connection('mysql2')->table('wip_job')->insertGetId( $insData );

                }

                if($data->ACTION == '2'){
                    if(!array_key_exists($data->BOOK_ID,$insertData)){

                       if(!array_key_exists($data->BOOK_ID,$updateData)){
                           $insData['LAST_MOD_DATE']   =   $currentDate;
                          // DB::connection('mysql2')->table('wip_job')->where('JOB_ID',$data->JOB_CODE_ID)->update( $insData );
                       }

                        $updateData[$data->JOB_ID]  =   $insData;
                    }
                }
            }

            $infoData['insertData']     =   array_keys($insertData);
            $infoData['updateData']     =   array_keys($updateData);
            $infoData['SynData']        =   $repData;

            if(!empty($repData)) {
                $syncUpdate['UPDATED_DATE']    =      $currentDate;
                $syncUpdate['SYNC_STATUS']     =      1;
                $syncUpdate['IS_ACTIVE']       =      0;
              //  DB::table('report_wip_job')->whereIn('ID',$repData)->update( $syncUpdate ); 
            }
        }
       
      return $infoData;
    }
	
	 public function movetowomatbystage(){
        
        $bookid 			=	'6477';
        $roundId 			=	'114';
         $cmn_obj                       =       new CommonMethodsController();
        if($roundId == '104'){
            
            $data['jobId']           =   $bookid;
            $data['tapstype']        =   2;
            $data['roundid']         =   $roundId;
            $curl                    =       Config('app.url').'/api/dosfiftymovenonTaps';
            //$api_response            =       $cmn_obj->RestfulPostcUrlExecution( json_encode( $data ) , $curl, 0 );
           
        }
        $exitdata[] = 'FM1';
		$exitdata[] = 'CHAPTER_1';
		$exitdata[] = 'CHAPTER_2';
		$exitdata[] = 'CHAPTER_3';
		$exitdata[] = 'CHAPTER_4';
	
		
        if($roundId == '114'){
            $getallchapters     =   taskLevelMetadataModel::getMetadatadetailsJob($bookid);
    
            foreach($getallchapters as $key => $metaData){
                
                $data                    =   array();
                
                $data['jobId']           =   $bookid;
                $data['metadataId']      =   $metaData->taskmetaid;
                $data['tapsstype']       =   '2';
                $data['ChapterNo']       =   $metaData->CHAPTER_NO;
                $data['ChapterTitle']    =   $metaData->CHAPTER_NAME;
                $data['roundid']         =   $roundId;
                $curl                    =   Config('app.url').'api/domovenonTapsManual';
				$api_response			=	'';
				if(!in_array($metaData->CHAPTER_NO, $exitdata)){
                $api_response            =   $cmn_obj->RestfulPostcUrlExecutionmanual(  $data   , $curl, 1 );
				Log::useDailyFiles(storage_path().'/Api/movetowomatmaual.log');
                Log::info( json_encode( $api_response ) );
				}
				
            
            }
            
        }
        
    }
    
    
}