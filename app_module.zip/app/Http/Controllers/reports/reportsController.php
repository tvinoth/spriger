<?php
namespace App\Http\Controllers\reports;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Session;
use Storage;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Mail;
use DB; 
class reportsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {  
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function arrivals(Request $request,$reporttype)
    {
        $data= array();
        
        if($reporttype 	==	1)
        {	
            $this->displayMenuName(Config::get('menuconstants.MENU.REPORT_ARRIVAL'),$data);
            return view('reports.arrivals')->with($data);
        }
        else if($reporttype 	==	2)
        {
            $this->displayMenuName(Config::get('menuconstants.MENU.REPORT_TRACK'),$data);
            return view('reports.trackTitle')->with($data);
        }
        else if($reporttype 	==	3)
        {
            $this->displayMenuName(Config::get('menuconstants.MENU.REPORT_PRODUCTIVITY'),$data);
            return view('reports.productivity')->with($data);
        }
    }
}