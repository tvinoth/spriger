<?php
namespace App\Http\Controllers\checkout;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\checkoutModel;
use App\Models\artcaterylogModel;
use App\Models\jobResource;
use App\Models\jobRound;
use App\Models\jobStage;
use App\Models\jobModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobInfoModel;
use App\Models\stageManager;
use App\Models\stageModel;
use App\Models\alfrescoCredentialModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\instructionLevelModel;
use App\Models\instructionModel;
use App\Models\instructionAcceptStatementModel;
use Illuminate\Http\Request;
use App\Models\jobWorkLogModel;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\autostageController;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\workflow\workflowRuleController;
use App\Http\Controllers\dynamicConstantController;
use App\Http\Controllers\Api\autoPageController;
use App\Models\apiAutoPage;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class stageMangerController extends Controller
{   
	public $formSubmitedData;
    public function __construct() {
        parent::__construct();
	 $this->ownConstruction();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function ownConstruction(){
        $dynmicConstObj  =   new dynamicConstantController();
    }
    
    public function stageSubmit( Request $request ){
        
        $commonObj      =       new CommonMethodsController();
        $data           =       json_decode($request->getContent());
       
        $this->formSubmitedData           =     $data;
       
        $stageProcess['filemovement']   = 'failed';
        $stageProcess['manageStage']    = 'failed';
        $checkIn                        =  '0';
       
        if(isset($data->checkin) && $data->checkin == '1'){
            $checkIn            =   '1';
        }
        
        //check checklist instruction
        if(isset($data->instID) && !empty($data->instID))
        {
            $stageProcess   =   $this->doSubmitChecklistValidate($data);
            if($stageProcess['result']  ==  400)
            {
                return response()->json($stageProcess);
            }
        }

       
        if(!empty($data->jbstgid)){
          
            $fileMoveStatus          =      stageMangerController::fileMovementProcess( $data->jbstgid , $checkIn );
           
//            $deleteRes               =   $commonObj->deletefilesInproduction($deleteWrokPath);
            $stageProcess['deletefiledrive'] = @$fileMoveStatus['pathDetails']['detail']['opendrive'];
                if($fileMoveStatus['status'] == 'success' || $fileMoveStatus['status'] =='nofileMovement' ){
                    
                    $stageProcess['filemovement'] = 'success';
                    
                    //file version movement
                    //if( $fileMoveStatus['status'] == 'success' )
                        //$fileversionresponse 	=   $this->fileVersionMovementProcess($fileMoveStatus,$data,$commonObj);
                    
                     
						$stageManage                =   $this->mangeStageProcess($data);
						
						 $stage_obj              =       new jobStage();
						 $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $data->jbstgid );
                    
						 $rounds600   			  = 	 \Config::get('constants.ROUND_NAME.S600');
						 $rounds650   			  = 	 \Config::get('constants.ROUND_NAME.S650');
						 
						 if(!isset($data->roundid)){
						   $checkout_m             =       new checkoutModel();
						   $checkout_Data  		   =       $checkout_m->getStageInfo( $data->jbstgid );
						   $data->roundid		   =       $checkout_Data ['0']->ROUND_ID;
						   $data->stageid		   =       $checkout_Data ['0']->STAGE_ID;
						 }
                        
                        
						if($data->roundid == $rounds600 || $data->roundid == $rounds650){
                            
                           // Log::useDailyFiles( storage_path().'/Api/packagecall.log' );
                            //Log::info(json_encode($data));
                            $sendemailalert         =   app('App\Http\Controllers\checkout\stageManagerCustomController')->validationProcessCheck($data);
                        }
                    
                    $repSuccess             =       app('App\Http\Controllers\reports\wipreportsController')->wipReportData($data,'process');
                    if($stageManage == true){
                        
                        $stageProcess['manageStage'] = 'success';
                     
                        //send email setup
                        $sendemailalert         =   app('App\Http\Controllers\Api\stagealertemailController')->doSendemailalertstage($data->jobId,$data->roundid,$data->stageid,$data->metadataid);
                        //$repSuccess             =       app('App\Http\Controllers\reports\wipreportsController')->wipReportData($data,'process');
                        //update round stage details and update user stage
                        $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($data->jobId,'','update',$data->jbstgid);
                        
                    }
             
           }else{
               $stageProcess['filemovement'] =	$fileMoveStatus['status'];
           }
           
        }
        
        return response()->json($stageProcess);
        
    }
    
    public function doSubmitChecklistValidate($request) 
    {
        $wheredata          =   [];
        $roundID            =   $request->roundid;
        $stageID            =   $request->stageid;
        $jobID              =   $request->jobId;
        $readtype           =   $request->typeoflevel;
        $instructionID      =   $request->instID;
        $correctiontype     =   $request->correctiontype;
        $level_enum_id      =   $request->levelid;
        $typeofInstruction  =   $request->submitype;
//        $mandatorytype      =   $request->mandatorytype;
        $metadataID             =   "";
        if ($readtype           ==  "2")
        {
            if(empty($request->metadataid))
            {
                $response         =   $this->failedResponse;
                $response['errMsg']       =   'Metadata ID field is required';   
                $response['filemovement'] =   'instructionchecklist';   
                return $response;
            }
            $metadataID         =   $wheredata['METADATA_ID']   =   $request->metadataid;
        }
        
        $userid                 =   Session::get('users')['user_id'];
        //read mandatory record
        if($typeofInstruction   ==  "checkout")
        {
            $mandatorydata          =   [];
            $checkmandatoyinstruction   =   instructionModel::getMandatoryInsructionroundstage($roundID,$stageID,$level_enum_id);
            if(count($instructionID)>=1)
            {
                if(in_array('',$instructionID)) {
                    $response       =   $this->validationResponse;
                    $response['filemovement']   =   'instructionchecklist';
                    return $response;
                }
                foreach($instructionID as $key=>$insID){
                    $checkdata          =   ['ID'=>$insID,'MANDATORY_TYPE'=>true];
                    $countinstruction   =   instructionLevelModel::Active()->where($checkdata)->first();
                    if(count($countinstruction)>=1)
                    {
                        $mandatorydata[]    =   $countinstruction;
                    }
                }
            }
            

            if(count($checkmandatoyinstruction) !=  count($mandatorydata))
            {
                $response       =   $this->validationResponse;
                $response['filemovement']   =   'instructionchecklist';
                return $response;
            }
        }
        //check exist record 
        $wheredata['JOB_ID']    =   $jobID;
        $wheredata['ROUND_ID']  =   $roundID;
        $wheredata['STAGE_ID']  =   $stageID;
        $wheredata['INSTRUCTION_TYPE_ENUM_ID']   =   $level_enum_id;
        $checkexistinstruction  =   instructionAcceptStatementModel::Active()->where($wheredata)->get();
        if(count($checkexistinstruction)>=1)
        {   
            $updatedata         =   ['IS_ACTIVE'=>'0'];
            $where              =   ['JOB_ID'=>$jobID,'ROUND_ID'=>$roundID,'STAGE_ID'=>$stageID,'METADATA_ID'=>$metadataID,'INSTRUCTION_TYPE_ENUM_ID'=>$level_enum_id];
            instructionAcceptStatementModel::where($where)->update($updatedata);
        }
        //insert data
        $insertinst             =   "";
        if($typeofInstruction   ==  "checkin"){
            $insertinst     =   1;
        }
        
        if(count($instructionID)>=1)
        {
            DB::beginTransaction();
            foreach($instructionID as $key=>$insID)
            {
                $datainsert                     =   [];
                $datainsert['JOB_ID']           =   $jobID;
                $datainsert['ROUND_ID']         =   $roundID;
                $datainsert['STAGE_ID']         =   $stageID;
                $datainsert['USER_ID']          =   $userid;
                $datainsert['INSTRUCTION_TYPE_ENUM_ID'] =   $level_enum_id;
                $datainsert['TYPE_OF_LEVEL']    =   ($readtype     ==  1?'1':'2');
                $datainsert['INSTRUCTION_LEVEL_ID']    =   $insID;
                $datainsert['IF_CORRECT']    =   (isset($correctiontype[$key])?$correctiontype[$key]:'');
//                $datainsert['MANDATORY_TYPE']   =   $mandatorytype[$key];
                if(!empty($metadataID)){
                    $datainsert['METADATA_ID']  =   $metadataID;
                }
                $datainsert['CREATED_BY']       =   $userid;
                $insertinst                     =   instructionAcceptStatementModel::insertGetId($datainsert);
            }
            DB::commit();
            if($insertinst)
            {
                $response     =   $this->insertedResponse;   
                return $response;
            }else{
                DB::rollback();
                $response   =   $this->failedResponse;
                $response['filemovement']   =   'instructionchecklist';
                return $response;
            }
        }
        $response     =   $this->insertedResponse;
        return $response;
    }
    
    public function fileMovementProcess($jobStageId,$checkInFlag){
        
        $workflowPath                     =   new workflowServerMapPathModel();
        $serverMapPath                    =   $workflowPath->getWorkflowServerMapPath($jobStageId);
       
        if($serverMapPath['status'] == '1'){
         $fileStatus                       =   stageMangerController::fileMoveMent($serverMapPath,$checkInFlag,$jobStageId);
         $fileStatus['pathDetails']        =    $serverMapPath;
        }else{
            $fileStatus['status'] = 'nofileMovement';
        }
        
        return $fileStatus;
      
    }
	
    public function fileVersionMovementProcess($fileMoveStatus,$data,$commonObj)
    {
        try
        {
            //get stage name 
            $stagename                      =   "";       
            $empid                          =   Session::get('users')['emp_id'];
            $user_name                      =   Session::get('users')['user_name'];
            $getjobstage                    =   jobStage::where('JOB_STAGE_ID',$data->jbstgid)->first();
            $getalfrescocren                =   alfrescoCredentialModel::first();
            $clientresponse                 =	['Status'=>'failed'];
            if(count($getjobstage)>=1)
            {
                    $stagename              =   stageModel::where('STAGE_ID',$getjobstage->STAGE_ID)->first();
                    $stagename              =   (count($stagename)>=1?$stagename->STAGE_NAME:'');
            }

            if(count($getalfrescocren)>=1)
            {
                $inp_rep_arr                =   array('{BID}' => $fileMoveStatus['pathDetails']['detail']['bookid'] , '{RID}' => $fileMoveStatus['pathDetails']['detail']['roundname'],
                                                                        '{STAGE_NAME}'=>$stagename,'{CID}' => $fileMoveStatus['pathDetails']['detail']['chaptername'] );
                $sourcepath                 =   $commonObj->arr_key_value_replace( $inp_rep_arr , $getalfrescocren->SOURCE_PATH );
                //split path
                $destsplitpath              =   ($data->checkin  ==  1?$fileMoveStatus['pathDetails']['detail']['temp']:$fileMoveStatus['pathDetails']['detail']['dest']);
                $pathsplit                  =   explode('/',$destsplitpath,2);
                $drivePath                  =   \Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                if(isset($pathsplit[0]) && isset($pathsplit[1]))
                {
                    $destinationpath        =   (isset($pathsplit[0])?$pathsplit[0].$drivePath.$pathsplit[1]:'');
                }else if($data->checkin  ==  1){
                    $destinationpath        =   $fileMoveStatus['pathDetails']['detail']['temp'];
                }else{
                    $destinationpath        =   $fileMoveStatus['pathDetails']['detail']['dest'];
                }

                $params                     =   array();
                $params['jobid']            =   $data->jobId;
                $params['empid']            =   $empid;
                $params['empname']          =   $user_name;
                $params['process']          =   $getalfrescocren->PROCESS_TYPE;
                $params['mode']             =   $getalfrescocren->PROCESS_MODE;
                $params['sourceurl']        =   $getalfrescocren->SOURCE_URL;
                $params['sourceusername']   =   $getalfrescocren->SOURCE_USERNAME;
                $params['sourcepassword']   =   $getalfrescocren->SOURCE_PASSWORD;
                $params['type']             =   $getalfrescocren->PROCESS_DOCUMENT_TYPE;
                $params['source_path']      =   $sourcepath;
                $params['dest_path']        =   $destinationpath;
                $params['file_username']    =   (isset($fileMoveStatus['pathDetails']['detail']['username'])?$fileMoveStatus['pathDetails']['detail']['username']:'');
                $params['file_password']    =   (isset($fileMoveStatus['pathDetails']['detail']['password'])?$fileMoveStatus['pathDetails']['detail']['password']:'');
                $params['stageName']        =   $fileMoveStatus['pathDetails']['detail']['roundname'].'-'.$stagename;
                $params                     =   json_encode($params);
                $client                     = 	new \soapclient($getalfrescocren->SERVICE_URL);
                $clientresponse             = 	$client->executeWebServ(array(0 => $params));
                if(is_soap_fault($clientresponse))
                {
                    return true;
                }
            }
            return $clientresponse;
        }catch(SoapFault $e){
            return true;
        }
    }
    
    public static function fileMoveMent($pathDetails,$checkInflag,$jobstageId){
		$fileMovementStatus 			=	[];
        $fileMovementStatus['status'] 	= 	"failed";
      
        if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
            
            $workDir            =   $pathDetails['detail']['work'];
          
            $destDir            =   $pathDetails['detail']['dest'];
           
            if($checkInflag == '1'){
                $destDir            = $pathDetails['detail']['temp'];
            }
            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
			$dofilecopyifworkdirfileexist 	=	true;	
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            //check workpath file is avaialbe or not 
			if(!empty($destDir)){
				$checkfileexitStatus	=   $fileHandlerObj->getDirectoryFiles($pathDetails['detail']['workdirlistpath']);
				if(empty($checkfileexitStatus) || count($checkfileexitStatus) == 0){
					$fileMovementStatus['status'] 	= 	"Working directory is should not to be empty or Invalid Path is given...";
					$dofilecopyifworkdirfileexist 	=	false;
				}
			}
            
			if($dofilecopyifworkdirfileexist){
            $destDirPath        =   str_ireplace($serverDetail['host'],'',$destDir);
            $directory          =   $fileHandlerObj->make_directory($destDirPath);
            $fileMoveStatus     =   $fileHandlerObj->ftp_dir_copy($crd.$workDir,$destDir);
            $commonMethod       =   new CommonMethodsController();
            $fileMovementStatus =   $commonMethod->getFileMovementStatus($fileMoveStatus);
            if($checkInflag !=   1 && $fileMovementStatus['status'] == "success"){
                //alfresco upload
                if($jobstageId != null && $pathDetails['detail']['ispartial'] == '0' && !empty($pathDetails['detail']['srcfileextension']) && $pathDetails['detail']['srcfileextension'] !='NA'){
                    $checkoutinit   =   new checkoutModel();
                    $jobstageinfo   =   $checkoutinit->getStageInfo($jobstageId);
                    $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobstageinfo[0]->JOB_ID,$jobstageinfo[0]->METADATA_ID,$jobstageinfo[0]->ROUND_ID,$jobstageinfo[0]->STAGE_ID,$pathDetails['detail']['dest'],'submit');
                }
            }
        }
        }
        
        return $fileMovementStatus;
    }
    
    public function mangeStageProcess($dataInfo){
        
        $manageStage        =   'false';
        $checkIn            =   false;
        $openNextStageStatus['status'] 	=	"";
        
        if(isset($dataInfo->checkin) && $dataInfo->checkin == '1'){
            $checkIn            =   true;
        }
       
        $jobStageId         =   $dataInfo->jbstgid;
        $inputQuanity       =   $dataInfo->inputQuantity;
        $outputQuanity      =   (isset($dataInfo->outputQuantity)?$dataInfo->outputQuantity:0);
        $inputRemarks       =   (!empty($dataInfo->inputRemarks)?$dataInfo->inputRemarks:'');
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   array();
        $currentstageDetails =   $checkoutObj->getStageInfo($jobStageId);
        $workLogStatus      =   $this->manageWorkLog($jobStageId,$inputQuanity,$outputQuanity,$inputRemarks,$currentstageDetails['0'],$checkIn);
        
        if($checkIn == false){
            $stageDetails           =   $checkoutObj->getStageInfo($jobStageId);                                   
            $this->preProductionSpiceCastGeneration($stageDetails['0']);
            $openNextStageStatus    =   $this->moveNextStage($stageDetails['0']);
            
        }else{
            $openNextStageStatus['status'] = 'success';
        }
        if($openNextStageStatus['status'] == 'success'){
            $manageStage        =   'true';
        }
       
       return $manageStage;
    }
    
    
     public function mangeWorkLogProcessOnly($dataInfo){
        
        $manageStage        =   'false';
        $checkIn            =   false;
        $openNextStageStatus['status'] 	=	"";
        
        if(isset($dataInfo->checkin) && $dataInfo->checkin == '1'){
            $checkIn            =   true;
        }
       
        $jobStageId         =   $dataInfo->jbstgid;
        $inputQuanity       =   $dataInfo->inputQuantity;
        $outputQuanity      =   (isset($dataInfo->outputQuantity)?$dataInfo->outputQuantity:0);
        $inputRemarks       =   (!empty($dataInfo->inputRemarks)?$dataInfo->inputRemarks:'');
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   array();
        $currentstageDetails =   $checkoutObj->getStageInfo($jobStageId);
        $workLogStatus      =   $this->manageWorkLog($jobStageId,$inputQuanity,$outputQuanity,$inputRemarks,$currentstageDetails['0'],$checkIn);
        
        if($checkIn == false){
           $manageStage        =   'true';
        }else{
            $openNextStageStatus['status'] = 'success';
        }
        if($openNextStageStatus['status'] == 'success'){
            $manageStage        =   'true';
        }
       
       return $manageStage;
    }
    
    public function preProductionSpiceCastGeneration($stageDetails){
            
       $copyEditingStage    =    Config::get('constants.STAGE_COLLEECTION.COPY_EDITING');
        
        if($stageDetails->STAGE_ID == $copyEditingStage ){
            
             $updatespicastdata      =   array('SPICAST_STATUS'=>'1');
                    $jobId = $stageDetails->JOB_ID;
                    $getartchapters         =   taskLevelMetadataModel::where('JOB_ID',$jobId)->where('UNIT_OF_MEASURE','!=','556')->get();     
                    $completeartchapter     =   taskLevelMetadataModel::getArtcompletedChpter($jobId);
                    $completecopyediting    =   taskLevelMetadataModel::getCopyeditingcompletedChpterNew($jobId);
                 
                    //spicast send background process
                    if(count($getartchapters)   ==  count($completecopyediting) && count($getartchapters)   ==  count($completeartchapter))
                    {
                        $updatespicastdata      =   array('SPICAST_STATUS'=>'1');
                        $updatejobinfo          =   jobInfoModel::where('JOB_ID',$jobId)->update($updatespicastdata);
                        $spicastbackresponse    =   app('App\Http\Controllers\spicast\spicastController')->spicastBackgroundProcess($jobId);
                        
                        $spicastStageID    =   taskLevelMetadataModel::getspicastStageID($jobId);
                        
                         if(count($spicastStageID)>=1){
                            $spicastStId       =   $spicastStageID['0']->JOB_STAGE_ID;
                            $roundId           =    $spicastStageID['0']->JOB_ROUND_ID;
                            $time                       = 	date('Y-m-d H:i:s'); 
                            $setArr        =   array( 'CHECK_OUT'  => $time , 'STATUS' => '23');
                            $updateQry     =   DB::table('job_stage')
                                                ->where('JOB_STAGE_ID', $spicastStId )
                                                ->update( $setArr );
                        }
                    }
                    
                    return true;
        }
    }
   
    public function manageWorkLog($jobStageId,$inputQuantity,$outputQuanity,$inputRemarks,$stageDetails,$checkInFlag=''){
        
        $time                       = 	date('Y-m-d H:i:s'); 
        $worklogData                =   jobWorkLogModel::where('JOB_STAGE_ID',$jobStageId)->orderBy('JOB_WORK_LOG_ID','desc')->first();
        
        if(count($worklogData)>=1){
            $pendingQuantity  = '0';
            
            if($checkInFlag == '1'){
                $pendingQuantity = $inputQuantity - $outputQuanity;
            }
           
             $setArr        =   array( 'CHECK_IN'  => $time ,  'OUTPUT_QUANTITY' => $outputQuanity ,'PENDING_QUANTITY'=>$pendingQuantity ,'REMARKS' => $inputRemarks);
             $updateQry     =   DB::table('job_work_log')
                                ->where('JOB_WORK_LOG_ID', $worklogData->JOB_WORK_LOG_ID )
                                ->update( $setArr );
             
        }
        
        $sql_sq_d                = "select sum(jw.OUTPUT_QUANTITY) as sumval from job_work_log jw where jw.JOB_STAGE_ID = '".$jobStageId."'";
        $totalQuantity           = DB::select($sql_sq_d);
        
        $stageOutputQuantity     = (!empty($totalQuantity['0']->sumval)?$totalQuantity['0']->sumval:'0');
        
        $status         =  '24';
        $partial        =   '0';
        
        if($checkInFlag == '1' || $checkInFlag == true){
            $status      =  '27';
            $partial     =   '1';
            $updateStageParam       =   array( 'STATUS'=>$status, 'OUTPUT_QUANTITY' => $stageOutputQuantity ,'IS_PARTIAL'=>$partial, 'COMMENTS' => $inputRemarks);
          
        }else{
             $updateStageParam       =   array( 'STATUS'=>$status,'CHECK_IN'  => $time ,  'OUTPUT_QUANTITY' => $stageOutputQuantity ,'IS_PARTIAL'=>$partial,'COMMENTS' => $inputRemarks);
        }
       
         //$updateStageParam       =   array( 'STATUS'=>$status,'CHECK_IN'  => $time ,  'OUTPUT_QUANTITY' => $stageOutputQuantity ,'IS_PARTIAL'=>$partial,'COMMENTS' => $inputRemarks);
         $updateQry              =   DB::table('job_stage')
                                    ->where('JOB_STAGE_ID', $jobStageId )
                                    ->update( $updateStageParam );
         
         if($checkInFlag == '1' || $checkInFlag == true){
             
             $jobRoundValue          =      array('STATUS'=>'27','CURRENT_STAGE' => $stageDetails->STAGE_ID);
             $updateQry              =      DB::table('job_round')
                                                ->where('JOB_ROUND_ID', $stageDetails->JOB_ROUND_ID )
                                                ->update( $jobRoundValue );
             
         }
         
         $deleteresourceQry      =   DB::table('job_resource')->where('JOB_STAGE_ID', $jobStageId )->delete();
         
         /** delete jobresource data **/
         
         
         return true;
        }
        
    public function moveNextStage( $stageData , $isArt = 0 ){
        if(empty($isArt)){
			$isArt  = 0;
		}
			
        $moveStage              =       array();
        $moveStage['status']    =       'failed';        
        //$stageData              =      (object)$stageData->all();        
        if( empty($stageData) )
            return $moveStage;
       
        $stageskipby            =       1;
        $jobRoundId             =       $stageData->JOB_ROUND_ID;
        $roundId                =       $stageData->ROUND_ID;
        $stageSequence          =       $stageData->STAGE_SEQ + $stageskipby;
        $workflowId             =       $stageData->WORKFLOW_ID;  
        $iteration              =       $stageData->ITERATION_ID;
        $jobId                  =       $stageData->JOB_ID;
        $outputQuantity         =       $stageData->OUTPUT_QUANTITY;
        $cur_jobstg_id          =       $stageData->JOB_STAGE_ID;
        $stg_id                 =       $stageData->STAGE_ID;
        $getmetaid              =       $stageData->METADATA_ID;
        
        geneateNextStage:
        
        $checkoutObj            =   new checkoutModel();
        $nexstageDetails        =   $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);
       
        if( !empty( $nexstageDetails ) ){
            
            $wrrfruleObj        =       new workflowRuleController();               
            //Check wheather this nextstage available as per rule or overwrite the nextstage variable
            $getRuleStage       =       $wrrfruleObj->getWorkflowRuleBasedJobStageAvail( $cur_jobstg_id , 2 );
            $ruleFlag           =       false;    
           
            //autopagebg stage cofirmation [ 'only for autopage stage' ] - start
            $autopagebg         =   \Config::get('constants.STAGE_COLLEECTION.AUTO_PAGE_BG');            
            $desktoppagination  =   \Config::get('dynamicConstant.STAGE_COLLEECTION.DESKTOP_PAGINATION'); 
            $manualpagination   =   \Config::get('dynamicConstant.STAGE_COLLEECTION.MANUAL_PAGINATION'); 
			
            if( $stg_id ==  $autopagebg || $stg_id ==  $desktoppagination  || $manualpagination == $stg_id ){
                $ruleFlag           =       true;
                $getRuleStage       =       $this->avoidWorkflowRuleConditionOnlyForAutopage( $cur_jobstg_id );  
            }			
            //autopagebg stage cofirmation [ 'only for autopage stage' ] - End
            
            if( ($getRuleStage) || ( $ruleFlag ) ){ 
                //is skip update yet to do for job stage entry
                $newstageSequence           =       $wrrfruleObj->getStageSequence( $getRuleStage , $roundId  , $jobId , $workflowId );
                $nexstageDetails            =       $checkoutObj->getNextStageDetails( $jobRoundId, $newstageSequence, $iteration, $workflowId );  
                
            }
            
            $nextJobStageId     =       $nexstageDetails->JOB_STAGE_ID;
            $nextStageId        =       $nexstageDetails->STAGE_ID;
            
            $getRuleStage       =       $wrrfruleObj->checkIsSkipWorkflowRule( $nextJobStageId , 1 );
            if(count($getRuleStage)>=1 && isset($getRuleStage[0]) && $getRuleStage[0]->IS_SKIP  ==  1){
                $stageSequence  +=  1;
                goto geneateNextStage;
            }
			
            $userDefData    =   taskLevelUserdefinedWorkflow::getUserDefineStageDetails($jobId, $workflowId,$roundId,$nextStageId);
            $stageType      =   $userDefData->IS_AUTO;
            
            //automatic stage close method
            if( isset( $stageData->CURRENTSTATUS  ) ){
                
                if( $stageData->CURRENTSTATUS == 23 || $stageData->CURRENTSTATUS == 76 ){
                    
                    $updateStageParam       =       array( 'STATUS' => '24' , 'CHECK_IN' => date( 'Y-m-d H:i:s' ) );
                    $updateQry              =       DB::table('job_stage') 
                                                    ->where('JOB_STAGE_ID', ( $stageData->JOB_STAGE_ID ) )
                                                    ->update( $updateStageParam );
                    
                    $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobId,$roundId,'update',$stageData->JOB_STAGE_ID);
                    
                }
                
            }
            
            $parallelProcess    =   $this->manageWaitngForParallelProcessUpdate( $nextJobStageId , 'block' );
            
            if( $parallelProcess ){
                $moveStage['status']  = 'success';
                return $moveStage;
            }
            
            if($stageType == '0'){
                
                //** Manual stage **/
               
                $updateStageParam       =       array( 'STATUS'=>'27','INPUT_QUANTITY' => $outputQuantity);
                $updateQry              =       DB::table('job_stage')
                                                    ->where('JOB_STAGE_ID', $nextJobStageId )
                                                    ->update( $updateStageParam );
                 
                $jobRoundValue          =       array('STATUS'=>'27','CURRENT_STAGE' => $nextStageId);
                $updateQry              =       DB::table('job_round')
                                                    ->where('JOB_ROUND_ID', $jobRoundId )
                                                    ->update( $jobRoundValue );
                  
                if($isArt == 1){
                    
                    if(!empty($stageData->artMetadataId) || !empty($stageData->ART_METADATA_ID ) ){
                        
                        if( !empty( $stageData->artMetadataId ) ){
                            $artMetadataId           =       $stageData->artMetadataId;
                        }
                        
                        if( !empty( $stageData->ART_METADATA_ID ) ){
                           $artMetadataId   =    array( $stageData->ART_METADATA_ID );
                        }
                        
                        $jobRoundValue2          =       array('CURRENT_STAGE' => $nextStageId);
                        $updateQry               =       DB::table('task_level_art_metadata')
                                                            ->whereIn('ART_METADATA_ID', $artMetadataId )
                                                            ->update( $jobRoundValue2 );
                        
                        $jobRoundValue3          =       array('CURRENT_STAGE' => $nextStageId);
                        $updateQry               =       DB::table('metadata_status')
                                                            ->where('ID', $stageData->METADATA_STATUS_ID )
                                                            ->update( $jobRoundValue3 );
                       
                    }
                    
                }
                 
                 $moveStage['status']  = 'success';
               
            }else{ 
                
                
                //** auto stage **/
                $updateStageParam       =   array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $outputQuantity);
                $updateQry              =   DB::table('job_stage')
                                            ->where('JOB_STAGE_ID', $nextJobStageId )
                                            ->update( $updateStageParam );
                 
                $jobRoundValue1         =   array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
                $updateQry              =   DB::table('job_round')
                                            ->where('JOB_ROUND_ID', $jobRoundId )
                                            ->update( $jobRoundValue1 );
               
                if($isArt == 1){

                  if(!empty($stageData->artMetadataId)){

                      $artMetadataId            =       $stageData->artMetadataId;
                      $jobRoundValue2           =       array('CURRENT_STAGE' => $nextStageId);
                      $updateQry                =       DB::table('task_level_art_metadata')
                                                          ->whereIn('ART_METADATA_ID', $artMetadataId )
                                                          ->update( $jobRoundValue2 );

                      $jobRoundValue3           =       array('CURRENT_STAGE' => $nextStageId);
                      $updateQry                =       DB::table('metadata_status')
                                                          ->where('ID', $stageData->METADATA_STATUS_ID )
                                                          ->update( $jobRoundValue3 );

                  }
                  
                }
                           
                if($isArt == '0'){
                  
                    $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobId,$roundId,'insert',$nextJobStageId);
                    $autoStageList      =       \Config::get('constants.AUTO_STAGE');
                    $autoProcessObj     =       new autostageController();             
                    
                    $getConfigInfo      =       $autoProcessObj->getAutoStageBgExecutionConfiguration( $nextJobStageId );
                 
                    if( !empty( $getConfigInfo ) ){
                        $autoStageList  =       $getConfigInfo;
                    }    
                   
                    if( isset( $autoStageList[$nextStageId] ) ){
                        
                        try{
                            
                            $formData       =   $this->formSubmitedData;
                            
                            $ret_status     =   $this->handlingAutoStages( $nextStageId , $nextJobStageId , $formData );     
                            
                        }catch(\Exception $e){
                            
                            $err_handle             =       new errorController();             
                            $err_handle->handleApplicationErrors( $e );
                            
                            $moveStage['status']    =       '0';
                            $moveStage['msg']       =       'Failed';
                            $moveStage['errMsg']    =       $e->getMessage();
                            
                            return $moveStage;
                            
                        }
                        
			$medaInfo                   =       DB::table( 'metadata_info' )->select('PRODUCTION_SYSTEM')
											->where( 'METADATA_ID' , '=' ,  $getmetaid )
											->get()->first();
			$conventional   =   false;
			if( count( $medaInfo ) ){
                            if( isset( $medaInfo->PRODUCTION_SYSTEM ) ){
                                if( $medaInfo->PRODUCTION_SYSTEM == 2 || $medaInfo->PRODUCTION_SYSTEM == '2' ){
                                    $conventional	=	true;
                                }
                            }				
			}
                       
                        $roundids200    =   \Config::get('constants.ROUND_NAME.S200');
                        if( $roundId == $roundids200 && !empty($ret_status) && !$conventional ){
                             
                            if( is_array( $ret_status ) ){
                                $ret_status =   response()->json( $ret_status );
                            }
                            if( $ret_status ){
                                //only for taps packaging response handle
                                $ret_status		=	( json_decode( $ret_status->content() , true ) );
								
                                $this->forTapsErrorMsgResponse( $nextStageId , $cur_jobstg_id , $ret_status );
                            }

                        }
						
                       // return response()->json( $ret_status );
                        
                    }
                    
                  }
                  
                  $moveStage['status']  = 'success';
                 
            }
            
        }
        
       return $moveStage;
        
    }
    
    public function manageWaitngForParallelProcessUpdate( $jbstgid , $action = 'block' ){
        
        //Action for block  , avail , inprogress        
        $jbstg       =       new jobStage();       
        $statusW     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORPARALLEL' );         
        $statusI     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
        $statusA     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.AVAILABLE' );
        $manual_pag  =       \Config::get('constants.STAGE_COLLEECTION.MANUAL_PAGINATION');
        
        $returnval      =   false;
        
        $checkoutObj        =       new checkoutModel();
        $stageData          =       $checkoutObj->getStageInfo( $jbstgid );
        $stageData          =       $stageData['0'];
        
        $roundId                =   $stageData->ROUND_ID;
        $workflowId             =   $stageData->WORKFLOW_ID;  
        $iteration              =   $stageData->ITERATION_ID;
        $jobId                  =   $stageData->JOB_ID;
        $cur_jobstg_id          =   $stageData->JOB_STAGE_ID;
        $stg_id                 =   $stageData->STAGE_ID;
        $metaid                 =   $stageData->METADATA_ID;
        $round                  =   $stageData->ROUND_ID;
        
        $tlam_obj               =   new taskLevelArtMetadataModel();
        $isart_completed_rec    =   $tlam_obj->isAllartStagesCompletedWithMetastatusTable( $metaid , $round , true );
       
        if( count( $isart_completed_rec ) >  0 ) {    
            
            $artNotCompletedRec     =       $isart_completed_rec;
            $endstage               =       $artNotCompletedRec->END_STAGE_ID;
            
            //customizing for s300 waiting for parallel rule.
            if( 118 == $stageData->ROUND_ID ){
                $endstage = $manual_pag;
            }
            // temporary and condition
            if( $stg_id == $endstage && $stg_id !== 1302 && $stg_id !== '1302' ){
                $setArr     =       array( 'STATUS' =>  $statusW );        
                $returnval  =       $jbstg->updateIfExist( $setArr , $jbstgid );
            }
                
        }
        
        return $returnval;
        
    }
    
    public function avoidWorkflowRuleConditionOnlyForAutopage( $cur_jobstg_id ){
        
        //Just giving exception patch for indesign autopage stage. to proceed manual cap 
        //Maintaing one workflow for s300 correction workflow so that.
     
            $checkoutObj            =       new checkoutModel();
            $stageDetails           =       $checkoutObj->getStageInfo($cur_jobstg_id);
            
            if(count($stageDetails) == 0){
                return false;
            }
            
            $jbstg_rec      =       $stageDetails[0];
            $round          =       $jbstg_rec->ROUND_ID;
            $metaid         =       $jbstg_rec->METADATA_ID;
            $jobid          =       $jbstg_rec->JOB_ID;
            
            $metaDetails       =       DB::table('metadata_info')->where( 'METADATA_ID' , '=' , $metaid  )->get();
            $workflowid        =       0;
            
            if( count( $metaDetails )){
                $metaDetails    =   $metaDetails[0];
                
                
            }
            //only for autopage            
            $cusomcondition  =      array( 'METADATA_ID' => $metaid , 'ROUND' => $round , 'JOB_ID' => $jobid );
            $apiAtPgObj      =      new apiAutoPage();
            $apirecordAP     =      $apiAtPgObj::select( )->where( $cusomcondition )->orderBy( 'ID' , 'desc' )->get()->first();
            $gotostage       =   '';
            
            if( count( $apirecordAP ) ){
                
                $platform         =     $apirecordAP->PLATFORM;
                $mode             =     $apirecordAP->MODE;         
                $withprint        =     ( $apirecordAP->WITHPRINT == 1) ? true : false;
                        
                // platform 1 for 3b2 
                // platform 2 for indesign  
                
                $casecondi  = strtolower($platform).'_'.strtolower( $mode );  
                               
                if( '3b2' == strtolower($platform) &&  'fpp' == strtolower( $mode ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    $extn           =   '3d';
                }
                
                if( ( 'indesign' == strtolower($platform) ||  'adobe indesign' == strtolower($platform ) ) &&  'fpp' == strtolower( $mode ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    $extn           =   'indd';
                }
                
                
                if( '3b2' == strtolower($platform) &&  ( 'cap' == strtolower( $mode ) || 'autopagination' == strtolower( $mode ) ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    $extn           =   '3d';
                }
                
                if( (  'indesign' == strtolower($platform)  ||  'adobe indesign' == strtolower($platform)  ) &&  'cap' == strtolower( $mode ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    $extn           =   'indd';
                }
                
                if( (  'indesign' == strtolower($platform)  ||  'adobe indesign' == strtolower($platform)  ) &&  'localpagination' == strtolower( $mode ) ){
                    
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    if( $metaDetails->FM_ARTICLE_BM == 5 || $metaDetails->FM_ARTICLE_BM == '5'){
                        $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.COVER_DP' );
                    }
                    $extn           =   'indd';
                    if( $withprint ){
                        $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_CAP' );
                        $withprinttxt   =   'YES';
                        $mode   =   'CAP';
                    }else{
                        $withprinttxt   =   'NO';
                    }
                    
                }          
                
                if( (  '3b2' == strtolower($platform)  ||  '3b2' == strtolower($platform)  ) &&  'localpagination' == strtolower( $mode ) ){
                    
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
                    if( $metaDetails->FM_ARTICLE_BM == 5 || $metaDetails->FM_ARTICLE_BM == '5'){
                        $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.COVER_DP' );
                    }
                    $extn           =   '3d';
                    if( $withprint ){
                        $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_CAP' );
                        $withprinttxt   =   'YES';
                        $mode   =   'CAP';
                    }else{
                        $withprinttxt   =   'NO';
                    }
                    
                }                
                
                if( ( 'indesign' == strtolower($platform)  || 'adobe indesign' == strtolower($platform) ) &&  'autopage' == strtolower( $mode ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
                    $extn           =   'indd';
                }
                
                if( ( 'indesign' == strtolower($platform)  || 'adobe indesign' == strtolower($platform) ) &&  'autoserver' == strtolower( $mode ) ){                    
                    $extn           =   'indd';
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
                }
                
                if( ( 'indesign' == strtolower($platform)  || 'adobe indesign' == strtolower($platform) ) &&  'localautopage' == strtolower( $mode ) ){                    
                    $extn           =   'indd';
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
                }
                
                if( '3b2' == strtolower($platform) &&  ( 'autopage' == strtolower( $mode ) || 'localautopage' == strtolower( $mode ) ) ){
                    $gotostage      =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
                    $extn           =   '3d';
                }
                
                $made_inp                   =       array( 'platform' => $platform , 'mode' => $mode , 'location' => 'SERVER' , 'autopageext' => $extn );
                
                if( $withprint && isset( $withprinttxt ) &&  'localpagination' == strtolower( $mode )){
                    $made_inp['withprint' ] =  $withprinttxt; 
                }
                
                $this->formSubmitedData     =       (object)array(  'optionalParamJson' => json_encode( $made_inp ) );
                
                return  $gotostage;
                
            }
            
        return false;
        
    }
    
    public function forTapsErrorMsgResponse( $nextStageId , $jobstgid, $ret_status ){
        
        $endtime        =   date( 'Y-m-d H:i:s' );
		
        if( isset( $ret_status['status'] ) ) { 
			
            if( $nextStageId == \Config::get('dynamicConstant.STAGE_COLLEECTION.PACKAGING') && $ret_status['status'] == 1 ){
               
                $stg_obj            =       new stageModel();
                $stg_info           =       $stg_obj->getStageInfoByStageId( $nextStageId );
                $checkoutObj        =       new checkoutModel();
                $stageDetails       =       $checkoutObj->getStageInfo( $jobstgid );
                $stageDetails       =       $stageDetails[0];
		
                $cnd_ary    =       array(  
                                           'METADATA_ID'   =>      $stageDetails->METADATA_ID , 
                                           'ROUND'         =>      $stageDetails->ROUND_ID                                                
                                       );

                $inp_arr    =       array( 'END_TIME' => $endtime , 'TAPSCOMPLETION_STATUS' => 2 , 'REMARKS' =>  '"'.strtoupper( $ret_status['msg'] ).'"' );

                DB::table('api_taps')
                        ->where( 'METADATA_ID' , '=' , "$stageDetails->METADATA_ID"  )
                        ->where( 'ROUND' , '=' , "$stageDetails->ROUND_ID"  )
                        ->orderBy('ID','desc')
                        ->update( $inp_arr );

                echo  '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">'.strtoupper( $ret_status['msg'] ).'</string>';
                exit;
                
            }

            if( $ret_status['status'] == 0 || $ret_status['status'] == 1.5 ){

                $stg_obj            =       new stageModel();
                $stg_info           =       $stg_obj->getStageInfoByStageId( $nextStageId );
                $checkoutObj        =       new checkoutModel();
                $stageDetails       =       $checkoutObj->getStageInfo( $jobstgid );
                $stageDetails       =       $stageDetails[0];
                $dispStg            =       $stageDetails->STAGE_ID;
                $cnd_ary            =       array();
                
		$stagidCollectionDisp   =       array( 
					\Config::get('constants.STAGE_COLLEECTION.SUCCESS_REDO') 	,  
					\Config::get('constants.STAGE_COLLEECTION.AUTO_PDF_MERGE')  , 
					\Config::get('constants.STAGE_COLLEECTION.DESPATCH_UPLOAD')  ,
					\Config::get('constants.STAGE_COLLEECTION.INDEXING_VALIDATION')  ,
					1317
                );
               
                if( $stageDetails->ROUND_ID == \Config::get('constants.ROUND_NAME.S200') && !in_array( $dispStg , $stagidCollectionDisp ) ){

                    $go_to_taps     =       \Config::get( 'constants.STAGE_COLLEECTION.TAPS_DESKTOP' ); 
                    
                    if( $ret_status['status'] == 0 && $nextStageId !== \Config::get( 'constants.STAGE_COLLEECTION.AUTO_PDF_MERGE' )){
                        
                        $rollbackStatus     =       $checkoutObj->StageRollBack( $stageDetails->JOB_ROUND_ID, $stageDetails->WORKFLOW_ID, $stageDetails->ROUND_ID, $stageDetails->ITERATION_ID, $go_to_taps , $stageDetails );
                    
                    }
                    
                    $cnd_ary    =       array(  
                                            'METADATA_ID'   =>      $stageDetails->METADATA_ID , 
                                            'ROUND'         =>      $stageDetails->ROUND_ID                                                
                                        );
                    
                    
                    $inp_arr    =       array( 'END_TIME' => $endtime , 'TAPSCOMPLETION_STATUS' => 3 , 'REMARKS' =>  '"'.strtoupper($ret_status['msg']).' : ('.strtolower( $stg_info->STAGE_NAME ).') '.$ret_status['errMsg'].'"' );
                   
                    DB::table('api_taps')
                            ->where( 'METADATA_ID' , '=' , "$stageDetails->METADATA_ID"  )
                            ->where( 'ROUND' , '=' , "$stageDetails->ROUND_ID"  )
                            ->orderBy('ID','desc')
                            ->update( $inp_arr );
                    echo  '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">'.strtoupper($ret_status['msg']).' : ('.strtolower( $stg_info->STAGE_NAME ).') '.$ret_status['errMsg'].'</string>';
                    exit;

                }
				
            }
            
        }     
        
    }
    
    public function handlingAutoStages( $nextStageId , $nextJobStageId , $formData = array() ){
        
        $autoStageList      =       \Config::get('constants.AUTO_STAGE');   
        $autoProcessObj     =       new autostageController();
         
        if(  !is_null( $formData ) && !empty( $formData )){
            
            if( isset( $formData->optionalParamJson ) ){                 
                $optionalParams  =   $formData->optionalParamJson;  
            }   
            
            $manualpagestagid   =   \Config::get('dynamicConstant.STAGE_COLLEECTION.AUTO_CAP');
            
            if( $manualpagestagid == $nextStageId ){
                
                $input_arr  =   json_decode(  $optionalParams  ); 
                
                if( isset( $input_arr->withprint ) ){
                    $withprint  =  $input_arr->withprint;                
                    if( $withprint && $withprint == 'true' ){    
        
                    }else{
                        $getDPstage     =   $this->gotoDistillingStage( $nextJobStageId );
                        $nextStageId    =   $getDPstage['nextstageid'];
                        $nextJobStageId =   $getDPstage['nextjobstageid'];
                    }   
                    
                }
                
            }
            
        }
 
        //dynamic auto stage execution configuration - start                
        $getConfigInfo      =       $autoProcessObj->getAutoStageBgExecutionConfiguration( $nextJobStageId );
        
        if( !empty( $getConfigInfo ) ){
            $autoStageList = $getConfigInfo;
        }
        
        //dynamic auto stage execution configuration - end
        $methodToCall       =       $autoStageList[$nextStageId];   
        $this->response     =       $this->oopsErrorResponse;
        
        try{
            
            if( is_array( $autoStageList[$nextStageId] ) ){

                $nextAutoStageInfo         =       $autoStageList[$nextStageId];
                $wayofAutoProcess          =       strtolower( $nextAutoStageInfo['type'] );
                $execution_method_arr      =       explode( '@' , $nextAutoStageInfo['executable'] );
                $controllerPath            =       'App\\Http\\Controllers\\'.$execution_method_arr[0];                 
                $methodname                =       $execution_method_arr[1];
                //$optionalParams            =       null; //json input
            
                if(empty( $optionalParams ) ){
                    $autoResponse              =       app($controllerPath)->$methodname( $nextJobStageId );    
                }else{    
                    $autoResponse              =       app($controllerPath)->$methodname( $nextJobStageId , $optionalParams );                   
                }
                
                $returns_from_bg            =       (array)json_decode( $autoResponse );
                
                $checkoutObj                =       new checkoutModel();
                $stageDetails               =       $checkoutObj->getStageInfo( $nextJobStageId );
                $stageDetailsObj            =       $stageDetails[0];
               
                if( !empty( $returns_from_bg ) ){
                    if( $returns_from_bg['status'] > 0 &&  $wayofAutoProcess == 'normalfunction' ){
                            $this->moveNextStage( $stageDetails['0'] );

                    }else if( $returns_from_bg['status'] > 0 &&  $wayofAutoProcess == 'watchfolder' || (  isset( $returns_from_bg['params']['waiting'] ))  ){

                            $roundDo        =   $stageDetailsObj->ROUND_ID;
                            $waitingcheck   =   false;
                            $roundS300      =   \Config::get('constants.ROUND_NAME.S200');

                            if( $roundDo  ==  $roundS300 && $nextAutoStageInfo['waiting'] ){
                                    $waitingcheck   =   true;
                            }
                            if( isset( $nextAutoStageInfo['waiting'] ) && strtolower( $nextAutoStageInfo['waiting'] ) !== 'false' && $waitingcheck ){
                                    if( isset( $returns_from_bg['params'] ) ){
                                            $params     =       (array)$returns_from_bg[ 'params'];
                                            $tokenkey   =       $params['tokenkey'];
                                            $table      =       $params['table'];
                                            $status_ret =       $this->watch_folder_loop( $tokenkey , $table );
                                            $response_watch     =       explode( '@@@' , $status_ret );

                                            if( $response_watch[0] == 2 ){
                                                    $this->response['msg']    =   'success';     
                                                    $this->response['status'] =   1;     
                                                    $this->response['errMsg'] =   $returns_from_bg['msg'];  

                                                    $this->triggerNextStage( $nextJobStageId );

                                            }else if( $response_watch[0] == 3 ){

                                                    $update_jobstg_Query = 'update job_stage set Rollback_Remarks="'.$response_watch[1].'" where job_stage_id= '.$nextJobStageId.' limit 1';
                                                    DB::update( $update_jobstg_Query );
                                                    $this->response['errMsg'] =   $response_watch[1];
                                            }else{

                                                    $this->response['msg']    =   'failed';      
                                                    $this->response['status'] =   1.5;     
                                                    $this->response['errMsg'] =   $response_watch[1];  

                                            }
                                    }
                            }else{
                                    //tool will send signal to move a stage no need else case here
                                    $this->response     =  $returns_from_bg;
                            }

					}else if( $returns_from_bg['status'] == 0 ){
						$update_jobstg_Query = 'update job_stage set Rollback_Remarks="'.addslashes( $returns_from_bg['errMsg'] ) .'" where job_stage_id= '.$nextJobStageId.' limit 1';
						DB::update( $update_jobstg_Query );
						$this->response['errMsg'] =   addslashes( $returns_from_bg['errMsg'] );
					}
				}	
				
                return $this->response;
				
            }else{  
                
                
                $autoResponse       =   $autoProcessObj->$methodToCall($nextJobStageId);            
            }
           
        }catch(\Exception $e){
                  
            $err_handle             =       new errorController();             
            $err_handle->handleApplicationErrors( $e );
            
            return $this->response;
        }
        
        //return $this->response;
        
    }
      
    public function gotoDistillingStage( $jbstgid = null ){
        
        $checkoutObj            =       new checkoutModel();
        $stageData              =       $checkoutObj->getStageInfo( $jbstgid );
        $stageData              =       $stageData[0];
        
        $stageskipby            =       1;
        $jobRoundId             =   $stageData->JOB_ROUND_ID;
        $roundId                =   $stageData->ROUND_ID;
        $stageSequence          =   $stageData->STAGE_SEQ + $stageskipby;
        $workflowId             =   $stageData->WORKFLOW_ID;  
        $iteration              =   $stageData->ITERATION_ID;
        $jobId                  =   $stageData->JOB_ID;
        $outputQuantity         =   $stageData->OUTPUT_QUANTITY;
        $cur_jobstg_id          =   $stageData->JOB_STAGE_ID;
        $stg_id                 =   $stageData->STAGE_ID;

      
        $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId );
        $nextJobStageId         =       $nexstageDetails->JOB_STAGE_ID;
        $nextStageId            =       $nexstageDetails->STAGE_ID;
        
        //Close the Autocap stage [ not cared art ]
        //automatic stage close method
        if( isset( $stageData->CURRENTSTATUS  ) ){
            if( $stageData->CURRENTSTATUS == 23 ){
                $updateStageParam       =   array( 'STATUS' => '24' , 'CHECK_IN' => date( 'Y-m-d H:i:s' ) );
                $updateQry              =   DB::table('job_stage') 
                                                ->where('JOB_STAGE_ID', ( $stageData->JOB_STAGE_ID ) )
                                                ->update( $updateStageParam );
            }
        }
        
        //** auto stage **/
              $updateStageParam       =   array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $outputQuantity);
              $updateQry              =   DB::table('job_stage')
                                          ->where('JOB_STAGE_ID', $nextJobStageId )
                                          ->update( $updateStageParam );

              $jobRoundValue1         =   array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
              $updateQry              =   DB::table('job_round')
                                          ->where('JOB_ROUND_ID', $jobRoundId )
                                          ->update( $jobRoundValue1 );

        return array( 'nextstageid' => $nexstageDetails->STAGE_ID , 'nextjobstageid' => $nexstageDetails->JOB_STAGE_ID );
        
    }
    
    public function triggerNextStage( $nextJobStageId ){

        $checkoutObj        =       new checkoutModel();
        $stageDetails       =       $checkoutObj->getStageInfo( $nextJobStageId );
        
        if(count($stageDetails)>=1){

            $stageData              =  $stageDetails['0'];    
            $jobRoundId             = $stageData->JOB_ROUND_ID;
            $roundId                = $stageData->ROUND_ID;
            $stageSequence          = $stageData->STAGE_SEQ;
            $workflowId             = $stageData->WORKFLOW_ID;  
            $iteration              = $stageData->ITERATION_ID;
            $jobId                  = $stageData->JOB_ID;
            $outputQuantity         = $stageData->OUTPUT_QUANTITY;
            $inputQuantity          = $stageData->INPUT_QUANTITY;

            $nexstageDetails =  $checkoutObj->getNextStageDetails( $jobRoundId, $stageSequence, $iteration, $workflowId ); 

            if(!empty($nexstageDetails)){
                $moveStageResponse = $this->moveNextStage( $stageDetails['0'] );
            }else{
                $moveStageResponse = $this->finalStage( $nextJobStageId, $stageDetails['0'] ); 
            }

        } 

        $updateStageParam       =   array( 'STATUS' => '24' , 'CHECK_IN' =>  date( 'Y-m-d H:i:s' )  );
        $updateQry              =   DB::table('job_stage') 
                                        ->where('JOB_STAGE_ID', ( $nextJobStageId ) )
                                        ->update( $updateStageParam );

    }
    
    public function  watch_folder_loop( $tokenkey , $table , $round = null ){
        $i = 0;
        $status_ret = '';
        
        while ($i < 60 ) {                
            $i++;
            
            $query = "select STATUS,REMARKS from $table where TOKEN_KEY='".$tokenkey."' ORDER BY ID DESC LIMIT 0,1";
            $watchResp = DB::SELECT( $query );
            $watchResp  =   (array)$watchResp[0];	
            $status     =   $watchResp['STATUS'];
            $remarks    =   $watchResp['REMARKS'];
           
            $processname    =   str_replace( 'api_' , '' , $table );
            
            if ($status == "1" || $status == "3") {                
                $status_ret	=	"3@@@ Process [ $processname ] => ".$remarks;
                break;                
            } elseif ($status == "5") {                
                $status_ret	=	"5@@@ Process [ $processname ] => ".$remarks;
                break;                
            } else if ($status == "2") {                
                $status_ret	=	"2@@@success";
                break;                
            } else if ($status == "4") {                
                $status_ret	=	$status."@@@".$remarks;
                break;                
            } else {                
                $status_ret	=	"1.5@@@$processname => ";
                sleep(15);
                continue;
            }
        }
        
        return $status_ret;
            
    }
	
    public function finalStage($jobStageId,$stageDetail,$isArt=0){
        
        $time                   =   date('Y-m-d H:i:s');
        $updateStageParam       =   array( 'STATUS'=>'24','CHECK_IN'=> $time,'OUTPUT_QUANTITY' => $stageDetail->INPUT_QUANTITY);
        $updateQry              =   DB::table('job_stage')
                                   ->where('JOB_STAGE_ID', $jobStageId )
                                   ->update( $updateStageParam );

         $jobRoundValue         =   array('STATUS'=>'24','CURRENT_STAGE' => $stageDetail->STAGE_ID);
         $updateQry             =   DB::table('job_round')
                                        ->where('JOB_ROUND_ID',  $stageDetail->JOB_ROUND_ID )
                                        ->update( $jobRoundValue );
        if($isArt !=   1){
            $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($stageDetail->JOB_ID,$stageDetail->JOB_ROUND_ID,'update',$jobStageId);
        }
         if($isArt == 1){
             
            $artMetaValue          =  array('STATUS_ENUM_ID'=>'47' , 'CURRENT_STAGE' => $stageDetail->STAGE_ID );
            $updateQry             =  DB::table('task_level_art_metadata')
                                        ->where('ART_METADATA_ID',  $stageDetail->ART_METADATA_ID )
                                        ->update( $artMetaValue );
            
           
            //Avail the task from waiting to avail mode
            $this->resumeFromWaitingParrallelProcess( $jobStageId , $stageDetail , $isArt );
          
         }
         
         return true;                  
           
    }
    
    public function resumeFromWaitingParrallelProcess( $jobStageId , $stageDetail , $isArt ){
        
        //Check parallel workflow completed,  currently considering art only for resuming
        
        if( !empty( $stageDetail ) ){            
            
            if( $isArt == 1 ){

                $metaid     =       $stageDetail->METADATA_ID;
                $round      =       $stageDetail->ROUND_ID;
                
                $jbRndObj   =       new jobRound();
                $artRec     =       $jbRndObj->getjobRoundEntryExistByMetaId( $metaid , $round , 1 );
                
                if( count( $artRec ) ){                

                    $tlam_obj               =       new taskLevelArtMetadataModel();
                    $isart_completed_rec    =       $tlam_obj->isAllartStagesCompletedWithMetastatusTable( $metaid , $round );

                        if( count( $isart_completed_rec ) ==  0 ) {
                            
                            //get currently hold , main workflow jobstageid.
                            //then trigger the resume process
                            
                            $instatus       =   \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORPARALLEL' );
                            $statusI     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
                            $statusA     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.AVAILABLE' );
                            
                            $jbStgObj       =   new jobStage();
                            $checkoutObj    =   new checkoutModel();
                            $curStgInfo     =   $jbStgObj->getCurrentJobStageInfo( $metaid , $round  , $instatus );
                            
                            if( count( $curStgInfo ) ){
                                $curStgInfo         =       $curStgInfo[0];
                                $trigJbstgid        =       $curStgInfo->JOB_STAGE_ID;
                                $trigstgid          =       $curStgInfo->STAGE_ID;
                                $trigjobroundid     =       $curStgInfo->JOB_ROUND_ID;
                                
                                $jbstg       =       new jobStage();
                                $autoStageList      =       \Config::get('constants.AUTO_STAGE');
                                
                                $autoProcessObj     =       new autostageController();                   
                                $getConfigInfo      =       $autoProcessObj->getAutoStageBgExecutionConfiguration( $trigJbstgid );
                                
                                if( !empty( $getConfigInfo ) ){
                                    $autoStageList  =       $getConfigInfo;
                                }
                                
                               
                                if( isset( $autoStageList[$trigstgid] ) ){
                                    
                                    $setArr     =       array( 'STATUS' =>  $statusI );    
									$setjobroundArr 	=       array( 'STATUS' =>  $statusI,'CURRENT_STAGE'=> $trigstgid);
									jobRound::where('JOB_ROUND_ID',$trigjobroundid)->update($setjobroundArr);									
                                    $returnval  =       $jbstg->updateIfExist( $setArr , $trigJbstgid );
                                    //yet to do trigger autostage
                                    $this->handlingAutoStages($trigstgid, $trigJbstgid);
                                    
                                }else{                                    
                                    $setArr     =       array( 'STATUS' =>  $statusA );   
                                    $setjobroundArr 	=       array( 'STATUS' =>  $statusA,'CURRENT_STAGE'=> $trigstgid);
									jobRound::where('JOB_ROUND_ID',$trigjobroundid)->update($setjobroundArr);	
                                    $returnval  =       $jbstg->updateIfExist( $setArr , $trigJbstgid );                                    
                                }
                               
                            }
                            
                        }                   

                }

            }

            return true;        
        }
        
        return false;
        
    }
    
    public function ArtfinalStage($jobStageId,$stageDetail,$isArt=0){
        
        $time                   =   date('Y-m-d H:i:s');
        $updateStageParam       =   array( 'STATUS'=>'24','CHECK_IN'=> $time,'OUTPUT_QUANTITY' => $stageDetail->INPUT_QUANTITY);
        $updateQry              =   DB::table('job_stage')
                                   ->where('JOB_STAGE_ID', $jobStageId )
                                   ->update( $updateStageParam );

         $jobRoundValue          =  array('STATUS'=>'24','CURRENT_STAGE' => $stageDetail->STAGE_ID);
         $updateQry              =   DB::table('job_round')
                                   ->where('JOB_ROUND_ID',  $stageDetail->JOB_ROUND_ID )
                                   ->update( $jobRoundValue );
         
         if($isArt == 1){
            $artMetaValue          =  array('STATUS_ENUM_ID'=>'47','CURRENT_STAGE' => $stageDetail->STAGE_ID);
            $updateQry              =   DB::table('task_level_art_metadata')
                                        ->where('METADATA_STATUS_ID',  $stageDetail->METADATA_STATUS_ID )
                                        ->update( $artMetaValue );
            
            $artMetaValue          =  array('CURRENT_STATUS'=>'47','CURRENT_STAGE' => $stageDetail->STAGE_ID);
            $updateQry              =   DB::table('metadata_status')
                                      ->where('ID',  $stageDetail->METADATA_STATUS_ID )
                                      ->update( $artMetaValue );
         }
         
         //Avail the task from waiting to avail mode
         $this->resumeFromWaitingParrallelProcess( $jobStageId , $stageDetail , $isArt );
         
         return true;
                  
           
    }
    
    public function artstageSubmit(Request $request){
        
        
        $art_informations   =   $request->all();
        
        if(!empty($art_informations)){
            foreach($art_informations['artName'] as $fkey => $filedata){
                $art_informations['artName'][$fkey] = $art_informations['artName'][$fkey].'.'.strtolower($art_informations['files'][$fkey]);
            }
        }
       
        $response           =   array();
        $commonObj          =    new CommonMethodsController();
        $job_id             =   $request->input('jobID');
        $chapterno          =   $request->input('chaptername');
        $batchId            =   $request->input('batchId');
        $checkFlag          =   $request->input('checkFlag');
        $metaStatus         =   $request->input('metadataStatusId');
        
        $stageProcess['filemovement']   = 'failed';
        $stageProcess['manageStage']    = 'failed';
       
        
        $response       =   $this->checkAddorRemoveArt($art_informations);
       
        if(isset($response['failed']) && !empty($response['failed'])){
            $stageProcess['status'] = 'failed';
            $stageProcess['msg']    = 'File not exist - '.implode(',',$response['failed']);
            return response()->json($stageProcess);
        }
        
        if(isset($response['newfileexist']) && !empty($response['newfileexist'])){
            $stageProcess['status'] = 'failed';
            $fileAr = array();
            foreach($response['newfileexist'] as $key => $records){
                $fileAr[] = $records->FILE_NAME;
            }
            $stageProcess['msg']    = 'File(s) already exist for this Chapter - '.implode(',',$fileAr);
            
        }
        
        if(!empty($response['newfig'])){
            
            foreach($response as $newkey => $formated){
               
                if(array_key_exists($newkey,$art_informations)){
                    $art_informations[$newkey] = $formated;
                }
                
            }
            
            $artDetail     =    DB::table('task_level_art_metadata')->where('JOB_ID',$job_id)->where('METADATA_STATUS_ID',$metaStatus)->whereIn('FILE_NAME',$response['newfig'])->get();
           
            if(!empty($artDetail)){
                foreach($artDetail as $files){
                    $newartFile[] =  $files->ART_METADATA_ID;
                }
               $art_informations['artmetaid'] = array_merge($art_informations['artmetaid'],$newartFile);
            }
            
        }
       
        //$figure                         =   array_combine($art_informations['jobStageId'],$art_informations['artName']);
        //$figure                         = $art_informations['artName'];
       
        if($checkFlag == '1'){
            $figure                         =   array_combine($art_informations['jobStageId'],$art_informations['artName']);
        }else{
             $figure                        =   $response['artName'];
        }
       
        if(!empty($batchId)){
            $getjobstage        =   jobResource::where('BATCH_ID',$batchId)->get();
            
            $getjobstage        =   $getjobstage->pluck('JOB_STAGE_ID');
       
            $jstageId           =   $getjobstage['0'];
            foreach($getjobstage as $k => $jsId){
                $stageIDs[] =   $jsId;
            }
            $jobStageIDs             =    implode(',',$stageIDs);
            $checkoutObj             =    new checkoutModel();
            $jstageInfo              =   $checkoutObj->getArtStageInfo($jobStageIDs);
            
            $stageId                 =   $jstageInfo['0']->STAGE_ID;
            $metaDataId              =   $jstageInfo['0']->METADATA_ID;
            $roundId                 =   $jstageInfo['0']->ROUND_ID;
            $metaStatusId            =   $jstageInfo['0']->METADATA_STATUS_ID;
            
            $fileMoveStatus          =    stageMangerController::artFileMovementProcess($jstageId,$figure,$jstageInfo,$checkFlag);
            
           if($fileMoveStatus['status'] == 'success' || $fileMoveStatus['status'] =='nofileMovement' ){
               $stageProcess['filemovement'] = 'success';
               
              
               $storeArtRes       = $this->storeArtInfo($art_informations,$checkFlag);
               $storeArtRes['status'] = 'success';
                if($storeArtRes['status'] == 'success'){
                    
                   $stageManage         = true;
                   $getCurrentStage         =   $checkoutObj->getCurrentStageDetais($metaStatusId);
                   $getCurrentStage->artMetadataId =  $art_informations['artmetaid'];
                   
                    /*foreach($jstageInfo as $key2 => $sdata){
                      //$stageManage = true;
                      if( in_array( $sdata->ART_METADATA_ID , $art_informations['isRej'] ) ){
                          $artmetaid    =    $sdata->ART_METADATA_ID;
                          $jbrid        =    $sdata->JOB_ROUND_ID;
                          $wrkflwid     =    $sdata->WORKFLOW_ID;
                          $rid          =    $sdata->ROUND_ID;
                          $iteration    =    $sdata->ITERATION_ID;
                         
                          $checkoutObj->artStageRollBack( $artmetaid , $jbrid , $wrkflwid , $rid , $iteration );
                          continue;
                      }
                    }*/
                    $movetoStage = 1;
                   if(!empty($art_informations['isRej'])){
                       $movetoStage =0;
                   }
                     $stageManage = $this->mangeArtStageProcess($getCurrentStage,$checkFlag,$movetoStage);
                  
                      if($stageManage == false){
                          $stageManage  =   false;
                      }
                      
                      if(!empty($art_informations['isRej'])){
                          
                          //$getCurrentStage         =   $checkoutObj->getCurrentStageDetais($stageDetails->METADATA_STATUS_ID);
                           $artMetaids             =    implode(',',$art_informations['isRej']);
                           
                           $checkoutObj->artStageRollBack($artMetaids,$getCurrentStage->METADATA_STATUS_ID,$getCurrentStage->JOB_ROUND_ID,$getCurrentStage->WORKFLOW_ID,$getCurrentStage->ROUND_ID,$getCurrentStage->ITERATION_ID,$getCurrentStage);
                      }
                        
                    if($stageManage == true ){
						
						$artQc     			= Config::get('constants.STAGE_COLLEECTION.ART_QC'); 
						$artManuplation     = Config::get('constants.STAGE_COLLEECTION.ART_MANIPULATION'); 
                        
                         $deleteWrokPath          =   $fileMoveStatus['pathDetails']['detail']['opendrive']; 
                         $deleteRes               =   $commonObj->deletefilesInproduction($deleteWrokPath);
                        
                            /** Art Validation **/
                            if($stageId == $artManuplation && $checkFlag == '0'){
                               
                                $artProcessObj  =    new artProcessController();
                                $process        =    $artProcessObj->artValidation($batchId,$metaStatusId,$metaDataId,$roundId);
                                
                            }
                           
                             /** Art PDF generation auto stage **/
                           if($stageId == $artQc && $checkFlag == '0' && $movetoStage == '1'){ 
                               // $qcStageComplete   =     $this->checkArtQcCompleted($metaDataId,$roundId);
                                $qcStageComplete    = true;
                                if($qcStageComplete == true){
                                    //get art meta id
                                    $wheredata      =   array('METADATA_ID'=>$metaDataId,'IS_ACTIVE'=>1);
                                    $artmetaid      =   taskLevelArtMetadataModel::where($wheredata)->get();
                                    $getallmetaid   =   $artmetaid->pluck('ART_METADATA_ID')->toArray();
                                    $artmetaid      =   implode(',',$getallmetaid);
                                    $tapsdata       =   [];
                                    $tapsdata['metadataid'] =   $metaDataId;
                                    $tapsdata['jobId']      =   $job_id;
                                    $tapsdata['artmetaid']  =   $artmetaid;
                                    $tapsdata['processtype']=   '2';
									
                                    $artProcessObj  =    	new artProcessController();
                                    $outputRes      =		$artProcessObj->doArtfigurePdfCreationxml2(  $artmetaid , $metaDataId , $job_id , 2 , $metaStatusId  );
                                }
                            }
                            
                         $stageProcess['status']    =   'success';
                    }else{
                        $stageProcess['status'] = 'failed';
                         $stageProcess['msg']    = 'Unable to store stage process';
                    }
                }else{
                    $stageProcess['status'] = 'failed';
                    $stageProcess['msg']    = 'Unable to store artinformation';
                }
             
           }else{
               $stageProcess['status'] = 'failed';
                $stageProcess['msg']    = 'Unable to copy files - '.implode(',',array_keys($fileMoveStatus['0']));
           }

        }
       
        return response()->json($stageProcess);

        $art_informations   =   $request->all();

    }
    
    public function checkAddorRemoveArt($artInfo){
       
        $artFigureDetails['artName'] = array();
        if(!empty($artInfo['artName'])){
            foreach($artInfo['artName'] as $key=>$data){
                if(!in_array($data,$artFigureDetails['artName'])){
                    $artFigureDetails['artName'][$key] = $data;
                    
                    if($artInfo['artmetaid'][$key] != ''){
                        $artFigureDetails['artmetaid'][$key]        =  $artInfo['artmetaid'][$key];
                        $artFigureDetails['files'][$key]            =   $artInfo['files'][$key];
                        $artFigureDetails['type'][$key]             =   $artInfo['type'][$key];
                        $artFigureDetails['complexity'][$key]       =   $artInfo['complexity'][$key];
                        $artFigureDetails['mode'][$key]             =   $artInfo['mode'][$key];
                        $artFigureDetails['workinvolved'][$key]     =   $artInfo['workinvolved'][$key];
                        $artFigureDetails['inputcolor'][$key]       =   $artInfo['inputcolor'][$key];
                        $artFigureDetails['outputcolor'][$key]      =   $artInfo['outputcolor'][$key];
                        $artFigureDetails['remarks'][$key]          =   $artInfo['remarks'][$key];
                    }else{
                        $artFigureDetails['newfig'][$key]           =   $data;
                        $artFigureDetails['files'][$key]            =   $artInfo['files'][$key];
                        $artFigureDetails['type'][$key]             =   $artInfo['type'][$key];
                        $artFigureDetails['complexity'][$key]       =   $artInfo['complexity'][$key];
                        $artFigureDetails['mode'][$key]             =   $artInfo['mode'][$key];
                        $artFigureDetails['workinvolved'][$key]     =   $artInfo['workinvolved'][$key];
                        $artFigureDetails['inputcolor'][$key]       =   $artInfo['inputcolor'][$key];
                        $artFigureDetails['outputcolor'][$key]      =   $artInfo['outputcolor'][$key];
                        $artFigureDetails['remarks'][$key]          =   $artInfo['remarks'][$key];
                    }
                }
            }
        }
        
        $fileResponse  = $this->checkFileExistInDir($artInfo['jobStageId']['0'],$artFigureDetails['artName']);
        
        if(!empty($fileResponse) && !empty($fileResponse['failed'])){
           return $fileResponse;
        }
        
        
        
        if(!empty($artFigureDetails['newfig'])){
            $artprocessObj      =   new artProcessController();
            $response           =   $artprocessObj->insertNewArtInProcess($artFigureDetails,$artInfo);
            
            if(isset($response['newfileexist']) && !empty($response['newfileexist'])){
                $existRecord['newfileexist']  = $response['newfileexist'];
                return $existRecord;
            }
            
        }
        
        return $artFigureDetails;
        
    }
   
    public function checkFileExistInDir($jobStageId, $files){ 
        
        $workflowPath                     =   new workflowServerMapPathModel();
        $jstageInfo                       =    0;
        $serverMapPath                    =   $workflowPath->getWorkflowServerMapPath($jobStageId,0,$jstageInfo);
        $path   = $serverMapPath['detail']['work'];
        $serverDetail  = $serverMapPath['serverCredential'];
        $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
        $fileexit = array();
        foreach($files as $key => $data){
            if(!empty($data)){
            $file_path      =   $path.$data;
            $res            =  $fileHandlerObj->ftpFileExist(str_ireplace($serverDetail['host'],'',$file_path));
            if($res == true){
               $fileexit['success'][] = $data; 
            }else{
               $fileexit['failed'][] = $data;
            }
            }else{
                $fileexit['failed'][] = 'Art name should not be empty';
            }
           
        }
        return $fileexit;
    }
	
    public function storeArtInfo($art_informations,$checkFlag){
        
        
	$job_id             =   $art_informations['jobID'];
        $chapterno          =   $art_informations['chaptername'];
        $batchId            =   $art_informations['batchId'];
        $getjobstage        =   jobResource::where('BATCH_ID',$batchId)->get();
        $artmetaid          =   $art_informations['artmetaid'];
        $wrkinv             =   $art_informations['workinvolved'];
        $mode               =   $art_informations['mode'];
        $complexity         =   $art_informations['complexity'];
        $type               =   $art_informations['type'];
        $file               =   $art_informations['files'];
        $artName            =   $art_informations['artName'];
        $inputcolor         =   $art_informations['inputcolor'];
        $outputcolor        =   $art_informations['outputcolor'];
        $remarks            =   $art_informations['remarks'];
        $chaptername        =   $art_informations['chaptername'];
        $completed          =   $art_informations['isCompleted'];
        $metaStatusId       =   $art_informations['metadataStatusId'];
        
        $allinsertsuccess   =   array();
        $round_arr          =   Config::get('constants.ROUND_ID');
        $round              =   $round_arr['S5'];
        //get book id 
        $bookdetaills       =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid             =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:''); 
        
        try
        {
            if(count($artmetaid)>=1)
            {
                //DB::commit();
                $inserid        =   '';
                $updatedata     =   [];
                $artCompletedStatus = 0;
                foreach( $artmetaid as $index => $value )
                {
                    if(in_array($value,$completed)){
                        $artCompletedStatus = 1;
                    }
                    
                    if($checkFlag != 1){
                        $artCompletedStatus = 1;
                    }
                     
                    $insert_arr['FIGURE_NAME']      =   $artName[$index];    
                    $getstageid                     =   $getjobstage->where('ART_METADATA_ID', $value)->first();
                    $insert_arr['JOB_STAGE_ID']     =   (count($getstageid)>=1?$getstageid->JOB_STAGE_ID:'');    
                    $insert_arr['ART_METADATA_ID']  =   $value;    
                    $insert_arr['BATCH_ID']         =   $batchId;
                    $insert_arr['METADATA_STATUS_ID']=   $metaStatusId;
                    $insert_arr['ROUND_ID']         =   Config::get('constants.ROUND_ID.S200');        
                    $insert_arr['COMPLEXITY']       =   $complexity[$index];    
                    $insert_arr['FILE_TYPE']        =   $file[$index];    
                    $insert_arr['IMAGE_TYPE']       =   $type[$index];    
                    $insert_arr['MODE']             =   $mode[$index];
                    $insert_arr['STATUS']           =   $artCompletedStatus;
                    $insert_arr['WORK_INVOLVED']    =   $wrkinv[$index];    
                    $insert_arr['INPUT_COLOR']      =   $inputcolor[$index];    
                    $insert_arr['OUT_COLOR']        =   $outputcolor[$index];    
                    $insert_arr['QUERY']            =   "";    
                    $insert_arr['REMARKS']          =   $remarks[$index];    
                    $insert_arr['CREATED_DATE']     =   Carbon::now();
                    $insert_arr['CREATED_BY']       =   Session::get('users')['user_id'];
                    $allinsertsuccess[$value]       =   '';
                  
                    $inserid                        =   DB::table('art_category_log')->insertGetId( $insert_arr );
                    $response['msg']                =   'Record insert success';
                    if( $inserid ){
                        //update art meta
                        $updatedata['FILE_NAME']        =   $artName[$index];    
                        //$updatedata['FIGURE_NO']        =   ($index+1);    
                        $updatedata['COMPLEXITY']       =   $complexity[$index];    
                        $updatedata['FIGURE_TYPE']      =   $type[$index];    
                        $updatedata['INPUTCOLOR']       =   $inputcolor[$index];    
                        $updatedata['OUTPUTCOLOR']      =   $outputcolor[$index];    
                        $updatedata['INPUT_MODE']       =   $mode[$index];    
                        $updatedata['INPUT_FILE']       =   $file[$index];
                        $updatedata['FIGURE_STATUS']    =   $artCompletedStatus;
                        $updatedata['WORK_INVOLVED']    =   $wrkinv[$index];    
                        $updatedata['REMARKS']          =   (!empty($remarks[$index])?$remarks[$index]:'');    
                        $allinsertsuccess[$value]       =   '';
                       
                        $updatertinfo                   =   DB::table('task_level_art_metadata')->where('ART_METADATA_ID',$value)->update($updatedata);
                        if($updatertinfo)
                        {
                            $allinsertsuccess[$value]   =   'success';
                        }
                        else
                        {
                            $allinsertsuccess[$value]   =   'failed';
                        }
                        $allinsertsuccess[$value]   =   'success';
                    }else{
                        $allinsertsuccess[$value]   =   'failed';
                    }                       
               
                }
                //DB::rollBack();      
                $responsemessge         =   (count($artName)  ==  0?'Submitted Successfully...':'Art information stored successfully...');
                if( in_array( 'failed' , $allinsertsuccess ) ){

                    foreach ($allinsertsuccess as $key => $value ){
                        if( $value == 'success' ){
                            unset( $allinsertsuccess[$key] );
                        }
                    }
                    $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>$job_id  ,'artMsg'=>$responsemessge, $allinsertsuccess );
                }else{
                    $allinsertsuccess    =       array( 'status' => 'success' ,'jobId'=>$job_id,'artMsg'=>$responsemessge, $allinsertsuccess );

                }
                return  $allinsertsuccess ;
            }
            $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>$job_id  ,'artMsg'=>$responsemessge, $allinsertsuccess );
            return $allinsertsuccess ;
            
        }catch( \Exception $e ){
                    $allinsertsuccess   =       array( 'status' => 'failed','jobId'=>''  ,'artMsg'=>'Kindly try again'.$e->getMessage());
             return $allinsertsuccess ;
        }
	
	}
    
    public function artFileMovementProcess($jobStageId,$figure,$jstageInfo,$checkFlag){
        $workflowPath                     =   new workflowServerMapPathModel();
        $serverMapPath                    =   $workflowPath->getWorkflowServerMapPath($jobStageId,1,$jstageInfo);
       
        $fileStatus                       = array();
       
        if($serverMapPath['status'] == '1' && $checkFlag == '0'){
            $fileStatus                       =   stageMangerController::artFileMoveMent($serverMapPath,$figure,$checkFlag);
            $fileStatus['pathDetails']           =  $serverMapPath;
        }elseif($serverMapPath['status'] == '1' && $checkFlag == '1'){
          
            $fileStatus                       =   stageMangerController::checkInartFileMoveMent($serverMapPath,$figure,$checkFlag);
             $fileStatus['pathDetails']           =  $serverMapPath;
        }else{
            $fileStatus['status'] = 'nofileMovement';
            $fileStatus['pathDetails']           =  '';
        }
       
      return $fileStatus;
    }
    
    public static function artFileMoveMent($pathDetails,$figure,$checkFlag){
        
        $fileMovementStatus = array();
       
        if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
            
            $workDir            =   $pathDetails['detail']['work'];
            $destDir            =   $pathDetails['detail']['dest'];
            $destDir2            =   $pathDetails['detail']['dest'];
            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
            //$qcStage                      =        \Config::get('constants.STAGE_COLLEECTION.ART_QC');
            
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            $copyStatus         =   array();
            
          
            $destDirPath        =   str_ireplace($serverDetail['host'],'',$destDir);
            $directory          =   $fileHandlerObj->make_directory($destDirPath);
            
            $existingFilelist    =    $fileHandlerObj->getDirectoryFiles($destDirPath);
            $existingFilename = array();
            if(!empty($existingFilelist)){
                
                foreach($existingFilelist as $list => $existData){
                    $splitData = explode('/',$existData);
					$exFilename = explode('.',end($splitData));
					if(count($exFilename)>1){
						$existingFilename[$exFilename['0']][] = $exFilename['1'];
                  	}
                }
               $backdirectory          =   $fileHandlerObj->make_directory($destDirPath.'/BACKUP');  
            }
			
			$options  		= array('ftp' => array('overwrite' => true));
			$stream   		= stream_context_create($options);
           
            foreach($figure as $key=>$data){
                $filepath       =   $workDir.$data;
                $destpath       =   $destDir.$data; 
                $fileExistPath  =   str_ireplace($serverDetail['host'],'',$filepath);
               
               $status          =    $fileHandlerObj->ftp_file_exist($fileExistPath);
             
               if($status == '1'){
				  
                    $orgFile			=	explode('.',$data);
                    if(!empty($orgFile)){

                                  if(array_key_exists( $orgFile[0], $existingFilename)){

                                    foreach($existingFilename[$orgFile[0]] as $exkey => $ext){
                                            $exfilename   = $orgFile[0].'.'.$ext;

                                            if($data != $exfilename){ //backup the existing data 
                                                    $fileString1      =   file_get_contents($crd.$destDir2.$exfilename);
                                                    $filecreate2      =   @file_put_contents($crd.$destDir2.'/BACKUP/'.$exfilename, $fileString1,0,$stream);
                                                    $deleteFile		=	 str_ireplace($serverDetail['host'],'',$destDir.$exfilename);
                                                    $fileHandlerObj->ftpDeleteFile($deleteFile);
                                            }

                                    }

                                  }
                    }
				  
                   $fileString      =   file_get_contents($crd.$filepath);
                   $filecreate      =   @file_put_contents($crd.$destpath, $fileString,0,$stream);
				   
				   
                   $copyStatus[$data] = 'success';
               }else{
                   $copyStatus[$data] = 'failed';
               }
            }
            
            $destDirPath3        =   str_ireplace($serverDetail['host'],'',$destDir.'REFERENCE_PDF');
            $directory          =   $fileHandlerObj->make_directory($destDirPath3);
              
            $fileExtension[] = '.pdf';
            $fileMoveStatus            =   $fileHandlerObj->ftp_dir_copy_word_file_only( $crd.$workDir, $destDir.'REFERENCE_PDF',array(),$fileExtension );
          
           
            //$workupstage                      = \Config::get( 'constants.ART_SUPPORTING_FOLDER_STAGES' );
            // if(in_array($stageInfo['0']->STAGE_ID,$workupstage)){
              
              $folderPath       =   $pathDetails['detail']['work'].'WORK_UP/';
              $folderPath2      =   $pathDetails['detail']['work'].'PRINT';
              $workupDirPath    =   str_ireplace($serverDetail['host'],'',$folderPath);
              $printDirPath     =   str_ireplace($serverDetail['host'],'',$folderPath2);
              $fileHandlerObj   =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
           
              $workupfolder        =   $fileHandlerObj->ftp_is_dir($workupDirPath);
              if($workupfolder == true){
                  $workupDir             =   str_ireplace($serverDetail['host'],'',$pathDetails['detail']['artworkuppath']);
                  $res                   =   $fileHandlerObj->ftp_dir_copy($crd.$folderPath2,$pathDetails['detail']['artworkuppath']);
              }
             
              $printFolder          =   $fileHandlerObj->ftp_is_dir($printDirPath);
               if($printFolder == true){
                 $printdir              =   str_ireplace($serverDetail['host'],'',$destDirPath);
                 $printCopyRes          =   $fileHandlerObj->make_directory($printdir.'/PRINT');
                 $printCopyRes          =   $fileHandlerObj->ftp_dir_copy($crd.$folderPath2,$destDirPath.'/PRINT');
                
              }
           // }
            
            $commonMethod       =   new CommonMethodsController();
            $fileMovementStatus =   $commonMethod->getFileMovementStatus($copyStatus);
            
        }
       
        return $fileMovementStatus;
    }
    
    public static function checkInartFileMoveMent($pathDetails,$figure,$checkInflag){
        
        
        $fileMovementStatus = array();
        
        if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
            
            $workDir            =   $pathDetails['detail']['work'];
          
            $destDir            =   $pathDetails['detail']['dest'];
           
            if($checkInflag == '1'){
                $destDir            = $pathDetails['detail']['arttemp'];
            }
            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            
            $destDirPath        =   str_ireplace($serverDetail['host'],'',$destDir);
          
            $directory          =   $fileHandlerObj->make_directory($destDirPath);
          
            $fileMoveStatus     =   $fileHandlerObj->ftp_dir_copy($crd.$workDir,$destDir);
         
            $commonMethod       =   new CommonMethodsController();
            $fileMovementStatus =   $commonMethod->getFileMovementStatus($fileMoveStatus);
        }
        return $fileMovementStatus;
        
    }
        
    public function mangeArtStageProcess($dataInfo,$checkFlag,$movetoStage){
        
        $manageStage        =   false;
        
        $jobStageId         = $dataInfo->JOB_STAGE_ID;
        $inputQuanity       = $dataInfo->INPUT_QUANTITY;
        $outputQuanity      = $dataInfo->OUTPUT_QUANTITY;
        $inputRemarks       = (!empty($dataInfo->inputRemarks)?$dataInfo->inputRemarks:'');
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
       
        $workLogStatus          =   $this->manageWorkLog($jobStageId,$inputQuanity,$outputQuanity,$inputRemarks,$dataInfo,$checkFlag);
       
        if($checkFlag == '0' && $movetoStage == '1'){
            $openNextStageStatus    =   $this->moveNextStage($dataInfo,1);
            if($openNextStageStatus['status'] == 'success'){
            $manageStage        =   true;
            }
        }else{
            $manageStage        =   true;
        }
        if($checkFlag == '1'){
             $manageStage        =   true;
        }
        
        
       return $manageStage;
    }
    
    public function checkArtQcCompleted($metaid,$roundId){
        
        /*$metaid                 =       '2651';
        $roundId                =       '116';*/
        $generatePdf            =       false;
        $totalArt               =       DB::table('task_level_art_metadata')->where( 'METADATA_ID' , $metaid )
                                        ->where('IS_ACTIVE', true)->get();
        $totalArtCount          =       count( $totalArt );
        
        $totalstageArt               =       DB::table('job_round')
                                                ->where( 'METADATA_ID' , $metaid )
                                                ->where('IS_ART',true)
                                                ->where('CURRENT_STAGE','1313')
                                                ->where('ROUND_ID', $roundId)->get();
        $totalCompleteStage       =       count( $totalstageArt );
        
        if($totalArtCount <= $totalCompleteStage){
            $generatePdf  = true;
        }
        
        return $generatePdf;
    }
    
    public function moveToNextStageForArtFigureValiation( $stageData , $isArt = 1 ){
        
        $moveStage = array();
        $moveStage['status']    =   'failed';
        if(empty($stageData) )
            return $moveStage;
       
        $time       =       date('Y-m-d H:i:s');
       
        $jobRoundId             =       $stageData->JOB_ROUND_ID;
        $roundId                =       $stageData->ROUND_ID;
        $stageSequence          =       $stageData->STAGE_SEQ + 1;
        $workflowId             =       $stageData->WORKFLOW_ID;  
        $iteration              =       $stageData->ITERATION_ID;
        $jobId                  =       $stageData->JOB_ID;
        $curjobstgid            =       $stageData->JOB_STAGE_ID;        
        $outputQuantity         =       $stageData->OUTPUT_QUANTITY;
     
        $updateStageParam       =       array( 'STATUS'=>'24','CHECK_IN'  => $time );
        
        $updateQry              =       DB::table('job_stage')
                                          ->where('JOB_STAGE_ID', $curjobstgid )
                                          ->update( $updateStageParam );
        
        $obj_pfl = new \App\Http\Controllers\workflow\workflowRuleController();
       
        if(!empty($stageData)){
           $stageId     =  $stageData->STAGE_ID;
           $jobId       =  $stageData->JOB_ID;
           $roundId     =  $stageData->ROUND_ID;
           $wfId        =  $stageData->WORKFLOW_ID; 
           $ruleDetail  =  $obj_pfl->getRuleForGivenStage($stageId, $roundId, $jobId, $wfId, $wfMid='');
           //echo "<pre>";print_r($ruleDetail);exit;
        }
        
        $checkoutObj            =       new checkoutModel();
        $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);
        
         if(!empty($nexstageDetails)){
            
            $nextStageId        =       $nexstageDetails->STAGE_ID;
            $nextJobStageId     =       $nexstageDetails->JOB_STAGE_ID;
            $userDefData        =       taskLevelUserdefinedWorkflow::getUserDefineStageDetails($jobId, $workflowId,$roundId,$nextStageId);
            $stageType          =       $userDefData->IS_AUTO;
            
            if($stageType == '0'){                
                //** Manual stage **/
                
                $updateStageParam       =   array( 'STATUS'=>'27','INPUT_QUANTITY' => $outputQuantity);
                $updateQry              =   DB::table('job_stage')
                                                ->where('JOB_STAGE_ID', $nextJobStageId )
                                                ->update( $updateStageParam );

                $jobRoundValue          =  array('STATUS'=>'27','CURRENT_STAGE' => $nextStageId);
                $updateQry              =   DB::table('job_round')
                                                ->where('JOB_ROUND_ID', $jobRoundId )
                                                ->update( $jobRoundValue );

                 if($isArt == 1){

                     $jobRoundValue2          =   array( 'CURRENT_STAGE'  =>  $nextStageId,'CURRENT_ITERATION' => $iteration  );
                     $updateQry               =   DB::table('task_level_art_metadata')
                                                        ->where('METADATA_STATUS_ID', $stageData->METADATA_STATUS_ID )
                                                        ->where('CURRENT_ROUND', $roundId )
                                                        ->update( $jobRoundValue2 );
														
					  $updateQry2               =   DB::table('metadata_status')
                                                        ->where('ID', $stageData->METADATA_STATUS_ID )
                                                        ->where('CURRENT_ROUND', $roundId )
                                                        ->update( $jobRoundValue2 );

                 }

                 $moveStage['status']  = 'success';
               
            }
            
         }
         else{
             $this->ArtfinalStage( $curjobstgid ,$stageData, 1 );
         }
         
    }
        
    public function stageRollBack( $jobStageId , $rollbackToStage = null  , $remarks = null  ){
       
	$stg_avail_const		=		\Config::get('constants.STATUS_ENUM_COLLEECTION.AVAILABLE');
	$stg_new_activity		=		\Config::get('constants.STATUS_ENUM_COLLEECTION.NEWACTIVITY');
	$stg_complt_const		=		\Config::get('constants.STATUS_ENUM_COLLEECTION.COMPLETED');
	$stg_inprogress_const           =		\Config::get('constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS');
        
        if( $rollbackToStage ==  \Config::get( 'constants.STAGE_COLLEECTION.PACKAGING' ) ){
            $stg_avail_const    =   $stg_inprogress_const;
        }
        
        if( $rollbackToStage ==  \Config::get( 'constants.STAGE_COLLEECTION.BOOK_BUILDING' ) ){
            $stg_avail_const    =   $stg_complt_const;
        }
		
	if( $rollbackToStage ==  \Config::get( 'constants.STAGE_COLLEECTION.REPACKAGE' ) ){
            $stg_avail_const    =   $stg_inprogress_const;
        }
        
	$arrayMsg                       =               array( 'status'=> '0'  , 'Msg' => 'Failed' , 'errMsg' => 'Invalid try [ check roleback method parameter ]'  );
        
	if( !is_null( $rollbackToStage ) && isset( $jobStageId ) ){
            
            $checkoutObj        =   new checkoutModel();
            $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
            
            if(count($stageDetails)){
           
                $jbstg_rec          =       $stageDetails[0];        
                $roundId            =       $jbstg_rec->ROUND_ID;
                $metaId             =       $jbstg_rec->METADATA_ID;

                $sql_stmt_jstg                  =		'select jr.JOB_ROUND_ID,js.JOB_STAGE_ID as CUR_JOBSTG_ID,js.ITERATION_ID + 1 as NEXT_ITERATION,jst.ITERATION_ID as CUR_ITERATION,
                                                                        jst.STAGE_SEQ as ROLL_STGSEQ 
                                                                        from task_level_metadata t 
                                                                        join job_round jr on jr.METADATA_ID=t.METADATA_ID and jr.REVISION_NO=t.REVISION_NO and jr.IS_ART is null 
                                                                        join job_stage js on js.JOB_ROUND_ID=jr.JOB_ROUND_ID and js.ITERATION_ID=jr.CURRENT_ITERATION_ID 
                                                                        left join job_stage jst on jst.JOB_ROUND_ID=jr.JOB_ROUND_ID and jst.ITERATION_ID=jr.CURRENT_ITERATION_ID and jst.STAGE_ID = '.$rollbackToStage.' 
                                                                        where jr.METADATA_ID = '.$metaId.' and jr.ROUND_ID = '.$roundId.' AND js.JOB_STAGE_ID  = '.$jobStageId.' ORDER BY js.JOB_STAGE_ID desc LIMIT 1';
                
                try{
                        
                        $jbstg_info			=		DB::select( $sql_stmt_jstg );
                        
                        if( count( $jbstg_info ) ){
                            
                            $jbstg_info                     =               ( array )$jbstg_info[0];
                            $job_roundId                    =   		$jbstg_info['JOB_ROUND_ID'];
                            $cur_job_stageId                =		$jbstg_info['CUR_JOBSTG_ID'];
                            $next_iterationId               =		$jbstg_info['NEXT_ITERATION'];
                            $cur_iterationId                =		$jbstg_info['CUR_ITERATION'];
                            $rollback_stageSeq              =		$jbstg_info['ROLL_STGSEQ'];

                            if( empty( $job_roundId ) ){
                                $sql_stmt_jstg2                  =		'select jr.JOB_ROUND_ID,js.JOB_STAGE_ID as CUR_JOBSTG_ID,js.ITERATION_ID + 1 as NEXT_ITERATION,jst.ITERATION_ID as CUR_ITERATION,
                                                                        jst.STAGE_SEQ as ROLL_STGSEQ 
                                                                        from task_level_metadata t 
                                                                        join job_round jr on jr.METADATA_ID=t.METADATA_ID and jr.REVISION_NO=t.REVISION_NO and jr.IS_ART is null 
                                                                        join job_stage js on js.JOB_ROUND_ID=jr.JOB_ROUND_ID and js.ITERATION_ID=jr.CURRENT_ITERATION_ID  
                                                                        left join job_stage jst on jst.JOB_ROUND_ID=jr.JOB_ROUND_ID and jst.ITERATION_ID=jr.CURRENT_ITERATION_ID 
                                                                        where jr.METADATA_ID = '.$metaId.' and jr.ROUND_ID = '.$roundId.' AND js.JOB_STAGE_ID  = '.$jobStageId.' ORDER BY js.JOB_STAGE_ID desc LIMIT 1';
                                $job_roundId                    =   	$jbstg_info2['JOB_ROUND_ID'];
                                $cur_job_stageId                =       $jbstg_info2['CUR_JOBSTG_ID'];
                                 $next_iterationId              =       $jbstg_info2['NEXT_ITERATION'];
                                
                            }
                            
                            
                            if( empty($cur_iterationId) ){
                                $cur_iterationId    =   1;
                            }
                            
                            if( empty( $rollback_stageSeq ) && isset( $rollbackToStage )){
                                $getRecordForSeq        =   DB::select( 'select * from job_stage where job_round_id = '.$job_roundId.' and ITERATION_ID = 1 AND STAGE_ID = '.$rollbackToStage. ' limit 1' );
                               
                                if( count( $getRecordForSeq ) ){
                                    $rollback_stageSeq      =       $getRecordForSeq[0]->STAGE_SEQ;
                                }
                                
                            }
                            
                          //  DB::beginTransaction();

                            //make current stage to completed
                            $make_stage_completed		=       'update job_stage set status = '.$stg_complt_const.', check_in = now() where job_stage_id = '.$cur_job_stageId;
                            $js_upd_cls    =   DB::update( $make_stage_completed );

                            //create next iteration entry
                            $create_next_stage_iteration    =       "insert into job_stage (JOB_ROUND_ID,WORKFLOW_MASTER_ID,WORKFLOW_ID,WORKFLOW_TYPE,WORKFLOW_SEQ,STAGE_ID,STAGE_SEQ,STATUS,INPUT_QUANTITY,ITERATION_ID)
                            select JOB_ROUND_ID,WORKFLOW_MASTER_ID,WORKFLOW_ID,WORKFLOW_TYPE,WORKFLOW_SEQ,STAGE_ID,STAGE_SEQ,".$stg_new_activity.",INPUT_QUANTITY, ".$next_iterationId." from job_stage "
                                    . "where job_round_id = ".$job_roundId." and stage_seq >= ".$rollback_stageSeq." and iteration_id = 1";
                            
                            $ins_jbs    =   DB::insert( $create_next_stage_iteration );	
                            
                            $additonal_set  =   '';
                            
                             if( !is_null($remarks) && isset( $remarks ) ){     
                                $remarks    = trim( $remarks );
                                if( strlen( $remarks ) ){
                                    $additonal_set           .=       ' , Rollback_Remarks =  "'.stripslashes( $remarks ).'" ';
                                }
                            }
                            
                            //make rollbacked stage to available
                            $make_stage_available           =       'update job_stage set STATUS = '.$stg_avail_const.$additonal_set.' where job_round_id = '.$job_roundId.' and stage_seq = '.$rollback_stageSeq.' and iteration_id = '.$next_iterationId;
                            
                            $js_upd_avl =   DB::update( $make_stage_available );

                            //job round update for iteration
                            $update_jb_rnd                  =       'update job_round set current_stage = '.$rollbackToStage.' ,current_iteration_id = '.$next_iterationId.', status = '.$stg_avail_const.' where job_round_id = '.$job_roundId ;
                            $jbs_rnd_upd    =   DB::update($update_jb_rnd);

                            $tasklevelmetadata_query        =	'update task_level_metadata set CURRENT_STAGE='.$rollbackToStage.',CURRENT_ITERATION= '.$next_iterationId.' where metadata_id = '.$metaId;
                            $tsk_crn_upd    =       DB::update( $tasklevelmetadata_query );
                            
                            $tsk_crn_upd=true; //exception case occured
                            
                            if( $js_upd_cls && $ins_jbs && $js_upd_avl && $jbs_rnd_upd && $tsk_crn_upd ){
                                //DB::commit();
                            }else{

                                $errorQuery   =     '';

                                if( !$js_upd_cls ){
                                    $errorQuery .=  ' '.$make_stage_completed.' ; '.PHP_EOL;
                                } 
                                if( !$ins_jbs ){
                                    $errorQuery .=  ' '.$create_next_stage_iteration.' ; '.PHP_EOL;
                                } 
                                if( !$js_upd_avl ){
                                    $errorQuery .=  ' '.$make_stage_available.' ; '.PHP_EOL;
                                } 
                                if( !$jbs_rnd_upd ){
                                    $errorQuery .=  ' '.$update_jb_rnd.' ; '.PHP_EOL;
                                } 
                                if( !$tsk_crn_upd ){
                                    $errorQuery .=  ' '.$tasklevelmetadata_query.' ; '.PHP_EOL;
                                }

                                throw new \Exception( $errorQuery );

                            }

                            $arrayMsg = array( 'status'=> '1'  ,  'Msg' => 'Success' , 'errMsg' => 'Successfully Rollbacked' );

                        }else{
                            
                            throw new \Exception( 'Invalid try, cross check the table entry...' );
                            
                        }
                        
                    }catch(\Exception $e){
                        
                        //DB::rollback();  
                        
                        $err_handle     =       new errorController();
                        $errorid        =       $err_handle->handleApplicationErrors( $e );   
                        
                        $arrayMsg['errorid'] =   $errorid;
                        $arrayMsg['reason'] =   $e->getMessage();
                        
                        return $arrayMsg;

                    }
                    
            }else{
                $arrayMsg['errMsg'] =   'Invalid jobstageid.';                
            }
            
        }
        
        return $arrayMsg;
        
    }
    
    public function semiAutomaticProcessHandling( $jbstgid = null , &$return_res = array() ){
        
        if( !is_null( $jbstgid ) ){
            
            $checkoutObj        =   new checkoutModel();
            $workflowPath       =   new workflowServerMapPathModel();
            $stageDetails       =   $checkoutObj->getStageInfo($jbstgid);
            $jbstg_obj          =   $stageDetails[0];
            
            $metaid             =   $jbstg_obj->METADATA_ID;
            $roundId            =   $jbstg_obj->ROUND_ID;
            $stageId            =   $jbstg_obj->STAGE_ID;
            $jobid              =   $jbstg_obj->JOB_ID;
            $jobid              =   $jbstg_obj->JOB_ID;
            
            $chapter_name       =   isset( $jbstg_obj->CHAPTER_NO ) ?  $jbstg_obj->CHAPTER_NO : '';
            $bookid             =   $jbstg_obj->BOOK_ID;
        
            //temprary code need to improve for semiautomatic now only caring pagination
            
            $manualpagestagid       =   \Config::get('dynamicConstant.STAGE_COLLEECTION.MANUAL_PAGINATION');
            $correctionEdiStgid     =   \Config::get('dynamicConstant.STAGE_COLLEECTION.CORRECTION_EDITING');
            $semiautocollect        =   \Config::get( 'dynamicConstant.SEMI_AUTO_STAGES' );
			$semiautocollect 		= array();
            $semistages             =   array_values($semiautocollect);
              
            if( $stageId == $manualpagestagid ){
               
                //prepare and post the meta into userwork directory
                $autopagination     =       new autoPageController();
                $optjson            =       '';
                
                $bookdata           =       jobModel::getjobInfodetails( $jobid );
                
                if( isset( $bookdata->APPLICATION ) ){  
                    
                    $application   =  strtolower( $bookdata->APPLICATION );
               
                    if( $application == '3b2' )
                        $inparr         =       array( 'platform' => '3B2' , 'autopageext' => '3d' , 'arttags' => 1  , 'location' => ''  , 'mode' => 'LocalPagination' , 'withprint' => 1 );
                    if( $application == 'indesign'  )
                        $inparr         =       array( 'platform' => 'ADOBE INDESIGN' , 'autopageext' => 'indd' , 'arttags' => 1  , 'location' => ''  , 'mode' => 'LocalPagination' , 'withprint' => 1 );

                    $optjson        =       json_encode( $inparr );
                    
                    $ret            =       $autopagination->startProcess( $jbstgid , $optjson );
                   
                    return $ret;
                }
            
            }else if( $stageId == $correctionEdiStgid ){
                
                $correctionEditorLaunchPath     =       \Config::get('dynamicConstant.CORRECTION_EDITING_LAUNCH');
                $round_arr                      =       \Config::get('constants.ROUND_NAME');
                $empid              =       \Session::get('users')['emp_id'];
                $cmn_obj            =       new CommonMethodsController();
                
                $pagObj             =       new autoPageController();
                $paging_collect     =       $pagObj->getPagingFileNameing(  $bookid , $chapter_name , $metaid); 
                extract( $paging_collect );
				
                $inp_rep_arr        =       array( 
                                                'BOOK_ID'       =>      $bookid ,   'ROUND_NAME'    =>      $roundId     ,
                                                '{BID}'         =>      $bookid ,   '{RID}' => $round_arr[$roundId]      ,
                                                '{EMPID}'       =>      $empid  ,   '{CID}'  => $chapter_name , 
                                                '{PAGING_FILENAMING}' =>    $pagingfilnaming 
                                            );
                
                
                $correctionEditorLaunchPath                 =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $correctionEditorLaunchPath );
                $return_res['correctionEditorSoftPath']     =       $correctionEditorLaunchPath;
                $return_res['correctionLaunch']             =       1;
                
            }else if( in_array( $stageId , $semistages ) ){
                
                $autoProcessObj     =       new autostageController();
                $getConfigInfo      =       $autoProcessObj->getAutoStageBgExecutionConfiguration( $jbstgid );
                
                if( !empty( $getConfigInfo ) ){
                    $autoStageList = $getConfigInfo;
                } 
                
                $nextAutoStageInfo         =       $autoStageList[$stageId];
                $wayofAutoProcess          =       strtolower( $nextAutoStageInfo['type'] );
                $execution_method_arr      =       explode( '@' , $nextAutoStageInfo['executable'] );
                $controllerPath            =       'App\\Http\\Controllers\\'.$execution_method_arr[0];                 
                $methodname                =       $execution_method_arr[1];
                //$optionalParams          =       null; //json input
             
                if(empty( $optionalParams ) ){
                    $autoResponse              =       app($controllerPath)->$methodname( $nextJobStageId );    
                }else{    
                    $autoResponse              =       app($controllerPath)->$methodname( $nextJobStageId , $optionalParams );                   
                }
		
            }
            
        }
        
    }
    
    
}

 
