<?php
namespace App\Http\Controllers\checkout;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\checkoutModel;
use App\Models\artcaterylogModel;
use App\Models\jobResource;
use App\Models\jobRound;
use App\Models\jobStage;
use App\Models\jobModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobInfoModel;
use App\Models\stageManager;
use App\Models\stageModel;
use App\Models\alfrescoCredentialModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\instructionLevelModel;
use App\Models\instructionModel;
use App\Models\instructionAcceptStatementModel;
use Illuminate\Http\Request;
use App\Models\jobWorkLogModel;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\Api\autostageController;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\workflow\workflowRuleController;
use App\Http\Controllers\dynamicConstantController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\production\movetoproductionController;
use App\Models\apiAutoPage;
use App\Models\workflowModel;

use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class stageManagerCustomController extends Controller
{   
	public $formSubmitedData;
    public function __construct() {
        parent::__construct();
	 $this->ownConstruction();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function ownConstruction(){
        $dynmicConstObj  =   new dynamicConstantController();
    }
   
    public function validateprocess(){
        $prQcStage      =  \Config::get('constants.STAGE_COLLEECTION.PR_QC'); 
        $ss['jobId']    = '6526';
        $ss['roundid']  = '120';
        $ss['stageid']  = $prQcStage;
        $dva= '{"checkin":0,"jobId":6526,"inputQuantity":10,"jbstgid":14952,"roundid":120,"stageid":1351,"metadataid":4814,"submitype":"checkout","levelid":1,"outputQuantity":10,"instID":[],"mandatorytype":[],"correctiontype":[],"typeoflevel":2}';
		
		$this->validationProcessCheck(json_decode($dva));
       // $this->validateBookTriggerInitiate((object)$ss);
        
    }
    public function validationProcessCheck($data){
        Log::useDailyFiles( storage_path().'/Api/bookmergesignal.log' );
                Log::info(json_encode($data));
        if($data->roundid == '119' || $data->roundid == '120' ){
            
            $prQcStage            =  \Config::get('constants.STAGE_COLLEECTION.PR_QC');
            $xmlQC                =  \Config::get('constants.STAGE_COLLEECTION.XML_QC');
        
            if($data->stageid  == $prQcStage) {
                $this->validateBookTriggerInitiate( $data );
            }
            
            if($data->stageid  == $xmlQC) {
                $this->validatePackageTriggerInitiate( $data );
            }
            
        }
        
    }
    
     public function validatePackageTriggerInitiate($cdata){
         $checkoutObj    =  new checkoutModel();
         $xmlQC                =  \Config::get('constants.STAGE_COLLEECTION.XML_QC');
         
         $package                =  \Config::get('constants.STAGE_COLLEECTION.PACKAGE');
        
            if($cdata->stageid  == $xmlQC) {
            $response           =  $checkoutObj->getStageCompletedForJob($cdata->jobId, $cdata->roundid, $cdata->stageid);
            
         
            $completedFlage     = 1;
            if(!empty($response)){
                
                foreach($response as $key => $sdata){
                    
                   if($sdata->STATUS  != '24' ){
                       $completedFlage  = 0;
                       break;
                   }
                }
				
               if($completedFlage == 1){ 
                   
                   $jobId   = $cdata->jobId;
                   $round    =   $cdata->roundid;
                   $jobinfoData    =   jobModel::getJobdetails($jobId);
                   $bookId         =   $jobinfoData->BOOK_ID;
                   $wherebookmeta  =   ['CHAPTER_NO'=>$bookId,'JOB_ID'=>$jobId,'UNIT_OF_MEASURE'=>\Config::get( 'constants.UNIT_OF_MEASURE')];
                   $existbookmeta  =   taskLevelMetadataModel::Active()->where($wherebookmeta)->first();
                   $masterid       =   \Config::get('constants.WORKFLOW.S600.MASTER_ID_BOOKBUILDING'); 
                   $statusW     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORPARALLEL' ); 
                   $metaid         =   $existbookmeta->METADATA_ID;
                   
                   $getStagesRec          =           DB::table( 'job_round as jr' )
                                               ->where('jr.JOB_ID'   , '=' , $jobId )
                                                ->where('jr.ROUND_ID'    , '=' , $round )
                                                ->where('jr.METADATA_ID' , '=' , $metaid )
                                                ->select()
                                                ->get(); 
                   
                    $jobroundId           =    $getStagesRec['0']->JOB_ROUND_ID;
                    $currentIteration     =    $getStagesRec['0']->CURRENT_ITERATION_ID;
                    $jobStage             =    $getStagesRec['0']->CURRENT_STAGE;
                    $status                 =    $getStagesRec['0']->STATUS;
                    
                    if($jobStage  == $package && $status  == $statusW ){
				//	 if($jobStage  == $package  ){
                        
                        $sql = "select *from job_stage as js where js.JOB_ROUND_ID = $jobroundId and js.STAGE_ID = $jobStage and js.ITERATION_ID = $currentIteration";
                        $getRec             =   DB::select( $sql );
        
                        if(count($getRec)>=1){
                         $stageDetails      =      $getRec['0'];
                         $nextJobStageId    =      $stageDetails->JOB_STAGE_ID;
                       
                         $updateStageParam       =       array( 'STATUS'=>'23');
                         $updateQry              =       DB::table('job_stage')
                                                                       ->where('JOB_STAGE_ID', $nextJobStageId )
                                                                       ->update( $updateStageParam );
                 
                        $jobRoundValue          =       array('STATUS'=>'23','CURRENT_STAGE' => $jobStage);
                        $updateQry              =       DB::table('job_round')
                                                        ->where('JOB_ROUND_ID', $jobroundId )
                                                        ->update( $jobRoundValue );
                        
                         $successfileresponse    =       app('App\Http\Controllers\Api\packageController')->startProcess($nextJobStageId);
                        
                         }
                    }else{
                        //not do any thing.
                    }
               }

                return true;
            }else{
                return false;
            }
        }
    }  
     
    
   // $data->jobId,$data->roundid,$data->stageid,$data->metadataid
    public function validateBookTriggerInitiate($cdata){
        
        $checkoutObj    =  new checkoutModel();
        $prQcStage      =  \Config::get('constants.STAGE_COLLEECTION.PR_QC'); 
        
            if($cdata->stageid  == $prQcStage) {
            $response           =  $checkoutObj->getStageCompletedForJob($cdata->jobId, $cdata->roundid, $cdata->stageid);
            
        
            $completedFlage     = 1;
            if(!empty($response)){
                
                foreach($response as $key => $sdata){
                    
                   if($sdata->STATUS  != '24' ){
                       $completedFlage  = 0;
                       break;
                   }
                }
             //   $completedFlage     = 1;
               if($completedFlage == 1){ 
                   
                    $this->triggerBookBuldingProcess($cdata);
               }

                return true;
            }else{
                return false;
            }
        
        }
    }
    
    public function test(){
        
        $bData['jobId'] = '6526';
        $bData['roundid'] = '120';
             
        $this->triggerBookBuldingProcess((object)$bData);
        
    }
    
    public function triggerBookBuldingProcess( $bData ){
        
      
      $stgMgCntrlr    =   new stageMangerController();
                
     //           $ret_status     =   $stgMgCntrlr->handlingAutoStages( 1370 , 13517 ); 
                
    // echo "<pre>";print_r($ret_status);exit;
    // exit;    
     $jobId         =   $bData->jobId;
     $round         =   $bData->roundid;
    // $stageId       =   1342;
    // $jbstageId     =   13341;
     //check job Stage are completed.
    // $metaid        =   '4802';
   //  $bookId        = '483071_1_En';
     $quanity       = '1';
     $duedate       = '2019-04-22 00:00:00';
     
     $stgMgCntrlr    =   new stageMangerController();
        /*
         $nextStageId    = '1370';
         $nextJobStageId  = '13910';
         $ret_status     =   $stgMgCntrlr->handlingAutoStages( $nextStageId , $nextJobStageId ); 

         echo "<pre>";print_r($ret_status);exit;
        */
     
      $jobinfoData    =   jobModel::getJobdetails($jobId);
      $bookId         =   $jobinfoData->BOOK_ID;
     
     $wherebookmeta  =   ['CHAPTER_NO'=>$bookId,'JOB_ID'=>$jobId,'UNIT_OF_MEASURE'=>\Config::get( 'constants.UNIT_OF_MEASURE')];
     
   
     $existbookmeta  =   taskLevelMetadataModel::Active()->where($wherebookmeta)->first();
     
     if($round == '119')
        $masterid       =   \Config::get('constants.WORKFLOW.S600.MASTER_ID_BOOKBUILDING');
     
     if($round == '120')
        $masterid       =   \Config::get('constants.WORKFLOW.S650.MASTER_ID_BOOKBUILDING');
    
     if(empty($existbookmeta)){
      
        $status_in_progress              =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.JOB_LEVEL.JOB_INPROGRESS');
        $input_arr['job_id']             =       $jobId;
        $input_arr['chapter_no']         =       $bookId;
        $input_arr['chapter_name']       =       'BWFBook';
        $input_arr['status_enum_id']     =       $status_in_progress;
        $input_arr['unit_of_measure']    =       Config::get( 'constants.UNIT_OF_MEASURE');
        $metaid                          =       DB::table( 'task_level_metadata' )
                                                                 ->insertGetId( $input_arr );
        if(!empty($metaid)){
           DB::insert( 'insert into metadata_info ( METADATA_ID , WORKFLOW_TYPE ) values ( '.$metaid.' , '.$masterid.' )'  );
        }
     }else{
            $metaid                         =   $existbookmeta->METADATA_ID;
     }
     
         $getStagesRec          =           DB::table( 'job_round as jr' )
                                               ->where('jr.JOB_ID'   , '=' , $jobId )
                                                ->where('jr.ROUND_ID'    , '=' , $round )
                                                ->where('jr.METADATA_ID' , '=' , $metaid )
                                                ->select()
                                                ->get();
         
         
        
         if(count($getStagesRec) != 0){
             
             $jobroundId           =    $getStagesRec['0']->JOB_ROUND_ID;
             $currentIteration     =    $getStagesRec['0']->CURRENT_ITERATION_ID;
             $jobStage             =    $getStagesRec['0']->CURRENT_STAGE;
             
             $getjobStagesRec      =           DB::table( 'job_stage as js' )
                                                ->where('js.JOB_ROUND_ID'   , '=' , $jobroundId )
                                                ->where('js.ITERATION_ID'    , '=' , $currentIteration )
                                                 ->where('js.STAGE_ID' , '=' , $jobStage )
                                                 ->select()
                                                 ->get();
             
             $nextJobStageId       =    $getjobStagesRec['0']->JOB_STAGE_ID;
             $nextStageId          =    $getjobStagesRec['0']->STAGE_ID;
             $jobRoundId           =    $getjobStagesRec['0']->JOB_ROUND_ID;
           
            $updateStageParam       =   array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $quanity);
            $updateQry              =   DB::table('job_stage')
                                        ->where('JOB_STAGE_ID', $nextJobStageId )
                                        ->update( $updateStageParam );

            $jobRoundValue1         =   array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
            $updateQry              =   DB::table('job_round')
                                        ->where('JOB_ROUND_ID', $jobRoundId )
                                        ->update( $jobRoundValue1 );

            $jobRoundValue2           =       array( 'CURRENT_STAGE' => $nextStageId , 'CURRENT_ROUND' => $round, 'CHAPTER_NAME' =>'BWFBook' );
            $updateQry                =       DB::table('task_level_metadata')
                                                        ->where( 'METADATA_ID', $metaid )
                                                        ->update( $jobRoundValue2 );
               

            $stgMgCntrlr    =   new stageMangerController();
            $ret_status     =   $stgMgCntrlr->handlingAutoStages( $nextStageId , $nextJobStageId ); 
             
            return true;
             
         }
      
       
      $wrftype        =           0;
          
      $wrkflw_mdl     =           new workflowModel();
      $wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
      $workflowid     =           $wfdata->WORKFLOW_ID;
      
      $mvtoProd       =           new movetoproductionController();
      $response_      =           $mvtoProd->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype  );
     
      $jbstgObj       =        new jobStage();
     
      $getCurrnt_stage =    $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 27 );						
     
        if( count( $getCurrnt_stage ) ){

            $jbstgInfo		=		$getCurrnt_stage[0];
            $job_round_id	=		$jbstgInfo->JOB_ROUND_ID;
            $job_stage_id	=		$jbstgInfo->JOB_STAGE_ID;

            $checkoutObj            =       new checkoutModel();
            $stageDetails           =       $checkoutObj->getStageInfo($job_stage_id);
            $stageData              =	$stageDetails[0];

            $jobRoundId             =       $stageData->JOB_ROUND_ID;
            $roundId                =       $stageData->ROUND_ID;
            $stageSequence          =       $stageData->STAGE_SEQ;
            $workflowId             =       $stageData->WORKFLOW_ID;  
            $iteration              =       $stageData->ITERATION_ID;
            $jobId                  =       $stageData->JOB_ID;
            $curjobstgid            =       $stageData->JOB_STAGE_ID;        
            $outputQuantity         =   	$stageData->OUTPUT_QUANTITY;
            $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);

            if(!empty($nexstageDetails)){

                    $nextJobStageId 	=   $nexstageDetails->JOB_STAGE_ID;
                    $nextStageId        =   $nexstageDetails->STAGE_ID;
                    $userDefData    	=   taskLevelUserdefinedWorkflow::getUserDefineStageDetails( $jobId, $workflowId , $round , $nextStageId );
                    $stageType      	=   $userDefData->IS_AUTO;

                    $updateStageParam       =   array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $outputQuantity);
                    $updateQry              =   DB::table('job_stage')
                                                                            ->where('JOB_STAGE_ID', $nextJobStageId )
                                                                            ->update( $updateStageParam );

                    $jobRoundValue1         =   array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
                    $updateQry              =   DB::table('job_round')
                                                                            ->where('JOB_ROUND_ID', $jobRoundId )
                                                                            ->update( $jobRoundValue1 );

                $jobRoundValue2           =       array( 'CURRENT_STAGE' => $nextStageId , 'CURRENT_ROUND' => $round );
                $updateQry                =       DB::table('task_level_metadata')
                                                            ->where( 'METADATA_ID', $metaid )
                                                            ->update( $jobRoundValue2 );

                $stgMgCntrlr    =   new stageMangerController();
               
                $ret_status     =   $stgMgCntrlr->handlingAutoStages( $nextStageId , $nextJobStageId ); 
                
                return true;
                
                //$returns        =       projectModel::skipStage( 1 , $job_stage_id, $quanity, $job_round_id , 1  );
            }

        }
      
    }
    
   
}

 
