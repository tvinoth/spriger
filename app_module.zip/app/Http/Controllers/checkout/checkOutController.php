<?php
namespace App\Http\Controllers\checkout;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\checkoutModel;
use App\Models\customizationModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\jobResource;
use App\Models\jobRound;
use App\Models\instructionModel;

use App\Models\jobStage;
use App\Models\jobModel;
use App\Models\errorTypeEnum;
use App\Models\fileHandler;
use App\Models\roundModel;
use App\Models\alfrescoLogModel;
use Illuminate\Http\Request;
use App\Models\jobWorkLogModel;
use App\Models\workflowModel;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\workflow\workflowRuleController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\production\movetoproductionController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Models\workflowServerMapPathModel;
use App\Models\apiBookMergeModel;
use App\Models\jobsheetViewpathModel;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class checkOutController extends Controller
{   
    //Parameter would be jobid  , metaid , round id ,  jobstageid.
    //[jobid] => 6302     , [metaid] => 2631 , [round] => 116,  [stageId] => 1296 ,  [jobstageid] => 23 , [artMetaid] => 

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function checkOutProcess( Request $request ){
    
        $postData    =      $request->all(); 
        extract( $postData );
        $response                   =       $this->notfoundResponse;
        $user_id                    =       \Session::get('users')['user_id'];
        $errMsg                     =       '';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );
        
       try{

            $jbr_obj                =       new jobResource();
            $stage_obj              =       new jobStage();
            $round_obj              =       new jobRound();
            $checkout_m             =       new checkoutModel();
            $isArtFlag              =       0;
            
            $multitry               =       $jbr_obj->getOtherJobResourceEntryExist( $user_id , $jobstageid );
            
            $resourceData           =       $jbr_obj->getJobResourceEntryByJobStageId( $jobstageid );
            $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $jobstageid );
            
            if( !empty( $multitry ) ){
                
                $jbstgid        =       $multitry->JOB_STAGE_ID;
                
                $checkout_Data  =       $checkout_m->getStageInfo( $jbstgid );
                $chap_name  =   $jobid  =   $book_id = "";
                if( !empty( $checkout_Data ) ){
                $chap_name      =       $checkout_Data[0]->CHAPTER_NO;
                $jobid          =       $checkout_Data[0]->JOB_ID;
                }
                
                $job_obj        =       new jobModel();
                $job_obj_info   =       $job_obj->getJobdetails( $jobid );
                $book_id        =       (isset($job_obj_info->BOOK_ID)?$job_obj_info->BOOK_ID:"");
                $response['errMsg']     =       'You have other '.strtolower( $metanaming ).' checked out entry for. ['.$chap_name.'] in '.$book_id;
                
            }else if( empty( $resourceData ) && $isArtFlag ){

                //Batch insert need to handle here.

            }else if( empty( $resourceData ) ){
                //Custom data feed for insert start 

                if( isset( $assign_to ) ){
                    $postData['userTo']          =       $assign_to;
                }else{
                    $postData['userTo']          =       $user_id;
                }

                $postData['userBy']              =       $user_id;
                $postData['is_art']              =       $isArtFlag;
                $postData['time']                =       date('Y-m-d H:i:s');//Carbon::now();
                $postData['team_id']             =       \Session::get('users')['team_id'];

            //End Custom feed

              DB::beginTransaction();
              $returns_jbre    =     $jbr_obj->buildInputAndinsertNewRecord( $postData );    
              if( $returns_jbre == 2 ){
                
                //update jobstage to inprogress : 23
                $returns_jbs      =     $stage_obj->updateIfExist( array( 'STATUS' => 23 ) , $jobstageid );
                $job_round_id     =     $jobStage_rec->JOB_ROUND_ID;
                //update round to inprogress : 23 
                $returns_jbr      =     $round_obj->updateIfExist( array( 'STATUS' => 23 ) , $job_round_id );
                
              }
              
              if( $returns_jbre && $returns_jbr ){
                
                DB::commit();
                //insert round stage details and insert user stage details
                $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobid,$round,'insert',$jobstageid);
                $response['status']     =       1;
                $response['Msg']        =       'Success';
                $response['errMsg']     =       'Success';
               
              }else{                  
                    DB::rollback();                
                $response['errMsg']     =       $response['reason']     =       ' Manual clearance not happened proberly';
              }
              
            }else if( !empty( $resourceData ) && $resourceData->CREATED_BY == $user_id ){
                $response['status']     =       1;
                $response['Msg']        =       'Success';
                $response['errMsg']     =       'Success';
                
            }else if( !empty( $resourceData ) && $resourceData->CREATED_BY !== $user_id ){
                
                $response               =       $this->failedResponse;
                $response['errMsg']     =       'This '.$metanaming.' is already checkout by other user';
                
            }else{
                $response               =       $this->failedResponse;
                $response['errMsg']     =       'oops ! something went wrong.'.$errMsg;
            }
            
        }catch( \Exception $e ){
             
           $response['errMsg']  =       $e->getMessage();
           $response['reason']  =       $e->getTraceAsString();
        
           return response()->json( $response , 401 );
           
        }
        
        return response()->json( $response , 200 );
    }
    
    public function batchCheckoutProcess( Request $request ){
        
        $inputCollection            =       array();
        $response                   =       $this->notfoundResponse;
        $response['errMsg']         =       'Failed to Checkout due to resource allocated.';
        
        $user_id                    =       \Session::get('users')['user_id'];
        
        $errMsg                     =       '';
        $metanaming                 =       \Config::get( 'constants.NAMING_CONVENTIONS.METADATA_ENTRY_NAME' );
        $time                       =       date("Y-m-d H:i:s");    
        
        try{
           
        if( null !== ( $request->input('batch') ) ){
            
            $inputCollection        =       $request->input('batch');
           
            $isArtFlag              =       1;
            $jbr_obj                =       new jobResource();
            $stage_obj              =       new jobStage();
            $round_obj              =       new jobRound();
            $checkout_m             =       new checkoutModel();
            
            $error_case             =       true;
            
            DB::beginTransaction();
            
            //insert batch table record
            $batch_id       =       DB::table('batch')->insertGetId( array(   'CREATED_DATE' => $time , 'CREATED_BY' => $user_id ));
            $response['params']['batchid']      =       $batch_id;
            
            foreach( $inputCollection as $key => $postData ){
                extract( $postData );
                $resourceData           =       $jbr_obj->getJobResourceEntryByJobStageId( $jobstageid );
                $jobStage_rec           =       $stage_obj->getJobStageInfoByJobStageId( $jobstageid );
                $returns_jbre           =       false;
                
                if( empty( $resourceData ) ){
                    
                    $postData['userTo']             =       $user_id;
                    $postData['batchid']            =       $batch_id;
                    $postData['userBy']              =       $user_id;
                    $postData['METADATA_STATUS']     =       $artMetaid;   
                    $postData['artMetaid']           =       $artMetaid;                    
                    $postData['is_art']              =       $isArtFlag;
                    $postData['time']                =       date('Y-m-d H:i:s');
                    $postData['team_id']             =       \Session::get('users')['team_id'];
                   
                    $returns_jbre                    =       $jbr_obj->buildInputAndinsertNewRecord( $postData );   
                    
                }
               
                if( $returns_jbre == 2 ){

                  //update jobstage to inprogress : 23
                  $returns_jbs      =     $stage_obj->updateIfExist( array( 'STATUS' => 23 ) , $jobstageid );
                  $job_round_id     =     $jobStage_rec->JOB_ROUND_ID;
                  //update round to inprogress : 23 
                  $returns_jbr      =     $round_obj->updateIfExist( array( 'STATUS' => 23 ) , $job_round_id );

                }else{
                    $error_case =   false;
                }
            }
            
            if( $error_case ){
                DB::commit();
                $response   =   $this->successResponse;
                $response['params']['batchid']      =       $batch_id;  
               
            }else{
                DB::rollback();
            }
            
        }else{
            
            $response['errMsg'] =   'Invalid try.';
           
        }
        
        }catch( Exception $ex ){
            $response['errMsg'] =   $ex->getMessage();
        }
        
        return response()->json( $response );
         
    }
    
    public function checkInDisplay( Request $request, $jsStageId ,$batch='' ){
        $checkoutDetails    =        [];
        $data               =        $request->All();
        $checkOutExist      =        0;
        $checkoutObj        =        new checkoutModel();
        $jStageId           =        array();
        $isArt              =        0;
        $batchId            =        0;
        $allartmetaid       =        ''; 
        $ruleRejectType     =       \Config::get( 'constants.RULE_IF_REJECT' );
        
        $this->displayMenuName(Config::get('menuconstants.MENU.PRODUCTION_BIN'),$checkoutDetails);
        
        /** Get stageDetails by batchId **/
        if($batch == 'batch'){            
            $isArt                  =   1;
            $batchId                =   $jsStageId;
            $jobstageDetails        =   $checkoutObj->getJobStageIdByBatch($batchId);
           
            $checkoutDetails['batchId']       = $batchId;
            $metadataStatusId = '';
            
            foreach($jobstageDetails as $key=>$value){
                $jStageId[]         =   $value->JOB_STAGE_ID;
                $metadataStatusId   =   $value->METADATA_STATUS;
            } 
            
           if(!empty($metadataStatusId)){
            $checkoutDetails['metadataStatusId']  = $metadataStatusId;
           }
           
        }else{
            $jStageId[]             =   $jsStageId;
            $checkoutDetails['metadataStatusId'] = '';
        }
        
        if( empty( $jStageId ) ){            
            return redirect('/projectbin?cntlr=projectBin&statusCode=3001');
        }
        
       
        $jsId                            =   implode(',',$jStageId);
     
        $workflowPath                    =   new workflowServerMapPathModel();
        $remarks_collect                 =   array();
       
        if($isArt == 1){
            $stageInfoSingle  = $stageInfo                       =   $checkoutObj->getArtStageInfo_old($jsId);
            $stageInfo2                                          =   $checkoutObj->getArtStageInfo($jsId);
           
            $artmetaid              =   [];
            
            if(count($stageInfo2)>=1){
              
                foreach($stageInfo2 as $value){
                    $artmetaid[]                        =   $value->ART_METADATA_ID;
                    $remarks_collect[$value->FILE_NAME] =   $value->REMARKS;
                }
                
            }
            
            $allartmetaid   =   implode(',',$artmetaid);
            $stageInfo = $stageInfo2;
            
        }else{
            
            $stageInfo                       =   $checkoutObj->getStageInfo($jsId);
           
            $checkoutWorklog                 =   $checkoutObj->getWorklogLatestRecord($jsId);
            if(!empty($checkoutWorklog)&& $stageInfo['0']->IS_PARTIAL == '1'){
                $stageInfo['0']->INPUT_QUANTITY =   $checkoutWorklog->PENDING_QUANTITY;
            }
           
            if( isset( $stageInfo[0]->REMARKS )){
                $remarks_collect        =   array( $stageInfo[0]->REMARKS );
            }
        }
        
        $checkoutDetails['isArt']        =   $isArt;
        $checkoutDetails['stageDetails'] =   $stageInfo;
        
        $getWrokLog             =   $checkoutObj->getWorklogInsertExist($jStageId);
		
		
        
        if(count($getWrokLog)== 0){
             if($isArt == 1){
                 
                $checkoutInfo           =   $this->manageWorklog($stageInfoSingle,$batchId);
              }else{
                 
                $checkoutInfo           =   $this->manageWorklog($stageInfo,$batchId);  
              }
             $checkOutExist          =   '1';
        }
        
        $checkoutDetails['checkoutExist']   = $checkOutExist;
        $checkoutDetails['jobID']       =   $jsId;
        $checkoutDetails['job_id']      =   $jsId;
        $checkoutDetails['jobstgid']      =   $jsId;
        
        $metaid  =  $checkoutDetails['meta_id']     =  (count($stageInfo)>=1?$stageInfo[0]->METADATA_ID:'');
        $chapterno      =   "";
        
        if(count($stageInfo)>=1){
            $jsStageId  =   $stageInfo[0]->JOB_STAGE_ID;
            $chapterno  =   $stageInfo[0]->CHAPTER_NO;
        }
        
        $serverMapPath      =   $workflowPath->getWorkflowServerMapPath($jsStageId);
        $ruleData = array();
        $ruleData           =   $this->getWorkFlowRuleByStages($jsStageId);
    
        $serverworkMapPath  =   "";
        $openworkMapPath    =   "";
        $closeworkMapPath   =   "";
        $openrawMapPath     =   "";
        $artworkupopenpath  =   '';
        $artworkuppathwithHost= '';
        
        if($serverMapPath['status'] == 1){
            
            $serverworkMapPath      =   $serverMapPath['detail']['work'];
            $openworkMapPath        =   $serverMapPath['detail']['opendrive'];
            $closeworkMapPath       =   $serverMapPath['detail']['closedrive'];
            $openrawMapPath         =   $serverMapPath['detail']['rawfile'];
            $artworkupopenpath      =   $serverMapPath['detail']['artworkupopenpath'];
            $artworkuppathwithHost  =   $serverMapPath['detail']['artworkuppathwithHost'];
            
        }
		if(strpos($openrawMapPath,'<>')){
			$splitusercredentials   =   explode('<>',$openrawMapPath);
			$openrawMapPath              =   (isset($splitusercredentials[0])?$splitusercredentials[0]:'');
		}
        
		$checkoutDetails['destlocpath']  	=   $serverMapPath['detail']['dest'];
        $checkoutDetails['serverpath']      =       $serverworkMapPath;
        $checkoutDetails['sourcepath']      =       (isset($serverMapPath['detail']['opensrcpath'])?$serverMapPath['detail']['opensrcpath']:$openworkMapPath);
        $checkoutDetails['getsourcepath']   =       (isset($serverMapPath['detail']['src'])?$serverMapPath['detail']['src']:$openworkMapPath);
        $checkoutDetails['openpath']        =       $openworkMapPath;
        $checkoutDetails['closepath']       =       (!empty($closeworkMapPath)?$closeworkMapPath:$closeworkMapPath);
        $checkoutDetails['rawpath']         =       $openrawMapPath;
        $checkoutDetails['workupPath']      =       $artworkupopenpath;
        $checkoutDetails['artworkuppathwithHost']  =   $artworkuppathwithHost;
        
        $checkoutDetails['serverPathDetails']   =   $serverMapPath;
        $checkoutDetails['pageTitle']           =   'CheckOut';
        $checkoutDetails['pageName']            =   'CheckOut';
        $checkoutDetails['batchId']             =   $batchId;
        
        $bookid     =   $checkoutDetails['bookid']      =   (count($stageInfo)>=1?$stageInfo[0]->BOOK_ID:'');
        $jobid      =   $checkoutDetails['jobID']       =   (count($stageInfo)>=1?$stageInfo[0]->JOB_ID:'');
        $roundid    =   $checkoutDetails['roundID']     =   (count($stageInfo)>=1?$stageInfo[0]->ROUND_ID:'');
        $stageId    =   $checkoutDetails['stageId']     =   (count($stageInfo)>=1?$stageInfo[0]->STAGE_ID:'');
        $stageMasterId    =   $checkoutDetails['workflowMasterId']     =   (count($stageInfo)>=1?$stageInfo[0]->WORKFLOW_MASTER_ID:'');
        
        $checkoutDetails['isRej']       =   ( $checkoutDetails['stageId'] == 1307 ) ? true : false;
        $checkoutDetails['allartmetaid']=   $allartmetaid;
        $checkoutDetails['roundId']     =   $roundid;
        $checkoutDetails['RuleisRej']           =   '';
        $checkoutDetails['RuleData']            =   ''; 
        $checkoutDetails['RuleRejectData']      =   '';
        $checkoutDetails['currentuserid']       =   Session::get('users')['user_id'];
        $checkoutDetails['currentuserroleid']   =   Session::get('users')['role_id'];
        $checkoutDetails['observeXmlFlag']      =   false;
        
        $tsklvlMetaObj          =       new taskLevelMetadataModel();
        $completedCheckStage    =       \Config::get( 'constants.STAGE_COLLEECTION.PR_QC' );
        $s600workflowID         =       \Config::get( 'constants.WORKFLOW.S600' );
        
        $countForobservexml     =       $tsklvlMetaObj->getAllOthersJobChaptersCompleted( $jobid , $metaid , $roundid , $completedCheckStage );
        
        $wherealfresco          =   ["JOB_ID"=>$jobid,"METADATA_ID"=>$checkoutDetails['meta_id'],"STAGE_ID"=>$stageId,"MODE"=>1];
        $checkexistalfresco     =   alfrescoLogModel::Active()->where($wherealfresco)->orderBy('ID','desc')->first();
        $checkoutDetails['alfresco']    =   ($checkexistalfresco  !=  null?$checkexistalfresco:'');
        
        if( !count( $countForobservexml ) )
          $checkoutDetails['observeXmlFlag']  =   true;
         
         
        
        
         $checkoutDetails['bookMerge']  =   false;
         $checkoutDetails['bookMergeStatus']  =  0;
         $reviewStage    =       \Config::get( 'constants.STAGE_COLLEECTION.BOOK_BUILDING_REVIEW' );
         
         if( $reviewStage == $stageId && in_array($stageMasterId,$s600workflowID)){
             $checkoutDetails['bookMerge']  =   true;
             $bookObj                       =    new apiBookMergeModel();
             $bookDetails                   =    $bookObj->getBookMergestatus($jobid);
           
             if(!empty($bookDetails)){
                 $checkoutDetails['bookMergeStatus']    =   $bookDetails->STATUS;
             }
         }
         
              
         if(!empty($ruleData) && isset($ruleData[$ruleRejectType]->GOTO_STAGE_ID)){
            $checkoutDetails['RuleisRej']      =  $ruleData[$ruleRejectType]->GOTO_STAGE_ID ; 
            $checkoutDetails['RuleData']       =  $ruleData; 
            }
        
            if(array_key_exists($ruleRejectType,$ruleData)){
              $checkoutDetails['RuleisRej']            =  $ruleData[$ruleRejectType]->GOTO_STAGE_ID ;
              $checkoutDetails['RuleRejectData']       =  $ruleData[$ruleRejectType] ;  
            }
        $checkoutDetails['bookMerge']  =   true;
       
        $jb_object                          =       jobModel::getJobdetails( $jobid );
        $checkoutDetails['remarks_arr']     =       $remarks_collect;
        $checkoutDetails['jb_obj']          =       $jb_object;
        
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
		
        if( empty( $chapterno2 ) ){
            $chapterno2     =       ucwords( strtolower( $chapterno  ) );
        }
        
        $filename           =        $chapterno.'@'.$bookid.'.xml';
       
        if( strpos( strtoupper( $chapterno ) , 'CHAPTER' ) >= 0 ){
            $filename       =       $chapterno2.'@'.$bookid.'.xml';
        }
        
        if( strpos( strtoupper( $chapterno ) , 'CHAPTER' ) == false ){
            
            $chapterno          =        str_replace( '_' , '' , ucwords( strtolower( $chapterno ) ) );
            $chapterno          =        str_replace( 'Chapter' , '' , ucwords( strtolower( $chapterno ) ) );
            $filename           =        $chapterno.'@'.$bookid.'.xml';
            
        }
        
        $checkoutDetails['metafilename']        =       $filename;
        $checkoutDetails['remarks_arr']         =       $remarks_collect;
        $checkoutDetails['jobsheetoptions']     =       roundModel::Active()->where('ID','<=',$checkoutDetails['roundID'])->get();
        //$fileStatus                           =       $this->fileMoveMent($serverMapPath);
        $checkoutDetails['prQcStageId']         =       \Config::get( 'constants.STAGE_COLLEECTION.PR_QC' );
        
        $cmn_obj                            =   new CommonMethodsController();
        $titleacronym                       =   (isset($jb_object->JOURNAL_ACRONYM)?$jb_object->JOURNAL_ACRONYM:'');
        $queriesurl                         =   Config::get( 'constants.QMS_QUERIES_URL')."?TItleAcronym=".$titleacronym."&ChapterNo=".$chapterno;
        $getqueriescount                    =   $cmn_obj->getcUrlExecution($queriesurl);
        $checkoutDetails['queriescount']    =   0;
        if(is_array($getqueriescount) && isset($getqueriescount[0])){
            $checkoutDetails['queriescount']=   $getqueriescount[0];
        }
        
       /* if(isset($checkoutDetails['serverPathDetails']['status']) && $checkoutDetails['serverPathDetails']['status']    ==  0){
            return redirect()->back();
        }*/
       // $checkoutDetails['jobid']           =   0; 
        
       //$previousRound   =    app('App\Http\Controllers\Api\JsCompareController')->getPreviousStage($checkoutDetails['roundID']);
       $roundList      =    \Config::get( 'constants.ROUND_NAME' );
	   $getlocationftp = productionLocationModel::doGetLocationname($jobid);
		$ftpObj = \Storage::createFtpDriver([
                    'host' => $getlocationftp->FTP_HOST,
                    'username' => $getlocationftp->FTP_USER_NAME,
                    'password' => Crypt::decryptString($getlocationftp->FTP_PASSWORD),// 
                   'timeout' => '30',
        ]);
	   
	    $revisedObj   =  new jobrevisedController();
		$cmn_obj = new CommonMethodsController();  
        $wheredata = ['ROUND_ID' => $checkoutDetails['roundID']];
        $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
		
		$jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                    
		$inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $roundList[$checkoutDetails['roundID']]);

		$serverDir = $prepared_path =$cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
		
		$serverDirFiles = $ftpObj->allFiles($serverDir);
	
	   
		$jobsheetpath  =   $revisedObj->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
		//echo $jobsheetpath;exit;
		$jobsheetpath        =   str_replace( '//' , '\\'  , $jobsheetpath );
		$checkoutDetails['jspath']  = $jobsheetpath;
		$sessionUser        =       \Session::get('users');  
		
		if($sessionUser['role_id'] == 1){
			$rolename  = 'CopyEditors';
		}else{
			
			$rolename  = 'ProjectManager';
		}
		
		
        if(!empty($previousRound)){
           $jcStage                 =   $roundList[$checkoutDetails['roundID']].'-'.$roundList[$previousRound];
        }else{
            $jcStage                 =   $roundList[$checkoutDetails['roundID']];
        }
	$checkoutDetails['jRole']  = $rolename;
        $checkoutDetails['jcstage']  = $jcStage;
        
        return view('checkout.checkout')->with($checkoutDetails);
        
    }
    
    public function openSourcePath(Request $request) {
        try {

            $validation = Validator::make($request->all(), [
                        'filePath' => 'required',
                        'jobId' => 'required',
                        'metadataId' => 'required|numeric',
                        'Chapter' => 'required',
						'type'=>'required'
            ]);
            
            $response   =   $this->notfoundResponse;
            
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId = $request->input('jobId');
            $metaid = $request->input('metadataId');
            $filepath = $request->input('filePath');
            $Chapter = $request->input('Chapter');
            $type = $request->input('type');
            
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            if($getlocationftp ==   null){
                $getlocationftp = productionLocationModel::doGetLocationnameByDefault();
            }
            $bookdetaills = jobModel::where('JOB_ID', $jobId)->first();
            
            if (count($getlocationftp) >= 1 && count($bookdetaills) >= 1 ) {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                
                $ftpObj = \Storage::createFtpDriver([
                                'host' => $hostserver,
                                'username' => $hostusername,
                                'password' => $hostpassword,
                                'port' => '21',
                                'timeout' => '30',
                    ]);
                
                $cmn_obj = new CommonMethodsController();              
				
				if($checkrootdirworkpath	=	strpos($filepath,Config::get('serverconstants.FILE_SERVER_FTP_PATH'))){
					$filepath 	=	'/'.substr($filepath,$checkrootdirworkpath,strlen($filepath));
				}
				
                $checkDirFiles = $ftpObj->allFiles($filepath);
                if(count($checkDirFiles) >= 1) {
                    
                    $userworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                    $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                    $getuserid  =   $this->empId;
                    $crd = "ftp://$hostusername:$hostpassword@";
                    $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $srcfile     =   $crd . $hostserver . '/' . $filepath;
					if($type == "RAW"){
						$desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.Config::get('constants.RAW_PATH');
						$open_path 	=   $hostserver.$ftp_root_dir.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.Config::get('constants.RAW_PATH');	
					}else{
                    $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$Chapter;
                    $open_path     =   $hostserver.$ftp_root_dir.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$Chapter;
					}
                    
                    $sourcepath     =   $crd . $hostserver . $filepath;
                    $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                    $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                
                    $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                    
                    if (in_array('failed', $response_copy)) {
                        foreach ($response_copy as $key => $value) {
                            if ($value == 'success') {
                                unset($response_copy[$key]);
                            }
                        }
                        $response_copy = array('status' => 'failed', $response_copy);
                    } else {
                        $response_copy = array('status' => 'success', $response_copy);
                    }
                
                    if ($response_copy['status'] == 'success') {

                        $postdata = [];
                        $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                        $postdata['system_ip'] = $request->ip();
                        $postdata['method_name'] = "doOpenDriveServer";
                        $postdata['processname'] = "checkout";
                        $insertfilehandler = fileHandler::insertNew($postdata);

                        if ($insertfilehandler) {
                            $response   =   $this->successResponse;
                            $response['errMsg'] = 'File open initialized..';
                            $response['rmID'] = $insertfilehandler;
                            return response()->json($response);
                        }
                    }
                    $response   =   $this->fileNotCopiedResponse;
                    return response()->json($response);
                }
                $response   =   $this->nofileResponse;
                return response()->json($response);
                
            }
            $response   =   $this->locationNotFoundResponse;
            return response()->json($response);
        } catch (\Exception $e) {
            $response   =   $this->locationNotFoundResponse;
            return response()->json($response);
        }
    }
    
    public function openFolderDrive(Request $request) {
        try {

            $validation = Validator::make($request->all(), [
                        'filePath' => 'required'
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $filepath = $request->input('filePath');
            if(strpos($filepath,"<>")){
                $splitusercredentials   =   explode('<>',$filepath);
                $splitip                =   explode('/',$filepath,2);
                $splitpath              =   (isset($splitusercredentials[0])?$splitusercredentials[0]:'');
				if($checkrootdirworkpath	=	strpos($splitpath,Config::get('serverconstants.FILE_SERVER_FTP_PATH'))){
					$splitpath 	=	substr($splitpath,$checkrootdirworkpath,strlen($splitpath));
				}
                
                $ftpObj                 =   \Storage::createFtpDriver([
                                                    'host' => (isset($splitip[0])?$splitip[0]:''),
                                                    'username' => (isset($splitusercredentials[1])?$splitusercredentials[1]:''),
                                                    'password' => (isset($splitusercredentials[2])?$splitusercredentials[2]:''),
                                                    'port' => '21',
                                                    'timeout' => '30',
                                                ]);
                //check exist path has or not
                $checkDirFiles  =   $ftpObj->has($splitpath);
                if(empty($checkDirFiles)){
                    $createDirFiles    =   $ftpObj->makeDirectory($splitpath,0777);
                }
                
                $response   =   $this->successResponse;
                $response['path']   =   $filepath;
                return response()->json($response);
            }
            $response   =   $this->nofileResponse;
            $response['errMsg']     =   'Invalid file path !';
            return response()->json($response);
        } catch (\Exception $e) {
            $response   =   $this->locationNotFoundResponse;
            return response()->json($response);
        }
    }
    
    public static function manageWorklog($stageDetails,$batchId) {
         
        $worklogInsert      =       array();
        $time               =       date('Y-m-d H:i:s');
        $sessionUser        =       \Session::get('users')['user_id'];  
        $teamDetail         =       \Session::get('users')['team_id'];
        $assignTeams        =        explode(',',$teamDetail);
        $team               =     $assignTeams['0'];
       
        $worklogdata                             =   array();
        $stage_obj              =       new jobStage();
	
        
        foreach($stageDetails as $key =>$stageInfo){
            $worklogInsert['JOB_STAGE_ID']           =   $stageInfo->JOB_STAGE_ID; 
            $worklogInsert['BATCH_ID']               =   $batchId; 
            $worklogInsert['CHECK_OUT']              =   $time; 
            $worklogInsert['INPUT_QUANTITY']         =   $stageInfo->INPUT_QUANTITY;
            $worklogInsert['DONE_BY']                =   $sessionUser;
            $worklogInsert['TEAM_ID']                =   $team;
            $worklogdata[]                           =  $worklogInsert;
           
            $returns_jbs                            =     $stage_obj->updateIfExist( array( 'CHECK_OUT' => $time ) , $stageInfo->JOB_STAGE_ID );
            
        }
        
        $jobInfoId                               =   DB::table('job_work_log')->insert( $worklogdata );
        
        return $jobInfoId;
        
    }
    
    public static function checkoutfileCopy(Request $request){
        
        $data                          =     json_decode($request->getContent());
        $checkoutObj                  =     new checkoutModel();
        $bookLevelProcess             =     0;
        $driveUsername                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_USERNAME' );
        $drivePassword                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_PASSWORD' );
        $drivepath                    =       \Config::get( 'serverconstants.DRIVE_FILE_SERVER_PATH' );
        $driveRootpath                =       \Config::get( 'serverconstants.DRIVE_FILE_SERVER_ROOT_PATH' );
        $indexingProcess              =       \Config::get( 'constants.STAGE_COLLEECTION.INDEXING' );
        $fileResponse       =       array();
        $fileResponse['sourcenotexist']     =   0;
        $fileResponse['errMsg']             =   "No data found";
        if(!empty($data->jobStageId)){
            
            $workflowPath                       =   new workflowServerMapPathModel();
            $serverMapPath                      =   $workflowPath->getWorkflowServerMapPath($data->jobStageId);
            $fileResponse['errMsg']             =   "Workflow server path data found";
            if( $serverMapPath['status'] != 0){
                
               /*  $stageInfo                       =   $checkoutObj->getStageInfo($data->jobStageId);
                 if(!empty($stageInfo)){
                     $stageDetails      =    $stageInfo['0'];
                     if($stageDetails->ROUND_ID  == '119' && $stageDetails->STAGE_ID == $indexingProcess){
                         $bookLevelProcess  = 1;
                         $jobId             =   $stageDetails->JOB_ID;
                        
                     }
                 }
                 
                if($bookLevelProcess  == 1) {
                    $tasklevelMetadataModel           =      new taskLevelMetadataModel();
                    $getJobChapters                    =   $tasklevelMetadataModel->getMetadatadetailsJob($jobId);
                   
                    if(!empty($getJobChapters)){
                        $chapterStatus  = array();
                        $srcpath         =   $serverMapPath['detail']['src'];
                        
                        if(!empty($pathDetails['detail']['mSrc'])){
                                $muliSourcePath  = 1;  
                        }
                        
                        foreach($getJobChapters as $key =>$chpInfo){
                           
                            $serverMapPath['detail']['src']  = $srcpath.$chpInfo->CHAPTER_NO.'/';
                            $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath,$data->jobStageId,1);
                            $chapterStatus[$chpInfo->CHAPTER_NO] = $fileStatus['status'];
                        }
                    }
                    $fileStatus['status'] = 'success';
                   
                   
                }else{
                     $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath,$data->jobStageId,1);
                }*/
               //echo "<pre>";print_r($serverMapPath);exit;
                $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath,$data->jobStageId,1);
               //echo "<pre>";print_r($fileStatus);exit;
                //optional purpose
                $stgMgr                     =   new stageMangerController();
                $stgMgr->semiAutomaticProcessHandling( $data->jobStageId , $fileResponse );
                
                $workingDir                       = explode('/',$serverMapPath['detail']['work']);
                $hostpath                         = $workingDir['0'];

                $openPath                         =  $serverMapPath['detail']['opendrive'];

                if($serverMapPath['detail']['ispartial'] == '1' && $fileStatus['status'] == 'success') {
                     
                    $commonObj                    =    new CommonMethodsController();
                    $tempPath                     =    $hostpath.str_ireplace($hostpath,$driveRootpath,$serverMapPath['detail']['temp']);
                    $tempPath                     =    str_ireplace('//', '/', $tempPath);
                    $fileResponse['deletePath']   =    $tempPath.'<>'.$driveUsername.'<>'.$drivePassword;
                    $commonObj->deletefilesInproduction($fileResponse['deletePath']);
                     
                }
                
                $fileResponse['opendir']            = $openPath;
                $fileResponse['filetransferStatus'] = $fileStatus['status'];
                if($fileStatus['status']    ==  "failed" && isset($fileStatus[0]['errMsg'])){
                    if(strpos($fileStatus[0]['errMsg'],'directory'))
                    $fileResponse['sourcenotexist']     =   1;
                    else
                    $fileResponse['sourcenotexist']     =   0;
                    $fileResponse['errMsg']             =   $fileStatus[0]['errMsg'];
                }else{
                    $fileResponse['errMsg']             =   "Success";
                    unset($fileResponse['sourcenotexist']);
                }
            }
            
            return response()->json( $fileResponse );
            
        }
        
    }
    
    public static function checkInfileCopy(Request $request){
        
        $data                          =     json_decode($request->getContent());
        
         $driveUsername                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_USERNAME' );
         $drivePassword                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_PASSWORD' );
         $drivepath                    =       \Config::get( 'serverconstants.FILE_SERVER_ROOT_DIR' );
        
        
        if(!empty($data->jobStageId)){
            $workflowPath                     =   new workflowServerMapPathModel();
            $serverMapPath                    =   $workflowPath->getWorkflowServerMapPath($data->jobStageId);
            
            $fileStatus                       =   checkOutController::fileMoveMent($serverMapPath,$data->jobStageId,0);
            
            $workingDir                       = explode('/',$serverMapPath['detail']['work']);
            $hostpath                         = $workingDir['0'];
            
            $openPath                         =  $serverMapPath['detail']['opendrive'];
            
             if($serverMapPath['detail']['filecheout'] == '1') {
                 $tempPath                     =  str_ireplace('$hostpath','$drivepath',$serverMapPath['detail']['temp']);
                 $fileResponse['deletePath']   = $tempPath.'<>'.$driveUsername.'<>'.$drivePassword;
            }
            
           // $fileResponse['opendir']            = $openPath.'<>'.$driveUsername.'<>'.$drivePassword;
            $fileResponse['opendir']            = $openPath;
            $fileResponse['filetransferStatus'] = $fileStatus['status'];
            
            return response()->json( $fileResponse );
        }
    }
    
    public static function fileMoveMent($pathDetails,$jobstageId    =   null,$checkoutorin = null){
       
        $fileMovementStatus = array();
        $fileStringmissingfile  =   [];
        $requesttime    =   1;
        geneateNextTime:
        //dd( $pathDetails );
        if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
            $muliSourcePath  = 0;
            if($pathDetails['detail']['ispartial'] == '0'){
                $src                =   $pathDetails['detail']['src'];
                
                if(!empty($pathDetails['detail']['mSrc'])){
                   $muliSourcePath  = 1;  
                }
            }else{
                $src                =   $pathDetails['detail']['temp'];
            }
            
            $workDir            =   $pathDetails['detail']['work'];            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            if($muliSourcePath == 1){
               
               foreach($pathDetails['detail']['mSrc'] as $key2 => $mData ) {
				   
                    $src                                         =   $mData;
                    $pathDetails['detail']['srcfilestring']      =   $pathDetails['detail']['mSrcfilestring'][$key2];
                    $pathDetails['detail']['srcfileextension']   =   $pathDetails['detail']['mSrcfileextension'][$key2];

                    if($pathDetails['detail']['ispartial'] == '0' && !empty($pathDetails['detail']['srcfileextension']) && $pathDetails['detail']['srcfileextension'] !='NA'){
                        $getinputchapters    =   array(); 
                        $fileExtension    	=   array(); 

                        if(!empty($pathDetails['detail']['srcfilestring']) && $pathDetails['detail']['srcfilestring'] != 'NA' && (strpos($pathDetails['detail']['srcfilestring'],',') !==   false || strpos($pathDetails['detail']['srcfileextension'],',') !==   false)){
							$returncomparefiledata	=	checkOutController::fileNameandExtnCompare($pathDetails['detail']['srcfilestring'],$pathDetails['detail']['srcfileextension']);
							$getinputchapters    	=   $returncomparefiledata['filesourcedata'];
                            $fileExtension     		=   $returncomparefiledata['fileextensiondata'];
                        }else{
							if(!empty($pathDetails['detail']['srcfilestring']) && $pathDetails['detail']['srcfilestring'] != 'NA'){
                            $getinputchapters[]     =   $pathDetails['detail']['srcfilestring'];
                        }
                        $fileExtension          =   explode(',',$pathDetails['detail']['srcfileextension']);
						}
                      
                        $checkexistDirFiles         =       $fileHandlerObj->getDirectoryFiles($src);
                        if(count($checkexistDirFiles)>=1){
                                //alfresco upload
//                                if($requesttime == 1 && $checkoutorin    ==  1 && $jobstageId != null){
//                                    $checkoutinit   =       new checkoutModel();
//                                    $jobstageinfo   =   $checkoutinit->getStageInfo($jobstageId);
//                                    $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobstageinfo[0]->JOB_ID,$jobstageinfo[0]->METADATA_ID,$jobstageinfo[0]->ROUND_ID,$jobstageinfo[0]->STAGE_ID,$src,'checkout');
//                                }
                            
                                $fileMoveStatus     =   $fileMoveStatus['multifiles'][]     =   $fileHandlerObj->ftp_dir_copy_word_file_only( $crd.$src, $workDir,$getinputchapters,$fileExtension );
                                if(count($fileMoveStatus) >=1 && in_array( 'failed' , $fileMoveStatus) && $requesttime <= 3 ){
                                    $requesttime  +=  1;
                                    goto geneateNextTime;
                                }
                                if(count($fileMoveStatus) == 0 && $requesttime <= 3 ){
                                    $requesttime  +=  1;
                                    goto geneateNextTime;
                                }
							
                                if(count($fileMoveStatus) == 0 ){		
                                        if( isset( $fileExtension[0] ) ){
                                                $extvar	=		$fileExtension[0];
                                                if( $extvar == '.3d' || $extvar == '.indd'){
                                                        //skipping application files
                                                }else{
                                                        $fileMoveStatus     =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => implode(',',$getinputchapters).' file is not available in '.$src.' directory , Try after sometimes' );
                                                }
                                        }

                                }
                                $fileMoveStatus['multifiles'][]            =   $fileHandlerObj->ftp_dir_copy_word_file_only( $crd.$src, $workDir,$getinputchapters,$fileExtension );
                        }else{
                            $fileMoveStatus     =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'file is not available in '.$src.' directory , Try after sometimes' );
                        }
                    }else{
                        //alfresco upload
//                        if($checkoutorin    ==  1 && $jobstageId != null){
//                            $checkoutinit   =       new checkoutModel();
//                            $jobstageinfo   =   $checkoutinit->getStageInfo($jobstageId);
//                            $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobstageinfo[0]->JOB_ID,$jobstageinfo[0]->METADATA_ID,$jobstageinfo[0]->ROUND_ID,$jobstageinfo[0]->STAGE_ID,$src,'checkout');
//                        }
                        $fileMoveStatus     =   $fileHandlerObj->ftp_dir_copy($crd.$src,$workDir);
                    }
               }
            }else{
            
                if($pathDetails['detail']['ispartial'] == '0' && !empty($pathDetails['detail']['srcfileextension']) && $pathDetails['detail']['srcfileextension'] !='NA'){
					/*$getinputchapters    =   array(); 
					if(!empty($pathDetails['detail']['srcfilestring']) && $pathDetails['detail']['srcfilestring'] != 'NA'){
						$getinputchapters[]       =   $pathDetails['detail']['srcfilestring'];
					}
                    $fileExtension          	=   explode(',',$pathDetails['detail']['srcfileextension']);*/
					
                   $getinputchapters    =   array(); 
					$fileExtension    			=   array(); 

					if(!empty($pathDetails['detail']['srcfilestring']) && $pathDetails['detail']['srcfilestring'] != 'NA' && (strpos($pathDetails['detail']['srcfilestring'],',') !==   false || strpos($pathDetails['detail']['srcfileextension'],',') !==   false)){
							$returncomparefiledata	=	checkOutController::fileNameandExtnCompare($pathDetails['detail']['srcfilestring'],$pathDetails['detail']['srcfileextension']);
							$getinputchapters    	=   $returncomparefiledata['filesourcedata'];
                            $fileExtension     		=   $returncomparefiledata['fileextensiondata'];
					}else{
                   if(!empty($pathDetails['detail']['srcfilestring']) && $pathDetails['detail']['srcfilestring'] != 'NA'){
                    $getinputchapters[]       =   $pathDetails['detail']['srcfilestring'];
                   }
                    $fileExtension          =   explode(',',$pathDetails['detail']['srcfileextension']);
					}
                    
                    $checkexistDirFiles         =       $fileHandlerObj->getDirectoryFiles($src);
                    
                    if(count($checkexistDirFiles)>=1){
                        
                        $fileMoveStatus            =   $fileHandlerObj->ftp_dir_copy_word_file_only( $crd.$src, $workDir,$getinputchapters,$fileExtension );
                        if(count($fileMoveStatus) >=1 && in_array( 'failed' , $fileMoveStatus ) && $requesttime <= 3 ){
                            $requesttime  +=  1;
                            goto geneateNextTime;
                        }
                        if(count($fileMoveStatus) == 0 && $requesttime <= 3 ){
                            $requesttime  +=  1;
                            goto geneateNextTime;
                        }
                        if(count($fileMoveStatus) == 0){
                            $fileMoveStatus     =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => implode(',',$getinputchapters).' file is not available in '.$src.' directory , Try after sometimes' );
                        }
                    }else{
                        $fileMoveStatus     =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'file is not available in '.$src.' directory , Try after sometimes' );
                    }
                    
                }else{
                    
                    $fileMoveStatus     =   $fileHandlerObj->ftp_dir_copy($crd.$src,$workDir);
                }
            }
			
		
            $fileMovementStatus         =   checkOutController::getFileMovementResposeStatus($pathDetails,$jobstageId,$checkoutorin,$fileMoveStatus);
        }
        
        return $fileMovementStatus;
    }
	
	public static function fileNameandExtnCompare($serverSourcestring,$serverSourceextn){
		$data['filesourcedata']		=	[];
		$data['fileextensiondata']	=	[];
		$serverSourcestring	=	rtrim($serverSourcestring,',');
		$serverSourceextn	=	rtrim($serverSourceextn,',');
		if(strpos($serverSourceextn,',') !== false || strpos($serverSourcestring,',') !== false){
			$srcFiletotalcount 	=	explode(',',$serverSourcestring);
			$extnFiletotalcount =	explode(',',$serverSourceextn);
		}
		
		if(strpos($serverSourceextn,',') !== false && strpos($serverSourceextn,',') !== false){
			if(count($srcFiletotalcount) == count($extnFiletotalcount)){
				$data['filesourcedata'] 	=	$srcFiletotalcount;
				$data['fileextensiondata'] 	=	$extnFiletotalcount;
			}else if(count($srcFiletotalcount) > count($extnFiletotalcount)){
				$data['filesourcedata'] 	=	$srcFiletotalcount;
				$data['fileextensiondata'] 	=	$extnFiletotalcount;
				$length 	=	count($srcFiletotalcount)-count($extnFiletotalcount);
				for($i=$length;$i>0;$i--){
					array_push($data['fileextensiondata'],end($extnFiletotalcount));
				}
			}else{
				$data['fileextensiondata'] 	=	$extnFiletotalcount;
				$data['filesourcedata'] 	=	$srcFiletotalcount;
				$length 	=	count($extnFiletotalcount)-count($srcFiletotalcount);
				for($i=$length;$i>0;$i--){
					array_push($data['filesourcedata'],end($srcFiletotalcount));
				}
			}
		}elseif(strpos($serverSourcestring,',') == false && strpos($serverSourceextn,',') !== false){
			$data['fileextensiondata'] 	=	$extnFiletotalcount;
			$data['filesourcedata'] 	=	$srcFiletotalcount;
			$length 	=	count($extnFiletotalcount)-count($srcFiletotalcount);
			for($i=$length;$i>0;$i--){
				array_push($data['filesourcedata'],$serverSourcestring);
			}
		}elseif(strpos($serverSourcestring,',') !== false && strpos($serverSourceextn,',') == false){
			$data['filesourcedata'] 	=	$srcFiletotalcount;
			$data['fileextensiondata'] 	=	$extnFiletotalcount;
			$length 	=	count($srcFiletotalcount)-count($extnFiletotalcount);
			for($i=$length;$i>0;$i--){
				array_push($data['fileextensiondata'],$serverSourceextn);
			}
		}
		return $data;
    }

    public  static function getFileMovementResposeStatus($pathDetails,$jobstageId,$checkoutorin,$response_copy){
        
        //check array single dimentional or multidimentional array
        $checkarray     =   array_filter($response_copy,'is_array');
        if(count($checkarray)>=1){
            $response_copy    =       array( 'status' => 'success' , $response_copy );
            return $response_copy;
            //multidimentional array
            foreach ($response_copy as $key => $value ){
                if( in_array( 'failed' , $value ) ){
                    $response_copy   =       array( 'status' => 'failed'  , $response_copy );
                    return $response_copy;//if failed return before all iterations
                }else{
                    //alfresco upload
                    // if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' && count($pathDetails['detail']['mSrcFullapth'])>=1 ){
                        // if($checkoutorin    ==  1 && $jobstageId != null && $pathDetails['detail']['ispartial'] == '0' && !empty($pathDetails['detail']['srcfileextension']) && $pathDetails['detail']['srcfileextension'] !='NA'){
                            // foreach($pathDetails['detail']['mSrcFullapth'] as $key2 => $mData ) {    
                                // $checkoutinit   =   new checkoutModel();
                                // $jobstageinfo   =   $checkoutinit->getStageInfo($jobstageId);
                                // $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobstageinfo[0]->JOB_ID,$jobstageinfo[0]->METADATA_ID,$jobstageinfo[0]->ROUND_ID,$jobstageinfo[0]->STAGE_ID,$mData,'checkout');
                            // }
                        // }
                    // }
                    
                    $response_copy    =       array( 'status' => 'success' , $response_copy );
                }
            }
            
        }else{
//            single dimentional array 
            if( in_array( 'failed' , $response_copy ) ){

                foreach ($response_copy as $key => $value ){
                if( $value == 'success' ){
                    unset( $response_copy[$key] );
                }
            }

                $response_copy   =       array( 'status' => 'failed'  , $response_copy );

            }else{

                //alfresco upload
//                if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
//                    if($checkoutorin    ==  1 && $jobstageId != null && $pathDetails['detail']['ispartial'] == '0' && !empty($pathDetails['detail']['srcfileextension']) && $pathDetails['detail']['srcfileextension'] !='NA'){
//                        $checkoutinit   =   new checkoutModel();
//                        $jobstageinfo   =   $checkoutinit->getStageInfo($jobstageId);
//                        $successfileresponse    =   app('App\Http\Controllers\Api\AlfrescoController')->alfrescoSentRequest($jobstageinfo[0]->JOB_ID,$jobstageinfo[0]->METADATA_ID,$jobstageinfo[0]->ROUND_ID,$jobstageinfo[0]->STAGE_ID,$pathDetails['detail']['opensrcpath'],'checkout');
//                    }
//                }

                $response_copy    =       array( 'status' => 'success' , $response_copy );
            }
        }
        
        
        return $response_copy;
    }
     
    public static function checkoutArtfileCopy(Request $request){
        
         $data                         =        json_decode($request->getContent());
         $driveUsername                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_USERNAME' );
         $drivePassword                =       \Config::get( 'serverconstants.MAGNUS_DOMAIN_PASSWORD' );
         $drivepath                    =       \Config::get( 'serverconstants.FILE_SERVER_ROOT_DIR' );
         $qcStage                      =        \Config::get('constants.STAGE_COLLEECTION.ART_QC');
        
      
        if(!empty($data->batchId)){
            
             $checkoutObj                     =  new checkoutModel();
            $jobstageDetails                  =   $checkoutObj->getJobStageIdByBatch($data->batchId);
            
                if(count($jobstageDetails)>= '1'){
                     foreach($jobstageDetails as $key=>$value){
                       $jStageId[]         =   $value->JOB_STAGE_ID;
                    }    
                    
                 $stageIds                 =   implode(',',$jStageId);
            }
          
            if(!empty($stageIds)){
                $stageInfo                       =   $checkoutObj->getArtStageInfo($stageIds);
            }
           
            $workflowPath                     =   new workflowServerMapPathModel();
            $serverMapPath                    =   $workflowPath->getWorkflowServerMapPath($stageInfo['0']->JOB_STAGE_ID,1,$stageInfo);
            $workupstage                      = \Config::get( 'constants.ART_SUPPORTING_FOLDER_STAGES' );
           
            $fileStatus                       =   checkOutController::fileMoveMentByFile($serverMapPath,$stageInfo);
            
            if(count($serverMapPath['detail']['mSrc'])>=2){ 
                
                $mulSrc             =   $serverMapPath['detail']['mSrc'];
                $mSrcFullapth       =   $serverMapPath['detail']['mSrcFullapth'];
                $mSrcfilestring     =   $serverMapPath['detail']['mSrcfilestring'];
                $mSrcfileextension  =   $serverMapPath['detail']['mSrcfileextension'];
                unset($mulSrc[0]);
                unset($mSrcFullapth[0]);
                unset($mSrcfilestring[0]);
                unset($mSrcfileextension[0]);
                $serverMapPath['detail']['mSrc']  = $mulSrc;
                $serverMapPath['detail']['mSrcFullapth']  = $mSrcFullapth;
                $serverMapPath['detail']['mSrcfilestring'] = $mSrcfilestring;
                $serverMapPath['detail']['mSrcfileextension'] = $mSrcfileextension;
                $fileStatus2          =   checkOutController::fileMoveMent($serverMapPath,$stageInfo);
               
            }
             if(in_array($stageInfo['0']->STAGE_ID,$workupstage)){
              $serverDetail     =   $serverMapPath['serverCredential'];
              $folderPath       =   $serverMapPath['detail']['work'].'WORK_UP';
              $folderPath2       =   $serverMapPath['detail']['work'].'PRINT';
              $workupDirPath    =   str_ireplace($serverDetail['host'],'',$folderPath);
              $printDirPath     =   str_ireplace($serverDetail['host'],'',$folderPath2);
              $fileHandlerObj   =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
           
              $directory        =   $fileHandlerObj->make_directory($workupDirPath);
              
              $directory        =   $fileHandlerObj->make_directory($printDirPath);
            }
            
            if($stageInfo['0']->ITERATION_ID >=2){
                $serverMapPath2                   =    $workflowPath->getServerPathBasedOnWorkflowStages($stageInfo['0']->JOB_ID,$stageInfo['0']->WORKFLOW_ID,$qcStage,array(9));
                $inp_rep_arr                      =   array('{BID}' => $stageInfo['0']->BOOK_ID , '{RID}' => $stageInfo['0']->ROUND_NAME,'{CID}' => $stageInfo['0']->CHAPTER_NO );
                $cmn_obj                          =   new CommonMethodsController(); 

                if(!empty($serverMapPath2)){
                    $serverDetail       =   $serverMapPath['serverCredential'];
                    $fileHandlerObj   =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
                    $artPdfRefferece  = $serverMapPath2['0']->SERVER_PATH.$serverMapPath2['0']->FOLDER_PATH.'REFERENCE_PDF/';
                    $artPdfRefferece = $cmn_obj->arr_key_value_replace( $inp_rep_arr , $artPdfRefferece );

                    $withoutHost     =    str_ireplace($serverDetail['host'],'',$artPdfRefferece);
                    $pdffolder        =   $fileHandlerObj->ftp_is_dir($withoutHost);
                   
                    if($pdffolder == true){

                        $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
                        $fileExtension[] = '.pdf';
                        $fileMoveStatus            =   $fileHandlerObj->ftp_dir_copy_word_file_only( $crd.$artPdfRefferece, $serverMapPath['detail']['work'],array(),$fileExtension );

                    }
                }
            }
            
            $workingDir                       = explode('/',$serverMapPath['detail']['work']);
            $hostpath                         = $workingDir['0'];
            
            $openPath                         =  $serverMapPath['detail']['opendrive'];
            
             if(isset($fileStatus['deletePath']) && $fileStatus['status'] == 'success' && !empty($fileStatus['deletePath'])) {
                  $commonObj                    =    new CommonMethodsController();
                  
                 foreach($fileStatus['deletePath'] as $filepath){
                    $tempPath                     =  str_ireplace($hostpath,$drivepath,$filepath);
                    $tempPath                     = $hostpath.$tempPath.'<>'.$driveUsername.'<>'.$drivePassword;
                    $tempPath                     = str_ireplace('//','/',$tempPath);
                    $commonObj->deletefilesInproduction($tempPath);
                 }
            }
            
            $fileResponse['opendir']            = $openPath;
            $fileResponse['filetransferStatus'] = $fileStatus['status'];
            
            return response()->json( $fileResponse );
        }
    }
    
    public static function fileMoveMentByFile($pathDetails,$stageDetails){
       
        $fileMovementStatus = array();
        
        if(!empty($pathDetails['detail']) && $pathDetails['status'] == '1' ){
            
            if($pathDetails['detail']['filecheout'] == '0'){
                $src                =   $pathDetails['detail']['src'];
            }else{
                $src                =   $pathDetails['detail']['temp'];
            }
            
            $workDir            =   $pathDetails['detail']['work'];
            
            $serverDetail       =   $pathDetails['serverCredential'];    
            $crd                =   'ftp://'.$serverDetail['username'].':'.$serverDetail['pasword'].'@'; 
            
            $fileHandlerObj     =   new ftpFileHandlerController($serverDetail['host'],$serverDetail['username'],$serverDetail['pasword']);
            $fileCopyStatus     =   array();
            $deletePath         =   array();
           // echo "<pre>";print_r($stageDetails);exit;
            foreach($stageDetails as $key => $filedata){
                
                if($filedata->IS_PARTIAL == '1'){
                    $pathDet        =   $pathDetails['detail']['arttemp'];
                    $src            =   $pathDet;
                    $deletePath[]   =   $src; 
                }else{
                    $src                =   $pathDetails['detail']['src'];
                }
                                
                $workDirWithFilename             =     '';
                $src1                            = $crd.$src.$filedata->FILE_NAME;
               
                $workDirWithFilename             = $crd.$workDir.$filedata->FILE_NAME;
                
                $fileData                        =   @file_get_contents($src1);
                
                if(!empty($fileData)){
                    $workDirPath        =   str_ireplace($serverDetail['host'],'',$workDir);
                    $directory          =   $fileHandlerObj->make_directory($workDirPath);
                    $fileRes            =   $fileHandlerObj->ftp_file_put($workDirWithFilename,$fileData);
                    $fileCopyStatus[$filedata->FILE_NAME]   =   'success';
                }else{
                   $fileCopyStatus[$filedata->FILE_NAME]   =   'failed';
                }
            
            }
            
            $fileMovementStatus                 =   checkOutController::getFileMovementResposeStatusOverall($fileCopyStatus);
             $fileMovementStatus['deletePath']  =   array();
             
            if($fileMovementStatus['status'] == 'success' && !empty($deletePath)){
                  $fileMovementStatus['deletePath'] =    $deletePath;           
            }
            
        }
       
        return $fileMovementStatus;
    }
	
    public  static function getFileMovementResposeStatusOverall($response_copy){
    
        if( in_array( 'failed' , $response_copy ) ){

            foreach ($response_copy as $key => $value ){
                if( $value == 'success' ){
                    unset( $response_copy[$key] );
                }
            }

            $response_copy   =       array( 'status' => 'failed'  , $response_copy );

        }else{
            $response_copy    =       array( 'status' => 'success' , $response_copy );
        }
        return $response_copy;
     }
        
    public function artGenerateMetaxml(Request $request){
        
        $data               =   $request->all();
          $checkoutObj                     =  new checkoutModel();
         
          if(!empty($data['jstageId'])){
                $stageInfo1                       =   $checkoutObj->getArtStageInfo($data['jstageId']);
                
                $stageInfo                       =   $stageInfo1['0'];
                $bookId                          =   $stageInfo->BOOK_ID;
                $roundName                       =   $stageInfo->ROUND_NAME;
                $chapterNo                       =   $stageInfo->CHAPTER_NO;
                $jobId                           =   $stageInfo->JOB_ID;
                
           }
            
            $workflowPath                    =   new workflowServerMapPathModel();
            $serverMapPath                   =   $workflowPath->getWorkflowServerMapPath($data['jstageId']);
          
            if($serverMapPath['status'] == '1'){
              $srcpathorg   =    $srcpath         =    $serverMapPath['detail']['work'];
               $ip              =    $serverMapPath['serverCredential']['host'];
            }
        
        $commonObj          =   new CommonMethodsController();
       
        $rootpath           =     \Config::get('constants.FILE_SERVER_WITH_ROOT_DIR');
        $artWebUrl          =     \Config::get('constants.GENERATE_ART_METAXML');
        
        $srcpath            =        '////'.$rootpath.str_replace($ip,'' , $srcpath);
        
       $srcpath             =    str_replace("/",'\\',$srcpath);
       
        $srcpath            =      str_replace( '//' , '\\' ,   $srcpath ); 
        $srcpath            =      str_replace( '\\\\' , '\\' ,   $srcpath ); 
        
        $input['BWFBookID']         = $bookId;
        $input['Stage']             = $roundName;
        $input['ChapterID']         = $chapterNo;
        $input['FileServerPath']    = $srcpath;
      
        $response  = $commonObj->PostcUrlExecution($input,$artWebUrl,0);
        $returndata['Status']   =   '0';
        $returndata['Msg']      =   'Not able to generate Art metadata xml.';
    
        if($response != ''){
            
            $response               =   html_entity_decode($response);
            $response               =   str_ireplace( '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">', '',$response);
            $response               =   str_ireplace( '</string>','', $response);
            $productionLocation     =   new productionLocationModel();
                        
            $ftobj                  =   new ftpFileHandlerController($serverMapPath['serverCredential']['host'],$serverMapPath['serverCredential']['username'],$serverMapPath['serverCredential']['pasword']);
            
            $crd                    =   'ftp://'.$serverMapPath['serverCredential']['username'].':'.$serverMapPath['serverCredential']['pasword'].'@'; 
            $savepath               =   $crd.$srcpathorg.'ArtMetadata.xml';
            
            
            $putfiledirectory       =   $ftobj->ftp_file_put($savepath,$response);
            $returndata['Status']   =   '1';
            $returndata['Msg']      =   'Success';
            $returndata['serverpath'] = $serverMapPath;
            $returndata['stageInfo'] = $stageInfo1;
            
           
        }
        
         
         return $returndata;
    }
        
    /*public function artGenerateMetaxml(Request $request){
        
        $data               =   $request->all();
          $checkoutObj                     =  new checkoutModel();
         
          if(!empty($data['jstageId'])){
                $stageInfo1                       =   $checkoutObj->getArtStageInfo($data['jstageId']);
                
                $stageInfo                       =   $stageInfo1['0'];
                $bookId                          =   $stageInfo->BOOK_ID;
                $roundName                       =   $stageInfo->ROUND_NAME;
                $chapterNo                       =   $stageInfo->CHAPTER_NO;
                $jobId                           =   $stageInfo->JOB_ID;
                
           }
            
            $workflowPath                    =   new workflowServerMapPathModel();
            $serverMapPath                   =   $workflowPath->getWorkflowServerMapPath($data['jstageId']);
          
            if($serverMapPath['status'] == '1'){
              $srcpathorg   =    $srcpath         =    $serverMapPath['detail']['work'];
               $ip              =    $serverMapPath['serverCredential']['host'];
            }
        
        $commonObj          =   new CommonMethodsController();
       
        $rootpath           =     \Config::get('constants.FILE_SERVER_WITH_ROOT_DIR');
        $artWebUrl          =     \Config::get('constants.GENERATE_ART_METAXML');
        
        $srcpath            =        '////'.$rootpath.str_replace($ip,'' , $srcpath);
        
       $srcpath             =    str_replace("/",'\\',$srcpath);
       
        $srcpath            =      str_replace( '//' , '\\' ,   $srcpath ); 
        $srcpath            =      str_replace( '\\\\' , '\\' ,   $srcpath ); 
        
        $input['BWFBookID']         = $bookId;
        $input['Stage']             = $roundName;
        $input['ChapterID']         = $chapterNo;
        $input['FileServerPath']    = $srcpath;
      
        $response  = $commonObj->PostcUrlExecution($input,$artWebUrl,0);
        $returndata['Status']   =   '0';
        $returndata['Msg']      =   'Not able to generate Art metadata xml.';
    
        if($response != ''){
            
            $response               =   html_entity_decode($response);
            $response               =   str_ireplace( '<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">', '',$response);
            $response               =   str_ireplace( '</string>','', $response);
            $productionLocation     =   new productionLocationModel();
                        
            $ftobj                  =   new ftpFileHandlerController($serverMapPath['serverCredential']['host'],$serverMapPath['serverCredential']['username'],$serverMapPath['serverCredential']['pasword']);
            
            $crd                    =   'ftp://'.$serverMapPath['serverCredential']['username'].':'.$serverMapPath['serverCredential']['pasword'].'@'; 
            $savepath               =   $crd.$srcpathorg.'ArtMetadata.xml';
            
            
            $putfiledirectory       =   $ftobj->ftp_file_put($savepath,$response);
            $returndata['Status']   =   '1';
            $returndata['Msg']      =   'Success';
            $returndata['serverpath'] = $serverMapPath;
            $returndata['stageInfo'] = $stageInfo1;
            
           
        }
        
         
         return $returndata;
    }*/
    
    public function endArtSubmit( Request $request )
    {
        $jobId          =   $request->input('jobId');
        $metaId         =   $request->input('metaId');
        $batchId         =   $request->input('batchId');
        $checkinFlag      =   $request->input('checkinFlag');
        $getatrmetadata =   taskLevelMetadataModel::getBatchArtfigurecatloguechapterInfo($jobId,$metaId,$batchId);
            
        if(count($getatrmetadata)>=1)
        {
            $get_information['art']             =   $getatrmetadata;
            $get_information['jobID']           =   $jobId;
            $get_information['Book_id']         =   $request->input('bookid');
            $get_information['chaptername']     =   $request->input('chapterno');
            $get_information['meta_id']         =   $metaId;
            $get_information['status']          =   1;
            $get_information['checkinFlag']     =   $checkinFlag;
            return response()->json( $get_information ); 
        }
        $response   =   $this->notfoundResponse;
        return response()->json( $response );    
    }
    
    /*public function endArtSubmit( Request $request )
    {
        $data           =   json_decode($request->getContent());
        $hostserver     =   $data->serverpath->serverCredential->host;
        $hostusername   =   $data->serverpath->serverCredential->username;
        $hostpassword   =   $data->serverpath->serverCredential->pasword;
        $srcpath        =   $data->serverpath->detail->work;
        $crd            =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
        $jobId          =   $data->stageInfo->JOB_ID;
        $book_id        =   $data->stageInfo->BOOK_ID;
        $chapterno      =   $data->stageInfo->CHAPTER_NO;
        $meta_id        =   $data->stageInfo->METADATA_ID;
        $ftpObj         =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfiledirectory      =   $ftpObj->getDirectoryFiles($crd.$srcpath);
        $getallfiles    =   [];
        // echo $full_file_path;exit;
        if(count($readfiledirectory)>=1)
        {
            $spiltchapter       =   "";
            foreach($readfiledirectory as $value)
            {
                if(strpos($value,'/') !== 	false)
                {
                    $getallfiles[]  =   substr(strrchr($value, "/"), 1);
                }
            } 
        }
        
        if($getposition     =   in_array(Config::get('constants.ART_METADATA_FILEW'),$getallfiles))
        {
            $full_file_path =   $crd.$srcpath.$getallfiles[$getposition];
            $get_information['art']             =        $this->readArtmetaXml( $full_file_path , $jobId );
            $get_information['jobID']           =        $jobId;
            $get_information['Book_id']         =        $book_id;
            $get_information['chaptername']     =        $chapterno;
            $get_information['meta_id']         =        $meta_id;
            $get_information['status']          =       1;
            return response()->json( $get_information );
        }
        $response['status']         =       0;
        $response['msg']            =       'Success';
        $response['errMsg']         =       'Art Meta Xml not found';
        return response()->json( $response );    
    }*/
    
    public function readArtmetaXml( $filePath  , $job_id ) 
    {    
        $artData    =	array();
        if(empty($filePath)){
            return $artData;
        }
        $getlocationftp     =   productionLocationModel::doGetLocationname( $job_id );  
        //need to dynamicaly bind the production location based on table location
        $hostserver         =   $getlocationftp->FTP_HOST;
        $usn                =   $hostusername   =   $getlocationftp->FTP_USER_NAME;
        $psw                =   $hostpassword   =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =   ( $getlocationftp->FTP_PATH );
        $metadataXml			=   file_get_contents($filePath );
        $xml                            =   simplexml_load_string(  $metadataXml , 'SimpleXMLElement' , LIBXML_NOCDATA );
        $metadataDetails		=   json_decode( json_encode((array)$xml ), TRUE );
        if(count($metadataDetails)>=1){
        if(count($metadataDetails['Figure'])!='0'){

                if(count($metadataDetails['Figure']) == '1'){
                        $artData[] =  $metadataDetails['Figure']['@attributes'];
                } else {
                        if(!empty($metadataDetails))	{
                                foreach($metadataDetails['Figure'] as $key => $data){
                                        $artData[] = $data['@attributes'];
                                }
                        }
                }
            }
        }

        return $artData;
    }
     
    public function downloadArtCreatedPdf( Request $request ){
        
        $getfile    =       $request->input('openPath');
        $root_dir   =       substr( \Config::get( 'serverconstants.FILE_SERVER_ROOT_DIR' ) , 1 );
        $getfile    =       str_replace( $root_dir , '' , $getfile );
        $appFolder  =       'downloadCreatedPdftemp/';
       
        try{
            
            $jobid      =       $request->input('jobid');
            $metaid     =       $request->input('metaid');
            $tlm        =       new taskLevelMetadataModel();
            
            $getlocationftp          =       productionLocationModel::doGetLocationname( $jobid );

            $host   =       $getlocationftp->FTP_HOST;$usr    =       $getlocationftp->FTP_USER_NAME;
            $psw    =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            
            $getfilelink             =       'ftp://'.$usr.':'.$psw.'@';
            $taskLevelInfo           =       $tlm->getMetadatadetailsChapter( $metaid );
            $chapterlist             =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
            $bi_obj                  =       new bookinfoModel();
            $bookinfo                =       $bi_obj->getBookinfodetails( $jobid );
            $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 

            if(empty( $bookinfo ))  
                throw new \Exception( 'Job information is not found' );        

            if(empty( $chapterlist ))  
                throw new \Exception( 'chapter level information is not found' );      

            $book_id            =       $bookinfo[0];
            
            //need to customize auto filenaming convention logic here
            $pdf_name           =       $book_id.'_'.$chapterlist[0].'_COMBINED_ARTWORK.pdf';
            $getfile            =       explode('<>'  , $getfile );
            $getfile            =       $getfile[0].$pdf_name;

            if(!empty($getfile)){

                if (!file_exists(public_path( $appFolder ))){
                    File::makeDirectory( public_path($appFolder) , $mode = 0777 , true , true );
                }

                $getfilesdownload   =       $getfilelink.$getfile;
                $getftpfile         =       file_get_contents( $getfilesdownload );
                
                $putfile            =       file_put_contents( public_path($appFolder.$pdf_name) , $getftpfile );
                
                if( $putfile && $getftpfile ){
                    $result             =   array( 'result' => 200 , 'status' => 1 , 'errMsg' => 'File is downloaded' , 'link' => url('/').'/public/'.$appFolder.$pdf_name );   
                }else{
                    $result             =   array( 'result' => 200 , 'status' => 0 , 'errMsg' => 'Pdf File downloading got failed, try again.' );   
                }
                
                return response()->json($result);

            }
        
        }catch( \Exception $ex ){
            
            return response()->json( array( 'result'=> 401 , 'status' => 0 , 'errMsg'=>'File downloading failed :'.$ex->getMessage() ) );
            
        }
        
        return  response()->json( array( 'result'=> 200 , 'status' => 0 , 'errMsg'=>'File downloading failed' ) );
        
    }
    
    public function getWorkFlowRuleByStages($jobStageId){
      
        $ruleData                        =  array();
        $checkoutObj                     =  new checkoutModel();
        $customObj                       =  new customizationModel();
        $jobstageDetails                 =   $checkoutObj->getWorkflowRuleDetails($jobStageId);
        
        if(!empty($jobstageDetails)){
            $ruleType                       =   array();
            $stageDetail                    =   $jobstageDetails['0'];
            $wfMid                          =   $stageDetail->WORKFLOW_MASTER_ID;
            $jobid                          =   $stageDetail->JOB_ID;
            $roundId                        =   $stageDetail->ROUND_ID;
            $wfId                           =   $stageDetail->WORKFLOW_ID;
            $stageId                        =   $stageDetail->STAGE_ID;
            
            $ruleData                       =   $customObj->getWorkflowRuleByStage($wfMid,$jobid,$roundId,$wfId,$stageId);
            
            if(!empty($ruleData)) {
                foreach($ruleData as $key => $data){
                    if($data->RULE_TYPE != 0){
                    $ruleType[$data->RULE_TYPE] = $data;
                    }
                }
            }
            
            return $ruleType;
        }
        
        return $ruleData;
        
    }
    
    public function rejectProcess(Request $request) {
        $data = $request->all();
       try{
        $checkoutObj = new checkoutModel();
        $manageSrtageObj = new stageMangerController();
        $response['status'] = 1;
        if (!empty($data)) {
            $stageInfo = $checkoutObj->getStageDetailByUserdefined($data['userDefinedId']);
           
            if (!empty($stageInfo)) {
                $stageDetails = $stageInfo['0'];
                $jobStageId = $stageDetails->JOB_STAGE_ID;

                $currentstageDetails = $checkoutObj->getStageInfo($jobStageId);
                $stagemanager = $manageSrtageObj->manageWorkLog($jobStageId, $data['quantity'], $data['quantity'], $data['remarks'], $currentstageDetails['0'], $checkInFlag = '1');
                
                $rollbackStatus = $checkoutObj->StageRollBack($stageDetails->JOB_ROUND_ID, $stageDetails->WORKFLOW_ID, $stageDetails->ROUND, $stageDetails->ITERATION_ID, $data['goToStageId'], $currentstageDetails['0']);
                $response['status'] = 2;
            }else{
                 $response['status'] = 1;
            }
        }
       
        }catch( \Exception $ex ){
            
            return $ex->getMessage();
            
        }
        return response()->json($response);
    }

    public function getQcErrorLogTypeTable( $jobstageid ){
        
        $subcircle  =   \Config::get('constants.CIRCLE.SUBCIRCLEID');
        $errTypEnumObj      =       new errorTypeEnum();
        $errLogType         =       $errTypEnumObj->getErrorRecordBysubCircleId( $subcircle );
        $returns            =       array();
        
        $chkObj             =       new checkoutModel();
        $stageDetails       =       $chkObj->getStageInfo( $jobstageid );
        $stageDetails       =       $stageDetails[0];
        
        $artProcont         =       new artProcessController();
        $metaid             =       $stageDetails->METADATA_ID;
        $artSelectionBox    =       $artProcont->getArtListDesign( $metaid );
        
            $tbrw           =       '<thead><tr>';
            $colgroup       =       $artSelectionBox.'<table id="prQc_table" class="table  table-bordered table-hover"><colgroup>';
            $tbrw2          =       '<tbody><tr>';
            
            $tbcell         =       '';
            $tbcell2        =       '';
            $errLogType     =       (array)( $errLogType );
            $colmd          =       1;
            
            if( count( $errLogType ) ){
                
                foreach( $errLogType as $key => $value ){
                    
                    foreach( $value as $ikey => $ivalue ){
                        
                        $colgroup   .=  '<col class="col-md-'.$colmd.'">';
                        $tbcell.= '<th>';
                            $tbcell .= $ivalue->ERROR_TYPE_NAME;
                        $tbcell.= '</th>';
                        
                        $emptyVar   =       '';
                        $otherattr  =       '';
                        
                        if( $ivalue->ERROR_CODE ==  'ART_ERROR' ){
                            //$otherattr      =   ' ng-change="artErrorPR_QC_RejectionDesign(this)" ';
                            $otherattr      =   ' readonly ';
                        }
                        
                        $tbcell2.= '<td>';
                            $tbcell2 .=  '<div>'
                                    . '<input '.$otherattr.' class="errorPrc" ng-init="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'='.($ivalue->ERROR_TYPE_ENUM_ID == Config::get('constants.ERROR_TYPE_ENUM_ID.ART_ERROR')?0:"''").'" type="text" ng-model="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" name="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" id="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" value="" >';
                            $tbcell2 .=  '<span class="help-block errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'_help"></span>'
                                    . '</div>';
                        $tbcell2.= '</td>';
                        
                    }
                    
                }
                
                $tbrw    .=  $tbcell;
                $tbrw2   .=  $tbcell2;
                $colgroup   .= '<col class"col-md-2"></colgroup>';
                
            }
            
            $tbrw       .=   '<th>Remarks</th></tr></thead>';
            $tbrw2      .=   '<td><textarea rows="3" style="width:100%" ng-model="prQc.remarks" id="remarks_errorvalidation" class=""></textarea><span class="help-block remarks_error_help"></span></td></tr></tbody></table>';
            
            $returns['msg'] =   'success';
            $returns['tablestr'] =   $colgroup.$tbrw.$tbrw2;
            
            return response()->json( $returns );
            
    }
    
     public function getbookReviewTypeTable( $jobstageid ){
        
        $subcircle  =   \Config::get('constants.CIRCLE.SUBCIRCLEID');
        $errTypEnumObj      =       new errorTypeEnum();
        $errLogType         =       $errTypEnumObj->getErrorRecordBysubCircleId( $subcircle );
        $returns            =       array();
        
        $chkObj             =       new checkoutModel();
        $stageDetails       =       $chkObj->getStageInfo( $jobstageid );
       
        $stageDetails       =       $stageDetails[0];
       
        $artProcont         =       new artProcessController();
        $metaid             =       $stageDetails->METADATA_ID;
        $artSelectionBox    =       $artProcont->getChapterListDesign( $stageDetails->JOB_ID );
        
            $tbrw           =       '<thead><tr>';
            $colgroup       =       $artSelectionBox.'<table id="prQc_table" class="table  table-bordered table-hover"><colgroup>';
            $tbrw2          =       '<tbody><tr>';
            
            $tbcell         =       '';
            $tbcell2        =       '';
            $errLogType     =       (array)( $errLogType );
            $colmd          =       1;
            
            if( count( $errLogType ) ){
                
                foreach( $errLogType as $key => $value ){
                    
                    foreach( $value as $ikey => $ivalue ){
                        
                        $colgroup   .=  '<col class="col-md-'.$colmd.'">';
                        $tbcell.= '<th>';
                        if( $ivalue->ERROR_CODE ==  'ART_ERROR' ){
                            $tbcell .= "Chapter Error";
                        }else{
                            $tbcell .= $ivalue->ERROR_TYPE_NAME;
                        }
                        $tbcell.= '</th>';
                        
                        $emptyVar   =       '';
                        $otherattr  =       '';
                        
                        if( $ivalue->ERROR_CODE ==  'ART_ERROR' ){
                            //$otherattr      =   ' ng-change="artErrorPR_QC_RejectionDesign(this)" ';
                            $otherattr      =   ' readonly ';
                        }
                        
                        $tbcell2.= '<td>';
                            $tbcell2 .=  '<div>'
                                    . '<input '.$otherattr.' class="errorPrc" ng-init="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'='.($ivalue->ERROR_TYPE_ENUM_ID == Config::get('constants.ERROR_TYPE_ENUM_ID.ART_ERROR')?0:"''").'" type="text" ng-model="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" name="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" id="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" value="" >';
                            $tbcell2 .=  '<span class="help-block errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'_help"></span>'
                                    . '</div>';
                        $tbcell2.= '</td>';
                        
                    }
                    
                }
                
                $tbrw    .=  $tbcell;
                $tbrw2   .=  $tbcell2;
                $colgroup   .= '<col class"col-md-2"></colgroup>';
                
            }
            
            $tbrw       .=   '<th>Remarks</th></tr></thead>';
            $tbrw2      .=   '<td><textarea rows="3" style="width:100%" ng-model="prQc.remarks" id="remarks_errorvalidation" class=""></textarea><span class="help-block remarks_error_help"></span></td></tr></tbody></table>';
            
            $returns['msg'] =   'success';
            $returns['tablestr'] =   $colgroup.$tbrw.$tbrw2;
            
            return response()->json( $returns );
            
    }
        
    public function validateWithImagexml($jobstageid, $stageInfo){
        
        $workflowPath       =   new workflowServerMapPathModel();
        $serverMapPath      =   $workflowPath->getWorkflowServerMapPath($jobstageid);
        $isArtPresent       =   0;
        
        $artmodelObj        =       new taskLevelArtMetadataModel();
        $artMetaFiles       =       $artmodelObj->getArtChapterwisefigureInfo($stageInfo->METADATA_ID);
        
        if(count($artMetaFiles) > 1){
            $isArtPresent       =   1;
            $roundarray         =   \Config::get('constants.ROUND_ID');
            $roundId            =   $roundarray[$stageInfo->ROUND_NAME];
            $artIsCompleted     =   $artmodelObj->isAllartStagesCompleted($stageInfo->METADATA_ID,$roundId);
            
            if(!empty($artIsCompleted)){
                $response['status'] = 0;
                $response['message']= 'Art production not yet completed';
                return $response;
            }
        }else{
            $response['status'] = 1;
            $response['message']= 'No art for this component';
            return $response;
        }
        
        
       
        $workPath           =   $serverMapPath['detail']['work'];
        $hostserver         =   $serverMapPath['serverCredential']['host'];
        $hostusername       =   $serverMapPath['serverCredential']['username'];
        $hostpassword       =   $serverMapPath['serverCredential']['pasword'];
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        
        $artQcPath          =   \Config::get('constants.ART_QC_PATH');
        $fileList           =   $ftpObj->getDirectoryFiles($workPath);
        $bookidreplace      =   array(
                                        '{BID}'       =>  $stageInfo->BOOK_ID,
                                        '{RNAME}'       =>  $stageInfo->ROUND_NAME,
                                        '{CID}'       =>  $stageInfo->CHAPTER_NO
                                      );
        $cmn_obj            =   new CommonMethodsController();
        $artQcPath          =   $cmn_obj->arr_key_value_replace( $bookidreplace , $artQcPath , true );
        $artQcfiles         =   $ftpObj->getDirectoryFiles($hostserver.'/'.$artQcPath);
        $qcfiles            =   array();
        $response           =   array();
        
        if(!empty($artQcfiles)){
           foreach($artQcfiles as $key => $data){
            $splitData   =    explode('/',$data);
            $split1      =    end($splitData);
            $files       =    explode('.',$split1);
                if(count($files)>= 2){
                  $ste      =   $files['0'];
                  $ste2     =   explode('_',$ste);
                  $removed  =   array_pop($ste2);
                  $qcfiles[] =  implode('_',$ste2);
                }
            }
        }
     
        if(empty($fileList) && empty($qcfiles)){
            $response['status'] = 1;
            $response['message']= 'No art files';
            return $response;
        }else if(empty($fileList) && !empty($qcfiles)){
            $response['status'] = 0;
            $response['message']= 'Image xml not found';
            return $response;
        }else if(!empty($fileList) && empty($qcfiles)){
            $response['status'] = 0;
            $response['message']= 'Art files are not available in production path';
            return $response;
        }
        
        $filePath       =   '';
        foreach($fileList as $key => $data){
           $splitData   =    explode('/',$data);
           $fileName    =    end($splitData);
           if (strpos($fileName, '_images.xml') !== false) {
                $filePath  = $data;
            }
        }
        
        if(!empty($filePath)){
            $crd                            =       'ftp://'.$hostusername.':'.$hostpassword.'@';   
            $metadataXml                    =       file_get_contents( $crd.$hostserver.$filePath );
            $xml                            =       simplexml_load_string(  $metadataXml , 'SimpleXMLElement' , LIBXML_NOCDATA );
            $metadataDetails                =       json_decode( json_encode((array)$xml ), TRUE );

            if(!empty($metadataDetails)){
                foreach($metadataDetails['item'] as $key => $artfile){
                    $splitData2   =   explode('_',$artfile['@attributes']['name']);
                    $removed      =   array_pop($splitData2);
                    $imagefile    =   implode('_',$splitData2);
                    $filename[]   =   $imagefile;
                }
            }
            $errorFiles = array();
            
            if(!empty($qcfiles) && !empty($filename)){
               
                foreach($filename as $img){
                    if(!in_array($img,$qcfiles)){
                        $errorFiles[]     =   $img;
                    }
                }
                if(empty($errorFiles)){
                    $response['status'] = 1;
                    $response['message']= 'Art files are valid';
                    return $response;
                }else{
                    $response['status'] = 0;
                    $error  = implode(', ',$errorFiles);
                    $response['message']= $error. ' - This Art files are not valid';
                    return $response;
                }
            }
            
        }else{
            $response['status'] = 0;
            $response['message']= 'Image xml file not found';
            return $response;
        }
       
    }
    public function validateArtxml( $jobstageid ){
        
        $subcircle  =   \Config::get('constants.CIRCLE.SUBCIRCLEID');
        $errTypEnumObj      =       new errorTypeEnum();
        $errLogType         =       $errTypEnumObj->getErrorRecordBysubCircleId( $subcircle );
        $returns            =       array();
        
        $chkObj             =       new checkoutModel();
        $stageDetails       =       $chkObj->getStageInfo( $jobstageid );
        $stageDetails       =       $stageDetails[0];
        
        
        $response           =       $this->validateWithImagexml($jobstageid, $stageDetails);
        
        $artProcont         =       new artProcessController();
        $metaid             =       $stageDetails->METADATA_ID;
        $artSelectionBox    =       $artProcont->getArtListDesign( $metaid );
        
        $getartfigure       =       taskLevelArtMetadataModel::whereIn( 'METADATA_ID' , array( $metaid )  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();   
        
            $tbrw           =       '<thead><tr><td>checkbox</td><td>';
            $colgroup       =       $artSelectionBox.'<table id="prQc_table" class="table  table-bordered table-hover"><colgroup>';
            $tbrw2          =       '<tbody><tr>';
            
            $tbcell         =       '';
            $tbcell2        =       '';
            $errLogType     =       (array)( $errLogType );
            $colmd          =       1;
            
           /* if( count( $errLogType ) ){
                
                foreach( $errLogType as $key => $value ){
                    
                    foreach( $value as $ikey => $ivalue ){
                        
                        $colgroup   .=  '<col class="col-md-'.$colmd.'">';
                        $tbcell.= '<th>';
                            $tbcell .= $ivalue->ERROR_TYPE_NAME;
                        $tbcell.= '</th>';
                        
                        $emptyVar   =       '';
                        $otherattr  =       '';
                        
                        if( $ivalue->ERROR_CODE ==  'ART_ERROR' ){
                            //$otherattr      =   ' ng-change="artErrorPR_QC_RejectionDesign(this)" ';
                            $otherattr      =   ' readonly ';
                        }
                        
                        $tbcell2.= '<td>';
                            $tbcell2 .=  '<div>'
                                    . '<input '.$otherattr.' class="errorPrc" ng-init="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'=0" type="text" ng-model="prQc.error.errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" name="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" id="errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'" value="" >';
                            $tbcell2 .=  '<span class="help-block errorid_'.$ivalue->ERROR_TYPE_ENUM_ID.'_help"></span>'
                                    . '</div>';
                        $tbcell2.= '</td>';
                        
                    }
                    
                }
                
                $tbrw    .=  $tbcell;
                $tbrw2   .=  $tbcell2;
                $colgroup   .= '<col class"col-md-2"></colgroup>';
                
            }*/
            $getartfigure   =   [];
            $tbrw       .=   '<>Remarks</th></tr></thead>';
            $tbrw       .=   '<th>Remarks</th></tr></thead>';
            $tbrw2      .=   '<td><textarea rows="3" style="width:100%" ng-model="prQc.remarks" class=""></textarea></td></tr></tbody></table>';
            $colgroup    =  '<table id="error" class ="table table-bordered table-hover"><tr>';
            if($response['status'] == 1){
              $colgroup    .= '<input type="hidden" id="artStatus" value='.$response['status'].'>';
              $colgroup    .= '<td>Validation Status &nbsp <i class="fa fa-check green" aria-hidden="true"></i></td> <td class="table-success">'.$response['message'].'</td>';  
            }else{
               $colgroup    .= '<input type="hidden" id="artStatus" value='.$response['status'].'>';
               $colgroup    .= '<td>Validation Status &nbsp <i class="fa fa-close red" style="font-size:20px"></i></td> <td  class="table-danger" >'.$response['message'].'</td>';  
            }
            $colgroup    .= '</tr></table>';
            $colgroup    .=  '<table id="prQc_table" class="table  table-bordered table-hover"> <tr><td>Is Reject</td><td rows="1">Type</td><td> Remarks</td></tr>';
            $colgroup    .= '<tr><td><input type="checkbox" id="artRejct" '.(count($getartfigure) == 0?"disabled":"").'></td><td>'.$artSelectionBox.'</td><td><textarea id="artRemarks"/></td></tr>';
            $colgroup    .= '<tr><td><input type="checkbox" id="ceRejct"></td><td>Copy Editing Error</td><td><textarea id="ceRemarks"/></td></tr>';
            $returns['msg'] =   'success';
            $returns['tablestr'] =   $colgroup;
            
            return response()->json( $returns );
            
    }
    
    public function artValidationProcess( Request $request ){
        
        $input_arr  =   $request->all();
        $elm_name   =   array();
        $elm_val    =   array();
        
        $response       =       array();
        
        $response['status']     =  0;
        $response['msg']        =  'Failed';
        $response['errMsg']     =  'Oops ! Something went wrong , Try again after sometimes';
            
        $insert_err_arr_coll     =       array();
        $insert_err_arr_sign     =       array();
        
        try {            

            if( !empty( $input_arr['storeQc'] ) ){

                $basicInput              =       $input_arr['storeQc']['basic'];
                $artSelect               =  [];
                if(isset($input_arr['storeQc']['artmetaidSelect'])){
                    $artSelect           =     $input_arr['storeQc']['artmetaidSelect'];
                }
                $artRejectFlag           =       0;
                $ceRejectFlag            =       0;
                $ceRemarks               =       '';
                $artRemarks              =       '';
                $rejectprocess           =       array();
				
                
                if( $input_arr['storeQc']['artReject']  == 1){
                    $artSelect                      =   $input_arr['storeQc']['artmetaidSelect'];
                    $artRejectFlag                  =   1;
                    $artRemarks                     =   $input_arr['storeQc']['artRejectRemark'];
                    $rejectprocess['art']['reject'] =   1;
                    $rejectprocess['art']['Remarks'] =  $artRemarks;
                }else{
					 $rejectprocess['art']['reject'] =   0;
					 $rejectprocess['art']['Remarks'] =  '';
				}
                
                if( $input_arr['storeQc']['ceReject']  == 1){
                    $ceRejectFlag                   =  1;
                    $ceRemarks                      =  $input_arr['storeQc']['ceRejectRemark'];
                    $rejectprocess['ce']['reject']  =   1;
                    $rejectprocess['ce']['Remarks'] =   $ceRemarks;
                }else{
					$rejectprocess['ce']['reject'] =   0;
					$rejectprocess['ce']['Remarks'] =  '';
				}
               
                if( $artRejectFlag == '1' || $ceRejectFlag == '1' ){
                    
                    $returnstatus           =   $this->failureCevalidateStageManager( $basicInput , $artSelect , $rejectprocess );
                    $response['status']     =   1;
                    $response['msg']        =   'Success';
                    $response['errMsg']     =   'Successfully saved';
                    $response['insertid']   =   $returnstatus;   
                    
                }else{
                    $remarks                =   '';
                    //normal stage movement [ proceed to next stage ]
                    
                    $basicInput              =      $input_arr['storeQc']['basic'];
                    $jbstgid                 =      $basicInput['jbstgid']; 
                    $stgManagerObj           =      new stageMangerController();
                    $checkoutObj             =      new checkoutModel();
                    $data                    =      (object)array( 'outputQuantity'  => 10 , 'inputRemarks' => $remarks ,
                                                        'inputQuantity' => $basicInput['inputQuantity'] , 
                                                        'jbstgid' => $basicInput['jbstgid'] 
                                                    );
                    $stageDetails           =   $checkoutObj->getStageInfo( $jbstgid );
                   
                             
                    $fileMoveStatus          =      $stgManagerObj->fileMovementProcess( $jbstgid , 0 );
                    $deleteWrokPath          =      @$fileMoveStatus['pathDetails']['detail']['opendrive']; 
                    $commonObj               =      new CommonMethodsController();
                    
                    if($fileMoveStatus['status'] == 'success' || $fileMoveStatus['status'] =='nofileMovement' ){
                        $deleteRes          =      $commonObj->deletefilesInproduction($deleteWrokPath);
                        
                        $response['msg']    =   'success';
                        $returnres          =   $stgManagerObj->mangeStageProcess( $data );  
                        if( $returnres || true){

                            $stageDetails           =   $checkoutObj->getStageInfo( $jbstgid ); 
                          //  $input_arr['storeQc']['nextskip'] = 1;
                            if(isset($input_arr['storeQc']['nextskip'])&& $input_arr['storeQc']['nextskip'] == '1'){
                                $jobRoundId             =   $stageDetails['0']->JOB_ROUND_ID;
                                $stageSequence          =   $stageDetails['0']->STAGE_SEQ +1;
                                $iteration              =   $stageDetails['0']->ITERATION_ID;
                                $workflowId             =   $stageDetails['0']->WORKFLOW_ID;

                                $nexstageDetails        =   $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);
                                $artXmlDelivery         =   \Config::get('constants.STAGE_COLLEECTION.ART_XML_DELIVERY');

                                if($nexstageDetails->STAGE_ID  == $artXmlDelivery){
                                    
                                    $stageDetails['0']->STAGE_SEQ  = $stageDetails['0']->STAGE_SEQ +1;
                                    
                                    $openNextStageStatus    =   $stgManagerObj->moveNextStage($stageDetails['0']);
                                    
                                    $updateStageParam       =       array( 'STATUS' => '24' , 'CHECK_IN' => date( 'Y-m-d H:i:s' ),'SKIP_ENABLED' => '1' );
                                    $updateQry              =       DB::table('job_stage') 
                                                                    ->where('JOB_STAGE_ID', ( $nexstageDetails->JOB_STAGE_ID ) )
                                                                    ->update( $updateStageParam );
                                }else{
                                    $openNextStageStatus    =   $stgManagerObj->moveNextStage($stageDetails['0']);
                                }
                                
                            }else{
                                    $openNextStageStatus    =   $stgManagerObj->moveNextStage($stageDetails['0']);
                            }

                            $response['status']     =  1;
                            $response['msg']        =  'Success';
                            $response['errMsg']     =  'Successfully completed...';
                           
                        }
                    }else{
                        $response['status']     =   0;
                        $response['msg']        =   'Failed';
                        $response['errMsg']     =   'FileMovent Got Failed, please try again';
                    }
                   
                     return response()->json( $response );
                }
                
                
            }else{
                throw new \Exception( 'invalid input. [ storeQc ]' );
            }
        
        } catch (\Exception $ex) {
            
            $response['reason'] =   $ex->getMessage();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
                        
            return response()->json( $response );
                    
        }
        
       return response()->json( $response );
        
    }
    
    public function proofReadingQCStageHandling( Request $request ){
        
        //Step  1   :   Server validation
        //Step  2   :   Save to table
        //if (error)
        //Step  3   :   Rollback the stages
        //if( art error persist )
        //Step  3.1 :   art rollback handling
        //else
        //Step  3   :   normal movetonext stage
        
        
        $input_arr  =   $request->all();
      
        $elm_name   =   array();
        $elm_val    =   array();
        
        $response               =   $this->oopsErrorResponse;
        
        $insert_err_arr_coll     =       array();
        $insert_err_arr_sign     =       array();
        
        try {            

            if( !empty( $input_arr['storeQc'] ) ){

                $basicInput              =       $input_arr['storeQc']['basic'];
                $errorInfo               =       $input_arr['storeQc']['error'];
                $remarks                 =       isset( $input_arr['storeQc']['remarks'] ) ? $input_arr['storeQc']['remarks'] : '';
                $artSelect               =       !empty( $input_arr['storeQc']['artmetaidSelect'] ) ?  $input_arr['storeQc']['artmetaidSelect']  : array();
                $artRejectFlag           =       false;
                
                foreach( $errorInfo as $key => $value ){
                    
                    $keyChg     =       '';
                    
                    if( intval( $value ) > 0 ){
                        
                        $insert_err_arr_sign    =   array();
                        $insert_err_arr_sign    =   $this->prepareInputForStorePrQcError( $basicInput );
                        
                        $keyChg     = str_replace( 'errorid_' , '' , $key );
                        $insert_err_arr_sign['ERROR_TYPE_ENUM_ID']      =   $keyChg; 
                        $insert_err_arr_sign['ERROR_COUNT']             =    $value;
                            
                            if( $keyChg == 8 ){
                                $artRejectFlag  =   true;
                            }
                            
                        $insert_err_arr_coll[]     =    $insert_err_arr_sign;
                        
                    }
                    
                }
                
                if( $artRejectFlag ){
                    $artSelect  =   $input_arr['storeQc']['artmetaidSelect'];
                }
                
                if( count( $insert_err_arr_coll ) == 0 && count($artSelect) > 0 ){
                    $response['errMsg']     =   'Invalid try, Total error count is Wrong';
                    throw new \Exception($response['errMsg']);
                }
                
                if( count( $insert_err_arr_coll ) ){
                    
                    DB::beginTransaction();
                    
                    $insert_status      =   DB::table('pr_qc_error_log')->insert($insert_err_arr_coll);
                    
                    if( $insert_status ){
                       
                        //call the proofreading failure case 
                        $returnstatus   =   $this->failureProofReadingStageManager( $basicInput , $artSelect , $remarks );
                        
                        if( $returnstatus ){    
                            
                            DB::commit();
                            $response   =   $this->insertedResponse;
                            $response['insertid']   =   $insert_status;   
                            
                        }else{
                            
                            DB::rollback();
                          //throw new \Exception( $returnstatus['errMsg'].'/t'.$returnstatus['reason'] );
                            
                        }
                    }else{
                        DB::rollback();
                    }
                }else{
                    
                    //normal stage movement [ proceed to next stage ]
                    
                    $basicInput              =      $input_arr['storeQc']['basic'];
                    $jbstgid                 =      $basicInput['jbstgid']; 
                    $stgManagerObj           =      new stageMangerController();
                    $checkoutObj             =      new checkoutModel();
                    $data                    =      (object)array( 'outputQuantity'  => 10 , 'inputRemarks' => $remarks ,
                                                        'inputQuantity' => $basicInput['inputQuantity'] , 
                                                        'jbstgid' => $basicInput['jbstgid'] 
                                                    );
                    
          
                    $fileMoveStatus          =      $stgManagerObj->fileMovementProcess( $jbstgid , 0 );
                    $deleteWrokPath          =      @$fileMoveStatus['pathDetails']['detail']['opendrive']; 
                    $commonObj               =      new CommonMethodsController();
                    $deleteRes               =      $commonObj->deletefilesInproduction($deleteWrokPath);
                    
                    if($fileMoveStatus['status'] == 'success' || $fileMoveStatus['status'] =='nofileMovement' ){
                        
                        $response['msg']    =   'success';
                        $returnres          =   $stgManagerObj->mangeStageProcess( $data );  
                        if( $returnres || true){
                          
                            $stageDetails           =   $checkoutObj->getStageInfo( $jbstgid );   
                            
                          
                            //$openNextStageStatus    =   $stgManagerObj->moveNextStage($stageDetails['0']);
                            $response   =   $this->successResponse;
                            $response['errMsg']     =  'Successfully completed...';
                           
                        }
                      
                     $rounds600   = \Config::get('constants.ROUND_NAME.S600');
					 $rounds650   = \Config::get('constants.ROUND_NAME.S650');
					//  Log::useDailyFiles( storage_path().'/Api/pcsubmit.log' );
                   //    Log::info(json_encode($stageDetails));
					 
                    if($stageDetails['0']->ROUND_ID == $rounds600 || $stageDetails['0']->ROUND_ID == $rounds650){
                        $data1  = array();
                        $data1['jobId'] = $stageDetails['0']->JOB_ID;
                        $data1['roundid'] = $stageDetails['0']->ROUND_ID;
                        $data1['stageid'] = $stageDetails['0']->STAGE_ID;
                        $sendemailalert         =   app('App\Http\Controllers\checkout\stageManagerCustomController')->validationProcessCheck((object)$data1);
                       }
                        
                    }else{
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   'FileMovent Got Failed, please try again';
                    }
                   
                     return response()->json( $response );
                }
                
                
            }else{
                throw new \Exception( 'invalid input. [ storeQc ]' );
            }
        
        } catch (\Exception $ex) {
            
            $response['reason'] =   $ex->getMessage();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
                        
            return response()->json( $response );
                    
        }
       
       return response()->json( $response );
        
    }
    
     public function bookReviewStageHandling( Request $request ){
        
        //Step  1   :   Server validation
        //Step  2   :   Save to table
        //if (error)
        //Step  3   :   Rollback the stages
        //if( art error persist )
        //Step  3.1 :   art rollback handling
        //else
        //Step  3   :   normal movetonext stage
        
        
        $input_arr  =   $request->all();
      
        $elm_name   =   array();
        $elm_val    =   array();
        
        $response               =   $this->oopsErrorResponse;
        
        $insert_err_arr_coll     =       array();
        $insert_err_arr_sign     =       array();
        
        try {            
           
            if( !empty( $input_arr['storeQc'] ) ){

                $basicInput              =       $input_arr['storeQc']['basic'];
                $errorInfo               =       $input_arr['storeQc']['error'];
                $remarks                 =       isset( $input_arr['storeQc']['remarks'] ) ? $input_arr['storeQc']['remarks'] : '';
                $artSelect               =       !empty( $input_arr['storeQc']['artmetaidSelect'] ) ?  $input_arr['storeQc']['artmetaidSelect']  : array();
                $artRejectFlag           =       false;
                
                foreach( $errorInfo as $key => $value ){
                    
                    $keyChg     =       '';
                    
                    if( intval( $value ) > 0 ){
                        
                        $insert_err_arr_sign    =   array();
                        $insert_err_arr_sign    =   $this->prepareInputForStorePrQcError( $basicInput );
                        
                        $keyChg     = str_replace( 'errorid_' , '' , $key );
                        $insert_err_arr_sign['ERROR_TYPE_ENUM_ID']      =   $keyChg; 
                        $insert_err_arr_sign['ERROR_COUNT']             =    $value;
                            
                            if( $keyChg == 8 ){
                                $artRejectFlag  =   true;
                            }
                            
                        $insert_err_arr_coll[]     =    $insert_err_arr_sign;
                        
                    }
                    
                }
                
                if( $artRejectFlag ){
                    $artSelect  =   $input_arr['storeQc']['artmetaidSelect'];
                }
                
                if( count( $insert_err_arr_coll ) == 0 && count($artSelect) > 0 ){
                    $response['errMsg']     =   'Invalid try, Total error count is Wrong';
                    throw new \Exception($response['errMsg']);
                }
                
                if( count( $insert_err_arr_coll ) ){
                    
                    DB::beginTransaction();
                    
                    $insert_status      =   DB::table('pr_qc_error_log')->insert($insert_err_arr_coll);
                    
                    if( $insert_status ){
                       
                        //call the proofreading failure case 
                        $returnstatus   =   $this->failureBookReviewStageManager( $basicInput , $artSelect , $remarks );
                        
                        if( $returnstatus ){    
                            
                            DB::commit();
                            $response   =   $this->insertedResponse;
                            $response['insertid']   =   $insert_status;   
                            
                        }else{
                            
                            DB::rollback();
                          //throw new \Exception( $returnstatus['errMsg'].'/t'.$returnstatus['reason'] );
                            
                        }
                    }else{
                        DB::rollback();
                    }
                }else{
                    
                    //normal stage movement [ proceed to next stage ]
                    
                    $basicInput              =      $input_arr['storeQc']['basic'];
                    $jbstgid                 =      $basicInput['jbstgid']; 
                    $stgManagerObj           =      new stageMangerController();
                    $checkoutObj             =      new checkoutModel();
                    $data                    =      (object)array( 'outputQuantity'  => 10 , 'inputRemarks' => $remarks ,
                                                        'inputQuantity' => $basicInput['inputQuantity'] , 
                                                        'jbstgid' => $basicInput['jbstgid'] 
                                                    );
                    
          
                    $fileMoveStatus          =      $stgManagerObj->fileMovementProcess( $jbstgid , 0 );
                    $deleteWrokPath          =      @$fileMoveStatus['pathDetails']['detail']['opendrive']; 
                    $commonObj               =      new CommonMethodsController();
                    $deleteRes               =      $commonObj->deletefilesInproduction($deleteWrokPath);
                    
                    if($fileMoveStatus['status'] == 'success' || $fileMoveStatus['status'] =='nofileMovement' ){
                        
                        $response['msg']    =   'success';
                        $returnres          =   $stgManagerObj->mangeWorkLogProcessOnly( $data );  
                        if( $returnres || true){
                                                  
                            $xmlQC      =  \Config::get('constants.STAGE_COLLEECTION.XML_QC'); 
                          
                            $stageDetails           =   $checkoutObj->getStageInfo( $jbstgid ); 
                            $cdata                  =   $stageDetails['0'];
                            $stagecomRes                =  $checkoutObj->getStageCompletedForJob($cdata->JOB_ID, $cdata->ROUND_ID, $xmlQC);
                            $completedFlage              = 0;
                            if(!empty( $stagecomRes)){
                                 $completedFlage              = 1;
                                foreach($stagecomRes as $key => $sdata){

                                    if($sdata->STATUS  != '24' ){
                                        $completedFlage  = 0;
                                        break;
                                    }
                                 }
                            }
                        
                            if( $completedFlage  == 1){
                                $openNextStageStatus    =   $stgManagerObj->moveNextStage($stageDetails['0']);
                            }else{
                                $statusW     =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORPARALLEL' ); 
                                $stageskipby            =       1;
                                $jobRoundId             =       $cdata->JOB_ROUND_ID;
                                $roundId                =       $cdata->ROUND_ID;
                                $stageSequence          =       $cdata->STAGE_SEQ + $stageskipby;
                                $workflowId             =       $cdata->WORKFLOW_ID;  
                                $iteration              =       $cdata->ITERATION_ID;
                                $jobId                  =       $cdata->JOB_ID;
                                $outputQuantity         =       $cdata->OUTPUT_QUANTITY;
                                $cur_jobstg_id          =       $cdata->JOB_STAGE_ID;
                                $stg_id                 =       $cdata->STAGE_ID;
                                $getmetaid              =       $cdata->METADATA_ID;
                                
                                $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);
                                $nextJobStageId         =       $nexstageDetails->JOB_STAGE_ID;
                                $nextStageId            =       $nexstageDetails->STAGE_ID;
                                
                                $updateStageParam       =       array( 'STATUS' => '24' , 'CHECK_IN' => date( 'Y-m-d H:i:s' ) );
                                $updateQry              =       DB::table('job_stage') 
                                                                       ->where('JOB_STAGE_ID', ( $cdata->JOB_STAGE_ID ) )
                                                                       ->update( $updateStageParam );
													
													
                                $updateStageParam       =       array( 'STATUS'=>$statusW,'INPUT_QUANTITY' => $cdata->OUTPUT_QUANTITY);
                                $updateQry              =       DB::table('job_stage')
                                                                       ->where('JOB_STAGE_ID', $nextJobStageId )
                                                                       ->update( $updateStageParam );
                 
                                $jobRoundValue          =       array('STATUS'=>$statusW,'CURRENT_STAGE' => $nextStageId);
                                $updateQry              =       DB::table('job_round')
                                                                ->where('JOB_ROUND_ID', $jobRoundId )
                                                                ->update( $jobRoundValue );
                                
                            }
                            
                            
                            
                            $response   =   $this->successResponse;
                            $response['errMsg']     =  'Successfully completed...';
                           
                        }
                      
                     $rounds600   = \Config::get('constants.ROUND_NAME.S600');
                     $rounds650   = \Config::get('constants.ROUND_NAME.S650');
                    if(($stageDetails['0']->ROUND_ID == $rounds600 || $stageDetails['0']->ROUND_ID == $rounds650) && $completedFlage == 1 ){
                        $data1  = array();
                        $data1['jobId'] = $stageDetails['0']->JOB_ID;
                        $data1['roundid'] = $stageDetails['0']->ROUND_ID;
                        $data1['stageid'] = $stageDetails['0']->STAGE_ID;
                     //   $sendemailalert         =   app('App\Http\Controllers\checkout\stageManagerCustomController')->validationProcessCheck((object)$data1);
                       }
                        
                    }else{
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   'FileMovent Got Failed, please try again';
                    }
                   
                     return response()->json( $response );
                }
                
                
            }else{
                throw new \Exception( 'invalid input. [ storeQc ]' );
            }
        
        } catch (\Exception $ex) {
            
            $response['reason'] =   $ex->getMessage();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
                        
            return response()->json( $response );
                    
        }
       
       return response()->json( $response );
        
    }
    
    public function failureCevalidateStageManager( $basicInput , $artinfo = array() , $rejectProcess ){
        
        $jobid              =   $basicInput['jobId'];        
        $metaid             =   $basicInput['metaid'];
        $jobStageId         =   $basicInput['jbstgid'];
        $lastmodBy          =   $basicInput['userid'];
        $volumeissue        =   $basicInput['volumeissue'];
        $inputQuantity      =   $basicInput['inputQuantity'];
        $return_main        =   array();
        $return_parallel    =   array();        
        $wrkflwruleObj      =   new workflowRuleController();
        $checkoutObj        =   new checkoutModel();
        
        //check wheather this nextstage available as per rule or overwrite the nextstage variable
       if($rejectProcess['ce']['reject'] == 1){
        
            $remarks                =       $rejectProcess['ce']['Remarks'];
            $gotostage              =       $wrkflwruleObj->getWorkflowRuleBasedJobStageAvail( $jobStageId , 3 );
            $currentstageDetails    =       $checkoutObj->getStageInfo($jobStageId);


            if( !$gotostage ){
                if(!empty($currentstageDetails['0']->STAGE_SEQ )){
                    $stageSeq           =   $currentstageDetails['0']->STAGE_SEQ -1;
                 }
                $nextStageDetails       =       $checkoutObj->getNextStageDetailsByStageid($currentstageDetails['0']->JOB_ROUND_ID, $stageSeq , $currentstageDetails['0']->ITERATION_ID, $currentstageDetails['0']->WORKFLOW_ID );
                $gotostage              =   $nextStageDetails->STAGE_ID;
            }

            //main workflow rollback section
            if( $gotostage ){
                $stgMgObj            =       new stageMangerController();
                $stagemanager        =       $stgMgObj->manageWorkLog($jobStageId, $inputQuantity , $inputQuantity , $remarks , $currentstageDetails['0'] );
                $return_main         =       $stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );
            }
            
            if($return_main == false){
                return $return_main;
            }
       }
       // Art rollback 
        if($rejectProcess['art']['reject'] == 1){
            $remarks                 =   $rejectProcess['art']['Remarks'];
            $return_main        =   $this->ceArtRejectionProcess( $metaid , $artinfo , $remarks );
            if($return_main == false){
                return $return_main;
            }
        }
      
        return $return_main;
        
    }
    
    public function failureBookReviewStageManager( $basicInput , $artinfo = array() , $remarks = '' ){
        
        $jobid              =   $basicInput['jobId'];        
        $metaid             =   $basicInput['metaid'];
        $jobStageId         =   $basicInput['jbstgid'];
        $lastmodBy          =   $basicInput['userid'];
        $volumeissue        =   $basicInput['volumeissue'];
        $inputQuantity      =   $basicInput['inputQuantity'];
        $return_main        =   false;
        $return_parallel    =   array();        
        $wrkflwruleObj      =   new workflowRuleController(); 
        $stgMgObj            =       new stageMangerController();
        $stmobj                 =   $stgMgObj;
        $gotostage  =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
        
       // $fileMoveStatus          =      $stmobj->fileMovementProcess( $jobStageId , 0 );
        //$deleteWrokPath          =      @$fileMoveStatus['pathDetails']['detail']['opendrive']; 
        $fileMoveStatus['status']  = 'success';
        
       // echo "<pre>";print_r($artinfo);exit;
        if( $fileMoveStatus['status'] == 'success' || true){
            
            $commonObj               =      new CommonMethodsController();
        //    $deleteRes               =      $commonObj->deletefilesInproduction($deleteWrokPath);
            
                $metaIDs   = implode(',',$artinfo);
                $sql = "select js.WORKFLOW_MASTER_ID, js.WORKFLOW_ID, js.JOB_STAGE_ID,js.STAGE_ID,jr.ROUND_ID,jr.CURRENT_ITERATION_ID  from task_level_metadata as tm 
                        join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and tm.CURRENT_ROUND = jr.ROUND_ID
                        join job_stage as js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID and js.STAGE_ID = jr.CURRENT_STAGE
                        where tm.METADATA_ID in($metaIDs)";
                $response = DB::select( $sql );
               
                if(!empty($response)){
                    
                    foreach($response as $key => $rec){
                        $return_main         =       $stgMgObj->stageRollBack( $rec->JOB_STAGE_ID , $gotostage , $remarks );
                    }
                }
                
                $gotostage  = \Config::get( 'constants.STAGE_COLLEECTION.BOOK_BUILDING' );
                
                //main workflow rollback section
                if( $gotostage ){
                    $checkoutObj         =       new checkoutModel();
                    $currentstageDetails =       $checkoutObj->getStageInfo($jobStageId);
                    $stagemanager        =       $stgMgObj->manageWorkLog($jobStageId, $inputQuantity , $inputQuantity , $remarks , $currentstageDetails['0'] );
                    $return_main         =       $stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );
                }

                
        
        }
        
        return $return_main;
        
    }
    
    public function failureProofReadingStageManager( $basicInput , $artinfo = array() , $remarks = '' ){
        
        $jobid              =   $basicInput['jobId'];        
        $metaid             =   $basicInput['metaid'];
        $jobStageId         =   $basicInput['jbstgid'];
        $lastmodBy          =   $basicInput['userid'];
        $volumeissue        =   $basicInput['volumeissue'];
        $inputQuantity      =   $basicInput['inputQuantity'];
        $roundId            =   $basicInput['roundid'];
        
        $return_main        =   false;
        $return_parallel    =   array();        
        $wrkflwruleObj      =   new workflowRuleController(); 
        $stmobj =   new stageMangerController();
        
        
        $fileMoveStatus          =      $stmobj->fileMovementProcess( $jobStageId , 0 );
        $deleteWrokPath          =      @$fileMoveStatus['pathDetails']['detail']['opendrive']; 
        
        if( $fileMoveStatus['status'] == 'success' ){
            
            $commonObj               =      new CommonMethodsController();
            $deleteRes               =      $commonObj->deletefilesInproduction($deleteWrokPath);

                //check wheather this nextstage available as per rule or overwrite the nextstage variable
                $gotostage              =       $wrkflwruleObj->getWorkflowRuleBasedJobStageAvail( $jobStageId , 1 );
                $gotostage              =       false;

                if( !$gotostage ){  
                    $gotostage  =   \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
                }

                //main workflow rollback section
                if( $gotostage ){

                    $stgMgObj            =       new stageMangerController();
                    $checkoutObj         =       new checkoutModel();
                    $currentstageDetails =       $checkoutObj->getStageInfo($jobStageId);

                    $stagemanager        =       $stgMgObj->manageWorkLog($jobStageId, $inputQuantity , $inputQuantity , $remarks , $currentstageDetails['0'] );
                    $return_main         =       $stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );

                }

                //Art rejection for proofreading only [ cause need to do movetoproduction for current round and rejection for selected art  ]
                if( !empty( $artinfo ) ){
                    $return_parallel        =   $this->artMovetoProductionAndRecjectSelectedArt( $metaid , $artinfo , $remarks,$roundId );
                    //if waiting for parralel case check need do

                }
        
        }
        
        return $return_main;
        
    }
    
    //  This method is currently applicable for s300  
    //  - cause there is no art move to production entry available for  this round during art rejection case
    
    public function artMovetoProductionAndRecjectSelectedArt( $metaid , $artinfo , $remarks, $rID ){
        
        //check art move to production already done for this workflow
        // if yes rollback to art manual pagination stage
        // if no do move production for current round
        
       
        $s300_round         =   \Config::get('constants.ROUND_ID.S300');
        
        if($rID == $s300_round){
             $workflowid         =   \Config::get('constants.S300_ART_WORKFLOWID');
        }else{
             $s300_round         = $rID;
             $sql1       = "SELECT js.WORKFLOW_MASTER_ID, tu.WORKFLOW, jr.JOB_ID from job_round as jr 
                            join job_stage as js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_STAGE = js.STAGE_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID
                            join task_level_userdefined_workflow as tu on tu.WORKFLOW_MASTER_ID = js.WORKFLOW_MASTER_ID and  jr.JOB_ID = tu.JOB_ID and tu.ROUND = jr.ROUND_ID and tu.WORKFLOW_TYPE = 2
                            WHERE jr.metadata_id = $metaid AND jr.ROUND_ID = $s300_round AND jr.IS_ART is NULL group by tu.WORKFLOW";
             
             $rDetails   = DB::select( $sql1 );
             
             if(!empty($rDetails)){
                 $workflowid  = $rDetails['0']->WORKFLOW;
             }
           
        }
        $productionObj      =   new movetoproductionController();
        
        $returresp          =   false;
        
        $sql1	 =  "SELECT * FROM metadata_status ms WHERE ms.metadata_id = $metaid AND ms.CURRENT_ROUND = $s300_round AND ms.IS_ART=1";                
        $metadata = DB::select( $sql1 );
        
        if(empty($metadata)){
            
            //Doing movetoproduction
            $returresp  =   $productionObj->doArtMoveToProductionWithGrouping( $metaid , $s300_round , $workflowid );
            
        }else{
            
            $metaStatusId   =   $metadata['0']->ID;
            //art stage rollback
            $checkoutModelObj      =   new checkoutModel(); 
            $iterationCount        =   1;
            
                foreach( $artinfo as $key => $value ){
                    
                    $artMetaId          =       $value;
                    $jrObj              =       new jobRound();
                    $art_manuplation_stage_id           =       \Config::get('constants.STAGE_COLLEECTION.ART_MANIPULATION');
                    
                    $roundRec   =   $jrObj->getjobRoundEntryExistByMetaId( $metaid , $s300_round , 1 );
                    $jobroundid  =  $roundRec->JOB_ROUND_ID;
                    
                    $query_str      =   '  SELECT * from metadata_status as mds LEFT JOIN job_round as jr on jr.METADATA_STATUS_ID = mds.ID AND mds.CURRENT_ROUND = jr.ROUND_ID AND mds.CURRENT_ITERATION = jr.CURRENT_ITERATION_ID '
                                        .' LEFT JOIN job_stage AS js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID WHERE mds.ID = '.$metaStatusId
                                        .' AND js.STAGE_ID = '.$art_manuplation_stage_id
                                        .' AND mds.CURRENT_ROUND = '.$s300_round
                                        .' AND jr.IS_ART = 1 ' 
                                        .' ORDER BY JOB_STAGE_ID DESC LIMIT 1';

                    $job_stg_rec             =       DB::select( $query_str );
                    
                    $job_stg_rec             =       $job_stg_rec[0];
                    $jobStageIDs             =       $job_stg_rec->JOB_STAGE_ID;
                    $iterationCount          =       $job_stg_rec->ITERATION_ID;
                    
                    $jstageInfo              =       $checkoutModelObj->getArtStageInfo_old( $jobStageIDs );
                    $stageDetails            =       $jstageInfo[0];
                    
                    $returresp              =        $checkoutModelObj->artStageRollBack(  $artMetaId , $metaStatusId, $jobroundid  , $workflowid , $s300_round , $iterationCount , $stageDetails );
                     
                    $jbStgObj               =        new jobStage();
                    $getjobstageInfo        =        $jbStgObj->getCurrentJobStageInfo( $metaid , $s300_round , 27 );
                   
                    if( count( $getjobstageInfo ) ){
                        
                        $stageinfo     =    isset( $getjobstageInfo[0] ) ? $getjobstageInfo[0] : $getjobstageInfo;
                        $jbstgId        =   $stageinfo->JOB_STAGE_ID;
                        $stgmgObj       =    new stageMangerController();
                        $stgmgObj->manageWaitngForParallelProcessUpdate( $jbstgId );
                        
                    }
                
                }
            
        }
        
        return $returresp;
        
    }
    
      public function ceArtRejectionProcess( $metaid , $artinfo , $remarks ){
        
        $roundId            =   \Config::get('constants.ROUND_ID.S200');
        $productionObj      =   new movetoproductionController();
        
        $returresp          =   false;
        
        $sql1	 =  "SELECT * FROM metadata_status ms WHERE ms.metadata_id = $metaid AND ms.CURRENT_ROUND = $roundId AND ms.IS_ART=1";                
        $metadata = DB::select( $sql1 );
        
        if(empty($metadata)){
            return false;
        }else{
            
            $metaStatusId          =   $metadata['0']->ID;
            
            if(!empty($artinfo)){
                $artMetaId             =    implode(',',$artinfo);
            }else{
                $artMetaId             =    '';
            }
            //art stage rollback
            $checkoutModelObj      =   new checkoutModel(); 
            $iterationCount        =   1;
            
            $metaStatus            =    $checkoutModelObj->getCurrentStageDetais($metaStatusId);
            
            $jobroundid             =       $metaStatus->JOB_ROUND_ID;
            $workflowid             =       $metaStatus->WORKFLOW_ID;
            $iterationCount         =       $metaStatus->ITERATION_ID;
            $returresp              =       $checkoutModelObj->artStageRollBack(  $artMetaId , $metaStatusId, $jobroundid  , $workflowid , $roundId , $iterationCount , $metaStatus );
             
            if($returresp == true && !empty($artMetaId)){
                $sql5          = "update task_level_art_metadata set REMARKS='".$remarks."' where ART_METADATA_ID IN(".$artMetaId.") ";
                $updateTable5  = DB::update( $sql5 );
            }
            
            $jbStgObj               =        new jobStage();
            $getjobstageInfo        =        $jbStgObj->getCurrentJobStageInfo( $metaid , $roundId , 27 );

            if( count( $getjobstageInfo ) ){

                $stageinfo     =    isset( $getjobstageInfo[0] ) ? $getjobstageInfo[0] : $getjobstageInfo;
                $jbstgId        =   $stageinfo->JOB_STAGE_ID;
                $stgmgObj       =    new stageMangerController();
                $stgmgObj->manageWaitngForParallelProcessUpdate( $jbstgId );
            }
        }
        
        return $returresp;
        
    }
    
    public function prepareInputForStorePrQcError( $basicInput ){
        
        $jobid          =   $basicInput['jobId'];        
        $metaid         =   $basicInput['metaid'];
        $jobstgid       =   $basicInput['jbstgid'];
        $lastmodBy      =   $basicInput['userid'];
        $roundId        =   $basicInput['roundid'];
        $volumeissue    =   $basicInput['volumeissue'];
        
        $returns_arr['JOB_ID']    =   $jobid;
        
        if( isset( $artmetaid ) && empty( $artmetaid ) ){
            $returns_arr['TASK_LEVEL_ART_METADATA_ID']    =   $artmetaid;
        }
        
        $time   =   date( 'Y-m-d H:i:s' );
        $returns_arr['TASK_LEVEL_METADATA_ID']    =   $metaid;
        $returns_arr['JOB_STAGE_ID']    =   $jobstgid;
        $returns_arr['ROUND_ID']        =   $roundId;
        $returns_arr['CREATED_DATE']    =   $time;
        $returns_arr['CREATED_BY']      =   $lastmodBy;
        $returns_arr['LAST_MOD_DATE']   =   $time;
        $returns_arr['LAST_MOD_BY']     =   $lastmodBy;
        
        if( isset( $volumeissue ) && empty( $volumeissue ) ){
            $returns_arr['VOLUME_ISSUE']    =   '';
        }
  
        
        return $returns_arr;
        
    }
    
}

 