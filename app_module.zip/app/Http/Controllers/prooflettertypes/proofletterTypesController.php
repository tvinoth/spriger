<?php
namespace App\Http\Controllers\prooflettertypes;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\proofLetterTypesModel;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Validation\Rule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use Session;
use Mail;
use Storage;
use Carbon\Carbon;
use Validator;
use File;
use DB;
use Log;
use Config;

class proofletterTypesController extends Controller
{    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        parent::__construct();
            $this->loginUserId  =   Session::get('users')['user_id'];
            $this->teamId       =   Session::get('users')['team_id'];
            $this->roleId       =   Session::get('users')['role_id'];
            $this->empId        =   Session::get('users')['emp_id'];
            $this->userName     =   Session::get('users')['user_name'];
            $this->roleName     =   Session::get('users')['role_name'];
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    //EMAIL REMAINDER SETUP PAGES
    public function index(Request $request){
        $data               =   array();
        $data['pageTitle']  = 	'Proof Letter Setup';
        $data['pageName']   =   'Proof Letter Setup';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data["userId"]     =   Session::get('users')['user_id'];
        $getId              =   $request->input('emailstageid');
        return view('proof-letter-types.aps_proof-letter-types')->with( $data );
    }
    
    public function dogetproofletterlist(Request $request)
    {
        $response               =   [];
        $data                   =   proofLetterTypesModel::active()->get();
        $response["emaillist"]  =   $data;
        $response["userId"]     =   Session::get('users')['user_id'];
        return response()->json($response);
    }
    
    public function doAddnewproofsetup(Request $request)
    {      
        try
        {
            $response           =   array('result'=>400,'errMsg'=>'Bad request method','validation'=>'');
            if($request->method()   ==  "POST")
            {
                $validation 	=   Validator::make($request->all(), [
                                                                            'emailsubject' => 'required',
                                                                            'emailbody' => 'required',
                                                                            'Typeofrequest' => 'required'
                                                                    ]);
                if ($validation->fails())
                {
                    $response 	=	array('result'=>400,'errMsg'=>'All fields are required','validation'=>$validation->errors());
                    return response()->json($response,400);
                }
                $Typeofrequest  =   trim($request->input('Typeofrequest'));
                $subject        =   trim($request->input('emailsubject'));
                $emailbody      =   strtolower($request->input('emailbody'));
                $getexistidofemailstageid   =   "";
                if($Typeofrequest   ==  "update")
                {
                    $getexistidofemailstageid   =   trim($request->input('existId'));
                    if (empty($getexistidofemailstageid))
                    {
                        $response 	=	array('result'=>400,'errMsg'=>'Invalid data, kindly retry!','validation'=>'');
                        return response()->json($response,400);
                    }
                    $wheredata              =   ['PROOF_NAME'=>$subject];
                    $existupdateroundstage  =   proofLetterTypesModel::Active()->where($wheredata)->where('ID','<>',$getexistidofemailstageid)->first();
                    if(count($existupdateroundstage)>=1)
                    {
                        $response       =	array('result'=>400,'errMsg'=>'Proof Name is already exists!','validation'=>'');
                        return response()->json($response,400);
                    }
                }
                
                //check exist round and stage
                $wheredata          =   ['PROOF_NAME'=>$subject];
                $existproof         =   proofLetterTypesModel::Active()->where($wheredata)->first();
                if(count($existproof)>=1 && $Typeofrequest     ==  "insert")
                {
                    $response       =	array('result'=>400,'errMsg'=>'Proof Name is already exists!','validation'=>'');
                    return response()->json($response,400);
                }
                
                if($Typeofrequest     ==  "insert")
                {
                    $datainsert['PROOF_NAME']   =   $subject;
                    $datainsert['BODY']         =   $emailbody;
                    $datainsert['CREATED_BY']   =   $this->loginUserId;
                    $datainsert['CREATED_AT']   =   Carbon::now();
                    $storeresponse              =   proofLetterTypesModel::insertGetId($datainsert);
                    if($storeresponse>=1)
                    {
                        $response 	=	array('result'=>200,'status'=>1,'errMsg'=>'Proof Letter setup is added successfully','validation'=>'');
                        return response()->json($response);
                    }
                    $response 	=	array('result'=>400,'errMsg'=>'Proof Letter setup is failed! try again','validation'=>'');
                    return response()->json($response,400);
                }
                if($Typeofrequest     ==  "update")
                {
                    $emailcontent       =   proofLetterTypesModel::where('ID',$getexistidofemailstageid)->first();
                    if(count($emailcontent)>=1)
                    {
                        $updatedata['PROOF_NAME']   =   $subject;
                        $updatedata['BODY']         =   $emailbody;
                        $updatedata['UPDATED_BY']   =   $this->loginUserId;
                        $updatedata['UPDATED_AT']   =   Carbon::now();
                        
                        $storeresponse      =   proofLetterTypesModel::where('ID',$getexistidofemailstageid)->update($updatedata);
                        if($storeresponse>=1)
                        {
                            $data       =   proofLetterTypesModel::Active()->where('ID',$getexistidofemailstageid)->first();
                            $response 	=   array('result'=>200,'status'=>1,'errMsg'=>'Proof Letter setup isupdated successfully','validation'=>$data);
                            return response()->json($response);
                        }
                        $response 	=	array('result'=>400,'errMsg'=>'Unable to update, Kindly try again','validation'=>'');
                    }
                    $response           =	array('result'=>400,'errMsg'=>'Error! invalid data!','validation'=>'');
                }
                $response               =	array('result'=>400,'errMsg'=>'Error! invalid data!','validation'=>'');
            }
            return response()->json($response,400);
        }
        catch(\Exception $e )
        {
            $response 	=	array('result'=>400,'errMsg'=>$e->getMessage(),'validation'=>'');
            return response()->json($response);
        }
    }
    
    public function doViewproofcontent(Request $request) 
    {
        try{
            $validation     =   Validator::make($request->all(), [
                                                    'emailstageid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                return response()->json($result);
            }
            $getId              =   $request->input('emailstageid');
            $emailcontent       =   proofLetterTypesModel::find($getId);
            if(count($emailcontent)>=1)
            {
                $result     =   array('result'=>200,'status'=>1,'errMsg'=> htmlspecialchars($emailcontent->BODY));   
                return response()->json($result);
            }
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Data not found');   
            return response()->json($result);
        }catch( \Exception $e ){
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Invalid data sending');   
            return response()->json($result);
        }
    }
    
    public function doDelete(Request $request) 
    {
        try{
            $validation     =   Validator::make($request->all(), [
                                                    'emailstageid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>401,'status'=>401,'errMsg'=>$validation->errors());   
                return response()->json($result);
            }
            $getId              =   $request->input('emailstageid');
            $emailcontent       =   proofLetterTypesModel::find($getId);
            if(count($emailcontent)>=1)
            {
                $updated        =   proofLetterTypesModel::where('ID',$emailcontent->ID)->update(['IS_ACTIVE'=>'0']);
                if($updated)
                {
                    $result     =   array('result'=>200,'status'=>1,'errMsg'=>'Record deleted successfully');   
                }else{
                    $result     =   array('result'=>200,'status'=>1,'errMsg'=>'Record not deleted successfully');   
                }
                return response()->json($result);
            }
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Data not found');   
            return response()->json($result);
        }catch( \Exception $e ){
            $result         =   array('result'=>401,'status'=>0,'errMsg'=>'Invalid data sending');   
            return response()->json($result);
        }
    }
    
}