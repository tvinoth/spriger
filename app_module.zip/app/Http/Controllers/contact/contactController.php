<?php

    namespace App\Http\Controllers\contact;

    use App\Http\Controllers\Controller;
    use App\Models\projectModel;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Redirect;
    use Session;
    use Validator;
    use PDF;
    use DB; 
    use Illuminate\Http\Response;
    use Excel;
    use Carbon\Carbon;
    use Illuminate\Support\Facades\Storage;
    use File;
    use App\Http\Controllers\Api\MetaExtractorController;
    use App\Http\Controllers\CommonMethodsController;
    use Config;
    
    class contactController extends Controller
    {
        public function __construct() {
            parent::__construct();
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
        
        public function index(){
             
            $data= array();
            $this->displayMenuName(Config::get('menuconstants.MENU.CONTACT_IMPORT'),$data);
            $data['user_name'] =  $this->userName;
            $data['role_name'] =  $this->roleName;
            $data['role_id']   =  $this->roleId;
            $data['downloadUrl']   =  url('downloadContactTemplate');
            $data['productionLocation']     =       \App\Models\productionLocationModel::getlocationofPmDetails();
            $data['locationList']           =       \App\Models\productionLocationModel::getProductionLocationList();
            return view('project.Contact-list')->with($data);
            
        }
        
        public function insert( Request $request ){
           
            $rules['contact_name']      =       'required';
            $rules['contact_email']     =       'required';
            $rules['location_id']       =       'required';
            
            $response   =   $this->oopsErrorResponse;
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['errMsg']      =       'Required field validation error occured.';
                
            }else{
            
                $in_data                             =       array();
                $in_data['contact_name']             =       $request->input( 'contact_name' );
                $in_data['contact_email']            =       $request->input( 'contact_email' );
                $in_data['location_id']              =       $request->input( 'location_id' );
                //$in_data['location_name']            =       $request->input( 'location_name' );
                $in_data['created_date']             =       date('Y-m-d H:i:s');
                $in_data['created_by']               =       $this->loginUserId;
               
                try{
                    
                    $insertId   =    DB::table('contact_details')->insertGetId( $in_data );
                    $response   =   $this->insertedResponse;
                }catch( \Exception $e ){                  
                                      
                }
                                
            }
            
             echo json_encode( $response );    
        }  

        public function getList( Request $request ){
            
            $response       =       array();
            
            $response['contacts']       =       \App\Models\contactDetailsModel::getContactInformation();
            
            echo json_encode( $response , true);
            
        }
        
        public function update( Request $request ){
            
            $inpArray = array();
            
            $rules['contactId']        =       'required';
            $rules['contactName']      =       'required';
            $rules['contactEmail']     =       'required';
            $rules['locationId']       =       'required';
            $response   =   $this->oopsErrorResponse;
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['errMsg']      =       'Required field validation error occured.';
                
            }else{
            
                $inpArray['ID']              =   $request->input('contactId');	
                $inpArray['CONTACT_NAME']    =   $request->input('contactName');	
                $inpArray['CONTACT_EMAIL']   =   $request->input('contactEmail');	
                $inpArray['LOCATION_ID']     =   $request->input('locationId');
                $user_info                           =       ( $request->session()->get('users') );
                $inpArray['user_id']         =   $this->loginUserId;

                $result     =        \App\Models\contactDetailsModel::updateContact( $inpArray );     
                $response   =   $this->insertedResponse;            
            }
            
            return response()->json($response); 		
                
        }
        
        public static function doUpdatepmlocation(Request $request){
            $locationid     =   $request->input('pmlocationid');
            $pmid           =   $request->input('pmid');
            $validation     =   Validator::make($request->all(), [
                                                                'pmlocationid' => 'required|numeric'
                                                            ]);
            if($validation->fails())
            {
                return response()->json($this->oopsErrorResponse,404);
            }
            $updatedata             =   ['PRODUCTION_AREA'=>$locationid,'LAST_MOD_DATE'=>Carbon::now(),'LAST_MOD_BY'=>$this->loginUserId];
            if(!empty($pmid))
            {
                $updatepmlocation   =   DB::table('pm_location_mapping')->where('ID', '=', $pmid)->update($updatedata);
            }else{
                //check exist id
                $wheredata          =   ['PROJECT_MANAGER_ID'=>$this->loginUserId,'STATUS'=>'ACTIVE'];
                $existpmrec         =   DB::table('pm_location_mapping')->where($wheredata)->first();
                if(count($existpmrec)   ==  0)
                {
                    $insertdata['PROJECT_MANAGER_ID']   =   $this->loginUserId;
                    $insertdata['PRODUCTION_AREA']      =   $locationid;
                    $insertdata['STATUS']               =   'ACTIVE';
                    $insertdata['CREATED_DATE']         =   Carbon::now();
                    $insertdata['CREATED_BY']           =   $this->loginUserId;
                    $updatepmlocation   =   DB::table('pm_location_mapping')->insertGetId($insertdata);
                }else{
                    $updatedata             =   ['PRODUCTION_AREA'=>$locationid,'LAST_MOD_DATE'=>Carbon::now(),'LAST_MOD_BY'=>$this->loginUserId];
                    $updatepmlocation   =   DB::table('pm_location_mapping')->where('ID', '=', (count($existpmrec)>=1?$existpmrec->ID:''))->update($updatedata);
                }
            }
            if($updatepmlocation)
            {
                return response()->json($this->updatedResponse,200);
            }
            return response()->json($this->updatedFailedResponse,404);
        }

        public function delete( Request $request ){
            
            $rowid          =       $request->input( 'ID' );
            $response       =       [];
            //$rowid          =       40;
            
            if( !empty( $rowid ) ){
                $response   =       \App\Models\contactDetailsModel::deleteContact( $rowid );
            }
            $response               =   $this->deletedResponse;
            return response()->json($response); 		
        }
        
        public function uploadExcel(){
            $response       =   $this->oopsErrorResponse;
            $response['errMsg'] =   'Excel upload got Failed. Try again';
            try{
                $currentDir     =   storage_path()."\\contactimport\\";
                $fileName       =   "contact_input_".date("YmdHis").".xlsx";
                $fileSavePath   =   $currentDir.$fileName;
                
                if(!File::exists($currentDir)) {
                    File::makeDirectory( $currentDir , 0777 , true ); 
                }      
                
                $getconetent    =   file_get_contents('php://input');                
                $uploadstatus         =   file_put_contents( $fileSavePath , file_get_contents('php://input') );
                
                if( $uploadstatus ){ 
                    $response               =   $this->successResponse;
                    $response['fileName']   =   $fileName;  
                    $response['errMsg']     =   'Successfully uploaded';
                }else{                    
                }               
                
            }catch( \Exception $e ){               
                $response['reason']    =   $e->getMessage();
                return response()->json( $response );                
            }            
                     
            return response()->json( $response );                   
            
        }
        
        public function importDataFromExcel( Request $request ){      
            
            $rowCnt = 0; $invalid = 0; $errMsg = ""; $errRows = ""; $importArray = array();
            $response       =   $this->oopsErrorResponse;
            $response['errMsg'] =   'insertion Failed , check the input file or try again after sometimes';
            
            $fileName       =       $request->input( 'fileName' );  
            $userId         =       $this->loginUserId;
            
            $currentDir         =       storage_path()."\\contactimport\\";;	
            $fileSavePath       =       $currentDir.$fileName;
            $filterArr          =       array ( DB::RAW( 'LOWER(LOCATION_NAME) as low_location_name' )  , 'LOCATION_NAME'  , 'ID' );
            $allLocations       =       array();
            
            $allLocations       =       \App\Models\locationModel::getLocationListWithFilter( $filterArr );
            $locationIdCollect  =       array();
          
            if( !empty( $allLocations ) ){
                foreach( $allLocations as $key => $value ){
                    $value  =  (array)$value;
                    $locationIdCollect[$value['low_location_name']]        =       $value['ID'];
                }
            }
           
            //Excel reader used in laravel
            Excel::load( $fileSavePath , function( $reader ) use (&$importArray , $userId, $fileName , &$invalid, &$rowCnt, &$errMsg, &$errRows , $locationIdCollect ) {
                
                $results = $reader->get();
                $results = $reader->all()->toArray();	
                
                if( count( $results ) == 0 ){
                    $insertResponse   =   array( 'status' => 0  , 'msg' => 'insertion Failed , check the input file or try again after sometimes' );  
                    return response()->json( $insertResponse );
                }
               
                foreach( $results as $key => $records ){
              
                    $input_array        =       array();
                    $input_array['CONTACT_NAME']      =   $records['name'];
                    $input_array['CONTACT_EMAIL']      =   $records['email'];
                    $lIndex         =           strtolower($records['location']);                    
                    $input_array['LOCATION_ID']         =       array_key_exists( $lIndex , $locationIdCollect ) ? $locationIdCollect[$lIndex] : '';
                    $input_array['STATUS']      =       1;
                    $input_array['CREATED_DATE']    =       date('Y-m-d H:i:s');
                    $user_info      =       $this->loginUserId;
                    $input_array['CREATED_BY']      =       $user_info;               
                    array_push( $importArray , $input_array );
                }
                
            });
           
            $tblname           =        'contact_details';
            
            try{ 
                
                DB::beginTransaction();
                $insertStatus     =       DB::table( $tblname )->insert( $importArray );
               
                if( $insertStatus && count($importArray) != 0 ){
                    
                    DB::commit();
                    $response   =   $this->insertedResponse;
                    
                    if( $insertStatus ){            
                        unlink($fileSavePath);
                    } 
                    
                }  
                
            } catch (\Exception $ex) {           
               
                DB::rollBack();
                $failure_rec        =   array();
                $succesRec          =   array();
                
                $this->failureHandlingOfBulkImport($importArray , $failure_rec , $succesRec );
                
                $response['errMsg'] =   'insertion Failed , check the input file or try again after sometimes';
                $response['failures']   =   json_encode( $failure_rec );
                $response['reason']     =   "";
                
                if( count( $succesRec ) ){
                    
                    $otherparams    =   array(  'totalrecords'      =>  count( $importArray ) ,
                                                'successrecords'    =>  count( $succesRec ) , 
                                                'failurerecords'    =>  count( $failure_rec ) 
                                        );
                    
                    $otherparams['successList']     =   $succesRec;
                    $otherparams['failureList']     =   $failure_rec;
                    
                    $design_params              =    $this->designTheContatImportResponse( $otherparams );
                    $response                   =   $this->successResponse;
                    $response['msg']            =   'Partially contact information imported successfully';
                    $response['otherParams']    =   $design_params;       
                }
                
            }
            
            return response()->json( $insertResponse );   
            
        }
        
        public function designTheContatImportResponse( $otherparams ){
            
            $successlist   =    $this->getLiDesign( $otherparams['successList'] );
            $failurelist     =    $this->getLiDesign( $otherparams['failureList'] );
            
            $design =       '<div class="col-md-12">
                
                                <div class="col-md-12"> <h1>Import report </h1></div>
                                
                                <div class="col-md-12"> 
                                    <div class="col-md-12"> 
                                        <span> Total no of records : </span> <span> '.$otherparams['totalrecords'].' </span>
                                    </div>
                                    <div class="col-md-12">     
                                        <span> Success Count : </span> <span> '.$otherparams['successrecords'].' </span>
                                    </div>
                                    <div class="col-md-12"> 
                                        <span> Failure Count : </span> <span> '.$otherparams['failurerecords'].' </span>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">                                
                                    <div class="col-md-6">
                                        <div class="col-md-6"> 
                                            <h4> Succss List </h4>
                                        </div>
                                        <div class="col-md-5 pull-right">
                                        <ul>'.$successlist.'</ul>
                                        </div>
                                    </div>

                                    <div class="col-md-6>
                                        <div class="col-md-6">
                                            <h4>Failure List</h4>
                                        </div>
                                        <div class="col-md-5 pull-right">
                                            <ul>'.$failurelist.'</ul>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>';
            
            return $design;
            
        }
        
        public function getLiDesign( $recArr    =   array() ){
            
            if( !empty( $recArr ) ){
                
                $returnstr      =   '';
                
                foreach( $recArr as $key => $value ){
                    
                    $returnstr.='<li>'.  json_encode( $value ).'</li>';
                    
                }
                
                return $returnstr;
                
            }
            
            return '';
        }
        
        
        public function failureHandlingOfBulkImport( $importArray , &$failed_rec , &$succesRec ){

            //bulk import failure handling
            
           //$failed_rec     =   array();

            if( count($importArray) ){
                
            $tblname    =   'contact_details';
            
                foreach( $importArray as $key => $value ){
                    
                    $row    =   $key+1;
                        
                    try{
                        DB::beginTransaction();
                        $individual_insert_status   =   DB::table( $tblname )->insert( $value );
                       
                    } catch (\Exception $ex) {   
                        DB::rollback();  
                        
                        $failed_rec[$row]['user']   =   $value['CONTACT_NAME'];                        
                        unset( $importArray[$key] );
                        $this->failureHandlingOfBulkImport($importArray, $failed_rec , $succesRec);
                        return false;
                        
                    }
                    
                    if( $individual_insert_status ){
                        DB::commit();
                        $succesRec[$row]['user'] = $value['CONTACT_NAME'];
                        unset( $importArray[$key] );
                    }
                    
                }

            }
            
            return $failed_rec;
            
        }
		
		
        public function getContactInromationPm( $jobid , $round , $return = 'xml' ){
            
            $metaExtObj     =       new MetaExtractorController();
            $xmlreturn      =       ( $return == 'xml' ) ? true : false;
            
            $returnarray    =       $metaExtObj->getContactInromationPm( $jobid, $round , $xmlreturn );
            
            return $returnarray;
            
        }
        
    }