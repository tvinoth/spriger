<?php
namespace App\Http\Controllers\transaction;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\userdefinedmenuModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;

class transactionController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
	public function index() {
        $data = array();
        $userid = $this->loginUserId;
        $roleid = $this->roleId;
//        $mastermenu         =   userdefinedmenuModel::getmainmenutransaction($roleid);
        $mastermenu = userdefinedmenuModel::getmainmenu($roleid);
//        $menutransaction    =   userdefinedmenuModel::getmenutransaction($roleid);
        $menutransaction = userdefinedmenuModel::getmainmenuchild($roleid);
        $dataofchild = [];
        $childname = [];
        if (count($menutransaction) >= 1) {
            foreach ($menutransaction as $key => $value) {
                if (strpos($value->TRANSACTION_NAME, '>>') !== false) {
                    $childname = explode('>>', $value->TRANSACTION_NAME);
                    $dataofchild[$key]['TRANSACTION_NAME'] = $childname[0];
                    $dataofchild[$key]['NAME'] = $childname[1];
                    $getSubMenuList = userdefinedmenuModel::getmainmenusubchild($dataofchild[$key]['TRANSACTION_NAME'] . '>>' . $dataofchild[$key]['NAME'] . '>>', $roleid,3);
                    $subMenuListArr = [];
                    $subMenuName = [];
                    if (count($getSubMenuList) > 0) {
                        $dataofchild[$key]['SUBCHILDNAMEAVAILABLE'] = true;
                        foreach ($getSubMenuList as $sMKey => $sMValue) {
                            if (strpos($sMValue->TRANSACTION_NAME, '>>') !== false) {
                                $subMenuName = explode('>>', $sMValue->TRANSACTION_NAME);
                                $subMenuListArr[$sMKey]['sMTRANSACTION_NAME'] = $subMenuName[0];
                                $subMenuListArr[$sMKey]['sMNAME'] = $subMenuName[1];
                                $subMenuListArr[$sMKey]['SUBCHILDNAME'] = $subMenuName[2];
                                $subMenuListArr[$sMKey]['sMPACKAGE_DISPLAY_ORDER'] = $sMValue->PACKAGE_DISPLAY_ORDER;
                                $subMenuListArr[$sMKey]['sMCODE'] = $sMValue->CODE;
                                $subMenuListArr[$sMKey]['sMCHILD_NAME'] = $sMValue->IS_CHECK_ACTIVE_NAME;
                                $subMenuListArr[$sMKey]['sMURL'] = $sMValue->URL;
                            }
                        }
                    }
                    $dataofchild[$key]['SUBCHILDNAMEARR'] = $subMenuListArr;
                } else {
                    $dataofchild[$key]['TRANSACTION_NAME'] = $value->TRANSACTION_NAME;
                    $dataofchild[$key]['NAME'] = $value->TRANSACTION_NAME;
                    $dataofchild[$key]['SUBCHILDNAMEAVAILABLE'] = false;
                }
                $dataofchild[$key]['PACKAGE_DISPLAY_ORDER'] = $value->PACKAGE_DISPLAY_ORDER;
                $dataofchild[$key]['CODE'] = $value->CODE;
                $dataofchild[$key]['CHILD_NAME'] = $value->IS_CHECK_ACTIVE_NAME;
                $dataofchild[$key]['URL'] = $value->URL;
            }
        }
        $result = array('result' => 1, 'errMsg' => 'Get Menu is successfully', 'menulilst' => $mastermenu, 'childmenu' => $dataofchild);
        return response()->json($result);
    }
	
    public function old_index()
    {
	$data               =   array();
        $userid             =   Session::get('users')['user_id'];
        $roleid             =   Session::get('users')['role_id'];
//        $mastermenu         =   userdefinedmenuModel::getmainmenutransaction($roleid);
        $mastermenu         =   userdefinedmenuModel::getmainmenu($roleid);
//        $menutransaction    =   userdefinedmenuModel::getmenutransaction($roleid);
        $menutransaction    =   userdefinedmenuModel::getmainmenuchild($roleid);
        $dataofchild        =   [];
        $childname          =   [];
        if(count($menutransaction)>=1)
        {
            foreach($menutransaction as $key=>$value)
            {
                if(strpos($value->TRANSACTION_NAME,'>>') !== 	false){
                    $childname                      =   explode('>>',$value->TRANSACTION_NAME);
                    $dataofchild[$key]['TRANSACTION_NAME']  =   $childname[0];
                    $dataofchild[$key]['NAME']      =   $childname[1];
                }else
                {
                    $dataofchild[$key]['TRANSACTION_NAME']  =   $value->TRANSACTION_NAME;
                    $dataofchild[$key]['NAME']      =   $value->TRANSACTION_NAME;
                }
                $dataofchild[$key]['PACKAGE_DISPLAY_ORDER']     =   $value->PACKAGE_DISPLAY_ORDER;
                $dataofchild[$key]['CODE']          =   $value->CODE;
                $dataofchild[$key]['CHILD_NAME']    =   $value->IS_CHECK_ACTIVE_NAME;
                $dataofchild[$key]['URL']           =   $value->URL;
            }
        }
        $result             =   array('result'=>1,'errMsg'=>'Get Menu is successfully','menulilst'=>$mastermenu,'childmenu'=>$dataofchild);   
        return response()->json($result);
    }
}