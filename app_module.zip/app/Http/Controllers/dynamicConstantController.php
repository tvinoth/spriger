<?php
namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Http\Controllers\dynamicConstantController;
//use App\Models\requiredConstants;
use App\Models\errorConstantModel;
use Illuminate\Http\Request;
use DB; 
use Config;

class dynamicConstantController extends Controller
{   
    public function __construct() {
//        $this->setAllRequiredConstants();
        $this->setDynamicErrorConstant();
    }
    
    /*public function getDynamicRequiredConstants(){
        
        $const_Obj      =       new requiredConstants();
        $returnConst    =       array();
        
        $const_Obj->getRequiredConstantsAll( null , $returnConst );
        
        if( !empty( $returnConst ) ){
            return $returnConst;
        }
        return array();   
    }
     
    public function setAllRequiredConstants(){
        $setArray_prepare       =       array();
        $returnConst            =       array(); 
        $const_Obj      =       new requiredConstants();
        $const_Obj->getRequiredConstantsAll( null , $returnConst );
        
        //NEED TO CHANGE IT FROM MULTIPLE RECORDS TO SINGLE JSON FORMATE CONSTANT STORE
        
        if( !empty( $returnConst ) ){
            //$this->setDynamicConstant( $returnConst );
        }
    }*/
    
    public function setDynamicConstant( $returnConst , $nameofparent = null ){

        foreach( $returnConst as $index_ => $value ){
            if( !is_array( $value ) && is_null($nameofparent) ){
                if( is_null( $nameofparent ) ){
                    $setArray_prepare["$index_"]      =   $value;
                    \Config::set("requiredconstants.$index_" , $value );
                }
            }else if( is_array( $value ) ){
                $this->setDynamicConstant( $value , $index_ );
            }else if( !is_null($nameofparent ) ){
                \Config::set("requiredconstants.$nameofparent.".$index_ , $value );
            }
        }

    }
    
    public function setDynamicErrorConstant(){
        $returnConst   =   errorConstantModel::Active()->get();
        if(count($returnConst)>=1){
            foreach( $returnConst as $index_ => $value ){
                $setvalue   =   ['status'=>$value->STATUS,'result'=>$value->RESULT,'msg'=>$value->MSG,'errMsg'=>$value->ERROR_MSG,'xmlcount'=>0];
                \Config::set("errorconstants.$value->ERROR_CODE" , $setvalue );
            }
        }
    }
    
    
}