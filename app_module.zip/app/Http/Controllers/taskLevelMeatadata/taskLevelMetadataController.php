<?php
namespace App\Http\Controllers\taskLevelMeatadata;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\chapterPartMapModel;
use App\Models\jobTimeSheet;
use App\Models\jobsheetViewpathModel;
use App\Models\bookinfoModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\ceEstimationController;
use App\Http\Controllers\production\movetoproductionController;
use App\Http\Controllers\Api\esmFileNameController;
use Session;
use Config;
use Storage;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 

class taskLevelMetadataController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        parent::__construct();
            $this->loginUserId  =   Session::get('users')['user_id'];
            $this->teamId       =   Session::get('users')['team_id'];
            $this->roleId       =   Session::get('users')['role_id'];
            $this->empId        =   Session::get('users')['emp_id'];
            $this->userName     =   Session::get('users')['user_name'];
            $this->roleName     =   Session::get('users')['role_name'];
        $this->middleware(function ($request, $next) {
           /*/ if (Session::has('users') == '') {
                return redirect('/');
            }*/
            return $next($request);
        });
    }
    
    public function insertChapterInfo($metadata)
    {
        //connect ftp
        $ftpObj     = 	Storage::createFtpDriver([
                                                    'host'     => Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST'), 
                                                    'username' => Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME'),
                                                    'password' => Crypt::decryptString(Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD')), // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                                ]);
        $ceestimationserverDir          =   \Config::get('constants.CE_ESTIMATION_FOLDER').$jobID;
        $serverDirFiles 		=   $ftpObj->allFiles($ceestimationserverDir);
        if(count($serverDirFiles)>=1)
        {
            //check Job ID IS EXIST
            $checkexist                 =   taskLevelMetadataModel::checkexistjob($jobID);
            
            if(count($checkexist)>=1)
            {
                $jobID 			=   $checkexist->JOB_ID;
                $bookid 		=   $checkexist->BOOK_ID;
                if(count($serverDirFiles)   >=  1)
                {
                    $jsonfiles          =	[];
                    
                    foreach($serverDirFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter 		=   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                    $splitname 		=   explode('.',$spiltchapter);
                                    $jsonfiles[$key] 	=   trim($splitname[0]);
                            }
                            else{
                                    $jsonfiles[$key] 	=   trim($spiltchapter);
                            }
                        }

                        else if(strpos($jsonvalue,'.') !== false)
                        {
                                $splitname 		=   explode('.',$jsonvalue);
                                $jsonfiles[$key] 	=   trim($splitname[0]);
                        }
                        else{
                                $jsonfiles[$key] 	=   trim($jsonvalue);
                        }
                    }
                    
                    //end foreach
                    $addresult 		=   taskLevelMetadataModel::doAddTaskLevelmetadata($jsonfiles,$jobID,$bookid);
                    if($addresult['result'] >= 1)
                    {
                        $response 	=   array('result'=>201,'msg'=>'Chapter is Added Successfully',
                                                                'existchapter'=>$addresult['chapter']);
                        return response()->json($response);
                    }
                    else
                    {
                        $response 	=   array('result'=>400,'msg'=>'Chapter is Not Added Successfully Kindly try again',
                                                                    'existchapter'=>$addresult['chapter']);
                        return response()->json($response);
                    }
                }
                $response 	=	array('result'=>404,'msg'=>'Chapter is not available for '.$bookid.' Book Id Try Again.');
                return response()->json($response);
            }
            $response 	=	array('result'=>404,'msg'=>$bookid.' Job Id is not exist with Books Try Again.');
            return response()->json($response);
        }
        $response 	=	array('result'=>404,'msg'=>'Directory is empty');
        return response()->json($response);
    }
    
    public function doChapterInfoOpen( $jobID 	=	null  , $src_path )
    {
       
        //connect ftp
        $bookdetails        =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobID)
                                            ->get()->first();            
           
        $book_id            =   $data['book_id'] =      $bookdetails['BOOK_ID'];
            
        $root               =   \Config::get('constants.FILE_SERVER_ROOT_DIR');
        $ftp_path_          =   \Config::get('constants.SPLIT_DESTINATION_PATH');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
       
        //ftp connection location job
        $getlocationftp     =   productionLocationModel::doGetLocationname( $jobID );            
       // echo "<pre>";print_r($getlocationftp);exit;
        //need to dynamicaly bind the production location based on table location

        $hostserver         =   $getlocationftp->FTP_HOST;
        $hostusername       =   $getlocationftp->FTP_USER_NAME;
        $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =   ( $getlocationftp->FTP_PATH );
        
        $chapter_path       =   $src_path;
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        
        $esmPath      =   $src_path.'ESM/';
        $esmFiles     =   $ftpObj->getDirectoryFiles( $esmPath );
        $esmChapter    =    array();
        if(!empty($esmFiles)){
            foreach($esmFiles as $esKey => $esmfiles){
               $esm     =    explode('/',$esmfiles);
               $esmChapter[] = end($esm);
            }
        } 
       
        $serverDirFiles     =   $ftpObj->getDirectoryFiles( $chapter_path );
        //echo "<pre>";print_r($serverDirFiles);exit;
        if(!empty($serverDirFiles)){
            $input              =   preg_quote('.json', '~');
            $result             =   preg_grep('~' . $input . '~', $serverDirFiles);
            if(empty($result)){
               $response 	=	array('result'=>404,'status'=>0,'msg'=>'Json file not found');
               return $response;
            }
            $jsonfileData       =   '';
            
            foreach($result as $key3 => $path){
                $filePath       =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver.$path;
                $jsonfileData   =   file_get_contents($filePath);
               
                if(!empty($jsonfileData)){
                   $jsonfileData =  json_decode($jsonfileData);
                   break;
                }
            }
            
             if( empty( $jsonfileData ) || !$jsonfileData ){
                
                $sJson = json_encode( $jsonfileDatasrc , JSON_UNESCAPED_SLASHES ); 
                $sJson = str_replace('\\"', '"', $sJson);
                $sJson = str_replace('"{', '{', $sJson);
                $sJson = str_replace('}"', '}', $sJson);

                $jsonfileData =  json_decode($sJson,true);
                if(is_array( $jsonfileData )){
                    $temp_convert     = json_encode( $jsonfileData, JSON_FORCE_OBJECT);
                    $jsonfileData = json_decode($temp_convert);
                }
               
            }
          
            if(!empty($jsonfileData)){
                $pageData['FM1']        = array();
                $pageData['Chapter']    = array();
                $pageData['Part']       = array();
                $pageData['BM1']        = array();
                
                
                foreach($jsonfileData->OutputFile as $key1=> $spdata){
                  
                    if($spdata->Component == 'FM'){
                        $pageData['FM1'][] = $spdata;
                    }
                    
                    if($spdata->Component == 'CHAPTER' || $spdata->Component == 'Chapter'){
                        $pageData['Chapter'][] = $spdata;
                    }
                    
                    if($spdata->Component == 'PART'){
                        $pageData['Part'][] = $spdata;
                    }
                    
                    if($spdata->Component == 'BM'){
                        $pageData['BM1'][] = $spdata;
                    }
                    
                }
                
                
                $chaptername  = array();
                $pageCount      =   0;
                $partnames      =   array();

                if(!empty($pageData['FM1'])){
                    
                    foreach($pageData['FM1']  as $key3 => $fm){
                        
                        $fmdata['chapter']      =   $fm->Component.'1';
                        $fmdata['sequence']     =   count($chaptername) +1;
                        $fmdata['title']        =   (isset($fm->Title)?$fm->Title:'');
                        $fmdata['filename']     =   (isset($fm->FileName)?$fm->FileName:'');
                        $fmdata['pagecount']     =   $fm->PageCount;
                        $chaptername[]          =   $fmdata;
                        $pageCount              =   $pageCount + $fm->PageCount;
                        
                    }
                    
                    foreach($pageData['Chapter']  as $key3 => $fm){
                  
                        $fmdata['chapter']      =   $fm->Component.'_'.$fm->Number;
                        $fmdata['sequence']     =   count($chaptername) +1;
                        $fmdata['title']        =   (isset($fm->Title)?$fm->Title:''); 
                        $fmdata['filename']     =   (isset($fm->FileName)?$fm->FileName:'');
                        $fmdata['part']         =   strtoupper((isset($fm->Part)?'Part_'.$fm->Part:'')); 
                        $fmdata['pagecount']     =   $fm->PageCount;
                        $chaptername[]          =   $fmdata;
                        $pageCount              =   $pageCount + $fm->PageCount;
                        
                    }
                  
                    foreach($pageData['Part']  as $key3 => $fm){
                        
                        $fmdata['chapter']      =   $fm->Component.'_'.$fm->Number;
                        
                        $partnames[]            =   $fmdata['chapter'];
                        $fmdata['sequence']     =   count($chaptername) +1;
                        $fmdata['title']        =   (isset($fm->Title)?$fm->Title:'');
                        $fmdata['filename']     =   (isset($fm->FileName)?$fm->FileName:'');
                        $fmdata['pagecount']     =   $fm->PageCount;
                        $chaptername[]          =   $fmdata;
                        $pageCount              =   $pageCount + $fm->PageCount;
                        
                    }
                    
                    foreach($pageData['BM1']  as $key3 => $fm){
                        
                        $fmdata['chapter']      =   $fm->Component.'1';
                        $fmdata['sequence']     =   count($chaptername) +1;
                        $fmdata['title']        =   (isset($fm->Title)?$fm->Title:'');
                        $fmdata['filename']     =   (isset($fm->FileName)?$fm->FileName:'');
                        $fmdata['pagecount']     =   $fm->PageCount;
                        $chaptername[]          =   $fmdata;
                        $pageCount              =   $pageCount + $fm->PageCount;
                        
                    }
                    
                }
               
                if(count($chaptername) == 0)
                    {
                        $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                            'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                            'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                        $jts_obj                =   new jobTimeSheet;
                        $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                        if(count($checkstatustimesheet)>=1)
                        {
                            $data               =   [];
                            $data['STATUS']     =   1;
                            $ues    =   jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                        }
                    }
                
                
                $response 	=   array('result'=>200,'status'=>1,'msg'=>'Chapter is Opened Successfully',
                                                        'jobID'=>$jobID,
                                                        'chapternames'=>$chaptername,
                                                        'partnames'=>$partnames,
                                                        'esm'=>$esmChapter,
                                                        'totalpages'=>$pageCount,
                                                        'Book_id'=>$book_id);
                
                
                return $response;
                
            }else{
                $response 	=	array('result'=>404,'status'=>0,'msg'=>'Not able to read the json file');
            }
            
             return $response;
        }else{
            $response 	=	array('result'=>404,'status'=>0,'msg'=>'Directory is empty');
            return $response;
        }
     
        
      /*  
      //  echo "<pre>";print_r($serverDirFiles);exit;
        if(count($serverDirFiles)>=1)
        {
            //check Job ID IS EXIST
            $checkexist                 =   taskLevelMetadataModel::checkexistjob($jobID);
            if(count($checkexist)>=1)
            {
                $jobID 			=   $checkexist->JOB_ID;
                $bookid 		=   $checkexist->BOOK_ID;
                if(count($serverDirFiles)   >=  1)
                {
                    $splitname          =   "";
                    $chapterfiles       =   [];
                    $frontmatterfiles   =   [];
                    $backmatterfiles    =   [];
                    $chaptercount       =   [];
                    $partfiles          =   [];
                    $originalchapter    =   "";
                    $spiltchapter       =   "";
                    $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                    $readfilepart       =   Config::get('constants.READ_TYPEOF_PART');
                    $readallfile        =   Config::get('constants.READ_CHAPTER_EXTENSTION');
                    $readfrontmatter    =   Config::get('constants.FRONT_MATTER');
                    $readbackmatter     =   Config::get('constants.BACK_MATTER');
                    foreach($serverDirFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readfrontmatter))
                                {
                                    $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                                    if(in_array($originalchapter,$readfileextenstion))
                                    {
                                        $splitname          =   explode('.',$spiltchapter);
                                        $frontmatterfiles[$key] =   trim($splitname[0]);
                                        $chaptercount[$key] =   trim($splitname[0]);
                                    }
                                }
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readallfile))
                                {
                                    $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                                    if(in_array($originalchapter,$readfileextenstion))
                                    {
                                        $splitname          =   explode('.',$spiltchapter);
                                        $chapterfiles[$key] =   trim($splitname[0]);
                                        $chaptercount[$key] =   trim($splitname[0]);
                                    }
                                }
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readfilepart))
                                {
                                    $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                                    if(in_array($originalchapter,$readfileextenstion))
                                    {
                                        $splitname          =   explode('.',$spiltchapter);
                                        $chapterfiles[$key] =   trim($splitname[0]);
                                        $partfiles[]        =   trim($splitname[0]);
                                    }
                                }
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readbackmatter))
                                {
                                    $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                                    if(in_array($originalchapter,$readfileextenstion))
                                    {
                                        $splitname          =   explode('.',$spiltchapter);
                                        $backmatterfiles[$key] =   trim($splitname[0]);
                                        $chaptercount[$key] =   trim($splitname[0]);
                                    }
                                }
                            }
                        }
                    }
                    $chaptersort        =   natcasesort($chapterfiles);
                    $partsort           =   natcasesort($partfiles);
                    $newchapterfiles    =   [];
                    $chapterseqnum      =   1;
                    $partseqnum         =   1;
                    $key                =   1;
                    foreach($frontmatterfiles   as    $value)
                    {
                        $newchapterfiles[$key]['chapter']       =   $value;
                        $newchapterfiles[$key]['sequence']      =   $chapterseqnum; 
                        $chapterseqnum++;
                        $key++;
                    }
                    foreach($chapterfiles   as    $value)
                    {
                        if(in_array(substr(strtolower($value),0,2),$readallfile))
                        {
                            $newchapterfiles[$key]['chapter']   =   $value;
                            $newchapterfiles[$key]['sequence']  =   $chapterseqnum; 
                            $chapterseqnum++;
                        }
                        if(in_array(substr(strtolower($value),0,2),$readfilepart))
                        {
                            $chpseq     =   $chapterseqnum+$partseqnum;
                            $newchapterfiles[$key]['chapter']   =   $value;
                            $newchapterfiles[$key]['sequence']  =   $partseqnum; 
                            $partseqnum++;
                        }
                        $key++;
                    }
                    foreach($backmatterfiles    as     $value)
                    {
                        $newchapterfiles[$key]['chapter']       =   $value;
                        $newchapterfiles[$key]['sequence']      =   $chapterseqnum; 
                        $chapterseqnum++;
                        $key++;
                    }
                    
                    $chapternoofcount   =   count($chaptercount);
                    $partfilenoofcount  =   count($partfiles);
                    $totalnumberofpages =   $chapternoofcount+$partfilenoofcount;
                    if(count($chapterfiles) == 0)
                    {
                        $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                            'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                            'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                        $jts_obj                =   new jobTimeSheet;
                        $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                        if(count($checkstatustimesheet)>=1)
                        {
                            $data               =   [];
                            $data['STATUS']     =   1;
                            $ues    =   jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                        }
                    }
                    $response 	=   array('result'=>200,'status'=>1,'msg'=>'Chapter is Opened Successfully',
                                                        'jobID'=>$jobID,
                                                        'chapternames'=>$newchapterfiles,
                                                        'partnames'=>$partfiles,
                                                        'totalpages'=>$totalnumberofpages,
                                                        'Book_id'=>$bookid);
                    return $response;
                }
                $response 	=	array('result'=>404,'status'=>0,'msg'=>'Chapter is not available for '.$bookid.' Book Id Try Again.');
                return $response;
            }
            $response 	=	array('result'=>404,'status'=>0,'msg'=>$bookid.' Job Id is not exist with Books Try Again.');
            return $response;
        }*/
        $response 	=	array('result'=>404,'status'=>0,'msg'=>'Directory is empty');
        return $response;
    }
	
   public function doAddChapterInfo(Request $request)
    {
        $data               =   json_decode(file_get_contents("php://input"), true);
        
        $jobID              =   $data['job_id'];
        $getinputchapters   =   $data['chapternames'];
        $getinputfilename   =   $data['chapterfiles'];
        $getchapterstitle   =   $data['chapterstitle'];
//        $getchapternumber   =   $data['chapternumber'];
        $getchapterpagecount   =   $data['chapterpagecount'];
        $getchapternumber   =   [];

        $getinputparts      =   $data['partnamesjob'];
        $chaptersequence    =   $data['chaptersequence'];
        $getesm             =   isset($data['esm'])?$data['esm']:array();
	$getchapterstitle   =   isset($data['chapterstitle'])?$data['chapterstitle']:array();
        if($jobID ==    '' && count($getinputchapters)<=0 ){
            $response 	=	array('result'=>404,'status'=>0,'msg'=>'There is no chapter files validation error occured...');
            return response()->json($response);
        }
        
        $whitespaceerror    =   [];
        if(count($getinputchapters)>=1 ){
            foreach ($getinputchapters as $name => $testcase) {
//                if (ctype_space($testcase)) {
                if (strpos($testcase,' ') !== false) {
                    $whitespaceerror[]  =   $testcase;
                }
            }
        }
        
        if(count($whitespaceerror)>= 1) {
            $response           =	array('result'=>404,'status'=>0,'msg'=>implode(',',$whitespaceerror).' ,Kindly remove unwanted space.');
            return response()->json($response);
        }

        if($data['partisavailornot']    ==  1){
            if(in_array('',$getinputparts)) {
                //$response 	=	array('result'=>404,'status'=>0,'msg'=>'All part filed is required');
                //return response()->json($response);
            }
        }
        
        if(is_array($data['deletedpartvalues']) &&  count($data['deletedpartvalues'])>=1){
            $matcheddeleteditems    =   array_intersect($data['deletedpartvalues'],$getinputparts);
            if(count($matcheddeleteditems)>= 1) {
                $response           =	array('result'=>404,'status'=>0,'msg'=>implode(',',$data['deletedpartvalues']).' part items has been removed but you are mapped part items '.implode(',',$matcheddeleteditems));
                return response()->json($response);
            }
        }
        
        $bookdetails        =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->where('job.JOB_ID',$jobID)
                                            ->get()->first();            
           
        $book_id            =   $data['book_id'] =      $bookdetails['BOOK_ID'];
            
        $root               =   \Config::get('constants.FILE_SERVER_ROOT_DIR');
        $ftp_path_          =   \Config::get('constants.SPLIT_DESTINATION_PATH');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        
        $user_info          =   ( $request->session()->get('users') );
        $user_id            =   $user_info['user_id'];
        $emp_id             =   $user_info['emp_id'];
        //need to dynamicaly bind the production location based on table location    
        //ftp connection location job
        $getlocationftp     =   productionLocationModel::doGetLocationname( $jobID );  
        $hostserver         =   $getlocationftp->FTP_HOST;
        $hostusername       =   $getlocationftp->FTP_USER_NAME;
        $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =   ( $getlocationftp->FTP_PATH );
        $crd2               =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 
        $userWorkDir        =   \Config::get('constants.USER_WORK_PATH');
        $userFinalOutput    =   $crd2.$hostserver.$hostpath.$userWorkDir.$book_id.'/out';
        $split_dest_dir     =   $hostserver.$hostpath.\Config::get('constants.SPLIT_DESTINATION_PATH');
        $esm_dest_dir       =   $hostserver.$hostpath.\Config::get('constants.EMS_DESTINATION_PATH');
                        
        $const_replace      =   array(  
                                        'USER_DIR' => $emp_id , 
                                        'ROUND_NAME' => 'S5' , 
                                        'STAGE_NAME' => \Config::get('constants.STAGE_NAME.SPLIT') ,
                                        'BOOK_ID' => $book_id
                                );
       
        foreach( $const_replace as $key => $value ){   
            $userFinalOutput    =   str_replace( $key , $value , $userFinalOutput );     
            $split_dest_dir     =   str_replace( $key , $value , $split_dest_dir );                 
        }
        
         foreach( $const_replace as $key => $value ){   
            $esm_dest_dir     =   str_replace( $key , $value , $esm_dest_dir );                 
        }
        
        $ftpObj                 =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $serverDirFiles         =   $ftpObj->getDirectoryFiles( $userFinalOutput );
        
//        $response_copy          =   $ftpObj->ftp_dir_copy_word_file_only(  $userFinalOutput , $split_dest_dir,$getinputchapters,Config::get('constants.COPY_FILE_EXTENTION.READ_WORD_EXTENSTION') );
        if(count($serverDirFiles)>=1)
        {   
            $invalidchapternamevalidation   =   array();
            
            foreach($getinputfilename as $key => $value){
                $result             =   preg_grep('~' . $value . '~', $serverDirFiles);
                
                 if(empty($result)){
                     $invalidchapternamevalidation[] = $value;
                 }
            }
            
            
            $fmpmfilesonly      =  array();
            $partfiles          =   array();
            $chapterfilesonly    =  array();
            
            foreach($getinputchapters as $key => $value){
                $exval      =    explode('_',$value);
                if($exval['0'] == 'FM1' || $exval['0'] == 'BM1'){
                    $fmpmfilesonly[] = $value;
                }
                
                if($exval['0'] == 'Chapter' || $exval['0'] == 'CHAPTER' ){
                    $chapterfilesonly[] = $value;
                }
                
                if($exval['0'] == 'Part' || $exval['0'] == 'PART'){
                    $partfiles[] = $value;
                }
            }
         
            if(!empty($invalidchapternamevalidation)){
                $response       =   array('result'=>404,'status'=>0,'msg'=> 'Below the files are missing...' ,'xmlerror'=>'',
                                                'shownotavaiablechapter'=>$invalidchapternamevalidation,'notexistdata'=>count($invalidchapternamevalidation));
                return response()->json($response);
            }
            
            
            //check Job ID IS EXIST
            $checkexist                 =   taskLevelMetadataModel::checkexistjob($jobID);
            if(count($checkexist)>=1)
            {
                $jobID 			=   $checkexist->JOB_ID;
                $bookid 		=   $checkexist->BOOK_ID;
                if(count($serverDirFiles)   >=  1)
                {
                    $splitname          =   "";
                    $chapterfiles       =   [];
                    $chaptercount       =   [];
                   // $partfiles          =   [];
                    $partfullname       =   [];
                  //  $chapterfilesonly   =   [];
                   // $fmpmfilesonly      =   [];
                    $chapternamevalidation          =   [];
                    $invalidchapternamevalidation   =   [];
                    $partnamevalidation =   [];
                    $fmbmnamevalidation =   [];
                    $invalidpartnamevalidation  =   [];
                   // $fmpmfilesonly      =   [];
                    $chapterfilesextention      =   [];
                    $docopypdfname      =   [];
                    $getallcopypdfname  =   [];
                    $pdfvalidationname  =   [];
                    $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                    $readfilepart       =   Config::get('constants.READ_TYPEOF_PART');
                    $readallfile        =   Config::get('constants.READ_TYPEOF_PM_FM');
                    $readfmpmfile       =   Config::get('constants.READ_TYPEOF_PM_FM_EXTENSTION');
                    $readchapterfile    =   Config::get('constants.READ_CHAPTER_EXTENSTION');
            
                    
                    $datacountmismatch  =   [];
                    //check job part,chapter and fm pm count 
                    $getjobdta  =   jobInfoModel::where('JOB_ID',$jobID)->first();
                    if(count($getjobdta)>=1)
                    {
                        if(count($partfiles) != $getjobdta->NO_PART_COUNT)
                        {
                            $datacountmismatch[]   =   "Part count mismatched with Job Sheet (Actual Part count in Job Sheet - ".$getjobdta->NO_PART_COUNT.")";		
                        }
                        if(count($fmpmfilesonly) != $getjobdta->NO_APAGE_COUNT)
                        {
                            $datacountmismatch[]   =   "Apage count mismatched with Job Sheet (Actual Apage count in Job Sheet - ".$getjobdta->NO_APAGE_COUNT.")";		
                        }
                        if(count($chapterfilesonly) != $getjobdta->NO_CHAPTER_COUNT)
                        {		
                            $datacountmismatch[]   =   "Chapter count mismatched with Job Sheet (Actual Chapter count in Job Sheet - ".$getjobdta->NO_CHAPTER_COUNT.")";		
                        }
                    }
                   
                    $inputchapternames      =   [];
                    $inputpartnames         =   [];
                    $inputapagenames        =   [];
                    $userinputnamesvalidation   =   [];
                  
                    // check chapter and part is exist or not
                    $chapternoofcount   =   count($chaptercount);
                    $partfilenoofcount  =   count($partfiles);
                    $totalnumberofpages =   $chapternoofcount+$partfilenoofcount;
                    
                   
                    if(count($getinputchapters)>=1)
                    {
                        $notexistdata       =   [];
                        $checkdiffchapter   =   array_diff($getinputchapters,$chapterfiles);
                        $esmData            =   array();
                        if(!empty($getesm)){
                            $notesmexistdata    =   array();
                            foreach($checkdiffchapter as $values){
                                if(in_array($values,$getesm)){
                                    $emsSorce           =   $userFinalOutput;
                                    $emsSorce           .= '/ESM/'.$values;
                                    $listfiles          =   $ftpObj->getDirectoryFiles($emsSorce);
                                    if(empty($listfiles)){
                                        $notesmexistdata[] = $values;
                                    }else{
                                        $esmData[$values] = $listfiles;
                                    }
                                }
                            }
                            if(!empty($notesmexistdata)){
                                $errRes             =   'Below Chapters ESM files not available :  ';
                                $response           =   array('result'=>404,'status'=>0,    'msg'=> $errRes , 'shownotavaiablechapter'=>$notesmexistdata,'notexistdata'=>count($notesmexistdata));
                                return response()->json($response);
                            }
                        }
                          
                       
                        if(count($checkdiffchapter) >= 1 && false)
                        {
                            foreach($checkdiffchapter as $values)
                            {
                                $notexistdata[]     =   trim($values);
                            }
                            $plural_handle      =   ' Chapter is ';                            
                            if( count( $checkdiffchapter  ) >  1 )
                                $plural_handle      =   ' Listed Chapters are ';      
                            $errRes     =   'Below '.$plural_handle .' not available :  ';
                            $response           =   array('result'=>404,'status'=>0,    'msg'=> $errRes , 'shownotavaiablechapter'=>$notexistdata,'notexistdata'=>count($notexistdata));
                            return response()->json($response);
                        }
                        else
                        {
                            $chapterexist       =   [];
                            foreach($getinputchapters as $key=>$val)
                            {
                                $checkexistchapter              =   taskLevelMetadataModel::where('JOB_ID',$jobID)->where('CHAPTER_NO',ucfirst($val))->where('IS_ACTIVE',true)->first();
                                $checkexistchapter = array();
                                if(count($checkexistchapter)>=1)
                                {		
                                    $chapterexist[]             =   ucfirst($val)." is already exist";		
                                }
                                
                            }
                            
                            if(count($chapterexist)>=1)
                            {
                                $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                                'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                                'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                                $jts_obj                =   new jobTimeSheet;
                                $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                                if(count($checkstatustimesheet)>=1)
                                {
                                    $data               =   [];
                                    $data['STATUS']     =   1;
                                    jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                                }
                                        
                                $response       =   array('result'=>404,'status'=>0,'msg'=> ' Below Listed exceptions are occured. ' ,'xmlerror'=>'',
                                            'shownotavaiablechapter'=>$chapterexist,'notexistdata'=>count($chapterexist));
                                return response()->json($response);
                            }
                            
                           
                            DB::beginTransaction();
							
                           $addnewchapter 	=   taskLevelMetadataModel::doAddTaskLevelmetadata($getinputchapters,$getchapternumber,$chaptersequence,$getinputparts,$jobID,$bookid,$getchapterstitle,$getchapterpagecount);
                           //$addnewchapter['result'] =   1;
                            if($addnewchapter['result'] >= 1 )
                            {
                                $getinputchapters   =   $data['chapternames'];
                                $getinputfilename   =   $data['chapterfiles'];
                                
                                $desfolder   = str_ireplace($hostserver,'',$split_dest_dir);
                                $esmfolder   = str_ireplace($hostserver,'',$esm_dest_dir);
                                $res         = $ftpObj->ftp_make_dir($desfolder);
                                
                                if(!empty($getesm)){
                                        $res = $ftpObj->ftp_make_dir($esmfolder);
                                }
                                
                               // echo "<pre>";print_r($getinputchapters);exit;
                                foreach($getinputchapters as $key => $chapFile){
                                    $sourcepath     =   $userFinalOutput.'/'.$getinputfilename[$key];
                                    $esmSourcepath  =   $userFinalOutput.'/ESM/'.$chapFile;
                                    $esmDestpath    =   $esm_dest_dir.$chapFile.'/';
                                    $destpath       =   $crd2.$split_dest_dir.$chapFile.'/'.$getinputfilename[$key];
                                    $copyres        =   $ftpObj->ftpSingleFileCopyOrMove(  $sourcepath , $destpath  );
                                   
                                    if(in_array($chapFile,$getesm)){
                                        $response       =       $ftpObj->ftp_dir_copy( $esmSourcepath , $esmDestpath );
                                    }
                                   
                                    if($copyres == true){
                                        $response_copy[$getinputfilename[$key]] = 'success';
                                    }else{
                                        $response_copy[$getinputfilename[$key]] = 'failed';
                                    }
                                }
                                $response   =   array();
                               
                                if( in_array( 'failed' , $response_copy ) ){

                                    foreach($response_copy as $key => $value ){
                                        if( $value == 'success' ){
                                            unset( $response[$key] );
                                        }
                                    }
                                    
                                    $response_copy   =       array( 'status' => 'failed'  , $response_copy );
                                    
                                }else{
                                    
                                    $response_copy    =       array( 'status' => 'success' , $response_copy );
                                    
                                }    
                                
                                if( $response_copy['status'] !== 'success' ){
                                    
                                    $response 	=	array( 'result'=>404 , 'status'=> 0 , 'msg' => 'File Moving got failed.., try again after some times' );
                                    DB::rollback();
                                    return response()->json($response);             
                                    
                                }else{
                                    

                                    DB::commit();
                                    
                                    if(!empty($esmData)){
                                       $esmres           =   $this->emsdataStore($esmData,$jobID);
                                    }
                            
                                    $wheredata              =       array(  'JOB_ID'    =>      $jobID  ,
                                                                            'USER_ID'   =>      Session::get('users')['user_id']    ,
                                                                            'STAGE'     =>      Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                                            'ROUND_ID'  =>      Config::get('constants.ROUND_ID.S5')
                                                                    );

                                    $jts_obj                =       new jobTimeSheet;
                                    $checkstatustimesheet   =       $jts_obj->getCheckedOutRecords($wheredata);

                                    if(count($checkstatustimesheet)>=1){
                                        $js_data['CHECK_IN']       =          date('Y-m-d H:i:s');
                                        $js_data['STATUS']         =          2;
                                        jobTimeSheet::updateIfExist($js_data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                                    }
                                        
                                }
                                
                                //CE ESTIMATION PROCESS
//                                $ceestimationresponse   =   $this->ceEstimationxmlprocess($book_id,$hostserver,$hostusername,$hostpassword,$hostpath,$jobID,$getinputchapters,$chapterfilesextention);
                                $ceestimationresponse   =   $this->ceEstimationxmlprocess($book_id,$hostserver,$hostusername,$hostpassword,$hostpath,$jobID,$getinputchapters,$getinputfilename);
                                
                                if(!empty($getesm)){
                                   $emsres          =    $this->generateEsm($jobID,$getesm);
                                }
                               
                                if($ceestimationresponse['result']  ==  200){
                                        $sendemailalert             =   app('App\Http\Controllers\Api\stagealertemailController')->doSendemailalertstage($jobID,Config::get('constants.ROUND_ID.S5'),Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),'');
                                        $successfileresponse        =   app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobID,Config::get('constants.ROUND_ID.S200'),'insert','chapter','');
                                        $jb_obj         =   new     jobModel();
                                        $job_info       =   $jb_obj->getJobdetails( $jobID );
                                        $ispar          =   $job_info['IS_PAR'];
                                        $ispar          =   ($ispar     ==  1?1:0);
                                        
                                        $movetopro      =   new movetoproductionController();
                                        $res            =   $movetopro->triggerTasklevelMoveToproduction($jobID,$this->round_ID_5);
                                        //spicast workflow process
                                        $spicastStageID    =   taskLevelMetadataModel::getspicastStageID($jobID);
                                        if(count($spicastStageID)>=1)
                                        {
                                            $spicastStId        =   $spicastStageID['0']->JOB_STAGE_ID;
                                            $roundId            =   $spicastStageID['0']->JOB_ROUND_ID;
                                            $time               =   date('Y-m-d H:i:s'); 
                                            $setArr             =   array( 'CHECK_OUT'  => $time , 'STATUS' => '23');
                                            $updateQry          =   DB::table('job_stage')
                                                                ->where('JOB_STAGE_ID', $spicastStId )
                                                                ->update( $setArr );
                                            app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobID,$roundId,'insert',$spicastStId);
                                        }
                                        //ce estimation workflow process
                                        $tasklevelModelObj  =   new taskLevelMetadataModel();
                                        $stageDetails       =   $tasklevelModelObj->getCestimationStageID($jobID);

                                        if(!empty($stageDetails)){
                                            $ceStId        =   $stageDetails['0']->JOB_STAGE_ID;
                                            $roundId       =   $stageDetails['0']->JOB_ROUND_ID;
                                            $time          = 	date('Y-m-d H:i:s'); 
                                            $setArr        =   array( 'CHECK_IN'  => $time , 'STATUS' => '23');
                                            $updateQry     =   DB::table('job_stage')
                                                                ->where('JOB_STAGE_ID', $ceStId )
                                                                ->update( $setArr );

                                            $setArr2        =   array( 'STATUS' => '23');
                                            $updateQry2     =   DB::table('job_round')
                                                                ->where('JOB_ROUND_ID', $roundId )
                                                                ->update( $setArr2 );
                                            app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobID,$roundId,'insert',$ceStId);
                                        }
                                        //cuc background process xml create
                                        $cucBackground  =   app('App\Http\Controllers\cucprocess\cucProcessController')->cucBackgroundprocess($jobID);
                                        $response       =   array(  'result'        =>      200 ,
                                                                        'status'        =>      1   ,
                                                                        'msg'           =>      'Chapter is added successfully..',
                                                                        'isPar'         =>      $ispar
                                                                     );
                                        return response()->json($response);
                                }
                                else {
                                    
                                        $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                                'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                                'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                                        $jts_obj                =   new jobTimeSheet;
                                        $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                                        if(count($checkstatustimesheet)>=1){
                                            $data               =   [];
                                            $data['STATUS']     =   1;
                                            jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                                        }
                                        $response       =   array('result'=>404,'status'=>0,'msg'=>'Error ocured in ce estimation','xmlerror'=>'',
                                            'existchapter'=>[]);
                                        return response()->json($response);
                                }
                            }
                            else
                            {
                                $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                            'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                            'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                                $jts_obj                =   new jobTimeSheet;
                                $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                                if(count($checkstatustimesheet)>=1)
                                {
                                    $data               =   [];
                                    $data['STATUS']     =   1;
                                    jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                                }
                                $response       =   array('result'=>404,'status'=>0,'msg'=>'Chapter is not added successfully try again..','xmlerror'=>'',
                                        'shownotavaiablechapter'=>$addnewchapter['chapter'],'existchaptercount'=>count($addnewchapter['chapter']));
                                    return response()->json($response);
                            }
                        }
                    }
                 
                    //update complete to incomplete
                    $wheredata              =   array('JOB_ID'=>$jobID,'USER_ID'=>Session::get('users')['user_id'],
                                                            'STAGE'=>Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'),
                                                            'ROUND_ID'=>Config::get('constants.ROUND_ID.S5'));
                    
                    $jts_obj                =   new jobTimeSheet;
                    $checkstatustimesheet   =   $jts_obj->getCheckedOutComplete($wheredata);
                    
                    if(count($checkstatustimesheet)>=1){
                        $data               =   [];
                        $data['STATUS']     =   1;
                        jobTimeSheet::updateIfExist($data,$checkstatustimesheet->JOB_TIME_SHEET_ID);
                    }
                    $response 	=	array('result'=>404,'status'=>0,'msg'=>'Chapter are empty try again..');
                    return response()->json($response);
                }
                $response 	=	array('result'=>404,'status'=>0,'msg'=>'Chapter is not available for '.$bookid.' Book Id Try Again.');
                return response()->json($response);
            }
            
            $response 	=	array('result'=>404 ,    'status'=>0 ,    'msg'   =>  $bookid.' Invalid jobid , Try Again.');
            return response()->json($response);
        }
        
        $response 	=	array('result'=>404,'status'=>0 , 'msg'=>  'Kindly check split output files , Split output Folder is empty' );
        return response()->json($response);
    }
    
    
    public function ceEstimationxmlprocess($book_id,$hostserver,$hostusername,$hostpassword,$hostpath,$jobID,$serverDirFiles,$chapterextention)
    {
        $chapternotgeneratexml  =       '';
        // check exist job id 
        $root               =   \Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
        $ceroot             =   \Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
        $ftp_path_          =   \Config::get("constants.BACKSLAH_SPLIT_DESTINATION_PATH")."\\";
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 

        $ftpObj             =   Storage::createFtpDriver([
                                    'host'     => $hostserver, 
                                    'username' => $hostusername,
                                    'password' => $hostpassword, 
                                    'port'     => '21',
                                    'timeout'  => '30',
                                ]);
        if(!empty($serverDirFiles)) 
        {
            $apicedata                  =	[];
            $apicedata['JOB_ID']        =	$jobID;
            $apicedata['ROUND']         =	Config::get('constants.ROUND_ID.S5');
            $apicedata['START_TIME']    =	Carbon::now();
            $apicedata['STATUS']        =	true;
            $apicedata['CREATED_AT']    =	Carbon::now();
            $apicedata['XML_STATUS']    =       '0';
            $baseurl                    =	url('/').'/api/apiceEstimationDoToolresponse';
            foreach($serverDirFiles as $chapternno) 
            {
                //get metaid 
                $getmetaId 		=       apiCeestimationModel::checkexistMetaId($jobID,trim($chapternno));
                if(empty($getmetaId))
                {
                    $chapternotgeneratexml  .=  $chapternno.',';
                }
            }
            $chapternotgeneratexml      =       rtrim($chapternotgeneratexml,',');                    
            $addnewcestimation          =	apiCeestimationModel::doAdd($apicedata);
            if(count($addnewcestimation) >= 1)
            {	
                $xml 	= 	new \XMLWriter();
                $xml->openMemory();
                $xml->startDocument();
                $xml->startElement('Metadata');
                $xml->setIndent(true);
                $xml->startElement('Files');
                foreach($serverDirFiles as $key=>$files) 
                {
                    //get metaid 
                    $getmetaId 			=   apiCeestimationModel::checkexistMetaId($jobID,trim($files));
                    if(count($getmetaId) >= 1)
                    {
                        $xml->startElement("File"); 
                        $xml->writeAttribute("file_id", $getmetaId->METADATA_ID); 
                        $xml->text("\\"."\\".$hostserver.$ceroot.$root.$ftp_path_.$book_id.'\\'.Config::get('constants.STAGE_NAME.SPLIT').'\\'.$files.'\\'.$chapterextention[$key]);
                        $xml->endElement();  
                    }else
                    {
                        $xml->startElement("File"); 
                        $xml->text('');
                        $xml->endElement();  
                    }
                }
                $xml->endElement();
                $xml->startElement('Workflow');
                //url parameter
                $xml->startElement('Url');
                $xml->writeAttribute('value', $baseurl);
                $xml->writeAttribute('method', "post");
                $xml->endElement();

                //id parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "token");
                $xml->writeAttribute('type', "fixed");
                $xml->writeAttribute('value', $addnewcestimation->TOKEN);
                $xml->endElement();

                //status parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "status");
                $xml->endElement();

                //end time parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "end_time");
                $xml->writeAttribute('value', "Y-m-d H:m:i");
                $xml->writeAttribute('type', "fixed");
                $xml->endElement();

                //jobid parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "job_id");
                $xml->writeAttribute('value', $addnewcestimation->JOB_ID);
                $xml->writeAttribute('type', "fixed");
                $xml->endElement();

                //round parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "round");
                $xml->writeAttribute('value', $addnewcestimation->ROUND);
                $xml->writeAttribute('type', "fixed");
                $xml->endElement();

                //remarks parameter
                $xml->startElement('parameter');
                $xml->writeAttribute('key', "remarks");
                $xml->writeAttribute('value', '');
                $xml->endElement();

                $xml->endElement();
                $xml->endElement();
                $xml->endDocument();

                $content 	= 	$xml->outputMemory();
                $filename 	=	$book_id.'_METAXML.xml';
                $successfileresponse 	=	$ftpObj->put(Config::get('constants.WATCH_CE_ESTIMATION_FOLDER').'/'.$filename, $content);   
                if($successfileresponse ==     true)
                {
                    $updatedata =   [];
                    $updatedata['XML_STATUS']   =   '1';
                    apiCeestimationModel::where('ID',$addnewcestimation->ID)->update($updatedata);
                }
                $response 	=	array(  'result'  =>    200   ,   'msg'=>'Success' , 'status' => 1,'errorxml'=>$chapternotgeneratexml );
                return $response;
            }		
            $response 	=	array('result'  =>  404 ,'msg'=>'Error occured try again.' , 'status' => 0 ,'errorxml'=>$chapternotgeneratexml );
            return $response;
        }
        $response 	=	array( 'result'=>404,'msg'=>'Directory is empty' , 'status' => 0 ,'errorxml'=>$chapternotgeneratexml  );
        return $response;
    }
    
    public function buildTasklevelInsertData( $insertdata ){
    
            extract( $insertdata );
            
            $round_arr      =           \Config::get( 'constants.ROUND_ID');
            $insert_arr         =       array();
            
            $insert_arr['JOB_ID']           =       $job_id;
            $insert_arr['CHAPTER_NO']       =       $chapter_no;
            $insert_arr['CHAPTER_NAME']     =       $chapter_name;
            $insert_arr['QUANTITY']         =       isset( $quantity ) ? $quantity : 1;
            $insert_arr['UNIT_OF_MEASURE']  =       isset( $unit_of_measure )  ? $unit_of_measure : 70;
            $insert_arr['COMPLEXITY']       =       isset( $complexity ) ? $complexity : 1; 
            $insert_arr['IS_BILLABLE']      =       isset( $is_billable ) ? $is_billable :  1;
            $insert_arr['IS_NEW_FILE']      =       isset( $is_new_file ) ?  $is_new_file : 0;
            $insert_arr['IS_ACTIVE']        =       isset( $is_active ) ? $is_active : 1;
            $insert_arr['CREATED_DATE']     =       isset( $created_date ) ? $created_date : date( 'Y-m-d H:i:s' );
            //$insert_arr['CREATED_BY']       =       isset( $created_by ) ? $created_by : '';
            $insert_arr['CURRENT_ROUND']    =       isset( $current_round ) ? $current_round : $round_arr['S5']; 
            $insert_arr['CURRENT_STAGE']    =       $current_stage;
            $insert_arr['STATUS_ENUM_ID']   =       isset( $status_enum_id ) ? $status_enum_id : 5;  
            //$insert_arr['CURRENT_QUANTITY'] =       1;
            $insert_arr['CURRENT_ITERATION']=       1;
            //$insert_arr['CASTOFF_PAGE']     =       1;
            $insert_arr['REVISION_NO']      =       1;
            
            //echo 'insert into task_level_metadata ( `'.implode( '`,' , array_keys( $insert_arr ) ).'` ,  ) values ( "'.implode( '",' , array_values( $insert_arr ) ).'" , )';
        return $insert_arr;
        
    }
    
    public function generateEsm($jobid, $esmdata=array()){
        $cmn_obj            =   new CommonMethodsController();
        $ref_pdf_data       =   ['jobid'   =>  $jobid,'emschapter'=>$esmdata];
        $ref_url            =   url('/').'/api/esmvalidation';
        $postreferencepdf   =   $cmn_obj->PostcUrlExecution($ref_pdf_data,$ref_url);
        return $postreferencepdf;
    }
    
    public function emsdataStore($esmData,$jobID){
        
        if(empty($esmData))
            return false;
        $esmfiletype        =   Config::get('constants.ESM_FILE_TYPE');
        $chapterDetails  = array_keys($esmData);
        foreach($esmData as $key => $value){
        
            $metaDetails   =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID'))
                                ->where('task_level_metadata.JOB_ID',$jobID)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                ->where('task_level_metadata.CHAPTER_NO',$key)
                                ->get(); 
           $metaData        =    $metaDetails[0];
           $metaId          =    $metaData->METADATA_ID;
           
           $setArr             =   array( 'TYPE_OF_CONTAINESM'  => 'YES');
           $updateQry          =   DB::table('metadata_info')
                                        ->where('METADATA_ID', $metaId )
                                        ->update( $setArr );
           
           $createdDate     =   date( 'Y-m-d H:i:s' );
           foreach($value as $mvfile){
              
              $filepath = explode('/',$mvfile);
              $filename = end($filepath);
              $filetypes = explode('.',$filename);
                       
                $mvdata['FILE_TYPE']             = 'others';
                if(!empty($filetypes['1'])){
                   $mvdata['FILE_FORMAT']             = $filetypes['1']; 
                   if(in_array($filetypes['1'],$esmfiletype)){
                           $mvdata['FILE_TYPE']             = 'video'; 
                   }else{
                       $mvdata['FILE_TYPE']             = 'others';
                       $mvdata['IS_VALID']             = '3';
                   }
                } 
               $mvdata['JOB_ID']            = $jobID;
               $mvdata['METADATA_ID']       = $metaId;
               $mvdata['ROUND']             = '104';
               $mvdata['ORGINAL_FILE_NAME'] = $filename;
               $mvdata['CREATED_DATE']      = $createdDate;
               $mvdata['CREATED_BY']        = $this->loginUserId;
               $inserid                     =   DB::table('metadata_esm')->insertGetId( $mvdata );
           }
        }
       return true;
      
    }
    
    public function createDynamicComponents( $jobId , $round ){
        
        $getComponentCrt    =       DB::select( 'SELECT NAMING_CONVENTION , COMPONENT_TYPE FROM books_component_creation WHERE ROUND_ID = '.$round.' AND STATUS = 1' );
        $metaid_arr         =       array();
        
        if( count( $getComponentCrt ) ){
            
            foreach(  $getComponentCrt as $keyi => $valueCmp ){
                $newmeata           =       false;
                $comptype           =       $valueCmp->COMPONENT_TYPE;
                $cmpname            =       $valueCmp->NAMING_CONVENTION;
                $metainformation    =       DB::select( 'SELECT METADATA_ID FROM task_level_metadata where CHAPTER_NO LIKE "%'.$cmpname.'%" AND JOB_ID = '.$jobId.' limit 1' );
                if( count( $metainformation ) ){
                    $metainformation=       $metainformation[0];
                    $newmeata       =       $metainformation->METADATA_ID;
                }else{
                    $newmeata       =       $this->insertNewComponent( $jobId , $round , $cmpname , $comptype  );
                }
                if( $newmeata ){
                    $metaid_arr[]   =       $newmeata;
                }
            }
            
        }
        
        return $metaid_arr;
        
    }
    
    public function insertNewComponent( $jobID , $rounid , $chpno , $comptype = null ){
        
        if( !empty($jobID) && !empty( $chpno ) ){
            $user_info          =       Session::get('users');
            $userid             =       $user_info['user_id'];
            if(empty($userid)) {
                $userid = Config::get('constants.ADMIN_USER_ID');
            } 
            $getCoverInfo   =   DB::table('task_level_metadata')->select('METADATA_ID')
                                                        ->where( 'JOB_ID' , '=' , $jobID )
                                                        ->where( 'CHAPTER_NO'  , 'LIKE' , '%'.$chpno.'%' )->get();

            if( count( $getCoverInfo ) == 0  ){

                $taskmetadata['CHAPTER_NO']     =   ucfirst($chpno);
                $taskmetadata['CHAPTER_NAME']   =   ucfirst($chpno);
                $taskmetadata['UNIT_OF_MEASURE']=   \Config::get('constants.CHAPTER_ENUM_ID');//chapter unit_enum id
                $taskmetadata['CURRENT_ROUND']  =   $rounid;//\Config::get('constants.ROUND_ID.S600');//chapter unit_enum id
                $taskmetadata['JOB_ID']         =   $jobID;
                $taskmetadata['IS_ACTIVE']      =   true;
                $taskmetadata['CREATED_DATE']   =   Carbon::now();
                $taskmetadata['CREATED_BY']     =   Session::get('users')['user_id'];
                $addresult                      =   DB::table('task_level_metadata')->insertGetId($taskmetadata);

                $insertrec                      =   array(  
                                                        'METADATA_ID'   =>      $addresult ,
                                                        'LAST_MOD_DATE' =>      Carbon::now(),
                                                        'LAST_MOD_BY'   =>      $userid
                                                    );
                
                if( !is_null( $comptype ) ){
                    $insertrec['FM_ARTICLE_BM']     =       $comptype;
                }else{
                    $insertrec['FM_ARTICLE_BM']     =       \Config::get('constants.ARTICLE_COVER');
                }
                
                //insert meta info details
                $insertMiStatus       =       DB::table('metadata_info')->insert($insertrec);        

            }else{

                return false;

            }

            return $addresult;
        }
        
        return false;
        
    }
    
}