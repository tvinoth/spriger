<?php
namespace App\Http\Controllers\taskLevelMeatadata;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\bookinfoModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Config;
use Storage;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
use App\Models\newComponent;
use App\Models\roundModel;
use App\Models\componentCategoryModel;


class newComponentController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        
        parent::__construct();
        
        $this->loginUserId  =   Session::get('users')['user_id'];
        $this->teamId       =   Session::get('users')['team_id'];
        $this->roleId       =   Session::get('users')['role_id'];
        $this->empId        =   Session::get('users')['emp_id'];
        $this->userName     =   Session::get('users')['user_name'];
        $this->roleName     =   Session::get('users')['role_name'];
            
        $this->middleware(function ($request, $next) {
            return $next($request);
        });
        
    }
    
    public function getComponentInfoByJobid( $jobid ){
        
        $response   =  $this->oopsErrorResponse;
        
        try{

            $newCmpMObj     =       new newComponent();
            $comprec        =       $newCmpMObj->getRecordsByJobId( $jobid );
            
            $roundEnum      =       new roundModel();
            $select_arr     =       array( 'ID' , 'NAME' );
            $roundinfo      =       $roundEnum->getAllRoundInfo($select_arr);
            
            $componCat      =       new componentCategoryModel();
            $component      =       $componCat->getComponentList();
            
            
            $response['status'] =   1;
            $response['msg']    =   'success';
            $response['errMsg'] =   '';
            $response['result'] =   '200';
            
            $response['compolist']   =   $comprec;
            $response['roundinfo']   =   $roundinfo;
            $response['components']   =   $component;
            
        
        }catch(\Exception $e){
            
            $response       =   $this->oopsErrorResponse;
            $response['status'] =   0;
            $response['msg']    =   'failed';
            $response['result'] =   '401';
            $response['errMsg'] =   '';
            
            return response()->json( $response );
        }
        
        return response()->json( $response );
    }
    
    public function createDynamicComponents( $jobId , $round ){
        
        $newCmpMObj         =   new newComponent();
        $getComponentCrt    =   $newCmpMObj->getRoundBasedComponetInformation( $round );
        //$getComponentCrt    =       DB::select( 'SELECT NAMING_CONVENTION , COMPONENT_TYPE FROM books_component_creation WHERE ROUND_ID = '.$round.' AND STATUS = 1' );
        
        $metaid_arr         =       array();
        
        if( count( $getComponentCrt ) ){
            
            foreach(  $getComponentCrt as $keyi => $valueCmp ){
                
                $newmeata           =       false;
                $comptype           =       $valueCmp->COMPONENT_TYPE;
                $cmpname            =       $valueCmp->NAMING_CONVENTION;
                $metainformation    =       DB::select( 'SELECT METADATA_ID FROM task_level_metadata where CHAPTER_NO LIKE "%'.$cmpname.'%" AND JOB_ID = '.$jobId.' limit 1' );
                
                if( count( $metainformation ) ){
                    $metainformation=       $metainformation[0];
                    $newmeata       =       $metainformation->METADATA_ID;
                }else{
                    $newmeata       =       $this->insertNewComponent( $jobId , $round , $cmpname , $comptype  );
                }
                
                if( $newmeata ){
                    $metaid_arr[]   =       $newmeata;
                }
                
            }
            
        }
        
        return $metaid_arr;
        
    }
    
    public function insertNewComponent( $jobID , $rounid , $chpno , $comptype = null ){
        
        if( !empty($jobID) && !empty( $chpno ) ){
            
            $user_info          =       Session::get('users');
            $userid             =       $user_info['user_id'];
            if(empty($userid)) {
                $userid = Config::get('constants.ADMIN_USER_ID');
            } 
            $getCoverInfo   =   DB::table('task_level_metadata')->select('METADATA_ID')
                                                        ->where( 'JOB_ID' , '=' , $jobID )
                                                        ->where( 'CHAPTER_NO'  , 'LIKE' , '%'.$chpno.'%' )->get();

            if( count( $getCoverInfo ) == 0  ){

                $taskmetadata['CHAPTER_NO']     =   ucfirst($chpno);
                $taskmetadata['CHAPTER_NAME']   =   ucfirst($chpno);
                $taskmetadata['UNIT_OF_MEASURE']=   \Config::get('constants.CHAPTER_ENUM_ID');//chapter unit_enum id
                $taskmetadata['CURRENT_ROUND']  =   $rounid;//\Config::get('constants.ROUND_ID.S600');//chapter unit_enum id
                $taskmetadata['JOB_ID']         =   $jobID;
                $taskmetadata['IS_ACTIVE']      =   true;
                $taskmetadata['CREATED_DATE']   =   Carbon::now();
                $taskmetadata['CREATED_BY']     =   Session::get('users')['user_id'];
                $addresult                      =   DB::table('task_level_metadata')->insertGetId($taskmetadata);

                $insertrec                      =   array(  
                                                        'METADATA_ID'   =>      $addresult ,
                                                        'LAST_MOD_DATE' =>      Carbon::now(),
                                                        'LAST_MOD_BY'   =>      $userid
                                                    );
                
                if( !is_null( $comptype ) ){
                    $insertrec['FM_ARTICLE_BM']     =       $comptype;
                }else{
                    $insertrec['FM_ARTICLE_BM']     =       \Config::get('constants.ARTICLE_COVER');
                }
                
                //insert meta info details
                $insertMiStatus       =       DB::table('metadata_info')->insert($insertrec);        

            }else{

                return false;

            }

            return $addresult;
        }
        
        return false;
        
    }
    
    public function createComponentFortheJob( Request $request ){
        
        $validator_rule =   array( 
            'job_id'    =>  'required|numeric', 
            'round'     =>  'required|numeric' , 
            'componame' =>  'required|max:50' ,  
            'compotype' => 'required|numeric' , 
            'descrip'   => 'required|max:250' , 
            'workflow' => 'nullable'
        );
        
        $validation     =   Validator::make( $request->all() , $validator_rule );
        
        if( $validation->fails() ){
            
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            
        }else{
            
            //insert records
            $insert_arr     =   new newComponent();
            $insert_arr['JOB_ID']       =   $request->input( 'job_id' );
            $insert_arr['ROUND_ID']     =   $request->input( 'round' );
            $insert_arr['NAMING_CONVENTION']    =   $request->input( 'componame' );
            $insert_arr['COMPONENT_TYPE']   =   $request->input( 'compotype' );
            $insert_arr['DESCRIPTION']      =   $request->input( 'descrip' );
            $insert_arr['STATUS']   =       1;
            $insert_ret                     =       $insert_arr->save();//::insertNew( $insert_arr );
            
            if( $insert_ret ){
               $response    =   $this->insertedResponse;
            }else{
               $response    =   $this->insertedFailedResponse;
            }
           
            return response()->json( $response );
            
        }
        
    }
    
    public function updateComponentInfoFortheJob( Request $request ){
        
        $validator_rule =   array( 
            'job_id'    =>  'required|numeric', 
            'id'        =>  'required|numeric', 
            'round'     =>  'required|numeric' , 
            'componame' =>  'required|max:50' ,  
            'compotype' =>  'required|numeric' , 
            'descrip'   =>  'required' , 
            'workflow'  =>  'nullable' , 
            'status'    =>  'required'
        );
        
        $validation     =   Validator::make( $request->all() , $validator_rule );
        
        if( $validation->fails() ){
            
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            
        }else{
            
            $newCmpMObj         =       new newComponent();
            
            //insert records
            $rowid              =       $request->all( 'id' );
            $update_arr['JOB_ID']       =   $request->input( 'job_id' );
            $update_arr['ROUND_ID']     =   $request->input( 'round' );
            $update_arr['DESCRIPTION']  =   $request->input( 'descrip' );
            $update_arr['NAMING_CONVENTION']    =   $request->input( 'componame' );
            $update_arr['COMPONENT_TYPE']       =   $request->input( 'compotype' );
            $update_arr['STATUS']   =       $request->input( 'status' );
            
            $updateSts              =       newComponent::updateIfExist( $update_arr , $rowid );
            
            if( $updateSts ){
               $response            =       $this->updatedResponse;
               $response['result']  =       200;
            }else{
               $response            =       $this->updatedFailedResponse;
               $response['result']  =       404;
            }
            
            return response()->json( $response );
            
        }
    }
    
    public function deleteComponentOfTheJob( Request $request ){
        
        $validator_rule =   array( 
            'id'    =>  'required|numeric', 
        );
        
        $validation     =   Validator::make( $request->all() , $validator_rule );
        
        if( $validation->fails() ){
            
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            return response()->json($response);
            
        }else{
            
            //
            $response           =       $this->deletedFailedResponse;
            $newCmpMObj         =       new newComponent();
            $rowid              =       $request->input( 'id' );
            $setArr['STATUS']   =       '3';
            $returnsts          =       $newCmpMObj->updateIfExist( $setArr , $rowid );
            
            if( $returnsts ){
                $response       =       $this->deletedResponse;
            }
            
            return response()->json( $response );
            
        }
    }
    
    
}