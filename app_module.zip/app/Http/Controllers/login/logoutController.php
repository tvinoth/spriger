<?php

namespace App\Http\Controllers\login;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\LoginUserHistoryModel;
use Illuminate\Support\Facades\Redirect;
use Session;
use Carbon\Carbon;
use DB; 

class logoutController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function logout(){
        //update login status 
        if (Session()->has('users')) {
            $userid         =   Session::get('users')['user_id'];
            $updatedata     =   ['LOGIN_CURRENT_STATUS'=>'0'];
            $wheredata      =   ['USER_ID'=>$userid];
            $updatestatus   =   UserModel::where($wheredata)->update($updatedata);           
            $updatehistory  =   ['LOGOUT_TIME'=>Carbon::now()];
            LoginUserHistoryModel::where($wheredata)->orderBy('ID', 'desc')->update($updatehistory);
        }
        Session::forget('users');
		Session::flush();
        Redirect::to('/')->send();          
     }    
}