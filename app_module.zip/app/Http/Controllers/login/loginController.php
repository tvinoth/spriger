<?php

namespace App\Http\Controllers\login;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Models\LoginUserHistoryModel;
use Illuminate\Support\Facades\Redirect;
use Config;
use Session;
use Validator;
use Carbon\Carbon;
use DB;

class loginController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        if (!Session::has('users')) {

            // Redirect::to('/dashboard')->send();
        }
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
        
        if (!Session::has('users')) {
            // Redirect::to('/dashboard')->send();
        }
        
        $data = array();
        $data['pageTitle'] = 'Login';
        $data['pageName'] = 'Login';
        return view('login.login')->with($data);
    }
    
    public function updateExpiredUserCrendentials( Request $request ){
        
        try {
            
            $response   =   [];
            
            //header("Access-Control-Allow-Origin: http://localhost:4200");
            //header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH");
            //header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, X-CSRF-TOKEN, x-xsrf-token");
            //print_r($_POST);print_r($_REQUEST);print_r($_GET);
            
            if ($request->input()) {
                
                $rules = array();
                
                $rules['username']      =       'required';
                $rules['curpass']       =       'required';
                $rules['newpass']       =       'required';
                $rules['cnfpass']       =       'required';
                $rules['domain_type']   =       'required';
                
                $validator  =   Validator::make( $request->all() , $rules );
                
                if ( $validator->fails() ) {
                    
                    $response['status'] =   0;
                    $response['msg']    =   'failed';
                    $response['errMsg'] =   'Required field validation error occured';
                    
                    return response()->json( $response );
                }
				$encrypted =  base64_decode(urldecode($request->input('password')));
                $user_name      =   $request->input('username');
                $encpassword    =   md5( $request->input('curpass') );
                $password       =   $request->input('newpass');
                $domain_type    =   $request->input('domain_type');
                
                $wheredata = [ "b.LOGIN_ID" => $user_name , "b.PASSWORD" => $encpassword, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE') ];
                
                if ($domain_type == "spi" || $domain_type ==    "spidom") {
                    
                    $loginResponse = $this->loginLdapService($user_name, $password,$domain_type);
                    
                } else {
                    
                    $loginResponse = $this->loginMagnusService($wheredata);
                    
                }

                if ($loginResponse != false ) {
                    
                    if($domain_type == "spi" || $domain_type ==    "spidom"){
                        $data = ["b.LDAP_USER_NAME" => $user_name, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE')];
                    }
                    else{
                        $data = ["b.LOGIN_ID" => $user_name, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE')];
                    }
                    
                    $result     =   UserModel::verifyLogin($data);
               
                    if ($result->count() >= 1) {
                        
                        if( isset( $result->user_id ) ){
                            $userid =   $result->user_id;
                        }
                        
                        if( isset( $result[0]->user_id ) ){
                            $userid =   $result[0]->user_id;
                        }
                        
                        $this->updateCredentials( $request ,  $userid , $response );
                        
                    }else{
                        
                        $response['status']     =   0;
                        $response['msg']        =   'failed';
                        $response['errMsg']     =   'Invalid username';
                        
                    }
                    
                } else {
                    
                    $response['status']     =   0;
                    $response['msg']        =   'failed';
                    $response['errMsg']     =   'Current password is invalid.';
                    
                }
                
                return response()->json($response);
                
            }
            
        } catch (Exception $e) {
            
            $response['errMsg']     =   $e->getMessage();
            
            $response['msg']        =   'failed';
            $response['status']     =   0;
            
            return response()->json($response);
        }
        
    }
    
    public function updateCredentials( $request  , $userid , &$response ){
        
        $time       =   date("Y-m-d H:i:s"); 
        $currentpwd =   md5($request->input('curpwd'));
        $newpwd     =   md5($request->input('cnfpass') );
        
        $sqlQrySmtPH        =       "SELECT * FROM password_history WHERE newpassword = '".$newpwd."' AND user_id =  ".$userid." ORDER BY ph_id DESC LIMIT 4";
        $recordset          =       DB::select( $sqlQrySmtPH );
        
        if( count( $recordset ) == 0 ){
            
            try{
                
                DB::beginTransaction();
                
                    $clientpassHist     =   DB::insert(
                                                "INSERT INTO password_history SET user_id = ".$userid.",
                                                oldpassword = '".$currentpwd."',
                                                newpassword = '".$newpwd."',
                                                createddate = '".$time."',			
                                                modified_by = ".$userid." "
                                            );

                    $sql_username_pwd   =   DB::update("update user_credential SET PASSWORD='".$newpwd."',LAST_MOD_DATE='".$time."',LAST_MOD_BY='".$userid."' WHERE INTERNAL_USER_ID='".$userid."'");

                DB::commit();
                
                $response['status']     =       1;
                $response['msg']        =       'success';
                $response['errMsg']     =       'Password successfully updated.';
            
            }catch( \Exception $e ){
                
                DB::rollback();
                
                $response['status']     =       0;
                $response['msg']        =       'failed';
                $response['errMsg']     =       'Something went wrong , try again after sometimes !.';
                
                throw new Exception( $response['errMsg'] );
                
            }
            
					
        }else{
            $response['status']     =       0;
            $response['msg']        =       'failed';
            $response['errMsg']     =       'Already this password had been used..';
        }
        
	
    }
    
    public function login(Request $request) {
        
        try {
            $response = [];
            //header("Access-Control-Allow-Origin: http://localhost:4200");
            //header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, PATCH");
            //header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization, X-CSRF-TOKEN, x-xsrf-token");
            //print_r($_POST);print_r($_REQUEST);print_r($_GET);
            if ($request->input()) {
				
				/*$key = pack("H*", "0123456789abcdef0123456789abcdef");
				$iv =  pack("H*", "abcdef9876543210abcdef9876543210");
				//$encrypted = urldecode(base64_decode($request->input('password')));
				
				$encrypted =  base64_decode(urldecode($request->input('password')));
				echo $encrypted;exit;
				$decpass =  trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $key, $encrypted, MCRYPT_MODE_CBC, $iv));
				*/
                $rules = array();
				$encrypted =  base64_decode(urldecode($request->input('password')));
				
                $rules['user_name'] = 'required';
                $rules['password'] = 'required';
                $rules['domain_type'] = 'required';
                $validator = Validator::make($request->all(), $rules);
				
                if ($validator->fails()) {
                    $response['status'] = Config::get('constants.STATUS_ENUM.ONE');
                    $response['msg'] = 'Validation Error';
                    $response['errMsg'] = 'Invalid username or password';
                    return response()->json($response);
                }

                $user_name = $request->input('user_name');
                $encpassword    =   md5($encrypted);
                $password       =   $encrypted;
                $domain_type    =   $request->input('domain_type');
                //            $data['remember_me']=   $request->input('remember_me');

                $wheredata = ["b.LOGIN_ID" => $user_name, "b.PASSWORD" => $encpassword, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE')];
                if ($domain_type == "spi" || $domain_type ==    "spidom") {
                    $loginResponse = $this->loginLdapService($user_name, $password,$domain_type);
                } else {
                    $loginResponse = $this->loginMagnusService($wheredata);
                }
                
                if ($loginResponse != false) {
                    
                    if($domain_type == "spi" || $domain_type ==    "spidom"){
                        
                        $data = ["b.LDAP_USER_NAME" => $user_name, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE')];
                        $isExpired  =   false;
                        
                    } else {
                        
                        $data           =       ["b.LOGIN_ID" => $user_name, "a.IS_ACTIVE" => Config::get('constants.STATUS_ENUM.ONE')];
                        $result         =       UserModel::verifyLogin($data);        
                        
                        if ($result->count() >= 1) {
                            $isExpired      =       $this->checkCredentialExpired( $result[0]->user_id );
                        }
                        
                    }
                    
                    if( !$isExpired ){
                        $setSessioncommon = $this->setLoginsession($data, $response, $request);
                    }else{
                        $response['status'] =   3;
                        $response['msg']    =   'failed';
                        $response['errMsg'] =   'User credentials got expired! ';
                    }
                    
                } else {
                    $response['status'] = 0;
                    $response['msg'] = 'failed';
                    $response['errMsg'] = 'Invalid username or password';
                }
                return response()->json($response);
            }
        } catch (Exception $e) {
            $response['errMsg'] = $e->getMessage();
            return response()->json($response);
        }
        
    }

    
    public function checkCredentialExpired( $userid ){
        
        $currentdate                    =       date("Y-m-d");
        
        if( isset( $userid ) ){
            
            $passwordcreated            =       "SELECT * FROM user_credential WHERE INTERNAL_USER_ID = ".$userid." ORDER BY LAST_MOD_DATE DESC limit 1";
            $passwordcreated_date       =       DB::select( $passwordcreated );


            if( count( $passwordcreated_date ) ){

                $pass_date              =       (array)$passwordcreated_date[0];
                $expdays                =       84;
                $no_of_days_expired     =       $pass_date['LAST_MOD_DATE'].' +'.$expdays.' days';
                $expdate                =       date('Y-m-d', strtotime($no_of_days_expired));

                if( $currentdate > $expdate ) {

                    return true;

                } else {

                    return false;

                }

            }
            
        }
        
        return false;
        
    }

    public function loginLdapService($username, $password , $domain_type) {
        try {
            $adServer = Config::get('constants.LDAP.LDAP_IP');
            $port = Config::get('constants.LDAP.LDAP_PORT');
            // connect to ldap server
            $ldap = ldap_connect($adServer, $port)or die("Could not connect to LDAP server.");
            $ldaprdn = ($domain_type    ==  "spi"?'SPI-GLOBAL\\':'SPIDOM\\'). $username;
            ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($ldap, LDAP_OPT_REFERRALS, 0);
            $bind = @ldap_bind($ldap, $ldaprdn, $password);
            $msg = @ldap_errno($ldap);
            if ($msg == "8" || $msg == "0") {
                @ldap_close($ldap);
                return true;
            } else {
                @ldap_close($ldap);
                return false;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    public function loginMagnusService($data) {
        $result = UserModel::verifyLogin($data);
        if ($result->count() >= 1) {
            return true;
        }
        return false;
    }

    public function setLoginsession($data, &$response, $request) {
        
        $result = UserModel::verifyLogin($data);
        
        if ($result->count() >= 1) {
            
            $arrData = array();
            $is_manager = false;
            $manger_role_id = Config::get('constants.MANAGER_ROLE_ID');
            
            if (in_array($result[0]->role_id, $manger_role_id)) {
                $is_manager = true;
            }
            
            $data['user_id'] = $result[0]->user_id;
            $teamResult = UserModel::getTeam($data);
            $teamval = $teamResult[0]->teamId;

            //declare session 
            $userData = array();
            $userData['user_name'] = $result[0]->first_name . ' ' . $result[0]->last_name;
            $userData['user_id'] = $result[0]->user_id;
            $userData['role_name'] = $result[0]->role_name;
            $userData['emp_id'] = $result[0]->employee_code;
            $userData['role_id'] = $result[0]->role_id;

            if ($is_manager) {
                $userData['manager'] = "true";
            } else {
                $userData['manager'] = "";
            }
            $userData['team_id'] = $teamval;

            $userData['subcircle'] = "";
            $userData['circle_id'] = "";
            $userData['menucode'] = "";
            $userData['login_info_id'] = "";

            Session::put('users', $userData);

            $arrData['employee_code'] = $result[0]->employee_code;
            $arrData['user_id'] = $result[0]->user_id;
            $arrData['first_name'] = $result[0]->first_name;
            $arrData['last_name'] = $result[0]->last_name;
            $arrData['full_name'] = Session::get('users')['user_name'];
            $arrData['role_id'] = $result[0]->role_id;
            $arrData['role_name'] = $result[0]->role_name;
            $arrData['is_manager'] = $is_manager;
            $arrData['user_name'] = Session::get('users')['user_name'];

            $response['status'] = Config::get('constants.STATUS_ENUM.ONE');
            ;
            $response['msg'] = 'success';
            $response['data'] = $arrData;

            //update login status 
            $updatedata = ['LOGIN_CURRENT_STATUS' => '1'];
            $updatestatus = UserModel::where('USER_ID', $userData['user_id'])->update($updatedata);
            //add history login status
            $addhistory = ['USER_ID' => $userData['user_id'], 'LOGIN_TIME' => Carbon::now(), 'SYSTEM_IP' => $request->ip()];
            LoginUserHistoryModel::insertGetId($addhistory);
        } else {
            $response['status'] = 0;
            $response['msg'] = 'failed';
            $response['errMsg'] = 'username not found in magnus';
        }
    }

}
