<?php

namespace App\Http\Controllers\ViewSource;

use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\bookinfoModel;
use App\Models\jobModel;
use App\Models\productionLocationModel;
use App\Models\ViewSource\downloadViewSourceModel;
use App\Models\requiredConstants;
use App\Models\roundModel;
use App\Models\fileHandler;
use App\Models\downloadModel;
use App\Models\apiEproofPackagingModel;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB;

class ViewSorceController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function viewSourceIndex(Request $request) {
        $data = array();
        $sourceview = downloadViewSourceModel::Active()->get();
        $this->displayMenuName(Config::get('menuconstants.MENU.VIEW_SOURCE'),$data);
        $booksinfo = bookinfoModel::allBookinfo();
        $booksOpt = '<option value="">--Select--</option>';
        foreach ($booksinfo as $key => $value) {

            $booksOpt .= '<option data-bookid="'.$value['BOOK_ID'].'" value="'.$value['JOB_ID'].'">';
            $booksOpt .= $value['BOOK_ID'];
            $booksOpt .= '</option>';
        }
        $sourceOpt = '<option value="">--Select--</option>';
        foreach ($sourceview as $key => $value) {

            $sourceOpt .= '<option value="'.$value->ID.'">';
            $sourceOpt .= $value->NAME;
            $sourceOpt .= '</option>';
        }
        
        $rounddata = roundModel::Active()->whereIn('ID',[$this->round_ID_300,$this->round_ID_600])->get();
        $roundOpt = '<option value="">--Select--</option>';
        foreach ($rounddata as $key => $value) {

            $roundOpt .= '<option value="' . ($value->ID) . '">';
            $roundOpt .= $value->NAME;
            $roundOpt .= '</option>';
        }
        
        $data['bookidCollect'] = $booksOpt;
        $data['sourceview'] = $sourceOpt;
        $data['round'] = $roundOpt;
        return view('ViewSource.index')->with($data);
    }

    public function viewSourceChapter(Request $request) {
        $validation = Validator::make($request->all(), [
                        'jodId' => 'required|numeric',
                        'bookId' => 'required',
                        'roundId' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
        $jobID = $request->input('jodId');
        $bookID = $request->input('bookId');
        $roundID = $request->input('roundId');
        $metadataID = $request->input('metadataId');
        $filterdata = downloadModel::searchDownloadedChapter($jobID,$bookID,$roundID, $metadataID);
        $data = downloadModel::searchDownloadedChapter($jobID,$bookID,$roundID, '');
        $response["chapterdata"] = $data;
        $response["filterchapterdata"] = $filterdata;
        $response["sourceview"] = downloadViewSourceModel::Active()->get();
        return response()->json($response);
    }
    
    public function openChapterFiles(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'roundId' => 'required|numeric',
                        'resourcetype' => 'required|numeric',
                        'chapterId' => "required|array|min:1",
                        'chapterId.*' => "required|distinct|min:1|numeric"
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $jobId = $request->input('jobId');
            $resourcetype = $request->input('resourcetype');
            $metaid = $request->input('chapterId');
            $roundId = $request->input('roundId');
            $roundname  =   roundModel::find($roundId);
            $roundname  =   ($roundname !=  ''?$roundname->NAME:'');
            $resourceview = downloadViewSourceModel::find($resourcetype);
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills = jobModel::where('JOB_ID', $jobId)->first();
            $filepathid     =   ($resourceview !=   ''?$resourceview->REQUIRED_CONSTANT_NAME:'');
            $getchapterinfo     =   taskLevelMetadataModel::wherein('METADATA_ID',$metaid)->Active()->get();
            $getchapterinfo     =   $getchapterinfo->pluck('CHAPTER_NO','METADATA_ID');
            $getfileconstant   =   requiredConstants::where('CONSTANT_NAME',$filepathid)->first();
            if (count($getlocationftp) >= 1 && $bookdetaills != null && $resourceview != null && count($bookdetaills) >= 1 && $getfileconstant !=    '' && count($getchapterinfo) >= 1 && $getchapterinfo != null) {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                
                $ftpObj = \Storage::createFtpDriver([
                                'host' => $hostserver,
                                'username' => $hostusername,
                                'password' => $hostpassword,
                                'port' => '21',
                                'timeout' => '30',
                    ]);
                
                $cmn_obj = new CommonMethodsController();
                $filepath   =   [];
                $getzipname     =   [];
                //PATH CONCATENATION
                switch($resourcetype){
                    case ($resourcetype ==  '7' || $resourcetype == '8' || $resourcetype == '10' || $resourcetype == '11'):
                        foreach($getchapterinfo as $key=>$value){
                                    $array = array(
                                    '{BID}' => $bookid,
                                    '{RID}' => $roundname,
                                    '{CID}' => $value
                                );
                            $filepath[$value]   =   $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                        }
                    
                    break;
                    case '9':
                    //zip file name
                    $getzipproofing     =   apiEproofPackagingModel::join(DB::raw('(select max(ID) as aepid from api_eproof_packaging group by METADATA_ID order by aepid desc) apieproof'), 
                                            function($join){
                                                 $join->on('api_eproof_packaging.ID', '=', 'apieproof.aepid');
                                             })
                                            ->wherein('METADATA_ID',$metaid)
                                            ->where('ROUND',$roundId)->get();
                                             
                                            if($getzipproofing == null || count($getzipproofing) == 0){
                                                $response   =   $this->notfoundResponse;
                                                $response['errMsg']     =   'Author Zip File is not found !';
                                                return response()->json($response);
                                            }
                    $getzipproofing     =   $getzipproofing->pluck('PACKAGE_ID','METADATA_ID')->toArray();
                                            foreach($getchapterinfo as $key=>$value){
                                                $array = array(
                                                '{BID}' => $bookid,
                                                '{RID}' => $roundname,
                                                '{CID}' => $value);
                                                $filepath[$value]     =   $cmn_obj->arr_key_value_replace($array, rtrim($getfileconstant->CONSTANT_VALUE,'/'));
                                            }
//                                            foreach($getzipproofing as $key=>$value){
//                                                if(array_key_exists($key, $filepath)){
//                                                    $newarray   =   explode('/',$filepath[$key]);
//                                                    //get chapter name
//                                                    $splitchp   =   last($newarray);
//                                                    $getzipname[$splitchp]  =   str_replace('.zip','',$filepath[$key].'/'.$value);
//                                                }
//                                            }                    
                    break;
                    default:
                    foreach($getchapterinfo as $key=>$value){
                                    $array = array(
                                    '{BID}' => $bookid,
                                    '{RID}' => $roundname,
                                    '{CID}' => $value
                                );
                            $filepath[$value]     =   $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                        }
                    break;    
                }
                
                $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                $userworkfolder  =   Config::get('serverconstants.RESOURCE_VIEW');
                $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                $getuserid  =   $this->empId;
                $crd = "ftp://$hostusername:$hostpassword@";
                $nameofresourceview = preg_replace('/\s+/', '_', $resourceview->NAME);
                $open_path     =   $hostserver.$ftp_root_dir.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview;
                $checkfilesexist    =   [];
                $filecopymessage    =   [];
                $getFileExtnType    =   [];
                
                if(count($filepath) >= 1){
                    foreach($filepath as $Chapter=>$value){
                        $checkDirFiles = $ftpObj->allFiles($value);
                        if(count($checkDirFiles) >= 1) {
                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
                            $sourcepath     =   $crd . $hostserver . '/' . $value;
                            //if format is not null copy only format file
                            if($resourceview->FILE_FORMAT   ==  null){
                                $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                            }else{
                                //if format is null copy all file
                                if(strpos($resourceview->FILE_FORMAT,',') !=    false){
                                    $getFileExtnType   =   explode(",",$resourceview->FILE_FORMAT);
                                }else{
                                    $getFileExtnType[]  =   $resourceview->FILE_FORMAT;
                                }
                                $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only(  $sourcepath , $desDir,[],$getFileExtnType );
                            }
                            
                            $filecopymessage[]  =   $response_copy;
                            $checkfilesexist[]  =   $value;
                        }else{
                            $checkfilesexist[]  =   "";
                        }
                    }
                }
                
                if(count($filepath) >= 1 && $resourcetype   ==  9){
                    $newFilepath    =   [];
                    foreach($filepath as $Chapter=>$value){
                        $newFilepath[$Chapter]    =   str_replace($roundname,Config::get('constants.ROUND_ID')[$this->round_ID_650],$value);
                    }
                    foreach($newFilepath as $Chapter=>$value){
                        $checkDirFiles = $ftpObj->allFiles($value);
                        if(count($checkDirFiles) >= 1) {
                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
                            $sourcepath     =   $crd . $hostserver . '/' . $value;
                            //if format is not null copy only format file
                            if($resourceview->FILE_FORMAT   ==  null){
                                $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                            }else{
                                //if format is null copy all file
                                if(strpos($resourceview->FILE_FORMAT,',') !=    false){
                                    $getFileExtnType   =   explode(",",$resourceview->FILE_FORMAT);
                                }else{
                                    $getFileExtnType[]  =   $resourceview->FILE_FORMAT;
                                }
                                $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only(  $sourcepath , $desDir,[],$getFileExtnType );
                            }
                            
                            $filecopymessage[]  =   $response_copy;
                            $checkfilesexist[]  =   $value;
                        }else{
                            $checkfilesexist[]  =   "";
                        }
                    }
                }
                
//                if(count($filepath) >= 1 && $resourcetype   !=  9){
//                    foreach($filepath as $Chapter=>$value){
//                        $checkDirFiles = $ftpObj->allFiles($value);
//                        if(count($checkDirFiles) >= 1) {
//                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
//                            $sourcepath     =   $crd . $hostserver . '/' . $value;
//                            $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
//                            $filecopymessage[]  =   $response_copy;
//                            $checkfilesexist[]  =   $value;
//                        }else{
//                            $checkfilesexist[]  =   "";
//                        }
//                    }
//                }
                
//                if(count($getzipname) >= 1 && $resourcetype   ==  9){
//                    foreach($getzipname as $Chapter=>$value){
//                        // get full path  except zip file name
//                        $getfilecopyname    =   substr(strrchr($value, "/"), 1);
//                        $totalleng  =   strlen($value) - strlen($getfilecopyname);
//                        $splitchp   =   substr($value,0,$totalleng);
//                        $checkDirFiles = $ftpObj->allFiles($splitchp);
//                        if(count($checkDirFiles) >= 1) {
//                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
//                            $sourcepath     =   $crd . $hostserver . '/' . $splitchp;
//                            $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only(  $sourcepath , $desDir,[$getfilecopyname],['.zip'] );
//                            $filecopymessage[]  =   $response_copy;
//                            $checkfilesexist[]  =   $value;
//                        }else{
//                            $checkfilesexist[]  =   "";
//                        }
//                    }
//                }
                
                if(count($checkfilesexist) >= 1){
                    if(in_array('',$checkfilesexist) && $resourcetype !=    9){
                        $response   =   $this->notfoundResponse;
                        $response['errMsg'] =   $resourceview->NAME.' file is not found !';
                        return response()->json($response);
                    }
                }
                
                if(count($filecopymessage)>=1){
                    foreach($filecopymessage as $key=>$value){
                        if(in_array('failed',$filecopymessage[$key])){
                            return response()->json($this->fileNotCopiedResponse);
                        }
                    }
                }
                
                if (count($filecopymessage) >= 1) {
                    $postdata = [];
                    $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                    $postdata['system_ip'] = $request->ip();
                    $postdata['method_name'] = "doOpenDriveServer";
                    $postdata['processname'] = "checkout";
                    $insertfilehandler = fileHandler::insertNew($postdata);

                    if ($insertfilehandler) {
                        $response       =   $this->successResponse;
                        $response['rmID'] = $insertfilehandler;
                        return response()->json($response);
                    }
                }
                return response()->json($this->fileNotCopiedResponse);
            }
            return response()->json($this->locationNotFoundResponse);
        } catch (\Exception $e) {
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
    /*public function openChapterFiles(Request $request) {
        try {

            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'Chapter' => 'required',
                        'metadataId' => 'required|numeric',
                        'roundId' => 'required|numeric',
                        'resourcetype' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                $response = array('result' => 401, 'errMsg' => 'Mandatory fields are required', 'validation' => $validation->errors());
                return response()->json($response);
            }
            $jobId = $request->input('jobId');
            $resourcetype = $request->input('resourcetype');
            $metaid = $request->input('metadataId');
            $Chapter = $request->input('Chapter');
            $roundId = $request->input('roundId');
            $roundname  =   roundModel::find($roundId);
            $roundname  =   ($roundname !=  ''?$roundname->NAME:'');
            $resourceview = downloadViewSourceModel::find($resourcetype);
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills = jobModel::where('JOB_ID', $jobId)->first();
            $filepathid     =   ($resourceview !=   ''?$resourceview->REQUIRED_CONSTANT_NAME:'');
            $getfileconstant   =   requiredConstants::where('CONSTANT_NAME',$filepathid)->first();
            if (count($getlocationftp) >= 1 && count($bookdetaills) >= 1 && $getfileconstant !=    '') {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                
                $ftpObj = \Storage::createFtpDriver([
                                'host' => $hostserver,
                                'username' => $hostusername,
                                'password' => $hostpassword,
                                'port' => '21',
                                'timeout' => '30',
                    ]);
                
                $cmn_obj = new CommonMethodsController();
                $filepath   =   "";
                $getzipname     =   "";
                //PATH CONCATENATION
                switch($resourcetype){
                    case ($resourcetype ==  '7' || $resourcetype == '8' || $resourcetype == '10' || $resourcetype == '11'):
                    $array = array(
                            '{BID}' => $bookid,
                            '{RID}' => $roundname,
                            '{CID}' => $Chapter
                        );
                    $filepath = $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                    break;
                    case '9':
                    //zip file name
                    $whereField     =   ['METADATA_ID'=>$metaid,'ROUND'=>$roundId];
                    $getzipname     =   apiEproofPackagingModel::where($whereField)->latest()->first();
                    if(empty($getzipname)){
                        $result = array('result' => 404, 'errMsg' => 'Author Zip File is not found !', 'xmlcount' => '0');
                        return response()->json($result);
                    }
                    
                    $getzipname     =   str_replace('.zip','',$getzipname->PACKAGE_ID);
                    $array = array(
                            '{BID}' => $bookid,
                            '{RID}' => $roundname,
                            '{CID}' => $Chapter
                        );
                    $filepath = $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                    break;
                    default:
                    $array = array(
                            '{BID}' => $bookid,
                            '{RID}' => $roundname,
                            '{CID}' => $Chapter
                        );
                    $filepath = $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                    break;    
                }
                
                
                $checkDirFiles = $ftpObj->allFiles($filepath);
                if(count($checkDirFiles) >= 1) {
                    
                    $userworkfolder  =   Config::get('serverconstants.RESOURCE_VIEW');
                    $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                    $getuserid  =   $this->empId;
                    $crd = "ftp://$hostusername:$hostpassword@";
                    $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $srcfile     =   $crd . $hostserver . '/' . $filepath;
                    $nameofresourceview = preg_replace('/\s+/', '_', $resourceview->NAME);
                    $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$Chapter.'/'.$nameofresourceview;
                    $open_path     =   $hostserver.$ftp_root_dir.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$Chapter.'/'.$nameofresourceview;
                    $sourcepath     =   $crd . $hostserver . '/' . $filepath;
                    
                    $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                    $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                    
                    //delete file 
//                    $deletedata = [];
//                    $delete_path=   $hostserver.$ftp_root_dir.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$Chapter.'/'.$nameofresourceview;
//                    $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
//                    $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
//
//                    $deletedata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
//                    $deletedata['system_ip'] = $request->ip();
//                    $deletedata['method_name'] = "deleteFileServer";
//                    $deletedata['processname'] = "deleteFileServer";
//                    $insertfilehandler = fileHandler::insertNew($deletedata);
                
                
                    if($resourcetype    ==  9){
                        $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only(  $sourcepath , $desDir,[$getzipname],['.zip'] );
                    }else{
                        $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                    }
                    $response   =   array(
                            'result' => 404, 
                            'msg'   => 'Failed' ,  
                            'errMsg'    => ""
                            );
                    
                    if (in_array('failed', $response_copy)) {
                        foreach ($response_copy as $key => $value) {
                            if ($value == 'success') {
                                unset($response[$key]);
                            }
                        }
                        $response_copy = array('status' => 'failed', $response_copy);
                    } else {
                        $response_copy = array('status' => 'success', $response_copy);
                    }
                
                    if ($response_copy['status'] == 'success') {

                        $postdata = [];
                        $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                        $postdata['system_ip'] = $request->ip();
                        $postdata['method_name'] = "doOpenDriveServer";
                        $postdata['processname'] = "checkout";
                        $insertfilehandler = fileHandler::insertNew($postdata);

                        if ($insertfilehandler) {
                            $response['result'] = 200;
                            $response['Msg'] = 'Success';
                            $response['errMsg'] = 'File open initialized..';
                            $response['rmID'] = $insertfilehandler;
                            return response()->json($response);
                        }
                    }
                    $result = array('result' => 404, 'errMsg' => 'File is not copied try again !', 'xmlcount' => '0');
                    return response()->json($result);
                }
                $result = array('result' => 404, 'errMsg' => $resourceview->NAME.' file is not found !', 'xmlcount' => '0');
                return response()->json($result);
                
            }
            $result = array('result' => 404, 'errMsg' => 'No files found in the Production Location or file path is not configured !', 'xmlcount' => 0);
            return response()->json($result);
        } catch (\Exception $e) {
            $result = array('result' => 404, 'errMsg' => "Could not connect with production location, Kindly check credential");
            return response()->json($result);
        }
    }*/

}
