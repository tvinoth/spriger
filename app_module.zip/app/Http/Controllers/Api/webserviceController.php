<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiLowRes;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelMetadataModel;
use App\Models\checkoutModel;
use App\Models\projectModel;
use App\Models\artCategoryLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\dynamicConstantController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\Api\autostageController;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\apsProductionFilePathValidationModel;
use App\Http\Controllers\Api\autoPageController;
use App\Models\jobModel;
use Illuminate\Support\Facades\Crypt;
use App\Models\bgprocessPathSetup;
use DOMDocument;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use File;
use Config;
use Storage;
use App\Models\downloadModel;
use App\Models\jobsheetViewpathModel;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\workflowServerMapPathModel;

class webserviceController extends Controller
{    

    //public $tablename       =       'api_low_res';
    //public $apiModel        =       'apiLowRes';

    public $metainfo        =       array();
    
    public function __construct() {
        parent::__construct();      
        
    }
    
    public $nameShake;
    
    
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);

        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD ); 
        $this->ftpInfo              =       $getlocationftp;
        $metainfo['{RNO}']          =       preg_replace( '/\D/', '', $jbstg_rec->ROUND_NAME );
        $curuserchpxml              =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jobStageId , 0,0,1 );
		
        $this->metainfo             =       $metainfo;
        $watchPath      =       $this->getWatchFolderPath( $path );
		
        $cmn_obj        =       new CommonMethodsController();
        $watchPath      =       $cmn_obj->backslashPathPrepare($watchPath, true);
        $metainfo['curuserchpxml']  =       $watchPath;
        $this->metainfo             =       $metainfo;
        
        return  $metainfo;
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath   =   '';
        extract( $this->metainfo ) ;
        
        if( isset( $path['detail']['opendrive'] ) ){
            
            $workpath   =   $path['detail']['opendrive'];
            $arriinup   =   explode( '<>' , $workpath );
            
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chaptername , $metaid ); 
            extract( $paging_collect );
           
            $workpath   =   $arriinup[0].$pagingfilnaming.'.xml';
            
        } 
        
        return $workpath;
        
    }
	
    public function initiateWebservice( Request $request ){
        
        $response['status']         =       4;
        $response['msg']            =       'success';
        $response['errMsg']         =       'Invalid input given again after sometimes';
        //return response()->json( $response );
        try{
        
            $jbstgid        =       $request->input( 'jbstgid');

            $inputarr       =       array( 'jobstgid' => $jbstgid );
            $rules          =       $this->validationRuleForResponseSignal(); 
            $validator      =       Validator::make( $inputarr , $rules );

                if ($validator->fails()) {
                    $response['errMsg']      =       'Required field validation error occured.';
                }else{ 

                    $this->customConstructor( $jbstgid );
                    $setupBg            =       $this->getBgsettingWbsvc();
                    $setupBgFnc			=		$this->getBgsettingFunc();
					
                    if( !empty( $setupBg ) ){
                        
                        $serviceinfo        =       $this->getWebserviceInfo();
                        //$serviceinfo            =       $this->prepareMeta( $jbstgid  );  
                        
                        if( !empty( $serviceinfo ) ){
                            
                            $this->prepareInputContentChecker( $serviceinfo ); 

                            $methodname         =       $serviceinfo['method'];
                            $outputparameter    =       $serviceinfo['output'];
                            $inputData          =       array( 'data' => $serviceinfo['input'] );
                            $serviceurl         =       $serviceinfo['url'];
                            $cmnobj             =       new CommonMethodsController();
                            //$output           =       $cmnobj->soapServiceCall( $serviceurl , $methodname , $inputData   , $outputparameter );
                            
                            $callurl             =       $serviceurl.$methodname;
                            							
                            $returcurl           =       $cmnobj->callService( $serviceinfo['input'] ,  $callurl , 'json' );
							
                            $response['inputgiven']     =   $serviceinfo['input'];
                            if( !empty($returcurl) ){
                                
                                $response['status']     =   1;
                                $response['msg']        =   'success';
                                $statustext             =   $returcurl["$outputparameter"];
                                
                                if( !empty( $statustext ) ){
                                    $response['errMsg']     =   $returcurl["$outputparameter"];
                                    if( strtolower( $statustext ) !== 'success' ) {
                                       $response['status']     =   0; 
                                       $response['msg']        =   'failed';
                                    }
                                }else{
                                    $response['errMsg'] =   '';
                                }
                                
                            }else{
                                $response['status']         =       0;
                                $response['msg']            =       'failed';
                                $response['errMsg']         =       'Webservice execution got failed';
                            }
                        }else{
                            $response['status']         =       0;
                            $response['msg']            =       'failed';
                            $response['errMsg']         =       'webservice configuration not found, but enabled service call';
                        }
                       
                    }else if( !empty( $setupBgFnc ) ){ 
					
						$controller   	=	( $setupBgFnc[$setupBgFnc['stageid']]['controller'] );
						$methodnamearr	=	( $setupBgFnc[$setupBgFnc['stageid']]['executable'] );
						$methodinput	=	explode( '@' ,  $methodnamearr );
						$methodname     =   $methodinput[1];
						$controllerPath =   'App\\Http\\Controllers\\Api\\'.$controller;
						$response       =   app($controllerPath)->$methodname(  $jbstgid  );
						
						
					}else{

                        $response['status']         =       4;
                        $response['msg']            =       'success';
                        $response['errMsg']         =       'webservice configuration not found';

                    }
                    
                    
                }
                
        }catch( \Exception $e ){

            $response['status'] =   0;
            $response['Msg']    =   'failed';
            $response['errMsg'] =   'Something went wrong, try again after sometimes';
            $err_handle         =   new errorController();
            $err_handle->handleApplicationErrors( $e );
            
            return response()->json( $response );
        }        
        
        return response()->json( $response );
    }
    
	public function getBgsettingFunc(){
		
		extract(  $this->metainfo );
        
        $ckm_obj            =       new checkoutModel();        
        $prepareConfig      =       array();
        $stageinfo          =       $ckm_obj->getStageInfo( $jobstgid );

        if( count( $stageinfo ) ){

            $stageinfo          =       $stageinfo[0];
			
            $stageid            =       $stageinfo->STAGE_ID;
            $round              =       $stageinfo->ROUND_ID;
            $wrkmstrid 			=		$stageinfo->WORKFLOW_MASTER_ID;
            $metaidfor 			=		$stageinfo->METADATA_ID;

            $bgExe              =       DB::table('bgprocess_execution')
                                        ->select()
                                        ->where( 'STAGE_ID' , '=' , $stageid );

            $bgExe->where( 'ROUND_ID' , '=' , $round );
            $bgExe->where( 'METHOD_TYPE' , '=' , 'FUNCTION' );
            $bgExe->where( 'STATUS' , '=' , 'ACTIVE' );
            //$bgExe->where( 'TYPE' , '=' , 1 );

            $bgExe = $bgExe->get()->first();

            if( count( $bgExe )  ){ 

                $prepareConfig[$stageid]        =       array(
                    'type'          =>      $bgExe->METHOD_TYPE  ,
                    'executable'    =>      $bgExe->METHOD_EXECUTION  ,   
                    'waiting'       =>      $bgExe->WAITING  ,
                    'controller'    =>      $bgExe->CONTROLLER
                );
				$prepareConfig['stageid']	=	$stageid;

            } 

        }

        return $prepareConfig;

	}
	
    public function getBgsettingWbsvc( ){
        
        extract(  $this->metainfo );
        
        $ckm_obj            =       new checkoutModel();        
        $prepareConfig      =       array();
        $stageinfo          =       $ckm_obj->getStageInfo( $jobstgid );

        if( count( $stageinfo ) ){

            $stageinfo          =       $stageinfo[0];
			
            $stageid            =       $stageinfo->STAGE_ID;
            $round              =       $stageinfo->ROUND_ID;
            $wrkmstrid 			=		$stageinfo->WORKFLOW_MASTER_ID;
            $metaidfor 			=		$stageinfo->METADATA_ID;

            $bgExe              =       DB::table('bgprocess_execution')
                                        ->select()
                                        ->where( 'STAGE_ID' , '=' , $stageid );

            $bgExe->where( 'ROUND_ID' , '=' , $round );
            $bgExe->where( 'METHOD_TYPE' , '=' , 'WEBSERVICE' );
            $bgExe->where( 'STATUS' , '=' , 'ACTIVE' );
            //$bgExe->where( 'TYPE' , '=' , 1 );

            $bgExe = $bgExe->get()->first();

            if( count( $bgExe )  ){ 

                $prepareConfig[$stageid]        =       array(
                    'type'          =>      $bgExe->METHOD_TYPE  ,
                    'executable'    =>      $bgExe->METHOD_EXECUTION  ,   
                    'waiting'       =>      $bgExe->WAITING  ,
                    'controller'    =>      $bgExe->CONTROLLER
                );

            } 

        }

        return $prepareConfig;
    }
    
    public function validationRuleForResponseSignal(){
        
        $rules['jobstgid']  =   'required';
       
        return $rules;
        
    }
    
    public function prepareInputContentChecker( &$serviceinfo ){
        
        extract( $this->metainfo );
        
        $jobXMLInfo         =   downloadModel::getJobXMLInfo($jobid);
        $getlocationftp     =   productionLocationModel::doGetLocationname( $jobid );
        $cid    =   '';
        
        if( isset( $metaid ) ){
            $cid    =   $metaid;
        }
        
        if(empty($jobXMLInfo)){
            echo "No data found..!";
            exit;
        }

        if( empty( $getlocationftp ) )            
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();

        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        
        $prepath            =       $hostserver.$getlocationftp->FILE_SERVER_PATH;
                
        // Do the FTP connection

        $ftpObj = \Storage::createFtpDriver([
            'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
            'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
            'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
            'port'     => '21',
            'timeout'  => '30',
        ]);  
        
            $chapterId         =    '';
            if($cid != '' && $cid !=null){
                $tasklevelMetaObj  = new taskLevelMetadataModel();
                $metaDataDetails   =    $tasklevelMetaObj->getMetadatadetailsChapter($cid);
                if(!empty($metaDataDetails)){
                    $chapterId      =   $metaDataDetails['0']->CHAPTER_NO;
                }
            } 
            $round_arr      =   \Config::get('constants.ROUND_NAME');
            $round_name     =   $round_arr[$round];
            $xmlFilePath    =   '';
            $replace_bf     =   array( '' );
            $jobAssignedConst   =   \Config::get('constants.JOB_ASSIGNED_CONST');
            $stageName          =   \Config::get('constants.STAGE_NAME.COPY_EDITING');
          //  echo $stageName;exit;
            $book_id            =   $jobXMLInfo->BOOK_ID;
            $wheredata          =   ['ROUND_ID'=>$round];

            $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();

            if(count($getjobsheetpath)>=1){
                $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 

                $inp_rep_arr    =   array( 
                                        'BOOK_ID'    =>  $book_id , 
                                        'ROUND_NAME' =>  $round_name,
                                        'STAGE_NAME' =>  $stageName,
                                        'CID'        =>  $chapterId
                                     );


                $cmn_obj        =   new CommonMethodsController();
                $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );

                $serverDirFiles =   $ftpObj->allFiles( $serverDir );

                if(!empty($serverDirFiles)) {
                    foreach($serverDirFiles as $serverDirFile) {
                        $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                        if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos($jobsheetpath,$book_id) !==   false) {
                            $xmlFilePath = $serverDirFile;
                        }
                    }
                }
            }
            
            $xmlFilePath        =       $prepath.$xmlFilePath;
            $inputprepared      =       explode( '/' , $xmlFilePath );
            $resultopt          =       array_unique($inputprepared);
            $xmlFilePath        =       implode( '/' , $resultopt );
            $xmlFilePath        =       $cmn_obj->backslashPathPrepare($xmlFilePath, true );
           
            $serviceinfo['input']['strInputXML']    =   $xmlFilePath;
            $serviceinfo['input']['strStage']       =   $round_arr[$round_arr[$round]];
        
    }
    
    public function prepareMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        $type               =       'INITIALIZE';
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        $preparedXml        =       '';  
        
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid ,  $type );
              
                
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid ,  $type );
                     
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                //'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
        
        $xmlStr                  =       $preparedXml;
        $bg_Obj                  =       new bgprocessController();   
        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        
        return $xmlStr;
        
    }
    
    public function getWebserviceInfo(){
        
        extract( $this->metainfo );
        
		$queryrest      =   DB::table('bgprocess_path_setup')
                                ->select()
                                ->where('STATUS' , '=' , 'ACTIVE' )
                                ->where('ROUND'  , '=' , $round )
                                ->where('STAGE_ID' , '=' , $stageid )
                                //->where('WORKFLOW_ID' , '=' , $workflowid )
                                //->where('WATCH_PATH' , '<>' , ''  )
                                ->where( 'TYPE' , '=' , 'INITIALIZE'  )
                                ->get()
                                ->first();
         
        $preparedinput  =   array();
        
        if( count( $queryrest ) ){
            
            $preparedinput      =   array( 'url' => $queryrest->WATCH_PATH );
            $returninput        =   json_decode( $queryrest->TEXT , true);
            extract( $returninput );
            $preparedinput['input']     =   $input;
            $preparedinput['output']    =   $output;
            $preparedinput['method']    =   $method;
            
        }
           
        return $preparedinput;
        
    }
    
	public function checkFileExistInUserDir( $jbstgid  ){
		
		$response['status']         =       4;
		$response['msg']            =       'Success';
		$response['errMsg']         =       'Some required information not properly found';
		
		return  $response;
		$round_arr		=		\Config::get( 'constants.ROUND_NAME' );
		
		$this->customConstructor( $jbstgid  );
		extract( $this->metainfo );
		
			$wrokfserMapmdl		=		new workflowServerMapPathModel();
			$recordset			=		$wrokfserMapmdl->getWorkflowServerMapPath( $jbstgid , 0 , 0 ,0 );
			$autoPgeContObj     =   	new autoPageController();
			$paginginfo     	=       $autoPgeContObj->getPagingFileNameing( $bookid , $chapterno , $metaid );
			
			$pagingfilnaming =   '';
			extract( $paginginfo );
			$fileExistFlag		=	false;
			
			if( $recordset['status']  == 1 ){
				
				$userdir				=		$recordset['detail']['workdirlistpath'];
				$prQcFilesValidate		= 		array(  
													'{PAGING_FILENAMING}_OnlinePDF.pdf' , 
													'{PAGING_FILENAMING}_PrintPDF_log.pdf' , 
													'{PAGING_FILENAMING}_OnlinePDF.pdf' ,  
													'{PAGING_FILENAMING}_PrintPDF.pdf' 
												);
				
                    $serverDir      	=   	$userdir;
					$inp_rep_arr    	=   	array( 
													'BOOK_ID'    =>  $bookid , 
													'ROUND_NAME' =>  $round_arr[$round] ,
													'CID'        =>  $chapterno , 
													'{PAGING_FILENAMING}'	=>  $pagingfilnaming
												 );
                    
					if( !empty( $prQcFilesValidate ) ){
						foreach( $prQcFilesValidate as $indx => $value ){
							$prQcFilesValidate[$indx]   =  str_replace( '{PAGING_FILENAMING}' , $pagingfilnaming , $value );
						}
					}
					
                    $cmn_obj        	=   		new CommonMethodsController();
					$getlocationftp     =           productionLocationModel::doGetLocationname( $jobid );
					
					if( empty( $getlocationftp ) )            
						$getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
					
					//need to dynamicaly bind the production location based on table location
					$hostserver         =       $getlocationftp->FTP_HOST;
					$hostusername       =       $getlocationftp->FTP_USER_NAME;
					$hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
					$hostpath           =       ($getlocationftp->FTP_PATH);
					// Do the FTP connection
					$ftpObj 			= 		\Storage::createFtpDriver([
													'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
													'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
													'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
													'port'     => '21',
													'timeout'  => '30',
												]);  
					$serverDirFiles 	=   	$ftpObj->allFiles($serverDir);
					$presentFiles		=		array();
					
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $filesList   =   substr(strrchr($serverDirFile, "/"), 1);
							$presentFiles[]		=	$filesList;
                        }
                    }
					
					$missingFiles	=	array_diff( $prQcFilesValidate , $presentFiles );
					
					if( count( $missingFiles ) > 0 ){
						 $fileExistFlag		=	false;
					}else{
						 $fileExistFlag	=	true;
					}
					
				if( $fileExistFlag ){
					
					$response['status']			=	1;
					$response['msg']            =       'success';
					
				}else{
					$response['status']			=	0;
					$response['msg']            =       'failed';
					$response['errMsg']         =       'Required Files are not found on the Userwork folder - '.implode( ', ' , $missingFiles );
				}
				
			}
			else{
				$response['status']			=	0;
				$response['msg']            =       'failed';
			}
			
		return $response;
		
		
	}
    
}
