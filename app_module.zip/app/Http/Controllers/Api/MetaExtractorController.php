<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiMetaExtractor;
use App\Models\taskLevelMetadataModel;
use App\Models\ServiceManager as ServiceModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Models\productionLocationModel;
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\apiFileUpload;
use App\Models\bookinfoModel;
use App\Models\jobRevisedModel;
use Carbon\Carbon;
use App\Http\Controllers\Api\apiFileUploadController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\download\downloadController;
use App\Http\Controllers\dynamicConstantController;
use Illuminate\Support\Facades\Input;
use App\Http\Controllers\Api\productionFileTransferController;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use SoapClient;

ini_set( 'max_execution_time' , 0 );

class MetaExtractorController extends Controller
{
    protected   $table      =   'api_meta_extractor';
    public      $timestamps =   true;
    protected   $dateFormat =   'Y-m-d H:i:s';
    public      $updatable_data         =       array();
    public      $errFlag                =      false;
    public      $autoTriggerUpload      =      true;
    public      $curl;
    
    public $workflow     =   array(         
            'process' => '' ,
            'round' =>  '' , 
            'bookid'    =>  '' , 
            'jobid'     => '',
            'metaid'    => '', 
            'token' =>  '' , 
            'status'    => '' , 
            'endtime'   =>  '' , 
            'remarks' => ''        
    );    
     
    public function __construct(){  
        parent::__construct();
	
        $this->middleware(function ($request, $next) {
            return $next($request);
        });
    }
    
    public function index( $param ){
        
       // array inputs [ 1 => wrong instruction ]
   
        $data 			=	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.JOB_MODIFICATION'),$data);
        $data['pageTitle'] 	= 	'MetaExtractor';
        $data['pageName']  	=	'Jobsheet Update';
        $data['user_name'] 	=  	$this->userName;
        $data['role_name'] 	=  	$this->roleName;
        
        switch( $param ){
            default : 
                return view( 'metaextractor.index' )->with($data);                
                break;
        }
        
    }
    
    public function wrongInstruction( Request $request , $jobid = null ){
        
        $data 			=	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.JOB_MODIFICATION'),$data);
        $data['user_name'] 	=  	$this->userName;
        $data['role_name'] 	=  	$this->roleName;
        
        $letterFormat_arr       =       \Config::get('constants.INTRODUCTORY.LETTER_FORMAT');
        
        $booksinfo              =       bookinfoModel::getBookinfo();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'DESCRIPTION' ) ); 
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        $roundinfo              =       $roundinfo->whereNotIn('ID',[$round_arr['S5']]);
        $booksOpt               =       '';
        $roundOpt               =       '';
       
        $data['jobid']          =       $jobid;
        
        foreach ( $booksinfo as $key => $value ){
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
        }
        
        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=  '<option value="'.($value['ID']).'">';
            $roundOpt      .=  $value['DESCRIPTION'];
            $roundOpt      .=  '</option>';
        }
        
        $data['roundCollect']            =      $roundOpt;
        
        $data['bookidCollect']           =      $booksOpt;
        
        return view( 'metaextractor.wrongInstruction' )->with( $data );
        
    }
    
    public function movetoWomat( Request $request , $jobid = null ){
        
        $data 			=	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.MOVE_TO_WOMAT'),$data);
        $data['user_name'] 	=  	$this->userName;
        $data['role_name'] 	=  	$this->roleName;
        
        $letterFormat_arr       =       \Config::get('constants.INTRODUCTORY.LETTER_FORMAT');
        
        $booksinfo              =       bookinfoModel::getBookinfo();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'DESCRIPTION' ) ); 
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        //$roundinfo              =       $roundinfo->whereNotIn('ID',[$round_arr['S5']]);
        $booksOpt               =       '';
        $roundOpt               =       '';
       
        $data['jobid']          =       $jobid;
        
        foreach ( $booksinfo as $key => $value ){
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
        }
        
        foreach ( $roundinfo as $key => $value ){
            $roundOpt      .=  '<option value="'.($value['ID']).'">';
            $roundOpt      .=  $value['DESCRIPTION'];
            $roundOpt      .=  '</option>';
        }
        
        $data['roundCollect']            =      $roundOpt;
        
        $data['bookidCollect']           =      $booksOpt;
        
        return view( 'metaextractor.movetoWomat' )->with( $data );
        
    }
    
    public function storeResponse( Request $request ){
         
        $inputarr       =       (array)json_decode( $request->getContent() );
        Log::useDailyFiles(storage_path().'/Api/jobsheet_update.log');
        Log::info($inputarr);
         
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $process        =       strtolower($inputarr['process']);
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Unable to update, Invalid Token key posted!';
       
        if( $process == 'jobsheet_upload' && 'S5' ==  $round_arr[$inputarr['round']] ){    
            
           $response        =        $this->s5MetaExtractionResponse( $inputarr );           
           
        }
        
        if( $process == 'jobsheet_update' && 'S5' ==  $round_arr[$inputarr['round']] ){
           
            $response        =        $this->s5MetaExtractionJobSheetUpdateResponse( $inputarr );     
           
        }
        
        return response()->json( $response );
        
    }
    
    public function s5MetaExtractionJobSheetUpdateResponse( $inputarr ){
        
       
        $rules['bookid']         =       'required:min:1';
        $rules['round']          =       'required|numeric';
        $rules['status']         =       'required:numeric';
        $rules['endtime']        =       'required:date';
        $rules['remarks']        =       'required';
        $rules['process']        =       'required';
        
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'OOPS! something went wrong, kindly try again!';
        
        $validator  =   Validator::make( $inputarr , $rules );
        
            if ($validator->fails()) { 
              
               $response['errMsg']      =       $validator->errors();
                
            }else{
               
               
                $in_data        =       array();
               
                $bookid         =       $inputarr['bookid'];
                $round          =       $inputarr['round'];
                
                $in_data['REMARKS']     =       $inputarr['remarks'];
                $status_buff            =       $in_data['STATUS']      =      $inputarr['status']; 
                $in_data['END_TIME']    =       $inputarr['endtime'];
                
                try{
                    
                    $records            =       apiMetaExtractor::getApiRequestByBookid( $bookid , $round );                    
                    $statusKey          =       apiMetaExtractor::updateIfExist( $in_data , $records->ID );                    
                    $response['status']      =       1;                    
                    $response['msg']         =       'Success';
                    $response['errMsg']      =       'Response received Successfully';                    
                    $jobid      =       $inputarr['jobid'];
                    
                    apiFileUploadController::sendRequestS5JobSheetUpload( $jobid , 'S5' );
                    
               }catch( \Exception $e ){                         
                    $response['status']      =       0;
                    $response['msg']         =       'Error';
                    $response['errMsg']      =       'Unable to update, kindly retry again!';                    
               }
                
            }
            
            return $response;
            
    }
    
    public function sendInputToExtractor_S5( $bookId , $round ){
    
        $input_arr      =      array();        
        $time = date( 'Y-m-d H:i:s' );	
        
        $response['status']  =      0;
        $response['msg']     =     'Failed';
        $response['errMsg']  =     'OOPS! something went wrong, kindly try again!';
        
        try
        {            
            $api_tbl_input      =       array( 'BOOK_ID' => $bookId , 'ROUND' => $round  , 'START_TIME' => $time );
            
            $curl = \Config::get('constants.WSDL_OF_METAEXTRACTOR');

            $cmn_obj    =       new CommonMethodsController();
            $data       =       $api_tbl_input;
            
            $this->workflow['bookid'] = $bookId;
            $this->workflow['jobid'] = '';
            $this->workflow['process'] = 'JOBSHEET_UPLOAD';
            $this->workflow['round'] = $round;
            
            $data['workflow']     =     $this->workflow;
            
            $returns_response        =       $cmn_obj->PostcUrlExecution( $data , $curl );
            
            if( $returns_response['http_code'] !== 200 ){
                $api_tbl_input['REMARKS']        =       $returns_response['curl_err'];
                $api_tbl_input['STATUS']         =        0;
            }
            
            $getResponse        =        apiMetaExtractor::insertNew( $api_tbl_input );
            
            if( $getResponse  ==  2  ){
                  
                $response['status']  =     1;
                $response['msg']     =     'Success';
                $response['errMsg']  =     'Request posted Successfully!';    
            
            }
            
        }catch( \Exception $e ){
            
             $response['errMsg']    =   $e->getMessage();
        }
        
        return $response;
        
    }
    
    public function getContactInromationPm( $job_id , $round , $xmlreturn = false  ){
        
        $response_array     =       array();
        
        $UserDetails = DB::table('job AS j')
                ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                ->where('j.JOB_ID','=', $job_id )
                ->select()
               ->first();
        
       $pm_empId     =   isset( $UserDetails->PM ) ? $UserDetails->PM  : null;
       
       if( !is_null( $pm_empId ) ){
           
           $usrC_obj    =       new usersController();
           $user_arr    =   $usrC_obj->getUserInfoByUserId($pm_empId); 
           if(!empty($user_arr->P_COUNTRY)){
               $country    =   $usrC_obj->getCountryId($user_arr->P_COUNTRY);
               $user_arr->P_COUNTRY = $country->name;
            }
           
           $response_array  =   array( 
               
                'ContactPerson' =>  array( 
                        'ContactPersonName' => array(                             
                            'GivenName' =>  $user_arr->FIRST_NAME , 
                            'FamilyName' => $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME                           
                            ), 
                        'Contact'   =>  array(                            
                            'Street'    =>  $user_arr->P_ADDRESS,
                            'City' => $user_arr->P_CITY, 
                            'Postcode'  => $user_arr->P_ZIP , 
                            'Country' => $user_arr->P_COUNTRY,
                            'Phone'    => $user_arr->PERSONAL_PHONE,
                            'Fax'   => $user_arr->FAX, 
                            'Email' => $user_arr->EMAIL
                            )
                    )
               
               );
           
           //temprary fixes -start [ for package ]
           if( $xmlreturn ){   
               
               $xmlstr  =   '';      
                $this->xmlPrepareFromArray( $response_array['ContactPerson'] , $xmlstr );
               $xmlstr  .=   ''; 
               return $xmlstr;
               
           }
           //temprary fixes -end
           
       } 
       
       return $response_array;
        
    }
    
    public function xmlPrepareFromArray( $response_array , &$xmlstr  =   array() ){
        
        foreach($response_array as $key => $value ){                   
            $xmlstr  .=  '<'.$key.'>';
             
            if( gettype( $value ) == 'string' ){                       
                $xmlstr  .=  $value;
            }

            if( gettype( $value ) == 'array' ){ 
                $this->xmlPrepareFromArray( $value , $xmlstr ); 
            }
            
            $xmlstr  .=  '</'.$key.'>';
        }
               
    }
    
     public function sendInputForJobsheetUpdate( $jobId , $round , $process_type= 'RECEIPT' , $metaid = null , $typeofRequest = 'New'  ){
		 
		if($metaid == 'null'){
			$metaid = null;
		}
        
        if( $round == 119 && $process_type== 'CORRECTION'){
            $round = 118;
        }
        // echo $jobId,$round,$process_type,$metaid,$typeofRequest;exit;
        $input_arr              =       array();        
        $time                   =       date( 'Y-m-d H:i:s' );	
        $data                   =       array();
        $job_id                 =       $jobId;
        $zipfileColc            =       '';
        $zip_file_out           =       ''; 
        $xml_name               =       '';
        $chap_id                =       '';
        $chapter_name           =       '';
        $data['jobid']          =       $jobId;
        $data['Stage']          =       $round;
        $data['Round']          =       $round;
        $this->curl             =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.PM_S5_METADATA_UPDATE');
        $cmn_obj                =       new CommonMethodsController();
        $objfile                =       new apiFileUploadController(); 
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        $root_path              =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
        $jbst_path              =       \Config::get('serverconstants.JOBSHEET_FULL_PATH');
           
        $response['status']     =       0;
        $k                      =       0;
        $response['msg']        =       'Failed';
        $response['errMsg']     =       'OOPS! something went wrong, kindly try again!';
        $response['REMARKS']    =       'OOPS! something went wrong, kindly try again!';
       /*try
       {  */ 
            $api_tbl_input      =       array( 'JOB_ID' => $jobId , 'ROUND' => $round  , 'START_TIME' => $time );
            $jobDetails         =       jobModel::getJobdetailsRawQuery( $jobId,'job.BOOK_ID,job.JOB_TYPE' );
              
            if( $typeofRequest == 'Retry' ){
                
                $backupstatus           =       null;
                $dwnldCntlrObj          =       new downloadController();
                $inputForRetry['metaid']        =   $metaid;
                $inputForRetry['jobid']         =   $jobId;
                $inputForRetry['metastatusid']  =   '';
                $inputForRetry['round']         =   $round;
                $inputForRetry['processtype']   =   $process_type;
                
                $dwnldCntlrObj->backupAndUpdatedFileMoveForRetry( $inputForRetry );
                
            }
            
            if( isset( $metaid ) && !is_null( $metaid ) && $metaid  != 'null'){
                
                $api_tbl_input['METADATA_ID']  =   $metaid;
                $jbst_path      =       \Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                $tsklMeta       =       new taskLevelMetadataModel();
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                $metadata       =       $meta_info->toArray();
                $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                $chp_arr        =		explode('_' , $chapter_name );
               
                if(count($chp_arr)>=2){
                    $chap_id        =       '_'.$chp_arr[1];
                }else{
                    $chap_id        =       '_'.$chp_arr[0];
                }	
                
                $this->workflow['metaid']       =   $metaid;
                //$this->curl     =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.JOBSHEET_S50_UPDATE');
                
            }
			$backupOption =	1;
			if($typeofRequest == 'LogRetry'){
				$backupOption =	2;
			}
               
            $productionFiletranserObj       =   new productionFileTransferController();
                if(!empty($metaid)){
                    $response2                       =   $productionFiletranserObj->copyChapterLevelProcessJobsheet($jobId, $round, $jobDetails->BOOK_ID,$chapter_name,$process_type);
                }else{
                    $response2                       =   $productionFiletranserObj->copyProcessJobsheet($jobId, $round, $jobDetails->BOOK_ID,$process_type,$backupOption);
                }
            
            $jbst_path.= $process_type.'/';
           
            $round_id_arr       =       \Config::get('constants.ROUND_ID');
            $api_tbl_input['BOOK_ID']   =    $book_id      =   $bookId             =       $jobDetails->BOOK_ID;
           
            // Build required parameter for service request           
            $data['BWFBookID']  =       $bookId;
            
            $response['PROCESS_TYPE']           =        $api_tbl_input['PROCESS_TYPE']      =        $data['ProcessType']       =       $process_type;
            $getlocationftp                     =        productionLocationModel::doGetLocationname( $jobId );
            $locationFlag	=	1;
            
            if($response2 != '1' && false ){
                $response['status'] =   0;
                $response['msg']    =   'Failed';
                $response['errMsg'] =   'Not able to copy jobsheet!, kindly check!';           
                echo json_encode( $response );exit;
            }
            if( empty( $getlocationftp ) )  {          
                $getlocationftp  =     (object)  productionLocationModel::getDefaultProductionLocationInfo();
                $locationFlag = 0;
            }
			
             
            //need to dynamicaly bind the production location based on table location
            $hostserver          =       $getlocationftp->FTP_HOST;
            $hostusername        =       $getlocationftp->FTP_USER_NAME;
            if($locationFlag == 0){
                $hostpassword  = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            }else{
                $hostpassword        =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
            }
            
            $hostpath            =       ($getlocationftp->FTP_PATH);
            
            $roundname           =       $round_arr[$round];
			
            $inp_rep_arr         =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname     ,
                                            '{BID}'         =>      $book_id , '{RID}' => $roundname  
                                         );
            if( isset( $chapter_name  ) && $chapter_name !== '' ){
                $inp_rep_arr['{CID}'] = $chapter_name;
            }
			
            $raw_path            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jbst_path );
            $convention          =       \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
            $convention          =       $convention[$roundname];
            
            if($jobDetails->JOB_TYPE == 'S200 Of Series' || $jobDetails->JOB_TYPE == 'Series'){
                $xml_name            =       $book_id.$chap_id.$convention;
            }else{
                 $xml_name           =       $book_id.$chap_id.$convention;
            }
           
            $jobsheet_file_path  =       $cmn_obj->backslashPathPrepare( $hostserver.$root_path.$hostpath.$raw_path , true );
			
            $prr_report_path     =      \Config::get('constants.PRR_REPORT_FILE');            
            $prr_report_path     =       $cmn_obj->backslashPathPrepare( $hostserver.$root_path.$prr_report_path , true );
            
            $prr_convention      =      \Config::get('constants.PRR_REPORT_FILE_NAME_SUFFIX');             
            $prr_report_path     =      $prr_report_path.$book_id.$prr_convention; 
          
            $jobsheet_file_path  =      $jobsheet_file_path.$xml_name;    
		
            $ftpObj              =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $fileCheck_path      =       str_replace( '\\\\'.$hostserver.str_replace( '/' , '\\' , $root_path  ) , '' , $jobsheet_file_path );
            //$fileCheck_path =   'SP_BOOKS\PRODUCTION\450217_1_En\S200\JOBSHEET\CHAPTER_1\450217_1_En_1_JobSheet_200.xml';
           
           if (false) { recheck: }
		  
            $fileExistCheck      =       $ftpObj->ftpFileExist(  $fileCheck_path );
            
            if( !$fileExistCheck ){
				
                $response['status'] =   0;
                $response['msg']    =   'Failed';
                $response['errMsg'] =   'Jobsheet not found!, kindly check!';                
                if($k <= '10'){
                        sleep(10);
                        $k = $k+1;
                        goto recheck;
                }
                return response()->json( $response );
            }
            
            $zipfileColc         =       array( $jobsheet_file_path );    
           
            
            if( !is_null( $metaid ) && $metaid !='null' ){
                $zip_create_info     =       $objfile->getClientUploadZipCreationInformation( $bookId , $jobId , $round , $metaid);
            }
            
            if( !is_null( $metaid ) && $round == 119 && $metaid !='null' ){
                $zip_create_info     =       $objfile->getClientUploadZipCreationInformation( $bookId , $jobId , $round );
            }
            if( is_null( $metaid ) || $metaid =='null' ){
                $zip_create_info     =       $objfile->getClientUploadZipCreationInformation( $bookId , $jobId , $round );
            }
            
            if( !empty( $zip_create_info ) ){
                $zip_file_out                     =      $zip_create_info['ZIP_OUTPUT_FILE_PATH'];
                $api_tbl_input['ZIP_NAME']        =      $zip_create_info['ZIP_NAME'];
            }else{
                $response['status'] =   0;
                $response['msg']    =   'Failed';
                $response['errMsg'] =   'Unable to create the Zip file, kindly retry!';                
                return response()->json( $response );
            }
            
            if( $process_type == 'NOTIFICATION' && 'S5' == $round_arr[$round] ){
                $data['PrrFileName']    =       $this->getPrrFileName( $jobId  , $round_arr['S5'] );
                $zipfileColc            =       array( $jobsheet_file_path  , $prr_report_path );    
            }
            
            $data['ZIP']          =      array( 'fileList' => $zipfileColc , 'destFile' => $zip_file_out );
               
            $data['FileServerPath']         =       $jobsheet_file_path;
            $this->workflow['bookid']       =       $bookId;
            $this->workflow['jobid']        =       $jobId;
            $this->workflow['process']      =       $data['ProcessType'];
            $this->workflow['round']        =       $round;
            $this->workflow['stage']        =       $round;
            
            if( $process_type == 'RECEIPT' ){
                $data['contact']            =       $this->getContactInromationPm($jobId, $round);
            }else if( $process_type == 'WRONG_INSTRUCTION' ){
                $data['UPDATE_ELEMENT']             =       $this->updatable_data;
            }else if($process_type == 'CORRECTION'){
                $data['ProcessType']       =       'NOTIFICATION';
            }else if($process_type == 'NOTIFICATION' && 'S300' == $round_arr[$round] ){
                $data['ProcessType']       =       'NOTIFICATIONPROOFRUN';
            }else if($process_type == 'NOTIFICATION' && 'S650' == $round_arr[$round] ){
                $data['ProcessType']       =       'NOTIFICATIONPROOFRUN';
            }
            
            $data['workflow']                       =       $this->workflow;
            
            Log::useDailyFiles(storage_path().'/Api/'.$round_arr[$round].'_jobsheet_update_input.log');
            Log::info(json_encode( $data ) );
            
            // OST TRACKING SYSTEM
            $checkactiveornot   =   ServiceModel\ServiceManagerEnumModel::Active()->where('CODE',Config::get('constants.SERVICE_ENUM.OST'))->first();
            
            if(Config::get('constants.OST_ACTIVE')    ==  1 && $checkactiveornot != null){
                if($process_type     ==  "RECEIPT" || $process_type     ==  Config::get('constants.PROCESS_TYPE') && ($round     ==  Config::get('constants.ROUND_ID')['S5'] || $round     ==  Config::get('constants.ROUND_ID')['S50'])){        
                    $successfileresponse    =       app('App\Http\Controllers\Api\ostController')->ostTrackingStatus($jobId,$round,$process_type,'');
                    //active mq
                    if(in_array($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $process_type !=  "UPDATE"){
                        $processstageId     =   array_search($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                        $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'insert','',$processstageId,$process_type);
                    }
                    if(isset($successfileresponse['status']) && $successfileresponse['status'] == 0){
                        $api_tbl_input['STATUS']    =   "3";
                        $api_tbl_input['END_TIME']  =   Carbon::now();
                        $api_tbl_input["REMARKS"]   =   $successfileresponse['errMsg'];
                        $getResponse    =   apiMetaExtractor::insertNew( $api_tbl_input );  
                        $response['status'] =   0;
                        $response['msg']    =   'Failed';
                        $response['errMsg'] =   $successfileresponse['errMsg'];                
                        return response()->json( $response );
                    }
                }
            
                if($process_type     ==  "RECEIPT" || $process_type     ==  Config::get('constants.PROCESS_TYPE') || $process_type     ==  "NOTIFICATIONPROOFRUN" && $round     ==  Config::get('constants.ROUND_ID')['S650']){        
                    $successfileresponse    =       app('App\Http\Controllers\Api\ostController')->ostTrackingStatus($jobId,$round,$process_type,'');
                    //active mq
                    if(in_array($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $process_type !=  "UPDATE"){
                        $processstageId     =   array_search($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                        $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'insert','',$processstageId,$process_type);
                    }
                    if(isset($successfileresponse['status']) && $successfileresponse['status'] == 0){
                        $api_tbl_input['STATUS']    =   "3";
                        $api_tbl_input['END_TIME']  =   Carbon::now();
                        $api_tbl_input["REMARKS"]   =   $successfileresponse['errMsg'];
                        $getResponse    =   apiMetaExtractor::insertNew( $api_tbl_input );  
                        $response['status'] =   0;
                        $response['msg']    =   'Failed';
                        $response['errMsg'] =   $successfileresponse['errMsg'];                
                        return response()->json( $response );
                    }
                }

                if($process_type     ==  "RECEIPT" || $process_type     ==  Config::get('constants.PROCESS_TYPE') || $process_type     ==  "NOTIFICATIONPROOFRUN" && ($round     ==  Config::get('constants.ROUND_ID')['S200'] || $round     ==  Config::get('constants.ROUND_ID')['S300'])){        
                    $successfileresponse    =       app('App\Http\Controllers\Api\ostController')->ostTrackingStatus($jobId,$round,$process_type,'');
                    //active mq
                    if(in_array($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $process_type !=  "UPDATE"){
                        $processstageId     =   array_search($process_type,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                        $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'insert',$metaid,$processstageId,$process_type);
                    }
                    if(isset($successfileresponse['status']) && $successfileresponse['status'] == 0){
                        $api_tbl_input['STATUS']    =   "3";
                        $api_tbl_input['END_TIME']  =   Carbon::now();
                        $api_tbl_input["REMARKS"]   =   $successfileresponse['errMsg'];
                        $getResponse    =   apiMetaExtractor::insertNew( $api_tbl_input );  
                        $response['status'] =   0;
                        $response['msg']    =   'Failed';
                        $response['errMsg'] =   $successfileresponse['errMsg'];                
                        return response()->json( $response );
                    }
                }
            }
            
            //trigger the metaExtractor Tool for update
            $api_status         =       $this->postDataToMetaExtractor( $data , $api_tbl_input , $response );
            
            extract( $response );
            $trigger_upload_flag        =   $this->autoTriggerUpload;
            if( isset( $revised_jobsheet_flag ) ){
                $trigger_upload_flag =	 true;
                $process_type			=	'REVISED_RECEIPT';
            }
                        
            if( $api_status == 2 && $trigger_upload_flag ){	
                
                $this->triggeringNextStageOfMeUpload( $jobId , $round , $process_type , $metaid  );
            }
            
      /*}catch( \Exception $e ){
            print_r($e->getMessage());exit;
           $api_tbl_input['REMARKS']		=		$response['REMARKS']    =       $response['errMsg']     =       $e->getMessage();
            
            $api_tbl_input['END_TIME']      =       date( 'Y-m-d H:i:s' );
            $api_tbl_input['updated_at']    =       Carbon::now();
            $api_tbl_input['created_at']    =       Carbon::now();
            $api_tbl_input['STATUS']        =       3;

            $insert_ret     =        apiMetaExtractor::insertNew( $api_tbl_input );
        
       }*/
	   
        return response()->json( $response );
//        echo json_encode( $response );
    }
    
    public function getmovtoWomatStatus( Request $request ){
        
        ///$pageno  =   isset( $request->input( 'pageno') ) ?  $request->input( 'pageno') : null;
        //$limit   =   isset( $request->input( 'limit') ) ?  $request->input( 'pageno') : null;;
        //$type    =   isset( $request->input( 'type') ) ?  $request->input( 'pageno') : null;;
        
        $pageno     =   null;
        $limit      =   null;
        //$type       =   null;
        
        $jobid      =   $request->input( 'jobid' );
        $metaid     =   '';
        $type       =   $request->input( 'type' );
        $type       =   '3';
        $data       =   [];
        if( is_null( $pageno ) && is_null( $limit ) && is_null( $type ) && is_null( $jobid ) && is_null( $metaid ) ){
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getmovetowomatsignallist('','','','',''); 
        }
        
        if( !is_null( $type ) && is_null( $jobid )  && is_null( $metaid ) ){
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getmovetowomatsignallist( $pageno ,  $limit , $type,'',''  ); 
        }
       
        if( !is_null( $type ) && !is_null( $jobid )  ||  !is_null( $metaid ) ){
       
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getmovetowomatsignallist( $pageno ,  $limit , $type  , $jobid , $metaid ); 
        }
        if( !is_null( $jobid )){
       
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getmovetowomatsignallist( $pageno ,  $limit , $type  , $jobid , $metaid ); 
        }
        
        return response()->json( $data );
        
    }
    
    
    public function getApiStatusOfJobSheet( Request $request ){
        
        ///$pageno  =   isset( $request->input( 'pageno') ) ?  $request->input( 'pageno') : null;
        //$limit   =   isset( $request->input( 'limit') ) ?  $request->input( 'pageno') : null;;
        //$type    =   isset( $request->input( 'type') ) ?  $request->input( 'pageno') : null;;
        
        $pageno     =   null;
        $limit      =   null;
        //$type       =   null;
        
        $jobid      =   $request->input( 'jobid' );
        $metaid     =   $request->input( 'metaid' );
        $type       =   $request->input( 'type' );
        $data       =   [];
        if( is_null( $pageno ) && is_null( $limit ) && is_null( $type ) && is_null( $jobid ) && is_null( $metaid ) ){
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getJobsheetStatus('','','','',''); 
        }
        
        if( !is_null( $type ) && is_null( $jobid )  && is_null( $metaid ) ){
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getJobsheetStatus( $pageno ,  $limit , $type,'',''  ); 
        }
       
        if( !is_null( $type ) && !is_null( $jobid )  ||  !is_null( $metaid ) ){
       
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getJobsheetStatus( $pageno ,  $limit , $type  , $jobid , $metaid ); 
        }
        
        if( !is_null( $jobid )){
       
            $obj_extractor      =       new apiMetaExtractor();
            $data               =       $obj_extractor->getJobsheetStatus( $pageno ,  $limit , $type  , $jobid , $metaid ); 
        }
        
        return response()->json( $data );
        
    }
    
    public function postDataToMetaExtractor( $data , $api_tbl_input , &$response = array() ){
        
        $cmn_obj                 =       new CommonMethodsController();
        $curl                    =       $this->curl;
        $returns_response        =       $cmn_obj->PostcUrlExecution( $data , $curl );
        $res_arr                 =       @json_encode( $returns_response );
        $res_arr                 =       (array) json_decode( $res_arr );
        $api_status              =       3;
        
        foreach( $res_arr as $key => $value ){
            $res_arr     =     (array)json_decode( $value , true );
            break;
        }
        
        if( isset( $res_arr['Status'] ) ){
        
            $response['msg']                =       $res_arr['Status'];
            $response['errMsg']             =       $response['PROCESS_TYPE'].' request processed successfully'; 
            $api_status                     =       $api_tbl_input['STATUS']         =       ( $res_arr['Status'] == 'Failure' ) ? '3' : 2;
            
            if( $res_arr['Status'] == 'Failure' || $res_arr['Status'] == 'Failed' ){
                $api_status     =    $api_tbl_input['STATUS']        =       3;
                $response['errMsg']            =       $res_arr["Remarks"];
            }else if( $res_arr['Status'] == 'Success'  ){
                $api_status     =    $api_tbl_input['STATUS']        =       2;
            }else{
                $response['errMsg']            =       $res_arr["Remarks"];
                $api_status     =    $api_tbl_input['STATUS']        =       3;
            }
            
            $response['status']             =       ( ( $api_status % 2 ) == 0 ) ? 1 : 0;
            $api_tbl_input['REMARKS']       =       ( $returns_response['http_code'] == 200 ) ?  $res_arr['Status']  : $returns_response['curl_err'];
            //$api_tbl_input['REMARKS']            =       $res_arr['Status'];
            
        }else{
            $response['status']             =       0;
            $errormsg       =   'Check with webservice , No response is received from webservice';
            $api_tbl_input['REMARKS']       =       $errormsg; 
            $response['errMsg']            =       $errormsg; 
            $api_tbl_input['STATUS']             =       3;
            
        }
        
        $api_status = 2;
        $api_tbl_input['END_TIME']      =       date( 'Y-m-d H:i:s' );
        $api_tbl_input['updated_at']    =       Carbon::now();
        $api_tbl_input['created_at']    =       Carbon::now();
		
		$processtype	=	$api_tbl_input['PROCESS_TYPE'];
		$roundid		=	$api_tbl_input['ROUND'];
		$metadataid		=	isset( $api_tbl_input['METADATA_ID'] ) ? $api_tbl_input['METADATA_ID'] : null;
		$jobid			=	$api_tbl_input['JOB_ID'];
		
		if( $processtype == 'RECEIPT' ){
			
			//verify this is related to revised.
			//we can get it from job round milestone table
			//we should validate wheather receipt already done
			 
			$jbrevised 		=	new jobRevisedModel();
			
			if( isset( $metadataid ) && !is_null( $metadataid ) ){
				$inputhwerearr['METADATA_ID']	=	$metadataid;
			}
			
			$inputhwerearr['ROUND']		=	$roundid;
			$inputhwerearr['JOB_ID']	=	$jobid;
			$isRevised		=	$jbrevised::where( $inputhwerearr )->get();
			
			if(  count( $isRevised ) > 1 ){
				$api_tbl_input['PROCESS_TYPE']	=	'REVISED_RECEIPT';
				$response['revised_jobsheet_flag']	=	true;
			}
			
		}
		
        $insert_ret     =        apiMetaExtractor::insertNew( $api_tbl_input );
        
        if( $api_status == 2 ){
            return $api_status;
        }
        
        return false;
        
    }
    
    public function triggeringNextStageOfMeUpload( $jobId , $round , $process_type , $metaid ){
        
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        $objfile                =       new apiFileUploadController(); 
         
        if( $process_type == 'RECEIPT' || $process_type == 'REVISED_RECEIPT' ){
			
            if( 'S5' == $round_arr[$round] ){
                $objfile->sendRequestS5JobSheetUpload( $jobId  , 'S5'  , $process_type );
            }
			
            if( 'S50' == $round_arr[$round] ){
                $objfile->sendRequestS50JobSheetUpload( $jobId , 'S50' , $process_type );     
            }
			
            if( 'S200' == $round_arr[$round] ){
                $objfile->sendRequestS200JobSheetUpload( $jobId , 'S200' , $process_type , $metaid );
            }
            
            if( 'S600' == $round_arr[$round] ){
                $objfile->sendRequestS5JobSheetUpload( $jobId  , 'S600'  , $process_type );
            }
            	
        }else if( $process_type == 'NOTIFICATION' && 'S5' == $round_arr[$round] ){                   

            $updating_flag      =       array('IS_ACTIVE' => 0 );
            $objfile            =       new apiFileUploadController();
            $objfile->sendRequestS5JobSheetUpload( $jobId , 'S5' , 'NOTIFICATION' );
            $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();

            $round_id_arr       =       \Config::get('constants.ROUND_ID');
            $bookId             =       $jobDetails[0]->BOOK_ID;

            DB::table( 'api_download' )
                ->where( 'BOOK_ID' , 'LIKE', '%'.$bookId.'%' )
                ->where( 'ROUND' , $round_id_arr['S5'] )->update( $updating_flag );

        }else if( $process_type == 'NOTIFICATION' && 'S300' == $round_arr[$round] ){
            
            $objfile->sendRequestS200JobSheetUpload( $jobId , 'S300' , 'NOTIFICATION' , $metaid );
            
        }else if( $process_type == 'NOTIFICATION' && 'S650' == $round_arr[$round] ){
            
            $objfile->sendRequestS5JobSheetUpload( $jobId , 'S650' , 'NOTIFICATION' );
            
        }else if( $process_type == 'CORRECTION' && 'S300' == $round_arr[$round] ){
            
            $objfile->sendRequestS200JobSheetUpload( $jobId , 'S300' , 'CORRECTION' , $metaid );
            
        }else if( $process_type == 'CORRECTION' && 'S650' == $round_arr[$round] ){
            
            $objfile->sendRequestReceiptJobSheetUpload( $jobId  , $round  , $process_type );
            
        }else{
            
            if( isset( $metaid ) )
                $objfile->sendRequestReceiptJobSheetUpload( $jobId  , $round  , $process_type ,  $metaid );
            
            if( !isset(  $metaId ) )
                $objfile->sendRequestReceiptJobSheetUpload( $jobId  , $round  , $process_type );
            
        }
        
    }
        
    public function getPrrFileName(  $jobId , $roundid ){
        
        $prr_path_obj       =           DB::table( 'api_prr_report' )->select()
                                            ->where( 'JOB_ID'   , $jobId )
                                            ->where( 'ROUND'    , $roundid )
                                            ->get()->last();
        $filename           =       '';
        if( count( $prr_path_obj ) > 0 ){ 
            $prrpath        =       str_replace( '\\' , '/' ,  $prr_path_obj->PRR_REPORT_PATH );
            $file_path      =       explode( '/' ,  $prrpath );
            $filename       =       end( $file_path );
        }   
        
        return $filename;
    }
    
    public function updateJobSheetweb( $jobId ) {
	
    	if(!empty($jobId)){
    		$res	=	$this->jobSheetS50Upload($jobId,'114');
        	
        	return $res;
    	}
    }
    
    public function updateJobSheet( Request $request) {
	
	$requestData	=	$request->all();
	
	$inputarr       =       (array)json_decode( $request->getContent() );
	//$jobId = '6284';
    	if(!empty($requestData['jobId'])){
    		
    		$jobId 	= 	$requestData['jobId'];
        	$res	=	$this->jobSheetS50Update($jobId,'114');
        	return $res;
    	}
    }
    
    public function validation( $input_arr = array() , $round ){
      
        $needfield   =   array(     
                                'jobId'             =>      'required',
                                'bookId'            =>      'required',
                                'process'           =>      'required|string|min:4',
                                'node'              =>      'required',
                                'instruction'       =>      'required',
                                'round'             =>      'required|numeric',                        
                            );
        
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        
       
        if( $round ==  $round_arr['S300'] ){
            unset( $needfield['node'] );
            unset( $needfield['instruction'] );
            if( $round_arr['S300'] >= $round )
                $needfield['metaid']  = 'required';
            
        }
        
        $validator  = Validator::make( $input_arr , $needfield );
        
        if($validator->fails()){
            $this->validationErr    =       array(
                                            'status'            =>      0,
                                            'validationerror'   =>      $validator->errors()
                                                ); 
            $this->errFlag          =       true;
           
        }
            
       return $validator; 
       
    }
    
    public function metaextractorUpdate( Request $request ){
        
        $inputs                 =       $request->all();
		
        $round                  =       $roundid                      =       '';
        
        $validator              =       $this->validation( $request->all() , $request->input( 'round' ) );
        
        if( $validator->fails() ){
            return response()->json( $this->validationErr , 401 );
        }
           
        $jobid          =       $request->input( 'jobId' );
        $bookid         =       $request->input( 'bookId' );
        $process        =       $request->input( 'process' );
        $node           =       $request->input( 'node' );
        $instruction    =       $request->input( 'instruction' );
        $round          =       $request->input( 'round' );
        $metaid         =       $request->input( 'metaid' );
        
        $updatexml      =       array();
        $updatexml      =       array( $node => $instruction );
        $this->updatable_data       =       $updatexml;
        
        // check exist is data processing
        $wheremeta      =   [];
        $wheremeta['PROCESS_TYPE']  =   $process;
        $wheremeta['ROUND']         =   $round;
        if(!empty($metaid)){
            $wheremeta['METADATA_ID']   =   $metaid;
        }
        $wheremeta['JOB_ID']        =   $jobid;
        $wheremeta['STATUS']        =   Config::get('constants.STATUS_ENUM.INPROGRESS');
        $checkexistdata =   apiMetaExtractor::where($wheremeta)->orderBy('ID','DESC')->first();
        if($checkexistdata !=   null){
            $getbookid  =   jobModel::getJobdetailsRawQuery($jobid,'job.BOOK_ID');
            $getbookid  =   ($getbookid !=  null?"Book - ".$getbookid->BOOK_ID:'Book');
            $response   =   $this->failedResponse;
            $response['errMsg']     =   "Previous request for this  $getbookid is still In Progress !";
            return response()->json($response);
        }
        $responsedata 	=	[];
        switch( $round ){
            
            case \Config::get('constants.ROUND_ID.S5') :
                //yet to do still not  yet get production knowledge.
                $responsedata 	=	$this->sendInputForJobsheetUpdate( $jobid , $round , $process );
                break;
            
            case \Config::get('constants.ROUND_ID.S50') :
                //yet to do still not  yet get production knowledge.
                $responsedata 	=	$this->sendInputForJobsheetUpdate( $jobid , $round , $process );
                break;
            
            case \Config::get('constants.ROUND_ID.S300') :
                $responsedata 	=	$this->sendInputForJobsheetUpdate( $jobid , $round , $process , $metaid );
                break;
            
            case \Config::get('constants.ROUND_ID.S200') :
                $responsedata 	=	$this->sendInputForJobsheetUpdate( $jobid , $round , $process , $metaid );
            break;
            
            default:   
                $responsedata 	=	$this->sendInputForJobsheetUpdate( $jobid , $round , $process );
                break;
        
        }
		
		if(is_object($responsedata)){
			return $responsedata->getContent();
		}
        
    }
    
    public function jobSheetS50Update(  $jobId, $round ){
    	 
    	$input_arr           =       array();
    	$time                =       date( 'Y-m-d H:i:s' );
    	$data                =       array();

    	$response['status']  =      0;
    	$response['msg']     =     'Failed';
    	$response['errMsg']  =     'OOPS! something went wrong, kindly try again!';
    	$response['REMARKS'] =     'OOPS! something went wrong, kindly try again!';

    	try
    	{    		 
    		$api_tbl_input                      =          array( 'JOB_ID' => $jobId , 'ROUND' => $round  , 'START_TIME' => $time );
    		$jobDetails                         =          DB::table('job')->where('JOB_ID', $jobId )->get();
    		$api_tbl_input['BOOK_ID']           =          $book_id      =   $bookId             =       $jobDetails[0]->BOOK_ID;    		 
                $zip_file_out                       =          ''; 
                
                $curl                    =       Config::get('constants.QMS_CHAPTER_QUERIES_URL').'?TitleAcronym='.$bookId."&ChapterNo=&Type=Magnus";
              
                $cmn_obj                 =       new CommonMethodsController();
                $returns_response        =       $cmn_obj->getcUrlExecution(  $curl );
                
                if($returns_response['http_code'] =='200'){
                    
                    if($returns_response['OpenCount']>=1){
                        $response['REMARKS']            =     'Failure';
                        $response['msg']                =     'Failure';
                        $response['errMsg']             =     'This title have open Query(s). Kindly close the open query(s) and continue the process';  
                        return $response;
                    }
                }
                
                $objfile                            =       new apiFileUploadController(); 
                $zip_create_info                    =          $objfile->getClientUploadZipCreationInformation( $book_id , $jobId , $round );   
                if(count( $zip_create_info )>=1 ){
                    $zip_file_out                =          $zip_create_info['ZIP_OUTPUT_FILE_PATH'];
                    $api_tbl_input['ZIP_NAME']   =          $zip_create_info['ZIP_NAME'];
                }else{
                    $response['REMARKS']            =     'Failure';
                    $response['msg']                =     'Failure';
                    $response['errMsg']             =     'Unable to create the Zip file, kindly retry!';   
                    return $response;
                    throw new \Exception( 'Unable to create the Zip file, kindly retry!' );
                }
                
    		$curl = \Config::get('constants.PRODUCTION_TOOLS_SETUP.JOBSHEET_S50_UPDATE');
    		$cmn_obj    =       new CommonMethodsController();    		 
    		$jobsheetInfo      		 =          $this->getS50JobsheetInformation($jobId, $round , $zip_file_out );
                Log::useDailyFiles(storage_path().'/Api/s50_jobsheet_update_input.log');
                Log::info( $jobsheetInfo  );
                
    		$returns_response1      =       $cmn_obj->PostcUrlExecution( $jobsheetInfo , $curl );
    		$returns_response       =	$returns_response1['0'];
    		$res_arr                =       @json_encode( $returns_response );
    		$res_arr                =       (array) json_decode( $res_arr );

    		foreach( $res_arr as $key => $value ){
    			$res_arr	=     (array)json_decode( $value , true );
    			break;
    		}

    		$stream_buf =   '';
                
    		if( $returns_response1['http_code'] !== 200 ){
                    $stream_remarks             =       $api_tbl_input['REMARKS']        =       $returns_response['curl_err'];
                    $api_tbl_input['STATUS']    =       ( $res_arr['Status'] == 'Failure' ) ? '3' : 2;
    		}else{
                    $api_tbl_input['STATUS']    =       ( $res_arr['Status'] == 'Failure' ) ? '3' : 2;
                    $stream_buf     		=       ( $res_arr['Status'] == 'Failure' ) ? '3' : 2;
                    $stream_remarks  		=       $api_tbl_input['REMARKS']  =    $res_arr['Status'];
    		}
                
                $api_tbl_input['PROCESS_TYPE']  =      'UPDATE';            
    		$response['REMARKS']     	=       ($res_arr['Status']);
    		$response['errMsg']     	=       ($res_arr['Status']);
    		$time2                          = 	date( 'Y-m-d H:i:s' );
    		$api_tbl_input['END_TIME']      =       $time2;

    		$getResponse        =       apiMetaExtractor::insertNew( $api_tbl_input );
       
    		if( $getResponse  >=  1  ){                    
                    $response['status']         =     1;
                    $response['msg']            =     'Success';
                    $response['errMsg']         =     'API request send Successfully!';                                 
    		}

    	}catch( \Exception $e ){

    		$response['errMsg']    =   $e->getMessage();
    	}

    	return $response;

    }
    
 public function getS50JobsheetInformation( $job_id , $round , $zip_file_out ) {

    	$response_array     =       array();

    	$UserDetails = DB::table('job AS j')
    	->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
    	->where('j.JOB_ID','=', $job_id )
    	->select('j.*','ji.*')
    	->first();
    	
        $partInfo = array(); 

    	$getlocationftp     =            productionLocationModel::doGetLocationname( $job_id );
        
        $productionFiletranserObj       =   new productionFileTransferController();
        $response2                       =   $productionFiletranserObj->copyProcessJobsheet($job_id, $round, $UserDetails->BOOK_ID,'UPDATE');
        
        if($response2 != '1'){
            throw new \Exception( 'Unable to copy jobsheet!, kindly check!' );
        }
    	 
    	//need to dynamicaly bind the production location based on table location
    	$hostserver         =           $getlocationftp->FTP_HOST;
    	$hostusername       =           $getlocationftp->FTP_USER_NAME;
    	$hostpassword       =           \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
    	$hostpath           =           ($getlocationftp->FTP_PATH);
    	 
    	$book_id            =           $UserDetails->BOOK_ID;
    	$root_path          =           \Config::get('constants.FILE_SERVER_ROOT_DIR');
    	$raw_path           =        	\Config::get('serverconstants.JOBSHEET_PATH');
       
    	$s5xml_name         =       	$UserDetails->BOOK_ID.'_JobSheet_50.xml';
       
    	 
    	$s5_jobsheet_file_path          =      str_replace( '/' , '\\' ,   $hostserver.$root_path.$hostpath.$raw_path.$book_id.'\\' );
        
        
    	$s5_jobsheet_file_path          =      str_replace( '//' , '\\' ,   $s5_jobsheet_file_path );
    	$s5_jobsheet_file_path          =      str_replace( '\\\\' , '\\' ,   $s5_jobsheet_file_path );
    	$s5_jobsheet_file_path          =      '\\\\'.$s5_jobsheet_file_path.'S50\\UPDATE\\'.$s5xml_name;
      	
		
		
        $getartinfo         			=   taskLevelMetadataModel::getArtfigureInfo($job_id);
        $printtotalcolor    			=   $getartinfo->pluck('OUTPUTCOLOR')->all();
        $printbwcolor       			=   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
        $printillu          			=   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
    	 
    	$pageInfo['BWFBookID'] 		=       $UserDetails->BOOK_ID;
    	$pageInfo['Stage']              =       $round;
    	$pageInfo['ProcessType'] 	=       'Jobsheet_Update';
    	$pageInfo['FileServerPath']     =       $s5_jobsheet_file_path;
        
        $zipfileColc                    =       array( $s5_jobsheet_file_path );
        
        $pageInfo['ZIP']      =      array( 'fileList' => $zipfileColc , 'destFile' => $zip_file_out );
	$totalPageCount       =      $UserDetails->NO_ROMAN_PAGES + $UserDetails->NO_ARABIC_PAGES;
        $pageInfo['JobSheet']['BookJobSheet']['CompoundObjectNumberOfRomanPages']   = $UserDetails->NO_ROMAN_PAGES;
    	$pageInfo['JobSheet']['BookJobSheet']['CompoundObjectNumberOfArabicPages']  = $UserDetails->NO_ARABIC_PAGES;
        $pageInfo['JobSheet']['BookJobSheet']['CompoundObjectTotalNumberOfPages']   = $totalPageCount;
    	
    	$imageInfo                              = array();
    	$imageInfo['@PrintImagesColor']         = count($printillu);
    	$imageInfo['@PrintImagesBlackWhite']    = count($printbwcolor);
    	$imageInfo['@Illustrations']            = count($printtotalcolor);
		
    	$pageInfo['JobSheet']['BookJobSheet']['CompoundObjectNumberOfImages']   = $imageInfo;
    	$contactPerson      =     $this->getContactInromationPm($job_id, $round);

    	$pageInfo['JobSheet']['BookJobSheet']['ContactPerson'] =  $contactPerson['ContactPerson'];



    	//echo "<pre>"; print_r($pageInfo);exit;
    	$BookObjectInfo = array();
    	DB::enableQueryLog();
    	$overallData	=	array();
    	$mappDetails = DB::table('task_level_metadata AS tm')
    	->join('metadata_info  as mi', 'mi.METADATA_ID', '=', 'tm.METADATA_ID')
    	->leftJoin('part_mapping as pm', function($join) {
    		$join->on('tm.METADATA_ID', '=', 'pm.CHAPTER_METADATA_ID');
    		$join->on('pm.JOB_ID', '=', 'tm.JOB_ID');
                $join->where('pm.STATUS', '=', '1');
    	})
    	->where('tm.JOB_ID','=',$job_id )
        ->where('tm.UNIT_OF_MEASURE','!=','556')
    	->select('tm.METADATA_ID','tm.CHAPTER_NO','mi.TYPE_OF_CONTAINESM','tm.CHAPTER_NAME','tm.CHAPTER_SEQ','mi.FM_ARTICLE_BM','pm.PART_METADATA_ID')
        ->orderby('tm.CHAPTER_SEQ','ASC')        
    	->get();
    	//dd(DB::getQueryLog());exit;
      
    	$partData = array();
        //echo "<pre>";print_r($mappDetails);exit;
    		foreach($mappDetails as $key => $value){
    		 
    		if($value->FM_ARTICLE_BM == '1'){ //Front matter
    			$partData['FM'] = $value;

    		}else if($value->FM_ARTICLE_BM == '2'){//chapter
    			$partData['Chapter'][$value->METADATA_ID] = $value;
				$chapter_sequence   = $value->CHAPTER_SEQ;
    		}else if($value->FM_ARTICLE_BM == '3'){//Back Matter
			
				$value->CHAPTER_SEQ    = $chapter_sequence +1;
    			$partData['BM'] = $value;

    		}else if($value->FM_ARTICLE_BM == '4'){ // Part
							
    			$partData['PART'][$value->METADATA_ID] = $value;

    		}

    	}
    
    	if(!empty($partData['PART'])){
    		 
    		$partMetaid     = array_keys($partData['PART']);
    		$chapterDetails = $partData['Chapter'];
    		
    		$rootChapter = array();
    		foreach($chapterDetails as $key => $data) {
    			$metaId		=	 $data->PART_METADATA_ID;
    			if(in_array($data->PART_METADATA_ID,$partMetaid)){
    				$partInfo[$metaId] = $partData['PART'][$metaId];
    				$partInfo[$metaId]->chapter[$data->METADATA_ID] = $data;
    			}elseif($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}else{
    				if($data->FM_ARTICLE_BM == '2'){
    					$rootChapter[$data->METADATA_ID]= $data;
    				}
    			}
    		}

    	}else{
		
            $chapterDetails = $partData['Chapter'];
    		
            $rootChapter = array();
            foreach($chapterDetails as $key => $data) {
    			if($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}
    		}
                  
        }
			
	

    	$overallData['part'] = $partInfo;

        if(!empty($partData['FM'])){
    	$fm['@ID'] = 'APage_FM1';
    	$fm['ChapterInfo'] = array(
         	 '@ChapterType' 	=> 'APageObject',
             'ChapterID' 		=> 'FM1',
             'ChapterSequenceNumber' => '1',
             'ChapterTitle' => array('@Language' => 'En',
               '#text' => 'Front Matter')
    	);
        $pageInfo['JobSheet']['BookJobSheet']['DiscreteBookObjectInfo'][] = $fm;
        }
        
        if(!empty($partData['BM'])){
            $bm['@ID'] = 'APage_BM1';
            $bm['ChapterInfo'] = array(
                     '@ChapterType' 	=> 'APageObject',
                 'ChapterID' 		=> 'BM1',
                 'ChapterSequenceNumber' => $partData['BM']->CHAPTER_SEQ,
                 'ChapterTitle' => array('@Language' => 'En',
                   '#text' => 'Back Matter')
            );

            $pageInfo['JobSheet']['BookJobSheet']['DiscreteBookObjectInfo'][] = $bm;
        }
       
    	if(!empty($rootChapter)){
    		$rootcha = array();
    		foreach($rootChapter as $key=>$rootData){
                         $chapId         = explode('_',$rootData->CHAPTER_NO);
                         $chapterId      = (!empty($chapId['1'])?$chapId['1']:$rootData->CHAPTER_NO);
    			$rootcha['@ID'] = ucfirst(strtolower($rootData->CHAPTER_NO));
    			$rootcha['ChapterInfo'] = array(
        		   	 '@ChapterType' => 'OriginalPaper',
		             '@NumberingStyle' => 'ChapterContent',
		             '@OutputMedium' => 'All',
		             '@TocLevels' => '0',
		             '@ContainsESM' => (!empty($rootData->TYPE_OF_CONTAINESM)? ucfirst( strtolower($rootData->TYPE_OF_CONTAINESM )) :'No'),
		             'ChapterID' => $chapterId,
		             'ChapterNumber' => $chapterId,
		             'ChapterSequenceNumber' => $rootData->CHAPTER_SEQ,
		             'ChapterTitle' =>  array('@Language' => 'En',
               			'#text' => (!empty($rootData->CHAPTER_NAME)?$rootData->CHAPTER_NAME:'Introduction'))
    			);
    			$pageInfo['JobSheet']['BookJobSheet']['DiscreteBookObjectInfo'][] = $rootcha;
    		}
    	}
        
        $partGroup  =   [];
    	if(!empty($partInfo)){

    		foreach($partInfo as $key => $partData){
    			$paCh = array();
				if(!empty($partData->chapter)){
					$pa_tem		=		explode( '_' , $partData->CHAPTER_NO );	
					
    				$paCh[] = array('@ID' 	=> "PartFrontmatter_".(isset($pa_tem[1])?$pa_tem[1]:'') ,
               							'BookFrontmatterInfo' => array(
        								'BookFrontmatterFirstPage' => '',
                 						'BookFrontmatterLastPage' => '',

    				)
    				);

    				foreach($partData->chapter as $key2 => $chDetails ){

    					$rootcha['@ID'] = ucfirst(strtolower($chDetails->CHAPTER_NO));
                                        $chapId         = explode('_',$chDetails->CHAPTER_NO);
                                        $chapterId      = (!empty($chapId['1'])?$chapId['1']:$chDetails->CHAPTER_NO);
                        $pa_tem		=		explode( '_' , $partData->CHAPTER_NO );	
					                                                      
    					$rootcha['ChapterInfo'] = array(
				        		   	 '@ChapterType' 			=> 'OriginalPaper',
						             '@NumberingStyle' 			=> 'ChapterContent',
						             '@OutputMedium' 			=> 'All',
						             '@TocLevels' 				=> '0',
						             '@ContainsESM' 			=> (!empty($chDetails->TYPE_OF_CONTAINESM)? ucfirst( strtolower($chDetails->TYPE_OF_CONTAINESM) ) :'No'),
						             'ChapterID' 				=> $chapterId,
						             'ChapterNumber' 			=> $chapterId,
						             'ChapterSequenceNumber' 	=> $chDetails->CHAPTER_SEQ,
						             'ChapterTitle' 			=>  array('@Language' => 'En',
				               			'#text' => (!empty($chDetails->CHAPTER_NAME)?$chDetails->CHAPTER_NAME:'')
    					),
    								'ChapterContext'=>array('PartID'=> (isset($pa_tem[1])?$pa_tem[1]:'') )
    					);
    					//$rootcha['ChapterContext'] = array('PartID'=>$partData->CHAPTER_NO);
    						
    					$paCh[] = $rootcha;

    				}
    					
					$pa_tem		=		explode( '_' , $partData->CHAPTER_NO );	
					
    				$partGroup[] = array(
						'PartInfo' => array(
							'@OutputMedium' 		=> 'All',
							 'PartID' 				=> (isset($pa_tem[1])?$pa_tem[1]:'') , 
							 'PartSequenceNumber' 	=> $pa_tem[1],//$partData->CHAPTER_SEQ,
							 'PartTitle' 			=> (!empty($partData->CHAPTER_NAME)?$partData->CHAPTER_NAME:''),
							 'PartChapterCount' 	=> count($partData->chapter)
						),
						'DiscreteBookObjectInfo' => $paCh
    				);

    			}

    		}

    	}
    	 

    	$pageInfo['JobSheet']['BookJobSheet']['PartInfoGroup'] = $partGroup;
		
            
    	return $pageInfo;

    }
   
    public function getChaptersByJoid( $jobid = null ){
        
        $chapter_collection =       array();
        
        if( !is_null( $jobid ) ){            
            $tlmd       =      new taskLevelMetadataModel();
            $chapter_collection['chapters']     =       $tlmd->getMetadatadetailsJob( $jobid );            
        }
            
        return response()->json( $chapter_collection );    
        
    }
   
   public function checkIfDispatched( Request $request ){
       
		$validation             =   Validator::make($request->all(), [
                                                    'bookid' 	=> 'required',
                                                    'stageid' 	=> 'required|numeric',
                                                    'purposetype' 	=> 'required'
                                            ]);
		if ($validation->fails())
		{
			$result      	=       array( 'result'=>400 ,'errMsg'  =>  'Kindly select bookid and stage!');   
			return response()->json($result,400);
		}
		$bookid 			=	$request->input('bookid');
		$stageid 			=	$request->input('stageid');
		$purposetype 		=	$request->input('purposetype');
		$wheredata 			=	['BOOK_ID'=>$bookid,'ROUND'=>$stageid,'PROCESS_TYPE'=>\Config::get('constants.PROCESS_TYPE'),'STATUS'=>2];
		$getdispatcheditem 	=	apiFileUpload::where($wheredata)->get();
		if(count($getdispatcheditem)>=1)
		{
			$result      	=       array( 'result'=>200 ,'errMsg'  =>  $bookid.' has been dispatched already!');   
			return response()->json( $result);
		}
    }
    
    
    public function movetowomatbystage(Request $request){
        
        $bookid                     =	$request->input('jobId');
        $roundId                    =	$request->input('round');
        $cmn_obj                    =   new CommonMethodsController();
        if($roundId == '104'){
            $data['jobId']          =   $bookid;
            $data['tapstype']       =   3;
            $data['roundid']        =   $roundId;
            $curl                    =       Config('app.url').'/api/dosfiftymovenonTaps';
            $api_response           =   $cmn_obj->RestfulPostcUrlExecution( $data  , $curl, 1,"" );
	    return response()->json($api_response);
        }
        
        if($roundId == '114' || $roundId == '116' ){
            $getallchapters     =   taskLevelMetadataModel::getMetadatadetailsJob($bookid);
            $api_response       =   array('result'=>200,'status'=>0,'errMsg'=>'Invalid try..');   
            if(!empty($getallchapters)){
				
                foreach($getallchapters as $key => $metaData){
                    $data                    =   array();
                    $data['jobId']           =   $bookid;
                    $data['metadataId']      =   $metaData->taskmetaid;
                    $data['tapsstype']       =   '3';
                    $data['ChapterNo']       =   $metaData->CHAPTER_NO;
                    $data['ChapterTitle']    =   $metaData->CHAPTER_NAME;
                    $data['roundid']         =   $roundId;
                    $curl                    =   url('api/domovenonTaps');
                    $api_response            =   $cmn_obj->RestfulPostcUrlExecution( $data  , $curl, 1,"" );
                }
                return response()->json($api_response);
            }else{
                $result         =   array('result'=>200,'status'=>0,'errMsg'=>'Chapter are not created for this title..');   
                return response()->json($result);
            }
        }
        $result         =   array('result'=>200,'status'=>0,'errMsg'=>'Invalid try..');   
        return response()->json($result);
    }
    
}