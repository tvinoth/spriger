<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\emailRemainderCorrectionHistoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\correction\correctionController;
use App\Http\Controllers\production\movetoproductionController;
use App\Http\Controllers\Api\tapsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\Api\esmFileNameController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\checkout\checkOutController;
use App\Models\productionLocationModel;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\jobInfoModel;
use App\Models\apiEsm;
use App\Models\apiProofingStatus;
use App\Models\bookinfoModel;
use App\Models\workflowModel;
use App\Models\jobStage;
use App\Models\taskLevelMetadataModel;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\Api\autostageController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Models\apiZipExtraction;
use App\Http\Controllers\Api\zipExtractionController;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use File;
use Config;
use Storage;

ini_set('max_execution_time', 0);

class clientAcknowledgementController extends Controller
{  
    public function storeResponse( Request $request ){
    
    try{
        
        $inputarr           =       json_decode( $request->getContent() );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $filteredInp        =       (array)$inputarr->Download;
        
        $processarr         =       array( 4 =>   'clientack' ,  5 => 'Eproof' , 6 => 'Correction' );
        $processKey         =       $filteredInp['ProcessType'];
        $processname        =       '';
		
        //Raw folder file movement          
        $normal_mails_round         =       array( $round_arr['S5'] , $round_arr['S50'] , $round_arr['S200'] , $round_arr['S600'] );    

        if( $processKey == 4 ){
            $normal_mails_round[]   =       $round_arr['S300'];
        }	

        if( in_array( $processKey , $processarr ) ){
            $processname            =       $processarr[$processKey];
        }
		
        $logfilename                =       $processname.'_successRedo.log';
        Log::useDailyFiles( storage_path().'/Api/'.$logfilename );
        Log::info( json_encode( $inputarr) );
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
        
        $rules['BookID']            =       'required';
        $rules['FileName']          =       'required';
        $rules['StartDate']         =       'required';
        $rules['EndDate']           =       'required';
        $rules['ProcessType']       =       'required';
        $rules['Remarks']           =       'required';
        $rules['Status']            =       'required';
        
        $validator                  =       Validator::make( $filteredInp , $rules );
     
            if ($validator->fails()) { 
               $response['errMsg']  =       'Required field validation error occured.';
            }else{
                
                $in_data            =       array();
                $book_id            =       $in_data['BOOK_ID']     =       $filteredInp['BookID'];                
                $round_arr          =       \Config::get('constants.ROUND_ID');
                $getRoundInfo       =       DB::table('api_download')->select()->where('BOOK_ID', 'like' , '%'.$book_id.'%')->get()->last();
                $round              =       null;   
                $jobId              =       '';
                $filenamingcheck    =       $filteredInp['FileName'];
                
                if( is_object( $getRoundInfo ) ){
                    $round          =        $in_data['ROUND']       =       $getRoundInfo->ROUND;
                }else if( strpos( $filenamingcheck , 'Mono' ) !== false ){
                    $round          =        $round_arr['S650']; 
                }
                
                $setArrCa['PROCESS_TYPE']   =        $in_data['PROCESS_TYPE']     =       $filteredInp['ProcessType'];
                $changedfilename            =        $setArrCa['FILE_NAME']       =        $in_data['FILE_NAME']        =       $filteredInp['FileName'];
                   
                $filenaming                 =        $filteredInp['FileNameinLog'];        
                $setArrCa['REMARKS']        =        $remarks                     =       $in_data['REMARKS']         =       $filteredInp['Remarks'];
                $setArrCa['STATUS']         =        $str_status                  =       $in_data['STATUS']          =       ( $filteredInp['Status'] == 'Success' ) ? 2 : 3;
                $setArrCa['START_TIME']     =        $in_data['START_TIME']       =       $filteredInp['StartDate']; 
                $setArrCa['END_TIME']       =        $in_data['END_TIME']         =       $filteredInp['EndDate'];
                $inp_arr                    =        $in_data;
                
                $bookdetails                =        bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                                        ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                                        ->where('job.BOOK_ID', 'like' , '%'.$book_id.'%')
                                                        ->get()->last(); 
                
                $jobId                      =       (count($bookdetails)>=1?$bookdetails['JOB_ID']:'');
                $getlocationftp             =       productionLocationModel::doGetLocationname($jobId);
		$defaultLocation            =       0;
                
                if( empty( $getlocationftp ) ){
                    $defaultLocation	=		1;
                    $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo(); 
                }

                if(count($getlocationftp)   !=  0){
                    
                    $hostserver             =   $getlocationftp->FTP_HOST;
                    $hostusername           =   $getlocationftp->FTP_USER_NAME;
                    if($defaultLocation == 1){
                        $hostpassword           =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    }else{
                        $hostpassword           =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    }
                    
                    $hostpath               =   $getlocationftp->FTP_PATH;
                    // Do the FTP connection
                    $ftpObj                 =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
                    
                }
                else {
                    return json_encode( $response );
                }
                
                $changedfilename    =   $filteredInp['FileName'];
                
                if( !empty( $bookdetails ) && !empty( $round ) ){
                    
                    $book_id                =         $bookdetails['BOOK_ID'];
                    $jobId                  =         $bookdetails['JOB_ID'];
                    $inp_arr['JOB_ID']      =         $jobId;
                    
                    if( $filteredInp['ProcessType']  == 5 ){
                        
                        if( $filteredInp['Status'] == 'Success'  ) {
                            
                            $filenaming     =   str_replace( 'Eproof_Success_' , '' , $filenaming );
                        }else{
                            $filenaming     =   str_replace( 'Eproof_Error_' , '' , $filenaming );
                        }
                            $filenaming     =   str_replace( '.xml' , '' , $filenaming );
                            
                    }
                    
                    $getRequestedRow        =         apiClientAcknowledgement::getApiRequest( $jobId , $round , $filenaming );
                    
                    if( count( $getRequestedRow ) > 0 ){
                        
                        $round      =   $getRequestedRow->ROUND;
                        $rowidca                =       $getRequestedRow->ID;     
                        apiClientAcknowledgement::updateIfExist( $setArrCa  , $rowidca );    
                        
                        //active mq
                        if(in_array($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $getRequestedRow->PROCESS_TYPE_DIFF !=  "UPDATE"){
                            $processstageId     =   array_search($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'update','',$processstageId,$getRequestedRow->PROCESS_TYPE_DIFF);
                        }
                        
                        $processType      =     Config::get('constants.REVISED_PROCESS_TYPE');
                        
                        //JS Compare
                        if(in_array($getRequestedRow->PROCESS_TYPE_DIFF, $processType)){
                                
                        //    $successfileresponse    =   app('App\Http\Controllers\Api\JsCompareController')->jsCompareProcess($getRequestedRow);
                        }
                        
                        
                        
                    }else{
                        
                        $round      =   isset( $getRequestedRow->ROUND ) ? $getRequestedRow->ROUND : '';
                        
                        if( strpos( strtolower( $changedfilename ) , 'contri' ) ){
                            $round = $round_arr['S300'];
                        }
                        
                        if( strpos( strtolower( $changedfilename ) , 'mono' ) !== false ){
                            $round = $round_arr['S650'];
                        }
                        
                        if( $round == $round_arr['S300'] && $filteredInp['ProcessType']  == 6 ){
                            
							$round			=	118;
							
                            $processtypename    =   "CORRECTION";
							$addionalobj        =       isset( $inputarr->eproof ) ? $inputarr->eproof : $inputarr;
							if( isset( $addionalobj[0] ) )
								$addionalobj        =		$addionalobj[0];
							
                            $eproofresponse     =       isset( $addionalobj->CorrectionDetails ) ? $addionalobj->CorrectionDetails : 'nocorrectionxml';
                            $in_data['status_txt']      =       $filteredInp['Status']; 
							
                            $metaid             =       $this->getMetaidForthisCorrectionDownload(  $eproofresponse , $inputarr , $jobId );
                           
                            //active mq
                            if(in_array($processtypename,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $processtypename !=  "UPDATE"){
                                $processstageId     =   array_search($processtypename,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                                $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'update',$metaid,$processstageId,$processtypename);
                            }
				
                            
                            ini_set('output_buffering','1');
                            ob_start();
                            
                            //store correction details
                            $corrCntrl      =        new \App\Http\Controllers\correction\correctionController();
                            $corrCntrl->sendInputForCorrectionTableDataInsert(  $jobId , $metaid , $round , $inputarr );
                            
                            //Handle the correction download here
                            $extractorCntrl      =        new \App\Http\Controllers\Api\MetaExtractorController();
                            $this->executeCorrectionJobsheetSimultaniously( $jobId , $round , $processtypename , $metaid );
                            
                            //s300 workflow starts
                            $this->correctionWorkflowMovetoProduction( $jobId , $metaid , $round , $eproofresponse , $response );
                            
                            $this->prepareRawpathForDownload(  $jobId , 119 , $metaid , $getlocationftp , $response , $eproofresponse );

                            $this->sendCorrectionLogMailtoAMorPM( $in_data , $round , $filteredInp , $addionalobj , $metaid , $response ); 
                            
                            $response['status']      =       1;
                            $response['msg']         =       'Success';
                            $response['errMsg']      =       'Signal received Successfully ';    
                                                        			
                            ob_end_clean();
                            ob_flush();

                            Log::useDailyFiles( storage_path().'/Api/correctiondonwloadresponse.log' );
                            Log::info( json_encode( $response ) );

                            return json_encode( $response );
                            
                        }else if( $round == $round_arr['S650'] && $filteredInp['ProcessType']  == 6 ){
                            
                            $response['round']          =       's650';
                            $metaid                     =       null;
                            $addionalobj                =       isset( $inputarr->eproof ) ? $inputarr->eproof : $inputarr;
                            $eproofresponse             =       $addionalobj;
                            $this->prepareRawpathForDownload(  $jobId , 120 , $metaid , $getlocationftp , $response , $eproofresponse );
                            $getlocationftp             =       productionLocationModel::doGetLocationname( $jobId );
                            
                            if( count( $getlocationftp ) ){
                                
                                $hostserver                 =       $getlocationftp->FTP_HOST;
                                $hostpath                   =       $getlocationftp->FTP_PATH;
                                $root_path                  =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
                                $raw_path                   =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.CORRECTION_DOWNLOAD_PATH');     

                                $downloadSrcpath            =       $hostserver.$root_path.$raw_path;
                                $cmn_obj                    =       new CommonMethodsController();
                                $downloadSrcpath            =       $cmn_obj->backslashPathPrepare( $downloadSrcpath, true );
                                $downloadDestpath           =       $response['rawPath'];

                                $extct_input                =       array( 
                                                                        'process_type'      =>     1 ,  
                                                                        'jobid'             =>     $jobId , 
                                                                        'round'             =>     $round , 
                                                                        'metaid'            =>     $metaid   ,  
                                                                        'downloadSrcpath'   =>     $downloadSrcpath.$changedfilename ,
                                                                        'downloadDestpath'  =>     $downloadDestpath
                                                                    );
                                $this->executeS650MonoCorrectionDownloadInsert( $jobId , $round , $book_id , $getlocationftp , $response , $eproofresponse ,  $inputarr );
                                $processtypename        =       "CORRECTION";
                                $in_data['status_txt']  =       $filteredInp['Status'];  
                                
                                $extractorCntrl         =        new \App\Http\Controllers\Api\MetaExtractorController();
                                $this->executeCorrectionJobsheetSimultaniously( $jobId , $round , $processtypename );
                                $this->sendCorrectionLogMailtoAMorPMS650( $in_data , $round , $filteredInp , $addionalobj , $response ); 
                            
                            }else{
                                $response['errMsg'] =   'Invalid try.';
                            }
                            
                        }else{
                            throw new \Exception( 'Invalid Api Request.' );
                        }
                    }
                    
                    $in_data['status_txt']   =       $filteredInp['Status'];
                    $msg_txt                 =       '';
                    
                    if( ( $round == $round_arr['S200'] || $round == $round_arr['S300'] || $round == $round_arr['S600']  ) &&   count( $getRequestedRow ) > 0  ){
		    	//active mq
                        if(in_array($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $getRequestedRow->PROCESS_TYPE_DIFF !=  "UPDATE"){
                            $processstageId     =   array_search($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                           // $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'update',$metaid,$processstageId,$getRequestedRow->PROCESS_TYPE_DIFF);
                        }
						
                        if($round == $round_arr['S200']){
                            
                          $datataps['jobId']        =  $getRequestedRow->JOB_ID;
                          $datataps['metadataId']   =  $getRequestedRow->METADATA_ID;
                          $datataps['roundid']      =  $getRequestedRow->ROUND;
                          $response     =   $this->callMoveToWomatTaps($datataps);
                          
     			}
                        
                        if( $getRequestedRow->PROCESS_TYPE_DIFF == 'PACKAGING' && $filteredInp['ProcessType']  ==  4 ){
                            
                            $metaid	=	$getRequestedRow->METADATA_ID;
                            $atstgCont  =       new autostageController();
                           
                            if( $str_status == 2 ){
                                $atstgCont->stageCompletionProcess( $metaid , $round );
                            }else if( $str_status == 3 ){
                                
                            }else{
                                
                            }
                            
                        }

                    }   
					
                    if( in_array( $round ,  $normal_mails_round ) ){
						
                        $status_res              =       $this->sendLogMailtoAMorPM( $in_data,$round );
                        if( $status_res['Status'] == 1  ){                            
                            $msg_txt             =       ' , Client Acknowledgement mail send with log file ';
                        }
                    }
                        
                    if( ( $round == $round_arr['S300'] ) || (  $round == $round_arr['S650'] ) &&   count( $getRequestedRow ) > 0 ){ 
                        //active mq
                        if(in_array($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME')) && $getRequestedRow->PROCESS_TYPE_DIFF !=  "UPDATE"){
                            $processstageId     =   array_search($getRequestedRow->PROCESS_TYPE_DIFF,Config::get('constants.ACTIVE_MQ_PROCESS_NAME'));
                            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'update',$getRequestedRow->METADATA_ID,$processstageId,$getRequestedRow->PROCESS_TYPE_DIFF);
                        }
                        
                        //for eproof 
                        if( $filteredInp['ProcessType']  ==  5 ){
                            //dd( $inputarr );
                            $addionalobj        =       isset( $inputarr->eproof ) ? $inputarr->eproof : $inputarr;
                            
                            if( $filteredInp['Status'] == 'Success' && ( $round == $round_arr['S300'] || $round == $round_arr['S650'] ) ){ 
                                
								$eproofresponse     =       $addionalobj->eProofResponse;
                                $recipi             =       $this->getRecipientFromResponse( $eproofresponse->Response );
                                $eprfCntrlr         =        new \App\Http\Controllers\eproof\eproofController();
                            
                                $precipi            =       $recipi->ProofRecipient;
                                $precipi            =       (array)$precipi;
                                $eproofresponse     =       $addionalobj->eProofResponse;
                                $recipi             =       (array)$recipi;
                                $resp_rem           =       (array)$recipi['Status'];
                                $resp_rem           =       $resp_rem['#text'];
                                $correction_duedate =       date("Y-m-d h:i:s", strtotime("+8 day"));
                                $second_correction_duedate  =   date("Y-m-d h:i:s", strtotime("+11 day"));
                                $third_correction_duedate   =   date("Y-m-d h:i:s", strtotime("+13 day"));
                                
                                $insert_epf_status      =       array(  
									'JOB_ID'	  =>		$getRequestedRow->JOB_ID ,
                                                                        'METADATA_ID' =>        $getRequestedRow->METADATA_ID ,
                                                                        'ROUND'       =>        $getRequestedRow->ROUND  ,
                                                                        'PROOFING_URL'=>        $precipi['URL'],
                                                                        'STATUS'      =>        ( $filteredInp['Status'] == 'Success') ? 2 : 3, 
                                                                        'REMARKS'     =>        $resp_rem ,   
                                                                        'CORRECTION_REQUIRED' => strtoupper( $precipi['@CorrectionsRequired'] ) ,
                                                                        'TYPE'           =>     strtoupper( $precipi['@Role'] ) ,
                                                                        'NAME'           =>     ( $precipi['Name'] ) ,
                                                                        'EMAIL'           =>    ( $precipi['Email'] ) ,
                                                                        'FIRST_CORRECTION_DUE'  =>    $correction_duedate,
                                                                        'SECOND_CORRECTION_DUE'  =>    $second_correction_duedate,
                                                                        'THIRD_CORRECTION_DUE'  =>    $third_correction_duedate,
                                                                        'CORRECTION_DUE'  =>    $correction_duedate
                                                                     );

                                $proofing           =   new apiProofingStatus();
                                $insertproofing     =   $proofing->insertNew( $insert_epf_status );
                                
                                if( $insertproofing ){									 
                                    
                                    $insertdata['JOB_ID']          		=   $getRequestedRow->JOB_ID;
                                    $insertdata['METADATA_ID']          =   $getRequestedRow->METADATA_ID;
                                    $insertdata['ROUND']                =   $getRequestedRow->ROUND;
                                    $insertdata['CORRECTION_DUE']       =   $correction_duedate;
                                    $insertdata['FIRST_CORRECTION_DUE'] =   $correction_duedate;
                                    $insertdata['SECOND_CORRECTION_DUE']=   $second_correction_duedate;
                                    $insertdata['THIRD_CORRECTION_DUE'] =   $third_correction_duedate;
                                    $insertdata['REMAINDER_TYPE']       =   Config::get('constants.REMAINDER_TYPE.EPROOF');
                                    $insertdata['CREATED_BY']           =   Config::get('constants.ADMIN_USER_ID');
                                    $storehistory                       =   emailRemainderCorrectionHistoryModel::insertGetId($insertdata);
                                    
                                }                                
                                //$this->triggerNotificationProofRun( $getRequestedRow );                                 
                            }
							
                            if( $filteredInp['Status'] == 'Success' ){
                                $this->triggerNotificationProofRun( $getRequestedRow ); 
                            } 
							
                            $this->sendEproofLogMailtoAMorPM( $in_data , $round , $filteredInp , $addionalobj );
							
                        }
                        
                    }
                
                    
                    $response['status']      =       1;
                    $response['msg']         =       'Success';
                    $response['errMsg']      =       'Response received Successfully '.$msg_txt;    
                    
                    return json_encode( $response );
                    
                }else{
                    
                    $response['status']         =   0;
                    $response['msg']            =   'failed';                    
                    $response['errMsg']         =   'Invalid try';   
                    
                    if( empty( $round ) ){
                        $response['errMsg']     =   'Invalid try'.' Round information not avaialable ';    
                    }
                    if( empty( $bookdetails ) ){
                        $response['errMsg']     =   'Invalid try'.' Bookdetails information not avaialable ';    
                    }
                    
                }
                    
                    return json_encode( $response );
                    
                }
                
            }catch( \Exception $e ){
                
                $response['status']      =       0;
                $response['msg']         =       'Error';
                $response['errMsg']      =       $e->getMessage();
                $response['details']      =       $e->getTraceAsString();
                $err_handle              =       new errorController();
                $errorid                 =       $err_handle->handleApplicationErrors( $e );
                
                return json_encode( $response );
                
        }
        
    }
    
    public function executeS650MonoCorrectionDownloadInsert( $jobId , $round , $bookid , $getlocationftp , $response , $eproofresponse , $inputarr ){
        
        $response['status'] =   0;
        $response['Msg']    =   'failed';
        $response['errMsg'] =   'oops! , Something went wrong';
        
        try{ 
		
	    
			$coverCorrection 	= 	' {"CorrectionDetails":{"BookID":"'.$bookid.'","ChapterID":"COVER","TextCorrection":{"NumberOfCorrections":"0"},"ImageCorrection":null,"NumberOfAuthorQueries":"0","NumberOfAttachments":"0","IndexCorrection":{"NumberOfCorrections":"0"}}}';
			
			$eproofresponse[]		 = 		 json_decode( $coverCorrection );			
			$arrayin                 =       $eproofresponse;	//json_decode( $eproofresponse , FALSE );
		 
			$insert_arr_mono         =       array(); 
			$insert_arr_stri         =       array(); 
			$fieldValue_str          =       ''; 
			$lstrec                  =       '';
								
            if( !empty( $arrayin ) ){

                $lstrec      =   	count( $arrayin )  - 1;
                $incc   	 =   	0;

                 foreach( $arrayin as $key => $addionalobj ){
                   
                    $insert_arr_mono    =       array();
                    $eproofresponse     =       isset( $addionalobj->CorrectionDetails ) ? $addionalobj->CorrectionDetails : 'nocorrectionxml';
                    $metaid             =       $this->getMetaidForthisCorrectionDownload(  $eproofresponse , $inputarr , $jobId );
                    
                    $corrCntrl          =        new \App\Http\Controllers\correction\correctionController();
                    $corrCntrl->sendInputForCorrectionTableDataInsertMonoDataPrepare(  $jobId , $metaid , $round , $addionalobj , $insert_arr_mono );

                    $arr_val			 =		array_values( $insert_arr_mono );
                    $fieldValue_str		.= 		"('".implode( "','" , $arr_val )."')";

                    if( $lstrec > $incc ){
                        $fieldValue_str     .=  ' , ';
                    }

                    $incc++;

                 }

                 $arr_key				=   	array_keys( $insert_arr_mono );
                 $fieldName             =   	implode( "," , $arr_key );
                 $queryStmt             =   	'';    
                 $queryStmt            .=   	"INSERT INTO `api_correction_download_mono` ( $fieldName )  VALUES  $fieldValue_str";	
                 $insertResp            =   	DB::insert( $queryStmt );

				if( $insertResp ){
					$response['status']     =   1;
					$response['Msg']    =   'success';
					$response['errMsg'] =   'Successfully completed';
				}
                    
             }

        
		   } catch (Exception $ex) {
			   
			   $response['reason']  =   $ex->getMessage();
			   return response()->json( $response );		   
			   
		   }
       
        return response()->json( $response );
    }
    
    public function executeCorrectionJobsheetSimultaniously( $jobid, $round , $process , $metaid = null ){

            $ch             = 	curl_init();
            $base_url       =   \Config::get('constants.BASE_URL');

            $params         =   "$jobid/$round/$process/$metaid";
            
            if( is_null( $metaid ) ){
                $params         =   "$jobid/$round/$process";
            }
            
            $request        =	$base_url.'api/sendInputForJobsheetUpdate/'.$params;

            try{

                Log::useDailyFiles( storage_path().'/Api/correctionjobsheetupdateinput.log' );
                Log::info( json_encode( $request ) );

                curl_setopt($ch, CURLOPT_URL , $request);
                curl_setopt($ch, CURLOPT_FRESH_CONNECT, true);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT , 1 );
                curl_exec($ch);
                curl_close($ch);

            }catch( \Exception $ex ){

                Log::useDailyFiles( storage_path().'/Api/correctionjobsheetupdateFailure.log' );
                Log::info( json_encode( $request ) );
                return false;
                
            }

            return true;	
    }
	
    public function getRecipientFromResponse( $recipObj ){
		
        $newbuildObj['Status'] = $recipObj->Status;

        if( isset( $recipObj->ProofRecipient )  ){

            if( count( $recipObj->ProofRecipient ) > 1  ){

                foreach( $recipObj->ProofRecipient as $key => $value ){
                    $value = (array)$value;
                    if( strtolower( $value['@CorrectionsRequired'] )  == 'yes'){
                        $newbuildObj['ProofRecipient']	=	$value;
                        return (object)$newbuildObj;
                    }
                }

            }

        }

        return $recipObj;
    }
	
    public function getMetaidForthisCorrectionDownload( $eproofresponse ,  $inputarr , $jobId ){

        $getmetaid  = false;
       
        if( is_object( $eproofresponse ) ){

            $chap_name          =       $eproofresponse->ChapterID;
            $chap_name_c          =       $eproofresponse->ChapterID;
            $chp_obj            =       explode( '_' , $eproofresponse->ChapterID );

            if( count( $chp_obj ) == 2 ){
                
                $chap_name      =       ( $chp_obj[1].'_'.$chp_obj[0] );
                
                if( strpos( strtolower( $chap_name_c ) , 'part') ){
                    $chap_name  =   'PART_'.$chp_obj[0];
                }
                if( strpos( strtolower( $chap_name_c ) , 'kbackmatter') ){
                    $chap_name  =   'BM1';
                }
                if( strpos( strtolower( $chap_name_c ) , 'kfrontmatter') ){
                    $chap_name  =   'FM1';
                }
            }else{
                
                if( strpos( strtolower($chap_name_c ) , 'kbackmatter') ){
                    $chap_name  =   'BM1';
                }
                if( strpos( strtolower($chap_name_c ) , 'kfrontmatter') ){
                    $chap_name  =   'FM1';
                }
            }
            
            $query      =       "select METADATA_ID from task_level_metadata where JOB_ID = $jobId and LOWER(CHAPTER_NO) =  '".strtolower( $chap_name )."'";
            $recset     =       DB::select( $query );   

            if( count( $recset ) ){

                $rec_task   =       $recset[0];
                if( !empty( $rec_task ) ){
                    $getmetaid     =   $rec_task->METADATA_ID;
                }else{

                }

            }

        }else{

           $getmetaid	=	$this->getMetaidBasedOnEproofUploadzip(  $inputarr );

        }

        return $getmetaid;

    }
	
    public function getMetaidBasedOnEproofUploadzip( $inputarr ){
        
       $downobj                 =	$inputarr->Download;
       $correctionFile		=	( $downobj->FileName );
       $arrInfo				=	explode( '=' , $correctionFile );
       $bookinfopre			=	explode( '_' , $arrInfo[1] );
       $chaptid				=	explode( '_' , $arrInfo[2] );

       $preparebookzipname	=	"BookTitleID=$bookinfopre[0]_EditionNumber=$bookinfopre[1]_Language=$bookinfopre[2]_Chapter=$chaptid[0]_eProof_Contri_";
       $recobj 		=		DB::select( "select METADATA_ID from api_eproof_packaging where PACKAGE_ID LIKE '%".$preparebookzipname."%'  ORDER BY ID DESC LIMIT 1" );
        if( count( $recobj ) ){
                     return $recobj[0]->METADATA_ID;
        }

        return false;
    }
	
    public function callMoveToWomatTaps($data){
        
       
        $metaId         =       $data['metadataId'];
        $tsklMeta       =       new taskLevelMetadataModel();
        $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaId );
        $metadata       =       $meta_info->toArray();
        
        $bookInfo         =       jobModel::getJobdetails( $data['jobId'] );
        $processType      =       $bookInfo->PRODUCTION_SYSTEM;
        
        if(empty($processType)){
            return false;
        }
        
       $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
       $data['ChapterNo']        =        $metadata[0]['CHAPTER_NO'];
       $data['ChapterTitle']     =        $metadata[0]['CHAPTER_NAME'];
       $data['tapsstype']        =        $processType;
       $data['skipval']          =        'validate';
       
        $url                =   \Config::get('constants.BASE_URL')."/api/domovenonTaps";
        
        $getToolresponse    =   app('App\Http\Controllers\CommonMethodsController')->PostcUrlExecution($data,$url,0);
        
        return true;
      
    }
    
    public function prepareRawpathForDownload( $jobid , $round , $metaid , $getlocationftp , &$response , $eproofresponse ){

        $rawpath       =       '';
        $round_arr          =       \Config::get('constants.ROUND_ID');
        $roundname          =       $round_arr[$round];
        
        $downloadPath       =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION');
        
        if( $eproofresponse == 'nocorrectionxml' && 'S600' !== $roundname ){
            $downloadPath       =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_PRODUCTION_STORAGE_LOCATION');
        }
        
        if( $round_arr['S600'] == $round ){
            $downloadPath       =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_600');
        } 
		
        if( $round_arr['S650'] == $round ){
            $downloadPath       =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_650');
        }  
        
        if( $round_arr['S300'] == $round || $round_arr['S600'] == $round || $round_arr['S650'] == $round ){
              $cmn_obj          =       new CommonMethodsController();
              $defaultCopyPath  =       $cmn_obj->backslashPathPrepare( $downloadPath , true );
              $bookInfo         =       jobModel::getJobdetails( $jobid );
              $book_id          =       $bookInfo->BOOK_ID;
                    
              $inp_rep_arr      =       array( 
                                            '{BID}'     =>      $book_id    , 
                                            '{RID}'     =>      $roundname  ,                                                 
                                            '{CID}'     =>      ''  ,                                                 
                                        );
               
              
                if( isset( $metaid ) )    { 
                    
                    $tsklMeta       =       new taskLevelMetadataModel();
                    $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                    $metadata       =       $meta_info->toArray();
                    $chapter_name   =       ( $metadata[0]['CHAPTER_NO'] );
                    $inp_rep_arr['{CID}']   =       $chapter_name;
                    
                }
                
                $rawpath    =   $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath );
                     
            $response['rawPath']  =  $rawpath;
            
        }        
        
    }
    
    public function correctionWorkflowMovetoProduction( $jobId , $metaid , &$round , $eproofresponse , &$response, $metaType='' ){
        
        //do the workflow - move to production
        
        if( $eproofresponse == 'nocorrectionxml' ){
            
            $author_cor  =   1; 
            $idx_cor		=	0;
            $txt_cor		=	0;
            $img_cor_flag	=	0;
		   
        }else{
			
            $text_cor          =        (array)$eproofresponse->TextCorrection;
            $imag_cor          =        (array)$eproofresponse->ImageCorrection;
            $indx_cor          =        (array)$eproofresponse->IndexCorrection;
            $author_cor        =        isset( $eproofresponse->NumberOfAuthorQueries ) ? $eproofresponse->NumberOfAuthorQueries : 0;
	
            $txt_cor           =   	isset( $text_cor['NumberOfCorrections'] ) ? $text_cor['NumberOfCorrections'] : 0;
            $img_cor_flag      =   	isset( $imag_cor['Image'] ) ? count( $imag_cor )  : 0;
            $idx_cor           =   	isset( $indx_cor['NumberOfCorrections'] ) ? $indx_cor['NumberOfCorrections'] : 0;

        }		
		
        
        $quanity    =   10;
		
		$chapter_arr         	=       taskLevelMetadataModel::select( DB::raw( 'task_level_metadata.*,metadata_info.*' ) )
											->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
											->where('task_level_metadata.METADATA_ID', $metaid )
											->get()->first();    
											
		if( !empty( $chapter_arr ) ){
			if( !empty( $chapter_arr['END_PAGE'] ) ){
				$quanity    =   $chapter_arr['END_PAGE'];
			}
		}			
		
        $duedate    =   date('Y-m-d H:i:s');
        $workflowid =   '';
        $response_  =   array();
        $round_arr          =       \Config::get('constants.ROUND_ID');
        
        $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
        $book_id            =       $bookId             =       $jobDetails[0]->BOOK_ID;
        $returnLatest_      =       DB::select( "SELECT round FROM api_download WHERE BOOK_ID LIKE '%".$book_id."%' AND ROUND IN( ".$round_arr['S600']." )"  );
        $roundPromo         =       $round_arr['118'];
        
        if( count( $returnLatest_ ) ){
            $roundid    =   $round_arr['S650'];
            $round      =   $roundid;
            //return false; // requerment changes received 
            $roundPromo = $round_arr['120'];
        }
        
        if( $txt_cor || $idx_cor || $author_cor ){

            $wrftype        =           0;
            $masterid       =           \Config::get('constants.WORKFLOW.S300.MASTER_ID_ERR');       
            
            if( $roundPromo == 'S650' ){
				if(!empty($metaType) &&  ($metaType == 1 || $metaType == 3)){
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_FM_CORRECTION');
				}else{
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_CORRECTION');
				}
            }
            
            if( $author_cor && $txt_cor == 0 && $idx_cor == 0 ){
                $masterid       =            \Config::get('constants.WORKFLOW.S300.MASTER_ID_AUTHOR');  
                
                if( $roundPromo == 'S650' ){
					if(!empty($metaType) &&  $metaType == 1){
						$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_FM');
					}else{
					    $masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_PAGINATION');
					}
                }
                
            }
            
           
            $wrkflw_mdl     =           new workflowModel();
            $wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
            $workflowid     =           $wfdata->WORKFLOW_ID;
            $mvtoProd       =           new movetoproductionController();
            $response_      =           $mvtoProd->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype  );

        }  
        
        if( $txt_cor == 0 && $idx_cor == 0 && $author_cor == 0 ){ 

            $wrftype    =   0;
            //$update         =   	jobInfoModel::where('JOB_ID',$jobId)->update(['WORKFLOW_TYPE'=>\Config::get('constants.WORKFLOW.S300.MASTER_ID')]);
            $masterid       =           \Config::get('constants.WORKFLOW.S300.MASTER_ID');
            
            if( $roundPromo == 'S650' ){
				
				if(!empty( $metaType ) &&  ( $metaType == 1 || $metaType == 3 )){
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_FM');
				}else if(!empty($metaType) &&  $metaType == 5){
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_COVER');
				}else if(!empty($metaType) &&  $metaType == 6){
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_INDEX');
				}else{
					$masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_PAGINATION');
				}

            }
            
            $wrkflw_mdl     =           new workflowModel();
            $wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
            $workflowid     =           $wfdata->WORKFLOW_ID;
            $mvtoProd       =           new movetoproductionController();
            
            $response_      =           $mvtoProd->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype );
           
            if( $roundPromo  == 'S300' ){
                $this->triggers300NonCorrectionPackaging( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype );
            }
            
        }

        if( $img_cor_flag ){

            $wrftype    =   2;
            //$update         =           jobInfoModel::where('JOB_ID',$jobId)->update(['WORKFLOW_TYPE'=>\Config::get('constants.WORKFLOW.S300.MASTER_ID_ERR')]);
            $masterid       =           \Config::get('constants.WORKFLOW.S300.MASTER_ID_ERR');
		
            if( $roundPromo == 'S650' ){
                $masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_CORRECTION');
            }	
           
            if( $author_cor && $txt_cor == 0 && $idx_cor == 0 ){
                $masterid       =            \Config::get('constants.WORKFLOW.S300.MASTER_ID_AUTHOR');       
                
                if( $roundPromo == 'S650' ){
                    $masterid       =            \Config::get('constants.WORKFLOW.S650.MASTER_ID_PAGINATION');
                }	
           
            }
						
             
            $wrkflw_mdl     =           new workflowModel();
            $wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
			
            $workflowid     =           $wfdata->WORKFLOW_ID;
            $mvtoProd       =           new movetoproductionController();
            $artinfo        =  		isset( $imag_cor['Image'] ) ? $imag_cor['Image'] : array(); 
            $remarks        =		'Author correction received for : '.implode( ', ' , $artinfo );
            $chkObj         =		new checkOutController();
            $artmetaid      =		array();
			
            if( count( $artinfo ) ){

                foreach( $artinfo as $key => $value ){
					
                    $records		=		DB::select( "select * from task_level_art_metadata where FILE_NAME LIKE '%$value%'");
                    if( isset( $records ) ){
                            $artmetaid[]	=	$records[0]->ART_METADATA_ID;
                    }
                    
                }
                
            }
			
            $response1_     =			$chkObj->artMovetoProductionAndRecjectSelectedArt( $metaid , $artmetaid , $remarks , $round );
			
            if( $response1_  ){
                $this->updateSelectedArtStatusChange( $metaid , $artinfo , $remarks );
            }
            
            $this->sendMailtoArtTeamForCorrectionFailed( $jobId , $round , $metaid , $eproofresponse );
            
        }
        
        $response[]         =           $response_;
        
        return $response;
        
    }

    public function s300directPack(){
            $duedate	=	date('Y-m-d H:i;s');
            $this->triggers300NonCorrectionPackaging( 6548 , 118 , 123 , 4172 , 10 , $duedate , 0 );
    }

    public function updateSelectedArtStatusChange( $metaid , $artinfo , $remarks ){

            $artmetaid		=	array();
			
            if( count( $artinfo ) ){

                foreach( $artinfo as $key => $value ){
					
                    $records		=		DB::select( "select * from task_level_art_metadata where FILE_NAME LIKE '%$value%'");
                    if( isset( $records ) ){
                            $artmetaid[]	=	$records[0]->ART_METADATA_ID;
                    }
                }
                
            }
            
            if( !empty( $artmetaid ) ){
                $string_art 		=		implode( ',' , $artmetaid  );
                DB::update( 'update task_level_art_metadata set STATUS_ENUM_ID = 45 , REMARKS = "'.$remarks.'"  where ART_METADATA_ID in ( '.$string_art.' ) ' );
            }

    }
	
    public function skipStageCorrection( $metaid , $round  ){

        $jbstgObj               =       new jobStage();
        $getCurrnt_stage 	=       $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 27  );
        $response		=	array();

        if( count( $getCurrnt_stage ) ){

                $jbstgInfo              =       $getCurrnt_stage[0];
                $job_round_id           =       $jbstgInfo->JOB_ROUND_ID;
                $job_stage_id           =       $jbstgInfo->JOB_STAGE_ID;
                $checkoutObj            =       new checkoutModel();
                $stageDetails           =       $checkoutObj->getStageInfo($job_stage_id);
                $stageData      		=		$stageDetails[0];

                $jobRoundId             =       $stageData->JOB_ROUND_ID;
                $roundId                =       $stageData->ROUND_ID;
                $stageSequence          =       $stageData->STAGE_SEQ;
                $workflowId             =       $stageData->WORKFLOW_ID;  
                $iteration              =       $stageData->ITERATION_ID;
                $jobId                  =       $stageData->JOB_ID;
                $curjobstgid            =       $stageData->JOB_STAGE_ID;        
                $outputQuantity         =   	$stageData->OUTPUT_QUANTITY;
                $inputQuantity          =   	$stageData->INPUT_QUANTITY;

                $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);

        }

        $response		=		projectModel::skipStage( $stageSequence, $job_stage_id, $inputQuantity, $jobRoundId , $iteration, $response );

    }
	
    public function triggers300NonCorrectionPackaging( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype ){

        $wrkflw_mdl     =           new workflowModel();
        //$wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
        //$workflowid     =           $wfdata->WORKFLOW_ID;
        $mvtoProd       =           new movetoproductionController();

        $response_      =           $mvtoProd->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype  );

        $jbstgObj		=			new jobStage();
        $getCurrnt_stage        =			$jbstgObj->getCurrentJobStageInfo( $metaid , $round , 27  );						

        if( count( $getCurrnt_stage ) ){

            $jbstgInfo		=       $getCurrnt_stage[0];
            $job_round_id           =       $jbstgInfo->JOB_ROUND_ID;
            $job_stage_id           =       $jbstgInfo->JOB_STAGE_ID;

            $checkoutObj            =       new checkoutModel();
            $stageDetails           =       $checkoutObj->getStageInfo($job_stage_id);
            $stageData              =       $stageDetails[0];

            $jobRoundId             =       $stageData->JOB_ROUND_ID;
            $roundId                =       $stageData->ROUND_ID;
            $stageSequence          =       $stageData->STAGE_SEQ;
            $workflowId             =       $stageData->WORKFLOW_ID;  
            $iteration              =       $stageData->ITERATION_ID;
            $jobId                  =       $stageData->JOB_ID;
            $curjobstgid            =       $stageData->JOB_STAGE_ID;        
            $outputQuantity         =   	$stageData->OUTPUT_QUANTITY;
            $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);

            if(!empty($nexstageDetails)){

                $nextJobStageId 	=   $nexstageDetails->JOB_STAGE_ID;
                $nextStageId        =   $nexstageDetails->STAGE_ID;
                $userDefData    	=   taskLevelUserdefinedWorkflow::getUserDefineStageDetails( $jobId, $workflowId , $round , $nextStageId );
                $stageType      	=   $userDefData->IS_AUTO;

                $updateStageParam       =       array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $outputQuantity);
                $updateQry              =       DB::table('job_stage')
                                                ->where('JOB_STAGE_ID', $nextJobStageId )
                                                ->update( $updateStageParam );

                $jobRoundValue1         =       array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
                $updateQry              =       DB::table('job_round')
                                                    ->where('JOB_ROUND_ID', $jobRoundId )
                                                    ->update( $jobRoundValue1 );

                $jobRoundValue2           =     array( 'CURRENT_STAGE' => $nextStageId , 'CURRENT_ROUND' => $round );
                $updateQry                =     DB::table('task_level_metadata')
                                                   ->where( 'METADATA_ID', $metaid )
                                                   ->update( $jobRoundValue2 );


                $stgMgCntrlr		=		new stageMangerController();
                $ret_status     =   $stgMgCntrlr->handlingAutoStages( $nextStageId , $nextJobStageId ); 

                //$returns        =       projectModel::skipStage( 1 , $job_stage_id, $quanity, $job_round_id , 1  );

            }

        }

    }
    
    public function sendMailtoArtTeamForCorrectionFailed( $jobid , $round , $metaid , $eproofresponse ){
        
        $mailArray      =   array();

        $chap_name          =       $eproofresponse->ChapterID;
        $bookid             =       $eproofresponse->BookID;
        $chp_obj            =       explode( '_' , $eproofresponse->ChapterID );
                          
        if( count( $chp_obj ) == 2 ){
            $chap_name      =       ( $chp_obj[1].'_'.$chp_obj[0] );
        }
        
        $mailData['Title']      =   'Art Correction alert';
        $mailData['HeadLine']   =   'Art Correction alert';  
        $mailData['ToName']     =   'Dear PM / Art Team';  
        $mailData['BookId']     =   $bookid;  
        $mailData['chap_no']    =   $chap_name;  
        $mailArray['Data']      =   $mailData;
        
        $imag_cor               =        (array)$eproofresponse->ImageCorrection;
        $imagname_arr           =        array();
        $artinfo        		=  		 isset( $imag_cor['Image'] ) ? $imag_cor['Image'] : $imag_cor; 
            
        foreach( $artinfo as $index => $value_ ){
            $imagname_arr[]    =   $value_;         
        }
        
        $mailArray['Data']['errorList']          =       $imagname_arr;
        $chpter_no                  =       preg_replace( '/\D/' , '', $chap_name );
        $mailData['chap_no']        =       $chpter_no;
        $mailArray['Subject']       =       'Springer :: Eproof Art Corrections Notification :: BookID: '.$bookid.' :: Chapter No. - : '.$chpter_no. ' :: eproof_Contri';   
        
        if( $round == 120 ){
            $mailArray['Subject']       =       'Springer :: Eproof Art Corrections Notification :: BookID: '.$bookid.' :: Chapter No. - : '.$chpter_no. ' :: eproof_Mono';      
        }
        
        $mailArray['FromMail']      =       'SPI-eProofing@spi-global.com';
        $mailArray['ToMail']        =        \Config::get('constants.ART_CORRECTION_MAIL_ALERT');
        $mailArray['TemplateName']  =        'emailtemplate.download.clientAckCorrectionArtFailed';
        
        $this->sendMailBladeTemplate( $mailArray );
        
    }
    
    public function sendRetryRequest( $jobId = null , $round = 114 ){
        
        $input_arr      =      array();        
        $time = date( 'Y-m-d H:i:s' );	
        
        $response['status']  =      0;
        $response['msg']     =     'Failed';
        $response['errMsg']  =     'Try again after some times';
        
        try
        {            
            $api_tbl_input      =       array( 'JOB_ID' => $jobId , 'ROUND' => $round  , 'START_TIME' => $time );
            $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
            $api_tbl_input['BOOK_ID']    =       $bookId             =       $jobDetails[0]->BOOK_ID;

            $curl = \Config::get('constants.WS_OF_CLIENTACKNOWLEDGE');

            $cmn_obj        =       new CommonMethodsController();
            
            $data           =       $api_tbl_input;
            $data['bookid'] =       $bookId;
            
            $returns_response        =       $cmn_obj->PostcUrlExecution( $data , $curl );
            
            if( $returns_response['http_code'] !== 200 ){
                $api_tbl_input['REMARKS']        =       $returns_response['curl_err'];
                $api_tbl_input['STATUS']         =        0;
            }
            
            $getResponse        =        apiClientAcknowledgement::insertNew( $api_tbl_input );
            
            if( $getResponse  ==  2  ){
                  
                $response['status']  =     1;
                $response['msg']     =     'Success';
                $response['errMsg']  =     'Api request send  successfully';    
            
            }
            
        }catch( \Exception $e ){
            
             $response['errMsg']    =   $e->getMessage();
             
        }
        
        return $response;
             
    }
    
    public function triggerNotificationProofRun( $obj_data ){
        
        $jobid          =       $obj_data->JOB_ID;
        $metaid         =       null;
        $round          =       $obj_data->ROUND;
        
        if( !empty( $obj_data->METADATA_ID ) ){
            $metaid     =       $obj_data->METADATA_ID;
        }
        
        $newmetExt      =       new MetaExtractorController();
        return $newmetExt->sendInputForJobsheetUpdate( $jobid , $round , 'NOTIFICATION' , $metaid  );
        
    }
    
    public function sendLogMailtoAMorPM( $in_data ,$round ){
        
        $mailArray  =   $mailData   =       array();
        $data_in['book_id']         =       $book_id        =       $in_data['BOOK_ID'];
        
        $job_info       =       DB::table( 'job as j' )
                                ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                ->where( 'BOOK_ID' , 'LIKE', '%'.$book_id.'%')
                                ->select()
                                ->get()->first();
       
        $pm_userid          =       $job_info->PM;
        $am_userid          =       $job_info->AM;
        
        $jobId =   $job_info->JOB_ID;
        $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
         
        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        $ftpObj = \Storage::createFtpDriver([
		'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
		'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
		'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
		'port'     => '21',
		'timeout'  => '30',
            ]);  
             
         
        if( !empty( $pm_userid ) ){
            
           $usrC_obj        =       new usersController();
           $user_arr        =       $usrC_obj->getUserInfoByUserId($pm_userid); 
           $pm_name         =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
           $pm_mail         =       $user_arr->EMAIL;
           
           $mailData['ToName']      =        $pm_name;
           $mailArray['ToMail']     =        $pm_mail;
           $mailArray['CcMail']     =        $job_info->AM_MAIL;
           
           $data_in['user_id']      =        $pm_userid; 
           
        }else if( !empty( $am_userid )){
        
            $am_name                =       $job_info->AM_NAME;
            $am_mail                =       $job_info->AM_MAIL;
            
            $mailData['ToName']     =       $am_name;
            $mailArray['ToMail']    =       $am_mail;
            $data_in['user_id']     =       $am_userid;  
            
        }else{
            return false;
        }
        
        $jobDetails     =   DB::table('job AS j')
                                ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                ->join('user as u','j.PM','=','u.USER_ID')
                                 ->join('user as u1','ji.AM','=','u1.USER_ID')
                                ->where('j.BOOK_ID', '=' ,   $book_id )
                                ->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.AUTHOR_NAME,ji.EDITOR_NAME,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_ONLINE,u1.EMAIL as PMemail,u1.EMAIL as AMemail ,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,concat(u1.FIRST_NAME," ",u1.LAST_NAME) AS AMname'))
                               ->first();

        $pickroundname  =   [ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
        $stagename      =   (isset($pickroundname[$round])?$pickroundname[$round]:'');
        $jobDetails     =   (array) $jobDetails;
        
        $mailData['Title']      =   '';
        $mailData['HeadLine']   =  '';  
        // 'Client Acknowledgement Received - '.$in_data['status_txt'];
        $mailData['BookId']         =       $jobDetails['BOOK_ID'];
        $mailData['BookTitle']      =       $jobDetails['JOB_TITLE'];
        $mailData['authorname']     =       $jobDetails['AUTHOR_NAME'];
        $mailData['editorname']     =       $jobDetails['EDITOR_NAME'];
        $mailData['BookIsbn']       =       $jobDetails['ISSN_ONLINE'];
        $mailData['status_txt']     =       $in_data['status_txt'];
        $mailData['ReceivedDate']   =       $jobDetails['JOB_ASSIGNED_DATE'];
        
        $mailArray['TemplateName']  =        'emailtemplate.download.clientAck';
        $subjectmsg                 =   ($in_data['STATUS'] == 2?'success':'error');
        
        $mailData['status_txt']     =       $subjectmsg;
        
        $mailArray['Subject']   =   'BFlux '.$subjectmsg.' Log Alert - BookID: '.$jobDetails['BOOK_ID'].' - '.$stagename;
        
        $chapterno_info     =       $this->getChapterNoByfilenameLog( $in_data['FILE_NAME'] );
        
        if( $chapterno_info ){            
            $mailData['chapterno']      =       $chapterno_info;
            $mailArray['TemplateName']  =       'emailtemplate.download.clientAckChapter';
            $mailArray['Subject']       =       'BFlux '.$subjectmsg.' Log Alert - BookID: '.$jobDetails['BOOK_ID'].' :: Chapter No. - '.$chapterno_info.' :: - '.$stagename;                
        }
        
        $mailArray['Data']          =       $mailData;
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        
        $success_path       =       \Config::get('constants.WATCH_CLIENT_ACK_SUCCESS_WATCH_FOLDER');
        $redo_path          =       \Config::get('constants.WATCH_CLIENT_ACK_REDO_WATCH_FOLDER');
        
        //confirm the attach path based on condition [ success / redo ]
        $log_file_path      =       $in_data['FILE_NAME'];
        if( $in_data['STATUS'] == 2 ){
            $getting_path           =   $success_path;  
            $destinationlogdir      =   Config::get('constants.COPY_CLIENT_ACK_FOLDER_SUCCESS').$log_file_path;
            $this->doClientlogfilecreation($ftpObj,$getting_path.$log_file_path,$destinationlogdir,$book_id,$round);
        }else{
            $getting_path           =   $redo_path;  
            $destinationlogdir      =   Config::get('constants.COPY_CLIENT_ACK_FOLDER_FAILED').$log_file_path;
            $this->doClientlogfilecreation($ftpObj,$getting_path.$log_file_path,$destinationlogdir,$book_id,$round);
        }
        
        $file_ob        =           $ftpObj->get( $getting_path.$log_file_path );
        $created_filename   =   'downloaded_'.date('Y_m_d_H_i_s').'.log';
        $path = storage_path().'/'.'success_redo_log/'.$created_filename;      
        $mailArray['created_file']     =        $path;
        ini_set('max_execution_time'  , 0 );
        file_put_contents( storage_path().'/'.'success_redo_log/'.$created_filename ,  $file_ob );
        $mailArray['file']      =   $path;
        $mailArray['attachfile']    =   array('as' => $in_data['FILE_NAME'] , 'mime' => 'text/plain');
		
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
     
    public function getChapterNoByfilenameLog( $filenamelog = null ){
        
        
        if( !is_null( $filenamelog ) ){
            
            $array_input        =       explode( '=' , $filenamelog );
            
            if( count( $array_input ) > 4 ){
               
                $lastind        =       count( $array_input ) - 1;
                $chapterno      =       explode( '_' ,  $array_input[$lastind] );
                
                if( strpos( strtolower( $filenamelog ) , 'part' ) ){
                    return 'PART'.$chapterno[0];
                }
                
                return $chapterno[0];
                
            }
            
        }
        
        return false;
        
        
    }
    
    public function sendCorrectionLogMailtoAMorPM( $in_data , $round , $filteredInp , $addionalobj , $metaid , &$response = array()){
        
        $mailArray 				= 		$mailData 		=		array();
        $data_in['book_id']     =       $book_id        =       $in_data['BOOK_ID'];
        $round_arr      		=       \Config::get('constants.ROUND_NAME');
        $roundname              =		$round_arr[$round];
        $success_path           =       \Config::get('constants.CORRECTION_DOWNLOADED_ZIP_TOOLS_LOCATION');
        $productionserverSuccessCopy    =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION');
        
        $taskLevelObj           =       new \App\Models\taskLevelMetadataModel();
        $taskLevelInfo          =       $taskLevelObj->getMetadatadetailsChapter( $metaid );
        
        $chapterlist            =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $chapter_name           =       $chapterlist[0];
        
        $inp_rep_arr            =       array( 
                                            '{BID}'         =>      $book_id    ,
                                            '{RID}'         =>      $roundname  ,
                                            '{CID}'         =>      $chapter_name
                                        );

        $cmn_obj                =       new CommonMethodsController();	
        
        $productionserverSuccessCopy 	=       $raw_path       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $productionserverSuccessCopy );
        $response['rawPath']            =       $cmn_obj->backslashPathPrepare( $productionserverSuccessCopy , true );			
        
        $job_info       =       DB::table( 'job as j' )
                                    ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                    ->where( 'BOOK_ID' , 'LIKE', '%'.$book_id.'%')
                                    ->select()
                                    ->get()->first();
               
        $pm_userid          =       $job_info->PM;
        $am_userid          =       $job_info->AM;
        $jobId              =       $job_info->JOB_ID;
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
        
        //need to dynamicaly bind the production location based on table location
        $hostserver         	=       $getlocationftp->FTP_HOST;
        $hostusername       	=       $getlocationftp->FTP_USER_NAME;
        $hostpassword      	=       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           	=       ($getlocationftp->FTP_PATH);
	
        if( !empty( $pm_userid ) ){
            
           $usrC_obj        =       new usersController();
           $user_arr        =       $usrC_obj->getUserInfoByUserId($pm_userid); 
           $pm_name         =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
           $pm_mail         =       $user_arr->EMAIL;
           
           $mailData['ToName']      =        $pm_name;
           $mailArray['ToMail']     =        $pm_mail;
           $data_in['user_id']      =        $pm_userid;  
           
        }else if( !empty( $am_userid )){
        
            $am_name                =       $job_info->AM_NAME;
            $am_mail                =       $job_info->AM_MAIL;
            
            $mailData['ToName']     =       $am_name;
            $mailArray['ToMail']    =       $am_userid;
            $data_in['user_id']     =       $am_userid;  
            
        }else{
            return false;
        }
		
        $mailArray['BccMail']  =  \Config::get('constants.BCC_EMAIL_LIST');
		
        $jobDetails     		=   		DB::table('job AS j')
												->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
												->join('user as u','j.PM','=','u.USER_ID')
												->join('user as u1','ji.AM','=','u1.USER_ID')
												->where('j.BOOK_ID', '=' ,   $book_id )
												->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.AUTHOR_NAME,ji.EDITOR_NAME,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_ONLINE,u1.EMAIL as PMemail,u1.EMAIL as AMemail ,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,concat(u1.FIRST_NAME," ",u1.LAST_NAME) AS AMname'))
												->first();
        
        $pickroundname  		=   	[ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
        $stagename      		=   	(isset($pickroundname[$round])?$pickroundname[$round]:'');
        $jobDetails     		=   	(array) $jobDetails;
        
        $mailData['Title']      =   '';
        $mailData['HeadLine']   =  '';  
		
        $mailData['BookId']         =       $jobDetails['BOOK_ID'];
        $mailData['BookTitle']      =       $jobDetails['JOB_TITLE'];
        $mailData['authorname']     =       $jobDetails['AUTHOR_NAME'];
        $mailData['editorname']     =       $jobDetails['EDITOR_NAME'];
        $mailData['BookIsbn']       =       $jobDetails['ISSN_ONLINE'];
        $mailData['status_txt']     =       $in_data['status_txt'];
        $mailData['ReceivedDate']   =       $jobDetails['JOB_ASSIGNED_DATE'];
        $mailArray['Data']          =       $mailData;
		
		$status_suffix              =       ($in_data['STATUS'] == 2)?'Success':'Failed';
        $bladename                  =       'clientAckCorrection'.$status_suffix;
        $mailArray['FromMail']      =       Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        	
        $subjectmsg                 =       $in_data['STATUS'] == 2	?	'success'	:	'error';
        $round_arr                  =       Config::get('constants.ROUND_NAME' );

        if( 'S300' ==   $round_arr[$round] && !empty($filteredInp) ){		
            $bladename          =       'clientAckCorrection'.$status_suffix;
            $chapter_no         =        preg_replace( '/\D/', '', $chapter_name );            
            $mailArray['Data']['chap_no']       =	$chapter_no;
            $mailArray['Subject']   		=   	'Springer :: Correction '.ucfirst( $subjectmsg ).' Notification :: BookID: - '.$jobDetails['BOOK_ID'].' :: Chapter No. - '.$chapter_no.' :: eproof_Contri ';
        }
        
        if( 'S600' ==   $round_arr[$round] || 'S650' ==   $round_arr[$round] && !empty($filteredInp) ){
            if( $status_suffix == 'Success' ){
                $bladename          =       's600clientAckCorrection'.$status_suffix;
            }
            $mailArray['Data']['corrrectionpath']   =   '';
            
            if( isset( $response['rawPath'] ) ){
                $mailArray['Data']['corrrectionpath']       =   $response['rawPath'];
            }
            
            $chapter_no         =        preg_replace( '/\D/', '', $chapter_name );            
            $mailArray['Data']['chap_no']	=	$chapter_no;
            
            $mailArray['Subject']   		=   	'Springer :: Eproof Late Correction Received Notification :: BookID: - '.$jobDetails['BOOK_ID'].' :: Chapter No. - '.$chapter_no.' :: eproof_Contri ';
           
        }
        
        $mailArray['TemplateName']  =       'emailtemplate.download.'.$bladename;
        
        return $Response = $this->sendMailBladeTemplate( $mailArray );

    }
    
    public function sendCorrectionLogMailtoAMorPMS650( $in_data , $round , $filteredInp , $addionalobj , &$response = array()){
        
        $mailArray 				= 		$mailData 		=		array();
        $data_in['book_id']     =       $book_id        =       $in_data['BOOK_ID'];
        
		$round_arr      		=       \Config::get('constants.ROUND_NAME');
        $roundname              =		$round_arr[$round];
        $success_path           =       \Config::get('constants.CORRECTION_DOWNLOADED_ZIP_TOOLS_LOCATION');
		
		$productionserverSuccessCopy    =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_650');
		if( $round == 120 ){
			$productionserverSuccessCopy    =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_650');
		}else if( $round == 119 ){
			$productionserverSuccessCopy    =       \Config::get('serverconstants.CORRECTION_DOWNLOAD_ZIP_PRODUCTION_STORAGE_LOCATION_600');
		}
		
        $inp_rep_arr            =       array( 
                                            '{BID}'         =>      $book_id    ,
                                            '{RID}'         =>      $roundname  ,                                           
                                        );

        $cmn_obj                =       new CommonMethodsController();	
        
        $productionserverSuccessCopy 	=       $raw_path       =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $productionserverSuccessCopy );
        $response['rawPath']            =       $cmn_obj->backslashPathPrepare( $productionserverSuccessCopy , true );			
        
        $job_info       =       DB::table( 'job as j' )
                                    ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                    ->where( 'BOOK_ID' , 'LIKE', '%'.$book_id.'%')
                                    ->select()
                                    ->get()->first();
               
        $pm_userid          =       $job_info->PM;
        $am_userid          =       $job_info->AM;
        $jobId              =       $job_info->JOB_ID;
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
        
        //need to dynamicaly bind the production location based on table location
        $hostserver         	=       $getlocationftp->FTP_HOST;
        $hostusername       	=       $getlocationftp->FTP_USER_NAME;
        $hostpassword      		=       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           	=       ($getlocationftp->FTP_PATH);
	
        if( !empty( $pm_userid ) ){
            
           $usrC_obj        =       new usersController();
           $user_arr        =       $usrC_obj->getUserInfoByUserId($pm_userid); 
           $pm_name         =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
           $pm_mail         =       $user_arr->EMAIL;
           
           $mailData['ToName']      =        $pm_name;
           $mailArray['ToMail']     =        $pm_mail;
           $data_in['user_id']      =        $pm_userid;  
           
        }else if( !empty( $am_userid )){
        
            $am_name                =       $job_info->AM_NAME;
            $am_mail                =       $job_info->AM_MAIL;
            
            $mailData['ToName']     =       $am_name;
            $mailArray['ToMail']    =       $am_userid;
            $data_in['user_id']     =       $am_userid;  
            
        }else{
            return false;
        }
		
        $mailArray['BccMail']  =  \Config::get('constants.BCC_EMAIL_LIST');
		
        $jobDetails     		=   		DB::table('job AS j')
												->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
												->join('user as u','j.PM','=','u.USER_ID')
												->join('user as u1','ji.AM','=','u1.USER_ID')
												->where('j.BOOK_ID', '=' ,   $book_id )
												->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.AUTHOR_NAME,ji.EDITOR_NAME,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_ONLINE,u1.EMAIL as PMemail,u1.EMAIL as AMemail ,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,concat(u1.FIRST_NAME," ",u1.LAST_NAME) AS AMname'))
												->first();
        
        $pickroundname  		=   	[ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
        $stagename      		=   	(isset($pickroundname[$round])?$pickroundname[$round]:'');
        $jobDetails     		=   	(array) $jobDetails;
        
        $mailData['Title']      =   '';
        $mailData['HeadLine']   =  '';  
		
        $mailData['BookId']         =       $jobDetails['BOOK_ID'];
        $mailData['BookTitle']      =       $jobDetails['JOB_TITLE'];
        $mailData['authorname']     =       $jobDetails['AUTHOR_NAME'];
        $mailData['editorname']     =       $jobDetails['EDITOR_NAME'];
        $mailData['BookIsbn']       =       $jobDetails['ISSN_ONLINE'];
        $mailData['status_txt']     =       $in_data['status_txt'];
        $mailData['ReceivedDate']   =       $jobDetails['JOB_ASSIGNED_DATE'];
        $mailArray['Data']          =       $mailData;
		
		$status_suffix              =       (	$in_data['STATUS'] == 2	)?'Success':'Failed';
        $bladename                  =       'clientAckCorrection'.$status_suffix;
        $mailArray['FromMail']      =       Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        	
        $subjectmsg                 =       $in_data['STATUS'] == 2	?	'success'	:	'error';
        $round_arr                  =       Config::get('constants.ROUND_NAME' );

        if( 'S600' ==   $round_arr[$round] || 'S650' ==   $round_arr[$round] && !empty( $filteredInp ) ){
            
            if( $status_suffix == 'Success' ){
                $bladename          =       's600clientAckCorrection'.$status_suffix;
            }
            
            $mailArray['Data']['corrrectionpath']   =   '';
            
            if( isset( $response['rawPath'] ) ){
                $mailArray['Data']['corrrectionpath']       =   $response['rawPath'];
            }
            
            $mailArray['Subject']   		=   	'Springer :: Eproof Correction Received Notification :: BookID: - '.$jobDetails['BOOK_ID'].' :: eproof_Mono ';
           
        }
        
        $mailArray['TemplateName']  =       'emailtemplate.download.'.$bladename;
        
        return $Response = $this->sendMailBladeTemplate( $mailArray );

    }
    
    public function sendEproofLogMailtoAMorPM( $in_data , $round , $filteredInp = array() , $addionalobj ){
        
        $mailArray 		 		 = 		$mailData 	= 		array();
        $data_in['book_id']      =      $book_id    =       $in_data['BOOK_ID'];
		
        $productionserverSuccessCopy		=		\Config::get('constants.EPROOF_CLIENT_ACK_PRODUCTION_STORAGE_LOCATION');  
        $redo_path 		=		$success_path       =        \Config::get('constants.EPROOF_TOOLS_CLIENT_ACK_LOG_LOCATION'); 
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $roundname		=		$round_arr[$round];

        $inp_rep_arr   	=       array( 
									'{BID}'         =>      $book_id , '{RID}' => $roundname  
								);

        $cmn_obj             =       new CommonMethodsController();								
        $productionserverSuccessCopy            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $productionserverSuccessCopy );
		$success_path       		        	=       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $success_path );
        
		$job_info                               =       DB::table( 'job as j' )
															->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
															->where( 'BOOK_ID' , 'LIKE', '%'.$book_id.'%')
															->select()
															->get()->first();
       
        $pm_userid          =       $job_info->PM;
        $am_userid          =       $job_info->AM;
        $jobId 				=   	$job_info->JOB_ID;
		
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) )
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
			
        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        
        $ftpObj				= 		\Storage::createFtpDriver([
											'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
											'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
											'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
											'port'     => '21',
											'timeout'  => '30',
									]);  
		
        if( !empty( $pm_userid ) ){
            
           $usrC_obj        =       new usersController();
           $user_arr        =       $usrC_obj->getUserInfoByUserId($pm_userid); 
           $pm_name         =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
           $pm_mail         =       $user_arr->EMAIL;
           
           $mailData['ToName']      =        $pm_name;
           $mailArray['ToMail']     =        $pm_mail;
           $data_in['user_id']      =        $pm_userid;  
           
        }else if( !empty( $am_userid )){
        
            $am_name                =       $job_info->AM_NAME;
            $am_mail                =       $job_info->AM_MAIL;
            
            $mailData['ToName']     =       $am_name;
            $mailArray['ToMail']    =       $am_userid;
            $data_in['user_id']     =       $am_userid;  
            
        }else{
            return false;
        }
		
        $jobDetails     	=   DB::table('job AS j')
									->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
									->join('user as u','j.PM','=','u.USER_ID')
									 ->join('user as u1','ji.AM','=','u1.USER_ID')
									->where('j.BOOK_ID', '=' ,   $book_id )
									->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.AUTHOR_NAME,ji.EDITOR_NAME,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_ONLINE,u1.EMAIL as PMemail,u1.EMAIL as AMemail ,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,concat(u1.FIRST_NAME," ",u1.LAST_NAME) AS AMname'))
								    ->first();
        
        $pickroundname  =   [ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
        $stagename      =   (isset($pickroundname[$round])?$pickroundname[$round]:'');
        $jobDetails     =   (array) $jobDetails;
        
        $mailData['Title']      =   '';
        $mailData['HeadLine']   =   '';  
		
        $mailData['BookId']         =       $jobDetails['BOOK_ID'];
        $mailData['BookTitle']      =       $jobDetails['JOB_TITLE'];
        $mailData['authorname']     =       $jobDetails['AUTHOR_NAME'];
        $mailData['editorname']     =       $jobDetails['EDITOR_NAME'];
        $mailData['BookIsbn']       =       $jobDetails['ISSN_ONLINE'];
        $mailData['status_txt']     =       $in_data['status_txt'];
        $mailData['ReceivedDate']   =       $jobDetails['JOB_ASSIGNED_DATE'];
        $mailArray['Data']          =       $mailData;
		
        $status_suffix              =       ( $in_data['STATUS'] == 2 )	?   'Success'   :   'Failed';
        $bladename                  =       'clientAckEproof'.$status_suffix;
        $mailArray['TemplateName']  =       'emailtemplate.download.'.$bladename;
        $subjectmsg                 =       ( $in_data['STATUS'] == 2  ? 'success' : 'error' );
        $mailArray['FromMail']      =       \Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $app_folder      			=   	'success_redo_log';
        $round_arr          		=       \Config::get('constants.ROUND_NAME' );

        if( ( 'S300' ==   $round_arr[$round] ) || ( 'S650' ==   $round_arr[$round] ) && !empty($filteredInp) ){

            $eproofresponse     =       $addionalobj->eProofResponse;
            $recipi             =       (array)$eproofresponse->Response;
            $resp_rem			=		(array)$recipi['Status'];
            $resp_rem			=		$resp_rem['#text'];
            
            if( isset( $eproofresponse->ChapterID ) &&  !empty(  $eproofresponse->ChapterID ) ){
                
                $chapter_no			=		$eproofresponse->ChapterID;
                $mailArray['Data']['chap_no']   =	$chapter_no;
                $mailArray['Subject']   =   'Springer :: Eproof '.ucfirst( $subjectmsg ).' Notification :: BookID: - '.$jobDetails['BOOK_ID'].' :: Chapter No. - '.$chapter_no.' :: eproof_Contri ';
            
            }else{
                
                $mailArray['Data']['chap_no']   =	'';
                $mailArray['Subject']   =   'Springer :: Eproof '.ucfirst( $subjectmsg ).' Notification :: BookID: - '.$jobDetails['BOOK_ID'].' :: eproof_Mono ';
            }
            
            if( $filteredInp['ProcessType']  ==  5 ){
                
                $app_folder         =       'eproof_signal_xml';
                if( $in_data['STATUS']  == 3  ){
                    $mailArray['Data']['errorList'] =  array($resp_rem);
                    //return $Response = $this->sendMailBladeTemplate($mailArray);
                }
                if( $in_data['STATUS']  == 2 && !isset( $eproofresponse->Remarks ) ){
                   // return $Response = $this->sendMailBladeTemplate($mailArray);
                }
				
                if( isset( $recipi['ProofRecipient'] ) ){
                    $precipi            =       $recipi['ProofRecipient'];
                    $precipi            =       (array)$precipi;

                        if( isset( $eproofresponse->Remarks ) ){
                            $mailArray['Subject'].='- Remarks';
                            $mailArray['Data']['proofLink']		=	$precipi['URL'];
                            $mailArray['Data']['eproofRemarks']	=	$eproofresponse->Remarks;
                            $bladename      =   'clientAckEproofLink';
                            $mailArray['TemplateName']  =        'emailtemplate.download.'.$bladename;
                        }
                }
            }
            
        }
		
        $log_file_path      =       $in_data['FILE_NAME'];
		
        if( $in_data['STATUS'] == 2 ){
            $getting_path           =   $success_path;  
            $destinationlogdir      =   $productionserverSuccessCopy.$log_file_path;
            $this->doClientlogfilecreation($ftpObj,$getting_path.$log_file_path,$destinationlogdir,$book_id,$round);
        }else{
            $getting_path           =   $redo_path;  
            $destinationlogdir      =   $productionserverSuccessCopy.$log_file_path;          
            $this->doClientlogfilecreation($ftpObj,$getting_path.$log_file_path,$destinationlogdir,$book_id,$round);
        }
        
        $file_ob        	=           $ftpObj->get( $getting_path.$log_file_path );
        $created_filename   =   		'downloaded_'.date('Y_m_d_H_i_s').'.xml';
        $folderPath			=			storage_path().'/'.$app_folder.'/';
        $path 				= 			$folderPath.$created_filename;   
		
        if(!File::exists($folderPath)) {
            File::makeDirectory($folderPath, $mode = 0777, true, true);
        }
		
        $mailArray['created_file']     =        $path;
        ini_set('max_execution_time'  , 0 );
        
        file_put_contents( $folderPath.$created_filename ,  $file_ob );
        
        if( $in_data['STATUS'] == 2 &&  isset( $eproofresponse->Remarks )){ 
            $mailArray['file']      	=   $path;
            $mailArray['attachfile']    =   array( 'as' => $in_data['FILE_NAME'] , 'mime' => 'text/plain' );
        }
        
        $Response   =   $this->sendMailBladeTemplate( $mailArray );
        return $Response;

    }
     
    public function doClientlogfilecreation($ftpObj,$sourceDir,$successdestinationDir,$book_id,$round){
        $roundname              =   Config::get('constants.ROUND_NAME')[$round];
        $inp_rep_arr            =   array( 
                                    'BOOK_ID' =>    $book_id , 
                                    'ROUND_NAME' =>    $roundname 
                                 );
        $cmn_obj                =   new CommonMethodsController();
        $successdestinationDir  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $successdestinationDir );
        //check directory exist or not
        if($ftpObj->has($successdestinationDir)){
            $ftpObj->delete($successdestinationDir);
            $putfile    =	$ftpObj->copy($sourceDir,$successdestinationDir,0777);
        }else{
            $putfile    =	$ftpObj->copy($sourceDir,$successdestinationDir,0777);
        }
        
        return $putfile;
    }
    
    public function sendMailBladeTemplate($mailArray) {
        
        try{

            if (is_array($mailArray)) {

                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {

                        $mailArray['CcMail']     =   \Config::get('constants.CC_EMAIL_LIST'); 
                        $mailArray['BccMail']    =   \Config::get('constants.BCC_EMAIL_LIST');
                        $mailArray['FromName']   =   \Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');

                        $message->subject($mailArray['Subject']);
                        $message->from($mailArray['FromMail'], $mailArray['FromName']);
                        $toAddress  = trim($mailArray['ToMail']);
                        $message->to($toAddress);

                        if ( array_key_exists( 'CcMail', $mailArray ) ) {
                                $message->cc($mailArray['CcMail']);
                        }

                        if (array_key_exists('BccMail', $mailArray)) {
                                $message->bcc($mailArray['BccMail']);
                        }



                        if( isset( $mailArray['file'] ) && isset($mailArray['attachfile']) )
                            $message->attach($mailArray['file'],$mailArray['attachfile']);

                        $message->getSwiftMessage();
                });

                if (Mail::failures()) {

                    $Response['Status'] = 0;
                    $Response['Msg'] = 'Failure';
                    $Response['MsgText'] = Mail::failures();

                } else {

                    if( isset( $mailArray['file'] ) && isset($mailArray['attachfile']) )
                        File::delete($mailArray['created_file']);

                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Success';

                }

                return $Response;
            }

        }catch(\Exception $ex){
            
            $Response['Status'] = 0;
            $Response['Msg'] = 'Failure';
            $Response['MsgText'] = $ex->getMessage();

            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $ex );
            return $Response;

        }

    }
    
    public function triggerEsmVidGeneration($data){
        
        if(!empty($data)){
            
            $jobId          =   $data['jobId'];
            $metaId         =   $data['metadataId'];
            $emsModelObj    =    new apiEsm();
            
            $medatVid                 =   $emsModelObj->getEsmVidByMetaId($metaId ,$jobId);
            $metaEsm                  =   $emsModelObj->getMetaEsmDetails($metaId ,$jobId);
            
            if(!empty($metaEsm) && empty($medatVid)) {
                $esmVidObj    = new esmFileNameController();
                $esmVidObj->startProcess($jobId,$metaId);
            }
            
            return true;
            
        }
        return false;
    }
        
}