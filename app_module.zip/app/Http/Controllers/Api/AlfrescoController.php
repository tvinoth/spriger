<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Controllers\CommonMethodsController;
use App\Models\alfrescoLogModel;
use App\Models\jobModel;
use App\Models\stageModel;
use App\Models\fileHandler;
use App\Models\taskLevelMetadataModel;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB;
use Log;
use Config;
use Session;

class AlfrescoController extends Controller {

    protected $alfrescoweburl;
    protected $alfrescosoapurl;

    public function __construct() {
        parent::__construct();
        $this->alfrescoweburl = Config::get('constants.ALFRESCO.ALFRESCO_WEB_URL');
        $this->alfrescosoapurl = Config::get('constants.ALFRESCO.ALFRESCO_SOAP_URL');
    }

    public function alfrescoSentRequest($jobId, $metaId, $roundId, $stage, $alfreshcofullpath, $checktype) {
            $result =   array();
            $result['result'] = 200;
            $result['errMsg'] = "success";
            $result['status'] = "1";
            return $result;
            
//        try{
        
        $result['result'] = 200;
            $result['errMsg'] = "success";
            $result['status'] = "1";
            return $result;
        $mode = "";
        $result = array('result' => 404, 'status' => 0, 'errMsg' => '', 'data' => []);
        $bookdata = jobModel::getJobdetailsRawQuery($jobId, 'job.BOOK_ID');
        //check job information exist or not
        if ($bookdata == null || empty($bookdata)) {
            $result['errMsg'] = "Invalid Job";
            return $result;
        }
        //check metadata information exist or not
        if (!empty($metaId)) {
            $wheredata = ['JOB_ID' => $jobId, 'METADATA_ID' => $metaId];
            $getchapterresult = taskLevelMetadataModel::Active()->where($wheredata)->first();
            if ($getchapterresult == null || empty($getchapterresult)) {
                $result['errMsg'] = "Invalid Chapter Information";
                return $result;
            }
        }

        $stagedeatils = stageModel::Active()->find($stage);
        if ($stagedeatils == null || empty($stagedeatils)) {
            $result['errMsg'] = "Invalid Stage";
            return $result;
        }

        $url = $this->alfrescoweburl;
        $aUsername = "admin";
        $aPassword = "Welcome123";
        $aPath = "/Shared/SP_BOOKS/";
        $sPath = $alfreshcofullpath . '<>fsr<>ewrr';

        if (strpos($sPath, "<>") !== false) {
            $splitusercredentials = explode('<>', $sPath);
            $sPath = $splitusercredentials[0];
        }
//            $sPath      =   "172.24.191.59/e/ftp/SP_BOOKS/PRODUCTION/FileVersioning";            

        $getlocationftp = productionLocationModel::doGetLocationname($jobId);
        if ($getlocationftp == null) {
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
        }
        $sUsername = $getlocationftp->FTP_USER_NAME;
        $sPassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath = $getlocationftp->FTP_PATH;

        $insertdata = [];
        $params = [];
        $tempParams = [];

        if (strpos($checktype, "download_version") !== false) {
            $splitobjectId = explode(',', $checktype);
            $checktype = $splitobjectId[0];
            $params['objectId'] = $splitobjectId[1];
        }

        $stageName = $stagedeatils->STAGE_NAME;
        switch ($checktype) {
            case ($checktype == 'checkout' || $checktype == 'submit'):
                $mode = strtoupper("upload");
                break;
            case 'download_version':
                $mode = strtoupper("download_version");
                break;
            default:
                $mode = strtoupper("retrieve_versions");
                break;
        }

        $cmn_obj = new CommonMethodsController();
        $tokenkey = $cmn_obj->generateRandomString(16, 'alfresco_log', 'TOKEN');
        $insertdata['CREATED_DATE'] = Carbon::now();
        $insertdata['JOB_ID'] = $params['jobid'] = (string) $jobId;
        $insertdata['METADATA_ID'] = $metaId;
        $insertdata['ROUND'] = $roundId;
        $insertdata['STAGE_ID'] = $stage;
        $insertdata['TOKEN'] = $tempParams['access_token'] = $tokenkey;
        $insertdata['CREATED_BY'] = $params['userid'] = (string) $this->loginUserId;
        $insertdata['REQUEST_TYPE'] = ($checktype == "checkout" ? 1 : 2);
        $insertdata['MODE'] = ($mode == "UPLOAD" ? 1 : 2);
        $params['process'] = $checktype;
        $params['mode'] = $mode;
        $insertdata['FILE_PATH'] = $params['file_path'] = $sPath;

        if (strpos($sPath, $hostpath) == false) {
            $insertdata['REMARKS'] = $result['errMsg'] = "Invalid Path Information";
            $insertdata['STATUS'] = "3";
            $insert = alfrescoLogModel::insertGetId($insertdata);
            return $result;
        }

        $pathsplit = explode($hostpath, $sPath);

        if (!isset($pathsplit[1])) {
            $insertdata['REMARKS'] = $result['errMsg'] = "Invalid Path Information";
            $insertdata['STATUS'] = "3";
            $insert = alfrescoLogModel::insertGetId($insertdata);
            return $result;
        }

        $params['empid'] = $this->empId;
        $params['empName'] = $this->userName;
        $params['sourceurl'] = $url;
        $params['sourceusername'] = $aUsername;
        $params['sourcepassword'] = $aPassword;
        $params['type'] = "document";
        $params['alfresco_path'] = $aPath . $pathsplit[1];
        $params['file_path'] = $sPath;
        $params['file_username'] = $sUsername;
        $params['file_password'] = $sPassword;
        $params['stageName'] = $stageName;
        $params['api_resp'] = json_encode($tempParams);
        $params['api_url'] = url('') . '/api/alfrescoCallback';

        $params = $insertdata['REQUEST_LOG'] = json_encode($params);
        $wsdl = $this->alfrescosoapurl;
        $client = new \soapclient($wsdl);
        $ackresponse = $client->cmisService(array(0 => $params));

        if (is_soap_fault($ackresponse)) {
            $insertdata['REMARKS'] = "Soap Called failed...";
            $insertdata['STATUS'] = "3";
            $insertdata['SERVER_REQUEST_STATUS'] = "3";
        }

        if ($mode != "UPLOAD" || $mode != "upload") {
            $result['result'] = 200;
            $result['errMsg'] = "success";
            $result['status'] = "1";
            $result['data'] = $ackresponse;
            return $result;
        }

        $insertlastId = alfrescoLogModel::insertGetId($insertdata);
        //update ack response
        $updatedata = alfrescoLogModel::find($insertlastId);

        if ($updatedata) {
            if (is_object($ackresponse)) {
                $emptystr = "";
                foreach ($ackresponse as $key => $val) {
                    $emptystr .= $val;
                }
                $updatedata->ACK_RESPONSE_LOG = json_encode($emptystr);
            } else {
                $updatedata->ACK_RESPONSE_LOG = json_encode($ackresponse);
            }
            $updatedata->save();
            $result['result'] = 200;
            $result['errMsg'] = "success";
            $result['status'] = "1";
            return $result;
        }

        $result['errMsg'] = "Invalid data, try again";
        return $result;
//        }catch(\Exception $e){
        $result['errMsg'] = $e->getMessage();
        $insertdata['REMARKS'] = $e->getMessage();
        $insertdata['STATUS'] = "3";
        $insertdata['SERVER_REQUEST_STATUS'] = "3";
        if ($mode == "UPLOAD" || $mode == "upload") {
            $insertlastId = alfrescoLogModel::insertGetId($insertdata);
        }
        return $result;
//        }
    }

    public function alfrescoRetrieveVersions(Request $request) {
        $validation = Validator::make($request->all(), [
                    'alfrescoId' => 'required|numeric'
        ]);

        $response = array('result' => 404, 'errMsg' => 'Mandatory fields are required', 'validation' => "", 'data' => []);
        if ($validation->fails()) {
            $response['result'] = 401;
            $response['validation'] = $validation->errors();
            return response()->json($response);
        }

        $alfrescoId = $request->input('alfrescoId');
        $getrecords = alfrescoLogModel::find($alfrescoId);
        if ($getrecords == null) {
            $response['errMsg'] = "Alresco data not found";
            return response()->json($response);
        }
        $getlocationftp = productionLocationModel::doGetLocationname($getrecords->JOB_ID);
        if ($getlocationftp == null || count($getlocationftp) == 0) {
            $response['errMsg'] = "Alresco data not found";
            return response()->json($response);
        }

        $retrieveversions = $this->alfrescoSentRequest($getrecords->JOB_ID, $getrecords->METADATA_ID, $getrecords->ROUND, $getrecords->STAGE_ID, $getrecords->FILE_PATH, 'retrieve');
        if (empty($retrieveversions)) {
            $response['result'] = 404;
            $response['errMsg'] = "Could not reach Alresco server";
            return response()->json($response);
        }

        $alfrscocontent = [];
        if (isset($retrieveversions['status']) && isset($retrieveversions['data']->return) && $retrieveversions['status'] == 1) {
            $decodedata = json_decode($retrieveversions['data']->return);
            $ownkey = 0;
            if (count($decodedata) >= 1) {
                foreach ($decodedata as $key => $value) {
                    if (isset($value->Version_Details) && count($value->Version_Details) >= 1) {
                        foreach ($value->Version_Details as $subkey => $val) {
                            $newdata = [];
                            $newdata['Path'] = $value->Path;
                            $newdata['FileName'] = $value->FileName;
//                            $newdata['FileSize'] =   $value->FileSize;
                            $newdata['ObjectId'] = $value->ObjectId . ';' . $val->Version;
                            $newdata['Version'] = $val->Version;
                            $newdata['Modified_At'] = $val->Modified_At;
                            $newdata['Comments'] = $val->Comments;
                            array_push($alfrscocontent, $newdata);
                            $ownkey++;
                        }
                    }
                }
            }
            $response['result'] = 200;
            $response['errMsg'] = "success";
            $response['data'] = $alfrscocontent;
            $response['alfrescoId'] = $alfrescoId;
        } else {
            $response['result'] = 404;
            $response['errMsg'] = (isset($retrieveversions['errMsg']) ? $retrieveversions['errMsg'] : "Alresco data not found");
        }
//        $data   =   '[{"Path":"/Shared/SP_BOOKS/PRODUCTION/FileVersioning/","FileName":"0004297202_4.INDD","ObjectId":"d3787084-c3ae-4ab2-a224-5058f9580d42","Version_Details":[{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"},{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"}]},{"Path":"/Shared/SP_BOOKS/PRODUCTION/FileVersioning/","FileName":"0004297202_4.INDD","ObjectId":"d3787084-c3ae-4ab2-a224-5058f9580d42","Version_Details":[{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"},{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"}]},{"Path":"/Shared/SP_BOOKS/PRODUCTION/FileVersioning/","FileName":"0004297202_4.INDD","ObjectId":"d3787084-c3ae-4ab2-a224-5058f9580d42","Version_Details":[{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"},{"Version":"1.1","Modified_At":"Fri Mar 01 19:06:35 IST 2019","Comments":"RAW; Done By - Ram Mahesh Kumar K","File Size":"9.95 MB"}]}]';
        return response()->json($response);
    }

    public function alfrescoDownloadVersions(Request $request) {
        $validation = Validator::make($request->all(), [
                    'objectId' => 'required',
                    'alfrescoId' => 'required|numeric'
        ]);

        $response = array('result' => 404, 'errMsg' => 'Mandatory fields are required', 'validation' => "", 'data' => []);
        if ($validation->fails()) {
            $response['result'] = 401;
            $response['validation'] = $validation->errors();
            return response()->json($response);
        }

        $alfrescoId = $request->input('alfrescoId');
        $objectId = $request->input('objectId');
        $getrecords = alfrescoLogModel::find($alfrescoId);
        if ($getrecords == null) {
            $response['errMsg'] = "Alresco data not found";
            return response()->json($response);
        }
        $getlocationftp = productionLocationModel::doGetLocationname($getrecords->JOB_ID);
        if ($getlocationftp == null || count($getlocationftp) == 0) {
            $response['errMsg'] = "Alresco data not found";
            return response()->json($response);
        }

        $bookdata = jobModel::getJobdetailsRawQuery($getrecords->JOB_ID, 'job.BOOK_ID');
        //check job information exist or not
        if ($bookdata == null || empty($bookdata)) {
            $result['errMsg'] = "Invalid Job";
            return $result;
        }

        $hostserver = $getlocationftp->FTP_HOST;
        $hostpath = ltrim($getlocationftp->FTP_PATH, '/');
        $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
        $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;
        $root = Config::get('constants.FILE_SERVER_ROOT_DIR');
        $getuserid = (empty($this->empId) ? '' : $this->empId . '/');
        $userdir = Config::get('serverconstants.USER_WORK_PATH');
        $userdirpath = $userdir . $getuserid . $bookdata->BOOK_ID;
        $openPath = $hostserver . $root . $hostpath . $userdirpath . '/' . Config::get('constants.ALFRESCO.USER_FOLDER');

        $retrieveversions = $this->alfrescoSentRequest($getrecords->JOB_ID, $getrecords->METADATA_ID, $getrecords->ROUND, $getrecords->STAGE_ID, $openPath, 'download_version,' . $objectId);
        if (empty($retrieveversions)) {
            $response['result'] = 404;
            $response['errMsg'] = "Could not reach Alresco server";
            return response()->json($response);
        }

        if (isset($retrieveversions['status']) && isset($retrieveversions['data']->return) && $retrieveversions['status'] == 1) {
            $decodedata = json_decode($retrieveversions['data']->return, true);
            if (count($decodedata) >= 1) {
                if (isset($decodedata[0]['Status']) && $decodedata[0]['Status'] == "Success") {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata = [];
                    $postdata['file_path'] = $openPath . '<>' . $hostuserfieserver . '<>' . $hostpasswordfieserver;
                    $postdata['method_name'] = "doOpenDriveServer";
                    $postdata['system_ip'] = $request->ip();
                    $postdata['processname'] = "checkout";
                    $insertfilehandler = fileHandler::insertNew($postdata);
                    if ($insertfilehandler) {
                        $response['result'] = 200;
                        $response['Msg'] = 'Success';
                        $response['errMsg'] = 'File open initialized..';
                        $response['rmID'] = $insertfilehandler;
                        return response()->json($response);
                    }
                } else {
                    $response['result'] = 404;
                    $response['errMsg'] = (isset($decodedata[0]['Remarks']) ? $decodedata[0]['Remarks'] : "File is not copied properly");
                }
            } else {
                $response['result'] = 404;
                $response['errMsg'] = "Invalid response from alfresco";
            }
        } else {
            $response['result'] = 404;
            $response['errMsg'] = (isset($retrieveversions['errMsg']) ? $retrieveversions['errMsg'] : "Alresco data not found");
        }
        return response()->json($response);
    }

    public function alfrescoResponse(Request $request) {
        $result = array('status' => 0, 'msg' => 'Failed', 'errMsg' => 'Invalid response data', 'token' => '');
        $getToolresponse = $request->getQueryString();
        parse_str($getToolresponse, $responsedata);
        if (is_array($responsedata) && array_key_exists('data', $responsedata)) {
            $getToolresponse = json_decode($responsedata['data']);
            if (count($getToolresponse) >= 1 && is_object($getToolresponse)) {
                $request['access_token'] = (isset($getToolresponse->access_token) ? $getToolresponse->access_token : '');
                $request['status'] = (isset($getToolresponse->status) ? $getToolresponse->status : '');
                $validation = Validator::make($request->all(), [
                            'access_token' => 'required',
                            'status' => 'required'
                ]);
                if ($validation->fails()) {
                    return response()->json($validation->errors());
                }

                $access_token = $getToolresponse->access_token;
                $wheredata = ['TOKEN' => $access_token, 'STATUS' => 1];
                $getdata = alfrescoLogModel::where($wheredata)->first();
                if ($getdata != null) {
                    $updatedata['REMARKS'] = (isset($getToolresponse->remarks) ? $getToolresponse->remarks : '');
                    $updatedata['STATUS'] = ($getToolresponse->status == "success" ? '2' : '3');
                    $updatedata['RESPONSE_LOG'] = json_encode($responsedata);
                    $updatedata = alfrescoLogModel::doupdate($access_token, $updatedata);
                    $result['errMsg'] = "success";
                    $result['status'] = "1";
                    return response()->json($result);
                }
                $result['errMsg'] = "Request is already completed";
            }
        }
        return response()->json($result);
    }

}
