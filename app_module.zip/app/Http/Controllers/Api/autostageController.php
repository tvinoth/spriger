<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobsheetViewpathModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager;
use App\Models\jobStage;
use App\Models\apiFigureValidation;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use \App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiObserveXml;
use App\Http\Controllers\workflow\workflowRuleController;
use App\Models\jobWorkLogModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\stagealertemailController;
use App\Http\Controllers\Api\lowResController;
use App\Http\Controllers\Api\tapsController;
use App\Http\Controllers\artProcess\artProcessController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;


class autostageController extends Controller
{  
    public function __construct()
    {
        parent::__construct();
    }
    
    public function storeResponse( Request $request ){
            
            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['errMsg']         =       'something went wrong , try again later'; 
            
            $inputarr                   =       (array)json_decode( $request->getContent() ); 
             Log::useDailyFiles( storage_path().'/Api/storeresponse.log' );
             Log::info($request->getContent());
            
            $_callback          =       null;
            
        try{
                  
            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $checkoutObj        =       new checkoutModel();
            $process            =       isset( $inputarr['process']) ? strtolower( $inputarr['process'] ) : '';
            $isart              =       0;
            $status             =       $inputarr['status'];
            
            if( $inputarr['status'] == 'F' || $inputarr['status'] == '0' ){
                $status     =   $inputarr['status']  =   3; 
            }
            
           /* if($inputarr['status'] == 'TRUE' || $inputarr['status'] == 'true' || $inputarr['status'] == true){
                 $status     =   $inputarr['status']  =   2; 
            }*/
            
            if( $inputarr['status'] == 'S' || $inputarr['status'] == '1' ){
                $status     =   $inputarr['status']  =   2; 
            }
            
            if( isset( $inputarr['isart'] ) && !empty($inputarr['isart']) ){
                $isart  =   $inputarr['isart'];
            }
            
            $returnStatus       =       false;
            
            //Common way to handle all the signal communication                                        
            $controllername            =        $this->getContorllerNameOfTheSignal($inputarr);   
           
            if( is_null( $controllername ) && empty( $controllername  ) )
                throw new \Exception( 'jobstageid invalid, kindly check the signal.' );
            
                $controllerPath            =        'App\\Http\\Controllers\\Api\\'.$controllername;
               
                $methodname                =        isset( $inputarr['methodname'] ) ? trim( $inputarr['methodname'] ) : 'storeSignal';
              
                $returnStatus              =        $this->$methodname( $inputarr , $response , $_callback );
                 
                if( isset( $returnStatus['status'] ) ){
                    
                    $response  = $returnStatus;
                    if( $returnStatus['status'] == 0 ){
                        $returnStatus=  false;
                    }
                    
                    if( $returnStatus['status'] == 1 ){
                        $returnStatus=  true;
                    }

                }
                
                // Success case Should handled here
                if( $returnStatus && $status == 2 && !is_null( $_callback ) ){      
                    // Trigger Next Stage
					
					
                    app($controllerPath)->$_callback( $inputarr , $response );   
                    
                }
                
                //Success case Should handled here to sucess case next stage trigger
                if( $returnStatus && $status == 2 && is_null( $_callback ) ){
                    
                    
                    //$mailalertObj->doSendemailalertstage($data->jobId,$data->roundid,$data->stageid,$data->metadataid);
                    
                    // Trigger Next Stage
                    // Jobstageid require for this process
                    // Rule based next stage should be handle here  
                    
                    $jobStageId         =       $inputarr['jobstageid'];
                    
                    
                    $stageDetails       =       $checkoutObj->getStageInfo( $jobStageId );
                    
                    if($isart == 0){
                      $isart  = $stageDetails['0']->IS_ART;
                    }
                    
                    if( $isart == 1 ){                        
                        $stageDetails       =       $checkoutObj->getArtStageInfo( $jobStageId );
                    }else{
                        $stageDetails       =       $checkoutObj->getStageInfo( $jobStageId );
                    }
                    
                    if(count($stageDetails)>=1){
                       
                        $stageData              =  $stageDetails['0'];    
                        $jobRoundId             = $stageData->JOB_ROUND_ID;
                        $roundId                = $stageData->ROUND_ID;
                        $stageSequence          = $stageData->STAGE_SEQ + 1;
                        $workflowId             = $stageData->WORKFLOW_ID;  
                        $iteration              = $stageData->ITERATION_ID;
                        $jobId                  = $stageData->JOB_ID;
                        $stageId                = $stageData->STAGE_ID;
                        $metadataId             = $stageData->METADATA_ID;
                        $outputQuantity         = $stageData->OUTPUT_QUANTITY;
                        $inputQuantity          = $stageData->INPUT_QUANTITY;
                        $stageManagerContObj    =       new stageMangerController();  
                        $nexstageDetails        =  $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId); 
                        
                        $mailalertObj   =      new stagealertemailController();
                        $mailalertObj->doSendemailalertstage( $jobId , $roundId , $stageId , $metadataId , 'success' );
                 
                        if(!empty($nexstageDetails)){ 
						
                           $moveStageResponse = $stageManagerContObj->moveNextStage( $stageDetails['0'] , $isart );                           
                        }else{
                           $moveStageResponse1 = $stageManagerContObj->finalStage($jobStageId, $stageDetails['0'],$isart ); 
                           $moveStageResponse['status'] = 'success'; 
                        }
                        
                    }
                    
                    //$stageManagerContObj    =       new stageMangerController();                    
                    //$moveStageResponse      =       $stageManagerContObj->moveNextStage( $stageDetails['0'] ,  $isart );                    
                    if( $moveStageResponse['status'] == 'success' ){
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal received successfully...';  
                    }
                }
                
                //Failure case should handled here with proper rollback handling
                if( $returnStatus && $status == 3 && !is_null( $_callback ) ){                    
                    app($controllerPath)->$_callback( $inputarr , $response );
                }
          
                if( $returnStatus && $status == 3 && is_null( $_callback ) ){
                    
                    // Rollback the stage
                    // Jobstageid require for this process 
                    // Rule based rolback should handle here.
                   
                    $jobStageId             =       $inputarr['jobstageid'];
                    $wrkflwruleObj          =       new workflowRuleController();   
                    
                    //check wheather this nextstage available as per rule or overwrite the nextstage variable
                    $gotostage              =       $wrkflwruleObj->getWorkflowRuleBasedJobStageAvail( $jobStageId , 1 );
                    
                    if( $gotostage ){
                        
                        $stgMgObj        =       new stageMangerController();
                        $remarks         =       @$inputarr['remarks'];
                        $stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );
                        
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal received successfully...';   
                        
                    }
            
                }         
                
                
        }catch( \Exception $e ){
            
            $err_handle             =       new errorController();             
            $bgCont_Obj             =       new bgprocessController();  
            $response['reason']     =       $e->getMessage();
            $response_to            =       $response;
            
            $inserid                =       $err_handle->handleApplicationErrors( $e );
            $inputarr['ERROR_ID']   =       $inserid;
            $bgCont_Obj->bgprocessSignalLogging( $inputarr , $response_to );
            
        }
        
        return response()->json( $response );

    }
    
    public function storeResponseQS( Request $request ){
            
        parse_str( $request->getQueryString() , $getToolresponse );
        
        Log::useDailyFiles(storage_path().'/Api/ObserveXmlReturnSignal.log');
        Log::info( json_encode( $getToolresponse ) );
        
        $getToolresponse    =   (object)$getToolresponse;
        
        if( count( $getToolresponse ) >= 1 ){	
            
            $request['token']       =   $getToolresponse->tokenkey;
            $request['status']      =   $getToolresponse->status;
            $request['round']       =   $getToolresponse->round;
            $request['endtime']     =   $getToolresponse->endtime;
            $request['metaid']      =   $getToolresponse->metaid;
            
            $validation             =   Validator::make($request->all(), [
                                                'token' 	=> 'required',
                                                'status' 	=> 'required|numeric',
                                                'round' 	=> 'required|numeric',
                                                'metaid' 	=> 'required|numeric',
                                                //'endtime' 	=> 'required'
                                        ]);
            
            if ($validation->fails()){
                return response()->json($validation->errors());
            }
            
            //dd( $getToolresponse );
            //update auto stage tool response
            $token                  =   trim($getToolresponse->tokenkey);
            $status                 =   trim($getToolresponse->status);
            $endtime                =   trim($getToolresponse->endtime);
            $metaid                 =   $getToolresponse->metaid;
            $roundid                =   $getToolresponse->round;
            
            $updatedata             =   [];
            $updatedata['END_TIME'] =   $endtime;
            $updatedata['STATUS']   =   (( $status    ==  1 || $status == 2 || $status == 'S' ) ?'2':'3');
            $updatedata['REMARKS']  =   trim($getToolresponse->remarks);
            //$updatedata['RESPONSE_LOG']   =   json_encode($_REQUEST);
            $records        =       apiObserveXml::getApiRequestByTokenKey($token);
            
            if( count( $records ) ){
                
                $updatemeta             =       apiObserveXml::updateIfExist($updatedata , $records->ID ); 

                $response               =       array( 'status' => 0 ,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token');

                if( $updatemeta ){
                    $response           =       array( 'status' => 1 ,'msg' => 'Success' , 'errMsg' => 'Response Signal Successfully received.' );
                }
                
            }else{
            
                 $response         =           array( 'status' => 0 , 'msg' => 'Failed' , 'errMsg' => 'Requested tokenkey is invalid.' , 'tokenid' => $token );
        
            }
            
        }
        
       
        return response()->json( $response );
        
        
    }
    
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['jobstageid']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required|numeric';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required|numeric';
        
        return $rules;
        
    }
     
    public function getContorllerNameOfTheSignal( $inputarr ){
        
        $controllername            =        isset( $inputarr['controller'])  ? $inputarr['controller'] : null;
        $returnjobstgid            =        isset( $inputarr['jobstageid'] ) ? $inputarr['jobstageid'] : null;
        
            if(is_null( $controllername )){
                if( !is_null( $returnjobstgid ) ){
                   
                    $getConfigInfo      =       $this->getAutoStageBgExecutionConfiguration( $returnjobstgid );
                  
                    if( !empty( $getConfigInfo ) ){
                        $autoStageList      =        $getConfigInfo;
                        $autoStageList      =        array_values($autoStageList);
                        if( count( $autoStageList ) ){
                            $autoStageList      =        $autoStageList[0];
                            $controllername     =        $autoStageList['controller'];
                        }
                    }  
                }
            }
           
        return $controllername;
        
    }
    
    public function storeSignal( $inputarr , &$response , &$_callback ){
        
        $bgCont_Obj     =       new bgprocessController();
        $response       =       $bgCont_Obj->bgprocessResponseSignalReceive( $inputarr );
		
	$response['errMsg']         =       "Signal Received Successfully ";
        $_callback      =       null;
         
        $bgCont_Obj->bgprocessSignalLogging( $inputarr , $response );
        
        if( isset( $inputarr['custom_calback'] ) && !empty(  $inputarr['custom_calback'] ) ){
            if( strlen( $inputarr['custom_calback'] ) ){
                $_callback      =       $inputarr['custom_calback'];
            }
        }
        
        return $response;
    }
    
    public function batchAutoStageMovement( $inpArr ){
        
        $checkoutObj                =           new checkoutModel();
        $stageManagerContObj        =           new stageMangerController();
        $jbs_obj                    =           new jobStage();
        $toolsResponse              =           $inpArr['Artwork'];
        $batchId                    =           $inpArr['batchid'];
        
        $getjobstage                =   jobWorkLogModel::where('BATCH_ID',$batchId)->get();
        $getjobstage                =   $getjobstage->pluck('JOB_STAGE_ID');
        
        foreach($getjobstage as $k => $jsId){
            $stageIDs[] =   $jsId;
        }
        
        $jobStageIDs             =    implode(',',$stageIDs);       
        $checkoutObj             =    new checkoutModel();
        $jstageInfo              =   $checkoutObj->getArtStageInfo_old($jobStageIDs);
         
        if(!empty($jstageInfo)){
            $stageDetails       =   $jstageInfo['0'];
        }
       
        $getCurrentStage         =   $checkoutObj->getCurrentStageDetais($stageDetails->METADATA_STATUS_ID);      
        $artmetaid                  =           null;
        $errRemarks                 =           array();
        $artmetaid2                  =           array();
        if( !empty( $toolsResponse ) ){
           $failedFlag               =   0;
           $successFlag              =   0;
            foreach( $toolsResponse as $key => $value ){
                
                 if( $toolsResponse[$key]->Status == 2 || $toolsResponse[$key]->Status == 0 ) {
                      $artFailedMetaID[]                         =        $value->ArtMetaID;
                       // $artmetaid['ART_METADATA_ID']              =        $value->ArtMetaID;
                        $artmetaid['STATUS']                       =        '0';
						
						 $artmetaid3['REMARKS']                      =       '';
						 DB::table('task_level_art_metadata')->where('ART_METADATA_ID', '=', $value->ArtMetaID )
                                         ->update($artmetaid3);
                        $successFlag              = 1;
                 }else if( $toolsResponse[$key]->Status == 3  ) {
                        $artFailedMetaID[]                         =        $value->ArtMetaID;
                        $artmetaid['ART_METADATA_ID']              =        $value->ArtMetaID;
                        $artmetaid['STATUS']                       =        '1';
                        $artmetaid['REMARKS']                      =        $value->Remarks;
                        
                        DB::table('art_category_log')->where('ART_METADATA_ID', '=', $value->ArtMetaID )
                                         ->update($artmetaid);
                        
						$artmetaid2['ART_METADATA_ID']              =        $value->ArtMetaID;
                        $artmetaid2['FIGURE_STATUS']                =        '1';
                        $artmetaid2['REMARKS']                      =        $value->Remarks;
						
						 DB::table('task_level_art_metadata')->where('ART_METADATA_ID', '=', $value->ArtMetaID )
                                         ->update($artmetaid2);
                        
                        $failedFlag                                =        1;
                       
                }else{
                    
                }
            }

            if($successFlag == '1' && $failedFlag == '0'){
              
               $artMetaids     =    implode(',',$artFailedMetaID);
              
               $stageManagerContObj->moveToNextStageForArtFigureValiation($getCurrentStage,1);
            }
          
            if($failedFlag == '1'){
              
               $artMetaids     =    implode(',',$artFailedMetaID);
               $checkoutObj->artStageRollBack($artMetaids,$stageDetails->METADATA_STATUS_ID,$stageDetails->JOB_ROUND_ID,$stageDetails->WORKFLOW_ID,$stageDetails->ROUND_ID,$stageDetails->ITERATION_ID,$stageDetails);
               
            }
            
        }
        
    }
  
    public function figureValidation_callback( $input_arr , &$response = array() , &$_callback = '' ){
        
        extract( $input_arr );
        
        $afv_obj        =       new apiFigureValidation();
        $rec            =       $afv_obj->getApiRequestByTokenkey(  $tokenkey );
        $inpArr['REMARKS']      =       json_encode( $Artwork );
        $inpArr['END_TIME']     =       date( 'Y-m-d H:i:s' );
        
        $bgCont_Obj             =       new bgprocessController();
        
        if(is_object( $rec )){

            $inpArr['STATUS']        =       $status;
            $rowid                   =       $rec->ID;
           $afv_obj->updateIfExist( $inpArr , $rowid );
           
            $_callback                  =       'batchAutoStageMovement';
           
            $response['status']         =       1;
            $response['msg']            =       'success';
            $response['errMsg']         =       'Signal received successfully';

       }else{
           
           $response['status']         =       0;
           $response['msg']            =       'Failed...';
           $response['errMsg']         =       'Requested api entry is not available';
                  
       }
        
       $bgCont_Obj->bgprocessSignalLogging( $input_arr , $response );
       return true;
    }
    
       public function doindexValidationRequest($jobStageId)
    {
         
       try
        {
            $checkoutObj        =   new checkoutModel();
            $workflowPath       =   new workflowServerMapPathModel();
            $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
            $serverMapPath      =   $workflowPath->getWorkflowServerMapPath($jobStageId);
           
            if(count($stageDetails) == 0){
                 return array();
            }
            
            $jobId                =   $stageDetails[0]->JOB_ID;
            $stageId              =   $stageDetails[0]->STAGE_ID;
            $roundId              =   $stageDetails[0]->ROUND_ID;
            $chapterID            =   $stageDetails[0]->METADATA_ID;
            $chapterNo            =   $stageDetails[0]->CHAPTER_NO;
            $esmDetails           =  array();
      
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $getchapters        =   taskLevelMetadataModel::getMetadatadetailsJob($jobId);
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            $wheredata          =   array('JOB_ID'=>$jobId,'METADATA_ID'=>$chapterID);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
              
                $spicepathreplce    =       Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                $stage_name         =       Config::get('constants.STAGE_NAME.COPY_EDITING');
                $cmn_obj            =   new CommonMethodsController();
                
                // S200 Jobsheet Path
                $wherejobdata = ['ROUND_ID' => $this->round_ID_200];
                $getjobsheetpath = jobsheetViewpathModel::active()->where($wherejobdata)->first();
                $jobsheetPath   =   $getjobsheetpath['JOBSHEET_PATH'];
                $inp_rep_arr = array(
                    'BOOK_ID' => $bookid,
                    'ROUND_NAME' => $this->round_NAME_S200,
                    'CID' => $chapterno
                );
                
                $reaadjobsheetpath  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobsheetPath );
                
                $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
               
                $documenttypeexnt   =   Config::get('constants.DOCUMENT_TYPE.document');
                $metadoctypeexnt    =   Config::get('constants.DOCUMENT_TYPE.meta');
                $rootdir            =   rtrim(Config::get('constants.FILE_SERVER_ROOT_DIR'),'/');
                $jobdirfiles        =   [];
                $jobfilesize        =   [];
                $jobdoctype         =   [];
                if (count($jobsheetDirFiles) >= 1) {
                    foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                        $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                        if (strpos($spiltchapter, '.') !== false) {
                            $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                            $splitname = explode('.', $spiltchapter);
                            if (in_array($nameofchapterextn, ['xml'])) {
                                if (strpos($spiltchapter, $bookid) !== false) {
                                    if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                        $jobdoctype[] = "meta";
                                    } else {
                                        $jobdoctype[] = "other";
                                    }
                                    $jobdirfiles[] = "//" . $hostserver . $rootdir . '/' . $reaadjobsheetpath .'/'.$spiltchapter;
                                    $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                }
                            }
                        }
                    }
                }
	
                // if S200 jobsheet not found job sheet get s50 job sheet
                if(count($jobdirfiles)  ==  0){
                    $jobdirfiles        =   [];
                    $jobfilesize        =   [];
                    $jobdoctype         =   [];
                    $whereS50data = ['ROUND_ID' => $this->round_ID_50];
                    $getjobsheetpath = jobsheetViewpathModel::active()->where($whereS50data)->first();
                    $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                    $inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $this->round_NAME_S50);
                    $reaadjobsheetpath = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
                    $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
                    if(count($jobsheetDirFiles)>=1) {
                        foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                            $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                            if (strpos($spiltchapter, '.') !== false) {
                                $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                                $splitname = explode('.', $spiltchapter);
                                if (in_array($nameofchapterextn, ['xml'])) {
                                    if (strpos($spiltchapter, $bookid) !== false) {
                                        if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                            $jobdoctype[] = "meta";
                                        } else {
                                            $jobdoctype[] = "other";
                                        }
                                        $jobdirfiles[] = "//" . $hostserver . $rootdir .'/'. $reaadjobsheetpath . $spiltchapter;
                                        $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                    }
                                }
                            }
                        }
                    }
                }
          
                // if not found job sheet get s5 job sheet
                if(count($jobdirfiles)  ==  0){
                    $jobdirfiles        =   [];
                    $jobfilesize        =   [];
                    $jobdoctype         =   [];
                    $whereS50data = ['ROUND_ID' => $this->round_ID_5];
                    $getjobsheetpath = jobsheetViewpathModel::active()->where($whereS50data)->first();
                    $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                    $inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $this->round_NAME_S5);
                    $reaadjobsheetpath = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
                    $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
                    if(count($jobsheetDirFiles)>=1) {
                        foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                            $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                            if (strpos($spiltchapter, '.') !== false) {
                                $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                                $splitname = explode('.', $spiltchapter);
                                if (in_array($nameofchapterextn, ['xml'])) {
                                    if (strpos($spiltchapter, $bookid) !== false) {
                                        if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                            $jobdoctype[] = "meta";
                                        } else {
                                            $jobdoctype[] = "other";
                                        }
                                        $jobdirfiles[] = "//" . $hostserver . $rootdir .'/'. $reaadjobsheetpath . $spiltchapter;
                                        $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                    }
                                }
                            }
                        }
                    }
                }
                
                $chapterlist        =       $getchapters->pluck('CHAPTER_NO')->toArray(); 
               
                if(!empty($serverMapPath['detail']['src'])){
                   $openPath        =    $serverMapPath['detail']['src'];
                   $open_path         =   str_ireplace($serverMapPath['serverCredential']['host'],'',$openPath);
                }
                
                $serverDirFiles     =   $ftpObj->allFiles($open_path);
                
                $getoriginalchapter =   [];
                $getartpaths        =   [];
                $getchapterpaths    =   [];
                // get chapter document
                if(count($serverDirFiles)>=1)
                {
                    $chapterfilesize    =   [];
                    $fmfilesize         =   [];
                    $getoriginalchapter =   [];
                    $documenttype       =   [];
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    $clientId           =   Config::get('constants.CLIENTID');
                    
                    $hostpath           =   str_replace("/",'',$hostpath);
                    
                    $esmfile2   =   [];
                    foreach($serverDirFiles as $key=>$jsonvalue)
                    {
                      
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                           
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                               
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    if(in_array($nameofchapterextn,$documenttypeexnt))
                                    {
                                        $documenttype[]     =   "document";
                                        $getoriginalchapter[]   =   "//".$hostserver.$rootdir.'/'.$open_path.$spiltchapter;
                                        $fmfilesize[]       =   $ftpObj->size($open_path.'/'.$spiltchapter);
                                    }
                                    else {
                                       
                                        $documenttype[]     =   "media";
                                         $getoriginalchapter[]   =   "//".$hostserver.$rootdir.$jsonvalue;
                                         $fmfilesize[]           =   $ftpObj->size($jsonvalue);
                                    }
                                  
                                }
                            }
                        }
                        
                    }
                
                    $destinationurl     =   $hostserver.$rootdir.$open_path;
				
                    if(!empty($serverMapPath['detail']['dest'])){
                        $destinationurl     =    str_replace($hostserver,$hostserver.$rootdir,$serverMapPath['detail']['dest']);
                        $destinationurl     =   str_replace("//","/",$destinationurl);
                    }else{
                        $destinationurl     =   str_replace("//","/",$destinationurl);
                        $destinationurl     =   str_replace(Config::get('constants.STAGE_NAME.COPY_EDITING'),Config::get('constants.STAGE_NAME.SPICE'),$destinationurl);
                    }
                    $destinationurl     =   "//".$destinationurl;
                    $wheredata          =   array('JOB_ID'=>$jobId,'CHAPTER_NO'=>$chapterno);
                    $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
                    $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
                    $spicast                    =   [];
                    $spicast['JOB_ID']          =   $jobId;
                    $spicast['ROUND']           =   $roundId;
                    $spicast['METADATA_ID']     =   $metadataID;
                    $spicast['STAGE']           =   $stageId;
                    $spicast['PROCESS_TYPE']    =   '2';
                    $spicast['START_TIME']      =   Carbon::now();
                    $spicast['CREATED_DATE']    =   Carbon::now();
                    $spicast['CREATED_BY']      =   Session::get('users')['user_id'];
                    $storespicast               =   autoStageModel::store($spicast);
                    // check layout is have or not for current book
                    $getlayoutprofile           =   jobInfoModel::where('JOB_ID',$jobId)->first();
                    $layoutprofile              =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                        =   \Config('app.url').'api/indexvalCallback';
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('Metadata');
                    $xml->setIndent(true);
                    $xml->startElement('Publisher');
                    $xml->text($clientId);
                    $xml->endElement();
                    $xml->startElement('Location');
                    $xml->text($getlocationftp->LOCATION_NAME);
                    $xml->endElement();
                    $xml->startElement('ClientID');
                    $xml->text($clientId);
                    $xml->endElement();
                    $xml->startElement('Cycle');
                    $xml->text(true);
                    $xml->endElement();
                    $xml->startElement('Process');
                    $xml->text('INDEXVALIDATION');
                    $xml->endElement();
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('ChapterNo');
                    $xml->text($chapterno);
                    $xml->endElement();
                    //SOURCE PATH
                    $xml->startElement('Source');
                        foreach($getoriginalchapter as $key=>$fmnames)
                        {
                            $xml->startElement("File"); 
                            $xml->writeAttribute("type", $documenttype[$key]); 
                            if(!empty($esmfile2)){
                                $splitArray       =   explode('/',$fmnames);
                                $fileName         =  end($splitArray);
                                $esmfileName      =  explode('.',$fileName);
                                if(array_key_exists($fileName,$esmfile2)){
                                    $xml->writeAttribute("VideoID", $esmfile2[$fileName]);
                                }
                            }
                            $xml->writeAttribute("size", $fmfilesize[$key]); 
                            $xml->writeAttribute("src", $fmnames); 
                            
                         
                            $xml->endElement();  
                        }
                        if(count($jobdirfiles)>=1)
                        {
                            foreach($jobdirfiles as $key=>$fmnames)
                            {
                                    $xml->startElement("File"); 
                                    $xml->writeAttribute("type", $jobdoctype[$key]); 
                                    $xml->writeAttribute("size", $jobfilesize[$key]); 
                                    $xml->writeAttribute("src", $fmnames); 
                                    $xml->endElement();
                            }
                        }
                        
                    $xml->endElement();
                    //DESTINATION PATH
                    $xml->startElement('Destination');
                        $xml->startElement("File"); 
                        $xml->writeAttribute("dest", $destinationurl); 
                        $xml->endElement();  
                    $xml->endElement();  
                    //work flow tag
                    $xml->startElement("Workflow"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "spice");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$metadataID);
                        $xml->writeAttribute('key', "metaid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$roundId);
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $storespicast->TOKEN);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();
                        
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $jobId);
                        $xml->writeAttribute('key', "jobid");
                        $xml->endElement();
                        
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $bookid);
                        $xml->writeAttribute('key', "bookid");
                        $xml->endElement();
                        
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $jobStageId);
                        $xml->writeAttribute('key', "jobstageid");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "data-time");
                        $xml->writeAttribute('value', "{0:yyyy-MM-dd HH-mm-ss}");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();

                    $content 	= 	$xml->outputMemory();
					
                   
                    $filename 	=	$bookid.'_'.$chapterno.'_meta.xml';
                    $successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICE_WATCH_FILE').'/'.$filename, $content);
                    $successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICE_WATCH_FILE').'MagnusTest/'.$filename, $content);
                    if($successfileresponse ==     true)
                    {
                        $result             =   array('status'=>'2','message'=>'success');
                    }
                    else
                    {
                        $result             =   array('status'=>'3','message'=>'failed');
                    }
                    
                    $result         =   array('status'=>'2','result'=>200,'errMsg'=>'Spice xml posted sucessfuly...');   
                    
                    return response()->json($result);
                }else{
                    
                }
            }
            
            $result         =   array('status'=>'3','result'=>400,'errMsg'=>'Chapters or Job Info data is missing');               
            return response()->json($result,404);
            
        }
        catch( \Exception $e )
        {     
          
            $result         =   array('status'=>'3','result'=>500,'errMsg'=>$e->getMessage());   
            return response()->json($result);
        }
        
    }
    
    public function doSpicerequest($jobStageId)
    {
       try
        {
            $checkoutObj        =   new checkoutModel();
            $workflowPath       =   new workflowServerMapPathModel();
            $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
            $serverMapPath      =   $workflowPath->getWorkflowServerMapPath($jobStageId);
          
            if(count($stageDetails) == 0){
                 return array();
            }
            
            $jobId                =   $stageDetails[0]->JOB_ID;
            $stageId              =   $stageDetails[0]->STAGE_ID;
            $roundId              =   $stageDetails[0]->ROUND_ID;
            $chapterID            =   $stageDetails[0]->METADATA_ID;
            $chapterNo            =   $stageDetails[0]->CHAPTER_NO;
            
       
        //$esmfilePath   =    str_ireplace('BOOK_ID', $bookid, $esmfilePath);
        
            $esmDetails   =   DB::table('metadata_esm as esm')->select(DB::raw('esm.*,tm.*'))
                                ->join( 'task_level_metadata as tm' , 'tm.METADATA_ID', '=', 'esm.METADATA_ID')
                                ->where('esm.JOB_ID',$jobId)
                                ->where('esm.METADATA_ID',$chapterID)
                                ->where('esm.IS_DELETED',0)
                                ->get();
      
            
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $getchapters        =   taskLevelMetadataModel::getMetadatadetailsJob($jobId);
		
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
		
            $wheredata          =   array('JOB_ID'=>$jobId,'METADATA_ID'=>$chapterID);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
			
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno !=    '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
                $esmfile       =    array();
                $esmfile2      =    array();
                
                if(!empty($esmDetails)){
                    $esmfilePath   =    $getlocationftp->FTP_PATH.Config::get('constants.EMS_DESTINATION_PATH').$chapterNo.'/';
                    $esmfilePath   =    str_replace('BOOK_ID',$bookid,$esmfilePath);
                    $esmfile       =    array();
                    $esmfile2      =    array();
                    foreach($esmDetails as $key => $data){
                       $esmfile[] = $esmfilePath.$data->ORGINAL_FILE_NAME;
                       $esmfile2[$data->ORGINAL_FILE_NAME] = $data->CLIENT_ID;
                    }
                }
               
                $spicepathreplce    =       Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                $stage_name              =       Config::get('constants.STAGE_NAME.COPY_EDITING');
                $cmn_obj            =   new CommonMethodsController();
                
                // S200 Jobsheet Path
                $wherejobdata = ['ROUND_ID' => $this->round_ID_200];
                $getjobsheetpath = jobsheetViewpathModel::active()->where($wherejobdata)->first();
                $jobsheetPath   =   $getjobsheetpath['JOBSHEET_PATH'];
				
			
                $inp_rep_arr = array(
                    'BOOK_ID' => $bookid,
                    'ROUND_NAME' => $this->round_NAME_S200,
                    'CID' => $chapterno
                );
                
                $reaadjobsheetpath  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobsheetPath );
                
                $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
                $documenttypeexnt   =   Config::get('constants.DOCUMENT_TYPE.document');
                $metadoctypeexnt    =   Config::get('constants.DOCUMENT_TYPE.meta');
                $rootdir            =   rtrim(Config::get('constants.FILE_SERVER_ROOT_DIR'),'/');
                $jobdirfiles        =   [];
                $jobfilesize        =   [];
                $jobdoctype         =   [];
                if (count($jobsheetDirFiles) >= 1) {
                    foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                        $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                        if (strpos($spiltchapter, '.') !== false) {
                            $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                            $splitname = explode('.', $spiltchapter);
                            if (in_array($nameofchapterextn, ['xml'])) {
                                if (strpos($spiltchapter, $bookid) !== false) {
                                    if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                        $jobdoctype[] = "meta";
                                    } else {
                                        $jobdoctype[] = "other";
                                    }
                                    $jobdirfiles[] = "//" . $hostserver . $rootdir . '/' . $reaadjobsheetpath .'/'.$spiltchapter;
                                    $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                }
                            }
                        }
                    }
                }
	
                // if S200 jobsheet not found job sheet get s50 job sheet
                if(count($jobdirfiles)  ==  0){
                    $jobdirfiles        =   [];
                    $jobfilesize        =   [];
                    $jobdoctype         =   [];
                    $whereS50data = ['ROUND_ID' => $this->round_ID_50];
                    $getjobsheetpath = jobsheetViewpathModel::active()->where($whereS50data)->first();
                    $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                    $inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $this->round_NAME_S50);
                    $reaadjobsheetpath = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
                    $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
                    if(count($jobsheetDirFiles)>=1) {
                        foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                            $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                            if (strpos($spiltchapter, '.') !== false) {
                                $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                                $splitname = explode('.', $spiltchapter);
                                if (in_array($nameofchapterextn, ['xml'])) {
                                    if (strpos($spiltchapter, $bookid) !== false) {
                                        if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                            $jobdoctype[] = "meta";
                                        } else {
                                            $jobdoctype[] = "other";
                                        }
                                        $jobdirfiles[] = "//" . $hostserver . $rootdir .'/'. $reaadjobsheetpath . $spiltchapter;
                                        $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                    }
                                }
                            }
                        }
                    }
                }
          
                // if not found job sheet get s5 job sheet
                if(count($jobdirfiles)  ==  0){
                    $jobdirfiles        =   [];
                    $jobfilesize        =   [];
                    $jobdoctype         =   [];
                    $whereS50data = ['ROUND_ID' => $this->round_ID_5];
                    $getjobsheetpath = jobsheetViewpathModel::active()->where($whereS50data)->first();
                    $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                    $inp_rep_arr = array('BOOK_ID' => $bookid,'ROUND_NAME' => $this->round_NAME_S5);
                    $reaadjobsheetpath = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
                    $jobsheetDirFiles   =   $ftpObj->allFiles($reaadjobsheetpath);
                    if(count($jobsheetDirFiles)>=1) {
                        foreach ($jobsheetDirFiles as $key => $jsonvalue) {
                            $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);
                            if (strpos($spiltchapter, '.') !== false) {
                                $nameofchapterextn = substr(strrchr($spiltchapter, "."), 1);
                                $splitname = explode('.', $spiltchapter);
                                if (in_array($nameofchapterextn, ['xml'])) {
                                    if (strpos($spiltchapter, $bookid) !== false) {
                                        if (in_array($nameofchapterextn, $metadoctypeexnt)) {
                                            $jobdoctype[] = "meta";
                                        } else {
                                            $jobdoctype[] = "other";
                                        }
                                        $jobdirfiles[] = "//" . $hostserver . $rootdir .'/'. $reaadjobsheetpath . $spiltchapter;
                                        $jobfilesize[] = $ftpObj->size($reaadjobsheetpath . '/' . $spiltchapter);
                                    }
                                }
                            }
                        }
                    }
                }
                
                $chapterlist        =       $getchapters->pluck('CHAPTER_NO')->toArray(); 
                $spicepathreplce    =       Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                $stage_name         =       Config::get('constants.STAGE_NAME.COPY_EDITING');
		$irp		    =       0;
                $gotostat   =   false;
		if( $gotostat ){
                    runAgainfrom:
                    $stage_name         =     Config::get('constants.STAGE_NAME.CE_INPUT_ANALYSIS'); 

					$irp   				=	$irp+1;
                }
				
				
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundId),
                                            '{STAGE}' =>  $stage_name,
                                            '{CID}' =>    $chapterno,
                                         );
                
                $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $open_path          =   $hostpath.$rawpath;
             
                $serverDirFiles     =   $ftpObj->allFiles($open_path);
                if(empty($serverDirFiles)){

                    if($irp  < 3 ) {
                            goto runAgainfrom;
                    }
                }
		
				
                if(!empty($esmfile)){
                    $serverDirFiles     = 	array_merge($serverDirFiles,$esmfile);
                }
                
                $getoriginalchapter =   [];
                $getartpaths        =   [];
                $getchapterpaths    =   [];
                // get chapter document
                if(count($serverDirFiles)>=1)
                {
                    $chapterfilesize    =   [];
                    $fmfilesize         =   [];
                    $getoriginalchapter =   [];
                    $documenttype       =   [];
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                    $clientId           =   Config::get('constants.CLIENTID');
                    
                    $hostpath           =   str_replace("/",'',$hostpath);
                    
                    
                    foreach($serverDirFiles as $key=>$jsonvalue)
                    {
                      
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                           
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                               
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    if(in_array($nameofchapterextn,$documenttypeexnt))
                                    {
                                        $documenttype[]     =   "document";
                                        $getoriginalchapter[]   =   "//".$hostserver.$rootdir.'/'.$open_path.$spiltchapter;
                                        $fmfilesize[]       =   $ftpObj->size($open_path.'/'.$spiltchapter);
                                    }
                                    else {
                                       
                                        $documenttype[]     =   "media";
                                         $getoriginalchapter[]   =   "//".$hostserver.$rootdir.$jsonvalue;
                                         $fmfilesize[]           =   $ftpObj->size($jsonvalue);
                                    }
                                  
                                }
                            }
                        }
                        
                    }
                
                    $destinationurl     =   $hostserver.$rootdir.$open_path;
				
                    if(!empty($serverMapPath['detail']['dest'])){
                        $destinationurl     =    str_replace($hostserver,$hostserver.$rootdir,$serverMapPath['detail']['dest']);
                        $destinationurl     =   str_replace("//","/",$destinationurl);
                    }else{
                        $destinationurl     =   str_replace("//","/",$destinationurl);
                        $destinationurl     =   str_replace(Config::get('constants.STAGE_NAME.COPY_EDITING'),Config::get('constants.STAGE_NAME.SPICE'),$destinationurl);
                    }
                    $destinationurl     =   "//".$destinationurl;
                    $wheredata          =   array('JOB_ID'=>$jobId,'CHAPTER_NO'=>$chapterno);
                    $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
                    $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
                    $spicast                    =   [];
                    $spicast['JOB_ID']          =   $jobId;
                    $spicast['ROUND']           =   $roundId;
                    $spicast['METADATA_ID']     =   $metadataID;
                    $spicast['STAGE']           =   $stageId;
                    $spicast['START_TIME']      =   Carbon::now();
                    $spicast['CREATED_DATE']    =   Carbon::now();
                    $spicast['CREATED_BY']      =   Session::get('users')['user_id'];
                    $storespicast               =   autoStageModel::store($spicast);
                    // check layout is have or not for current book
                    $getlayoutprofile           =   jobInfoModel::where('JOB_ID',$jobId)->first();
                    $layoutprofile              =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                        =   \Config('app.url').'api/spiceCallback';
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('Metadata');
                    $xml->setIndent(true);
                    $xml->startElement('Publisher');
                    $xml->text($clientId);
                    $xml->endElement();
                    $xml->startElement('Location');
                    $xml->text($getlocationftp->LOCATION_NAME);
                    $xml->endElement();
                    $xml->startElement('ClientID');
                    $xml->text($clientId);
                    $xml->endElement();
                    $xml->startElement('Cycle');
                    $xml->text(true);
                    $xml->endElement();
                    $xml->startElement('Process');
                    $xml->text(Config::get('constants.STAGE_NAME.TAPS'));
                    $xml->endElement();
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('ChapterNo');
                    $xml->text($chapterno);
                    $xml->endElement();
                    //SOURCE PATH
                    $xml->startElement('Source');
                        foreach($getoriginalchapter as $key=>$fmnames)
                        {
                            $xml->startElement("File"); 
                            $xml->writeAttribute("type", $documenttype[$key]); 
                            if(!empty($esmfile2)){
                                $splitArray       =   explode('/',$fmnames);
                                $fileName         =  end($splitArray);
                                $esmfileName      =  explode('.',$fileName);
                                if(array_key_exists($fileName,$esmfile2)){
                                    $xml->writeAttribute("VideoID", $esmfile2[$fileName]);
                                }
                            }
                            $xml->writeAttribute("size", $fmfilesize[$key]); 
                            $xml->writeAttribute("src", $fmnames); 
                            
                         
                            $xml->endElement();  
                        }
                        if(count($jobdirfiles)>=1)
                        {
                            foreach($jobdirfiles as $key=>$fmnames)
                            {
                                    $xml->startElement("File"); 
                                    $xml->writeAttribute("type", $jobdoctype[$key]); 
                                    $xml->writeAttribute("size", $jobfilesize[$key]); 
                                    $xml->writeAttribute("src", $fmnames); 
                                    $xml->endElement();
                            }
                        }
                        
                    $xml->endElement();
                    //DESTINATION PATH
                    $xml->startElement('Destination');
                        $xml->startElement("File"); 
                        $xml->writeAttribute("dest", $destinationurl); 
                        $xml->endElement();  
                    $xml->endElement();  
                    //work flow tag
                    $xml->startElement("Workflow"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "spice");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$metadataID);
                        $xml->writeAttribute('key', "metaid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$roundId);
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $storespicast->TOKEN);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "data-time");
                        $xml->writeAttribute('value', "{0:yyyy-MM-dd HH-mm-ss}");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();

                    $content 	= 	$xml->outputMemory();
                                  
                    $filename 	=	$bookid.'_'.$chapterno.'_meta.xml';
                    $successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICE_WATCH_FILE').'/'.$filename, $content);
					$successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICE_WATCH_FILE').'MagnusTest/'.$filename, $content);
                    if($successfileresponse ==     true)
                    {
                        $result             =   array('status'=>'2','message'=>'success');
                    }
                    else
                    {
                        $result             =   array('status'=>'3','message'=>'failed');
                    }
                    
                    $result         =   array('status'=>'2','result'=>200,'errMsg'=>'Spice xml posted sucessfuly...');   
                    
                    return response()->json($result);
                }
            }
            
            $result         =   array('status'=>'3','result'=>400,'errMsg'=>'Chapter or Job Info data is missing');               
            return response()->json($result,404);
            
        }
        catch( \Exception $e )
        {           
            $result         =   array('status'=>'3','result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
        
    }
    
    public function doFigurevalidationxml($jobId = null,$stageId = null,$roundId = null,$chapterID = null)
    {
        try
        {
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            $wheredata          =   array('JOB_ID'=>$jobId,'METADATA_ID'=>$chapterID);
            $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
            $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
            $chapterno          =   (count($getmetadata)>=1?$getmetadata->CHAPTER_NO:'');
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && $chapterno   !=  '')
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                
                
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                
                $figurelocation     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.Config::get('constants.SPLIT_DESTINATION_PATH').$chapterno;
                $inp_rep_arr        =   array( 
                                            'BOOK_ID' =>    $bookid , 
                                            'STAGE_NAME' =>  Config::get('constants.ART_SOURCE_PATHS') 
                                         );
                $cmn_obj            =   new CommonMethodsController();
                $figurelocation     =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $figurelocation );
                
                $figurelocation     =   str_replace( '//' ,'/', $figurelocation );
                $open_path          =   Config::get('constants.SPICAST_BACKGROUND_FILE').'/'.$bookid.'/'.$chapterno.Config::get('constants.SPICAST_IMAGES_FILE');
                $serverDirFiles     =   $ftpObj->allFiles($open_path);
                
                if(!empty($figurelocation))
                {
                    $figurelocation =   "\\\\".$figurelocation;
                    $figurelocation =   str_replace( '/' ,'\\', $figurelocation );
                }
                $spicepathreplce    =   Config::get('serverconstants.SPICE_PRODUCTION_CHAPTER_PATH');
                $inp_rep_arr        =   array( 
                                            '{BID}' =>    $bookid , 
                                            '{RID}' =>    Config::get('constants.ROUND_NAME.'.$roundId),
                                            '{STAGE}' =>  Config::get('constants.STAGE_NAME.ART_FILES'),
                                            '{CID}' =>    $chapterno,
                                         );
                $cmn_obj            =   new CommonMethodsController();
                $rawpath            =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $spicepathreplce );
                $destinationurl     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$hostpath.$rawpath;
                $destinationurl     =   str_replace( '//' ,'/', $destinationurl);
                if(!empty($destinationurl))
                {
                    $destinationurl     =   "\\\\".$destinationurl;
                    $destinationurl     =   str_replace( '/' ,'\\', $destinationurl );
                }
                $getartfigure       =   taskLevelArtMetadataModel::getArtChapterwisefigureInfo($metadataID);
             
                if(count($serverDirFiles)>=1)
                {
                    $spicast                    =   [];
                    $spicast['JOB_ID']          =   $jobId;
                    $spicast['ROUND']           =   $roundId;
                    $spicast['METADATA_ID']     =   $metadataID;
                    $spicast['STAGE']           =   $stageId;
                    $spicast['PROCESS_TYPE']    =   true;
                    $spicast['START_TIME']      =   Carbon::now();
                    $spicast['CREATED_DATE']    =   Carbon::now();
                    $spicast['CREATED_BY']      =   Session::get('users')['user_id'];
                    $storespicast               =   figureValidationModel::store($spicast);
                    // check layout is have or not for current book
                    $getlayoutprofile           =   jobInfoModel::where('JOB_ID',$jobId)->first();
                    $layoutprofile              =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                        =   \Config::get('constants.ROUTE_URL').'/api/figurevalidationCallback';
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('ArtMeta');
                    $xml->writeAttribute("figureLocation", $figurelocation); 
                    $xml->setIndent(true);
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('metaid');
                    $xml->text($metadataID);
                    $xml->endElement();
                    $xml->startElement('aid');
                    $xml->text($chapterno);
                    $xml->endElement();
                    $xml->startElement('round');
                    $xml->text($roundId);
                    $xml->endElement();
                    $xml->startElement('destpath');
                    $xml->text($destinationurl);
                    $xml->endElement();
                    //FIGURE DETAILS
                    if(count($getartfigure)>=1)
                    {
                        foreach($getartfigure as $key=>$value)
                        {
                            $xml->startElement('Figure');
                            $xml->writeAttribute("query", ""); 
                            $xml->writeAttribute("graphicalabstract", ""); 
                            $xml->writeAttribute("inputMode", $value->INPUT_MODE); 
                            $xml->writeAttribute("complexity", $value->COMPLEXITY); 
                            $xml->writeAttribute("printColor", $value->OUTPUTCOLOR); 
                            $xml->writeAttribute("webColor", ""); 
                            $xml->writeAttribute("inputColor", $value->INPUTCOLOR); 
                            $xml->writeAttribute("workInvolved", $value->WORK_INVOLVED); 
                            $xml->writeAttribute("figureType", $value->FIGURE_TYPE); 
                            $xml->writeAttribute("fileType", $value->INPUT_FILE); 
                            $xml->writeAttribute("remarks", ""); 
                            $xml->writeAttribute("inputDPI", ""); 
                            $xml->writeAttribute("name", $value->FILE_NAME); 
                            $xml->endElement();  
                        }
                    }
                    //work flow tag
                    $xml->startElement("WorkflowAPI"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "pdfcreation");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "autoStageController");
                        $xml->writeAttribute('key', "controller");
                        $xml->endElement();

                        
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "figureValidation_callback");
                        $xml->writeAttribute('key', "methodname");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "batchAutoStageMovement");
                        $xml->writeAttribute('key', "_callback");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$metadataID);
                        $xml->writeAttribute('key', "metaid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$roundId);
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $storespicast->TOKEN);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "date-time");
                        $xml->writeAttribute('value', "Y-m-d H:m:i");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();

                    $content 	=   $xml->outputMemory();
                    $filename 	=   $bookid.'_FIGUREVALIDATION.xml';
                    $filepath   =   str_replace('TYPEOFART','FIGURE_VALIDATION',Config::get('constants.ARTFIES_WATCH_FILE'));
                    $successfileresponse 	=	$ftpObj->put($filepath.'/'.$filename, $content);
                    if($successfileresponse ==     true)
                    {
                        $result             =   array('message'=>'success');
                    }
                    else
                    {
                        $result             =   array('message'=>'failed');
                    }
                    $result         =   array('result'=>200,'errMsg'=>'Figurevalidation xml posted sucessfuly...');   
                    return response()->json($result);
                }
            }
            $result         =   array('result'=>400,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result,404);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
	
	public function spicetest(){
		
		$jobId				=  '6539';
		$metaid				=  '4063';
		$roundID			=  '116';
		$ChapterNo			=  'FM1';
		$ChapterTitle		=  'INTRODUCTION';
		
		$getToolresponse    =   app('App\Http\Controllers\Api\tapsController')->domoveTaps($jobId,$metaid,$roundID,$ChapterNo,$ChapterTitle);
		echo "<pre>";print_r($getToolresponse);exit;
		
	}
    
    public function spiceCallbacktoolresponse(Request $request)
    {    
        parse_str($request->getQueryString(),$getToolresponse);
        Log::useDailyFiles(storage_path().'/Api/spiceReturnSignal.log');
		
		try{
			
			Log::info( json_encode( $getToolresponse ) );
			$getToolresponse    =   (object)$getToolresponse;
			
			if(count($getToolresponse)>=1){	
				
				$request['token']       =   $getToolresponse->tokenkey;
				$request['status']      =   $getToolresponse->status;
				$request['round']       =   $getToolresponse->round;
				$request['endtime']     =   $getToolresponse->endtime;
				$request['metaid']      =   $getToolresponse->metaid;
				
				$validation             =   Validator::make($request->all(), [
													'token' 	=> 'required',
													'status' 	=> 'required|numeric',
													'round' 	=> 'required|numeric',
													'metaid' 	=> 'required|numeric',
													'endtime' 	=> 'required'
											]);
				
				if ($validation->fails())
				{
					return response()->json($validation->errors());
				}
				
				//update auto stage tool response
				$token                  =   trim($getToolresponse->tokenkey);
				$status                 =   trim($getToolresponse->status);
				if($status  == '1' || $status  == '0'){
					$status  = 1;
				}
				
				
				$endtime                =   trim($getToolresponse->endtime);
				$metaid                 =   $getToolresponse->metaid;
				$roundid                =   $getToolresponse->round;
				$updatedata             =   [];
				$updatedata['END_TIME'] =   $endtime;
				$updatedata['STATUS']   =   ($status    ==  1 ? '2' : '3' );
				$updatedata['REMARKS']  =   trim($getToolresponse->remarks);
				$updatedata['RESPONSE_LOG']   =   json_encode($_REQUEST);
				
				$rec_arr                =       autoStageModel::getApiRequestByTokenKey( $token );
				
				if( count( $rec_arr ) ){
				
					$updatemeta             =       autoStageModel::doupdate( $token , $updatedata );

					$getchapters            =       taskLevelMetadataModel::where( 'METADATA_ID' , $getToolresponse->metaid )->first();

					if( $status  ==  "1" && count( $getchapters )>=1){

                                            $artProcessObj      =   new artProcessController();
                                            
                                            $jobsheetmove       =   $artProcessObj->dosfiftyJobsheetmove($getToolresponse->metaid);
                                            $tapsxml            =   $artProcessObj->doTapssupportingxml($getToolresponse->metaid);
                                            $chapartmetaxml     =   $artProcessObj->doChapterartmetaxml($getToolresponse->metaid);
                                            $chapmetaxml        =   $artProcessObj->doChaptermetaxml($getToolresponse->metaid);
                                            $referencexml        =  $artProcessObj->doReferencePdfFileCopy($getToolresponse->metaid);

                                            $ChapterNo          =   ( count($getchapters)>=1?$getchapters->CHAPTER_NO:'' );
                                            $ChapterTitle       =   ( count($getchapters)>=1?$getchapters->CHAPTER_NAME:'' );
                                            $jobId              =   ( count($getchapters)>=1?$getchapters->JOB_ID:'' );
                                            
                                            $roundID            =   Config::get('constants.ROUND_NAME.S200');
                                            $tapsCont           =   new tapsController();
                                            $getToolresponse    =   $tapsCont->domoveTaps($jobId,$metaid,$roundID,$ChapterNo,$ChapterTitle);

                                            if($updatemeta){

                                                $this->stageCompletionProcess($metaid,$roundid);
                                                $result     =   array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Success Response signal received and updated Successfully' );    
                                                return response()->json( $result );

                                            }
						
					}
					
					$result         =   array( 'status'=>0 , 'msg'=>'success' , 'errMsg'=>'Failure Response signal received and updated Successfully' );
					return response()->json($result);
			 
				}else{

					$result         =           array( 'status' => 0 , 'msg'=> 'failed' , 'errMsg'=>'Invalid try , [ Reason : Invalid tokenkey or Signal already received for this tokenkey ]'  );
					
					return response()->json($result);

				}
			
			}
		
        }catch( \Exception $e ){
			
			$result         =           array('status'=>0 , 'msg'=>'Bad Request' , 'errMsg'=>  $e->getMessage().'[ Reason : invalid input]');
			return response()->json($result);
			
		}
		
        $result         =           array('status'=>0 , 'msg'=>'Bad Request' , 'errMsg'=>'Bad request Sending try again. [ Reason : invalid input type ]','token'=>'');
        return response()->json($result);
        
    }
    
    public function figureCallbacktoolresponse(Request $request)
    {      
            $array  =   array(
            'Spicastdetails'=>
                array(array('id'=>1879,'SNo'=>1,'ChapterName'=>'chapter 1x.docx','Words'=>3026,'Pages'=>7,'Characters'=>12369,'Lines'=>290,'ArtPages'=>10,'Blanks'=>50,'TotalPages'=>500),
            array('id'=>1892,'SNo'=>2,'ChapterName'=>'chapter 2x.docx','Words'=>302,'Pages'=>7,'Characters'=>123,'Lines'=>29,'ArtPages'=>10,'Blanks'=>5,'TotalPages'=>50),
            array('id'=>1896,'SNo'=>3,'ChapterName'=>'chapter 3x.docx','Words'=>302,'Pages'=>7,'Characters'=>123,'Lines'=>29,'ArtPages'=>10,'Blanks'=>5,'TotalPages'=>50)),
            'workflow'=>array('token'=>'HS1EiO4d4u','status'=>1,'job_id'=>6298,'round'=>116,'end_time'=>'2018-03-29 11:53:35','remarks'=>array('feedback'=>"Error occured during Image DLL")));
            $url    =   url('/').'/api/apiSpicastToolresponse';
                
        $getToolresponse    =  json_decode(file_get_contents('php://input'));
        Log::useDailyFiles(storage_path().'/Api/figurevallog.log');
        Log::info($getToolresponse);
        if(count($getToolresponse)>=1)
        {
            if(count($getToolresponse->workflow)>=1)
            {			
                $request['token']       =   $getToolresponse->workflow->token;
                $request['status'] 	=   $getToolresponse->workflow->status;
                $request['job_id'] 	=   $getToolresponse->workflow->job_id;
                $request['round'] 	=   $getToolresponse->workflow->round;
                $request['end_time']    =   $getToolresponse->workflow->end_time;
                $validation             =   Validator::make($request->all(), [
                                                    'token' 	=> 'required',
                                                    'status' 	=> 'required|numeric',
                                                    'job_id' 	=> 'required',
                                                    'round' 	=> 'required',
                                                    'end_time' 	=> 'required'
                                            ]);
                if ($validation->fails())
                {
                    return response()->json($validation->errors());
                }
                //update auto stage tool response
                $token                  =   trim($getToolresponse->workflow->token);
                $status 		=   trim($getToolresponse->workflow->status);
                $endtime 		=   trim($getToolresponse->workflow->end_time);
                $updatedata             =   [];
                $updatedata['END_TIME'] =   $endtime;
                $updatedata['STATUS']   =   $status;
                $updatedata['RESPONSE_LOG']   =   file_get_contents('php://input');
                if(count($getToolresponse->workflow->remarks)>=1)
                {
                    $updatedata['REMARKS']  =	trim($getToolresponse->workflow->remarks->feedback);
                }
                $updatemeta         =   figureValidationModel::doupdate($token,$updatedata);
                if($updatemeta)
                {
                    $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                    return response()->json($result);
                }
                $errormetaid    =   "";
                $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token');
                return response()->json($result);
            }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Work flow data is empty','token'=>'');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'');
        return response()->json($result);
    }
    
    public function pdfcreationCallbacktoolresponse(Request $request)
    {           
        $getToolresponse    =  json_decode($request->getContent());
        Log::useDailyFiles(storage_path().'/Api/pdfcreationlog.log');
        Log::info($request->getContent());
        
        if(count($getToolresponse)>=1)
        {
            $token                  =   trim($getToolresponse->tokenkey);
            $request['token']       =   $getToolresponse->tokenkey;
            $request['status']      =   $getToolresponse->status;
            $request['metaid']      =   $getToolresponse->metaid;
            $request['round']       =   $getToolresponse->round;
            $round                  =   $getToolresponse->round;
            
            $validation             =   Validator::make($request->all(), [
                                                'token' 	=> 'required',
                                                'status' 	=> 'required|numeric',
                                                'metaid' 	=> 'required',
                                                'round' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                return response()->json($validation->errors());
            }

            $gettypeofprocess   =   apipdfcreationModel::where('TOKEN_KEY',$getToolresponse->tokenkey)->first();            
            if(count($gettypeofprocess)>=1)
            {
                $typeofwomat    =   $gettypeofprocess->WOMAT_TYPE;
                $metadataID     =   $gettypeofprocess->METADATA_ID;
                $status         =   trim($getToolresponse->status);
                $endtime        =   (isset($getToolresponse->endtime)?$getToolresponse->endtime:Carbon::now());
                
                if($gettypeofprocess->PROCESS_TYPE  ==  1){
                    //update auto stage tool response
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    $updatedata['RESPONSE_LOG']   =   file_get_contents('php://input');
                    $updatedata['REMARKS']  =	trim($getToolresponse->remarks);
                    $updatemeta             =   apipdfcreationModel::doupdate($token,$updatedata);
                    if($updatemeta)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                        return response()->json($result);
                    }
                    else
                    {
                        $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Requested api entry is not available','token'=>$token.' is not valid token');
                        return response()->json($result);
                    }
              }else{
                    
                    //update auto stage tool response
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    $updatedata['RESPONSE_LOG']   =   file_get_contents('php://input');
                    $updatedata['REMARKS']  =   trim($getToolresponse->remarks);
                    $updatemeta             =   apipdfcreationModel::doupdate($token,$updatedata);
                    if($updatemeta)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');

                        $wheredata      =   array('METADATA_ID'=>$metadataID,'IS_ACTIVE'=>1);
                        $artmetaid      =   taskLevelArtMetadataModel::where($wheredata)->get();
                        $getallmetaid   =   $artmetaid->pluck('ART_METADATA_ID')->toArray();
                        $jbs_obj        =   new jobStage();
                        $checkoutObj    =   new checkoutModel();
                        
                       $currentStageDetails =    $checkoutObj->getCurrentStageDetaisByMetadataId($request['metaid'],$request['round']);
                       $currentStageDetails->artMetadataId = $getallmetaid;
                      
                       /* foreach( $getallmetaid as $key => $value ){
                            
                            $jobstage               =        $jbs_obj->getJobStageInfoByArtMetaId( $value );
                            $jobStageId             =        $jobstage[0]->JOB_STAGE_ID;
                            $stageDetails           =        $checkoutObj->getArtStageInfo($jobStageId);
                            $stageData              =        $stageDetails['0'] ;
                            
                            //Move to next stage
                            //app('App\Http\Controllers\checkout\stageMangerController')->moveToNextStageForArtFigureValiation(  $stageDetails['0']  );
                            
                        }*/
                       
                       /** report data **/
                        $reportData['JOB_ID']       =   $currentStageDetails->JOB_ID;
                        $reportData['METADATA_ID']  =   $metadataID;
                        $reportData['ROUND_ID']     =   $currentStageDetails->ROUND_ID;
                        $reportData['ACTION']       =   '1';
			
                        if(count($currentStageDetails)>=1){

                               $jobRoundId             = $currentStageDetails->JOB_ROUND_ID;
                               $roundId                = $currentStageDetails->ROUND_ID;
                               $stageSequence          = $currentStageDetails->STAGE_SEQ + 1;
                               $workflowId             = $currentStageDetails->WORKFLOW_ID;  
                               $iteration              = $currentStageDetails->ITERATION_ID;
                               $jobStageId			   = $currentStageDetails->JOB_STAGE_ID;	
                               $stageDetails       	   = $checkoutObj->getArtStageInfo( $jobStageId );   

							   $stageDetails['0']->artMetadataId  = $getallmetaid;
					
                               $stageManagerContObj     =       new stageMangerController();  
                               $nexstageDetails         =  $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId); 
							  
                               //$mailalertObj   =      new stagealertemailController();
                               //$mailalertObj->doSendemailalertstage( $jobId , $roundId , $stageId , $metadataId , 'success' );
                               $isart  = 1;
                               if(!empty($nexstageDetails)){ 
							   												   
                                    $moveStageResponse = $stageManagerContObj->moveNextStage( $stageDetails['0'] , $isart );  

									$lowres     = \Config::get('constants.STAGE_COLLEECTION.AUTO_ART_LOWRES');
									
									if($nexstageDetails->STAGE_ID  == $lowres ){
										
										$nextjobStageId 			=		$nexstageDetails->JOB_STAGE_ID;
										$checkoutObj                =       new checkoutModel();
										$stageDetails1               =       $checkoutObj->getStageInfo( $nextjobStageId );
										$stageDetailsObj1            =       $stageDetails1[0];
									
										$lowresContObj      =       new lowResController();
										$response  			=		$lowresContObj->lowResCreationBgProcessInitialize( $metadataID , $round ,$stageDetailsObj1);
										
									}
								
								
                               }else{
                                  $moveStageResponse1 = $stageManagerContObj->ArtfinalStage($jobStageId, $stageDetails['0'],$isart ); 
                                  $moveStageResponse['status'] = 'success'; 
                               }

                       }
						
					
                      //  $repSuccess                 =   app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData,'art');
                      //  echo "<pre>";print_r($currentStageDetails);exit;
                       // app('App\Http\Controllers\checkout\stageMangerController')->moveToNextStageForArtFigureValiation(  $currentStageDetails  );
                       //$stageResponse =   app('App\Http\Controllers\checkout\stageMangerController')->mangeArtStageProcess( $currentStageDetails,0,1);
					
                    $repSuccess                 =   app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData,'art');
                     if($round == '116'){
                        //sendinput for womat tool
                        app('App\Http\Controllers\Api\womatSignalController')->sendingSignalToWomatForArt( $metadataID , $round );

                        //send input signal for taps art completed
                        app('App\Http\Controllers\Api\tapsController')->sendArtCompletedSignaltoTaps(  $metadataID ,  $round );
			
                        $this->copyCreatedPdfAndRenameItForTaps( $metadataID , $round );
                      }
                        
                        //$lowresContObj      =       new lowResController();
                        //$lowresContObj->lowResCreationBgProcessInitialize( $metadataID , $round );
                        
                        return response()->json($result);
                        
                    }
                    else
                    {
                        $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Requested api entry is not available','token'=>$token.' is not valid token');
                        return response()->json($result);
                    }
                }
            }
            $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'');
        return response()->json($result);
    }
    
    public function copyCreatedPdfAndRenameItForTaps($metaid , $round ){
       
        $tlm                =       new taskLevelMetadataModel();

        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        $job_id             =       $jobinfo[0];
        $chapName           =       $chapterlist[0];
        
        $chp_arr            =       explode( '_' ,  $chapName  );
        
        if( count($chp_arr) == 2 ){

            $bi_obj                  =       new bookinfoModel();
            $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
            $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
            $book_id                 =       $bookinfo[0];
            $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );
            $round_arr               =       \Config::get('constants.ROUND_NAME');
            $roundname               =       $round_arr[ $round ];

            if( empty( $getlocationftp ) )            
               $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();

            $host   =   $hostserver     =       $getlocationftp->FTP_HOST;
            $usr    =   $hostusername   =       $getlocationftp->FTP_USER_NAME;
            $psw    =   $hostpassword   =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostPath           =   ( $getlocationftp->FTP_PATH );
            $crd        =       'ftp://'.$usr.':'.$psw.'@'; 

            $cmn_obj                 =       new CommonMethodsController();
            $tempPath                =       $host.'/'.\Config::get('constants.TAPS.TAPS_TEMP_PATH');   
            $pdfPath                 =       $host.$hostPath.\Config::get('serverconstants.ART_PDF_PRODUCTION_PATH');   

            $sourcePath                  =       $crd.$pdfPath.$book_id.'_'.$chapName.'_COMBINED_ARTWORK.pdf'; 
            $copy_name                   =       $book_id.'_'.$chp_arr[1].'_'.$chp_arr[0].'.pdf';
            $descPath                    =       $crd.$tempPath.$copy_name;
            $fileExistPath               =       $pdfPath.$copy_name;

            $inp_rep_arr            =       array( 
                                'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname   ,
                                '{BID}'         =>      $book_id ,   '{RID}'         =>      $roundname   ,      
                                '{CID}'         =>      $chapName
                            );

            $sourcePath                    =      $cmn_obj->arr_key_value_replace( $inp_rep_arr , $sourcePath );

            $fileExistPath               =       str_replace( '\\' , '/'  , $fileExistPath );
            $content                     =       file_get_contents($sourcePath);
             
            $options        = array('ftp' => array('overwrite' => true));
            $stream         = stream_context_create($options);
            
                if(!empty($content)) {
                    $descPath                =       str_replace( '\\' , '/'  , $descPath );
                    $response_file           =       @file_put_contents($descPath,$content , 0 , $stream);
                }
        
        }
        
        
        return true;
    }
    
    public function stageCompletionProcess($metaId,$roundId){
        
        $stageManagerModelObj       =       new stageManager();
        $stageManagerContObj        =       new stageMangerController();
        $stageInfo                  =       $stageManagerModelObj->getAutoStageInformation($metaId,$roundId);
        
        if(count($stageInfo)>=1){
           $jobStageId  =    $stageInfo['0']->JOB_STAGE_ID;
           
           $checkoutObj        =   new checkoutModel();
           $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
           
           if(count($stageDetails)>=1){
               
            $stageData              =   $stageDetails['0'];    
            $jobRoundId             =   $stageData->JOB_ROUND_ID;
            $roundId                =   $stageData->ROUND_ID;
            $stageSequence          =   $stageData->STAGE_SEQ + 1;
            $workflowId             =   $stageData->WORKFLOW_ID;  
            $iteration              =   $stageData->ITERATION_ID;
            $jobId                  =   $stageData->JOB_ID;
            $outputQuantity         =   $stageData->OUTPUT_QUANTITY;
            $inputQuantity          =   $stageData->INPUT_QUANTITY;
            
             $nexstageDetails =  $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId); 
             
            if(!empty($nexstageDetails)){ 
                
                $moveStageResponse = $stageManagerContObj->moveNextStage( $stageDetails['0'] );
                return $moveStageResponse;
                
            }else{
                
                $moveStageResponse = $stageManagerContObj->finalStage($jobStageId, $stageDetails['0'] ); 
                
            }
             
             $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully');
            
           }else{
            $result         =   array('status'=>0,'msg'=>'Failed','errMsg'=>'Stage details is empty');
           }
           
        }else{
             $result         =   array('status'=>0,'msg'=>'Failed','errMsg'=>'StageMovement process Failed');
        }
        
        return response()->json($result);
    }
    
    public function writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $whereToWrite , &$errorMsg = ''){
       
        try{
            
            $getToolresponse    =   $content;
       
            $ftpObj             =   Storage::createFtpDriver([
                                                        'host'     =>   $ftpInfo['HOST']    , 
                                                        'username' =>   $ftpInfo['FTP_USERNAME']    ,
                                                        'password' =>   $ftpInfo['FTP_PASSWORD']    ,
                                                        'port'     =>   '21',
                                                        'timeout'  =>   '30',
                                                ]); 
												
            if( substr( $whereToWrite , -1 ) !== '/' ){
       		$whereToWrite	.=	'/';
	    }
			
            return $ftpObj->put(  $whereToWrite.$filename, $content);
            
       }catch(\Exception $e){
           
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
           return false;
           
       }
       
    } 
    
    public function getAutoStageBgExecutionConfiguration( $jobstageid ){
        
        $ckm_obj            =       new checkoutModel();        
        $prepareConfig      =       array();
        
        $stageinfo          =       $ckm_obj->getStageInfo( $jobstageid );
       
        if( count( $stageinfo ) ){
            
            $stageinfo          =       $stageinfo[0];

            $stageid            =       $stageinfo->STAGE_ID;
            $round              =       $stageinfo->ROUND_ID;
            $wrkmstrid 		=	$stageinfo->WORKFLOW_MASTER_ID;
            $metaidfor 		=	$stageinfo->METADATA_ID;
			
            $bgExe              =       DB::table('bgprocess_execution')
                                            ->select()
                                            ->where( 'STAGE_ID' , '=' , $stageid )
                                            ->where( 'automatic_type' , '=' , 1 );
            
            $conventional		=		false;
            $tapswrkflwflg		=		false;

            $pacg			=		\Config::get( 'constants.STAGE_COLLEECTION.PACKAGING' );
            $getBatConv			=		DB::table('workflow_master')->select('workflow_master_id')
                                                                            ->where( 'workflow_master_id' , '=' , $wrkmstrid )
                                                                            ->where( 'workflow_master_name' , 'LIKE' , "%CONVEN%" )->get()->first();

            $medaInfo			=		DB::table( 'metadata_info' )->select('PRODUCTION_SYSTEM')
                                                                            ->where( 'METADATA_ID' , '=' , $metaidfor )
                                                                            ->get()->first();

            if( count( $medaInfo ) ){
                if( isset( $medaInfo->PRODUCTION_SYSTEM ) ){
                    if( $medaInfo->PRODUCTION_SYSTEM == 2 || $medaInfo->PRODUCTION_SYSTEM == '2' ){
                        $conventional	=	true;
                    }
                }				
            }

            if( count( $getBatConv ) ){
                $conventional	=	true;
            }
			
            if( $round == 116 && $stageid == $pacg && $conventional ){
                $bgExe->where( 'ROUND_ID' , '=' , $round );
            }else if( $round == 116 && $stageid == $pacg && !$conventional ){
		$bgExe->where( 'ROUND_ID' , '=' , $round );
		//return array();
	    }
            
            $bgExe = $bgExe->get()->first();
            
            if( count( $bgExe )  ){ 
                
                $prepareConfig[$stageid]        =       array(
                        'type'          =>      $bgExe->METHOD_TYPE  ,
                        'executable'    =>      $bgExe->METHOD_EXECUTION  ,   
                        'waiting'       =>      $bgExe->WAITING  ,
                        'controller'    =>      $bgExe->CONTROLLER
                );
                                
            }
            
        }
        
        return $prepareConfig;
        
    }
	
	  public function pitstopupdate($inputarr, &$response , &$_callback ){
		  
        $bgCont_Obj     =       new bgprocessController();
		  
        $response       =       $bgCont_Obj->pitstopResponseSignalReceive( $inputarr );
        $_callback      =       null;
        
        $bgCont_Obj->bgprocessSignalLogging( $inputarr , $response );
        
        if( isset( $inputarr['custom_calback'] ) && !empty(  $inputarr['custom_calback'] ) ){
            if( strlen( $inputarr['custom_calback'] ) ){
                $_callback      =       $inputarr['custom_calback'];
            }
        }
        
        return $response;
    }
    
}
