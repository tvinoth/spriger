<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\productionLocationModel;
use App\Models\apiActivemqModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiMetaExtractor;
use App\Models\apsRemainderEmailonoffModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\workflowServerMapPathModel;
use App\Models\jobsheetViewpathModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Http\Controllers\taskLevelMetadataController;
use App\Http\Controllers\customization\customizationController;
use App\Models\stageManager;
use App\Models\customizationModel;
use App\Http\Controllers\users\usersController;
use App\Mail\Jobdownloadfailed;
use App\Models\apiProductionFileTransfer;
use App\Http\Controllers\workflow\serverMapPathController;
use App\Http\Controllers\Api\revisedJobController;
use App\Http\Controllers\bookinfo\bookinfoController;
use App\Http\Controllers\Api\productionFileTransferController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;

#use Ixudra\Curl\Facades\Curl;
#use Ixudra\Curl\CurlService;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Carbon\Carbon;

class JsCompareController extends Controller
{
    
    
    public function jsCompareProcess($details, $others= array()){
      
      if(empty($details)){
          return false;
      }
      
      $jobId    = $details->JOB_ID;
      $roundId  = $details->ROUND;
      $metaId   = '';
      
      if($details->METADATA_ID != 0){
        $metaId     =    $details->METADATA_ID; 
      }
     
      if($details->PROCESS_TYPE_DIFF == 'RECEIPT'){
        $process  =   'compare';
      }else if($details->PROCESS_TYPE_DIFF == 'REVISED_RECEIPT'){
         $process  =   'recompare';  
      }
       $res  =  $this->jobsheetCompare($process,$roundId,$jobId,$metaId); 
       
       if($roundId == '118' || $roundId == '119'){
          $metadetailsRes      =    $metadataObj->getMetadatadetailsChapter($metaId);
          $metadetails         =    $metadetailsRes['0'];
          
          if($metadetails->FM_ARTICLE_BM == 1 || $metadetails->FM_ARTICLE_BM == 'FRONT MATTER' && $details->PROCESS_TYPE_DIFF == 'RECEIPT'){
              $process  = 'extratedxml';
              $res  =  $this->jobsheetCompare($process,$roundId,$jobId,$metaId); 
          }
         
       }
       
       
      return $res;
        
    }
    
    
  
    public function jobsheetCompare($process='' ,$currentRoundId='' , $jobId='', $metaId='' ){
     $process         =  'compare'; 
     $currentRoundId  = '114';  
     $jobId           = '6507';
     $metaId          = '';
     $postculrinit                 =       new CommonMethodsController();
     $postUrl                 =       Config::get('constants.JS_COMPARE.POST_URL');
     
     $logfilename             =       'JsCompare.log';
     Log::useDailyFiles(storage_path().'/Api/'.$logfilename);
     $dataInfo                =        array();
     switch ($process) {
            
        case "compare":
            $compareStage       =    $this->getPreviousStage($currentRoundId);
            $dataInfo           =    $this->compareStageJobsheet($jobId, $currentRoundId, $compareStage,$metaId);
            Log::info( json_encode( $dataInfo) );
            $contents           =   $postculrinit->RestfulPostcUrlExecution($dataInfo,$postUrl,true,"");
             Log::info( json_encode( $contents) );
            $result             =   array('result'=>200,'status'=>1,'errMsg'=>$contents);
        break;
        case "recompare":
              $dataInfo         =    $this->revisionCompare($jobId ='6513', $currentRoundId, $metaId);
              Log::info( json_encode( $dataInfo) );
              $contents         =   $postculrinit->RestfulPostcUrlExecution($dataInfo,$postUrl,true,"");
              Log::info( json_encode( $contents) );
              $result           =   array('result'=>200,'status'=>1,'errMsg'=>$contents);
            break;
        case "extratedxml":
            $compareStage       =    $this->getPreviousStage($currentRoundId);
            $dataInfo           =    $this->compareStageJobsheetWithXml($jobId, $currentRoundId, $compareStage,$metaId);
            Log::info( json_encode( $dataInfo) );
            $contents           =   $postculrinit->RestfulPostcUrlExecution($dataInfo,$postUrl,true,"");
            Log::info( json_encode( $contents) );
            $result             =   array('result'=>200,'status'=>1,'errMsg'=>$contents);
            break;
        
          /*  if(!empty($dataInfo)){
                $data                    =      json_encode($dataInfo);
                $returns_response        =       $cmn_obj->PostcUrlExecution( $data , $curl );
            }*/

        }
      
    }
    
   public function getPreviousStage($currentRoundId){
       $roundId   = '';
       if($currentRoundId  == '114'){
           $roundId = '104';
       }
       
        if($currentRoundId  == '116'){
           $roundId =  '114';
        }
        
         if($currentRoundId  == '118'){
           $roundId = '116';
        }
        
        return $roundId;
       
   }
    
   public function compareStageJobsheet( $jobId, $currentStage, $previousStage, $metaId){
       
       $jobModelObj            =    new jobModel();
       $metadetails            =    array();
       $compareData            =    array();
       $jobDetails             =    $jobModelObj->getJobdetails($jobId);
        if(!empty($metaId)){
        $metadetailsRes         =    $metadataObj->getMetadatadetailsChapter($metaId);
        $metadetails            =    $metadetailsRes['0'];
       }
       
       $jobsheetDetails        =    $this->jobSheetReturn($jobId, $currentStage, $jobDetails, $metadetails);
       $PrejobsheetDetails     =    $this->jobSheetReturn($jobId, $previousStage, $jobDetails, $metadetails);
       if(empty($PrejobsheetDetails)){
           $previousStage       =    $this->getPreviousStage($previousStage);
           $PrejobsheetDetails =    $this->jobSheetReturn($jobId, $previousStage, $jobDetails, $metadetails);
       }
       
       $roundName                           = Config::get('constants.ROUND_NAME');
       $compareData['JS_Type']              = 'compare';
       $compareData['BookId']               = $jobDetails->BOOK_ID;
       $compareData['ChapterNo']            = $jobDetails->CHAPTER_NO;
       $compareData['PreviousJobsheet']     = $PrejobsheetDetails;
       $compareData['CurrentJobsheet']      = $jobsheetDetails;
       $compareData['FromStage']            = $roundName[$previousStage];
       $compareData['ToStage']              = $roundName[$currentStage];
       $compareData['Stage']                = $roundName[$currentStage];
       $compareData['UserRole']             = '';
       $compareData['ExcelFilePath']        = '';
       
       return $compareData;
       
    
   }
   
   
   public function compareStageJobsheetWithXml( $jobId, $currentStage, $previousStage, $metaId){
       
       $jobModelObj            =    new jobModel();
       $compareData            =    array();
       $metadetails            =    array();
       $jobDetails             =    $jobModelObj->getJobdetails($jobId);
       $metadataObj            =    new taskLevelMetadataModel();
       
       if(!empty($metaId)){
         $metadetailsRes         =    $metadataObj->getMetadatadetailsChapter($metaId);
         $metadetails            =    $metadetailsRes['0'];
        }
     

       $jobsheetDetails        =    $this->jobSheetReturn($jobId, $currentStage, $jobDetails, $metadetails);
       $PrejobsheetDetails     =    $this->getXmlPath($jobId, $previousStage, $jobDetails, $metadetails);
      
       $roundName                           = Config::get('constants.ROUND_NAME');
       $compareData['JS_Type']              = 'extratedxml';
       $compareData['BookId']               = $jobDetails->BOOK_ID;
       $compareData['ChapterNo']            = $metadetails->CHAPTER_NO;
       $compareData['PreviousJobsheet']     = $PrejobsheetDetails;
       $compareData['CurrentJobsheet']      = $jobsheetDetails;
       $compareData['FromStage']            = $roundName[$previousStage];
       $compareData['ToStage']              = $roundName[$currentStage];
       $compareData['Stage']                = $roundName[$currentStage];
       $compareData['UserRole']             = '';
       $compareData['ExcelFilePath']        = '';
        
        return $compareData;
    
   }
   
   
   public function revisionCompare($jobId, $currentStage, $metaId){
       
       $metadetails            =   array();
       $jobModelObj            =    new jobModel();
       $metadataObj            =    new taskLevelMetadataModel();
       $compareData            =    array();
       $jobDetails             =    $jobModelObj->getJobdetails($jobId);
       
       if(!empty($metaId)){
         $metadetails         =    $metadataObj->getMetadatadetailsChapter($metaId);
         $metadetails            =    $metadetailsRes['0'];
       }
       
       $jobsheetDetails        =    $this->jobSheetReturn($jobId, $currentStage, $jobDetails, $metadetails);
       
       $PrejobsheetDetails     =    $this->revisedjobSheetReturn($jobId, $currentStage, $jobDetails, $metadetails);
       $roundName                           = Config::get('constants.ROUND_NAME');
       $compareData['JS_Type']              = 'relavant';
       $compareData['BookId']               = $jobDetails->BOOK_ID;
       $compareData['ChapterNo']            = $jobDetails->CHAPTER_NO;
       $compareData['PreviousJobsheet']     = $PrejobsheetDetails;
       $compareData['CurrentJobsheet']      = $jobsheetDetails;
       $compareData['FromStage']            = $roundName[$currentStage];
       $compareData['ToStage']              = $roundName[$currentStage];
       $compareData['Stage']                = $roundName[$currentStage];
       $compareData['UserRole']             = '';
       $compareData['ExcelFilePath']        = '';
        return $compareData;
       
   }
   
   
    public function jobSheetReturn($jobId, $roundId, $jobDetails, $metadetails='' ) {
        $cmn_obj        =       new CommonMethodsController();
        $getlocationftp =       productionLocationModel::doGetLocationname($jobId);
        
        if (empty($getlocationftp))
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
            $getlocationftp->FTP_PASSWORD = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);

        $wheredata              = ['ROUND_ID' => $roundId];
        $getjobsheetpath        = jobsheetViewpathModel::active()->where($wheredata)->first();
        $jobsheetPath           = $getjobsheetpath['JOBSHEET_PATH'];
        
        $roundName              =   Config::get('constants.ROUND_NAME');
       
        if(!empty($metadetails)){
     
            $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                'ROUND_NAME' => $roundName[$roundId],
                'CID' => $metadetails->CHAPTER_NO
            );
            
        }else{
             $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                'ROUND_NAME' => $roundName[$roundId]
               );
            
        }
      
        $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
       
        //  echo "<pre>";print_r($serverDir);exit;
        $ftpObj = \Storage::createFtpDriver([
                    'host' => $getlocationftp->FTP_HOST,
                    'username' => $getlocationftp->FTP_USER_NAME,
                    'password' => $getlocationftp->FTP_PASSWORD, // 
                    'port' => '21',
                    'timeout' => '30',
        ]);
        
        $jobsheetJsPath   =     "";
        $serverDirFiles   =     $ftpObj->allFiles($serverDir);
        $jobsheetJsPath   =     $this->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
       
        return $jobsheetJsPath;
    }
    
    
    
    public function revisedjobSheetReturn($jobId, $roundId, $jobDetails, $metadetails='' ) {
        $cmn_obj        =       new CommonMethodsController();
        $getlocationftp =       productionLocationModel::doGetLocationname($jobId);
        
        if (empty($getlocationftp))
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
            $getlocationftp->FTP_PASSWORD = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);

        $wheredata              = ['ROUND_ID' => $roundId];
        $getjobsheetpath        = jobsheetViewpathModel::active()->where($wheredata)->first();
        $jobsheetPath           = $getjobsheetpath['JOBSHEET_PATH'];
        
        $roundName              =   Config::get('constants.ROUND_NAME');
       
        if(!empty($metadetails)){
            
            $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                'ROUND_NAME' => $roundName[$roundId],
                'CID' => $metaDetails->CHAPTER_NO
            );
            
        }else{
             $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                'ROUND_NAME' => $roundName[$roundId]
               );
            
        }
      
        $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
        $ftpObj             =       new ftpFileHandlerController($getlocationftp->FTP_HOST, $getlocationftp->FTP_USER_NAME , $getlocationftp->FTP_PASSWORD );
        $jobsheetJsPath     =     "";
     
        $serverDirFiles     =     $ftpObj->getDirectoryFiles($serverDir.'BACKUP/');
      
        if(!empty($serverDirFiles)){
             $rjspath            =     end($serverDirFiles);
             $serverDirFiles2   =     $ftpObj->getDirectoryFiles($rjspath);
             $jobsheetJsPath   =     $this->productionJobSheetPathReturn($serverDirFiles2,$getlocationftp);
        }
       
       
        return $jobsheetJsPath;
    }
    
    public function productionJobSheetPathReturn($serverDirFiles,$getlocationftp){
        $xmlFilePath    =   "";
        if (!empty($serverDirFiles)) {
            if (!empty($serverDirFiles)) {
                foreach ($serverDirFiles as $serverDirFile) {
                    $jobsheetpath = substr(strrchr($serverDirFile, "/"), 1);
                    if (pathinfo($serverDirFile)['extension'] == 'xml' && strpos(strtolower($jobsheetpath), 'jobsheet') !== false) {
                        $xmlFilePath = $serverDirFile;
                    }
                }
            }

            if (!empty($xmlFilePath)) {
                $xmlFilePath = str_ireplace($getlocationftp->FTP_PATH, '', '/' . $xmlFilePath);
                $xmlFilePath = '////' . $getlocationftp->FTP_HOST . '/' . $getlocationftp->FILE_SERVER_PATH . '/' . $xmlFilePath;
            }
            $xmlFilePath    =   str_replace("//", "/", $xmlFilePath);
        }
        return $xmlFilePath;
    }
    
    
      public function getXmlPath($jobId, $roundId, $jobDetails, $metadetails ) {
        $cmn_obj            =       new CommonMethodsController();
        $getlocationftp     =       productionLocationModel::doGetLocationname($jobId);
        
        if (empty($getlocationftp))
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
            $getlocationftp->FTP_PASSWORD = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
         
         $roundName         =       Config::get('constants.ROUND_NAME');
        
        $tapsDetails        =   DB::table('api_taps as tp')
                                ->where( 'tp.METADATA_ID'  , $metadetails->CHAPTER_NO )->select()->get();
     
        $pagingFilename    =    $jobDetails->BOOK_ID.'_BookFrontmatter';
        
        if(count($tapsDetails) == 0 && $roundId == '116'){
            $xmlPath      =   Config::get('constants.JS_COMPARE.NON_TAPS_XML_PATH');
        }else{
            $xmlPath      =   Config::get('constants.JS_COMPARE.TAPS_XML_PATH');
        }
        
        $filename     =   $jobDetails->BOOK_ID.'_BookFrontmatter.xml';
        if(!empty($metadetails)){
            
            $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                '{BID}' => $jobDetails->BOOK_ID,
                '{RID}' => $roundName[$roundId],
                'ROUND_NAME' => $roundName[$roundId],
                '{PAGING_FILENAMING}' => $pagingFilename,
                '{CID}' => $metadetails->CHAPTER_NO
            );
            
        }else{
             $inp_rep_arr = array(
                'BOOK_ID' => $jobDetails->BOOK_ID,
                '{BID}' => $jobDetails->BOOK_ID,
                 '{PAGING_FILENAMING}' => $pagingFilename,
                '{RID}' => $roundName[$roundId],
                'ROUND_NAME' => $roundName[$roundId],
               );
            
        }
        $serverDir = $prepared_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $xmlPath);
        
        return '//'.$getlocationftp->FTP_HOST.'/'.$serverDir.$filename;
        
       
       
        $ftpObj             =       new ftpFileHandlerController($getlocationftp->FTP_HOST, $getlocationftp->FTP_USER_NAME , $getlocationftp->FTP_PASSWORD );
        $jobsheetJsPath     =     "";
  
        $serverDirFiles     =     $ftpObj->getDirectoryFiles($serverDir);
       
        if(!empty($serverDirFiles)){
             $rjspath            =     end($serverDirFiles);
             $serverDirFiles2   =     $ftpObj->getDirectoryFiles($rjspath);
             $jobsheetJsPath   =     $this->productionJobSheetPathReturn($serverDirFiles2,$getlocationftp);
        }
       
       
        return $jobsheetJsPath;
    }
   
    
}
