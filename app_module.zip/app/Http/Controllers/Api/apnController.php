<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager;
use App\Models\jobStage;
use App\Models\apiApn;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiAutoPage;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\Api\schedulers\pageCountPaginationController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\workflow\workflowRuleController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\autostageController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class apnController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_apn';
    public $apiModel        =       'apiApn';
    
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
        
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        $job_id         =       $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metaidof   =   $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $cmn_obj                    =       new CommonMethodsController();
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , $this->tablename , 'TOKEN_KEY' );
        
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        	
        $extentionforapp            =       '3d';
        
        $job_inf_ob                 =       DB::select( 'SELECT APPLICATION FROM job_info WHERE JOB_ID = '.$job_id.' ORDER BY JOB_ID DESC LIMIT 1' );

        if( count( $job_inf_ob ) )	{

            $jobinf		=	$job_inf_ob[0];

            if( strtolower( $jobinf->APPLICATION ) == '3b2'  ){
                $extentionforapp		=	'3d';
            }

            if( strtolower( $jobinf->APPLICATION ) == 'indesign'  ){
                $extentionforapp		=	'indd';
            }

            if( strtolower( $jobinf->APPLICATION ) == ''  ){
                $extentionforapp		=	'';
            }

        }

        $returnstr      		=       $this->getAllChapterInformationTags( $job_id , $metaidof , $jbstg_rec , $getlocationftp );
         
		 
		$metadataid			    =		$this->getApnFailureMetaid( $job_id  , $metainfo['round']  );
		 
	    $chapter_arr         	=       taskLevelMetadataModel::select( DB::raw( 'task_level_metadata.*,metadata_info.*' ) )
											->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
											->where('task_level_metadata.METADATA_ID', $metadataid )
											->get()->first();    
											
											
		$resumepagenofrom    	=   	'';
		$resumecompoat			=		'';
		
		if( !empty( $chapter_arr ) ){
			
			$chapter_arr         =       taskLevelMetadataModel::select( DB::raw( 'task_level_metadata.*,metadata_info.*' ) )
											->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID' )
											->where( 'task_level_metadata.CHAPTER_SEQ' ,  intval( $chapter_arr['CHAPTER_SEQ'] - 1 ) )
											->where( 'task_level_metadata.JOB_ID' , $job_id )
											->get()->first();
											
			if( ( intval( $chapter_arr['CHAPTER_SEQ'] ) - 1 ) <= 0 ){	
				$resumepagenofrom			=			1;
			}else{
				$resumepagenofrom			=		intval( $chapter_arr['END_PAGE'] )+1;
			}
			
			$resumecompoat  				= 		$metadataid ;
			
		}
			
        if( $returnstr ){
            $jsonstr    =       json_encode( array(  'apn_chapter_info' => $returnstr , 'apln_ext' => $extentionforapp  , 'resumepagenofrom' => $resumepagenofrom , 'resumecompoat' => $resumecompoat ) );
            $this->assignAdditonalOptionToMetaInfo( $jsonstr );        
        }
        
		
        return  $this->metainfo;
        
    }
    
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){

       if( isset( $optional_param_json ) ){
           if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
               $addionalParam      =       json_decode( $optional_param_json );
               
               if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                   
                   $autopageInput      =       (array)$addionalParam; 
                   $exitsing_meta      =        $this->metainfo;

                   foreach( $addionalParam as $key => $value ){          
                        $this->metainfo[ $key ]     = $value;                              
                   }
                
               }
           }
       }

   }     
    
	public function getApnFailureMetaid( $jobid , $roundID ){
	
	 
        $componentSupport   =       array( 
                                        \Config::get('constants.FM_ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_CHAPTER') , 
                                        \Config::get('constants.ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_PART') , 
                                    ); 
        
        
        $chapter_arr         =       taskLevelMetadataModel::select( DB::raw('task_level_metadata.*,metadata_info.*') )
                                        ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                        ->where('task_level_metadata.JOB_ID',$jobid)
										->where( 'task_level_metadata.UNIT_OF_MEASURE', 70 )
                                        ->whereIn('metadata_info.FM_ARTICLE_BM', $componentSupport  )
                                        ->orderBy('task_level_metadata.CHAPTER_SEQ' , 'asc' )
                                        ->get();    
        
        $return_str           =       ''; 
          
        $autoPgeContObj     =       new autoPageController();
        $cmn_obj     =      new CommonMethodsController();
        $apnStage    =      \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN');
        $manuapgeStage    =      \Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION');
        $pgeCountPagiObj	=	new pageCountPaginationController();
		
       if( count( $chapter_arr ) ){
           
           $return_str      = false;
           
           foreach( $chapter_arr as $index => $value  ){               
		   
               $metaid          =       $value->METADATA_ID;               
		      
			   $holdStatus  =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORCHAPTERSCOMPLETION' );
               $inprog      =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
               $availe      =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.AVAILABLE' );
               $complete    =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.COMPLETED' );
               
			   $sqlSmt         =   " SELECT tlmd.* from task_level_metadata tlmd LEFT JOIN job_round jr "
                                    . " ON tlmd.METADATA_ID = $metaid AND tlmd.METADATA_ID = jr.METADATA_ID AND tlmd.CURRENT_ROUND = $roundID AND jr.IS_ART IS NULL "
                                    . " LEFT JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                                    . " WHERE tlmd.METADATA_ID = $metaid AND jr.ROUND_ID = $roundID AND js.STAGE_ID = $apnStage AND js.STATUS IN ( $inprog , $holdStatus )"
                                    . " ORDER by js.JOB_STAGE_ID DESC LIMIT 1 ";
              
			  $queryReturns   =   DB::select( $sqlSmt );
               
				if( count( $queryReturns ) == 0){
					
					$retrun   =  $pgeCountPagiObj->updatePageCountInformationOnDemand( $metaid , $roundID );
					
                }else{
					
					$retrun   =  $pgeCountPagiObj->updatePageCountInformationOnDemand( (intval( $queryReturns[0]->METADATA_ID ) - 1) , $roundID );
					
					if( isset(  $queryReturns[0]->METADATA_ID  ) ){
						return (  $queryReturns[0]->METADATA_ID );
					}else{
						return false;
					}
					
				}
               
           }
           
           if( empty( $return_str ) ){
               return false;               
           }
           
       }else{
           
           return false;
           
       }
       
       return $return_str;
	}
	
    public function getAllChapterInformationTags( $jobid , $metaidin , $jbstg_rec , $getlocationftp ){
        
        $componentSupport   =       array( 
                                        \Config::get('constants.FM_ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_CHAPTER') , 
                                        \Config::get('constants.ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_PART') , 
                                    ); 
        
        
        $chapter_arr         =       taskLevelMetadataModel::select( DB::raw('task_level_metadata.*,metadata_info.*') )
                                        ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                        ->where('task_level_metadata.JOB_ID',$jobid)
										->where( 'task_level_metadata.UNIT_OF_MEASURE', 70 )
                                        ->whereIn('metadata_info.FM_ARTICLE_BM', $componentSupport  )
                                        ->orderBy('task_level_metadata.CHAPTER_SEQ' , 'asc' )
                                        ->get();    
        
        $return_str           =       ''; 
          
        $autoPgeContObj     =       new autoPageController();
        $bookId      =       $jbstg_rec->BOOK_ID;
        $rouundid    =      $jbstg_rec->ROUND_ID;
        
        $cmn_obj     =      new CommonMethodsController();
        $apnStage    =      \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN');
       
       if( count( $chapter_arr ) ){
           
           $return_str      = '';
           
           foreach( $chapter_arr as $index => $value  ){
               
               $chatperId       =       $value->CHAPTER_NO;
               $metaid          =       $value->METADATA_ID;
               $paginginfo      =       $autoPgeContObj->getPagingFileNameing( $bookId , $chatperId , $metaid );
               $pagingfilnaming =       '';
               $chapnoonly      =       preg_replace( '/\D/', '', $chatperId );
               
                if( !strpos( strtoupper( $chatperId ) , 'CHAPTER' ) ){
                    $chapnoonly =   $chatperId;
                }
                
               extract( $paginginfo );
               $roundID   =       $rouundid;
               
               $cno         =       '';
               $ctitle      =       $value->CHAPTER_NAME;
               $cseq        =       $value->CHAPTER_SEQ;
               $holdStatus  =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORCHAPTERSCOMPLETION' );
               $inprog      =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
               
                $sqlSmt         =   " SELECT tlmd.* from task_level_metadata tlmd LEFT JOIN job_round jr "
                                    . " ON tlmd.METADATA_ID = $metaid AND tlmd.METADATA_ID = jr.METADATA_ID AND tlmd.CURRENT_ROUND = $roundID AND jr.IS_ART IS NULL "
                                    . " LEFT JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                                    . " WHERE tlmd.METADATA_ID = $metaid AND jr.ROUND_ID = $roundID AND js.STAGE_ID = $apnStage AND js.STATUS IN ( $inprog , $holdStatus )"
                                    . " ORDER by js.JOB_STAGE_ID DESC LIMIT 1 ";
                       
                $queryReturns   =   DB::select( $sqlSmt );
               
                if( count( $queryReturns ) == 0){
                   // continue;
                }
                
               $comptype    =       'chapter';
               
               //LATE CORRECTION PATH CHANGE LOGIC NEED TO WRITE
               $apn_path    =       \Config::get('constants.APN_PROCESS_APP_PATH');
               $apndesti    =       \Config::get('dynamicConstant.APNBGSETUP.APN_PROCESS_DESTINATION_PATH');
              
               $roundname   =       \Config::get('constants.ROUND_ID.118');
               $roundarr    =       \Config::get('constants.ROUND_ID');
               $serverip    =       $getlocationftp->FTP_HOST;
               $rootdir     =       $getlocationftp->FILE_SERVER_PATH;
               
               $inp_rep_arr            =    array(
                                                '{BID}' => $bookId , '{RID}' => $roundarr[$roundID] , '{RNAME}' =>  $roundarr[$roundID] ,
                                                '{CID}' => $chatperId , '{PAGING_FILENAMING}' => $pagingfilnaming , 
                                                '{CNO}' => $chapnoonly , 
                                                '{SIP}' => $serverip , '{RDIR}' => $rootdir  ,
                                                '{APNFINDROUND}' => $roundname ,
                                            );
               
               $call_urlo           =       \Config::get('constants.BASE_URL').'api/initiateOnlineDpFilePost/'.$metaid.'/'.$rouundid;
               $call_urlp           =       \Config::get('constants.BASE_URL').'api/initiatePrintDpFilePost/'.$metaid.'/'.$rouundid;
               
               $apn_path            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $apn_path );
               $apn_path            =       $cmn_obj->backslashPathPrepare( $apn_path , true );
               $apndesti            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $apndesti );
               $apndesti            =       $cmn_obj->backslashPathPrepare( $apndesti , true );
               
               $tempContentFormat   =       '<ChapterInfo id="'.$metaid.'">
                                                <Chapter_Number>'.$chapnoonly.'</Chapter_Number>
                                                <Chapter_Name>'.addslashes($ctitle).'</Chapter_Name>
                                                <ChapterID>'.$metaid.'</ChapterID>
                                                <StartPage>0</StartPage>
                                                <EndPage>0</EndPage>
                                                <ChapterOrder>'.$cseq.'</ChapterOrder>
                                                <chapter_type_description>'.$comptype.'</chapter_type_description>
                                                <ChapterDispFormat>C</ChapterDispFormat>
                                                <FileInfo>
                                                  <ApplicationProcess>'.$apn_path.'</ApplicationProcess>
                                                  <ApplicationServer>'.$apndesti.'</ApplicationServer>
                                                </FileInfo>
                                                <onlinePDF>'.$call_urlo.'</onlinePDF>
                                                <printPDF>'.$call_urlp.'</printPDF>
                                            </ChapterInfo>'.PHP_EOL;
               
               $return_str  .=  $tempContentFormat;
               
           }
           
           if( empty( $return_str ) ){
               return false;               
           }
           
       }else{
           
           return false;
           
       }
       
       return $return_str;
        
    }
   
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function validateApnProcessTrigger( $jbstgid ){
        
        //Steps
        
        // 1) checking other activities completed and ready for apn process initialization
        // 2) Otherwise hold on aproach  
        // 3) if OK or hold on state means inprogress and retrigger
        
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jbstgid);
        
        if(count($stageDetails) == 0){
            return false;
        }
        
        $jbstg_rec      =       $stageDetails[0];
        $jobid          =       $job_id         =       $jbstg_rec->JOB_ID;        
        $stageid        =       $jbstg_rec->STAGE_ID;
        $round          =       $jbstg_rec->ROUND_ID;
        $metaid         =       $jbstg_rec->METADATA_ID;
        $jbrnd_id       =       $jbstg_rec->JOB_ROUND_ID;
        $releaseStatus  =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORCHAPTERSCOMPLETION' );
        $getRecords     =       $this->getAllNormalComponentCurrentStatus( $jobid , $round , $metaid );
       
        if( !empty( $getRecords ) ){
            
            $recordFind     =       array_unique( array_values( $getRecords ) );
            
            if( count( $recordFind ) > 1 ){
                
            }
            
            if( count( $recordFind ) == 1 ){
                
                if( $recordFind[0] == $releaseStatus ){
                    return true;
                }
                
            }
            
        }else if( empty( $getRecords ) ){
            return true;
        }
        
        if( !empty( $releaseStatus ) ){
            
            $updateQry1             =       "UPDATE job_stage SET STATUS = $releaseStatus WHERE job_stage_id = $jbstgid limit 1";
            $updateQry2             =       "UPDATE job_round SET STATUS = $releaseStatus WHERE job_round_id = $jbrnd_id limit 1";
            $update_queryStatus     =        DB::update( $updateQry1 );
            $update_queryStatus     =        DB::update( $updateQry2 );
            
            return false;
        }
        
        return false;
        
    }
    
    public function getAllNormalComponentCurrentStatus( $jobid , $round , $cur_metaid ){
        
        $tsklvlObj          =       new taskLevelMetadataModel();
        
        $componentSupport   =       array( 
                                        //\Config::get('constants.FM_ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_CHAPTER') , 
                                        \Config::get('constants.ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_PART') , 
                                    ); 
        
        //$metainfos      =       $tsklvlObj->getAllChapterBasedOnComponentInfo( $jobid , 2 );
        $metainfos      =       $tsklvlObj->getAllChapterBasedOnComponentInfo( $jobid , $componentSupport );
       
        $jbstg          =       new jobStage();
        $statusI        =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
        $returnstatus   =       array();
        $apnStage       =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN' );
        
        if( !empty( $metainfos ) ){
            
            foreach (  $metainfos as $index => $arrayInput ){
                
                if( $arrayInput->CURRENT_ROUND == $round ){
                    
                    $loopmetaid     =   $arrayInput->METADATA_ID;
                    
                    if( $cur_metaid == $loopmetaid ){
                        continue;
                    }

                        $sqlSmt         =   " SELECT js.* from task_level_metadata tlmd LEFT JOIN job_round jr "
                            . " ON tlmd.METADATA_ID = $loopmetaid AND tlmd.METADATA_ID = jr.METADATA_ID AND tlmd.CURRENT_ROUND = $round AND jr.IS_ART IS NULL "
                            . " LEFT JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                            . " WHERE tlmd.METADATA_ID = $loopmetaid AND jr.ROUND_ID = $round AND js.STAGE_ID = $apnStage AND js.STATUS !=24 "
                            . " ORDER by js.JOB_STAGE_ID DESC LIMIT 1 ";
               
                        $queryReturns   =   DB::select( $sqlSmt );
                        
                        if( count( $queryReturns ) ){
                            $recordsRs                  =       $queryReturns[0];
                            $returnstatus[$loopmetaid]  =       $recordsRs->STATUS;
                        }
                        
                }else{
                    //if incase other rounds check logic present
                    
                }
                
            }
            
        }
       
        return $returnstatus;
        
    }
    
    public function startProcess( $jbstgid ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        
        $valid_trigger  =       $this->validateApnProcessTrigger( $jbstgid );
        
        if( !$valid_trigger  ){
            //stop propagation of APN
            echo json_encode( array( 'status' => 1 , 'msg' => 'Success' , 'errMsg' => 'Waiting for other component completion'));
			exit;
        }
        
        $this->customConstructor( $jbstgid );
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
         
        try{
            
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
           
            $watchPath      =       $this->getWatchFolderPath( $path );
            
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoStageMeta( $jbstgid );
           
            $metafileInput['metafilename']      =   $this->getMetafilename();
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input   =       array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
            
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
        }catch( \Exception $e ){
          
            $response['status']     =       0;
            $response['Msg']        =       'failed';
            $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
            $err_handle             =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
        }
        
        return json_encode( $response );
        
    }
    
    public function getMetafilename(){
        
        extract(  $this->metainfo );
        $roundarr    =       \Config::get('constants.ROUND_ID');
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $iteration          =        0;
        $reccount           =        DB::select('select job_id from api_apn where JOB_ID='.$jobid );
        
        if( count( $reccount ) ){
            $iteration      =       count( $reccount );
        }
        
        $cmn_obj            =        new CommonMethodsController();
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
        $filename           =        $bookid.'@'."$iteration".'@'.$metaid.'.xml';

        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.APN_PROCESS');
          
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
            
                $watchPath          =       $path['detail'];
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                $empdir        =   Session::get('users')['emp_id'];  
                //remove user directory 
                $workpath           =       str_replace(  $empdir , '', $workpath);
                $workpath           =       str_replace('//', '', $workpath);
               
            }
        
        }
        
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

        $cmn_obj                    =       new CommonMethodsController();
        $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
        if( is_array( $ftpobj )  ){
            $ftpobj 		=	$ftpobj['ftpInfo'];
        }
	   
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
       $errorstr           =            '';
      
       //echo '<pre>';
       //echo $whereToWrite;
       //exit;
       //echo htmlspecialchars($getMetaFormat);
       //exit;
       
       $atoStgObj          =            new autostageController();
       $postMetaStatus     =            $atoStgObj->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){
           
           $this->updateOtherChaptersStatus( $api_tbl_input['JOB_ID'] , $api_tbl_input['ROUND'] ,  $api_tbl_input['METADATA_ID'] );
           
           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           $insert_ret                     =       apiApn::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiApn::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

        return json_encode( $response );
        exit;
        
   }

    public function prepareAutoStageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid );
        $preparedXml        =       '';    

        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );

                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
    
    public function getArtMetaDataTags( $jbstgid ){
        
        $xmlStr     =   '<ArtMetaData>';
       
            extract( $this->metainfo );            
            $getartfigure       =       DB::table( 'task_level_art_metadata' )
                                            ->whereIn( 'METADATA_ID' , array( $metaid )  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();   

            $xmlStr         .=          app('App\Http\Controllers\artProcess\artProcessController')->prepareFigureTags( $getartfigure );
            $xmlStr        .=          '</ArtMetaData>';
         
        return $xmlStr;
        
    }
      
    public function replaceRequireKeysToValues( $xmlStr ){
        
        $cmn_obj             =       new CommonMethodsController();
        $inp_rep_arr         =      $this->getRequiredReplacables();
        $xmlStr     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlStr );
        return $xmlStr;
    }
    
    public function updateOtherChaptersStatus( $jobid , $round , $metaid ){
        
        $apnStage       =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN' );
        $statusw        =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.WAITINGFORCHAPTERSCOMPLETION' );
        $statusi        =       \Config::get( 'constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS' );
        
        $stmt_qury      =   "SELECT js.* from task_level_metadata tlmd LEFT JOIN job_round jr
                            ON tlmd.JOB_ID = $jobid AND tlmd.METADATA_ID = jr.METADATA_ID AND tlmd.CURRENT_ROUND =  $round  AND jr.IS_ART IS NULL 
                            LEFT JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND jr.CURRENT_ITERATION_ID = js.ITERATION_ID 
                            WHERE tlmd.JOB_ID = $jobid AND jr.ROUND_ID = $round AND js.STAGE_ID = $apnStage AND js.STATUS = $statusw 
                            ORDER by js.JOB_STAGE_ID DESC ";
        
        $qry_rs         =   DB::select( $stmt_qury );
        $totrec         =   count( $qry_rs );
        
        if( $totrec ){
           
            foreach( $qry_rs as $keyi  =>  $valuei ){
                
                $jbstsgid   =   $valuei->JOB_STAGE_ID;
                $jbrndid    =   $valuei->JOB_ROUND_ID;
                
                if( !empty( $jbstsgid ) ){
                    $status_s       =   DB::update( "update job_stage set status = $statusi where job_stage_id = $jbstsgid limit 1" );
                }
                
                if( !empty( $jbrndid ) ){
                    $status_r       =   DB::update("update job_round set status = $statusi where job_round_id = $jbrndid limit 1");
                }
                
                
            }
            
        }
        
        
    }
    
    public function storeResponse( $inputarr , &$response ){
        
        $response['status']         =       1;
        $response['msg']            =       'Successw';
        $response['errMsg']         =       'Signal received successfully...';   
        $response['params']         =       'Am under testing mode';   
        
        //return true;
        
        extract( $inputarr );
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
     
        $jbstgObj                   =       new jobStage();
       
        $sqlSmt             =   " SELECT * from task_level_metadata tlmd left join job_round jr "
                                    . " on tlmd.METADATA_ID = $metaid and tlmd.METADATA_ID = jr.METADATA_ID and tlmd.CURRENT_ROUND = $round and jr.IS_ART IS NULL "
                                    . " left join job_stage js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                                    . " where tlmd.METADATA_ID = $metaid and jr.ROUND_ID = $round and js.`STATUS`  in (23,76) "
                                    . " order by js.JOB_STAGE_ID DESC LIMIT 1 ";
        
        $getCurrnt_stage     =    DB::select( $sqlSmt );
		
		$insQry = "insert into cron_fetchpagecount ( METADATA_ID , ROUND , STATUS  ) values ( '$metaid','$round',0 )";
       
		
        //$getCurrnt_stage            =       $jbstgObj->getCurrentJobStageInfo( $metaid , $round , 23  );
        
        if( count( $getCurrnt_stage ) ){
            
            $jbstgInfo			=       $getCurrnt_stage[0];
            $job_round_id		=		$jbstgInfo->JOB_ROUND_ID;
            $jobStageId         =		$jbstgInfo->JOB_STAGE_ID;
            $checkoutObj        =       new checkoutModel();
            $stageDetails       =       $checkoutObj->getStageInfo( $jobStageId );
            
            if( $status == 2 ){
				
                 DB::insert($insQry);
				 
                if( count( $getCurrnt_stage ) ){

                    if(count($stageDetails)>=1){

                        $stageData              =   $stageDetails['0'];    
                        $jobRoundId             =   $stageData->JOB_ROUND_ID;
                        $roundId                =   $stageData->ROUND_ID;
                        $stageSequence          =   $stageData->STAGE_SEQ + 1;
                        $workflowId             =   $stageData->WORKFLOW_ID;  
                        $iteration              =   $stageData->ITERATION_ID;
                        $jobId                  =   $stageData->JOB_ID;
                        $stageId                =   $stageData->STAGE_ID;
                        $metadataId             =   $stageData->METADATA_ID;
                        $outputQuantity         =   $stageData->OUTPUT_QUANTITY;
                        $inputQuantity          =   $stageData->INPUT_QUANTITY;

                        $stageManagerContObj    =   new stageMangerController();  
                        $nexstageDetails        =   $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId); 
                        
                        if(!empty($nexstageDetails)){ 
                           $moveStageResponse = $stageManagerContObj->moveNextStage( $stageDetails['0'] , 0 );                           
                        }else{
                           $moveStageResponse1 = $stageManagerContObj->finalStage($jobStageId, $stageDetails['0'] ); 
                           $moveStageResponse['status'] = 'success'; 
                        }

                    }

                    if( $moveStageResponse['status'] == 'success' ){
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal received successfully..., stagemovement done';  
                    }

                }
            }

            if( $status == 3 ){

                // Rollback the stage
                // Jobstageid require for this process 
                // Rule based rolback should handle here.
                $wrkflwruleObj          =       new workflowRuleController();   

                //check wheather this nextstage available as per rule or overwrite the nextstage variable
                $gotostage              =       $wrkflwruleObj->getWorkflowRuleBasedJobStageAvail( $jobStageId , 1 );

                if( $gotostage ){
                    
                    $stgMgObj        =       new stageMangerController();
                    $remarks         =       @$inputarr['remarks'];
                    $stgMgObj->stageRollBack( $jobStageId , $gotostage , $remarks );

                    $response['status']         =       1;
                    $response['msg']            =       'Success';
                    $response['errMsg']         =       'Signal received successfully..., stage rollback done';   

                }

            }

        }
        
    }
    
}