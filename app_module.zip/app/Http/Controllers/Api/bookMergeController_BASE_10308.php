<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiReferencePdfModel;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiBookMergeModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Models\jobsheetViewpathModel;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\Api\pitstopController;
use App\Http\Controllers\artProcess\artProcessController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class bookMergeController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_bookMerge';
    public $apiModel        =       'apiBookMergeModel';
    public  $common_obj;
    public function __construct()
    {
        $this->cmn_obj      =       new CommonMethodsController();
    }
    public function customConstructor( $jobStageId ){ 
       
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
       
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['roundname']      =       \Config::get('constants.ROUND_ID')[$jbstg_rec->ROUND_ID];
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        $metainfo['issnPrint']      =       $jbstg_rec->ISSN_PRINT;
        
        $metainfo['book_merge_tags'] =       1;
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD ); 
        $this->ftpInfo              =       $getlocationftp;
        $this->tokenkey             =       $this->cmn_obj->generateRandomString( 16 , 'api_bookMerge' , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $metainfo['location']       =       $getlocationftp;
        $this->metainfo             =       $metainfo;
        
	$made_inp           =   array( 'jobsheetpath' => '' , 'pdfpath' =>'' );
        
	$this->assignAdditonalOptionToMetaInfo(  $made_inp  );
       
        return  $metainfo;
        
    }
	
    public function assignAdditonalOptionToMetaInfo( $optional_param_json, $return=0 ){
       
      if(!empty($optional_param_json)){
         $getlocationftp = $this->metainfo['location'];
        
          $ftpObj = \Storage::createFtpDriver([
                    'host' => $getlocationftp->FTP_HOST,
                    'username' => $getlocationftp->FTP_USER_NAME,
                    'password' => $getlocationftp->FTP_PASSWORD, // 
                    'port' => '21',
                    'timeout' => '30',
        ]);
           $roundName         = $this->metainfo['roundname'];
          
          foreach($optional_param_json as $key => $value){
            
              if($key  == 'jobsheetpath'){
                   $revisedObj   =  new jobrevisedController();
                   $wheredata = ['ROUND_ID' => $this->metainfo['round']];
                    $getjobsheetpath = jobsheetViewpathModel::active()->where($wheredata)->first();
                    $jobsheetPath = $getjobsheetpath['JOBSHEET_PATH'];
                  
                    $inp_rep_arr = array('BOOK_ID' => $this->metainfo['bookid'],'ROUND_NAME' => $this->metainfo['roundname']);

                    $serverDir = $prepared_path = $this->cmn_obj->arr_key_value_replace($inp_rep_arr, $jobsheetPath);
                    
                    $serverDirFiles = $ftpObj->allFiles($serverDir);
                   
                    $jobsheetpath  =   $revisedObj->productionJobSheetPathReturn($serverDirFiles,$getlocationftp);
                    $jobsheetpath        =   str_replace( '/' , '\\'  , $jobsheetpath );
                    
                    $this->metainfo[$key] = $jobsheetpath;
                    
                    if($return == 1){
                        return $jobsheetpath;
                    }
              }
              
              if($key == 'pdfpath'){
                  
                  $strPrint = '';
                   $tasklevelMetadataModel           =      new taskLevelMetadataModel();
                   $getJobChapters                    =   $tasklevelMetadataModel->getMetadatadetailsJob($this->metainfo['jobid']);
              
                    $autoPgeContObj     =   new autoPageController();
                   $serverDetails       =  $this->metainfo['location'];
                   $bookatt             =   array('online','print','mycopy','scopy');
                   foreach($bookatt as $booktype){
                       $str = '';
					   $str2 = '';
                       if($booktype  == 'online'){
                           $paginfile  = 'OnlinePDF';
                            foreach($getJobChapters as $key2 => $chData){
                                $chapterNumber  = $chData->CHAPTER_NO;
                                $metaId         = $chData->METADATA_ID;
                                $bookId         = $this->metainfo['bookid'];
                                 $paginginfo    = $autoPgeContObj->getPagingFileNameing( $bookId , $chapterNumber ,$metaId );

                                 $bookSrcpath   = \Config::get('constants.BOOK_MERGE_SRCPATH'); 
                                 $inp_rep_arr   = array('{BID}' => $this->metainfo['bookid'],'{RID}' => $roundName,'{CID}' => $chapterNumber );

                                 $prepared_path      =   $this->cmn_obj->arr_key_value_replace($inp_rep_arr, $bookSrcpath);

                                 if($chData->FM_ARTICLE_BM == '5'){
                                 $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.'Cover/Cover_FC.pdf';
								 
								  $chapterPath        =   str_replace( '/' , '\\'  , $chapterPath );                      

                                 $str2  = '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
								 
                                 }else{
                                   $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.$paginginfo['pagingfilnaming'].'_'.$paginfile.'.pdf'; $chapterPath        =   str_replace( '/' , '\\'  , $chapterPath );                      

                                 $str  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';  
                                 }
                                

                             /*    if($chData->FM_ARTICLE_BM != '5'){

                                     $strPrint  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
                                 }*/
                        
                             }
                          if(!empty($str2)){
							
							$str5  = $str;
							$str	= '';
							$str  .=$str2;
							$str  .=$str5;
						  }
                        $this->metainfo[$booktype] = $str;
                           
                       }
                      
                       if($booktype  == 'print'){
                           $paginfile  = 'PrintPDF';
                            foreach($getJobChapters as $key2 => $chData){
                                $chapterNumber  = $chData->CHAPTER_NO;
                                $metaId         = $chData->METADATA_ID;
                                $bookId         = $this->metainfo['bookid'];
                                 $paginginfo    = $autoPgeContObj->getPagingFileNameing( $bookId , $chapterNumber ,$metaId );

                                 $bookSrcpath   = \Config::get('constants.BOOK_MERGE_SRCPATH'); 
                                 $inp_rep_arr   = array('{BID}' => $this->metainfo['bookid'],'{RID}' => $roundName,'{CID}' => $chapterNumber );

                                 $prepared_path      =   $this->cmn_obj->arr_key_value_replace($inp_rep_arr, $bookSrcpath);

                                 if($chData->FM_ARTICLE_BM != '5'){
                                 $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.$paginginfo['pagingfilnaming'].'_'.$paginfile.'.pdf';  
                                 
                                 $chapterPath        =   str_replace( '/' , '\\'  , $chapterPath );                      

                                 $str  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
                                 
                                 
                                 }
                                                   
                             }
                             
                        $this->metainfo[$booktype] = $str;
                           
                       }
                       
                       if($booktype  == 'mycopy' || $booktype  == 'scopy'){
                           $paginfile  = 'PrintPDF';
                            foreach($getJobChapters as $key2 => $chData){
                                $chapterNumber  = $chData->CHAPTER_NO;
                                $metaId         = $chData->METADATA_ID;
                                $bookId         = $this->metainfo['bookid'];
                                 $paginginfo    = $autoPgeContObj->getPagingFileNameing( $bookId , $chapterNumber ,$metaId );

                                 $bookSrcpath   = \Config::get('constants.BOOK_MERGE_SRCPATH'); 
                                 $inp_rep_arr   = array('{BID}' => $this->metainfo['bookid'],'{RID}' => $roundName,'{CID}' => $chapterNumber );

                                 $prepared_path      =   $this->cmn_obj->arr_key_value_replace($inp_rep_arr, $bookSrcpath);

                                 if($chData->FM_ARTICLE_BM != '5'){
                                     
                                 if($chData->FM_ARTICLE_BM == '1'){    
                                     $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.$paginginfo['pagingfilnaming'].'_MyCopyPDF.pdf';  
                                 }else{
                                     $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.$paginginfo['pagingfilnaming'].'_'.$paginfile.'.pdf';  
                                 }
                                 $chapterPath        =   str_replace( '/' , '\\'  , $chapterPath );                      

                                 $str  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
                                 
                                 
                                 }
                                                   
                             }
                             
                        $this->metainfo[$booktype] = $str;
                           
                       }
                   }
                 /*  foreach($getJobChapters as $key2 => $chData){
                      
                       $chapterNumber  = $chData->CHAPTER_NO;
                       $metaId         = $chData->METADATA_ID;
                       $bookId         = $this->metainfo['bookid'];
                        $paginginfo    = $autoPgeContObj->getPagingFileNameing( $bookId , $chapterNumber ,$metaId );
                        
                        $bookSrcpath   = \Config::get('constants.BOOK_MERGE_SRCPATH'); 
                        $inp_rep_arr   = array('{BID}' => $this->metainfo['bookid'],'{RID}' => 'S600','{CID}' => $chapterNumber );
                
                        $prepared_path      =   $this->cmn_obj->arr_key_value_replace($inp_rep_arr, $bookSrcpath);
                        
                        if($chData->FM_ARTICLE_BM == '5'){
                        $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.'Cover/Cover_FC.pdf';
                        }else{
                          $chapterPath        =  '//'.$serverDetails->FTP_HOST.$serverDetails->FILE_SERVER_PATH.$prepared_path.$paginginfo['pagingfilnaming'].'.pdf';  
                        }
                        $chapterPath        =   str_replace( '/' , '\\'  , $chapterPath );                      
                       
                        $str  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
                        
                        if($chData->FM_ARTICLE_BM != '5'){
                            
                            $strPrint  .= '<PdfFile ChapterNumber="'.$chapterNumber.'" path="'.$chapterPath.'" />';
                        }
                        
                   }*/
                 
              }
              
          }
        
      }
        
    }     
    
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        ($inputarr['status']   ==  1?'2':'3');
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess($jbstgid ){
        
       
        if(!empty($jbstgid))
        {
            $response           =   array();
            $watchPath          =   '';
            $wrkflwMapPath      =   new workflowServerMapPathModel();
            $this->customConstructor( $jbstgid );
            $metainfo           =   $this->metainfo;
           
            $this->metainfo =       $metainfo;
            extract( $metainfo );
            //try{
                $platform       =   '3b2';
                $path           =   $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
               
                $watchPath      =   $this->getWatchFolderPath( $path );
                $ftpDefault     =   $this->ftpInfo;
                
                $content        =   $this->prepareAutoPageMeta( $jbstgid , $platform ,null );
                
                $metafileInput['metafilename']      =   $this->getMetafilename();
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();
                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
				
                $returnresponse     =   $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
                if(isset($returnresponse['status']) && $returnresponse['status'] == 1){
                    $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobid,$round,'insert',$jbstgid);
                }

           /* }catch( \Exception $e ){

                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
            }*/
        }else{
            $response['status']     =   0;
            $response['Msg']        =   'failed';
            $response['errMsg']     =   'No data found';
        }
        return response()->json( $response );
    }
    
    public function getMetafilename(){
        extract(  $this->metainfo );
        $inp_rep_arr    =       array(  
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_{TKEY}_bookmerge.xml';
        return $this->cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
    }
    
    public function getWatchFolderPath( $path ){
        
       
        if( !empty(  $path['workingpathCredential'] ) ){    
            $recServer  =   $path['workingpathCredential'];
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =   (object)$cr_data; 
            $this->ftpInfo              =   $metaPostInfo['ftpInfo'];
            if( !empty( $path['detail'] ) ){
                $watchPath              =   $path['detail'];
                $workpath               =   str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath               =   str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                $workpath               =   preg_replace('/[0-9]/', '', $workpath);
                $workpath               =   str_replace('//', '', $workpath);
            }
        }
         $workpath       =   Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_BOOK_MERGE');
        
        return $workpath;
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){
        
        $ftpobj                     =   $metaFileInput['ftpInfo']; 
        $ftpInfo['HOST']            =   $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =   $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =   $ftpobj->FTP_PASSWORD;
        $filename                   =   $metaFileInput['metafilename'];
        $whereToWrite               =   $metaFileInput['watch_folder'];
        
        $callBookService            =  \Config::get('constants.BOOK_BUILDING_WEB_URL').'?xmlFileName='.$filename; 
      
        $getMetaFormat              =   $this->cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
	   
        $errorstr                   =   '';
        
        $postMetaStatus             =   app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
       
        
        $callBookUrl                =   $this->cmn_obj->getcUrlExecution($callBookService,0); 
        
         Log::useDailyFiles( storage_path().'/Api/bookmergeSignal.log' );
         
         Log::info($callBookService.'||'.$callBookUrl);
        
        if( !$postMetaStatus ){
            $response['errMsg']     =   'File posted to WatchFolder got Failed';
        }

        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $insert_ret                     =   apiBookMergeModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   1;
                $response['msg']            =   'Success';
                $response['errMsg']         =   'Meta Posted Successfully to Watchfolder';
                
                
            }else{
                $response['status']         =   0;
                $response['errMsg']         =   'api table Record insertion failed';
            }
            return $response;
        }else{

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $api_tbl_input['END_TIME']      =   date('Y-m-d H:i:s');
            $api_tbl_input['STATUS']        =   3;
            $api_tbl_input['REMARKS']       =   $errorstr;

            $insert_ret                     =   apiBookMergeModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   0;
                $response['msg']            =   'Failed';
                $response['errMsg']         =   $response['errMsg'];
                return $response;
            }else{
                $response['status']         =   0;
                $response['errMsg']         =   'api table Record insertion failed';
            }
        }

       return false;

   }

    public function prepareAutoPageMeta( $jbstageid , $platform = '3b2' , $type = null){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
      
        $preparedXml        =       '';  
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );
                
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    //var_dump( $bgprocess );
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();   
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        return $xmlStr;
    }
    
    public function prepareSourceDestFileTags($input_rec, $returns   =   'xml',$typeofdoc){
        $figure_arr     =   array();
        $figure_str     =   '';
        $figure         =   '';
        
     
        if(isset($input_rec['chapter_info_data']) && count($input_rec['chapter_info_data'])>=1){
            if($typeofdoc     ==  "source")
            {
                foreach( $input_rec['chapter_info_data'] as $key => $value ){
                    $replaceslash           =   $this->cmn_obj->backslashPathPrepare($value,true);
                    if( $returns == 'xml' ){
                        
                        $figure_str         .=  '<File src="'.$replaceslash.'" metaid="'.$key.'"/>'.PHP_EOL;
                    }

                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
            
            if($typeofdoc     ==  "dest")
            {
                foreach($input_rec['chapter_info_data'] as $key => $value ){
                    if(strpos($value,'/') !== 	false){
                        $doc_exntension         =   substr(strrchr($value, "."), 0);
                        $total_leng             =   (strlen($value))-(strlen($doc_exntension));
                        $pdfnamedest            =   substr($value, 0,$total_leng);
                        
                        $pdfnamedest            =   str_replace(strtoupper('split'),'REFERENCE_PDF',$pdfnamedest);
                        $replaceslash           =   $this->cmn_obj->backslashPathPrepare($pdfnamedest,true);
                        if( $returns == 'xml' ){
                            $figure_str         .=  '<File src="'.$replaceslash.'" metaid="'.$key.'"/>'.PHP_EOL;
                        }
                    }
                
                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;    
            if( $returns == 'xml' )
                $figure     =   $figure_str;
        }
        return $figure;
    }
    
    public function metaprocess($metaId,$process,$status){
        
        echo "succes";
        exit;
    }
    
    public function pitstopupdate(){
        
        return true;
    }
    
    public function bookmergeDpPost($metaId, $processType, $status){
       
        $apiBookObj     = new apiBookMergeModel();
        $recordDetails  =  $apiBookObj->getApiRequestByMetaId($metaId);
        
        $jobId     = $recordDetails->JOB_ID;
        $roundId   = $recordDetails->ROUND;
             
        if($status == 'succes'){
           
            $pitstopObj     = new pitstopController();
            $response       = $pitstopObj->startBookDbComponentwise($metaId , $roundId, $processType );
            
            if($processType == 'online') {
                $setArr     =      array( 'ONLINE_STATUS'   =>     '1.5'  );
            }else if($processType == 'print'){
                $setArr     =      array( 'PRINT_STATUS'   =>    '1.5' );
            }else if($processType == 'mycopy'){
                $setArr     =      array( 'MYCOVER_STATUS'   =>    '1.5'  );
            }else if($processType == 'scopy'){
                $setArr     =      array( 'SOFTCOPY_STATUS'   =>    '1.5' );
            }

            $updateQry  =   DB::table('api_bookMerge')
                                ->where('ID', $recordDetails->ID )
                                ->update( $setArr );
                       
        }else{
            
            if($processType == 'online') {
                $setArr     =      array( 'ONLINE_STATUS'   =>     '3'  );
            }else if($processType == 'print'){
                $setArr     =      array( 'PRINT_STATUS'   =>    '3' );
            }else if($processType == 'mycopy'){
                $setArr     =      array( 'MYCOVER_STATUS'   =>    '3'  );
            }else if($processType == 'scopy'){
                $setArr     =      array( 'SOFTCOPY_STATUS'   =>    '3' );
            }

            $updateQry  =   DB::table('api_bookMerge')
                                ->where('ID', $recordDetails->ID )
                                ->update( $setArr );
        }
        
        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully');
        return json_encode( $result );
        exit;
        
    }
    
    public function bookmergeDpResponse($inputarr ){
        
        if(!empty($inputarr)){
            $metaId         =   $inputarr['metaid'];
            $apiBookObj     =   new apiBookMergeModel();
            $recordDetails  =   $apiBookObj->getApiRequestByMetaIdBylatest($metaId);
            
            if($inputarr['status'] == '2'){
                $updateStatus  = '2';
            }else{
                $updateStatus  = '3';
            }
            
            if($inputarr['process'] == 'book_online') {
                $setArr     =      array( 'ONLINE_STATUS'   =>     $updateStatus  );
            }else if($inputarr['process'] == 'book_print'){
                $setArr     =      array( 'PRINT_STATUS'   =>    $updateStatus );
            }else if($inputarr['process'] == 'book_mycopy'){
                $setArr     =      array( 'MYCOVER_STATUS'   =>    $updateStatus  );
            }else if($inputarr['process'] == 'book_scopy'){
                $setArr     =      array( 'SOFTCOPY_STATUS'   =>    $updateStatus );
            }
            
           /* 
            if($updateStatus == 3){
                
                
                $updateQry  =   DB::table('api_bookMerge')
                                ->where('ID', $recordDetails->ID )
                                ->update( $setArr );
                
            }*/

            $updateQry  =   DB::table('api_bookMerge')
                                ->where('ID', $recordDetails->ID )
                                ->update( $setArr );
            
            
            $metaId         =   $inputarr['metaid'];
            $apiBookObj     =   new apiBookMergeModel();
            $recordDetails  =  $apiBookObj->getApiRequestByMetaId($metaId);
          
            if(!empty($recordDetails)){
                
                if($recordDetails->ONLINE_STATUS != '1.5' && $recordDetails->PRINT_STATUS != '1.5' && $recordDetails->MYCOVER_STATUS != '1.5' && $recordDetails->SOFTCOPY_STATUS != '1.5'){
                  //MOVE to next stage method   
                    $stageMagerObj      =    new stageMangerController();
                    $dataInfo['checkin'] = 0;
                    $dataInfo['jbstgid'] = $inputarr['jobstageid'];
                    $dataInfo['inputQuantity'] = 0;
                    $dataInfo['outputQuantity'] = 0;
                    $dataInfo['inputRemarks'] = '';
                     $stageMagerObj->mangeStageProcess((object)$dataInfo);
                    //app('App\Http\Controllers\Api\autostageController')->stageCompletionProcess($metaId,'119');
                     $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($recordDetails->JOB_ID,'','update',$inputarr['jobstageid']);
                     
                    $result     =   array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Success Response signal received and updated Successfully' );    
                    return response()->json( $result );
                     
                }else{
                    
                }
            }else{
                return false;
            }
            
        }else{
            return false;
        }
        
    }
    
    public function bookMergepackageInfo($jobStageId){
        
        $componentType      = array('1' =>'BookFrontmatter','2'=>'Chapter','3'=> 'BookBackmatter','4'=>'PartFrontmatter','5' =>'COVER','6' => 'INDEX');
        $data2               =   $this->customConstructor($jobStageId);
        
        $jobId              =   $data2['jobid'];
        $roundname          =   $data2['roundname'];
        $bookId             =   $data2['bookid'];
        $issnprint          =   $data2['issnPrint'];
        $partInfo = array(); 
        // $jobId              =  6418;
        $mappDetails = DB::table('task_level_metadata AS tm')
    	->join('metadata_info  as mi', 'mi.METADATA_ID', '=', 'tm.METADATA_ID')
    	->leftJoin('part_mapping as pm', function($join) {
    		$join->on('tm.METADATA_ID', '=', 'pm.CHAPTER_METADATA_ID');
    		$join->on('pm.JOB_ID', '=', 'tm.JOB_ID');
                $join->where('pm.STATUS', '=', '1');
    	})
    	->where('tm.JOB_ID','=',$jobId )
        ->where('tm.UNIT_OF_MEASURE','!=','556')
    	->select('tm.METADATA_ID','tm.CHAPTER_NO','mi.TYPE_OF_CONTAINESM','tm.CHAPTER_NAME','tm.CHAPTER_SEQ','mi.FM_ARTICLE_BM','pm.PART_METADATA_ID')
        ->orderby('tm.CHAPTER_SEQ','ASC')        
    	->get();
      
		$bmPresent		=	0;
		$indexPresent   =   0;
        foreach($mappDetails as $key => $value){
    		 
    		if($value->FM_ARTICLE_BM == '1'){ //Front matter
    			$partData['FM'] = $value;

    		}else if($value->FM_ARTICLE_BM == '2'){//chapter
    			$partData['Chapter'][$value->METADATA_ID] = $value;

    		}else if($value->FM_ARTICLE_BM == '3'){//Back Matter
    			$partData['BM'] = $value;
				$bmPresent		=	1;

    		}else if($value->FM_ARTICLE_BM == '4'){ // Part
    			$partData['PART'][$value->METADATA_ID] = $value;

    		}else if($value->FM_ARTICLE_BM == '5'){ // Part
    			$partData['COVER'] = $value;

    		}else if($value->FM_ARTICLE_BM == '6'){ // Part
    			$partData['INDEX'] = $value;
				$indexPresent		=	1;

    		}
               $metaid[] =  $value->METADATA_ID;
    	}
        
       
   
    	if(!empty($partData['PART'])){
    		 
    		$partMetaid     = array_keys($partData['PART']);
    		$chapterDetails = $partData['Chapter'];
    		
    		$rootChapter = array();
    		foreach($chapterDetails as $key => $data) {
    			$metaId		=	 $data->PART_METADATA_ID;
    			if(in_array($data->PART_METADATA_ID,$partMetaid)){
    				$partInfo[$metaId] = $partData['PART'][$metaId];
    				$partInfo[$metaId]->chapter[$data->METADATA_ID] = $data;
    			}elseif($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}else{
    				if($data->FM_ARTICLE_BM == '2'){
    					$rootChapter[$data->METADATA_ID]= $data;
    				}
    			}
    		}

    	}else{
            $chapterDetails = $partData['Chapter'];
            $rootChapter = array();
            foreach($chapterDetails as $key => $data) {
    			if($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}
    		}
                  
        }
	
    	$overallData['part'] = $partInfo;
        if(!empty($partData['PART'])){
    		 
    		$partMetaid     = array_keys($partData['PART']);
    		$chapterDetails = $partData['Chapter'];
    		
    		$rootChapter = array();
    		foreach($chapterDetails as $key => $data) {
    			$metaId		=	 $data->PART_METADATA_ID;
    			if(in_array($data->PART_METADATA_ID,$partMetaid)){
    				$partInfo[$metaId] = $partData['PART'][$metaId];
    				$partInfo[$metaId]->chapter[$data->METADATA_ID] = $data;
    			}elseif($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}else{
    				if($data->FM_ARTICLE_BM == '2'){
    					$rootChapter[$data->METADATA_ID]= $data;
    				}
    			}
    		}

    	}else{
		
            $chapterDetails = $partData['Chapter'];
    		
            $rootChapter = array();
            foreach($chapterDetails as $key => $data) {
    			if($data->FM_ARTICLE_BM == '2') {
    				$rootChapter[$data->METADATA_ID]= $data;
    			}
    		}
                  
        }
			
       $artProcessData       =   new artProcessController();
      
      $artIllustXml			=	'';
      $artXml               =   $artProcessData->getArtMetaDataTags($metaid);
	  
	  $artIllustXml          =   $artProcessData->getfigurecountInfo($jobId);
      
    	$overallData['part'] = $partInfo;
      
        if(!empty($partData['COVER'])){
            $pageInfo['JobSheet']['DiscreteBookObjectInfo'][] = $partData['COVER'];
        }
        
        if(!empty($partData['INDEX'])){
            $pageInfo['JobSheet']['DiscreteBookObjectInfo'][] = $partData['INDEX'];
        }

        if(!empty($partData['FM'])){
            $pageInfo['JobSheet']['DiscreteBookObjectInfo'][] = $partData['FM'];
        }
        
        if(!empty($partData['BM'])){
            $pageInfo['JobSheet']['DiscreteBookObjectInfo'][] = $partData['BM'];
        }
      
    	if(!empty($rootChapter)){
    		$rootcha = array();
    		foreach($rootChapter as $key=>$rootData){
    			$pageInfo['JobSheet']['DiscreteBookObjectInfo'][] = $rootData;
    		}
    	}
      $indexCom		=	 $this->getIndexComponent($partData, $data2);
        $partGroup  =   [];
    	if(!empty($partInfo)){

    		foreach($partInfo as $key => $partData){
    			$paCh = array();
				if(!empty($partData->chapter)){
    				$paCh[] = $partData;
    				foreach($partData->chapter as $key2 => $chDetails ){
    					$rootcha['ChapterInfo'] = $chDetails;
    					$paCh[] = $rootcha;
    				}
    				$partGroup[] = $partData;

    			}

    		}

    	}
    	 

    	$pageInfo['JobSheet']['PartInfoGroup'] = $partGroup;
        $pxml       =   '';
        $filepath   = '//'.Config::get('constants.FILE_SERVER_WITH_ROOT_DIR').Config::get('constants.BOOK_BUILDING_DB_WATHC_PATH');
        
        $Lowfilepath = '//'.Config::get('constants.FILE_SERVER_WITH_ROOT_DIR').Config::get('constants.BOOK_BUILDING_LOW_RES_PATH');
		
        $artQC = '//'.Config::get('constants.FILE_SERVER_WITH_ROOT_DIR').Config::get('constants.BOOK_BUILDING_ART_QC_PATH');
        
        /* 		$curartRound       =    null;
                $getArtRoundqry    =   'SELECT ID,CURRENT_ROUND FROM metadata_status WHERE metadata_id = '.$metaid.' ORDER BY id DESC LIMIT 1';
                $getArtRound       =    DB::select( $getArtRoundqry );
                
                if( count( $getArtRound ) ){
                    $curartRound    =   $getArtRound[0]->CURRENT_ROUND;
                }  

		*/
		
	
        foreach($pageInfo['JobSheet']['DiscreteBookObjectInfo'] as $key => $jdata){
 
            $ctype   = $jdata->FM_ARTICLE_BM;
            $cname   = $componentType[$ctype];
			$metaId2  = $jdata->METADATA_ID;
        
            $inp_rep_arr        = array('{BID}' => $bookId,'{RID}' => $roundname,'{CID}' => $jdata->CHAPTER_NO );
            $prepared_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $filepath));  
			
			$curartRound       =    null;
			$isArt			= 0;
			$getArtRoundqry    =   "SELECT ID,CURRENT_ROUND FROM metadata_status WHERE metadata_id = '$metaId2' ORDER BY id DESC LIMIT 1";
			
			$getArtRound       =    DB::select( $getArtRoundqry );
			
			if( count( $getArtRound ) ){
				$curartRound    =   $getArtRound[0]->CURRENT_ROUND;
				$curartRound    =   \Config::get('constants.ROUND_ID')[$curartRound];
				$isArt			=  1;
			}
           
		   if($curartRound  != null ){
		    $inp_rep_arr2        = array('{BID}' => $bookId,'{RID}' => $curartRound,'{CID}' => $jdata->CHAPTER_NO );
            $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $Lowfilepath));  
			
			$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $artQC));  
		   }else{
			   $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $Lowfilepath));  
			
			$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $artQC));  
		   }
            
            if($ctype == '5' ){
             
                $cname    = strtolower($cname);
                $pxml  .= '<component name="'.ucfirst($cname).'">';
                $pxml  .= '<bookcoverprintpdf>'.$prepared_path.'Cover\\'.$bookId.'_Cover.pdf</bookcoverprintpdf>';
                $pxml  .= '<bookprintcoverpdfpitstoplog>'.$prepared_path.'Cover\\'.$bookId.'_Cover_log.pdf</bookprintcoverpdfpitstoplog>';
                $pxml  .= '<bookmycopycoverpdf>'.$prepared_path.'MyCopyCover\\'.$bookId.'_MyCopyCover.pdf</bookmycopycoverpdf>';
                $pxml  .= '<bookmycopycoverpdfpitstoplog>'.$prepared_path.'MyCopyCover\\'.$bookId.'_MyCopyCover_log.pdf</bookmycopycoverpdfpitstoplog>';
                
                $pxml  .= '<booksoftcoverpdf>'.$prepared_path.'SoftCopy\\'.$bookId.'_SoftCopy.pdf</booksoftcoverpdf>';
                $pxml  .= '<booksoftcoverpitstoplog>'.$prepared_path.'SoftCopy\\'.$bookId.'_SoftCopy_log.pdf</booksoftcoverpitstoplog>';
                
                $pxml  .= '<bookprintcovertifimage>'.$prepared_path.$issnprint.'.tif</bookprintcovertifimage>';
                $pxml  .= '<bookSoftcovertifimage>'.$prepared_path.$issnprint.'.tif</bookSoftcovertifimage>';
                $pxml  .= '<ebookcoverjpgimage>'.$prepared_path.$issnprint.'.jpg</ebookcoverjpgimage>';
                $pxml  .= '<ebookcovertifimage>'.$prepared_path.$issnprint.'.tif</ebookcovertifimage>';
                 
                 
                 
                $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
                $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
                $pxml  .= '</component>';
            }
          
            if($ctype == '6' ){
				if($bmPresent == 0 && $indexPresent == 1){
					$cname2   = $componentType['3'];
					$pxml  .= '<component name="'.$cname2.'">';
					$pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$cname.'.xml</xmlfile>';
					$pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF.pdf</pdffile>';
					$pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF_log.pdf</pitstopstopfile>';
					$pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
					$pxml .= '<highresimagefolder>'.$lowres_path.'</highresimagefolder>';
					$pxml  .= '</component>';
				}
            }
            
            if($ctype == '1' ){
                $pxml  .= '<component name="'.$cname.'">';
                $pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$cname.'.xml</xmlfile>';
                $pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF.pdf</pdffile>';
                $pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF_log.pdf</pitstopstopfile>';
                $pxml  .= '<BookTOCpdffile>'.$prepared_path.$bookId.'_'.$cname.'_TOC_OnlinePDF.pdf</BookTOCpdffile>';
                $pxml  .= '<BookTOCpitstopstopfile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF_log.pdf</BookTOCpitstopstopfile>';
               $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
                $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
                $pxml  .= '</component>';
            }
            
            if($ctype == '3' ){
                $pxml  .= '<component name="'.$cname.'">';
                $pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$cname.'.xml</xmlfile>';
                $pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF.pdf</pdffile>';
                $pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF_log.pdf</pitstopstopfile>';
               $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
                $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
                $pxml  .= '</component>';
            }
            
            if($ctype == '2' ){
                
                  
                     $cname      = $componentType[$ctype];
                     
                     $name  = explode('_',$jdata->CHAPTER_NO);
                     $cname1 = $name[1].'_'.$componentType[$ctype]; 
                     
                     $inp_rep_arr        = array('{BID}' => $bookId,'{RID}' => $roundname,'{CID}' => $jdata->CHAPTER_NO );
                     $prepared_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $filepath));  
                     
                     $pxml  .= '<component name="'.$cname1.'">';
                            $pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'.xml</xmlfile>';
                            $pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'_OnlinePDF.pdf</pdffile>';
                            $pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'_OnlinePDF_log.pdf</pitstopstopfile>';
                            $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
                            $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
                     $pxml  .= '</component>';
            }
            
        }
        
        
        foreach($pageInfo['JobSheet']['PartInfoGroup'] as $key => $jdata){
						
            $ctype        = $jdata->FM_ARTICLE_BM;
			$metaId2       = $jdata->METADATA_ID;
            $cname2        = $componentType[$ctype];
            $name         = explode('_',$jdata->CHAPTER_NO);
            $ctypename    = $name[1].'_'.ucfirst(strtolower($name['0']));  
            $cname        = $name[1].'_'.$cname2;  
            $inp_rep_arr        = array('{BID}' => $bookId,'{RID}' => $roundname,'{CID}' => $jdata->CHAPTER_NO );
            $prepared_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $filepath));  
            
            $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $Lowfilepath));  
			$art_path          =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $artQC));  
			
			$curartRound       =    null;
			$isArt			= 0;
			$getArtRoundqry    =   "SELECT ID,CURRENT_ROUND FROM metadata_status WHERE metadata_id = '$metaId2' ORDER BY id DESC LIMIT 1";
			
			$getArtRound       =    DB::select( $getArtRoundqry );
			
			if( count( $getArtRound ) ){
				$curartRound    =   $getArtRound[0]->CURRENT_ROUND;
				$curartRound    =   \Config::get('constants.ROUND_ID')[$curartRound];
				$isArt			=  1;
			}
           
		   if($curartRound  != null ){
		    $inp_rep_arr2        = array('{BID}' => $bookId,'{RID}' => $curartRound,'{CID}' => $jdata->CHAPTER_NO );
            $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $Lowfilepath));  
			
			$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $artQC));  
		   }else{
			   $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $Lowfilepath));  
			
			$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $artQC));  
		   }
            
            $pxml  .= '<component name="'.$ctypename .'">';
            
            $pxml  .= '<component name="'.$cname.'">';
            $pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$cname.'.xml</xmlfile>';
            $pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$cname.'_OnlinePDF.pdf</pdffile>';
            $pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname2.'_OnlinePDF_log.pdf</pitstopstopfile>';
            $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
            $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
            $pxml  .= '</component>';
            
            if(isset($jdata->chapter) && !empty($jdata->chapter)){
                
                foreach($jdata->chapter  as $key3  => $cdata){
                     $ctype   = $cdata->FM_ARTICLE_BM;
					 $metaId2 = $cdata->METADATA_ID;
                     $cname      = $componentType[$ctype];
                     
                     $name  = explode('_',$cdata->CHAPTER_NO);
                     $cname1 = $name[1].'_'.ucfirst(strtolower($componentType[$ctype])); 
                     
                     $inp_rep_arr        = array('{BID}' => $bookId,'{RID}' => $roundname,'{CID}' => $cdata->CHAPTER_NO );
                     $prepared_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $filepath));  
					 
					 
                     $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $Lowfilepath));  
                      $art_path          =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $artQC));  
					  
					$curartRound       =    null;
					$isArt			= 0;
					$getArtRoundqry    =   "SELECT ID,CURRENT_ROUND FROM metadata_status WHERE metadata_id = '$metaId2' ORDER BY id DESC LIMIT 1";
					
					$getArtRound       =    DB::select( $getArtRoundqry );
					
					if( count( $getArtRound ) ){
						$curartRound    =   $getArtRound[0]->CURRENT_ROUND;
						$curartRound    =   \Config::get('constants.ROUND_ID')[$curartRound];
						$isArt			=  1;
					}
				   
				   if($curartRound  != null ){
					$inp_rep_arr2        = array('{BID}' => $bookId,'{RID}' => $curartRound,'{CID}' => $cdata->CHAPTER_NO );
					$lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $Lowfilepath));  
					
					$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr2, $artQC));  
				   }else{
					   $lowres_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $Lowfilepath));  
					
					$art_path      =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $artQC));  
				   }
					  
					  
                     $pxml  .= '<component name="'.$cname1.'">';
                     $pxml  .= '<xmlfile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'.xml</xmlfile>';
                     $pxml  .= '<pdffile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'_OnlinePDF.pdf</pdffile>';
                     $pxml  .= '<pitstopstopfile>'.$prepared_path.$bookId.'_'.$name[1].'_'.$cname.'_OnlinePDF_log.pdf</pitstopstopfile>';
                     $pxml .= '<lowresimagefolder>'.$lowres_path.'</lowresimagefolder>';
                     $pxml .= '<highresimagefolder>'.$art_path.'</highresimagefolder>';
                     $pxml  .= '</component>';
                }
            }
            
            $pxml  .= '</component>';
            
        }
        
        $made_inp           =   array( 'jobsheetpath' => '' );
		$jspath             =   $this->assignAdditonalOptionToMetaInfo(  $made_inp , 1 );
       
       
        $response['jspath']     = $jspath;
        $response['packdata']   = $pxml;
        $response['artdetails'] = $artXml;
		$response['indexComponent'] = $indexCom;
        $response['artIllusdetails'] = $artIllustXml;
        
       
        return $response;
       
    }
	
	public function getIndexComponent($partGroup, $otherDetails){
		$jobId              =   $otherDetails['jobid'];
        $roundname          =   $otherDetails['roundname'];
        $bookId             =   $otherDetails['bookid'];
        $issnprint          =   $otherDetails['issnPrint'];
		
		$bookSrcpath   = '//'.Config::get('constants.FILE_SERVER_WITH_ROOT_DIR').Config::get('constants.INDEX_COMPONENT_SRCPATH'); 
		$indexPath 			=	'';
		
			
		if(isset($partGroup['INDEX']) && !empty($partGroup['INDEX'])){
			
		
			if($partGroup['INDEX']->FM_ARTICLE_BM == '6' || $partGroup['INDEX']->CHAPTER_NO == 'INDEX'){
				
				
				$inp_rep_arr   	= array('{BID}' => $this->metainfo['bookid'],'{RID}' => $roundname,'{CID}' => $partGroup['INDEX']->CHAPTER_NO );
				
				$prepared_path  =   str_ireplace('/','\\',$this->cmn_obj->arr_key_value_replace($inp_rep_arr, $bookSrcpath));
				$index    		= 	ucfirst(strtolower($partGroup['INDEX']->CHAPTER_NO));
				
				$filename  		= 	$this->metainfo['bookid'].'_'.$index.'.xml';
			
				$indexPath  .= '<Indexcomponent name="'.$index.'">
								  <xmlfile>'.$prepared_path.$filename.'</xmlfile>
								  </Indexcomponent>';
  
			}
		}
		
		return $indexPath 	;
	}
    
    public function tempreturn( $inputarr , &$response ){
        
       $response['status']         =       1;
        $response['msg']            =       'Success';
        $response['errMsg']         =       'Signal received successfully..., stage rollback done';   

        return response()->json($resp);
        
    }
}