<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager;
use App\Models\jobStage;
use App\Models\apiPitstop;
use App\Models\apiCap;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class capController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    public $tablename       =       'api_cap';
    public $apiModel        =       'apiCap';
    
    public function customConstructor( $jobStageId ){
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
        
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $cmn_obj                    =       new CommonMethodsController();
        $tablename                  =       $this->tablename;
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , $tablename , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
         
        return  $metainfo;
        
    }
    
    public function storeResponse( Request $request ){
       
        $inputarr           =       json_decode( $request->getContent() );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $inputarr           =       (array)$inputarr;
        
        Log::useDailyFiles(storage_path().'/Api/cap_response.log');
        Log::info( json_encode( $inputarr ) );
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Try again after sometimes';
        
        $rules      =   $this->validationRuleForResponseSignal(); 
        $validator                  =       Validator::make( $inputarr , $rules );
      
            if ($validator->fails()) {
                
               $response['errMsg']      =       'Required field validation error occured.';
               
            }else{ 
                
                $token_key      =      $inputarr['tokenkey'];
                $sig_obj        =      new apiCap();
                $getRec         =      $sig_obj->getApiRequestByTokenKey( $token_key );
                 
                    if(!empty( $getRec )){

                        $this->prepareUpdationValues( $inputarr , $inpArr );

                        $rowid              =           $getRec->ID;
                        $lwr_up_status      =           $sig_obj->updateIfExist( $inpArr, $rowid );

                        if( $lwr_up_status ){

                            $response['status']         =       1;
                            $response['msg']            =       'Success';
                            $response['errMsg']         =       'Signal Received Successfully';

                        }else{
                            $response['errMsg']         =       'Signal update Query got Failed';
                        }

                    }else{
                        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
                    }
                
            }
            
            echo json_encode( $response );
            
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess( $jbstgid ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        $this->customConstructor( $jbstgid );
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
         
        try{
            
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
            $watchPath      =       $this->getWatchFolderPath( $path );
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoPageMeta( $jbstgid );
           
            $metafileInput['metafilename']      =   $this->getMetafilename();
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input      =       array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            //$api_tbl_input['PLATFORM']      =   $platform;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
            
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
        }catch( \Exception $e ){
            
            $response['status'] =   0;
            $response['Msg']    =   'failed';
            $response['errMsg']    =   'Something went wrong, try again after sometimes';
            
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
        }
        
        return response()->json( $response );
        
    }
    
    public function getMetafilename(){
        
        extract(  $this->metainfo );
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_{CNAME}_{TKEY}_cap.xml';
        $cmn_obj        =       new CommonMethodsController();
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH');
          
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
            $cr_data['FTP_HOST']        =       $recServer['host'];
            $cr_data['FTP_USER_NAME']   =       $recServer['username'];
            $cr_data['FTP_PASSWORD']    =       $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
            
                $watchPath          =       $path['detail'];
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                //remove user directory 
                $workpath           =       preg_replace('/[0-9]/', '', $workpath);
                $workpath           =       str_replace('//', '', $workpath);
                
            }
        
        }
        
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

       $cmn_obj                    =       new CommonMethodsController();

       $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );

       $errorstr           =            '';
       $postMetaStatus     =            app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           $insert_ret                     =       apiCap::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiCap::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

       return false;

   }

    public function prepareAutoPageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid );
        $preparedXml        =       '';    

        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){

                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );

                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();

                    if( !empty( $bgprocess ) ){
                        $xmlStr               =       $cmn_obj->array2xml( $bgprocess , false , $parent_info->TAG_NAME );
                        $xmlStr               =       str_replace( '<?xml version="1.0"?>' , '' , $xmlStr );    
                        $preparedXml         .=       $xmlStr;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }

                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );

        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
    
    public function getArtMetaDataTags( $jbstgid ){
        
        $xmlStr     =   '<ArtMetaData>';
       
            extract( $this->metainfo );            
            $getartfigure       =       DB::table( 'task_level_art_metadata' )
                                            ->whereIn( 'METADATA_ID' , array( $metaid )  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();   

            $xmlStr         .=          app('App\Http\Controllers\artProcess\artProcessController')->prepareFigureTags( $getartfigure );
            $xmlStr        .=          '</ArtMetaData>';
         
        return $xmlStr;
        
    }
    
    public function getOrderExecSeq( $process ){
        
        $xmlStr     =   '';
        
        switch ( $process ){
            
            case '3b2' :
                 $xmlStr =   '
                <Process OrderNo="1" ProcessName="FPP" State="Q|I|C" ServerName=""/>
                <Process OrderNo="2" ProcessName="FileCopy" State="Q|I|C" ServerName=""/>';
                break;
            
            case 'distiller':
                $xmlStr =   '<Process OrderNo="3" ProcessName="D/P" State="Q|I|C" ServerName=""/>
                <Process OrderNo="4" ProcessName="FileCopy" State="Q|I|C" ServerName=""/>';
                break;
            
            default :
                $xmlStr =   '
                            <Process OrderNo="1" ProcessName="FPP" State="Q|I|C" ServerName=""/>
                            <Process OrderNo="2" ProcessName="FileCopy" State="Q|I|C" ServerName=""/>
                            <Process OrderNo="3" ProcessName="D/P" State="Q|I|C" ServerName=""/>
                            <Process OrderNo="4" ProcessName="FileCopy" State="Q|I|C" ServerName=""/>
                            ';
                break;
        }
            
        return $xmlStr;
        
    }
    
    public function getMetadataTagsInformation( $jbstgid ){
     
        $xmlStr =       '';
        extract( $this->metainfo );
        
        $bgprocesPath        =       new bgprocessPathSetup();
        $stage__id           =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' );
        $processname         =       'METADATA';
        $parent_info         =       $bgprocesPath->getBgProcessSetup( $round , $processname , $stage__id );
        
        if( count( $parent_info ) ){
            $bgprocess           =       $bgprocesPath->getBgProcessMetaDirectXmlArray( $round , $processname , $stage__id );
            $xmlStr              =       true;
            $cmn_obj             =       new CommonMethodsController();
            $xmlStr              =       $cmn_obj->array2xml( $bgprocess , false , $parent_info->TAG_NAME );
            $xmlStr              =       str_replace( '<?xml version="1.0"?>' , '' , $xmlStr );    
        }
        
        return $xmlStr;
        
    }
          
    public function replaceRequireKeysToValues( $xmlStr ){
        
        $cmn_obj             =       new CommonMethodsController();
        $inp_rep_arr         =      $this->getRequiredReplacables();
        $xmlStr     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlStr );
        return $xmlStr;
    }
    
    public function getRequiredReplacables(){
           
        $empid          =        Session::get('users')['emp_id'];
        $username       =        Session::get('users')['user_name'];
        try{
        extract( $this->metainfo );
        
        $getlocationftp =        productionLocationModel::doGetLocationname( $jobid );
        
        $chapterno2      =        preg_replace( '/\D/', '', $chapterno );
        $ckey           =        preg_replace("/[0-9_]/", '', $chapterno);
        $chpatername    =        $chapterno;
        
        //need to dynamicaly bind the production location based on table location
        $hostserver     =       $getlocationftp->FTP_HOST;
        
        $rdir           =       str_replace( $getlocationftp->FTP_PATH , '' , $getlocationftp->FILE_SERVER_PATH );
        $rdir           =       substr($rdir, 1);
        $rdir           =       str_replace(  '/' , '\\' ,  $rdir );
        
        $tsklvel        =       new taskLevelMetadataModel();
        $taskinfo       =       $tsklvel->getMetadatadetailsChapter( $metaid );
        $eproof         =       ( $taskinfo[0]->EPROOFING_SYSTEM == 1 ) ? 'YES': 'NO';
        $job_info                               =       DB::table( 'job as j' )
											->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
											->where( 'j.JOB_ID' , 'LIKE', '%'.$jobid.'%')
											->select()
											->get()->first();
        
        $round_arr      =       \Config::get( 'constants.ROUND_ID' );
        $roundname      =       $round_arr[$round];
        $publisher      =       $job_info->PUBLISHER_NAME;
        $issno          =       $job_info->ISSN_ONLINE;
        $issnp          =       $job_info->ISSN_PRINT;            
            
        
        $array          =       array(  
                                '{EMPID}'       =>      $empid      , '{UNAME}'     =>  $username  , 
                                '{RNAME}'       =>      $roundname  , '{CNAME}'     =>  $chpatername , '{RID}'  =>  $round ,
                                '{CAMELCNAME}'  =>      ucfirst( strtolower( $chpatername ) ) ,  '{BID}'    =>  $bookid , 
                                '{ISSNO}'       =>      $issno     , '{ISSNP}' => $issnp ,   '{CNO}'   =>   $chapterno2 , 
                                '{CKEY}'        =>      $ckey   ,     '{EPROF}' => $eproof ,
                                '{PUBLISHER}'   =>      $publisher ,  '{SIP}'  => $hostserver , '{RDIR}' => $rdir  ,
                                '{APPURL}'      =>      \Config('app.url') , '{JOBID}' => $jobid , 
                                '{JBSTGID}'     =>      $jobstgid , '{METAID}' => $metaid , 
                                '{TKEY}'        =>      $this->tokenkey  ,'{CAMELCKEY}' => ucfirst( strtolower( $ckey ) )      
                            );

        return $array;
        
        }catch( \Exception $e ){
            throw new \Exception( $e->getMessage() );
        }
        
    }
    
    
}