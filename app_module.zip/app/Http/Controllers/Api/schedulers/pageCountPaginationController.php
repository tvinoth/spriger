<?php
namespace App\Http\Controllers\Api\schedulers;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\autoPageController;
use App\Models\Schedulers\pageCountModel;
USE App\Models\bookinfoModel;
use App\Models\taskLevelMetadataModel;
use App\Models\productionLocationModel;
use Storage;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Mail;
use DB;
use Log;

class pageCountPaginationController extends Controller{
    
    public $timeDelay       =   10;
    public $extracttype     =   'ftp'; //'wcs';
    
    Public function __construct() {
        
        //
        //parent::__construct();
       
    }
    
    public function fetchPageCountShedule(){
		
        //Log::useDailyFiles(storage_path().'/Api/pageCountPaginationCorrection.log');
	//Log::info( "Correction Controller call" );
		
        $pgeMdl     =       new pageCountModel();
        $cmn_obj    =       new CommonMethodsController;
        $findRec    =       $pgeMdl->getRunableRecordWithPriority(1);
        $runRec     =       array();
        
        $response['status']      =   	0;
        $response['msg']         =   	'failed';
        $response['errMsg']      =   	'There is no record to proceed pagecount fetch';
		
        try{
				
			if( count( $findRec ) ){
				$runRec      =       $findRec;
			}else{
				$findRec     =       $pgeMdl->getRunableRecord();
				$runRec      =       $findRec;
			}
			
			if( count( $runRec ) ){
				
				$runRec				=	  (array)$runRec;
				
				$crontblId			=	  $runRec['ID'];
				$metaid             =     $runRec['METADATA_ID'];
				$roundid            =     $runRec['ROUND'];
				$paginationpath     =     '';	
				$wcsUrl             =     \Config::get('constants.PRODUCTION_TOOLS_SETUP.JOBSHEET_DOWNLOAD_SERVICE');
				
				//$data               =     $this->prepareWebeserviceInput();
				//$returns_response   =   $cmn_obj->RestfulPostcUrlExecution( $data , $wcsUrl , 1 , "text" );
				
				$paginationpath		=	  $this->paginationProductionFilePath( $metaid , $roundid );
				
				if( $paginationpath ){
						
					$pgecontent     	=     @file_get_contents( $paginationpath );
				
					if( $pgecontent !== false ){
						
						$xmlstr			=		simplexml_load_string( $pgecontent );
						
						if( !empty( $xmlstr ) && $xmlstr ){
							
							$arr_co			=		json_encode(  $xmlstr  );
							
							//if valid json
							if( $arr_co ){	
							
								$pgeObj			=		json_decode(  $arr_co  );						
								$insSts			=		$this->storePageInfo( $pgeObj , $runRec );
												
								if( $insSts ){	
									//update cron success
									$pgeMdl::updateIfExist( array( 'STATUS' => 2 ) , $crontblId );		
									
								}else{
									$updatval		=	array( 'STATUS' => 1 , 'REMARKS' => 'Page count information not updated' ) ;	
									//update cron failure
									$pgeMdl::updateIfExist( $updatval , $crontblId );			
								}
								
							}else{		
							
								$updatval		=	array( 'STATUS' => 3 , 'REMARKS' => 'json encode error occured' );
								//send update to no pagefile found
								$pgeMdl::updateIfExist( $updatval , $crontblId );				
								
							}
							
						}else{
							
							$updatval		=	array( 'STATUS' => 3 , 'REMARKS' => 'Invalid xml string to load' );
							//send update to no pagefile found
							$pgeMdl::updateIfExist( $updatval , $crontblId );	
							
						}
						
					}else{
						
						$updatval		=	array( 'STATUS' => 3 , 'REMARKS' => 'Pg count xml file not found' ) ;
						//send update to no pagefile found
						$pgeMdl::updateIfExist( $updatval , $crontblId );
						
					}
					
				}else{
					
					$updatval		=	array( 'STATUS' => 1 , 'REMARKS' => ' Invalid request , Page count information not updated - ' ) ;	
					//update cron failure
					$pgeMdl::updateIfExist( $updatval , $crontblId );	
					
					
					
				}
				
			}else{
				
				return response()->json( $response );
				
			}
			
		}catch( \Exception $e ){
			
			//need to update failure remarks.
			$response['errMsg']		=		 $e->getTraceAsString();
			
			return response()->json( $response );
			
		}
        
		
    }
    
	public function storePageInfo( $pgeObj , $metaArr ){
		
		$metaid 	 = 		$metaArr['METADATA_ID'];
		//$round	 = 		$metaArr['ROUND_ID'];
	
		
		if( isset( $metaid ) && !empty( $metaid ) ){ 
			
			$pgeObj		=	$pgeObj->PageCount;
			
			$Startpage	=	isset( $pgeObj->Startpage ) ? $pgeObj->Startpage : 0;
			$Endpage	=	isset( $pgeObj->Endpage ) ? $pgeObj->Endpage : 0;
			$Blankpage	=	isset( $pgeObj->Blankpage ) ? $pgeObj->Blankpage : 0;
			$Totalpage	=	isset( $pgeObj->Totalpage ) ? $pgeObj->Totalpage : 0;
			
			$updArr		=	array(  
									'START_PAGE' 	=> 	$Startpage  , 
									'END_PAGE' 		=>  $Endpage	, 
									'BLANK_PAGE' 	=> 	$Blankpage  , 
									'TOTAL_PAGE' 	=> 	$Totalpage 
								);
			
			$upSts		=	DB::table('metadata_info')->where( 'METADATA_ID' , $metaid )->update( $updArr );
			
			if( $upSts ){
				return true;
			}else{
				return false;
			}
			
		}

		return false;
		
	}
	
	
    public function updatePageCountInformationOnDemand( $metaid , $roundid ){
       
        $pgeMdl     =       new pageCountModel();
        $cmn_obj    =       new CommonMethodsController;
        $findRec    =       $pgeMdl->getRunableRecordWithPriority(1);
        $runRec     =       array();
        
        $response['status']      =   	0;
        $response['msg']         =   	'failed';
        $response['errMsg']      =   	'There is no record to proceed pagecount fetch';

        try{

			if( isset(  $metaid  ) ){
				
				$wcsUrl             =     \Config::get('constants.PRODUCTION_TOOLS_SETUP.JOBSHEET_DOWNLOAD_SERVICE');
				$paginationpath		=	  $this->paginationProductionFilePath( $metaid , $roundid );
				
				$pgecontent     	=     @file_get_contents( $paginationpath );
				
				if( $pgecontent ){
					
					$xmlstr			=		simplexml_load_string( $pgecontent );
					$arr_co			=		json_encode(  $xmlstr  );
					$pgeObj			=		json_decode(  $arr_co  );
					
					$insSts			=		$this->storePageInfo( $pgeObj , $runRec );
					//$crnCnd			=		array( 'ID' , $crontblId );
					
					if( $insSts ){	
						//update cron success
						$pgeMdl::updateIfExist( array( 'STATUS' => 2 ) , $crontblId );		
					}else{
						$updatval		=	array( 'STATUS' => 1 , 'REMARKS' => 'Page count information not updated' ) ;	
						//update cron failure
						$pgeMdl::updateIfExist( $updatval , $crontblId );			
					}
					
				}else{
					
					$updatval		=	array( 'STATUS' => 3 , 'REMARKS' => 'Pg count xml file not found' ) ;
					//send update to no pagefile found
					$pgeMdl::updateIfExist( $updatval , $crontblId );
					
				}
				
			}else{
				
				return response()->json( $response );
				
			}
			
		}catch( \Exception $e ){
			
			//need to update failure remarks.
			$response['errMsg']		=		 $e->getTraceAsString();
			return response()->json( $response );
		}
        
		
    } 
    
	
    public function paginationProductionFilePath( $metaid , $roundid ){
		
		$tskMdl             =       new taskLevelMetadataModel();
		$metadata           =       $tskMdl->getMetadatadetailsChapter( $metaid );
		$cmn_obj    		=       new CommonMethodsController;
		
		if( count( $metadata ) ){
			
			$metadata   	=       $metadata[0];
			$jobId      	=       $metadata->JOB_ID;
			$chapterno  	=       $metadata->CHAPTER_NO;  
			$comptype   	= 	$metadata->FM_ARTICLE_BM;
			
		}else{
			
			return false;
			
		}
		

		$jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
		$job_id             =       $jobId;     

		$bookdetails        =  		bookinfoModel::select(DB::raw('job.*,job_info.*'))
											->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
											->where( 'job.JOB_ID',$jobId )
											->get()->first();            

		$bookId             =       $book_id            =   $data['book_id'] =      $bookdetails['BOOK_ID'];
		$root               =   	\Config::get('constants.FILE_SERVER_ROOT_DIR');
		$ftp_path_          =   	\Config::get('constants.SPLIT_DESTINATION_PATH');
		$crd                =   	\Config::get('constants.FILE_SERVER_CREDENTIALS'); 

		//need to dynamicaly bind the production location based on table location    
		//ftp connection location job

		$getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );  
		$hostserver         =   $getlocationftp->FTP_HOST;
		$hostusername       =   $getlocationftp->FTP_USER_NAME;
		$hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
		$hostpath           =   ( $getlocationftp->FTP_PATH );
		$crd2               =   'ftp://'.$hostusername.':'.$hostpassword.'@'; 

		//$userWorkDir      =   \Config::get('constants.USER_WORK_PATH');
		$round_const        =   \Config::get( 'constants.ROUND_ID' );
		$paginationpath     =   \Config::get('constants.PAGINATION_FILEPATH');
		
		$componetskip		=	array( 2 );
		
		if( !in_array(  $comptype ,  $componetskip ) ){
			$paginationpath		=	str_replace(  'APN_PAGINATION'  , 'PAGINATION_FILES' , $paginationpath );
		}
		
		$rootdir			=	'/';\Config::get('constants.FILE_SERVER_ROOT_DIR');
		$paginationpath     =   $hostserver.$rootdir.$paginationpath["$round_const[$roundid]"].'{PAGING_FILENAMING}_Pgcount.xml';
		
		$autoPgeContObj		=	new autoPageController();
		
		$chatperId       	=   $chapterno;
		$paginginfo      	=   $autoPgeContObj->getPagingFileNameing( $bookId , $chatperId , $metaid );
		$pagingfilnaming 	=   '';
		
		$chapnoonly      	= 	preg_replace( '/\D/', '', $chatperId );

		 if( !strpos( strtoupper( $chatperId ) , 'CHAPTER' ) ){
			$chapnoonly     =       $chatperId;
		 }

		extract( $paginginfo );

		$const_replace      =   array(  
									'RNAME'     =>  $round_const["$roundid"] , 
									'RID'       =>  $round_const["$roundid"] , 
									'{CID}'       =>  $chatperId , 
									'{BID}'       =>     $book_id , 
									'{PAGING_FILENAMING}'  =>   $pagingfilnaming
								);
		
		$paginationpath      =       $cmn_obj->arr_key_value_replace( $const_replace , $paginationpath );
		
		//Log::useDailyFiles(storage_path().'/Api/pageCountPaginationCorrection.log');
		//Log::info( "Correction Controller call" );
		//Log::info( $crd2.$paginationpath );
		 
		return $crd2.$paginationpath;
            
	}
	
}