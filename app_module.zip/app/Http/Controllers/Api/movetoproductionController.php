<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\apiSpicastModel;
use App\Models\apitapsModel;
use App\Models\tapsmetadataModel;
use App\Models\metadataInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\taskLevelMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class movetoproductionController extends Controller
{  
    public function domoveToproduction(Request $request)
    {
        $getToolresponse    =   json_decode(file_get_contents('php://input'));
         
        if(count($getToolresponse)>=1)
        {
            $roundid    =   $getToolresponse->ROUND_ID;
            $jobId      =   $getToolresponse->JOB_ID;
            $workflowid =   $getToolresponse->WORKFLW_ID;
            $metaid     =   $getToolresponse->META_ID;
            //check quantity field is exist or not
            if(isset($getToolresponse->QUANTITY)){
				
                $quanity    =   $getToolresponse->QUANTITY; 
                
            }else{
				
                $getchapters=   taskLevelMetadataModel::getMetadatadetailsChapter($metaid);
				
                $quanity    =   (count($getchapters)>=1?$getchapters[0]->NO_MSP:1);
			
            }
			
             if($quanity == '0' || $quanity == 'null' || $quanity == '' ){
                    $quanity  = 1;
             }
			
            $bookdetaills   =   jobModel::getJobdetails($jobId);
            if($bookdetaills != null){
                $deadline_array     =   json_decode( $bookdetaills->STAGE_DEADLINES_COLLECTION,true);
                if(count($deadline_array)>=1){

                    $getroundstage  =   Config::get('constants.ROUND_NAME')[$roundid];
                    $duedate    =   str_ireplace('.','-',$deadline_array[$getroundstage]);
                }else{
                    $duedate    =   date("Y-m-d");
                }
            }else{
                $duedate    =   date("Y-m-d");
            }
            $userid     =   $getToolresponse->USER_ID;
            $datas      =    "success";
            
           $query_stmt =   "CALL movetoproduction('".$jobId."', '".$roundid."', '".$workflowid."', '".$metaid."', NULL, '".$quanity."', '".$duedate."', 0,'".$userid."')";
		 Log::useDailyFiles(storage_path().'/Api/movetoproduction.log');
        Log::info($query_stmt );
            $moveDetails    =   DB::select( $query_stmt );  
          
            if(count($moveDetails)>=1)
            {
                //get max of id 
                $getmax     =   tapsmetadataModel::where('METADATA_ID',$metaid)->orderBy('ID','DESC')->first();
                $maxId      =   (count($getmax)>=1?$getmax->ID:'');
                $updatetapsdata     =   [];
                $updatetapsdata['MOVETOPRODUCTION']  =   json_encode($moveDetails);
                $updatetapsdata['PRODUCTION_STATUS'] =   ($moveDetails[0]->errcode == 0?'1':'2');
                $updated    =	tapsmetadataModel::where('ID',$maxId)->update($updatetapsdata);
                if($updated)
                {
                    $result         =   array('result'=>200,'status'=>1,'errMsg'=>'Move to Production has been successfully sent');   
                    return response()->json($result);
                }
                $result         =   array('result'=>400,'status'=>0,'errMsg'=>'Move to Production failed try again');   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'status'=>0,'errMsg'=>'Move to Production failed try again');   
            return response()->json($result);
        }
        $result         =   array('result'=>404,'status'=>0,'errMsg'=>'Move to Production failed try again');   
        return response()->json($result);
    }
}