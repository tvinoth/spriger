<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\jobInfoModel;
use App\Models\apiClientAcknowledgement;
use App\Models\jobRoundModel;
use App\Models\jobResource;
use App\Models\apiActivemqModel;
use App\Models\jobTimeSheet;
use App\Models\downloadModel;
use App\Models\checkoutModel;
use App\Models\apiFileUpload;
use App\Models\jobModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class activeMqReportController extends Controller
{ 
    protected  $tablename;
    protected  $titlemastertable;
    protected  $titleworkmastertable;
    protected  $chaptermastertable;
    protected  $roundstagetable;
    protected  $userstagetable;
    protected  $statusCompleted;
    protected  $statusRelease;
    protected  $statusInprogress;
    protected  $successredo;
    protected  $loginUserID;
    protected  $senderName;
    public function __construct()
    {
        $this->tablename            =   "job_time_sheet";
        $this->titlemastertable     =   "title_master";
        $this->titleworkmastertable =   "title_work_clasification";
        $this->chaptermastertable   =   "chapter_master";
        $this->roundstagetable      =   "round_stage_details";
        $this->userstagetable       =   "user_stage_details";
        $this->statusCompleted      =   Config::get('constants.STATUS_ENUM_COLLEECTION.COMPLETED');
        $this->statusInprogress     =   Config::get('constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS');
        $this->successredo          =   Config::get('constants.STAGE_COLLEECTION.SUCCESS_REDO');
        $this->statusRelease        =   Config::get('constants.ACTIVEMQ_REQUEST');
        $this->senderName        	=   "Springer";
        $this->loginUserID          =   (isset(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID'));
      	
    }    
//    public function doSendjobtimereportRequest($jobID,$timesheetid,$processtype){        
//        $whArr                  =   [];
//        $getjobinfo             =   jobModel::where('JOB_ID',$jobID)->first();
//        $jobtimeinfo            =   jobTimeSheet::where('JOB_TIME_SHEET_ID',$timesheetid)->get();
//        
//        if( $jobtimeinfo->count() >=1 && $jobtimeinfo->count() >=1)
//        {
//            $jobtimeinfo=   $jobtimeinfo[0];
//            
//            $inp['JOB_TITLE']   =   trim($getjobinfo->JOB_TITLE);
//            $inp['CHECK_IN']    =   trim($jobtimeinfo->CHECK_IN);
//            $inp['LOUNGE_ID']   =   trim($jobtimeinfo->CREATED_BY);
//            $inp['DONE_BY']     =   trim($jobtimeinfo->CREATED_BY);
////            $inp['job_title']   =   $getjobinfo->JOB_TITLE;
////            $inp['job_id']      =   $getjobinfo->JOB_ID;
////            $inp['job_ref']     =   $getjobinfo->$timesheetid;
////            $inp['created_date']    =   $jobtimeinfo->CHECK_IN;
////            $params['whereClauseFieldsAnd']     =   [];
//            $params['sender']       =   $this->senderName;
//            $params['tableName']    =   $this->tablename;
//            $params['processType']  =   $processtype;
//            $params['fields']       =   $inp;
////            $params['whereClauseFieldsAnd']     =   [];
////            $params['whereClauseFieldsOr']      =   [];
////            print_r($params); exit;
////            $params['whereClauseFieldsAnd']     =   $whArr;
////            print_r($params); exit;
//            $jsonInp            =   json_encode($params);
//            $url                =   'http://172.24.191.85:8080/Exporter/Message/activemq';
//            $ch                 =   curl_init();
//            curl_setopt($ch, CURLOPT_URL, $url);
//            curl_setopt($ch, CURLOPT_POST, 1);
//            curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonInp);
//            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
//            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//            $contents           =   curl_exec($ch);
//            $headers            =   curl_getinfo($ch);
//            print_r($contents); exit;
//            curl_close($ch);
//            $result             =   array('result'=>200,'status'=>1,'errMsg'=>'Report send successfully');   
//            return $params;
//        }
//        $result                 =   array('result'=>404,'status'=>0,'errMsg'=>'Record not found');   
//        return $result;
//    }
    
    public function doActivemqRequest($inputdata){
//        $jsonencodeddata    =   json_encode($inputdata);
        $url                =   Config::get('constants.ACTIVEMQ_URL');
       // $url                =   'http://172.24.191.85:8080/Exporter/Message/activemq';
//        $ch                 =   curl_init();
//        curl_setopt($ch, CURLOPT_URL, $url);
//        curl_setopt($ch, CURLOPT_POST, 1);
//        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonencodeddata);
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        $contents           =   curl_exec($ch);
//        $headers            =   curl_getinfo($ch);
//        curl_close($ch);
//        $result             =   array('result'=>200,'status'=>1,'errMsg'=>$contents);   
////        return $result;
        $postculrinit       =   new CommonMethodsController();
        $contents           =   $postculrinit->RestfulPostcUrlExecution($inputdata,$url,true,"");
        $result             =   array('result'=>200,'status'=>1,'errMsg'=>$contents);  
        return $result;
    }
    
    public function roundStageandUserStageDetails($jobid = null,$round = null,$crudtype = null,$jbstgid = null){
		$result             =   array('result'=>200,'status'=>1,'errMsg'=>'');  
        return $result;
        if($jobid !=    null && $jbstgid != null && $crudtype != null){
            $successfileresponse    =       $this->Activemqrequesthandling($jobid,$round,$crudtype,'roundstage',$jbstgid,null);
                        //insert user stage details
            $successfileresponse    =       $this->Activemqrequesthandling($jobid,$round,$crudtype,'userstage',$jbstgid,null);
        }
    }
    
    public function roundStageandUserStageDetailsClosure($jobid = null,$round = null,$crudtype = null,$metadataid = null,$processStageID   =   null,$processType   =   null){
//        if($jobid !=    null && $round != null && $stageID != null && $processType != null  && $crudtype != null  &&  $round != Config::get('constants.ROUND_NAME.S200') && $round != Config::get('constants.ROUND_NAME.S300')){
        return true;
        if($jobid !=    null && $round != null && $stageID != null && $processType != null  && $crudtype != null){
//            
            $successfileresponse    =       $this->Activemqrequesthandling($jobid,$round,$crudtype,'roundstageclosure',$metadataid,$processStageID,$processType);
            //insert user stage details
            $successfileresponse    =       $this->Activemqrequesthandling($jobid,$round,$crudtype,'userstageclosure',$metadataid,$processStageID,$processType);
        }
    }
    
    /*public function test(){
        $type   =   "roundstage";
        // $type   =   "userstage";
        echo "<pre>";
        if($type    == "roundstage" ){
            $query     =   'SELECT j.BOOK_ID,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.STATUS as CURRENTSTATUS,js.Rollback_Remarks,js.CHECK_OUT,js.CHECK_IN,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID,js.Rollback_Remarks as REMARKS
                    FROM job_stage js
                    JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                     JOIN job j ON j.JOB_ID = jr.JOB_ID
                    JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                    LEFT OUTER
                    JOIN round_enum r ON r.ID = jr.ROUND_ID
                    LEFT OUTER
                    JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                    WHERE js. JOB_ROUND_ID IN (4508,4509,4555,4556,4628,4643,4651,4761) and js.stage_id not in (20343,20344,20345,20346,20347,20348,20349,20350,20351,20352,20353,20354,20355,20356,20357,20358,20359,20360,20361,20362,20363,20364,20365,20366,20367,20368,20369,20370,20371,20372,20373,20374,20375,20376,20377,20378,20379,20380,20381,20382,20383,20384,20385,20386,20387,20388,20389,20390,20391,20392,20393,20394,20395,20396,20397,20398,20399,20400,20401,20402,22471,20418,20419,20420,20421,20425,20426,20427,20428,20429,20430,20431,20432,20433,20434,20435,20436,20437,20438,20439,20440,20456,20457,20458,20459,20463,20464,20465,20466,20467,20468,20469,20470,20471,20472,20473,20474,20475,20476,20477,20478,21418,21419,21420,21421,21422,21423,21424,21425,21426,21427,21553,21554,21555,21556,21557,21558,21559,21560,21561,21562,20494,20495,20496,20497,20501,20502,20503,20504,20505,20506,20507,20508,20509,20510,20511,20512,20513,20514,20515,20516,21433,21434,21435,21436,21437,21438,21439,21440,21441,21442,21508,21509,21510,21511,21512,21513,21514,21515,21516,21517,21848,21849,21850,21851,21852,21853,21854,21855,21856,2185) and js.status in (23,24)';
            $chapterdataa     =   DB::select($query);
            
            $insertparams                           =   [];
            $updateparams                           =   [];
            $params                                 =   [];
            $currenttime                            =   date('Y-m-d H:i:s');
            $jobID  =   6804;
            $crudtype   =   "insert";
            $tokenkey   ="nsdfni@#df";
            $jobmilestone   =   jobRoundModel::where(['JOB_ID'=>$jobID,'ROUND_ID'=>116])->first();
            $jobdeadline    =   jobInfoModel::select(DB::Raw('STAGE_DEADLINES_COLLECTION'))->where(['JOB_ID'=>$jobID])->first();
            if(count($chapterdataa)>=1)
            {
                foreach($chapterdataa as $key=> $chapterdata){
                //insert param's
                $insertparams['FK_TITLE_ID']        =   (string)$jobID;
                $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata->METADATA_ID;
                $insertparams['PK_PRODUCTION_JOB_ROUND_ID']     =   (string)$chapterdata->JOB_ROUND_ID;
                $insertparams['FK_ROUND_ID']        =   (string)$chapterdata->ROUND_ID;
                $insertparams['FK_STAGE_ID']        =   (string)$chapterdata->STAGE_ID;
                $insertparams['IS_ACTIVE']          =   '1';
                if(count($jobmilestone)>=1)
                {
                    $insertparams['ROUND_RECEIVED_DATE']    =   (count($jobmilestone)>=1?$jobmilestone->RECEIVED_DATE:'');
                }
                if(count($jobdeadline)>=1)
                {
                    $jsondecodedate     =   json_decode($jobdeadline->STAGE_DEADLINES_COLLECTION);
                    if(isset($jsondecodedate->S200))
                    {
                        $jsondecodedate     =   str_replace('.','-',$jsondecodedate->S200);
                        $insertparams['ROUND_SCHEDULED_DATE']   =   $jsondecodedate;
                    }
                }

                $updateparams['FK_STAGE_STATUS_ID'] =   $insertparams['FK_STAGE_STATUS_ID']     =   (string)$chapterdata->CURRENTSTATUS;
                $updateparams['SUB_PROCESS_IHP']    =   $insertparams['SUB_PROCESS_IHP']        =   (string)"null";
                $updateparams['REVERTED_REMARKS']   =   $insertparams['REVERTED_REMARKS']       =   (string)$chapterdata->Rollback_Remarks;
                $insertparams['CURRENT_FLAG']       =   (string)1;
                $updateparams['CURRENT_FLAG']       =   (string)0;
                $updateparams['START_PAGE']         =   $insertparams['START_PAGE']             =   (string)"null";
                $updateparams['END_PAGE']           =   $insertparams['END_PAGE']               =   (string)"null";
                $updateparams['UPDATE_DATE']        =   $insertparams['INSERTED_DATE']          =   $currenttime;
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;

                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null' || $value     ==  ''){
                        unset($updateparams[$chapterkey]);
                    }
                }

                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null' || $value     ==  ''){
                        unset($insertparams[$chapterkey]);
                    }
                }

                $params['sender']                       =   $this->senderName;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->roundstagetable;
				$params['release']                  =   $this->statusRelease;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$chapterdata->METADATA_ID,'FK_ROUND_ID'=>(string)$chapterdata->ROUND_ID,'FK_STAGE_ID'=>(string)$chapterdata->STAGE_ID,'PK_PRODUCTION_JOB_ROUND_ID'=>(string)$chapterdata->JOB_ROUND_ID];
                    $params['sender']                   =   $this->senderName;
                    $params['tableName']                =   $this->roundstagetable;
                    $params['processType']              =   'update';
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $params['processType']              =   'update';
                }
				
				$out 	=	$this->doActivemqRequest($params);
					print_r($out);
                }
            }
        }
        
        else{
            $query     =   'SELECT j.BOOK_ID,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.STATUS as CURRENTSTATUS,js.Rollback_Remarks,js.CHECK_OUT,js.CHECK_IN,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID,js.Rollback_Remarks as REMARKS
                    FROM job_stage js
                    JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                     JOIN job j ON j.JOB_ID = jr.JOB_ID
                    JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                    LEFT OUTER
                    JOIN round_enum r ON r.ID = jr.ROUND_ID
                    LEFT OUTER
                    JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                    WHERE js. JOB_ROUND_ID IN (4506,4507,4573,4629,4650,4703,4782,4508,4509,4555,4556,4628,4643,4651,4761,4510,4511,4557,4558,4635,4652,4763,4512,4513,4559,4560,4634,4653,4765,4514,4515,4561,4562,4637,4654,4767,4516,4517,4563,4564,4638,4655,4769,4518,4519,4565,4566,4636,4656,4771,4520,4521,4567,4568,4646,4657,4772,4522,4523,4569,4570,4647,4658,4773,4524,4525,4571,4572,4639,4659,4774,4526,4527,4546,4547,4640,4660,4775,4528,4529,4548,4549,4648,4661,4776,4530,4531,4550,4551,4641,4662,4777,4778,4532,4533,4552,4553,4642,4645,4663,4779,4534,4535,4554,4644,4664,4780,4536,4537,4574,4649,4665,4762,4538,4539,4576,4633,4666,4764,4540,4541,4575,4632,4667,4766,4542,4543,4577,4630,4668,4768,4544,4545,4578,4631,4669,4770,4502,4503,4504,4505,4760,4785,4670,4783,4702,4784) and js.stage_id not in (20343,20344,20345,20346,20347,20348,20349,20350,20351,20352,20353,20354,20355,20356,20357,20358,20359,20360,20361,20362,20363,20364,20365,20366,20367,20368,20369,20370,20371,20372,20373,20374,20375,20376,20377,20378,20379,20380,20381,20382,20383,20384,20385,20386,20387,20388,20389,20390,20391,20392,20393,20394,20395,20396,20397,20398,20399,20400,20401,20402,22471,20418,20419,20420,20421,20425,20426,20427,20428,20429,20430,20431,20432,20433,20434,20435,20436,20437,20438,20439,20440,20456,20457,20458,20459,20463,20464,20465,20466,20467,20468,20469,20470,20471,20472,20473,20474,20475,20476,20477,20478,21418,21419,21420,21421,21422,21423,21424,21425,21426,21427,21553,21554,21555,21556,21557,21558,21559,21560,21561,21562,20494,20495,20496,20497,20501,20502,20503,20504,20505,20506,20507,20508,20509,20510,20511,20512,20513,20514,20515,20516,21433,21434,21435,21436,21437,21438,21439,21440,21441,21442,21508,21509,21510,21511,21512,21513,21514,21515,21516,21517,21848,21849,21850,21851,21852,21853,21854,21855,21856,2185) and js.status in (23,24)';
            $chapterdataa     =   DB::select($query);
            $jobID  =   6804;
            $tokenkey   ="nsdfni@#df";
            $crudtype   =   "insert";
//            print_r($chapterdataa); exit;
            $insertparams                           =   [];
            $updateparams                           =   [];
            $params                                 =   [];
            $currenttime                            =   date('Y-m-d H:i:s');
            if(count($chapterdataa)>=1)
            {
                foreach($chapterdataa as $chapterdata){
                    //insert param's
                    $insertparams['PK_PRODUCTION_JOB_WORKLOG_ID']   =   (string)$chapterdata->JOB_STAGE_ID;
                    $insertparams['FK_TITLE_ID']        =   (string)$jobID;
                    $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata->METADATA_ID;
                    $wheredata                          =   ['P_METADATA_ID'=>$chapterdata->METADATA_ID,'JOB_ID'=>$jobID,'JOB_STAGE_ID'=>$chapterdata->JOB_STAGE_ID];
                    $jobresourceget                     =   jobResource::select(DB::Raw('CREATED_BY'))->where($wheredata)->first();
                    $insertparams['FK_USER_ID']         =   (count($jobresourceget)>=1?$jobresourceget->CREATED_BY:Config::get('constants.ADMIN_USER_ID'));
                    $insertparams['FK_DEPARTMENT_ID']   =   (string)1;
                    $insertparams['FK_ROUND_ID']        =   (string)$chapterdata->ROUND_ID;
                    $insertparams['FK_STAGE_ID']        =   (string)$chapterdata->STAGE_ID;
                    $insertparams['IHP_DETAILS']        =   (string)"null";
                    $insertparams['IS_ACTIVE']          =   (string)'1';
                    $updateparams['PAGES']              =   $insertparams['PAGES']                  =   ($chapterdata->OUTPUT_QUANTITY !=   ''?(string)$chapterdata->OUTPUT_QUANTITY:(string)'null');
                    $insertparams['START_TIME']         =   (string)$chapterdata->CHECK_OUT;
                    $updateparams['END_TIME']           =   ($chapterdata->CHECK_IN !=   ''?(string)$chapterdata->CHECK_IN:(string)'null');
                    $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']          =   $currenttime;
                    $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;
        //                
                    foreach($updateparams as $chapterkey=>$value){
                        if($value     ==  'null' || $value     ==  ''){
                            unset($updateparams[$chapterkey]);
                        }
                    }

                    foreach($insertparams as $chapterkey=>$value){
                        if($value     ==  'null' || $value     ==  ''){
                            unset($insertparams[$chapterkey]);
                        }
                    }

                    $params['sender']                       =   $this->senderName;
                    $params['id']                           =   $tokenkey;
                    $params['tableName']                    =   $this->userstagetable;
					$params['release']                  =   $this->statusRelease;
                    if($crudtype    ==  "insert")
                    {
                        $params['processType']              =   'insert';
                        $params['fields']                   =   [$insertparams];
                    }
                    else if($crudtype    ==  "update")
                    {
                        $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$chapterdata[0]->METADATA_ID,'FK_ROUND_ID'=>(string)$chapterdata[0]->ROUND_ID,'FK_STAGE_ID'=>(string)$chapterdata[0]->STAGE_ID,'PK_PRODUCTION_JOB_WORKLOG_ID'=>(string)$chapterdata[0]->JOB_STAGE_ID];
                        $params['sender']                   =   $this->senderName;
                        $params['tableName']                =   $this->userstagetable;
                        $params['processType']              =   'update';
                        $params['fields']                   =   [$updateparams];
                        $params['whereClauseFieldsAnd']     =   $updatedata;
                        $params['processType']              =   'update';
                    }
                    $out 	=	$this->doActivemqRequest($params);
                    print_r($out);
                }
            }
        }
    }*/
    
    public function Activemqrequesthandling($jobID,$roundID     =   null, $crudtype,$typeofrequest = null ,$jobstageIdormetadataID  =   null,$processStageID   =   null,$processType = null)
    {
        $cmn_obj                    =   new CommonMethodsController();
        $tokenkey                   =   $cmn_obj->generateRandomString( 16 , 'api_activemq_log' ,'TOKEN'); 
        $activemqdata['TOKEN']      =   $tokenkey;
        if(strpos($jobstageIdormetadataID,"-") !== false){
            $stageid    =   explode('-',$jobstageIdormetadataID);
            $activemqdata['STAGE']      =   $stageid[1];
            $metadataID =   $stageid[0];
        }else{
            $activemqdata['STAGE']      =   $jobstageIdormetadataID;
            $metadataID =   $jobstageIdormetadataID;
        }
        // if process request check file upload or clientack 
        if(!empty($processType)){
            $checkouttime           =   "";
            $checkinouttime         =   "";
            if(empty($metaid)){
                $checkinouttime     =   apiClientAcknowledgement::select(DB::Raw('STATUS,END_TIME'))->where(['JOB_ID'=>$jobID,'ROUND'=>$roundID,'PROCESS_TYPE_DIFF'=>$processType])->orderBy('ID','desc')->first();
            }else{
                $checkinouttime     =   apiClientAcknowledgement::select(DB::Raw('STATUS,END_TIME'))->where(['JOB_ID'=>$jobID,'ROUND'=>$roundID,'METADATA_ID'=>$metadataID,'PROCESS_TYPE_DIFF'=>$processType])->orderBy('ID','desc')->first();
            }
            $wherefield     =   ['JOB_ID'=>$jobID,'ROUND'=>$roundID,'PROCESS_TYPE'=>$processType];
            $checkouttime       =   apiFileUpload::select(DB::Raw('STATUS,END_TIME'))->where($wherefield)->orderBy('ID','desc')->first();
        }
        
        $activemqdata['CREATED_DATE']   =   Carbon::now();
        switch(strtolower($typeofrequest))
        {
            case 'download':
            $inputparams    =   $this->activemqdownloadrequest($jobID,$roundID,$crudtype,$tokenkey);
            if($crudtype    ==  "insert" && count($inputparams)>=1)
            {
                // insert activemq request
                $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                $storedata                  =   apiActivemqModel::insertGetId($activemqdata);
                $pentahooutput  =   $this->doActivemqRequest($inputparams);
                $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                if(count($pentahooutput)>=1)
                {
                    $bookdata                           =   jobModel::getJobdetails($jobID);
                    $inputofwork['FK_TITLE_ID']         =   $jobID;
                    $inputofwork['SUB_CLASSIFICATION']  =   ($bookdata->COPY_EDITING_LEVEL     ==  ''?"null":$bookdata->COPY_EDITING_LEVEL);
                    $inputofwork['INSERTED_DATE']       =   date('Y-m-d H:i:s');
                    $inputofwork['IS_ACTIVE']           =   '1';
                    $inputofwork['INSERTED_BY_USER_ID'] =   $this->loginUserID;
                    $params['sender']                   =   $this->senderName;
					$params['release']                  =   $this->statusRelease;
                    $params['id']                       =   $tokenkey;
                    $params['tableName']                =   $this->titleworkmastertable;
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$inputofwork];
                    $output         =   $this->doActivemqRequest($params);
                }
            }
            
            if($crudtype    ==  "update" && count($inputparams)>=1)
            {
                $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                $storedata                  =   apiActivemqModel::insertGetId($activemqdata);
                $pentahooutput  =   $this->doActivemqRequest($inputparams);
                $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                if(count($pentahooutput)>=1)
                {
                    $bookdata                           =   jobModel::getJobdetails($jobID);
    //              $inputofwork['WORK_CLASSIFICATION'] =   ($bookdata->COPY_EDITING_LEVEL     ==  ''?"null":$bookdata->COPY_EDITING_LEVEL);
                    $updateparams['SUB_CLASSIFICATION'] =   ($bookdata->COPY_EDITING_LEVEL     ==  ''?"null":$bookdata->COPY_EDITING_LEVEL);
                    $updateparams['UPDATE_DATE']        =   date('Y-m-d H:i:s');
                    $updateparams['UPDATED_BY_USER_ID'] =   $this->loginUserID;
                    
                    $updatedata                         =   ['IS_ACTIVE'=>'1','FK_TITLE_ID'=>$jobID];
                    $params['sender']                   =   $this->senderName;
					$params['release']                  =   $this->statusRelease;
                    $params['tableName']                =   $this->titleworkmastertable;
                    $params['processType']              =   'update';
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $output         =   $this->doActivemqRequest($params);
                }
            }
            break;
            case 'chapter':
            $chapterdata                            =   taskLevelMetadataModel::getMetadatadetailsJob($jobID);
            if(count($chapterdata)>=1)
            {
                foreach($chapterdata as $key=>$chapterid)
                {
                    $inputparams    =   $this->activemqChapterrequest($jobID,$chapterid->METADATA_ID,$roundID,$crudtype,$tokenkey);
                    if(count($inputparams)>=1)
                    {   
                        // insert activemq request
                        $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                        $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                        $pentahooutput      =   $this->doActivemqRequest($inputparams);
                        $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                    } 
                }
            }
            
            break; 
            
            case 'bookunitmeasurechapter':
                
                $inputparams    =   $this->activemqBookChapterrequest($jobID,$roundID,$crudtype,$tokenkey);
                if(count($inputparams)>=1)
                {   
                    // insert activemq request
                    $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                    $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                    $pentahooutput      =   $this->doActivemqRequest($inputparams);
                    $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                }
            break; 
            
            case 'roundstage':
                $inputparams    =   $this->activemqRoundStagedetailsrequest($jobID,'',$roundID,$crudtype,$tokenkey,$jobstageIdormetadataID);
                if(count($inputparams)>=1)
                {
                    $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                    $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                    $pentahooutput      =   $this->doActivemqRequest($inputparams);
                    $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                }
            break; 
            case 'userstage':
                $inputparams    =   $this->activemqUserStagedetailsrequest($jobID,'',$roundID,$crudtype,$tokenkey,$jobstageIdormetadataID);
                if(count($inputparams)>=1)
                {
                    $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                    $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                    $pentahooutput      =   $this->doActivemqRequest($inputparams);
                    $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                }
            break;
            case 'roundstageclosure':
                $inputparams    =   $this->activemqRoundStagedetailsClosurerequest($jobID,$jobstageIdormetadataID,$roundID,$crudtype,$tokenkey,$processStageID,$checkouttime,$checkinouttime);
                if(count($inputparams)>=1)
                {
                    $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                    $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                    $pentahooutput      =   $this->doActivemqRequest($inputparams);
                    $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                }
            break;
            case 'userstageclosure':
                $inputparams    =   $this->activemqUserStagedetailsClosurerequest($jobID,$jobstageIdormetadataID,$roundID,$crudtype,$tokenkey,$processStageID,$checkouttime,$checkinouttime);
                if(count($inputparams)>=1)
                {
                    $activemqdata['REQUEST_LOG']   = json_encode($inputparams);
                    $storedata          =   apiActivemqModel::insertGetId($activemqdata);
                    $pentahooutput      =   $this->doActivemqRequest($inputparams);
                    $this->activeMqRequestServerreachedornot($pentahooutput,$storedata);
                }
            break;
        }
        
//        $activemqdata['TOKEN']      =   $tokenkey;
//        $activemqdata['JOB_ID']     =   "5455";
//        $activemqdata['ROUND']      =   "104";
//        $activemqdata['CREATED_DATE']   =   date('y-m-d H:m:s');
//        $storedata                  =   apiActivemqModel::insertGetId($activemqdata);
//        $whArr                      =   [];
//        $inp['USER_NAME']           =   'Vinoth.T';
//        $inp['REPORTING_TO']        =   '1252';
//        $inp['UPDATED_BY_USER_ID']  =   "25";
//        $inp['UPDATE_DATE']         =   "2018-06-26 12:20:10";
//        $inp['TEAM_ID']             =   "2";
//        $updatedata                 =   ['IS_ACTIVE'=>'1','PK_USER_ID'=>'1'];
//        $params['sender']           =   $this->senderName;
//        $params['tableName']        =   'user_master';
//        $params['processType']      =   'update';
//        $params['fields']           =   $inp;
//        $params['whereClauseFieldsAnd']     =   $updatedata;
    }
    
	public function addNewuser(){
		$cmn_obj                    =   new CommonMethodsController();
        $tokenkey                   =   $cmn_obj->generateRandomString( 16 , 'api_activemq_log' ,'TOKEN'); 
		$emp 	=	DB::select("
						select u.*,ut.TEAM_ID,t.TEAM_HEAD from user u
						left join user_team_map ut on ut.USER_ID = u.USER_ID
						left join team t on t.TEAM_ID = ut.TEAM_ID
						 where u.USER_ID in ('')");				 
		foreach($emp as $value){
			$inp['EMP_ID']        	=   $value->EMPLOYEE_ID;
			$inp['PK_USER_ID']  	=   $value->USER_ID;
			$inp['INSERTED_DATE']   =   "2020-01-26 12:20:10";
			$inp['TEAM_ID']         =   $value->TEAM_ID;
			$inp['FIRST_NAME']      =   $value->FIRST_NAME;
			$inp['LAST_NAME']       =   $value->LAST_NAME;
			$inp['EMAIL_ID']        =   $value->EMAIL;
			$inp['REPORTING_TO']    =   $value->TEAM_HEAD;
			$inp['IS_ACTIVE']       =   "1";
			$params['sender']       =   $this->senderName;
			
			// $params['id']         		=   $tokenkey;
			$params['release']      =   $this->statusRelease;
			$params['tableName']    =   'user_master';
			$params['processType']  =   'insert';
			foreach($inp as $chapterkey=>$val){
					if($val     ==  'null' || empty($val)){
						unset($inp[$chapterkey]);
					}
			}
			$params['fields']           =   [$inp];
			$output         =   $this->doActivemqRequest($params);
			echo "<pre>";
			print_r($output);//exit;
		}
	}
	
	public function updateTilteinformation(){
		$cmn_obj                    =   new CommonMethodsController();
        $tokenkey                   =   $cmn_obj->generateRandomString( 16 , 'api_activemq_log' ,'TOKEN'); 
		$emp 	=	DB::select("select ji.JOB_ID,ji.AM,ji.AM_NAME from job_info ji where ji.AM in ()");
		echo "<pre>";
		foreach($emp as $value){
			$updateparams['ACCOUNT_MANAGER_ID'] 	=	($value->AM ==  ''?"null":$value->AM);
            $updateparams['ACCOUNT_MANAGER_NAME']   =   ($value->AM_NAME             ==  ''?"null":$value->AM_NAME);
			$updatedata                         =   ['IS_ACTIVE'=>'1','PK_TITLE_ID'=>$value->JOB_ID];
            $params['tableName']                =   $this->titlemastertable;
            $params['whereClauseFieldsAnd']     =   $updatedata;
			$params['sender']       =   $this->senderName;
			
			// $params['id']         		=   $tokenkey;
			$params['release']      =   $this->statusRelease;
			$params['tableName']    =   'title_master';
			$params['processType']  =   'update';
			foreach($updateparams as $chapterkey=>$val){
					if($val     ==  'null' || empty($val)){
						unset($updateparams[$chapterkey]);
					}
			}
			
            $params['fields']                   =   [$updateparams];
			$output         =   $this->doActivemqRequest($params);
			echo "<pre>";
			print_r($output);//exit;
		}
	}
	
	public function addNewjob(){
		$cmn_obj                    =   new CommonMethodsController();
        $tokenkey                   =   $cmn_obj->generateRandomString( 16 , 'api_activemq_log' ,'TOKEN'); 
		$jobdetails 	=	DB::select("
						select j.*,ji.* from job j
						join job_info ji on ji.JOB_ID = j.JOB_ID
						 where j.JOB_ID in (6807,6783,6782,6781,6649,6642)");		
						 
		foreach($jobdetails as $bookdata){
			
            //insert param's
            $insertparams['PK_TITLE_ID']            =   $bookdata->JOB_ID;
            $insertparams['TITLE_ACRONYM_BOOK_ID']  =   $bookdata->JOURNAL_ACRONYM;
            $insertparams['ISBN']                   =   $bookdata->ISSN_ONLINE;
            $insertparams['JOB_ID']                 =   $bookdata->JOB_ID;
            $insertparams['TITLE_NAME']             =   $bookdata->JOB_TITLE;
            $insertparams['RECEIVED_DATE']          =   $bookdata->CREATED_DATE;
            $insertparams['TITLE_STATUS']           =   "1";
            $insertparams['INSERTED_DATE']          =   date('Y-m-d H:i:s');
            $insertparams['IS_ACTIVE']              =   '1';
            $insertparams['INSERTED_BY_USER_ID']    =   Config::get('constants.ADMIN_USER_ID');
            $updateparams['ACCOUNT_MANAGER_ID'] 	=	$insertparams['ACCOUNT_MANAGER_ID']     =   ($bookdata->AM                  ==  ''?"null":$bookdata->AM);
            $updateparams['ACCOUNT_MANAGER_NAME']   =   $insertparams['ACCOUNT_MANAGER_NAME']   =   ($bookdata->AM_NAME             ==  ''?"null":$bookdata->AM_NAME);
            $insertparams['TITLE_AUTHOR']           =   ($bookdata->AUTHOR_NAME         ==  ''?"null":$bookdata->AUTHOR_NAME);
            $insertparams['PUBLISHER']              =   ($bookdata->PUBLISHER_NAME      ==  ''?"null":$bookdata->PUBLISHER_NAME);
            $insertparams['PUBLISHER_LOCATION']     =   ($bookdata->PUBLISHER_LOCATION  ==  ''?"null":$bookdata->PUBLISHER_LOCATION);
            $insertparams['PROJECT_TYPE']           =   ($bookdata->PROJECT_TYPE        ==  ''?"null":$bookdata->PROJECT_TYPE);
            $insertparams['TITLE_TYPE']             =   ($bookdata->JOB_TYPE            ==  ''?"null":$bookdata->JOB_TYPE);
            //update param's
            $updateparams['VOLUME']                 =   ($bookdata->BOOK_MULTI_VOLUME_COUNT     ==  ''?"null":$bookdata->BOOK_MULTI_VOLUME_COUNT);
//            $updateparams['TYPE_SET_PAGES']        =   "null";
//            $updateparams['PROJECT']               =   "null";
//            $updateparams['EST_PAGES']             =   "null";
            $updateparams['WORKFLOW_ID']            =   ($bookdata->WORKFLOW_TYPE     ==  ''?"null":$bookdata->WORKFLOW_TYPE);
            $updateparams['SPI_CONTACT_ID']         =   ($bookdata->PM     ==  ''?"null":$bookdata->PM);
            $getpmname                              =   downloadModel::getUserDetails($updateparams['SPI_CONTACT_ID']);
            if(count($getpmname)>=1)
            {
                $updateparams['SPI_CONTACT_NAME']   =   ($getpmname->userName   ==  ''?"null":$getpmname->userName);
            }            
            $updateparams['SOFTWARE']               =   ($bookdata->APPLICATION     ==  ''?"null":$bookdata->APPLICATION);
//            $updateparams['PUBLISHER_CONTACT']     =   ($bookdata->BOOK_MULTI_VOLUME_COUNT     ==  ''?"null":$bookdata->BOOK_MULTI_VOLUME_COUNT);
            $updateparams['TITLE_CATEGORY']         =   ($bookdata->EPROOFING_SYSTEM     ==  ''?"null":$bookdata->EPROOFING_SYSTEM);
            $updateparams['PUBLISHER_LOCATION']     =   $bookdata->PUBLISHER_LOCATION;
            $updateparams['UPDATE_DATE']            =   date('Y-m-d H:i:s');
            $updateparams['IS_ACTIVE']              =   '1';
            $updateparams['UPDATED_BY_USER_ID']     =   $this->loginUserID;
                            
            foreach($insertparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($insertparams[$chapterkey]);
                }
            }
                
            $params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
            $params['id']                           =   $tokenkey;
            $params['tableName']                    =   $this->titlemastertable;
            $params['processType']              =   'insert';
            $params['fields']                   =   [$insertparams];
			$output         =   $this->doActivemqRequest($params);
			echo "<pre>";
			print_r($output);//exit;
		}
	}
	
	public function addNewchapter(){
		$cmn_obj                    =   new CommonMethodsController();
        $tokenkey                   =   $cmn_obj->generateRandomString( 16 , 'api_activemq_log' ,'TOKEN'); 
		$chapterdata 	=	DB::select("
						select tlm.METADATA_ID,tlm.CHAPTER_NO,j.JOB_ID,ji.doi as DOIN_NUMBER,tlm.CHAPTER_NAME,mi.NO_MSP,mi.DOI,tlm.CREATED_DATE,mi.PAGE_COUNT_BY_WORDS,mi.SPICAST_BLANKS,j.BOOK_ID from task_level_metadata tlm
						join metadata_info mi on mi.METADATA_ID = tlm.METADATA_ID
						join job j on j.job_id = tlm.job_id join job_info ji on ji.JOB_ID = j.JOB_ID
						 where j.JOB_ID in ('')");	
		echo "<pre>";
		
		foreach($chapterdata as $key=>$chapter)
		{
			$bookQuery                          =   $this->getQueryCountByJob($chapter->BOOK_ID);
			//insert param's
			$insertparams['FK_TITLE_ID']        =   $chapter->JOB_ID;
			$insertparams['PK_CHAPTER_ID']      =   $chapter->METADATA_ID;
			$insertparams['CHAPTER_NUMBER']     =   ($chapter->CHAPTER_NO     ==  ''?'null':$chapter->CHAPTER_NO);
			$insertparams['CHAPTER_NAME']       =   ($chapter->CHAPTER_NAME     ==  ''?'null':$chapter->CHAPTER_NAME);
			if(in_array(substr(strtolower($chapter->CHAPTER_NO),0,2),Config::get('constants.READ_TYPEOF_PART')))
			{
				$insertparams['CHAPTER_TYPE']   =   "PART";
			}
			else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.FRONT_MATTER') !== false))
			{
				$insertparams['CHAPTER_TYPE']   =   "FM";
			}
			else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.BACK_MATTER') !== false))
			{
				$insertparams['CHAPTER_TYPE']   =   "BM";
			}
			else
			{
				$insertparams['CHAPTER_TYPE']   =   "CHAPTER";
			}
			$checkartdata                       =   taskLevelArtMetadataModel::where('METADATA_ID',$chapter->METADATA_ID)->first();
			$insertparams['IS_ACTIVE']          =   "1";
			$insertparams['CHAPTER_FILE_LINK']  =   'Yes';
			$insertparams['DOI_NUMBER']         =   ($chapter->DOIN_NUMBER != null?$chapter->DOIN_NUMBER:'null');
			$updateparams['MS_PAGES']           =   $insertparams['MS_PAGES']           =   ($chapter->NO_MSP     ==  ''?'null':$chapter->NO_MSP);
//                $updateparams['TS_PAGES']           =   $insertparams['TS_PAGES']           =   ($chapter->BLANK_PAGE     ==  ''?'null':$chapter->BLANK_PAGE);
			$updateparams['CE_ESTIMATION_PAGES']=   $insertparams['CE_ESTIMATION_PAGES']=   ($chapter->PAGE_COUNT_BY_WORDS     ==  ''?'null':$chapter->PAGE_COUNT_BY_WORDS);
			$updateparams['FIGURE_FILE_LINK']   =   $insertparams['FIGURE_FILE_LINK']   =   (count($checkartdata)>=1?'Yes':'No');
			$updateparams['FIGURE_LINKED_DATE'] =   $insertparams['FIGURE_LINKED_DATE'] =   "null";
			$updateparams['FIGURE_LINKED_BY_USER_ID']   =   $insertparams['FIGURE_LINKED_BY_USER_ID']   =   "null";
			$updateparams['BLANK_PAGES']        =   $insertparams['BLANK_PAGES']                =   ($chapter->SPICAST_BLANKS     ==  ''?'null':$chapter->SPICAST_BLANKS);
			$insertparams['CHAPTER_LINKED_DATE']=   ($chapter->CREATED_DATE     ==  ''?'null':$chapter->CREATED_DATE);
			$updateparams['DOI_NUMBER']         =   $insertparams['DOI_NUMBER']                 =   ($chapter->DOI     ==  ''?'null':$chapter->DOI);
			$updateparams['ART_STATUS']         =   $insertparams['ART_STATUS']                 =   (count($checkartdata)>=1?'1':'0');
			$updateparams['OPEN_QUERY_CNT']     =   $insertparams['OPEN_QUERY_CNT']             =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'open');
			$updateparams['CLOSED_QUERY_CNT']   =   $insertparams['CLOSED_QUERY_CNT']           =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'close');
			$updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']              =   date('Y-m-d H:i:s');
			$updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']        =   $this->loginUserID;
			
			foreach($updateparams as $chapterkey=>$value){
				if($value     ==  'null' || empty($value)){
					unset($updateparams[$chapterkey]);
				}
			}
			
			foreach($insertparams as $chapterkey=>$value){
				if($value     ==  'null' || empty($value)){
					unset($insertparams[$chapterkey]);
				}
			}
			
			$params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
			$params['id']                           =   $tokenkey;
			$params['tableName']                    =   $this->chaptermastertable;
			$params['processType']              =   'insert';
			$params['fields']                   =   [$insertparams];
			$output         =   $this->doActivemqRequest($params);
			echo "<pre>";
			print_r($output);//exit;
		}
	}
    
    public function activeMqRequestServerreachedornot($response,$lastId){
        $updatedata     =   ['SERVER_REQUEST_STATUS'=>'3'];
        $wheredata      =   ['ID'=>$lastId];
        if(count($response)>=1){
            if(isset($response['status']) && $response['status']    ==  1 && isset($response['errMsg']) && count($response['errMsg'])>=1){
                if($response['errMsg']['http_code'] !=  200){
                    apiActivemqModel::where($wheredata)->update($updatedata);
                }
            }else{
                apiActivemqModel::where($wheredata)->update($updatedata);
            }
        }

    }
        
        
    public function activemqdownloadrequest($jobID,$roundID,$crudtype,$tokenkey)
    {   
        $whArr                                  =   [];
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $bookdata                               =   jobModel::getJobdetails($jobID);
        if(count($bookdata)>=1)
        {
            //insert param's
            $insertparams['PK_TITLE_ID']            =   $bookdata->JOB_ID;
            $insertparams['TITLE_ACRONYM_BOOK_ID']  =   $bookdata->JOURNAL_ACRONYM;
            $insertparams['ISBN']                   =   $bookdata->ISSN_ONLINE;
            $insertparams['JOB_ID']                 =   $bookdata->JOB_ID;
            $insertparams['TITLE_NAME']             =   $bookdata->JOB_TITLE;
            $insertparams['RECEIVED_DATE']          =   $bookdata->CREATED_DATE;
            $insertparams['TITLE_STATUS']           =   "1";
            $insertparams['INSERTED_DATE']          =   date('Y-m-d H:i:s');
            $insertparams['IS_ACTIVE']              =   '1';
            $insertparams['INSERTED_BY_USER_ID']    =   Config::get('constants.ADMIN_USER_ID');
            $updateparams['ACCOUNT_MANAGER_ID'] 	=	$insertparams['ACCOUNT_MANAGER_ID']     =   ($bookdata->AM                  ==  ''?"null":$bookdata->AM);
            $updateparams['ACCOUNT_MANAGER_NAME']   =   $insertparams['ACCOUNT_MANAGER_NAME']   =   ($bookdata->AM_NAME             ==  ''?"null":$bookdata->AM_NAME);
            $insertparams['TITLE_AUTHOR']           =   ($bookdata->AUTHOR_NAME         ==  ''?"null":$bookdata->AUTHOR_NAME);
            $insertparams['PUBLISHER']              =   ($bookdata->PUBLISHER_NAME      ==  ''?"null":$bookdata->PUBLISHER_NAME);
            $insertparams['PUBLISHER_LOCATION']     =   ($bookdata->PUBLISHER_LOCATION  ==  ''?"null":$bookdata->PUBLISHER_LOCATION);
            $insertparams['PROJECT_TYPE']           =   ($bookdata->PROJECT_TYPE        ==  ''?"null":$bookdata->PROJECT_TYPE);
            $insertparams['TITLE_TYPE']             =   ($bookdata->JOB_TYPE            ==  ''?"null":$bookdata->JOB_TYPE);
            //update param's
            $updateparams['VOLUME']                 =   ($bookdata->BOOK_MULTI_VOLUME_COUNT     ==  ''?"null":$bookdata->BOOK_MULTI_VOLUME_COUNT);
//            $updateparams['TYPE_SET_PAGES']        =   "null";
//            $updateparams['PROJECT']               =   "null";
//            $updateparams['EST_PAGES']             =   "null";
            $updateparams['WORKFLOW_ID']            =   ($bookdata->WORKFLOW_TYPE     ==  ''?"null":$bookdata->WORKFLOW_TYPE);
            $updateparams['SPI_CONTACT_ID']         =   ($bookdata->PM     ==  ''?"null":$bookdata->PM);
            $getpmname                              =   downloadModel::getUserDetails($updateparams['SPI_CONTACT_ID']);
            if(count($getpmname)>=1)
            {
                $updateparams['SPI_CONTACT_NAME']   =   ($getpmname->userName   ==  ''?"null":$getpmname->userName);
            }            
            $updateparams['SOFTWARE']               =   ($bookdata->APPLICATION     ==  ''?"null":$bookdata->APPLICATION);
//            $updateparams['PUBLISHER_CONTACT']     =   ($bookdata->BOOK_MULTI_VOLUME_COUNT     ==  ''?"null":$bookdata->BOOK_MULTI_VOLUME_COUNT);
            $updateparams['TITLE_CATEGORY']         =   ($bookdata->EPROOFING_SYSTEM     ==  ''?"null":$bookdata->EPROOFING_SYSTEM);
            $updateparams['PUBLISHER_LOCATION']     =   $bookdata->PUBLISHER_LOCATION;
            $updateparams['UPDATE_DATE']            =   date('Y-m-d H:i:s');
            $updateparams['IS_ACTIVE']              =   '1';
            $updateparams['UPDATED_BY_USER_ID']     =   $this->loginUserID;
            
            foreach($updateparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($updateparams[$chapterkey]);
                }
            }
                
            foreach($insertparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($insertparams[$chapterkey]);
                }
            }
                
            $params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
            $params['id']                           =   $tokenkey;
            $params['tableName']                    =   $this->titlemastertable;
            if($crudtype    ==  "insert")
            {
                $params['processType']              =   'insert';
                $params['fields']                   =   [$insertparams];
            }
            else if($crudtype    ==  "update")
            {
                $updatedata                         =   ['IS_ACTIVE'=>'1','PK_TITLE_ID'=>$jobID];
                $params['tableName']                =   $this->titlemastertable;
                $params['fields']                   =   [$updateparams];
                $params['whereClauseFieldsAnd']     =   $updatedata;
                $params['processType']              =   'update';
            }
        }
        return $params;
    }
    
    public function activemqChapterrequest($jobID,$metaid,$roundID,$crudtype,$tokenkey)
    {   
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $callchapterdata                        =   new taskLevelMetadataModel();
        $chapterdata                            =   $callchapterdata->getTaskLevelDetails($metaid);
        $bookdata                               =   jobModel::getJobdetailsRawQuery($jobID,'job.BOOK_ID,job_info.DOI');
        if(count($chapterdata)>=1)
        {
            $bookQuery                          =   $this->getQueryCountByJob(($bookdata != null?$bookdata->BOOK_ID:'') );
            foreach($chapterdata as $key=>$chapter)
            {
                //insert param's
                $insertparams['FK_TITLE_ID']        =   $jobID;
                $insertparams['PK_CHAPTER_ID']      =   $chapter->METADATA_ID;
                $insertparams['CHAPTER_NUMBER']     =   ($chapter->CHAPTER_NO     ==  ''?'null':$chapter->CHAPTER_NO);
                $insertparams['CHAPTER_NAME']       =   ($chapter->CHAPTER_NAME     ==  ''?'null':$chapter->CHAPTER_NAME);
                if(in_array(substr(strtolower($chapter->CHAPTER_NO),0,2),Config::get('constants.READ_TYPEOF_PART')))
                {
                    $insertparams['CHAPTER_TYPE']   =   "PART";
                }
                else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.FRONT_MATTER') !== false))
                {
                    $insertparams['CHAPTER_TYPE']   =   "FM";
                }
                else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.BACK_MATTER') !== false))
                {
                    $insertparams['CHAPTER_TYPE']   =   "BM";
                }
                else
                {
                    $insertparams['CHAPTER_TYPE']   =   "CHAPTER";
                }
                $checkartdata                       =   taskLevelArtMetadataModel::where('METADATA_ID',$chapter->METADATA_ID)->first();
                $insertparams['IS_ACTIVE']          =   "1";
                $insertparams['CHAPTER_FILE_LINK']  =   'Yes';
                $insertparams['DOI_NUMBER']         =   ($bookdata != null?$bookdata->DOI:'null');
                $updateparams['MS_PAGES']           =   $insertparams['MS_PAGES']           =   ($chapter->NO_MSP     ==  ''?'null':$chapter->NO_MSP);
//                $updateparams['TS_PAGES']           =   $insertparams['TS_PAGES']           =   ($chapter->BLANK_PAGE     ==  ''?'null':$chapter->BLANK_PAGE);
                $updateparams['CE_ESTIMATION_PAGES']=   $insertparams['CE_ESTIMATION_PAGES']=   ($chapter->PAGE_COUNT_BY_WORDS     ==  ''?'null':$chapter->PAGE_COUNT_BY_WORDS);
                $updateparams['FIGURE_FILE_LINK']   =   $insertparams['FIGURE_FILE_LINK']   =   (count($checkartdata)>=1?'Yes':'No');
                $updateparams['FIGURE_LINKED_DATE'] =   $insertparams['FIGURE_LINKED_DATE'] =   "null";
                $updateparams['FIGURE_LINKED_BY_USER_ID']   =   $insertparams['FIGURE_LINKED_BY_USER_ID']   =   "null";
                $updateparams['BLANK_PAGES']        =   $insertparams['BLANK_PAGES']                =   ($chapter->SPICAST_BLANKS     ==  ''?'null':$chapter->SPICAST_BLANKS);
                $insertparams['CHAPTER_LINKED_DATE']=   ($chapter->CREATED_DATE     ==  ''?'null':$chapter->CREATED_DATE);
                $updateparams['DOI_NUMBER']         =   $insertparams['DOI_NUMBER']                 =   ($chapter->DOI     ==  ''?'null':$chapter->DOI);
                $updateparams['ART_STATUS']         =   $insertparams['ART_STATUS']                 =   (count($checkartdata)>=1?'1':'0');
                $updateparams['OPEN_QUERY_CNT']     =   $insertparams['OPEN_QUERY_CNT']             =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'open');
                $updateparams['CLOSED_QUERY_CNT']   =   $insertparams['CLOSED_QUERY_CNT']           =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'close');
                $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']              =   date('Y-m-d H:i:s');
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']        =   $this->loginUserID;
                
                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($updateparams[$chapterkey]);
                    }
                }
                
                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($insertparams[$chapterkey]);
                    }
                }
                
                $params['sender']                       =   $this->senderName;
				$params['release']                  	=   $this->statusRelease;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->chaptermastertable;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'PK_CHAPTER_ID'=>(string)$chapter->METADATA_ID];
                    $params['tableName']                =   $this->chaptermastertable;
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $params['processType']              =   'update';
                }
            }
        }
        return $params;
    }
    
    public function activemqBookChapterrequest($jobID,$roundID,$crudtype,$tokenkey)
    {   
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $callchapterdata                        =   new taskLevelMetadataModel();
        $chapterdata                            =   $callchapterdata->getUnitMeasureChapterLevelDetails();
        $bookdata                               =   jobModel::getJobdetailsRawQuery($jobID,'job_info.DOI');
        if(count($chapterdata)>=1)
        {
            $bookQuery                          =   $this->getQueryCountByJob(($bookdata != null?$bookdata->BOOK_ID:'') );
            foreach($chapterdata as $key=>$chapter)
            {
                //insert param's
                $insertparams['FK_TITLE_ID']        =   $jobID;
                $insertparams['PK_CHAPTER_ID']      =   $chapter->METADATA_ID;
                $insertparams['CHAPTER_NUMBER']     =   ($chapter->CHAPTER_NO     ==  ''?'null':$chapter->CHAPTER_NO);
                $insertparams['CHAPTER_NAME']       =   ($chapter->CHAPTER_NAME     ==  ''?'null':$chapter->CHAPTER_NAME);
                if(in_array(substr(strtolower($chapter->CHAPTER_NO),0,2),Config::get('constants.READ_TYPEOF_PART')))
                {
                    $insertparams['CHAPTER_TYPE']   =   "PART";
                }
                else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.FRONT_MATTER') !== false))
                {
                    $insertparams['CHAPTER_TYPE']   =   "FM";
                }
                else if(strpos(strtolower($chapter->CHAPTER_NO),Config::get('constants.BACK_MATTER') !== false))
                {
                    $insertparams['CHAPTER_TYPE']   =   "BM";
                }
                else
                {
                    $insertparams['CHAPTER_TYPE']   =   "CHAPTER";
                }
                $checkartdata                       =   taskLevelArtMetadataModel::where('METADATA_ID',$chapter->METADATA_ID)->first();
                $insertparams['IS_ACTIVE']          =   "1";
                $insertparams['CHAPTER_FILE_LINK']  =   'Yes';
                $insertparams['DOI_NUMBER']         =   ($bookdata != null?$bookdata->DOI:'null');
                $updateparams['MS_PAGES']           =   $insertparams['MS_PAGES']           =   ($chapter->NO_MSP     ==  ''?'null':$chapter->NO_MSP);
//                $updateparams['TS_PAGES']           =   $insertparams['TS_PAGES']           =   ($chapter->BLANK_PAGE     ==  ''?'null':$chapter->BLANK_PAGE);
                $updateparams['CE_ESTIMATION_PAGES']=   $insertparams['CE_ESTIMATION_PAGES']=   ($chapter->PAGE_COUNT_BY_WORDS     ==  ''?'null':$chapter->PAGE_COUNT_BY_WORDS);
                $updateparams['FIGURE_FILE_LINK']   =   $insertparams['FIGURE_FILE_LINK']   =   (count($checkartdata)>=1?'Yes':'No');
                $updateparams['FIGURE_LINKED_DATE'] =   $insertparams['FIGURE_LINKED_DATE'] =   "null";
                $updateparams['FIGURE_LINKED_BY_USER_ID']   =   $insertparams['FIGURE_LINKED_BY_USER_ID']   =   "null";
                $updateparams['BLANK_PAGES']        =   $insertparams['BLANK_PAGES']                =   ($chapter->SPICAST_BLANKS     ==  ''?'null':$chapter->SPICAST_BLANKS);
                $insertparams['CHAPTER_LINKED_DATE']=   ($chapter->CREATED_DATE     ==  ''?'null':$chapter->CREATED_DATE);
                $updateparams['DOI_NUMBER']         =   $insertparams['DOI_NUMBER']                 =   ($chapter->DOI     ==  ''?'null':$chapter->DOI);
                $updateparams['ART_STATUS']         =   $insertparams['ART_STATUS']                 =   (count($checkartdata)>=1?'1':'0');
                $updateparams['OPEN_QUERY_CNT']     =   $insertparams['OPEN_QUERY_CNT']             =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'open');
                $updateparams['CLOSED_QUERY_CNT']   =   $insertparams['CLOSED_QUERY_CNT']           =   $this->getQueryCountByChapter($chapter->CHAPTER_NO,$bookQuery ,'close');
                $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']              =   date('Y-m-d H:i:s');
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']        =   $this->loginUserID;
                
                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($updateparams[$chapterkey]);
                    }
                }
                
                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($insertparams[$chapterkey]);
                    }
                }
                
                $params['sender']                       =   $this->senderName;
				$params['release']                  	=   $this->statusRelease;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->chaptermastertable;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'PK_CHAPTER_ID'=>(string)$chapter->METADATA_ID];
                    $params['tableName']                =   $this->chaptermastertable;
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $params['processType']              =   'update';
                }
            }
        }
        return $params;
    }
    
    public function activemqRoundStagedetailsrequest($jobID,$metaid,$roundID,$crudtype,$tokenkey,$stageID)
    {   
        $types5orproductionbased    =   "";
        $metadataID     =   "";
        if(strpos($stageID,"-") !== false){
            $stageid    =   explode('-',$stageID);
            $types5orproductionbased      =   false;
            $stageID    =   $stageid[1];
            $metadataID =   $stageid[0];
        }else{
            $types5orproductionbased      =   true;
        }
        
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $currenttime                            =   date('Y-m-d H:i:s');
        $jobmilestone   =   jobRoundModel::where(['JOB_ID'=>$jobID,'ROUND_ID'=>$roundID])->first();
        $jobdeadline    =   jobInfoModel::select(DB::Raw('STAGE_DEADLINES_COLLECTION'))->where(['JOB_ID'=>$jobID])->first();
        if($types5orproductionbased == true){
            $chapterdata    =   checkoutModel::getStageInfo($stageID);
            if(count($chapterdata)>=1)
            {
                //insert param's
                $insertparams['FK_TITLE_ID']        =   (string)$jobID;
                $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata[0]->METADATA_ID;
                $insertparams['PK_PRODUCTION_JOB_ROUND_ID']     =   (string)$chapterdata[0]->JOB_ROUND_ID;
                $insertparams['FK_ROUND_ID']        =   (string)$chapterdata[0]->ROUND_ID;
                $insertparams['FK_STAGE_ID']        =   (string)$chapterdata[0]->STAGE_ID;
                $insertparams['IS_ACTIVE']          =   '1';
                if(count($jobmilestone)>=1)
                {
                    $insertparams['ROUND_RECEIVED_DATE']    =   (count($jobmilestone)>=1?$jobmilestone->RECEIVED_DATE:'');
                }
                if(count($jobdeadline)>=1)
                {
                    $jsondecodedate     =   json_decode($jobdeadline->STAGE_DEADLINES_COLLECTION);
                    if(isset($jsondecodedate->S200))
                    {
                        $jsondecodedate     =   str_replace('.','-',$jsondecodedate->S200);
                        $insertparams['ROUND_SCHEDULED_DATE']   =   $jsondecodedate;
                    }
                }

                $updateparams['FK_STAGE_STATUS_ID'] =   $insertparams['FK_STAGE_STATUS_ID']     =   (string)$chapterdata[0]->CURRENTSTATUS;
                $updateparams['SUB_PROCESS_IHP']    =   $insertparams['SUB_PROCESS_IHP']        =   (string)"null";
                $updateparams['REVERTED_REMARKS']   =   $insertparams['REVERTED_REMARKS']       =   (string)$chapterdata[0]->Rollback_Remarks;
                $insertparams['CURRENT_FLAG']       =   (string)1;
                $updateparams['CURRENT_FLAG']       =   (string)0;
                $updateparams['START_PAGE']         =   $insertparams['START_PAGE']             =   (string)"null";
                $updateparams['END_PAGE']           =   $insertparams['END_PAGE']               =   (string)"null";
                $updateparams['UPDATE_DATE']        =   $insertparams['INSERTED_DATE']          =   $currenttime;
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;

                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null'  || empty($value)){
                        unset($updateparams[$chapterkey]);
                    }
                }

                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null'  || empty($value)){
                        unset($insertparams[$chapterkey]);
                    }
                }

                $params['sender']                       =   $this->senderName;
				$params['release']                  	=   $this->statusRelease;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->roundstagetable;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$chapterdata[0]->METADATA_ID,'FK_ROUND_ID'=>(string)$chapterdata[0]->ROUND_ID,'FK_STAGE_ID'=>(string)$chapterdata[0]->STAGE_ID,'PK_PRODUCTION_JOB_ROUND_ID'=>(string)$chapterdata[0]->JOB_ROUND_ID];
                    $params['tableName']                =   $this->roundstagetable;
                    $params['processType']              =   'update';
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                }
            }
        }else{
            $chapterdata    =   jobTimeSheet::select(DB::raw('job_time_sheet.JOB_TIME_SHEET_ID,job_time_sheet.STATUS AS CURRENTSTATUS,job_time_sheet.COMMENTS AS Rollback_Remarks,tlm.METADATA_ID'))
                    ->leftjoin( 'task_level_metadata as tlm' , 'tlm.METADATA_ID', '=', 'job_time_sheet.METADATA_ID' )      
                    ->where(['job_time_sheet.JOB_ID'=>$jobID,'job_time_sheet.ROUND_ID'=>$roundID,'job_time_sheet.METADATA_ID'=>$metadataID,'job_time_sheet.STAGE'=>$stageID])->orderBy('JOB_TIME_SHEET_ID','desc')->first();
         
            if(!empty($chapterdata))
            {
                //insert param's
                $insertparams['FK_TITLE_ID']        =   (string)$jobID;
                $insertparams['FK_CHAPTER_ID']      =   (string)$metadataID;
                $insertparams['PK_PRODUCTION_JOB_ROUND_ID']     =   (string)$chapterdata->JOB_TIME_SHEET_ID;
                $insertparams['FK_ROUND_ID']        =   (string)$roundID;
                $insertparams['FK_STAGE_ID']        =   (string)$stageID;
                $insertparams['IS_ACTIVE']          =   '1';
                if(!empty($jobmilestone))
                {
                    $insertparams['ROUND_RECEIVED_DATE']    =   (!empty($jobmilestone)?$jobmilestone->RECEIVED_DATE:'');
                }
                if(count($jobdeadline)>=1)
                {
                    $jsondecodedate     =   json_decode($jobdeadline->STAGE_DEADLINES_COLLECTION);
                    if(isset($jsondecodedate->S200))
                    {
                        $jsondecodedate     =   str_replace('.','-',$jsondecodedate->S200);
                        $insertparams['ROUND_SCHEDULED_DATE']   =   $jsondecodedate;
                    }
                }
                $currentStatus  =   ($chapterdata->CURRENTSTATUS    ==  "1"?"23":"8");
                /*switch($stageID){
                    case Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'):
                        $currentStatus  =   ($chapterdata->CURRENTSTATUS    ==  "1"?"46":"47");
                        break;
                    case Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'):
                        $currentStatus  =   ($chapterdata->CURRENTSTATUS    ==  "1"?"46":"47");
                        break;
                    default:
                        $currentStatus  =   "27";
                        break;
                }*/
                    
                $updateparams['FK_STAGE_STATUS_ID'] =   $insertparams['FK_STAGE_STATUS_ID']     =   (string)$currentStatus;
                $updateparams['SUB_PROCESS_IHP']    =   $insertparams['SUB_PROCESS_IHP']        =   (string)"null";
                $updateparams['REVERTED_REMARKS']   =   $insertparams['REVERTED_REMARKS']       =   (string)$chapterdata->Rollback_Remarks;
                $insertparams['CURRENT_FLAG']       =   (string)1;
                $updateparams['CURRENT_FLAG']       =   (string)0;
                $updateparams['START_PAGE']         =   $insertparams['START_PAGE']             =   (string)"null";
                $updateparams['END_PAGE']           =   $insertparams['END_PAGE']               =   (string)"null";
                $updateparams['UPDATE_DATE']        =   $insertparams['INSERTED_DATE']          =   $currenttime;
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;

                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null'  || empty($value)){
                        unset($updateparams[$chapterkey]);
                    }
                }

                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null'  || empty($value)){
                        unset($insertparams[$chapterkey]);
                    }
                }

                $params['sender']                       =   $this->senderName;
				$params['release']                  	=   $this->statusRelease;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->roundstagetable;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$chapterdata->METADATA_ID,'FK_ROUND_ID'=>(string)$roundID,'FK_STAGE_ID'=>(string)$stageID,'PK_PRODUCTION_JOB_ROUND_ID'=>(string)$chapterdata->JOB_TIME_SHEET_ID];
                    $params['tableName']                =   $this->roundstagetable;
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $params['processType']              =   'update';
                }
            }
        }
        return $params;
    }
       
    public function activemqUserStagedetailsrequest($jobID,$metaid,$roundID,$crudtype,$tokenkey,$stageID)
    {   
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $currenttime                            =   date('Y-m-d H:i:s');
        $types5orproductionbased    =   "";
        $metadataID     =   "";
        if(strpos($stageID,"-") !== false){
            $stageid    =   explode('-',$stageID);
            $types5orproductionbased      =   false;
            $stageID    =   $stageid[1];
            $metadataID =   $stageid[0];
        }else{
            $types5orproductionbased      =   true;
        }
        
        if($types5orproductionbased == true){
            $chapterdata                            =   checkoutModel::getStageInfo($stageID);
            if(count($chapterdata)>=1)
            {
                //insert param's
                $insertparams['PK_PRODUCTION_JOB_WORKLOG_ID']   =   (string)$chapterdata[0]->JOB_STAGE_ID;
                $insertparams['FK_TITLE_ID']        =   (string)$jobID;
                $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata[0]->METADATA_ID;
                $wheredata                          =   ['P_METADATA_ID'=>$chapterdata[0]->METADATA_ID,'JOB_ID'=>$jobID,'JOB_STAGE_ID'=>$stageID];
                $jobresourceget                     =   jobResource::select(DB::Raw('CREATED_BY'))->where($wheredata)->first();
                $insertparams['FK_USER_ID']         =   (count($jobresourceget)>=1?$jobresourceget->CREATED_BY:Config::get('constants.ADMIN_USER_ID'));
                $insertparams['FK_DEPARTMENT_ID']   =   (string)1;
                $insertparams['FK_ROUND_ID']        =   (string)$chapterdata[0]->ROUND_ID;
                $insertparams['FK_STAGE_ID']        =   (string)$chapterdata[0]->STAGE_ID;
                $insertparams['IHP_DETAILS']        =   (string)"null";
                $insertparams['IS_ACTIVE']          =   (string)'1';
                $updateparams['PAGES']              =   $insertparams['PAGES']                  =   ($chapterdata[0]->OUTPUT_QUANTITY !=   ''?(string)$chapterdata[0]->OUTPUT_QUANTITY:(string)'null');
                $insertparams['START_TIME']         =   (string)$chapterdata[0]->CHECK_OUT;
                $updateparams['END_TIME']           =   ($chapterdata[0]->CHECK_IN !=   ''?(string)$chapterdata[0]->CHECK_IN:(string)'null');
                $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']          =   $currenttime;
                $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;
    //                
                foreach($updateparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($updateparams[$chapterkey]);
                    }
                }

                foreach($insertparams as $chapterkey=>$value){
                    if($value     ==  'null' || empty($value)){
                        unset($insertparams[$chapterkey]);
                    }
                }

                $params['sender']                       =   $this->senderName;
				$params['release']                  	=   $this->statusRelease;
                $params['id']                           =   $tokenkey;
                $params['tableName']                    =   $this->userstagetable;
                if($crudtype    ==  "insert")
                {
                    $params['processType']              =   'insert';
                    $params['fields']                   =   [$insertparams];
                }
                else if($crudtype    ==  "update")
                {
                    $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$chapterdata[0]->METADATA_ID,'FK_ROUND_ID'=>(string)$chapterdata[0]->ROUND_ID,'FK_STAGE_ID'=>(string)$chapterdata[0]->STAGE_ID,'PK_PRODUCTION_JOB_WORKLOG_ID'=>(string)$chapterdata[0]->JOB_STAGE_ID];
                    $params['tableName']                =   $this->userstagetable;
                    $params['fields']                   =   [$updateparams];
                    $params['whereClauseFieldsAnd']     =   $updatedata;
                    $params['processType']              =   'update';
                }
            }
        }else{
            $chapterdata    =   jobTimeSheet::select(DB::raw('job_time_sheet.JOB_TIME_SHEET_ID,job_time_sheet.CHECK_OUT,job_time_sheet.CHECK_IN,job_time_sheet.CREATED_BY,job_time_sheet.STATUS AS CURRENTSTATUS,job_time_sheet.COMMENTS AS Rollback_Remarks,tlm.METADATA_ID'))
                    ->leftjoin( 'task_level_metadata as tlm' , 'tlm.METADATA_ID', '=', 'job_time_sheet.METADATA_ID' )      
                    ->leftjoin( 'metadata_info as mi' , 'mi.METADATA_ID', '=', 'tlm.METADATA_ID' )
                    ->where(['job_time_sheet.JOB_ID'=>$jobID,'job_time_sheet.ROUND_ID'=>$roundID,'job_time_sheet.METADATA_ID'=>$metadataID,'job_time_sheet.STAGE'=>$stageID])->orderBy('JOB_TIME_SHEET_ID','desc')->first();
            //insert param's
            $insertparams['PK_PRODUCTION_JOB_WORKLOG_ID']   =   (string)$chapterdata->JOB_TIME_SHEET_ID;
            $insertparams['FK_TITLE_ID']        =   (string)$jobID;
            $insertparams['FK_CHAPTER_ID']      =   (string)$metadataID;
            $insertparams['FK_USER_ID']         =   (string)$chapterdata->CREATED_BY;
            $insertparams['FK_DEPARTMENT_ID']   =   (string)1;
            $insertparams['FK_ROUND_ID']        =   (string)$roundID;
            $insertparams['FK_STAGE_ID']        =   (string)$stageID;
            $insertparams['IHP_DETAILS']        =   (string)"null";
            $insertparams['IS_ACTIVE']          =   (string)'1';
            $updateparams['PAGES']              =   $insertparams['PAGES']  =   (string)'null';
            $insertparams['START_TIME']         =   (string)$chapterdata->CHECK_OUT;
            $updateparams['END_TIME']           =   ($chapterdata->CHECK_IN !=   ''?(string)$chapterdata->CHECK_IN:(string)'null');
            $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']          =   $currenttime;
            $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;
//                
            foreach($updateparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($updateparams[$chapterkey]);
                }
            }

            foreach($insertparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($insertparams[$chapterkey]);
                }
            }

            $params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
            $params['id']                           =   $tokenkey;
            $params['tableName']                    =   $this->userstagetable;
            if($crudtype    ==  "insert")
            {
                $params['processType']              =   'insert';
                $params['fields']                   =   [$insertparams];
            }
            else if($crudtype    ==  "update")
            {
                $updatedata                         =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$metadataID,'FK_ROUND_ID'=>(string)$roundID,'FK_STAGE_ID'=>(string)$stageID,'PK_PRODUCTION_JOB_WORKLOG_ID'=>(string)$chapterdata->JOB_TIME_SHEET_ID];
                $params['tableName']                =   $this->userstagetable;
                $params['fields']                   =   [$updateparams];
                $params['whereClauseFieldsAnd']     =   $updatedata;
                $params['processType']              =   'update';
            }
        }
        return $params;
    }
    
    public function activemqRoundStagedetailsClosurerequest($jobID,$metaid,$roundID,$crudtype,$tokenkey,$processStageID,$checkouttime,$checkinouttime)
    {   
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $currenttime                            =   date('Y-m-d H:i:s');
        $jobmilestone   =   jobRoundModel::select(DB::Raw('RECEIVED_DATE'))->where(['JOB_ID'=>$jobID,'ROUND_ID'=>$roundID])->first();
        $jobdeadline    =   jobInfoModel::select(DB::Raw('STAGE_DEADLINES_COLLECTION'))->where(['JOB_ID'=>$jobID])->first();
        if(empty($metaid)){
            $chapterdata    =   taskLevelMetadataModel::select(DB::Raw('METADATA_ID'))->where(['JOB_ID'=>$jobID,'UNIT_OF_MEASURE'=>Config::get('constants.UNIT_OF_MEASURE')])->first();
        }else{
            $chapterdata    =   taskLevelMetadataModel::select(DB::Raw('METADATA_ID'))->where(['JOB_ID'=>$jobID,'METADATA_ID'=>$metaid])->first();
        }
        $jobroundId     =   ($metaid == ''?$jobID.$roundID:$roundID.$metaid);
        if($jobdeadline != null)
        {
            //insert param's
            $insertparams['FK_TITLE_ID']        =   (string)$jobID;
            $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata->METADATA_ID;
            $insertparams['PK_PRODUCTION_JOB_ROUND_ID']     =   (string)$jobroundId;
            $insertparams['FK_ROUND_ID']        =   (string)$roundID;
            $insertparams['FK_STAGE_ID']        =   (string)$processStageID;
            $insertparams['IS_ACTIVE']          =   '1';
            $insertparams['ROUND_RECEIVED_DATE']    =   ($jobmilestone != null?$jobmilestone->RECEIVED_DATE:'');
            if($jobdeadline !=  null)
            {
                $jsondecodedate     =   json_decode($jobdeadline->STAGE_DEADLINES_COLLECTION,true);
                $jsondecodedate     =   $jsondecodedate[Config::get('constants.ROUND_ID')[$roundID]];
                $jsondecodedate     =   str_replace('.','-',$jsondecodedate);
                $insertparams['ROUND_SCHEDULED_DATE']   =   ($jsondecodedate != ''?$jsondecodedate:'');
            }
            
            $updateparams['SUB_PROCESS_IHP']    =   $insertparams['SUB_PROCESS_IHP']        =   (string)"null";
            $updateparams['REVERTED_REMARKS']   =   $insertparams['REVERTED_REMARKS']       =   (string)"";
            $insertparams['CURRENT_FLAG']       =   (string)1;
            $updateparams['CURRENT_FLAG']       =   (string)0;
            $updateparams['START_PAGE']         =   $insertparams['START_PAGE']             =   (string)"null";
            $updateparams['END_PAGE']           =   $insertparams['END_PAGE']               =   (string)"null";
            $updateparams['UPDATE_DATE']        =   $insertparams['INSERTED_DATE']          =   $currenttime;
            $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;

            foreach($updateparams as $chapterkey=>$value){
                if($value     ==  'null'  || empty($value)){
                    unset($updateparams[$chapterkey]);
                }
            }

            foreach($insertparams as $chapterkey=>$value){
                if($value     ==  'null'  || empty($value)){
                    unset($insertparams[$chapterkey]);
                }
            }
            
            
            $params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
            $params['id']                           =   $tokenkey;
            $params['tableName']                    =   $this->roundstagetable;
            if($crudtype    ==  "insert")
            {
                $params['processType']              =   'insert';
                $insertparams['FK_STAGE_STATUS_ID'] =   (string)$this->statusInprogress;
                $params['fields']                   =   [$insertparams];
            }
            else if($crudtype    ==  "update")
            {
                // client ack and file upload table
                if($checkouttime != null && $checkouttime->STATUS == 2){
                    $getstatusupdate                    =   ($checkinouttime != null && $checkinouttime->STATUS == 2?$this->statusCompleted:$this->statusInprogress);
                }else{
                    $getstatusupdate                =   $this->statusInprogress;
                }
                
                $updateparams['FK_STAGE_STATUS_ID'] =   (string)$getstatusupdate;
                if(empty($metaid)){
                    $updatedata                     =   ['FK_TITLE_ID'=>(string)$jobID,'FK_ROUND_ID'=>$roundID,'PK_PRODUCTION_JOB_ROUND_ID'=>(string)$jobroundId];
                }else{
                    $updatedata                     =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$metaid,'FK_ROUND_ID'=>(string)$roundID,'PK_PRODUCTION_JOB_ROUND_ID'=>(string)$jobroundId];
                }
                $params['tableName']                =   $this->roundstagetable;
                $params['fields']                   =   [$updateparams];
                $params['whereClauseFieldsAnd']     =   $updatedata;
                $params['processType']              =   'update';
            }
        }
        return $params;
    }
       
    public function activemqUserStagedetailsClosurerequest($jobID,$metaid,$roundID,$crudtype,$tokenkey,$processStageID,$checkouttime,$checkinouttime)
    {   
        $insertparams                           =   [];
        $updateparams                           =   [];
        $params                                 =   [];
        $currenttime                            =   date('Y-m-d H:i:s');
        
        $jobdeadline    =   jobInfoModel::select(DB::Raw('STAGE_DEADLINES_COLLECTION'))->where(['JOB_ID'=>$jobID])->first();
        if(empty($metaid)){
            $chapterdata    =   taskLevelMetadataModel::select(DB::Raw('METADATA_ID'))->where(['JOB_ID'=>$jobID,'UNIT_OF_MEASURE'=>Config::get('constants.UNIT_OF_MEASURE')])->first();
        }else{
            $chapterdata    =   taskLevelMetadataModel::select(DB::Raw('METADATA_ID'))->where(['JOB_ID'=>$jobID,'METADATA_ID'=>$metaid])->first();
        }
        
        $jobroundId     =   ($metaid == ''?$jobID.$roundID:$roundID.$metaid);
        if($jobdeadline !=  null)
        {
            //insert param's
            $insertparams['PK_PRODUCTION_JOB_WORKLOG_ID']   =   (string)$jobroundId;
            $insertparams['FK_TITLE_ID']        =   (string)$jobID;
            $insertparams['FK_CHAPTER_ID']      =   (string)$chapterdata->METADATA_ID;
            $wheredata                          =   ['P_METADATA_ID'=>$metaid,'JOB_ID'=>$jobID];
            $jobresourceget                     =   jobResource::select(DB::Raw('CREATED_BY'))->where($wheredata)->orderBy('JOB_RESOURCE_ID','desc')->first();
            $insertparams['FK_USER_ID']         =   ($jobresourceget != null?$jobresourceget->CREATED_BY:Config::get('constants.ADMIN_USER_ID'));
            $insertparams['FK_DEPARTMENT_ID']   =   (string)1;
            $insertparams['FK_ROUND_ID']        =   (string)$roundID;
            $insertparams['FK_STAGE_ID']        =   (string)$processStageID;
            $insertparams['IHP_DETAILS']        =   (string)"null";
            $insertparams['IS_ACTIVE']          =   (string)'1';
            $insertparams['START_TIME']         =   (string)($checkouttime != null?$checkouttime->END_TIME:'');
            $updateparams['END_TIME']           =   (string)($checkinouttime != null?$checkinouttime->END_TIME:'');
            $updateparams['UPDATED_DATE']       =   $insertparams['INSERTED_DATE']          =   $currenttime;
            $updateparams['UPDATED_BY_USER_ID'] =   $insertparams['INSERTED_BY_USER_ID']    =   $this->loginUserID;
//                
            foreach($updateparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($updateparams[$chapterkey]);
                }
            }

            foreach($insertparams as $chapterkey=>$value){
                if($value     ==  'null' || empty($value)){
                    unset($insertparams[$chapterkey]);
                }
            }

            $params['sender']                       =   $this->senderName;
			$params['release']                  	=   $this->statusRelease;
            $params['id']                           =   $tokenkey;
            $params['tableName']                    =   $this->userstagetable;
            if($crudtype    ==  "insert")
            {
                $params['processType']              =   'insert';
                $params['fields']                   =   [$insertparams];
            }
            else if($crudtype    ==  "update")
            {
                if(empty($metaid)){
                    $updatedata                     =   ['FK_TITLE_ID'=>(string)$jobID,'FK_ROUND_ID'=>(string)$roundID,'PK_PRODUCTION_JOB_WORKLOG_ID'=>(string)$jobroundId];
                }else{
                    $updatedata                     =   ['FK_TITLE_ID'=>(string)$jobID,'FK_CHAPTER_ID'=>(string)$metaid,'FK_ROUND_ID'=>(string)$roundID,'PK_PRODUCTION_JOB_WORKLOG_ID'=>(string)$jobroundId];
                }
                $params['tableName']                =   $this->userstagetable;
                $params['fields']                   =   [$updateparams];
                $params['whereClauseFieldsAnd']     =   $updatedata;
                $params['processType']              =   'update';
            }
        }
        return $params;
    }
    
    public function activemqCallbacktoolresponse(Request $request)
    {      
        $getToolresponse    =   json_decode($request->getContent());
        Log::useDailyFiles(storage_path().'/Api/activemqlog.log');
        Log::info( json_encode( $getToolresponse ) );
        if(count($getToolresponse)>=1)
        {
            $getuniqueueid          =   trim($getToolresponse->id);
            if($getuniqueueid   !=  null)
            {
                $updatedata['UPDATED_DATE']     =   Carbon::now();
                $updatedata['STATUS']   =   ($getToolresponse->status   ==  'Success'?'2':'1');
                $updatedata['REMARKS']  =   trim($getToolresponse->remarks);
                $updatedata['RESPONSE_LOG']   =   $request->getContent();
                $updatemeta             =   apiActivemqModel::doupdate($getuniqueueid,$updatedata);
                if($updatemeta)
                {
                    $result             =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                    return response()->json($result);            
                }
                $result             =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received  not updated Successfully','token'=>$getuniqueueid.' is not valid token');
                return response()->json($result);            
            }            
            $result         =   array('status'=>0,'msg'=>'Failure','errMsg'=>'Response not received  Some issue','token'=>'');
            return response()->json($result);            
        }
    }
    
    public function getQueryCountByJob($bookId){
        
        $openquerychap          =   array();
        $closequerychap         =   array();
        
        $curl                   =   Config::get('constants.QMS_JOB_QUERIES_URL').'?TitleAcronym='.$bookId.'&Type=Magnus';
        $data                   =   array( 'BOOK_ID' => $bookId );
        $cmn_obj                =   new CommonMethodsController();
        $returns_response       =   json_decode($cmn_obj->getcUrlExecution(  $curl,0 ));
        if(count($returns_response)>=1 && isset($returns_response['http_code']) && $returns_response['http_code'] == 200){
            
        }
        
        $returndata             =   [];
        foreach($returns_response as $key => $data){
          
            if($data->Status == 'Open'){
               $chapters    =    explode(',',$data->Chapters);
             
               foreach($chapters as $chap){
                   if(array_key_exists($chap,$openquerychap) ){
                        $openquerychap[$chap] = (isset($openquerychap[$chap])?$openquerychap[$chap]:'')+1;
                    }else{
                        $openquerychap[$chap] =  1;  
                   }
               }
            }
            
            if($data->Status == 'Closed'){
               $chapters    =    explode(',',$data->Chapters);
             
               foreach($chapters as $chap){
                   if(array_key_exists($chap,$closequerychap) ){
                        $closequerychap[$chap] = (isset($closequerychap[$chap])?$closequerychap[$chap]:'')+1;
                    }else{
                        $closequerychap[$chap] =  1;  
                   }
               }
            }
        }
        $returndata['open']     =   $openquerychap;
        $returndata['close']    =   $closequerychap;
        return $returndata;
    }
    
    public function getQueryCountByChapter($chapter,$bookQuery,$type){
        if($type    ==  "open"){
            if(array_key_exists($chapter,$bookQuery['open'])){
                $queryExist     =   (isset($bookQuery[$chapter])?$bookQuery[$chapter]:'');
                return $queryExist;
            }else{
                return 0;
            }
        }else{
            if(array_key_exists($chapter,$bookQuery['close'])){
                $queryExist     =   (isset($bookQuery[$chapter])?$bookQuery[$chapter]:'');
                return $queryExist;
            }else{
                return 0;
            }
        }
        return 0;
    }
    
}