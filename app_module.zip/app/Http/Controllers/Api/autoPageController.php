<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager;
use App\Models\jobStage;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\custom\errorController;
use App\Models\apiAutoPage;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\dynamicConstantController;
use App\Http\Controllers\Api\autostageController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class autoPageController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    public $optionalParam   =       '';
    
    public $tablename       =       'api_autopage';
    public $apiModel        =       'apiAutoPage';
    
    public function customConstructor( $jobStageId ){
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
        
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      			=       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $stageid                    =       $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        $metainfo['platform']       =       '3b2';
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
		
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        
		
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $cmn_obj                    =       new CommonMethodsController();
        
        $tablename                  =       $this->tablename;
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , $tablename , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
		$metapdfrequired			=		'N';
	 if($jbstg_rec->FM_ARTICLE_BM == '6'){
		$metainfo['correctionorindex']       =       'INDEXING_QA';
	}else{
		$metainfo['correctionorindex']       =       'CORRECTION';
    	}
      
        $this->metainfo             =       $metainfo;
         
        
            //only for autopage            
            $cusomcondition  =      array( 'METADATA_ID' => $jbstg_rec->METADATA_ID , 'ROUND' => $jbstg_rec->ROUND_ID , 'JOB_ID' => $jbstg_rec->JOB_ID );
            $apiAtPgObj      =      new apiAutoPage();
            $apirecordAP     =      $apiAtPgObj::select( )->where( $cusomcondition )->orderBy( 'ID' , 'desc' )->get()->first();
			$metainftbl		 =		DB::table( 'metadata_info' )->select( 'FM_ARTICLE_BM' )->where( 'METADATA_ID' ,  $jbstg_rec->METADATA_ID )->orderBy( 'METADATA_ID' , 'desc' )->get()->first();
			
			if( isset( $metainftbl->FM_ARTICLE_BM ) ){
				$comptyp =		$metainftbl->FM_ARTICLE_BM;
				$metapdfrequired_comp		=		array( \Config::get( 'constants.ARTICLE_CHAPTER' )  );
				
				if( in_array( $comptyp , $metapdfrequired_comp ) ){
					$metapdfrequired	=	'Y';
				}
			}
			
            $gotostage       =   '';
           
            $capstage      =       \Config::get('dynamicConstant.STAGE_COLLEECTION.AUTO_CAP'); 
            
            if( count( $apirecordAP ) && $stageid == $capstage ){
                
                $platform           =       $apirecordAP->PLATFORM;
                $mode               =       'CAP';
                $extension_ps       =       'ps';
                $location           =       'SERVER';//$apirecordAP->LOCATION;
                $autoext            =       'indd';
                
                switch ( $platform ){
                    
                    case 'ADOBE INDESIGN':
                        $extension_ps   =       'pdf';
                        $extension_ps   =       'indd';
                        $autoext        =   'indd';
                       break;
                    case '3B2':
                        $autoext           =    '3d';
                        $extension_ps     =     'ps';
                       break;
                    case 'LATEX':
                        $extension_ps     =     '';
                       break;
                   
                }
                
                $made_inp           =   array( 'platform' => $platform , 'mode' => $mode , 'autopageext' => $autoext  , 'arttags' => 1, 'location' => $location , 'pitstopsrcext' => $extension_ps ,
				'metapdfrequired' => $metapdfrequired
				);
                
                $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp ) );
                
            }

            
        return  $metainfo;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['jobstageid']        =       'required';
        $rules['round']             =       'required|numeric';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required|numeric';
        
        return $rules;
    }
    
    public function autostart(){
        
        $jbstgid   = '17837';
        $optional_param_json  = '{"platform":"3B2","mode":"FPP","location":"SERVER","autopageext":"3d"}';
        $res  =        $this->startProcess($jbstgid, $optional_param_json);
    }
           
    public function startProcess( $jbstgid , $optional_param_json  = '' ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
       
            
            
        $this->customConstructor( $jbstgid );        
        $this->optionalParam        =       $optional_param_json;
        $this->assignAdditonalOptionToMetaInfo( $optional_param_json );   
        
        $metainfo       =       $this->metainfo;
		
        extract( $metainfo );
        
        try{
           
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid , 0,0,1 );
            
           
            $watchPath      =       $this->getWatchFolderPath( $path );
            $ftpDefault     =       $this->ftpInfo;
            
            $content        =       $this->prepareAutoStageMeta( $jbstgid );
           
            //mode based watchfolder choosing option logic            
            $watchPath      .=     ( isset($location) && $location !==  '' )? strtoupper( $location ).'/' :  '';
           
            $metafileInput['metafilename']      =   $this->getMetafilename( $metainfo , $path );
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input                      =   array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['LOCATION']      =   isset($location) ? strtoupper( $location ) :  'SERVER';
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            
           
            //optional field
            $api_tbl_input['PLATFORM']      =   $platform;
            $api_tbl_input['MODE']          =   strtoupper($mode);
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
            
            if( isset( $withprint ) ){
                if( $withprint ){
                    $api_tbl_input['WITHPRINT']          =   $withprint;
                }
            }
           
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
        }catch( \Exception $e ){
            
            //print_r($e->getMessage());
           $response['status']     =       0;
           $response['Msg']        =       'failed';
           $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
           $err_handle     =       new errorController();
           $err_handle->handleApplicationErrors( $e );
     
        }
        
        return json_encode( $response );
        exit;
        
    }
    
    public function editPostedMetaxml( Request $request ){
        
        $jbstagid       =       $request->jobstgid;
        $type           =       'chapter';
        $option         =       $request->option;
        $filename       =       $request->metafilename;
        
        $resonse['status']  =       1;
        $resonse['Msg']     =       'Failed';
        $resonse['errMsg']  =       'metaxml update failed';
            
        $checkoutObj        =       new checkoutModel();
        $stageDetails       =       $checkoutObj->getStageInfo( $jbstagid );
        
        if( count( $stageDetails ) ){
            
            $jbstg_rec          =       $stageDetails[0];
            $job_id             =       $jbstg_rec->JOB_ID;
            $round              =       $jbstg_rec->ROUND_ID;
            $metaid             =       $jbstg_rec->METADATA_ID;
            $bookid             =       $jbstg_rec->BOOK_ID;
            $chapterno          =       $jbstg_rec->CHAPTER_NO;
            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundname          =       $round_arr[$round];  
            $tlm                =       new taskLevelMetadataModel();
    
            $getlocationftp             =       productionLocationModel::doGetLocationname( $job_id );
            
            $host   =   $hostserver     =       $getlocationftp->FTP_HOST;
            $usr    =   $hostusername   =       $getlocationftp->FTP_USER_NAME;
            $psw    =   $hostpassword   =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            
            $bi_obj                 =       new bookinfoModel();
            $bookinfo               =       $bi_obj->getBookinfodetails( $job_id );
            $bookinfo               =       $bookinfo->pluck('BOOK_ID')->toArray(); 
            $book_id                =       $bookinfo[0];
            
            $hostPath               =       ( $getlocationftp->FTP_PATH );
            $crd                    =       'ftp://'.$usr.':'.$psw.'@'; 
            $userdir                =       \Config::get('constants.USER_WORK_PATH').'{BID}/{CID}/';
            
            $sourcePath             =       $host.$hostPath.$userdir;
            $cmn_obj                =       new CommonMethodsController();
            
            $inp_rep_arr            =       array( 
                                'BOOK_ID'       =>      $book_id  ,   'ROUND_NAME'    =>      $roundname   ,
                                '{BID}'         =>      $book_id  ,   '{RID}'         =>      $roundname   ,      
                                '{CID}'         =>      $chapterno ,   'USER_DIR'      =>      Session::get('users')['emp_id']
                            );
							
            $cusomcondition  =      array( 'METADATA_ID' => $metaid , 'ROUND' => $round , 'JOB_ID' => $job_id );
            $apiAtPgObj      =      new apiAutoPage();
            $apirecordAP     =      $apiAtPgObj::select( )->where( $cusomcondition )->orderBy( 'ID' , 'desc' )->get()->first();
            
            $update_arr      =      array( 'WITHPRINT' =>  ( $option == 'NO' ) ? 0 : 1 );
            
            if( !empty( $apirecordAP ) )
                $apirecordAP::where('ID', $apirecordAP->ID )->update( $update_arr );
            
			
            $sourcePath            =      $cmn_obj->arr_key_value_replace( $inp_rep_arr , $sourcePath );
            $descPath              =        $crd.$sourcePath.$filename;   
          
            if( file_exists( $descPath ) ){
                
                //$content             =      file_get_contents( $crd.$sourcePath.$filename );
                $xml               =      simplexml_load_file( $descPath );

                $options        =   array('ftp' => array('overwrite' => true));
                $stream         =   stream_context_create($options);
                $inputTag       =   'BGProcess';
                //$xml = simplexml_load_string( $content );
                $xml->MetaData->$inputTag = $option;

                $content        =  $xml->asXML();

                if(!empty($content)) {

                    $descPath                =       str_replace( '\\' , '/'  , $descPath );
                    $response_file           =       file_put_contents($descPath,$content , 0 , $stream);

                }

                $resonse['status']  =   1;
                $resonse['Msg']     =   'Success';
                $resonse['errMsg']  =   'Successfully updated';
            
            }

        }
        
        return response()->json( $resonse );
        
    }
    
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){
        
        if( isset( $optional_param_json ) ){
            if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
                $addionalParam      =       json_decode( $optional_param_json );
                $location           =       '';
                if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                    $autopageInput      =       (array)$addionalParam; 
                    $exitsing_meta      =   $this->metainfo;
                   
                    foreach( $addionalParam as $key => $value ){  
                        $this->metainfo[ $key ]     = $value;     
                        if( $key == 'location' ){
                            $location   =   $value;
                        }
                    }
                    
                //find production location tools machine name
                 $bgConObj      =   new bgprocessController();
                 if( isset( $location ) ){
                     
                    if( strtolower( $location ) == 'desktop' ){
                        $toolsinfo['toolsmachine_name']     =   \Request::ip();
                        $metacollect        =   $this->metainfo;
                        
                        if( $metacollect['mode'] == 'AUTOPAGE' || $metacollect['mode'] == 'AUTOPAGE' )
                            $this->metainfo[ 'mode' ]   =   'LocalAutopage';
                        
                        //if( $metacollect['mode'] == 'CAP' )
                            //$this->metainfo[ 'mode' ]   =   'LocalPagination';
                    }
                    
                    if( strtolower( $location ) == 'server' ){
                        $toolsinfo     =   $bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput );                
                    }
                    
                 }
                 
                 $this->metainfo['toolsmachine_name']       =    isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : 'xxxx';
                 
                }
            }
        }
        
    }     
    
    public function getMetafilename( $metainfo , $path ){
        
        extract(  $metainfo );     
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $tokenkey ,
                                    );
        
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
		
		
        
        if( empty( $chapterno2 ) ){
            $chapterno2     =       ucwords( strtolower( $chapterno  ) );
        }
        
        $filename           =        $chapterno.'@'.$bookid.'.xml';
       
        if( strpos( strtoupper( $chapterno ) , 'CHAPTER' ) >= 0 ){
            $filename       =       $chapterno2.'@'.$bookid.'.xml';
        }
        
        if( strpos( strtoupper( $chapterno ) , 'CHAPTER' ) == false ){
            
            $chapterno          =        str_replace( '_' , '' , ucwords( strtolower( $chapterno ) ) );
            $chapterno          =        str_replace( 'Chapter' , '' , ucwords( strtolower( $chapterno ) ) );
            $filename           =        $chapterno.'@'.$bookid.'.xml';
            
        }
        
        $cmn_obj            =        new CommonMethodsController();
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
       
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH');
               
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
               
                $watchPath          =       $path['detail'];
                
                if( strpos( $watchPath['work'] , 'USER-WORK' )  ){
                    
                    $empid      =   $userarr  = Session::get('users')['emp_id'];
                    $watchPath['work']   = str_replace(  'USER-WORK' , "USER-WORK/$empid/" , $watchPath['work'] );
                    
                }
               
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                //remove user directory 
                //$workpath           =       preg_replace('/[0-9]/', '', $workpath);
                //$workpath           =       str_replace('//', '', $workpath);
             
            }
        
        }  
        
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

       $cmn_obj                    =       new CommonMethodsController();
       $ftpobj                     =       $metaFileInput['ftpInfo']; 
       if( is_array( $ftpobj )  ){
            $ftpobj 		=	$ftpobj['ftpInfo'];
        }
	   
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
	
       $errorstr           =            '';
       $autoStgObj         =            new autostageController();

        $whereToWrite2		=			 $whereToWrite.'/BACKUP_Autopage/';
        $curtimefomr		=			 '_'.date( 'Y_m_d_H_i_s' ).'.xml';
        $filename2		    =			 str_replace( '.xml' , $curtimefomr , $filename );
        
        $postMetaStatus =   1;
	
        $postMetaStatus      =            $autoStgObj->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
        
        if( !strpos(  $whereToWrite2 , 'USER' ) )
            $postMetaStatus2     =            $autoStgObj->writeMetafiletoWatchFolder( $filename2 , $getMetaFormat , $ftpInfo , $whereToWrite2 , $errorstr );

        if( !$postMetaStatus ){
            $response['errMsg']     =      'File posted to WatchFolder got Failed';
        }
       
        $modelname                           =       $this->apiModel;
        $apiModelObj                         =       app("App\\Models\\$modelname");

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']         =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']             =       1.5;           
           
           $insert_ret                          =       $apiModelObj->insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']         =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']           =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']             =       3;
           $api_tbl_input['REMARKS']            =       $errorstr;
           
           $insert_ret                          =       $apiModelObj->insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

       return false;

   } 

    public function prepareAutoStageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
               
        $bgp            =       new bgprocessPathSetup();           
        $platformtype   =       '3B2';            
        $type           =       strtolower( $autopageext );    
     
        if(strtolower( $mode ) == 'autoserver'){
            $type   =  'indd_autopage'; 
        }
       
        if(strtolower( $mode ) == 'autopage' || ( $mode == 'LocalAutopage' || strtolower( $mode ) == 'localautopage' ) ){
            $type   =  'indd_autopage'; 
        }
       
        if(( $mode == 'LocalAutopage' || strtolower( $mode ) == 'localautopage' ) && $type == '3d'){
            $type   =  '3d_autopage'; 
        }
        
        if(( $mode == 'LocalPagination' || strtolower( $mode ) == 'localpagination' ) && $type == '3d'){
            
            $type   =  '3d_autopage'; 
            if( isset( $withprint ) ){
               $type   =  '3d';  
            }
        
        }
        
        if(( $mode == 'LocalPagination' || strtolower( $mode ) == 'localpagination' ) && $type == 'indd'){
            
            $type   =  'indd_autopage'; 
            if( isset( $withprint ) ){
               $type   =  'indd';  
            }
        
        }
        
        if( isset( $autopageext ) ){
            
            switch( $type ){
                case '3d' :
                    $type   =   '3B2';
                    break;
                case 'indd' :
                    $type   =   'INDESIGN';
                    break;
                case 'indd_autopage' :
                    $type   =   'INDESIGN_AUTOPAGE';
                    break;
                case '3d_autopage' :
                    $type   =   '3B2_AUTOPAGE';
                    break;
                default : 
                    $type   =   '3B2';
                    break;                
            }
            
        }
        
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
       
        $preparedXml        =       '';    
        
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){

                $processname         =       $svalue->PROCESS_NAME;                
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid , $type );
               
                if( count( $parent_info ) ){
                    
                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid , $type );
					
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }

                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr                 =       '<WorkflowMetadata>'
                                            .$preparedXml
                                        .'</WorkflowMetadata>';
      
        $bg_Obj                  =       new bgprocessController();     
        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
    
        return $xmlStr;
        
    }
    
    public function validateAutopageSignal( Request $request ){
        
        $jbstgid    =   $request->input( 'jbstgid' );
        $chkObj     =   new checkoutModel();
        $stageInfo  =   $chkObj->getStageInfo( $jbstgid );
        $stageData  =   $stageInfo[0];
        
            $stageId     =  $stageData->STAGE_ID;
            $jobId       =  $stageData->JOB_ID;
            $metadataid  =  $stageData->METADATA_ID;
            $roundId     =  $stageData->ROUND_ID;
            $bookid      =  $stageData->BOOK_ID;
            $chapterno   =  $stageData->CHAPTER_NO;
            $comptyp     =  null;
            $metapdfrequired    =   0;

            $metainftbl		 =		DB::table( 'metadata_info' )->select( 'FM_ARTICLE_BM' )->where( 'METADATA_ID' ,  $metadataid )->orderBy( 'METADATA_ID' , 'desc' )->get()->first();
			if( isset( $metainftbl->FM_ARTICLE_BM ) ){
				$comptyp    =		$metainftbl->FM_ARTICLE_BM;
            }

            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundname          =       $round_arr[$roundId];  
            $manualpagination       =   \Config::get('dynamicConstant.STAGE_COLLEECTION.MANUAL_PAGINATION'); 
          
        if( $manualpagination == $stageId ){

            $otherFilesValidation       =   true;
            
            $workflowPath                    =   new workflowServerMapPathModel();
            $serverMapPath                   =   $workflowPath->getWorkflowServerMapPath( $jbstgid );

            $workpath       =   @$serverMapPath['detail']['work'];
            $crdInfo        =   @$serverMapPath['workingpathCredential'];

            $hostserver     =   $crdInfo['host'];
            $hostusername   =   $crdInfo['username'];
            $hostpassword   =   $crdInfo['pasword'];

            $pagingNames   =   '';
            $paging_collect     =   $this->getPagingFileNameing($bookid, $chapterno,$metadataid); 
            extract( $paging_collect );
            $pagingNames    =   $pagingfilnaming;
            
            $filename           =   $pagingNames.'_'.'Success.xml';
            $fileCheck_path     =  str_replace( '/' , '\\' ,   str_replace( $hostserver , '' , $workpath.$filename ) );
            
            $ftpObj              =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $status              =       $ftpObj->ftpFileExist(  $fileCheck_path );

	        $ftpObj              =      \Storage::createFtpDriver([
                                            'host'     => $hostserver , // $jobXMLInfo->FTP_HOST,
                                            'username' => $hostusername , // $jobXMLInfo->FTP_USER_NAME,
                                            'password' => $hostpassword , // Crypt::decryptString($jobXMLInfo->FTP_PASSWORD),
                                            'port'     => '21',
                                            'timeout'  => '30' 
                                        ]); 

            $rootdirname        =   \Config::get('serverconstants.FILE_SERVER_FTP_PATH');    
			$fileCheck_path		=	$workpath;
			
            $needle             =       strpos(  $fileCheck_path , str_replace(  '/', '',  $rootdirname ) );
           
		   if( $needle )
                $fileCheck_path     =       strstr(  $fileCheck_path  , $rootdirname );
			
            $serverDirFiles     =    $ftpObj->allFiles( $fileCheck_path );
            $required_ext       =    array( 'xml' , 'pdf' , 'log' , 'indd' , 'INDD' ,  '3D' , '3d' , 'txt' );
            
            //MANUAL PAGINATION REQUIRED FILES BASED ON ROUND AND COMPOTYPE ARRAY BUILD
            //ARTICLE_FM //FM_ARTICLE_BM //ARTICLE_CHAPTER //ARTICLE_BM //ARTICLE_PART //ARTICLE_COVER

            $requiredFiles_arr      =           array( 
														\Config::get('constants.ARTICLE_CHAPTER')   =>  array( 
															'S650' => array( $pagingNames.'_MetaPDF.pdf' , $pagingNames.'_Success.xml' ) , 
															'S600' => array( $pagingNames.'_MetaPDF.pdf' , $pagingNames.'_Success.xml' ) , 
															'S300' => array( $pagingNames.'_MetaPDF.pdf' , $pagingNames.'_Success.xml' ) , 
															'S200' => array( $pagingNames.'_MetaPDF.pdf' , $pagingNames.'_Success.xml' ) , 
														) ,
														\Config::get('constants.ARTICLE_PART')   =>  array( 
															'S650' => array(  $pagingNames.'_Success.xml' ) , 
															'S600' => array(  $pagingNames.'_Success.xml' ) , 
															'S300' => array(  $pagingNames.'_Success.xml' ) , 
															'S200' => array(  $pagingNames.'_Success.xml' ) , 
														),
														\Config::get('constants.ARTICLE_FM')   =>  array( 
															'S650' => array(  $pagingNames.'_Success.xml' ) , 
															'S600' => array(  $pagingNames.'_Success.xml' ) , 
															'S300' => array(  $pagingNames.'_Success.xml' ) , 
															'S200' => array(  $pagingNames.'_Success.xml' ) , 
														) ,														
														\Config::get('constants.ARTICLE_BM')   =>  array( 
															'S650' => array(  $pagingNames.'_Success.xml' ) , 
															'S600' => array(  $pagingNames.'_Success.xml' ) , 
															'S300' => array(  $pagingNames.'_Success.xml' ) , 
															'S200' => array(  $pagingNames.'_Success.xml' ) , 
														) ,
														
														
													);

            $userbinfiles       =       array();
			
            if(!empty($serverDirFiles)) {
                foreach($serverDirFiles as $serverDirFile) {
                    $userWorkFolderPath   =   substr( strrchr( $serverDirFile, "/" ) , 1 );
					$pathinformation		=		(  pathinfo( $serverDirFile ) );
					if( in_array( $pathinformation['extension'] , $required_ext ) ) {
                        $userbinfiles[]   =   $pathinformation['filename'].'.'.$pathinformation['extension'];        
                    }
                }
            }
			
            if( !empty( $comptyp ) && !empty( $requiredFiles_arr[$comptyp][$roundname] ) ){
                
				$absent				=		array();
                $reqFileValidarr        =       $requiredFiles_arr[$comptyp][$roundname];
				
                foreach( $reqFileValidarr as $keys => $values  ){
					
                    if( in_array( $values , $userbinfiles ) ){

                    }else{
						$absent[]	=	$values;
                        $status   =  false;
                        $otherFilesValidation  = false;
                    }

                }

            }
			
            if( $status && $otherFilesValidation ){

                $response['status'] =   1;
                $response['Msg']    =   'Success';
                $response['errMsg'] =   'Success log available';

                return response()->json( $response );

            }else if( !$status && !$otherFilesValidation ){ 

                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg'] =   'Required Files are missing to Proceed into next Activity!';
                $response['reason'] = 	$absent;

            }else{
                
                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg'] =   'Success log is Required to Proceed into next Activity!';

            }
        
        }else{
            $response['status'] =   1;
            $response['Msg']    =   'Success';
            $response['errMsg'] =   'Success log Validation not required here.';
            
        }
        
		return response()->json( $response );
                
    }
    
    public function getPagingFileNameing( $bookid , $chapterno ,  $metadataid = null ){
        
       
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
        $ckey               =        preg_replace("/[0-9_]/", '', $chapterno);
        $chpatername        =        $chapterno;

        $revchpatername     =        $chapterno2.'_'.$ckey;
        $ucrevchpatername   =        $chapterno2.'_'.ucfirst( strtolower( $ckey ) );

        $pagingfilnamingWithCno     =   null;
        $pagingfilnaming            =   null;
        
        $pagingfilnaming            =         $bookid.'_'.$ucrevchpatername;
        $pagingBooknameWithCno      =         $bookid.'_'.$chapterno2;
        $paginationFoldername       =         $chpatername;
        $compattr_name              =       '';
        
        //part and fm and bm handling need to do
        $paginginfo['pagingfilnaming']          =       $pagingfilnaming;
        $paginginfo['pagingBooknameWithCno']    =       $pagingBooknameWithCno;
        $paginginfo['paginationFoldername']     =       $paginationFoldername;
        $paginginfo['fmbmpartjobsheetname']     =       $pagingBooknameWithCno;
		
        if( !is_null( $metadataid ) ){
            
            $tlm_obj            =       new taskLevelMetadataModel();
            $cmn_obj            =       new CommonMethodsController();
            $taskLevelInfo      =       $tlm_obj->getTaskLevelDetails( $metadataid );
            $jbMdl              =       new jobModel();
           
            //1-FRONT MATTER, 2-ARTICLE, 3-BACK MATTER ,4 -PART,5-COVER
                
            if( count( $taskLevelInfo ) ){
                
                $taskLevelInfo          =       $taskLevelInfo[0];
                $fmbmpartVal            =       trim($taskLevelInfo->FM_ARTICLE_BM);
             
                $jb_info                =       $jbMdl->getJobdetails( $taskLevelInfo->JOB_ID );
                
                if( isset( $jb_info->JOB_TYPE ) ){
                    if( strpos( $jb_info->JOB_TYPE , 'Series') !== false ){
                        $fmbmpartVal        =       9;
                    } 
                }        
                //front matter
                if( $fmbmpartVal == '1' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_BookFrontmatter';
                    $paginginfo['packagecomponaming']       =       'BookFrontmatter';
                    $paginginfo['fmbmpartjobsheetname']     =       $bookid.'_'.$chapterno;	
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $bookid.'_'.$chapterno.'_Chapter' );
                }
				
                if( $fmbmpartVal == '2' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_'.$chapterno2.'_Chapter'; 
                    $paginginfo['packagecomponaming']       =       $chapterno2.'_Chapter';
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $paginginfo['pagingfilnaming'] );
                }

                if( $fmbmpartVal == '3' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_BookBackmatter';
                    $paginginfo['packagecomponaming']       =       'BookBackmatter';
                    $paginginfo['fmbmpartjobsheetname']     =       $bookid.'_'.$chapterno;	
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $bookid.'_'.$chapterno.'_Chapter' );
                }	

                if( $fmbmpartVal == '4' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_'.$chapterno2.'_PartFrontmatter';
                    $paginginfo['packagecomponaming']       =       $chapterno2.'_PartFrontmatter';
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $paginginfo['pagingfilnaming'] );				
                }

                if( $fmbmpartVal == '5' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_Cover';	
                    $paginginfo['packagecomponaming']       =       'Cover';
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $paginginfo['pagingfilnaming'] );	
                }
                
                 if( $fmbmpartVal == '6' ){
                    $paginginfo['pagingfilnaming']          =       $bookid.'_Index';	
                    $paginginfo['packagecomponaming']       =       'Index';
                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $paginginfo['pagingfilnaming'] );	
                }

                if( $fmbmpartVal == '9' ){

                    $paginginfo['pagingfilnaming']          =       $bookid.'_'.$chapterno2.'_Chapter'; 
                    $paginginfo['packagecomponaming']       =       $chapterno2.'_Chapter';

                    $compattr_name      =       str_replace( "$bookid".'_' , '' , $paginginfo['pagingfilnaming'] );
                }						
            
                $paginginfo['packagingCompattr']        =       $compattr_name;
				
            }
            
            
        }
        
        
        return $paginginfo;    
    }
    
}

