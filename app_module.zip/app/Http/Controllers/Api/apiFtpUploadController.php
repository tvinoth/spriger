<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiFileUpload;
use App\Models\apiFtpUpload;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\productionLocationModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\workflowServerMapPathModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\Api\autostageController;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\Api\clientAcknowledgementController;
use App\Http\Controllers\Api\autoPageController;
use Session;
use Illuminate\Support\Facades\Storage;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\custom\errorController;

class apiFtpUploadController extends Controller
{
    
    public function storeResponse( Request $request ){
           
        $inputarr       =       (array)json_decode( $request->getContent() );
        
        Log::useDailyFiles(storage_path().'/Api/package_upload_output.log');
        Log::info(json_encode($inputarr));
       
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $process        =       strtolower($inputarr['process']);
        $status         =       $inputarr['status'];
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
     
        $jobId          =       $job_id         =       $inputarr['jobid'];
        $book_id        =       $inputarr['bookid']; 
        $round          =       $inputarr['round'];
        $token_key      =       $inputarr['tokenkey'];
        $metaid         =       isset( $inputarr['chapterid'] ) ?$inputarr['chapterid'] : $inputarr['metaid'] ;
        $jobstageid     =       $inputarr['jobstageid'];
        
        $str_remarks    =   $inpArr['REMARKS']       =      $inputarr['remarks'];
        $inpArr['END_TIME']     =       date( 'Y-m-d H:i:s' );
        $errMsg =   '';      
        
        $rec 	=	$getRec       =         DB::table('api_ftp_upload as afu')
                                                        ->where('METADATA_ID', '=', $metaid )
                                                        ->where('ROUND', '=', $round )                                            
                                                        ->where('TOKEN_KEY', '=', $token_key )   
                                                        ->where('STATUS', '=', '1.5' )
                                                        ->orderBy('afu.ID', 'desc')
                                                        ->get()->first();
	
        $api_pft        =       new apiFtpUpload();
        
        if(is_object( $rec )){

            $inpArr['STATUS']       =       $status;
            $rowid      =       $rec->ID;
            $api_pft->updateIfExist($inpArr, $rowid);
            
            $response['status']         =       1;
            $response['msg']            =       'Success';
            $response['errMsg']         =       'signal received';
            
             
         if( $status == 2 ){
            app('App\Http\Controllers\Api\autostageController')->stageCompletionProcess($metaid,$round);
         }else{
            $update_jobstg_Query = 'update job_stage set Rollback_Remarks="'.$str_remarks.'" where job_stage_id= '.$jobstageid.' limit 1';
            DB::update( $update_jobstg_Query );
         }
         
        }else{
            
            $response['status']         =       0;
            $response['msg']            =       'Failed...';
            $response['errMsg']         =       'Invalid Try';
            
        }
        
        return response()->json( $response );
        
    }
    
    public function sendRequestForPackagingUploadChapterLevel( $jobstageid )
    {
        $input_arr                  =   array();        
        $time                       =   date( 'Y-m-d H:i:s' );	    
        
        $response['status']         =   0;
        $response['msg']            =   'Failed';
        $response['errMsg']         =   'Try again after some times';
        $response['msgstatus']      =   '';
        
        $checkoutObj            =       new checkoutModel();
        $stageDetails           =       $checkoutObj->getStageInfo($jobstageid);
        $stageDetails           =       $stageDetails[0];
        
        $round                  =       $stageDetails->ROUND_ID;
        $chapterid              =       $metaid      =   $stageDetails->METADATA_ID;
        $jobId                  =       $stageDetails->JOB_ID;
        $chaptername            =       $stageDetails->CHAPTER_NO;
        
         $round_name                 =   Config::get('constants.ROUND_NAME')[$round];
        
        try
        {
            $table_name             =       'api_ftp_upload'; 
            $cmn_obj                =       new CommonMethodsController();
            $token_key              =       $cmn_obj->generateRandomString( 16 , $table_name); 
           
            $api_tbl_input          =       array( 
                                                'JOB_ID'        =>      $jobId , 
                                                'ROUND'         =>      $round  ,
                                                'START_TIME'    =>      $time ,
                                                'TOKEN_KEY'     =>      $token_key , 
                                                'STATUS'        =>      1.5 ,
                                                'METADATA_ID'   =>      $chapterid
                                            );
            
            $jobDetails             =       DB::table('job')->where('JOB_ID', $jobId )->first();
            $book_id                =   "";
            
            if(count($jobDetails)>=1){
                $book_id            =      $jobDetails->BOOK_ID;
            }
                    
            $getlocationftp         =       productionLocationModel::doGetLocationname( $jobId );             
             if( empty( $getlocationftp ) )
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            if(count( $getlocationftp )>=1){
                
                //need to dynamicaly bind the production location based on table location
                $ftp_path           =   $getlocationftp->FTP_PATH;
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   $getlocationftp->FTP_PATH;
                
                
                $getUploadCreden    =       $this->getClientServerDetailsForPackageUpload();
                extract( $getUploadCreden );
                
                //$jbst_path              =   Config::get('constants.UPDATED_JOBSHEET_PATH'); 
                $cmn_obj                =   new CommonMethodsController();
                $travers_filesname      =   '';
                $process_enum           =   array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 , 'WRONG_INSTRUCTION' => 4 , 'PACKAGING' => 5);
                $ptype                  =   $process_enum['PACKAGING'];
                
                $array_cond_     =       array( 'ROUND' => $round ,'METADATA_ID'=>$chapterid , 'STATUS' => 2 );
                
                $api_dataset     =       DB::table('api_dataset')
                                                        ->where( $array_cond_ )
                                                        ->orderBy('ID' , 'desc')                                               
                                                        ->first();
              
                
                if( count( $api_dataset ) == 0 ){
                    throw new \Exception( 'Despatch Package zip name record not found' );
                }
                
                $travers_filesname      =       $api_dataset->NEW_PACKAGE_NAME;
                $wrkSerMapObj           =       new workflowServerMapPathModel();
                $_file_path             =       $wrkSerMapObj->getWorkflowPathBasedOnJobStageIdAndType( $jobstageid , 6 );
                
                if( !$_file_path || true ){ 
                    $_file_path         =   	$hostserver.\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.UPLOADDESTINATIONPATH');
                }
				
                if( !strpos( $travers_filesname , '.zip' ) ){
                    $travers_filesname		=	$travers_filesname.'.zip';
                }
				
                $inp_rep_arr            =   array( 
                                                '{BID}'    =>      $book_id           , 
                                                '{RID}'    =>      $round_name        ,                 
                                                '{DID}'    =>      $travers_filesname ,
                                                '{CID}'    =>      $chaptername
                                            );
                
                $_file_path               =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $_file_path );
                $_file_path               =   $cmn_obj->backslashPathPrepare( $_file_path , true );
                $ret_url                =   url('/').'/api/chapterLevelPackageUploadCallback';
                
                $uploadMeta = "";            
                $uploadMeta .= "<uploadMeta>";
                $uploadMeta .= "<bookid>" . $book_id . "</bookid>";
                $uploadMeta .= "<stage>" . $round_name . "</stage>";
                $uploadMeta .= "<uploadtype>PACKAGE_UPLOAD</uploadtype>";
                $uploadMeta .= "<sourceFile>";
                $uploadMeta .= "<filepath>" .$_file_path."</filepath>";
                $uploadMeta .= "</sourceFile>";
                $uploadMeta .= "<destPath>";
                $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
                $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
                $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
                $uploadMeta .= "<path>".$_upload_path."</path>";
                $uploadMeta .= "<username>".$ftp_username."</username>";
                $uploadMeta .= "<password>".$ftp_password."</password>";
                $uploadMeta .= "</destPath>";
                $uploadMeta .= '<WorkflowAPI>
                                    <Url value="'.$ret_url.'"/>
                                    <parameter key="process" value="upload" type="fixed"/>
                                    <parameter key="jobid" value="'.$jobId.'" type="fixed"/>
                                    <parameter key="chapterid" value="'.$chapterid.'" type="fixed"/>
                                    <parameter key="jobstageid" value="'.$jobstageid.'" type="fixed"/>
                                    <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                    <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                    <parameter key="round" value="'.$round.'" type="fixed"/>
                                    <parameter key="status" type="boolean"/>
                                    <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                    <parameter key="remarks" type="string"/>
                                </WorkflowAPI>';
                $uploadMeta .= "</uploadMeta>";
                
                $uploadMeta      =           $cmn_obj->formatXmlString( $uploadMeta );
				 
                $content 	= 	$uploadMeta;
				$pagObj             =       new autoPageController();
                $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chaptername , $metaid ); 
                extract( $paging_collect );
                $filename           =       $pagingfilnaming.'@'.$round_name.'_upload.xml';
 
                $watchpath                        =       Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/';
                
                $ftpInfo['HOST']                  =       $hostserver;
                $ftpInfo['FTP_USERNAME']          =       $hostusername;
                $ftpInfo['FTP_PASSWORD']          =       $hostpassword;
                
                $autoStageCont          =       new autostageController();
                $successfileresponse    =       $autoStageCont->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );
                $api_tbl_input['REQUEST_LOG']   = $uploadMeta;
                    
                if($successfileresponse == true){
                    
                    $getResponse            =   apiFtpUpload::insertNew( $api_tbl_input );
                    $acknow_data            =   array(  
                                                    'JOB_ID'    =>      $jobId ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    'METADATA_ID'=>     $chapterid,
                                                    'PROCESS_TYPE_DIFF' =>      5 , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                                );
                    //clientAck insert
                    apiClientAcknowledgement::insertNew( $acknow_data );
                    
                    if( $getResponse >= 1  ){                  
                        $response['status']     =       1;
                        $response['msg']        =       'Success';
                        $response['errMsg']     =       '  [ Despatch upload ]  - Bg process initialized  ';     
                        $response['params'] =   array( 'tokenkey' => $token_key , 'table' => 'api_ftp_upload' , 'waiting' => true );
                    }
                    
                    return json_encode($response);
                    
                }else{
                    $response['errMsg']     =       ' Despatch Upload - Bg process intialization failed.'; 
                    $api_tbl_input['status']    =   0;
                    $getResponse                =   apiFtpUpload::insertNew( $api_tbl_input );
                
                }
                
                return json_encode($response);
                
            }
            
                $result         =       array('status'=> 0 ,'errMsg'=>'Unable to connect to production Server...','msg'=>'Failure');   
                
                return joson_encode($result); 
            
            }catch( \Exception $e ){
                
                $custommsg      =   'Oops! Something went wrong, Try again later.';
                
                $api_tbl_input['STATUS']    =   0;
                $api_tbl_input['REMARKS']   =   $custommsg;
                
                $getResponse           =   apiFtpUpload::insertNew( $api_tbl_input );
                $response['errMsg']    =   $custommsg;             
                $response['reason']    =   $e->getMessage(); 
                 
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
                
                return json_encode( $response );      
                
            }  
            
        return json_encode( $response );   
        
    }
    
   
    public function getClientServerDetailsForPackageUpload(){
        
        $return_arr     =   array();
        
            $return_arr['ftp_host']               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
            $return_arr['ftp_username']           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
            $return_arr['ftp_password']           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
            $return_arr['ftp_type']               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
            $return_arr['fingerPrint']            =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');
            $return_arr['_upload_path']           =       \Config::get('constants.PACKAGE_PATH.PACKAGE_UPLOAD_PATH');
                
        return $return_arr;
        
    }
    
    public function doEproofstoreresponse(Request $request)
    {
        try
        {   
            $getToolresponse    =   json_decode(file_get_contents('php://input'));
            
            if( count($getToolresponse)>=1 ){
                
                $endtime    =  $getToolresponse->endtime;
                $endtime    =  $endtime[1];
                $request['token']       =       $getToolresponse->tokenkey;
                $request['status'] 	=       $getToolresponse->status;
                $jobid                  =       $request['job_id'] 	=       $getToolresponse->jobid;
                $round                  =	$request['round'] 	=   $getToolresponse->round;
                $request['end_time']    =       $endtime;
                
                $round_arr              =       \Config::get('constants.ROUND_NAME');
                $validation_arr         =       [   
                                                    'token' 	=> 'required',
                                                    'status' 	=> 'required|numeric',
                                                    'job_id' 	=> 'required',
                                                    'round' 	=> 'required',
                                                    'end_time' 	=> 'required'
                                                ];
                
                if( 'S650' == $round_arr[$round] ){
                    
                }else{
                    
                    $metaid                     =       $request['metaid']      =   $getToolresponse->chapterid;
                    $validation_arr['metaid']   =       'required';
                    
                }
                
                $validation             =       Validator::make( $request->all() , $validation_arr );
                
                if( $validation->fails() ){
                    return response()->json( $validation->errors() );
                }
                
                //update tool response
                $status                     =       trim( $getToolresponse->status );
                $token                      =       trim( $getToolresponse->tokenkey );
                $updatedata                 =       [];
                $updatedata['REMARKS']      =       trim( $getToolresponse->remarks );
                $updatedata['END_TIME']     =       $endtime;
                $updatedata['STATUS']       =       $status;
                $updatedata['STATUS']       =       $status;
              
                $rec                        =       apiFtpUpload::where( 'TOKEN_KEY' , $getToolresponse->tokenkey )
                                                        ->where( 'STATUS' , '=' , '1.5' )
                                                        ->where( 'ROUND' , '=' , $round );
                
                if( 'S650' == $round_arr[$round] ){
                    $rec    =   $rec->where( 'JOB_ID' , '=' , $jobid )->first();
                }else{
                    $rec    =   $rec->where( 'METADATA_ID' , '=' , $metaid )->first();
                }
                
                if( count( $rec ) >=1 ){
                    
                    $rowid              =       $rec->ID;
                    $api_pft            =       new apiFtpUpload();
                    $updatemeta         =       $api_pft->updateIfExist( $updatedata , $rowid );
                    
                    if( $updatemeta ){
                        
                        if( 'S650' !== $round_arr[$round] ){
                            $this->sendMailNotificationForUpload( $rec->JOB_ID , $rec->METADATA_ID , $rec->ROUND , $getToolresponse );
                        }else{
                            $this->sendMailNotificationForMonoEproofUpload( $rec->JOB_ID , $rec->ROUND , $getToolresponse );
                        }
                        
                        $result         =   array( 'status'=>1 , 'msg' => 'Success' , 'errMsg' => 'Response received Successfully' , 'token' => '' );
                        return response()->json($result);
                        
                    }
                    
                    $result 		=   array( 'status'=>0 , 'msg' => 'Error' , 'errMsg' => 'Try again some issue' , 'token'=> $token.' is not valid token');
                    return response()->json( $result );
                    
                }
                
                $result 		=   array( 'status' => 0 , 'msg' => 'Error' , 'errMsg' => 'Invalid data sending try again' , 'token' => '' );
                return response()->json( $result );
                
            }
            
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Invalid data sending try again','token'=>'');
            return response()->json($result);
            
        }catch( \Exception $e ){
            
            $result         =   array( 'result'=>500 , 'errMsg'=>$e->getMessage() , 'traces' => $e->getTraceAsString() );   
            return response()->json($result);
            
        }
        
    }
    
    public function sendMailNotificationForUpload( $jobid , $metaid , $round ,  $toolsresponse ){
        
        $mailArray          =       array();
        $jobDetails         =       DB::table('job')->where('JOB_ID', $jobid )->get();
        
        if( count( $jobDetails ) ){            
            
            $jobDetails             =       $jobDetails[0];
            $bookid                 =       $jobDetails->BOOK_ID;
            $pm_userid              =       $jobDetails->PM;
        
            $tsklMeta               =       new taskLevelMetadataModel();
            $meta_info              =       $tsklMeta->getMetadatadetailsChapter( $metaid );
            $metadata               =       $meta_info->toArray();
            $metadata               =       $metadata[0];
            $chap_name              =       $chapterno      =       $metadata['CHAPTER_NO'];
            
            $mailData['Title']      =   'Eproof Package Upload Alert';
            $mailData['HeadLine']   =   'Eproof upload Alert';  
            $mailData['ToName']     =   'Dear PM';  
            $mailData['BookId']     =   $bookid;  
            //$mailData['chap_no']    =   $chapterno;  
            $mailData['status_str'] =   ( $toolsresponse->status == 2 ) ? 'SUCCESS' : 'FAILED';  
            
            $chpter_no                  =       preg_replace( '/\D/' , '', $chap_name );
            $mailData['chap_no']        =       $chpter_no;
            $mailArray['Data']          =       $mailData;
                
            $mailArray['Subject']       =       'Springer :: Eproof Upload Notification :: BookID: '.$bookid.' :: Chapter No. - : '.$chpter_no. ' :: eproof_Contri';               
            $mailArray['FromMail']      =       'SPI-eProofing@spi-global.com';
            $mailArray['ToMail']        =        \Config::get('constants.ART_CORRECTION_MAIL_ALERT');
            
            if(!empty($pm_userid) && false ){
            
                $usrC_obj               =       new usersController();
                $user_arr               =       $usrC_obj->getUserInfoByUserId( $pm_userid ); 
                $pm_name                =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
                $pm_mail                =       $user_arr->EMAIL;
                $mailData['ToName']     =       'Dear '.$pm_name;
                $mailArray['ToMail']    =       $pm_mail;

            }
            
            $mailArray['TemplateName']  =        'emailtemplate.download.eproofUploadStatusAlert';
            
            $clientAck                  =        new clientAcknowledgementController();
            $clientAck->sendMailBladeTemplate( $mailArray );

                return true;
            
        }else{
            
            return false;
            
        }
        
    }
    
    public function sendMailNotificationForMonoEproofUpload( $jobid , $round ,  $toolsresponse ){
        
        $mailArray          =       array();
        $jobDetails         =       DB::table('job')->where('JOB_ID', $jobid )->get();
        
        if( count( $jobDetails ) ){            
            
            $jobDetails             =       $jobDetails[0];
            $bookid                 =       $jobDetails->BOOK_ID;
            $pm_userid              =       $jobDetails->PM;
            //$tsklMeta               =       new taskLevelMetadataModel();
            //$meta_info              =       $tsklMeta->getMetadatadetailsChapter( $metaid );
            //$metadata               =       $meta_info->toArray();
            //$metadata               =       $metadata[0];
            //$chap_name              =       $chapterno      =       $metadata['CHAPTER_NO'];
            
            $mailData['Title']      =   'Eproof Package Upload Alert';
            $mailData['HeadLine']   =   'Eproof upload Alert';  
            $mailData['ToName']     =   'Dear PM';  
            $mailData['BookId']     =   $bookid;  
            //$mailData['chap_no']    =   $chapterno;  
            $mailData['status_str'] =   ( $toolsresponse->status == 2 ) ? 'SUCCESS' : 'FAILED';  
            
            //$chpter_no                  =       preg_replace( '/\D/' , '', $chap_name );
            //$mailData['chap_no']        =       $chpter_no;
            $mailArray['Data']          =       $mailData;
            $mailArray['Subject']       =       'Springer :: Eproof Upload Notification :: BookID: '.$bookid.' :: eproof_Mono';
            $mailArray['FromMail']      =       'SPI-eProofing@spi-global.com';
            $mailArray['ToMail']        =       \Config::get('constants.ART_CORRECTION_MAIL_ALERT');
            
            if(!empty( $pm_userid ) && false ){
            
                $usrC_obj               =       new usersController();
                $user_arr               =       $usrC_obj->getUserInfoByUserId( $pm_userid ); 
                $pm_name                =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
                $pm_mail                =       $user_arr->EMAIL;
                $mailData['ToName']     =       'Dear '.$pm_name;
                $mailArray['ToMail']    =       $pm_mail;

            }
            
            $mailArray['TemplateName']  =        'emailtemplate.download.eproofUploadStatusAlertS650';
            
            $clientAck                  =        new clientAcknowledgementController();
            $mailres                    =        $clientAck->sendMailBladeTemplate( $mailArray );

            return true;
            
        }else{
            
            return false;
            
        }
        
    }
    
    
}