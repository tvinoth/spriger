<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\ApiModel;
use App\Models\jobRevisedModel;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\productionFileTransferController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Models\taskLevelMetadataModel;
use App\Models\projectModel;
use App\Http\Controllers\CommonMethodsController;
use App\Models\bookinfoModel;

use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class revisedJobController extends Controller
{  
    protected $revisedtypedata;
    protected $receipttypedata;
    public function __construct(){  
        parent::__construct();
        $this->revisedtypedata  =   Config::get('constants.REVISED_PROCESS_TYPE.REVISED_RECEIPT');
        $this->receipttypedata  =   Config::get('constants.REVISED_PROCESS_TYPE.REVISED_RECEIPT');
    }
    
    public function doJobrevised(Request $request)
    {      
        try
        {
            if($request->method()   ==  "POST")
            {
                $validation 	= 	Validator::make($request->all(), [
                                                                            'bookid' => 'required',
                                                                            'roundid' => 'required',
                                                                            'jobsheetname' => 'required|file|mimes:xml'
                                                                    ]);

                if ($validation->fails())
                {
                    $response 	=	array('result'=>400,'errMsg'=>'All fields are required','validation'=>$validation->errors());
                    return response()->json($response);
                }
                $datetime       =   date('Y-m-d H-i-s');                
                $job_id         =   "";
                $bookid         =   trim($request->input('bookid'));
                $roundid        =   trim($request->input('roundid'));
                $jobsheetfile   =   $request->file('jobsheetname');
                $getbookinfo    =   jobModel::where('BOOK_ID',$bookid)->first();
                if(count($getbookinfo)>=1)
                {
                     $job_id    =      $getbookinfo->JOB_ID;
                }
                else
                {
                    $response 	=	array('result'=>400,'errMsg'=>'Invalid Book Id','validation'=>'Invalid Book Id');
                    return response()->json($response);
                }
                $getroundinfo   =   roundModel::where('NAME',$roundid)->first();
                if(count($getbookinfo)>=1)
                {
                    $roundid    =      $getroundinfo->NAME;
                }
                else
                {
                    $response 	=	array('result'=>400,'errMsg'=>'Invalid Round Id','validation'=>'Invalid Round Id');
                    return response()->json($response);
                }
                $getlocationftp     =   productionLocationModel::doGetLocationname( $job_id );         
                if(count($getlocationftp)>=1)
                {
                    $hostserver     =   $getlocationftp->FTP_HOST;
                    $hostusername   =   $getlocationftp->FTP_USER_NAME;
                    $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    $hostpath       =   $getlocationftp->FTP_PATH;
                    // Do the FTP connection
                    $ftpObj         =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
                    $getuserid      =   Session::get('users')['user_id'];
                    
                    $jobfiles       =   Config::get('constants.UPDATED_JOBSHEET_PATH');
                    
                    $jobfiles       =   str_replace( 'BOOK_ID' ,$bookid, $jobfiles );
                    $jobfiles       =   str_replace( 'ROUND_NAME' ,$roundid, $jobfiles );
                    
                    $sourcefile     =   $hostpath.$jobfiles;
                    $xmlFilePath    =   "";
                    $cucxmlfilename =   '';
                    //get all files from ftp based on given folder name
                    $serverDirFiles     =   $ftpObj->allFiles($sourcefile);
                    foreach($serverDirFiles as $value)
                    {
                        if(pathinfo($value)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $value;
                        }
                    }
                    if(!empty($xmlFilePath)) 
                    {
                        //check directory exist or not
                        $checkdirexistchapter   =   $ftpObj->has($xmlFilePath);
                        $backupfile         =   Config::get('constants.JOBSHEET_BACKUP_FOLDER');
                        $createbackup       =   $sourcefile.$backupfile.$datetime;
                        if($ftpObj->has($createbackup))
                        {
                            
                        }
                        else
                        {
                            $cucDirFiles=   $ftpObj->makeDirectory($createbackup,0777);
                        }
                        if(strpos($xmlFilePath,'/') !== 	false)
                        {
                            $cucxmlfilename     =   substr(strrchr($xmlFilePath, "/"), 1);
                        }
                        if($ftpObj->has($createbackup))
                        {
                            $putfile    =   $ftpObj->copy($xmlFilePath,$createbackup.'/'.$cucxmlfilename,0777);
                        }
                        if($ftpObj->has($xmlFilePath))
                        {
                            $ftpObj->delete($xmlFilePath);
                        }
                    }
                    $filename           =   $jobsheetfile->getClientOriginalName();
                    $fileupload         =   $ftpObj->put($sourcefile.$filename,$jobsheetfile->getClientOriginalName());    
                    $remarks            =   "";
                    $remarks            =   ($fileupload  ==  true?"Job Sheet copied successfully":"Job Sheet copied failed try again");
                    $datainsert         =   [];
                    $datainsert['JOB_ID']   =   $job_id;
                    $datainsert['ROUND']    =   $roundid;
                    $datainsert['CREATED_BY']   =   $getuserid;
                    $datainsert['REMARKS']      =   $remarks;
                    $datainsert['CREATED_DATE'] =   Carbon::now();
                    $storeresponse      =   jobRevisedModel::store($datainsert);
                    if($storeresponse>=1)
                    {
                        $response 	=	array('result'=>200,'errMsg'=>'Job Sheet uploaded successfully','validation'=>'');
                        return response()->json($response);
                    }
                    $response 	=	array('result'=>400,'errMsg'=>'Job Sheet uploaded failed try again','validation'=>'');
                    return response()->json($response);
                }
                $response 	=	array('result'=>400,'errMsg'=>'Production location not found','validation'=>'');
                return response()->json($response);
            }
        }
        catch(\Exception $e )
        {
            $response 	=	array('result'=>400,'errMsg'=>$e->getMessage(),'validation'=>'');
            return response()->json($response);
        }
    }
     
    public function revisingJobsheetAtDownload( $metaExtractorData , &$response ){
       
        extract( (array)$metaExtractorData );
        
        $bookid              =       $MetadataExtraction->BookID;
        $roundFrm            =       'S'.$Download->Stage;   
        $round_arr           =       \Config::get('constants.ROUND_ID');
        $response            =       array();
        
        $response['default_jobsheet_path']      =       '';
        
        $round               =       $round_arr[$roundFrm];
       
        $jst                 =       $MetadataExtraction->JobSheet;
        
        $out_validation      =       array();   // this will hold jobid , metaid for feature method extraction.
        
        //check the revised is needed
        $rvsd_validation      =       $this->validatingRevisedJsEntrysOnJobAndTaskLevel( $bookid , $jst , $round , $out_validation );
        
        //do the revising
        if( $rvsd_validation ){  
           extract( $out_validation );
           
            if( isset( $jobId ) && !isset( $metaid ) ){
				
                $response['default_jobsheet_path']  =   $this->revisingProcessJobLevel( $jobId , $round,$this->receipttypedata );
                $response['processType']            =   'JobLevel';
                $response['jobId']                  =   $jobId;
                $response['round']                  =   $round;
                $response['metaid']                 =   '';
                
                //Revised receipt entry
                //$revised_receipturl                 =   url('/').'/api/sendInputForJobsheetUpdate/'.$jobId.'/'.$round.'/'.$this->receipttypedata;
                
               //$cmn_obj                            =   new CommonMethodsController();
               //$revisedreceiptentry                =   $cmn_obj->getcUrlExecution($revised_receipturl);
				
            }
           
            if( isset( $jobId ) && isset( $metaid ) ){
				
                $response['default_jobsheet_path']  =   $this->revisingProcessTaskLevel( $jobId , $round , $metaid ,$this->receipttypedata);
                $response['processType']            =   'TaskLevel';
                $response['jobId']                  =   $jobId;
                $response['round']                  =   $round;
                $response['metaid']                 =   $metaid;
				
                //switch($round){
                    
                    //case $round_arr['S200'] :
                        
                        //$revised_receipturl                 =   url('/').'/api/sendInputForJobsheetUpdate/'.$jobId.'/'.$round.'/'.$this->receipttypedata.'/'.$metaid;
                        //$cmn_obj                            =   new CommonMethodsController();
                        //$revisedreceiptentry                =   $cmn_obj->getcUrlExecution( $revised_receipturl );
                        
                    //break;
                    
                //}
                
            }
           
           return $response;
           
        }
        
        return false;        
        
    }
    
    
    public function validatingRevisedJsEntrysOnJobAndTaskLevel( $bookid , $jst_obj ,  $round  , &$output ){
        
        $metaid              =       $jobId     =       null;
        $taskLevelInf        =       $this->getMetaidForThisJobsheet( $jst_obj , $bookid );
        
        extract( $taskLevelInf );        
        $bookdetails         =       DB::select( 'select j.JOB_ID from job j left join api_download apd on apd.BOOK_ID = j.BOOK_ID where apd.ROUND = '.$round.' and apd.BOOK_ID = "'.$bookid.'"' );           
        
        $round_arr           =       \Config::get('constants.ROUND_ID');
        
        if( !empty( $bookdetails ) && !empty($round) ){
            $jobId           =       $bookdetails[0]->JOB_ID;
        }
        
        if( isset( $jobId ) && isset( $metaid ) && !empty( $metaid ) && ( in_array( $round_arr[$round] , array(  'S200' , 'S300' ) ) ) ){ 
            
            $output['metaid']   =       $metaid;
            $output['jobId']    =       $jobId; 
            
            $checkExistDownloadEntry    =       'SELECT ID FROM api_download apd WHERE apd.ROUND = '
                    .$round.' and apd.BOOK_ID = "'.$bookid.'" and apd.METADATA_ID = '.$metaid.' AND apd.IS_COMPLETED=1 AND apd.IS_ACTIVE=1 limit 1';
            
            $downLoadDetails         =       DB::select( $checkExistDownloadEntry );
            
            if( count( $downLoadDetails ) )
                return true;
            
        }else if( !empty( $jobId ) && !is_null( $jobId ) && ( in_array( $round_arr[$round] , array(  'S5' , 'S50' ) ) ) ){
            
            //for job available case handle here
            $output['jobId']   =   $jobId;        
            
            return true;
            
        }else{
            return false;
            
        }
        
        return false;
    }
        
    public function getMetaidForThisJobsheet( $jobsheetDetails, $bookid ){
       
        $jobDetails     =       ApiModel::getJobDetails( $bookid );
        
        $metaId         =   '';
        $chapterNo      =   '';
        
        if(empty($jobDetails)){
            return array( 'processType' => 'book' , 'metaid' =>  null ,  'chapterid' => null );
            
        }
        $taskLevelObj   =       taskLevelMetadataModel::getMetadatadetailsJob($jobDetails->JOB_ID);
       
        $processType    =       'chapter';
        
        if(isset($jobsheetDetails->JobSheet)){
            
            $articleNo        =     $jobsheetDetails->JobSheet->ChapterID;
            if(empty($articleNo) && !empty($jobsheetDetails->JobSheet->PartID)){
                $articleNo    =     $jobsheetDetails->JobSheet->PartID;
                $processType  =     'part';
            }
            
        }else{
            
            $articleNo      =   (isset($jobsheetDetails->ChapterID)?$jobsheetDetails->ChapterID:"");
            if(empty($articleNo) && !empty($jobsheetDetails->PartID)){
                $articleNo    =     $jobsheetDetails->PartID;
                $processType  =     'part';
            }
            
        }
        
        if(  $taskLevelObj->count() == 0 ){
            
            $metaId         =   null;
            $chapterNo      =   null;
            $processType    =   'book';
        }
        
        if(!empty($taskLevelObj)) {
            
            foreach ($taskLevelObj  as $key => $data){
                
                if($processType == 'chapter'){
                    
                    if($data->FM_ARTICLE_BM == '2' || $data->FM_ARTICLE_BM == '1' || $data->FM_ARTICLE_BM == '3'){
                        
                       $chapterNos = explode('_',$data->CHAPTER_NO) ;
                      
                       if(!empty($chapterNos['1']) && $chapterNos['1'] == $articleNo ){
                           $metaId      =   $data->METADATA_ID;
                           $chapterNo   =   $data->CHAPTER_NO;
                       }else{
                           if(!empty($chapterNos['0']) && $chapterNos['0'] == $articleNo){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
                       }
                    }
                }
				
                if($processType == 'part'){
                    
                    if($data->FM_ARTICLE_BM == '4'){
                      
                       $chapterNos = explode('_',$data->CHAPTER_NO) ;
                     
                       if(!empty($chapterNos['1']) && $chapterNos['1'] == $articleNo ){
                           $metaId      =   $data->METADATA_ID;
                           $chapterNo   =   $data->CHAPTER_NO;
                       }else{
                           if(!empty($chapterNos['0']) && $chapterNos['0'] == $articleNo){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
						   
                           $partId   =  '';
                           $partId   = 'PART'.$articleNo;
						
                           if(empty($metaId) && !empty($chapterNos['0']) && $chapterNos['0'] == $partId){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
                                                      
                       }
                    }
                }
                /** Part and other information need work **/
            }
        }
        
        $returnData['metaid']       =   $metaId ;
        $returnData['chapterid']    =   $chapterNo ;
        $returnData['processType']    =   $processType ;
        
        return $returnData;
        
    }
    
    public function reviseTest(){
        
    }
    
    public function backupRawFilePathLocation($jobId, $round, $metaid = null ,$originalsrcpath = null,$originaldestpath = null){
        
        $bookdetaills       =       jobModel::getJobdetailsRawQuery( $jobId,'job.BOOK_ID' );
        $bookid             =       (!empty($bookdetaills)?$bookdetaills->BOOK_ID:'');
        $base_url           =       \Config::get('constants.BASE_URL');
       
        $input_arr          =       array( 
                                            'book_id'   =>    $bookid, 
                                            'filepath'   =>  '' , 
                                            'callbackUrl'   =>  $base_url.'/api/productionFileTransferCallback'
                                        );
        
        $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
        
       //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);
        
        $production_file_server_ip  =   $hostserver.$hostpath;
        $cn_user        =       $hostusername;
        $cn_pass        =       $hostpassword;
        $credentials    =       '<>'.$cn_user.'<>'.$cn_pass;
        $root           =       Config::get('constants.FILE_SERVER_ROOT_DIR');
        $rawpath        =       Config::get('constants.SPLIT_SOURCE_PATH');
        $copyEditingpath        =       Config::get('serverconstants.COPY_EDITING_PRODUCTION_PATH');
        
        $s50Round       =       Config::get('constants.JOB_ASSIGNED_CONST');
        $roundname_arr  =       \Config::get('constants.ROUND_NAME');
        $roundname      =       $roundname_arr[$round];
        
        $inp_rep_arr        =   array( 
                                        'BOOK_ID'        =>      $bookid , 
                                        'ROUND_NAME'     =>      $roundname ,
                                        '{BID}'          =>      $bookid , 
                                        '{RID}'          =>      $roundname , 
                                     );
        
        if( !is_null( $metaid )  ){
            $chaptername                =       '';
            $tlm                        =       new taskLevelMetadataModel();
            $taskLevelInfo              =       $tlm->getMetadatadetailsChapter( $metaid );
            $chapterlist                =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray();
            $inp_rep_arr['{CID}']       =       $chapterlist[0];
        }
            
        $cmn_obj                        =       new CommonMethodsController();
        
        switch( $roundname ){
            case 'S200':
                    $copyEditingpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $copyEditingpath );
                    $file_copy_to       =       $hostpath.$copyEditingpath;
                    $file_copy_to     =   rtrim($file_copy_to,"/");;
                break;
				
				case 'S300':
                    $copyEditingpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $copyEditingpath );
                    $file_copy_to       =       $hostpath.$copyEditingpath;
                    $file_copy_to     =   rtrim($file_copy_to,"/");;
                break;
				
            default : 
                    $rawpath            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $file_copy_to       =       $hostpath.$rawpath;
                break;
        }
        
        $ftpObj         =       new ftpFileHandlerController( $hostserver, $hostusername, $hostpassword );
        // file copy within raw file stage wise
        if(!empty($originalsrcpath) && !empty($originaldestpath)){
            $response_copy  =       $ftpObj->ftpSingleFileCopyOrMove(  $originalsrcpath , $originaldestpath , false );
        }
        
        $destPath       =       $file_copy_to.'/'.date('Y_m_d_h_i_s');
        $src            =       $file_copy_to;
        $dirExist       =       $ftpObj->ftp_is_dir( $src );
        $response       =       true;
        
        /*if($dirExist == true && false ){
            $response       =       $ftpObj->ftpRename( $src, $destPath );
        }*/
        
        return $response;
       
    }
    
    public function revisingProcessJobLevel( $jobId , $round,$processtype   =   "RECEIPT" ){
        
        
       
        //To do the where the current process is going on and put filename to backup the js
        $round_arr           =       \Config::get('constants.ROUND_ID');
        $currenttime        =   date('Y_m_d_h_i_s');
        $fileName            =       $round_arr[$round].'_'.$currenttime.'.xml';
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );     
        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       $getlocationftp->FTP_PATH;
        $crd                =       'ftp://'.$hostusername.':'.$hostpassword.'@';   
        
        $js_cpy_const       =       Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $raw_js_cpy_const   =       Config::get('serverconstants.RAW_PATH_FULL_INFO');
        $cmn_obj            =       new CommonMethodsController();
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $defaultCopyPath    =       str_replace( '\\\\' , '' , $defaultCopyPath );
        $defaultrawCopyPath    =       $cmn_obj->backslashPathPrepare( $raw_js_cpy_const , true );
        $defaultrawCopyPath    =       str_replace( '\\\\' , '' , $defaultrawCopyPath );
        
        $naming             =       \config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        
        $namin_convention   =       $naming[$round_arr[$round]];
        $bookInfo           =       jobModel::getJobdetailsRawQuery( $jobId,'job.BOOK_ID' );
        $bookid             =       $bookInfo->BOOK_ID;
        $srcsameplacefilecopysrcpath   =   $defaultrawCopyPath.$bookid.$namin_convention;
        $srcsameplacefilecopydestpath   =   $defaultrawCopyPath.$currenttime.'\\'.$fileName;
        $src_path           =       $defaultCopyPath.$bookid.$namin_convention;
        
        $rpl_array          =       array(  'BOOK_ID' => $bookid  ,  'STAGE_NAME' => $round_arr[$round]  , '{BID}' => $bookid , '{CID}' => '' , '{RID}' => $round_arr[$round] );
        $src_path           =       $cmn_obj->arr_key_value_replace( $rpl_array  , $src_path  );
        $srcsameplacefilecopydestpath   =       $cmn_obj->arr_key_value_replace( $rpl_array  , $srcsameplacefilecopydestpath  );
        $srcsameplacefilecopysrcpath   =       $cmn_obj->arr_key_value_replace( $rpl_array  , $srcsameplacefilecopysrcpath  );
	$return_src_path    =       $cmn_obj->arr_key_value_replace( $rpl_array  , $defaultCopyPath  );
		
        $dest_path          =       $defaultCopyPath."BACKUP\\".date('Y-m-d h-i-s')."\\".$fileName;
        $dest_path          =       $cmn_obj->arr_key_value_replace( $rpl_array  , $dest_path  );
       
        $file_server_path   =       str_replace( $getlocationftp->FTP_PATH , ''  , $getlocationftp->FILE_SERVER_PATH );
        
        $file_server_path   =       $cmn_obj->backslashPathPrepare( $file_server_path , false );
        
        $pre_remove         =       str_replace( '/' , '\\' , $file_server_path ); 
//        $pre_remove         =       substr_replace($file_server_path, "", -1);
        $src_path           =       str_replace( $pre_remove , '' , $src_path );
        $srcsameplacefilecopydestpath           =       str_replace( $pre_remove , '' , $srcsameplacefilecopydestpath );
        $srcsameplacefilecopysrcpath           =       str_replace( $pre_remove , '' , $srcsameplacefilecopysrcpath );
        $dest_path          =       str_replace( $pre_remove , '' , $dest_path );
        
        $ftpObj             =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $response_copy      =       $ftpObj->ftpSingleFileCopyOrMove(  $crd.$src_path , $crd.$dest_path , false );
       
        $otherParamLog['STAGE_LEVEL']   =       'BOOK';
        $otherParamLog['REMARKS']       =       'Job Sheet copied successfully';
        $otherParamLog['STATUS']        =       '2';
        
        $returns    =   $this->insertLog( $jobId , $round , $otherParamLog );
        $res                        =   $this->backupRawFilePathLocation($jobId , $round,null,$crd.$srcsameplacefilecopysrcpath,$crd.$srcsameplacefilecopydestpath);
        if($res == true){
            $productionFileTransObj     =   new productionFileTransferController();
            $fileTransRes               =   $productionFileTransObj->locationChangeRequest($jobId,$round,null,$processtype);
        }
        
        return '\\\\'.$return_src_path;
        
    }
    
      public function revisingProcessJobLevelforOst( $jobId , $round ){
        
        //To do the where the current process is going on and put filename to backup the js
        $round_arr           =       \Config::get('constants.ROUND_ID');
        //$fileName            =       $round_arr[$round].'_'.date('Y_m_d_h_i_s').'.xml';
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );     
        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       $getlocationftp->FTP_PATH;
        $crd                =       'ftp://'.$hostusername.':'.$hostpassword.'@';   
        
        $js_cpy_const       =       Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $cmn_obj            =       new CommonMethodsController();
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $defaultCopyPath    =       str_replace( '\\\\' , '' , $defaultCopyPath );
        
        $naming             =       \config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $rawconfig          =       \config::get('constants.RAW_PATH');
        
        $rawPath             =       str_ireplace('/','',$rawconfig);
        
        $jobsheetPath       =       \config::get('constants.JOBSHEETPATH');
        
        
     
        $namin_convention   =       $naming[$round_arr[$round]];
        $bookInfo           =       jobModel::getJobdetails( $jobId );
        $bookid             =       $bookInfo->BOOK_ID;
        $src_path           =       $defaultCopyPath.$bookid.$namin_convention;
        
        $namingExp          =       explode( '.' , $namin_convention );
        $fileName           =       $bookid.$namingExp[0].'.xml';
        
        $rpl_array          =       array(  'BOOK_ID' => $bookid  ,  'STAGE_NAME' => $round_arr[$round]  , '{BID}' => $bookid , '{CID}' => '' , '{RID}' => $round_arr[$round] );
        $src_path           =       $cmn_obj->arr_key_value_replace( $rpl_array  , $src_path  );
        $return_src_path    =       $cmn_obj->arr_key_value_replace( $rpl_array  , $defaultCopyPath  );
        
      
        $rawJobsheetPath    =       str_ireplace($jobsheetPath,$rawPath,$return_src_path);
       
        $copyPath['rawJobsheet']   =  $rawJobsheetPath;
        $copyPath['jobsheet']      =  $return_src_path;
        
        $dest_path          =       $defaultCopyPath."BACKUP\\".date('Y-m-d h-i-s')."\\".$fileName;   
        $dest_path          =       $cmn_obj->arr_key_value_replace( $rpl_array  , $dest_path  );
        
        $file_server_path   =       str_replace( $getlocationftp->FTP_PATH , ''  , $getlocationftp->FILE_SERVER_PATH );
    
        $file_server_path   =       $cmn_obj->backslashPathPrepare( $file_server_path , false );
       
        $pre_remove         =       str_replace( '/' , '\\' , $file_server_path ); 
      //  echo $file_server_path;exit;
      //  $pre_remove         =       substr_replace($file_server_path, "", -1);
        //echo $pre_remove;exit;
        
        $src_path           =       str_replace( $pre_remove , '' , $src_path );
        $dest_path          =       str_replace( $pre_remove , '' , $dest_path );
        
        $ftpObj             =       new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
       
        $response_copy      =       $ftpObj->ftpSingleFileCopyOrMove(  $crd.$src_path , $crd.$dest_path , true );
       
        $otherParamLog['STAGE_LEVEL']   =       'BOOK';
        $otherParamLog['REMARKS']       =       'Job Sheet copied successfully';
        $otherParamLog['STATUS']        =       '2';
        
        $returns                        =       $this->insertLog( $jobId , $round , $otherParamLog );
        
             
       /*  $res                            =   $this->backupRawFilePathLocation($jobId , $round,null,null,null);
            if($res == true){
                $productionFileTransObj     =   new productionFileTransferController();
                $fileTransRes               =   $productionFileTransObj->locationChangeRequest($jobId,$round);
            }
         * 
         */
        return $copyPath;
        
    }
     
    public function revisingProcessTaskLevel( $jobId , $round , $metaid, $processtype   =   "RECEIPT" ){
        
        //To do the where the current process is going on and put filename to backup the js
        $round_arr           =      \Config::get('constants.ROUND_ID');
        //$fileName            =      $round_arr[$round].'_'.date('Y_m_d_h_i_s').'.xml';
        $currenttime        =   date('Y_m_d_h_i_s');
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );         
       
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       $getlocationftp->FTP_PATH;
        $crd                =       'ftp://'.$hostusername.':'.$hostpassword.'@';   
        
        $js_cpy_const       =       Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
        $cmn_obj            =       new CommonMethodsController();
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $defaultCopyPath    =       str_replace( '\\\\' , '' , $defaultCopyPath );
        
        // get raw file 
        $raw_js_cpy_const   =       Config::get('serverconstants.RAW_PATH_FULL_INFO');
        $defaultrawCopyPath    =       $cmn_obj->backslashPathPrepare( $raw_js_cpy_const , true );
        $defaultrawCopyPath    =       str_replace( '\\\\' , '' , $defaultrawCopyPath );
        
        $naming             =       \config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $namin_convention   =       '_{JOBSHEETCHNO}'.$naming[$round_arr[$round]];
        $bookInfo           =       jobModel::getJobdetails( $jobId );
        $bookid             =       $bookInfo->BOOK_ID;
        $src_path           =       $defaultCopyPath.$bookid.$namin_convention;
        
        $namingExp          =       explode( '.' , $namin_convention );
        $fileName           =       $bookid.$namingExp[0].'.xml';
        $srcsameplacefilecopysrcpath   =   $defaultrawCopyPath.$bookid.$namin_convention;
        $srcsameplacefilecopydestpath   =   $defaultrawCopyPath.$currenttime.'\\'.$fileName;
        
        $tlm                =       new taskLevelMetadataModel();
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $splitchpno         =       explode( '_' , $chapterlist[0] );
        $chpNo              =       (isset($splitchpno[1]) && $splitchpno[1] != ''?$splitchpno[1]:$chapterlist[0]);
        $rpl_array          =       array(  'BOOK_ID' => $bookid  ,  'STAGE_NAME' => $round_arr[$round]  , '{BID}' => $bookid , '{CID}' =>$chapterlist[0], '{JOBSHEETCHNO}' =>$chpNo  , '{RID}' => $round_arr[$round] );
        $src_path           =       $cmn_obj->arr_key_value_replace( $rpl_array  , $src_path  );
	$srcsameplacefilecopydestpath   =       $cmn_obj->arr_key_value_replace( $rpl_array  , $srcsameplacefilecopydestpath  );
        $srcsameplacefilecopysrcpath   =       $cmn_obj->arr_key_value_replace( $rpl_array  , $srcsameplacefilecopysrcpath  );	
        $return_src_path    =       $cmn_obj->arr_key_value_replace( $rpl_array  , $defaultCopyPath  );
        
        $dest_path          =       $defaultCopyPath."BACKUP\\".$currenttime."\\".$fileName;        
        $dest_path          =       $cmn_obj->arr_key_value_replace( $rpl_array  , $dest_path  );
        
        $file_server_path   =       str_replace( $getlocationftp->FTP_PATH , ''  , $getlocationftp->FILE_SERVER_PATH );
        $file_server_path   =       $cmn_obj->backslashPathPrepare( $file_server_path , false );
        $pre_remove         =       str_replace( '/' , '\\' , $file_server_path ); 
        //$pre_remove         =       substr_replace($file_server_path, "", -1);
        $src_path           =       str_replace( $pre_remove , '' , $src_path );
        $dest_path          =       str_replace( $pre_remove , '' , $dest_path );
        $srcsameplacefilecopydestpath           =       str_replace( $pre_remove , '' , $srcsameplacefilecopydestpath );
        $srcsameplacefilecopysrcpath           =       str_replace( $pre_remove , '' , $srcsameplacefilecopysrcpath );
        
        $ftpObj         =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
        
        $sourcefile  =   substr( $src_path , 0 , strrpos ( $src_path , '\\' )+1 );
        $sourcefile  =   substr( $sourcefile , strpos ( $sourcefile , '\\' )  );
       
        $serverDirFiles     =   $ftpObj->allFiles($sourcefile);
        $xmlFilePath = '';
        foreach($serverDirFiles as $value){
            if(pathinfo($value)['extension'] == 'xml'){
                $xmlFilePath    =   $value;
            }
        }
        
        $xmlFilePath    =       substr( $xmlFilePath ,  strrpos ( $xmlFilePath , '/' )+1 );   
        $src_path       =       substr( $src_path , 0 ,   strrpos ( $src_path , '\\' )+1  );
        $src_path       =       $src_path.$xmlFilePath;
        
        $ftpObj             =       new ftpFileHandlerController( $hostserver, $hostusername , $hostpassword );
        $response_copy      =       $ftpObj->ftpSingleFileCopyOrMove(  $crd.$src_path , $crd.$dest_path , false );

        
        $otherParamLog['STAGE_LEVEL']   =       preg_replace("/[^A-Z]+/", "", $chapterlist[0] );
        
        $otherParamLog['REMARKS']       =       'Job Sheet copied successfully';
        $otherParamLog['STATUS']        =       '2';
        $otherParamLog['METADATA_ID']  =       $metaid;
        
        $returns    =   $this->insertLog( $jobId , $round , $otherParamLog );
        
		switch( $round_arr[$round] ){
		
			case 'S200': 
				
				$res                        =   $this->backupRawFilePathLocation( $jobId , $round , $metaid ,$crd.$srcsameplacefilecopysrcpath , $crd.$srcsameplacefilecopydestpath);
			 
				if($res == true){
					$productionFileTransObj     =   new productionFileTransferController();
					$fileTransRes               =   $productionFileTransObj->locationChangeRequest($jobId,$round,$metaid,$processtype);
				}
				
			break;
                        
                        case 'S300': 
				
				$res                        =   $this->backupRawFilePathLocation( $jobId , $round , $metaid ,$crd.$srcsameplacefilecopysrcpath , $crd.$srcsameplacefilecopydestpath);
			 
				if($res == true){
					$productionFileTransObj     =   new productionFileTransferController();
					$fileTransRes               =   $productionFileTransObj->locationChangeRequest($jobId,$round,$metaid,$processtype);
				}
				
			break;
			
		}
		
        return '\\\\'.$return_src_path;
        
    }
   
    public function insertLog( $jobid , $round , $datainsert ){

        $datainsert['JOB_ID']   =       $jobid;
        $datainsert['ROUND']    =       $round;
        $datainsert['PROCESS']          =       2;
        $datainsert['STATUS']           =       0;
        $datainsert['CREATED_DATE']     =       Carbon::now();
        
        $response   =   jobRevisedModel::store($datainsert);
        if( $response )
            return $response;
        
        return false;
        
    }
    
}