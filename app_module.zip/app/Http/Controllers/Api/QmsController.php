<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\teamModel;
use App\Models\stageModel;
use App\Models\roundModel;
use App\Models\UserModel;
use App\Models\QmsModel;
use App\Models\taskLevelMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
#use Ixudra\Curl\Facades\Curl;
#use Ixudra\Curl\CurlService;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;

class QmsController extends Controller
{
  
     public function __construct( ){ 
        Log::useDailyFiles(storage_path().'/Api/QMS.log');
        Log::info(json_encode($_SERVER['REDIRECT_URL']));
    }
    
  public function getjobDetails(Request $request,$jobid,$userId){
      $requestData        =    $request->getContent();
      
      $response['status'] =  'failed';
      $response['remarks'] =  '';
      
      if(empty($jobid) || empty($userId)){
         $response['remarks'] =  'Invalid parameter';
      }
      
     $jobDetail     =  jobModel::getJobdetails($jobid);
     $userDeatil    =  UserModel::getUserDetails($userId);
     //echo "<pre>";print_r($userDeatil);exit;
     $metaDeatil    =  taskLevelMetadataModel::getMetadatadetailsJob($jobid);
     $getUserTeamDetails =  UserModel::getUserTeamDetails($userId);
    
     if(!empty($metaDeatil)){
         $metaDataDetails = array();
         
         foreach($metaDeatil as $key => $meta){
             $metaDataDetails[] = $meta->CHAPTER_NO;
         }
         $chapters  = implode(',',$metaDataDetails);
     }
    
     $userName      =  $userDeatil->FIRST_NAME .' '.$userDeatil->LAST_NAME;
     
     $data['TitleId']       =   $jobDetail->JOB_ID;
     $data['TitleAcronym']  =   $jobDetail->BOOK_ID;
     $data['JobId']         =   $jobDetail->JOB_ID;
     $data['Isbn']          =   $jobDetail->ISSN_ONLINE;
     $data['Author']        =   $jobDetail->AUTHOR_NAME;
     $data['Chapters']      =   $chapters;
     $data['userid']        =   $userId;
     $data['AccessTypeId']  =   '11';
     $data['UserName']      =   $userName;
     $data['ProjectId']     =   $jobDetail->JOB_ID;
     $authorname            =   ($jobDetail->AUTHOR_NAME    ==  ''?$jobDetail->EDTIOR_NAME:$jobDetail->AUTHOR_NAME);
     $data['ProjectName']   =   $jobDetail->JOB_TITLE.' - '.$authorname;
     $data['PMUserId']      =   $jobDetail->PM;
     $data['TeamId']        =   $getUserTeamDetails->TeamId;
     $data['StageId']       =   '99';
     $data['DepartmentId']  =   ($getUserTeamDetails->departmentId?$getUserTeamDetails->departmentId:'');
	 $managerRoles          =    \Config::get('constants.MANAGER_ROLE_ID');
     
     if(in_array($userDeatil->ROLE_ID,$managerRoles)){
         $data['AccessTypeId']  =   $userDeatil->ROLE_ID;
     }
     
     
     
      $response['status']   =  'success';
      $response['data']     =  $data;
     
      return json_encode($data);
           
  } 
   
  public function getJobList(){
     $jobDetails  =  jobModel::where('IS_ACTIVE',true)->get();
     
     $jobList = array();
     $jobList = array();
     foreach($jobDetails as $key => $data){
         
         $joblist['ProjectId'] = $data->JOB_ID;
         $joblist['ProjectName'] = $data->JOB_TITLE;
         $joblist['ProjectDisplayName'] = $data->JOB_TITLE;
         $jobList[] =   $joblist;
         
     }
      return json_encode($jobList);
      
  }
  
   public function getProcessList(){
     $stageDetails  =  stageModel::where('IS_ACTIVE',true)->get();
     
     $jobList = array();
     $jobList = array();
     foreach($stageDetails as $key => $data){
         
         $joblist['StageId'] = $data->STAGE_ID;
         $joblist['StageDescription'] = $data->STAGE_NAME;
         $jobList[] =   $joblist;
         
     }
      return json_encode($jobList);
      
  }
  
  public function getTeamIdByUser(Request $request,$userId) {
      if(empty($userId))
          return "invalid parameter";
      
        $teamId = QmsModel::getTeamIdByUser($userId);

        foreach($teamId as $key=>$data){
            $team['TeamId']  = $data->SUB_CIRCLE;
        }

        return json_encode($team);
      
  }
  
  public function getAllMangerByTeam(Request $request,$subcircle,$team) {
      
      $teamDetails  = array();
      
      if(empty($subcircle))
          return "invalid parameter";
      
        $userDetails = QmsModel::getUserDetailByTeamTemp($subcircle,$team);
       
        foreach($userDetails as $key=>$data){
            
            $teamInfo['UserId']      = $data->USER_ID;
            $teamInfo['EmailId']     = $data->EMAIL;
            $name                    =  $data->FIRST_NAME;
            if(!empty($data->LAST_NAME)){
                $name                    .= ' '.$data->LAST_NAME;
            }
            $teamInfo['ActualName']  =$name;
            $teamDetails[] = $teamInfo;
        }
        
        return json_encode($teamDetails);
     
  }
  
  public function getAllteam() {
      
        //$teamId = QmsModel::getAllTeamDetails();
      $teamDetails  =  teamModel::where('IS_ACTIVE',true)->get();

        foreach($teamDetails as $key=>$data){
         $teamlist['DepartmentId']            = $data->TEAM_ID;
         $teamlist['DepartmentDescription']          = $data->TEAM_NAME;
         $team[] =   $teamlist;
        }

        return json_encode($team);
      
  }
  
  
  public function getUseridByEmployeeId(Request $request,$employeeId) {
      
        //$teamId = QmsModel::getAllTeamDetails();
          $userDetails  =   UserModel::getUserIdBasedOnEmployeeId($employeeId);
          $user        =   array();
           
          if(!empty($userDetails)){
               foreach($userDetails as $key=>$data){
                $user['UserId']   =   $data->USER_ID;
               }
          }
        
        return json_encode($user);
      
  }
  
  
  
   public function getStageList(){
     $stageDetails  =  roundModel::where('IS_ACTIVE',true)->get();
     
     $jobList = array();
     $jobList = array();
     foreach($stageDetails as $key => $data){
         
         $joblist['StageId'] = $data->ID;
         $joblist['StageDescription'] = $data->NAME;
         $jobList[] =   $joblist;
         
     }
      return json_encode($jobList);
      
  }
  
    public function GetSpikeInfo(Request $request,$jobId){
       
       $metaDeatil    =  taskLevelMetadataModel::getMetadatadetailsJob($jobId);
       $spikeDetails  =  array();
       $chapterDetails =  array();
       foreach($metaDeatil as $key => $metadata){
           
           $chapInfo['CHAPTER_NAME']        =   $metadata->CHAPTER_NAME;
           $chapInfo['CHAPTER_NUMBER']      =   $metadata->CHAPTER_NO;
           $chapInfo['CHAPTER_ORDER']       =   $metadata->CHAPTER_SEQ;
           $chapInfo['CHAPTER_TYPE']        =   $metadata->CHAPTER_NO;
           $chapInfo['PK_CHAPTER_ID']       =   $metadata->METADATA_ID;
           $chapterDetails[] = $chapInfo;
       }
       $spikeDetails['ChapterInfo']         =   $chapterDetails;
       
       $stageDetails  =  stageModel::where('IS_ACTIVE',true)->get();
     
        
        $jobList = array();
        foreach($stageDetails as $key => $data){

            $joblist['PK_PROCESS_ID']          = $data->STAGE_ID;
            $joblist['PROCESS_NAME'] 		   = $data->STAGE_NAME;
            $jobList[] =   $joblist;

        }
         $spikeDetails['ProcessInfo']         =   $jobList;
        
         $stageDetails  =  roundModel::where('IS_ACTIVE',true)->get();
            $jobList = array();
            foreach($stageDetails as $key => $data){

                $joblist['PK_STAGE_ID'] = $data->ID;
                $joblist['STAGE_DESCRIPTION'] = $data->NAME;
                $jobList[] =   $joblist;

            }
            
          $spikeDetails['StageInfo']         =   $jobList;
        
            $data           =   [];    
            $jobDetail     =  jobModel::getJobdetails($jobId);

            $data['FK_PROJECT_ID']      =   $jobDetail->JOB_ID;
            $data['ISBN_NUMBER']        =   $jobDetail->ISSN_ONLINE;
            $data['ISSUE_PII']          =   $jobDetail->ISSN_ONLINE;
            $data['AUTHOR_NAME']        =   $jobDetail->AUTHOR_NAME;
            $data['EDITOR_NAME']        =   $jobDetail->EDITOR_NAME;
            $data['PK_TITLE_ID']        =   $jobDetail->JOB_ID;
            $data['TITLE_ACRONYM']      =   $jobDetail->BOOK_ID;
            $data['TITLE_NAME']         =   $jobDetail->JOB_TITLE;
            $data['TITLE_PATH']         =   '';
     
         $spikeDetails['TitleInfo']         =   $data;
       
       return json_encode($spikeDetails);
   }
    
    
    
    
    
	

}