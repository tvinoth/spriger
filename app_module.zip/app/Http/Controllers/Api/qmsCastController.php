<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\jobModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class qmsCastController extends Controller
{
    public function qmsGetmetaInfo(Request $request)
    {
//        if($request->method()   ==  "POST" && $request->input('tokenkey') == Config::get('constants.THIRDPARTYAPIKEY'))
//        {
//            $validation 	= 	Validator::make($request->all(), [
//                                                                        'tokenkey' => 'required',
//                                                                        'BookId' => 'required'
//                                                                ]);
//
//            if ($validation->fails())
//            {
//                $result         =   array('result'=>0,'errMsg'=>'all fields are required','status' => 0 );   
//                return response()->json($result);
//            }
            $bookid             =   $request->input('BookId'); 
            $bookid             =   "453816_1_En"; 
            $data               =   array('BOOK_ID'=>$bookid);
            $checkexist         =   jobModel::getQmsportdetails($data);
            
            if(count($checkexist)>=1)
            {     
                $response 	=	array('result'  =>  200 ,'msg'=>'Success' , 'status' => 1 ,'response'=>$checkexist );
                return response()->json($response);
            }
            $response 	=	array('result'=>404,'msg'=>$jobID.' Book Id is not exist Try Again.' , 'status' => 0 ,'errorxml'=>$chapternotgeneratexml  );
            return response()->json($response);
//        }
//        $response 	=	array('result'=>401,'msg'=>'Invalid access Try Again.' , 'status' => 0 );
//        return response()->json($response);
    }
}