<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\jobTimeSheet;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelMetadataModel; 
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class ceEstimationController extends Controller
{
    public function getContent($arrayinput,$url)
    {
       // check if cURL installed or not in your system?
        if (!function_exists('curl_init'))
        {
                return 'Sorry cURL is not installed!';
        }
        $ch 	= 	curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
        $postdata 	=	array($arrayinput);
        if ($postdata)
        {
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($postdata));
        }
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 ;Windows NT 6.1; WOW64; AppleWebKit/537.36 ;KHTML, like Gecko; Chrome/39.0.2171.95 Safari/537.36");
        $contents       =   curl_exec($ch);
        $headers        =   curl_getinfo($ch);
        curl_close($ch);
        //echo "<pre>";
        //print_r($contents);
        //print_r($headers);exit;
        return array($contents);
    }
    public function ceEstimationresponse(Request $request)
    {      
        $getToolresponse    =  json_decode(file_get_contents('php://input'));
     
        if(count($getToolresponse)>=1)
        {
            if(count($getToolresponse->workflow)>=1)
            {			
                $request['token']       =   $getToolresponse->workflow->token;
                $request['status'] 	=   $getToolresponse->workflow->status;
                $request['job_id'] 	=   $getToolresponse->workflow->job_id;
                $request['round'] 	=   $getToolresponse->workflow->round;
                $request['end_time']    =   $getToolresponse->workflow->end_time;
                $validation             =   Validator::make($request->all(), [
                                                    'token' 	=> 'required',
                                                    'status' 	=> 'required|numeric',
                                                    'job_id' 	=> 'required',
                                                    'round' 	=> 'required',
                                                    'end_time' 	=> 'required'
                                            ]);
                if ($validation->fails())
                {
                    return response()->json($validation->errors());
                }
                //update ce estimation tool response
                $status 		=   trim($getToolresponse->workflow->status);
                if($status  ==  1 || $status  ==  0)
                {
                    $token              =   trim($getToolresponse->workflow->token);
                    $endtime 		=   trim($getToolresponse->workflow->end_time);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    $updatedata['RESPONSE_LOG'] =   $request->getContent();
                    if(count($getToolresponse->workflow->remarks)>=1)
                    {
                        $updatedata['REMARKS']  =	trim($getToolresponse->workflow->remarks->feedback);
                    }
                    $updatemeta         =   apiCeestimationModel::doupdate($token,$updatedata);
                    $errormetaid        =   "";
                    if($updatemeta)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'','fileid'=>'');
                        return response()->json($result);
                    }
                    $result 		=   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token','fileid'=>$errormetaid.' File id is not matching ');
                    return response()->json($result);
                }    
                //update metainfo table
                $filesread 		=   $getToolresponse->Files;
                if(count($filesread)>=1)
                {
                    $errormetaid    =   "";
                    $updatemeta     =	false;
                    $updatemetadata =	[];
                    $jobtimedata    =   [];
                    foreach($filesread as $key=>$jsonvalue)
                    {
                        $metaID         =   trim($jsonvalue->file_id);
                        $getmetainfo 	=   apiCeestimationModel::checkMetaidexist($metaID);
                        if(count($getmetainfo)>=1)
                        {
                            $updatemetadata     =   array(
                                                        'NO_CHARACTERS'=>trim($jsonvalue->NoOfCharacters),
                                                        'PAGE_COUNT_BY_CHARACTERS'=>trim($jsonvalue->PageCount_ByCharacters),
                                                        'NO_WORDS'=>trim($jsonvalue->NoOfWords),
                                                        'PAGE_COUNT_BY_WORDS'=>trim($jsonvalue->PageCount_ByWords),
                                                        'LAST_MOD_DATE'=>Carbon::now()
                                                    );
                            $updatemeta 	=   apiCeestimationModel::updatemetainfo($updatemetadata,$metaID);
                            unset($updatemetadata);
                            
                        }
                        else
                        {
                                $errormetaid    .=  $metaID.',';
                        }
                    }
                    //update ce estimation tool response
                    $token              =   trim($getToolresponse->workflow->token);
                    $status 		=   trim($getToolresponse->workflow->status);
                    $endtime 		=   trim($getToolresponse->workflow->end_time);
                    $wfJobID 		=   trim($getToolresponse->workflow->job_id);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   $status;
                    $updatedata['RESPONSE_LOG'] =   $request->getContent();
                    if(count($getToolresponse->workflow->remarks)>=1)
                    {
                        $updatedata['REMARKS']  =	trim($getToolresponse->workflow->remarks->feedback);
                    }
                    $errormetaid        =   rtrim($errormetaid,',');
                    $updatemeta         =   apiCeestimationModel::doupdate($token,$updatedata);
                    
                    $tasklevelModelObj  =   new taskLevelMetadataModel();
                    $stageDetails       =   $tasklevelModelObj->getCestimationStageID($wfJobID);
                    if(!empty($stageDetails)){
                        $ceStId       =   $stageDetails['0']->JOB_STAGE_ID;
                        $roundId      =    $stageDetails['0']->JOB_ROUND_ID;
                        $time                       = 	date('Y-m-d H:i:s'); 
                        $setArr        =   array( 'CHECK_IN'  => $time , 'STATUS' => '24');
                        $updateQry     =   DB::table('job_stage')
                                            ->where('JOB_STAGE_ID', $ceStId )
                                            ->update( $setArr );
                        app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($wfJobID,$roundId,'update',$ceStId);
                    }
                    
                    if($updatemeta)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'','fileid'=>'');
                        return response()->json($result);
                    }
                    $result 		=   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token','fileid'=>$errormetaid.' File id is not matching ');
                    return response()->json($result);
                }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Given Files are empty try again','token'=>'','fileid'=>'');
            return response()->json($result);
            }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Work flow data is empty','token'=>'','fileid'=>'');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'','fileid'=>'');
        return response()->json($result);
    }
}