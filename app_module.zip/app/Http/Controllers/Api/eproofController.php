<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Controllers\users\usersController;
use App\Models\productionLocationModel;
use App\Models\jobInfoModel;
use App\Models\jobModel;
use App\Models\apiFtpUpload;
use App\Models\taskLevelMetadataModel;
use App\Models\apiClientAcknowledgement;
use App\Models\eproofPackageModel;
use App\Models\checkoutModel;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\bookinfo\bookinfoController;
use Session;
use Storage;
use Carbon\Carbon;
use Validator;
use File;
use DB;
use Log;
use Config;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\jobStage;
use App\Models\bgprocessPathSetup;
use App\Http\Controllers\custom\errorController;
use App\Models\apiEproofPackagingModel;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\Api\autostageController;



class eproofController extends Controller
{   
    public function doEproofresponse(Request $request)
    {
        try{   
            
            $getToolresponse    =   json_decode( file_get_contents('php://input') );
            
            Log::useDailyFiles(storage_path().'/Api/eproofpackage_create_response.log');
            Log::info(file_get_contents('php://input'));
           
            if(count($getToolresponse)>=1)
            {			
                $endtime =  $getToolresponse->endtime;
                $endtime  =  $endtime[1];
                
                $request['token']       =   $getToolresponse->tokenkey;
                $request['status'] 	=   $getToolresponse->status;
                $request['job_id'] 	=   $getToolresponse->jobid;
                $round      =   $request['round'] 	=   $getToolresponse->round;
                $request['end_time']    =   $endtime;
                $request['process']     =   $getToolresponse->process;
                $request['metaid']      =   isset( $getToolresponse->metaid ) ? $getToolresponse->metaid : '';
                $validation             =   Validator::make($request->all(), [
                                                    'token' 	=> 'required',
                                                    'status' 	=> 'required|numeric',
                                                    'job_id' 	=> 'required',
                                                    'round' 	=> 'required',
                                                    'end_time' 	=> 'required',
                                                    //'metaid' 	=> 'required',
                                                    'process'=> 'required'
                                            ]);
                
                if ( $validation->fails() ){
                    return response()->json($validation->errors());
                }
                
                //update tool response
                $status 		=   trim( $getToolresponse->status );
                $token                  =   trim( $getToolresponse->tokenkey );
                
                $updatedata             =   [];
                
                $updatedata['END_TIME'] =   $endtime;
                $updatedata['STATUS']   =   $status;
                $updatedata['RESPONSE_LOG'] =   $request->getContent();
                
                $startprocess	=	$getToolresponse->startprocess;
                $finalZipName	=	$getToolresponse->finalZipName;
				
                if(isset( $finalZipName ) && !empty( $finalZipName ) ){
                   $updatedata['NEW_PACKAGE_NAME']       =   $finalZipName;
                }

                if(isset( $startprocess ) ){
                   $updatedata['PACKAGE_RESUME_AT']       =   $startprocess;
                }
				
                $remarks                    =   $updatedata['REMARKS']  =   trim($getToolresponse->remarks);
                
                //if( strpos( $remarks , 'ReadMetaChk' ) ){
                    //$updatedata['VALIDATION_STATUS']   =   1;
                //}
                $updatemeta             =   eproofPackageModel::doupdate( $token , $updatedata );
                
                 if( $status == 2 && $updatemeta ){
                     
                    $round_arr      =    \Config::get('constants.ROUND_ID');

                    if( $round == $round_arr['S650'] ){
                        $this->sendRequestForPackagingUploadJobLevel(trim($getToolresponse->jobid) , trim($getToolresponse->round)  );
                    }else {
                        $this->sendRequestForPackagingUploadChapterLevel(trim($getToolresponse->metaid) , trim($getToolresponse->round)  );
                    }
                    
                }
                
                if($updatemeta){
                    $result             =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                    return response()->json($result);
                }
                
                $result 		=   array('status'=>0,'msg'=>'Error','errMsg'=>'Try again some issue','token'=>$token.' is not valid token');
                return response()->json($result);
                
            }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Invalid data sending try again','token'=>'');
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>$e->getTraceAsString());   
            return response()->json($result);
        }
    }
    
    
    public function getLastPackageInfo( $metaid , $round ){
        
        $round_arr          =   Config::get('constants.ROUND_NAME');
       
        if( !is_null( $metaid ) && !is_null( $round ) && $round < $round_arr['S650'] ){
            
            $records        =   DB::select( "SELECT * FROM api_eproof_packaging where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet;
            }
            
        }
        
        if( !is_null( $metaid ) && !is_null( $round ) && $round == $round_arr['S650']  ){
            
            $records        =   DB::select( "SELECT * FROM api_eproof_packaging where JOB_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet;
            }
            
        }
        
        return false;
    }
    
    public function sendRequestForPackagingUploadChapterLevel($metaid , $round )
    { 
        $input_arr                  =   array();        
        $time                       =   date( 'Y-m-d H:i:s' );	    
        
        $response['status']         =   0;
        $response['msg']            =   'Failed';
        $response['errMsg']         =   'Try again after some times';
        $response['msgstatus']      =   '';
        
        $getchapters                =   taskLevelMetadataModel::where('METADATA_ID',$metaid)->first();
        $jobId                      =   (count($getchapters)>=1?$getchapters->JOB_ID:'');
        $getjobdata                 =   jobModel::where('JOB_ID',$jobId)->first();
        $getlocationftp             =   productionLocationModel::doGetLocationname( $jobId );     
        $chaptername                =   '';
        
        if( empty( $getlocationftp ) )
        $getlocationftp             =   productionLocationModel::getDefaultProductionLocationInfo();
        
            $table_name             =   'api_ftp_upload'; 
            $cmn_obj                =   new CommonMethodsController();
            $token_key              =   $cmn_obj->generateRandomString( 16 , $table_name); 
            if(count( $getlocationftp )>=1 && count($getchapters)>=1 && count($getjobdata)>=1){
                $book_id            =   $getjobdata->BOOK_ID;
                //need to dynamicaly bind the production location based on table location
                $ftp_path           =   $getlocationftp->FTP_PATH;
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   $getlocationftp->FTP_PATH;
                $round_name         =   Config::get('constants.ROUND_NAME')[$round];
                $chaptername        =   $getchapters->CHAPTER_NO;
                
                $_upload_path       =   Config::get('constants.PACKAGE_PATH.E_PROOF_PACKAGE_UPLOAD_PATH');
                
                
                $pm_loc_query           =       'select * from job jb left join user u on u.USER_ID = jb.PM left join pm_location_mapping plm '
                                                .' on plm.PROJECT_MANAGER_ID = jb.PM and plm.STATUS = 1 left join production_area_location pal '
                                                . ' on pal.id = plm.PRODUCTION_AREA where jb.JOB_ID = '.$jobId; 
                $record_set             =       DB::select( $pm_loc_query );
                if(  count( $record_set ) ){
                    
                    $pm_loc     =       explode( '_',$record_set[0]->LOCATION_NAME ) ;
                    $pm_loc     =       strtolower( $pm_loc[0]);
                    
                }else{
                         $pm_loc     =      'pondy';
                }
                
                $_upload_path           = str_replace( '{PMLOC}' , $pm_loc, $_upload_path );
               
                $ftp_host           =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
                $ftp_username       =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
                $ftp_password       =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
                $ftp_type           =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
                $fingerPrint        =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');
                
                $travers_filesname      =   '';
                $process_enum           =   array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 , 'WRONG_INSTRUCTION' => 4 , 'PACKAGING' => 5);
                $ptype                  =   $process_enum['PACKAGING'];
                $array_cond_            =   array( 'ROUND' => $round ,'METADATA_ID'=>$metaid );
                $api_dataset            =   eproofPackageModel::where( $array_cond_ )
                                                        ->orderBy('ID' , 'desc')                                               
                                                        ->first();
                if(count($api_dataset)==0){
                    $response['status']     =   0;
                    $response['msg']        =   'Filure';
                    $response['errMsg']     =   'Zip name is empty';                
                    $response['msgstatus']  =   "";
                    return response()->json($response);
                }
                
                $api_tbl_input          =       array( 
                                                'JOB_ID'        =>      $jobId , 
                                                'ROUND'         =>      $round  ,
                                                'PROCESS_TYPE'  =>      '2',
                                                'START_TIME'    =>      Carbon::now() ,
                                                'TOKEN_KEY'     =>      $token_key , 
                                                'STATUS'        =>      '1.5',
                                                'METADATA_ID'   =>      $metaid
                                            );
                
                $travers_filesname      =   $api_dataset->NEW_PACKAGE_NAME;   
                $_file_path             =   \Config::get('constants.FILE_SERVER_ROOT_DIR').Config::get('constants.PACKAGE_PATH.UPLOADDESTINATIONPATH');             
                $inp_rep_arr            =   array( 
                                                '{BID}'     =>   $book_id, 
                                                '{RID}'     =>   $round_name,                 
                                                '{DID}'     =>   $travers_filesname ,
                                                '{CID}'     =>   $chaptername
                                            );
                $_file_path             =   str_replace('PACKAGING','EPROOF_PACKAGING',$_file_path);                
                $_file_path             =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $_file_path );
                $_file_path             =   $cmn_obj->backslashPathPrepare( $hostserver.$_file_path , true );
                $ret_url                =   url('/').'/api/eproofPackageUploadCallback';
                $uploadMeta = "";            
                $uploadMeta .= "<uploadMeta>";
                $uploadMeta .= "<bookid>" . $book_id . "</bookid>";
                $uploadMeta .= "<stage>" . $round_name . "</stage>";
                $uploadMeta .= "<uploadtype>PACKAGE_UPLOAD</uploadtype>";
                $uploadMeta .= "<sourceFile>";
                $uploadMeta .= "<filepath>" .$_file_path."</filepath>";
                $uploadMeta .= "</sourceFile>";
                $uploadMeta .= "<destPath>";
                $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
                $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
                $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
                $uploadMeta .= "<path>".$_upload_path."</path>";
                $uploadMeta .= "<username>".$ftp_username."</username>";
                $uploadMeta .= "<password>".$ftp_password."</password>";
                $uploadMeta .= "</destPath>";
                $uploadMeta .= '<WorkflowAPI>
                                    <Url value="'.$ret_url.'"/>
                                    <parameter key="process" value="upload" type="fixed"/>
                                    <parameter key="jobid" value="'.$jobId.'" type="fixed"/>
                                    <parameter key="chapterid" value="'.$metaid.'" type="fixed"/>
                                    <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                    <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                    <parameter key="round" value="'.$round.'" type="fixed"/>
                                    <parameter key="status" type="boolean"/>
                                    <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                    <parameter key="remarks" type="string"/>
                                </WorkflowAPI>';
                $uploadMeta .= "</uploadMeta>";
                $content 	= 	$uploadMeta;
                $filename 	=	$metaid.'_'.$round_name.'_eproof_packaging_upload_meta.xml';
                Log::useDailyFiles(storage_path().'/Api/eproof_packaging_upload.log');
                Log::info( $uploadMeta );
                $watchpath                        =       Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER');
                $ftpInfo['HOST']                  =       $hostserver;
                $ftpInfo['FTP_USERNAME']          =       $hostusername;
                $ftpInfo['FTP_PASSWORD']          =       $hostpassword;
				 
                $successfileresponse    =       app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );
                if($successfileresponse == true)
                {
                    $getResponse            =   apiFtpUpload::insertNew( $api_tbl_input );
                    $acknow_data            =   array(  
                                                    'JOB_ID'    =>      $jobId ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    'METADATA_ID'=>     $metaid,
                                                    'PROCESS_TYPE_DIFF' =>      5 , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                                );
                    //clientAck insert
                    apiClientAcknowledgement::insertNew( $acknow_data );
                    
                    if( $getResponse >= 1  ){                  
                        $response['status']     =       1;
                        $response['msg']        =       'Success';
                        $response['errMsg']     =       ' upload meta posted successfully';                
                        apiFtpUpload::whereid($getResponse)->first();
                        $response['params'] =   array( 'tokenkey' => $token_key , 'table' => 'api_ftp_upload' , 'waiting' => true );
                    }
                    return json_encode($response);
                }
                return json_encode($response);
            }
            
            
            $result         =   array('status'=> 0 ,'errMsg'=>'Job or chapter data not found','msg'=>'Failure');   
            return joson_encode($result); 
            
            //}catch( \Exception $e ){            
            //$response['errMsg']    =   $e->getMessage();             
            //}         
    }
    
    public function sendRequestForPackagingUploadJobLevel( $jobId , $round ){ 
        
        $input_arr                  =   array();        
        $time                       =   date( 'Y-m-d H:i:s' );	    
        
        $response['status']         =   0;
        $response['msg']            =   'Failed';
        $response['errMsg']         =   'Try again after some times';
        $response['msgstatus']      =   '';
        
        $getjobdata                 =   jobModel::where('JOB_ID',$jobId)->first();
        $getlocationftp             =   productionLocationModel::doGetLocationname( $jobId );     
        $chaptername                =   '';
        
        if( empty( $getlocationftp ) )
        $getlocationftp             =   productionLocationModel::getDefaultProductionLocationInfo();
        
            $table_name             =   'api_ftp_upload'; 
            $cmn_obj                =   new CommonMethodsController();
            $token_key              =   $cmn_obj->generateRandomString( 16 , $table_name ); 
            
            if(count( $getlocationftp )>=1 && count($getjobdata)>=1){
                
                $book_id            =   $getjobdata->BOOK_ID;
                //need to dynamicaly bind the production location based on table location
                $ftp_path           =   $getlocationftp->FTP_PATH;
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   $getlocationftp->FTP_PATH;
                $round_name         =   Config::get('constants.ROUND_NAME')[$round];
                $_upload_path       =   Config::get('constants.PACKAGE_PATH.E_PROOF_PACKAGE_UPLOAD_PATH');
                $chaptername        =       '';
                
                $pm_loc_query           =       'select LOCATION_NAME from job jb left join user u on u.USER_ID = jb.PM left join pm_location_mapping plm '
                                                .' on plm.PROJECT_MANAGER_ID = jb.PM and plm.STATUS = 1 left join production_area_location pal '
                                                . ' on pal.id = plm.PRODUCTION_AREA where jb.JOB_ID = '.$jobId; 
                $record_set             =       DB::select( $pm_loc_query );
                
                if(  count( $record_set ) ){
                    
                    $pm_loc     =       explode( '_',$record_set[0]->LOCATION_NAME ) ;
                    $pm_loc     =       strtolower( $pm_loc[0]);
                    
                }else{
                         $pm_loc     =      'pondy';
                }
                
                $_upload_path           = str_replace( '{PMLOC}' , $pm_loc , $_upload_path );
               
                $ftp_host           =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
                $ftp_username       =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
                $ftp_password       =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
                $ftp_type           =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
                $fingerPrint        =   \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');
                
                $travers_filesname      =       '';
                $process_enum           =       array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 , 'WRONG_INSTRUCTION' => 4 , 'PACKAGING' => 5);
                $ptype                  =       $process_enum['PACKAGING'];
                $array_cond_            =       array( 'ROUND' => $round ,'JOB_ID' => $jobId );
                $api_dataset            =       eproofPackageModel::where( $array_cond_ )
                                                    ->orderBy('ID' , 'desc')                                               
                                                    ->first();
                
                if( count( $api_dataset ) == 0 ){
                    
                    $response['status']     =   0;
                    $response['msg']        =   'Filure';
                    $response['errMsg']     =   'Zip name is empty';                
                    $response['msgstatus']  =   "";
                    
                    return response()->json($response);
                    
                }
                
                $api_tbl_input          =       array( 
                                                    'JOB_ID'        =>      $jobId , 
                                                    'ROUND'         =>      $round  ,
                                                    'PROCESS_TYPE'  =>      '2',
                                                    'START_TIME'    =>      Carbon::now() ,
                                                    'TOKEN_KEY'     =>      $token_key , 
                                                    'STATUS'        =>      '1.5'
                                                );
                
                $travers_filesname      =   $api_dataset->NEW_PACKAGE_NAME;   
                $_file_path             =   \Config::get('constants.FILE_SERVER_ROOT_DIR').Config::get('constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.UPLOADDESTINATIONPATH');             
                $inp_rep_arr            =   array( 
                                                '{BID}'     =>   $book_id, 
                                                '{RID}'     =>   $round_name,                 
                                                '{DID}'     =>   $travers_filesname ,
                                                '{PACKAGEZIPNAME}'     =>   $travers_filesname ,
                                                '{CID}'     =>   $chaptername
                                            );
                $_file_path             =   str_replace('PACKAGING','EPROOF_PACKAGING',$_file_path);                
                $_file_path             =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $_file_path );
                $_file_path             =   $cmn_obj->backslashPathPrepare( $hostserver.$_file_path , true );
                
                $ret_url                =   url('/').'/api/eproofPackageUploadCallback';
                
                $uploadMeta = "";            
                $uploadMeta .= "<uploadMeta>";
                $uploadMeta .= "<bookid>" . $book_id . "</bookid>";
                $uploadMeta .= "<stage>" . $round_name . "</stage>";
                $uploadMeta .= "<uploadtype>PACKAGE_UPLOAD</uploadtype>";
                $uploadMeta .= "<sourceFile>";
                $uploadMeta .= "<filepath>" .$_file_path."</filepath>";
                $uploadMeta .= "</sourceFile>";
                $uploadMeta .= "<destPath>";
                $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
                $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
                $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
                $uploadMeta .= "<path>".$_upload_path."</path>";
                $uploadMeta .= "<username>".$ftp_username."</username>";
                $uploadMeta .= "<password>".$ftp_password."</password>";
                $uploadMeta .= "</destPath>";
                $uploadMeta .= '<WorkflowAPI>
                                    <Url value="'.$ret_url.'"/>
                                    <parameter key="process" value="upload" type="fixed"/>
                                    <parameter key="jobid" value="'.$jobId.'" type="fixed"/>
                                    <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                    <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                    <parameter key="round" value="'.$round.'" type="fixed"/>
                                    <parameter key="status" type="boolean"/>
                                    <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                    <parameter key="remarks" type="string"/>
                                </WorkflowAPI>';
                $uploadMeta .= "</uploadMeta>";
                $content 	= 	$uploadMeta;
                $api_tbl_input['REQUEST_LOG' ] =  $content ;
                $uploadMeta     =       $cmn_obj->formatXmlString( $content );
                $filename 	=	$book_id.'_'.$round_name.'_eproof_package_upload.xml';
                $watchpath                        =       Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER');
                
                $ftpInfo['HOST']                  =       $hostserver;
                $ftpInfo['FTP_USERNAME']          =       $hostusername;
                $ftpInfo['FTP_PASSWORD']          =       $hostpassword;
                
		        $autoStgObj             =            new autostageController();		 
                $successfileresponse    =       $autoStgObj->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );
                
                if($successfileresponse == true){
                    
                    $getResponse            =   apiFtpUpload::insertNew( $api_tbl_input );
                    $acknow_data            =   array(  
                                                    'JOB_ID'    =>      $jobId ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    //'METADATA_ID'=>     $metaid,													
                                                    'PROCESS_TYPE_DIFF' =>      8 , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                                );
                    
                    //clientAck insert
                    apiClientAcknowledgement::insertNew( $acknow_data );
                    
                    if( $getResponse >= 1  ){
                        
                        $response['status']     =       1;
                        $response['msg']        =       'Success';
                        $response['errMsg']     =       ' upload meta posted successfully';     
                        
                        apiFtpUpload::whereid($getResponse)->first();
                        
                        $response['params'] =   array( 'tokenkey' => $token_key , 'table' => 'api_ftp_upload' , 'waiting' => true );
                        
                    }
                    
                    return response()->json( $response , 200 );
                }
                
                return response()->json( $response , 206 );
                
            }
            
            $result         =   array( 'status' => 0 ,'errMsg' => 'Job or chapter data not found' , 'msg'=>'Failure' );   
            return response()->json( $result , 400 ); 
            
            //}catch( \Exception $e ){            
            //    $response['errMsg']    =   $e->getMessage();             
            //}    
            
    }
    
    public function startEproofPackagingS650( $jobid , $round , $typeofprocess = 'package'){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        //$this->customConstructor( $jbstgid );
        $vendorResp	=		$this->doEproofVendorFileCreation( $jobid , $round );
		
		if( $vendorResp['status']  == 0 ){
			
			return response()->json( $vendorResp );
		
		}
		
        $getlocationftp             =       productionLocationModel::doGetLocationname( $jobid );

        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        //$hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $root               =       \Config::get('constants.FILE_SERVER_ROOT_DIR');    
            
        $cmn_obj                    =       new CommonMethodsController();
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , 'api_eproof_packaging' , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        $jbmobj                     =       new jobModel();
        
        $bookinfo           =        $jbmobj->getJobdetails( $jobid );
        $platform           =        $bookinfo->APPLICATION;
        $bookid             =        $bookinfo->BOOK_ID;
        $stageid            =        \Config::get( 'constants.STAGE_COLLEECTION.EPROOF' );
        $round_arr          =        \Config::get('constants.ROUND_NAME');
        $jobsheetpath       =        '';
        
        $preparedDatasetid  =       '';
        $metaid             =       null;
        $bookinfoCont       =       new bookinfoController();
        $preparedDatasetid  =       $bookinfoCont->prepareSpringerNamingConvention( $jobid , $metaid , $round , true , true );
        $without_zip_datasetid        =     str_replace( '.zip' , '' , $preparedDatasetid.'\\' );
        $without_zip_datasetid        =     $without_zip_datasetid;
        
        $pckg_Cont_obj      =       new eproofController();
        $packageInfo        =       $pckg_Cont_obj->getLastPackageInfo( $jobid , $round );
        
        $startProcess       =       0;
        
        if( $packageInfo ){
            $packagename        =       $packageInfo->PACKAGE_ID;
            $packagename        =       str_replace( '.zip' , '' , $packagename );
            $packagename_old    =       $packagename;
            $startProcess       =       isset( $packageInfo->PACKAGE_RESUME_AT ) ? $packageInfo->PACKAGE_RESUME_AT : 0;
        }

        $inp_rep_arr        =       array( 
                                        'BOOK_ID'        =>      $bookid , 
                                        'ROUND_NAME'     =>      $round_arr[$round] ,
                                        '{BID}'          =>      $bookid , 
                                        '{RID}'          =>      $round_arr[$round] , 
                                        '{DID}'             => $preparedDatasetid , 
                                        '{PACKAGEZIPNAME}'  =>  $preparedDatasetid
                                    );
            
        $rawpath                =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S650');
        
        $file_copy_to            =       $hostserver.$root.$rawpath;
        $file_copy_to            =       str_replace( '//' , '/' , $file_copy_to );
        $file_copy_to            =       str_replace( '/' , '\\' , $file_copy_to );            
        
        $rawpath                 =       '\\\\'.$file_copy_to.$bookid.\Config::get( 'constants.JOBSHEET_SUFFIX_CONVENTION.S650' );
        $rawpath2                =       \Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.VENDORXML' );
        $rawpath3                =       \Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.DESTINATION_PATH' );
        $rawpath4                =       \Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.COMPO.COVERJPEG' ).$bookid.'_Cover.jpg';
        
        $file_copy_to2           =       $hostserver.$root.$rawpath2;
        $file_copy_to2           =       str_replace( '//' , '/' , $file_copy_to2 );
        $file_copy_to2           =       str_replace( '/' , '\\' , $file_copy_to2 );            
       
        $file_copy_to3           =       $hostserver.$root.$rawpath3;
        $file_copy_to3           =       str_replace( '//' , '/' , $file_copy_to3 );
        $file_copy_to3           =       str_replace( '/' , '\\' , $file_copy_to3 );   
        
        $file_copy_to4           =       $hostserver.$root.$rawpath4;
        $file_copy_to4           =       str_replace( '//' , '/' , $file_copy_to4 );
        $file_copy_to4           =       str_replace( '/' , '\\' , $file_copy_to4 );   
        
        $vendorpath              =       '\\\\'.$file_copy_to2;
        $desinationpath          =       '\\\\'.$file_copy_to3;
        $coverimg                =       '\\\\'.$file_copy_to4;
        
        $desinationpath         =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $desinationpath );
        $jobsheetpath           =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
        $vendorpath             =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $vendorpath );
        $coverimg             =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $coverimg );
        
        //$coverimg               =       '';
       
        $made_inp               =       array( 
                                            'platform'      =>      $platform ,
                                            'roundidinfo'   =>      $round , 
                                            'round'         =>      $round , 
                                            'roundname'     =>      $round_arr[$round] , 
                                            'bookid'        =>      $bookid ,
                                            'stageid'       =>      $stageid , 
                                            'jobid'         =>      $jobid , 
                                            'jobsheetpath'  =>      $jobsheetpath , 
                                            'vendorxmlpath'     =>      $vendorpath , 
                                            'destinationpath'   =>      $desinationpath , 
                                            'resumepackageat'   =>      $startProcess,
                                            'contactinform' => 1   ,
                                            'coverimgpath'  =>  $coverimg,
                                            'isnonline'  =>  $bookinfo->ISSN_ONLINE ,
                                            'issnp'  =>  $bookinfo->ISSN_PRINT
                                        );  
        
        $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp ) );
                
        $metainfo       =       $this->metainfo;
        $componentInfo  =   '';
        $inputfilepath  =   \Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.COMPO' );
        $addeftpath     =   \Config::get( 'constants.FILE_SERVER_ROOT_DIR');
        $empid          =   \Session::get('users')['emp_id'];
        $findlatestround    =   null;
        
        
        $inp_rep_arr    =   array(  
                                '{BID}' => $bookid ,
                                'BOOK_ID'       =>  $bookid ,
                                'ROUND_NAME'    =>  $round_arr[$round] ,
                                'STAGE_NAME'    =>  $round_arr[$round] , 
                                '{RID}' =>  $round_arr[$round] ,
                                '{EMPID}'   => $empid  , 
                                '{FINDARTLATESTROUND}'    =>    '{FINDARTLATESTROUND}' ,
                                '{ISSNP}' => $bookinfo->ISSN_PRINT
                            );
        
        $cmn_obj            =   new CommonMethodsController();
        $made_inp2          =   array();
        
        foreach( $inputfilepath as $key_in  => $value ){
            
            $lastpath           =   $hostserver.'/'.$addeftpath.Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.COMPO.'.strtoupper( $key_in ) );
            
            if( !empty( Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.COMPO.'.strtoupper( $key_in ) ) ) ){
                $lastpath           =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lastpath , true );
                $lastpath           =   $cmn_obj->backslashPathPrepare( $lastpath , true );
                $made_inp2[strtolower( $key_in )]     =   $lastpath;
            }
            
        }
        
        $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp2 ) );      
        $metainfo       =       $this->metainfo;
        $artmetatags    =       '';   //$artPCont->getArtMetaDataTags($metaid);
        
        $this->getAllComponentInfoForEproofPackaging( $this->metainfo , $componentInfo , $artmetatags );
        
        $made_inp2['artmetatags']           =       $artmetatags;
        $made_inp2['allcomponenteproof']    =       $componentInfo;
        
        $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp2 ) );      
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
        
        try{
            
            $watchPath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.EPROOF_PACKAGE_FOLDER_DEV');
           
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoStageMeta();
            $metafileInput['metafilename']      =       $this->getMetafilename( $this->metainfo );
            $metafileInput['metaContent']       =       $content;
            $metafileInput['watch_folder']      =       $watchPath;
            $metafileInput['ftpInfo']           =       $ftpDefault;
            $api_tbl_input                      =       array();

            //$api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            $api_tbl_input['PACKAGE_ID']         =   $preparedDatasetid;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            
			
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
           
            }catch( \Exception $e ){

                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';

                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );

            }
        
        return response()->json( $response );
    }
    
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){

       if( isset( $optional_param_json ) ){
           if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
               $addionalParam      =       json_decode( $optional_param_json );
               
               if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                   
                   $autopageInput      =       (array)$addionalParam; 
                   $exitsing_meta      =        $this->metainfo;

                   foreach( $addionalParam as $key => $value ){          
                        $this->metainfo[ $key ]     = $value;                              
                   }
                   
               }
           }
       }

   }  
   
    public function getMetafilename( $metainfo ){
        
        extract(  $metainfo );   
        
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        $apc_obj                =       new autoPageController();
        return $filename        =       $bookid.'_Book@'.$roundname.'_eproof_'.$tokenkey.".xml";
        $cmn_obj            =        new CommonMethodsController();
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
   
    public function prepareAutoStageMeta(){
        
        $roundname          =       '';
        extract( $this->metainfo );
         
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        //$tasklev_info         =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
	//$fmbmpartVal          =       intval( $tasklev_info[0]->FM_ARTICLE_BM );
        
        $wrkmstid       =       null;
        $jbstgObj       =       new jobStage();
        $type           =       'INITIALIZE';
        
        //$jbstginfo      =       $jbstgObj->getJobStageInfoByJobStageId( $jbstageid );
        //$noncorrection  =       \Config::get('constants.WORKFLOW.S300.MASTER_ID');
        
        //if( count( $jbstginfo ) ){
            //$wrkmstid       =       $jbstginfo->WORKFLOW_MASTER_ID;
        //}
        
        //if( $fmbmpartVal == 2 && intval( $wrkmstid ) !== intval( $noncorrection ) ){
        //    $type =  'INITIALIZE';
        //}else if( $wrkmstid == $noncorrection &&  $fmbmpartVal == 2 ){
        //    $type =  'NONCORRECTION';
        //}else{
        //    $type =  'FMBMPART';
        //}
         
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        $preparedXml        =       '';    
        
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){

                $processname         =       $svalue->PROCESS_NAME;                
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid , $type  );
               
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid , $type );
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();

                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }

                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
            
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){ 

       $cmn_obj                    =       new CommonMethodsController();
       $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
        if( is_array( $ftpobj )  ){
            $ftpobj 		=	$ftpobj['ftpInfo'];
        }
	   
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       $metaFileInput['metaContent'] =   str_replace( '&' , '&amp;' , $metaFileInput['metaContent'] );
       $getMetaFormat      =          $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
      
       $errorstr           =            '';
       $autoStgObj         =            new autostageController();
       
       //echo '<pre>';
       //echo htmlspecialchars( $getMetaFormat );
       //exit;
        
       $postMetaStatus     =            $autoStgObj->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           
           $insert_ret                     =       apiEproofPackagingModel::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiEproofPackagingModel::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

        return json_encode( $response );
        exit;
        
    }

    public function getAllComponentInfoForEproofPackaging( $metainfoarr , &$componentInfo , &$artmetatags ){
        
        extract( $metainfoarr );
        
        $tskLvlModel        =       new taskLevelMetadataModel();
        
        $taskinfo_stmt      =       "SELECT *
                                        FROM task_level_metadata tlmd
                                        LEFT JOIN metadata_info mi ON mi.METADATA_ID = tlmd.METADATA_ID
                                        LEFT JOIN job j ON j.JOB_ID = tlmd.JOB_ID
                                        WHERE j.JOB_ID = $jobid  and tlmd.UNIT_OF_MEASURE != 556 order by tlmd.CHAPTER_SEQ ";
        
	$bmtypeval			=		\Config::get( 'constants.ARTICLE_BM' );
	$bm_cmpo_cnt	 		=   	taskLevelMetadataModel::select( DB::raw( 'task_level_metadata.METADATA_ID as taskmetaid' ) )
										->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID' )
										->where( 'task_level_metadata.JOB_ID'  , $jobid )
										->where( 'metadata_info.FM_ARTICLE_BM'  , $bmtypeval )
										->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
										->where('task_level_metadata.IS_ACTIVE',true)
										->get()->count();   
																
        $taskinfo           =       DB::select( $taskinfo_stmt );
        $empid              =       \Session::get('users')['emp_id'];
        $xmlstring          =       '';
        
        $xmlconst           =       $xmlfile;
        $pdfconst           =       $pdffile;
        $lowresconst        =       $lowresimagefolder;
        $deltaconst         =       $deltapdffile;
        $apdfconst          =       $authorpdflocation;
        
        
        if( count( $taskinfo ) ){
            
            foreach( $taskinfo as $key => $metaobj ){
                
               //1-FRONT MATTER, 2-ARTICLE, 3-BACK MATTER ,4 -PART,5-COVER
                 
                $apc_obj            =       new autoPageController();
                $paging_collect     =       $apc_obj->getPagingFileNameing( $bookid , $metaobj->CHAPTER_NO ,  $metaobj->METADATA_ID );
                extract( $paging_collect );
                $metaid             =       $metaobj->METADATA_ID;
                
               
                $curartRound       =    null;
                $getArtRoundqry    =   'SELECT ID,CURRENT_ROUND FROM metadata_status WHERE metadata_id = '.$metaid.' ORDER BY id DESC LIMIT 1';
                $getArtRound       =    DB::select( $getArtRoundqry );
                
                if( count( $getArtRound ) ){
                    $curartRound    =   $getArtRound[0]->CURRENT_ROUND;
                }
                  
                $round_arr          =        \Config::get('constants.ROUND_NAME');
                
                $inp_rep_arr        =   array(  
                                            '{BID}' => $bookid ,
                                            'BOOK_ID'       =>  $bookid ,
                                            'ROUND_NAME'    =>  $round_arr[$round] ,
                                            'STAGE_NAME'    =>  $round_arr[$round] , 
                                            '{RID}'         =>  $round_arr[$round] ,
                                            '{EMPID}'       =>  $empid  , 
                                            '{FINDARTLATESTROUND}'    =>   !is_null( $curartRound ) ? $round_arr[$curartRound] : '' ,
                                            '{PAGING_FILENAMING}'     =>    $pagingfilnaming , 
                                            '{CID}'         =>  $metaobj->CHAPTER_NO
                                        );
                
                $artPCont           =       new artProcessController();
                $artmetatags        .=       $artPCont->getArtMetaDataTags( $metaid );
                $cmn_obj            =       new CommonMethodsController();
                
                $lowresimagefolder  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lowresconst , true );
                $lowresimagefolder  =   $cmn_obj->backslashPathPrepare( $lowresimagefolder , true );
                
                $xmlfile           =    $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlconst , true );
                $xmlfile           =    $cmn_obj->backslashPathPrepare( $xmlfile , true );
                
				$pdffile           =    $cmn_obj->arr_key_value_replace( $inp_rep_arr , $pdfconst , true );
                $pdffile           =    $cmn_obj->backslashPathPrepare( $pdffile , true );
                
                $deltapdffile      =    $cmn_obj->arr_key_value_replace( $inp_rep_arr , $deltaconst , true );
                $deltapdffile      =    $cmn_obj->backslashPathPrepare( $deltapdffile , true );
                
                $authorpdflocation =    $cmn_obj->arr_key_value_replace( $inp_rep_arr , $apdfconst , true );
                $authorpdflocation =    $cmn_obj->backslashPathPrepare( $authorpdflocation , true );
                
                //$lowresimagefolder           =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $lowresimagefolder , true );
                //$lowresimagefolder           =   $cmn_obj->backslashPathPrepare( $lowresimagefolder , true );
                $lowrespresentpath      =   !is_null( $curartRound ) ? $lowresimagefolder : '';
                
         	if( $bm_cmpo_cnt == 0 && intval( $metaobj->FM_ARTICLE_BM ) == 6  ){ 
		        $xmlstring          .=      '<component name="BookBackmatter">';
		    }else{
			    $xmlstring          .=      '<component name="'.$packagecomponaming.'">';
		    }
				
		    $spCompo			 	=	  	array( 
											    1 , 4 , 3 , 6
										    );
				
                if( $metaobj->FM_ARTICLE_BM == 5 ){
                    $xmlstring  .=   '<coverjpgimage userbin="">'.$coverimgpath.'</coverjpgimage>';                        
                }else if( in_array(  $metaobj->FM_ARTICLE_BM , $spCompo ) ){
                    
                    $xmlstring  .=   '<xmlfile userbin="">'.$xmlfile.'</xmlfile>';    
		            $xmlstring  .=   '<pdffile userbin=""></pdffile>';  
                    //$xmlstring  .=   '<pdffile userbin="">'.$pdffile.'</pdffile>';    
                    $xmlstring  .=   '<deltapdffile userbin="">'.$deltapdffile.'</deltapdffile>';    
                    //$xmlstring.=   '<EsmDetails userbin="">'.isset($esmdetails)? $esmdetails:''.'</EsmDetails>';    
                    $xmlstring  .=   '<authorpdflocation userbin="">'.$pdffile.'</authorpdflocation>';    
                    $xmlstring  .=   '<pitstopstopfile userbin=""></pitstopstopfile>';    
                    $xmlstring  .=   '<refpdffile userbin=""></refpdffile>';    
                    $xmlstring  .=   '<textfile userbin=""></textfile>';    
                    $xmlstring  .=   '<proofpdffile userbin=""></proofpdffile>';    
                    $xmlstring  .=   '<highresimagefolder userbin=""></highresimagefolder>';    
                    $xmlstring  .=   '<lowresimagefolder userbin="">'.$lowrespresentpath.'</lowresimagefolder>';    
                    $xmlstring  .=   '<stripinsfolder userbin=""></stripinsfolder>';    
                    $xmlstring  .=   '<epsilonpdffile userbin=""></epsilonpdffile>';    
					
                }else{
                    
                    $xmlstring  .=   '<xmlfile userbin="">'.$xmlfile.'</xmlfile>';    
                    $xmlstring  .=   '<pdffile userbin=""></pdffile>';    
                    $xmlstring  .=   '<deltapdffile userbin="">'.$deltapdffile.'</deltapdffile>';    
                    //$xmlstring.=   '<EsmDetails userbin="">'.isset($esmdetails)? $esmdetails:''.'</EsmDetails>';    
                    $xmlstring  .=   '<authorpdflocation userbin="">'.$authorpdflocation.'</authorpdflocation>';    
                    $xmlstring  .=   '<pitstopstopfile userbin=""></pitstopstopfile>';    
                    $xmlstring  .=   '<refpdffile userbin=""></refpdffile>';    
                    $xmlstring  .=   '<textfile userbin=""></textfile>';    
                    $xmlstring  .=   '<proofpdffile userbin=""></proofpdffile>';    
                    $xmlstring  .=   '<highresimagefolder userbin=""></highresimagefolder>';    
                    $xmlstring  .=   '<lowresimagefolder userbin="">'.$lowrespresentpath.'</lowresimagefolder>';    
                    $xmlstring  .=   '<stripinsfolder userbin=""></stripinsfolder>';    
                    $xmlstring  .=   '<epsilonpdffile userbin=""></epsilonpdffile>';    
					
                }
                
                $xmlstring  .=   '</component>';
            }
            
            $xmlstring  .=  '';
            
        }
        //exit;
        $componentInfo  =   $xmlstring;
        
        return $xmlstring;
        
    }
    
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        //$rules['jobstageid']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required|numeric';
        $rules['remarks']           =       'required';
        $rules['startprocess']           =       'required';
        $rules['custom_calback']           =       'required';
        $rules['controller']           =       'required';
        $rules['status']            =       'required|numeric';
        
        return $rules;
        
    }
     
    public function eproofS650StoreResponse($inputarr , &$returns ){
        
        $response['status']         =       1;
        $response['msg']            =       'Success';
        $response['errMsg']         =       'Signal received successfully...';   
        $response['param']          =       array( 'Am in testing mode' );
        
    }
    
    public function doEproofVendorFileCreation( $jobId ,  $roundId , $metadataID = null ){
        
        try{   
            
            $response           =   $this->notfoundResponse;
            $usrC_obj           =   new usersController();
            
            $bookdata           =   jobModel::getjobInfodetails( $jobId );
            $cmn_obj            =   new CommonMethodsController();
            
            $tapsdata           =   [];
            $bookid             =   ( count( $bookdata ) >= 1 ? $bookdata->BOOK_ID : '' );
            
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
            if( count( $getlocationftp ) >= 1 && count( $bookdata ) >= 1 ){
                
                $currentuser_id     =   $bookdata->PM;
                $user_arr           =   $usrC_obj->getUserInfoByUserId( $currentuser_id ); 
                $additional_email   =   $bookdata->ADDITIONAL_EPROOF_RECIPIENT;   
                $eproof_email       =   $bookdata->EPROOF_RECIPIENT;   
                $additional_email   .=  ','.$eproof_email;
                
                $email_collect      =   explode( ',' , $additional_email );
                $new_arr            =   array_map( 'trim' , $email_collect );
                $additional_email   =   ( implode( ', ', $new_arr ) );

                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
                $hostpath           =   $getlocationftp->FTP_PATH;
                
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                
                // Do the FTP connection
                $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     =>   $hostserver , 
                                                    'username' =>   $hostusername ,
                                                    'password' =>   $hostpassword ,
                                                    'port'     => '21' ,
                                                    'timeout'  => '30' ,
                                            ]); 
                
                $stage_name         =   \Config::get('constants.ROUND_NAME.'.$roundId);
                $tmestampnow        =   Carbon::now();
                    
                    $xmlstring      =   "<eProofResponse timestamp='$tmestampnow'>
                                            <BookID>$bookid</BookID> 
                                            <ChapterID>Chapters</ChapterID> 
                                            <VendorDetails>
                                                <Name>SPi_Global</Name> 
                                                <ProjectManagerName>$user_arr->FIRST_NAME $user_arr->LAST_NAME</ProjectManagerName>
                                                <Phone>$user_arr->PERSONAL_PHONE</Phone>
                                                <Fax>$user_arr->FAX</Fax> 
                                                <Email>$user_arr->EMAIL</Email> 
                                            <AdditionalEmail>$additional_email</AdditionalEmail> 
                                            </VendorDetails>
                                        </eProofResponse>";
                
                    $filename 	=	'VendorDetails.xml';
                    $xmlstring      =           $cmn_obj->formatXmlString( $xmlstring );
       
                    //echo '<pre>';
                    //echo htmlspecialchars( $xmlstring );
                    //exit;
                    
                    $bookidreplace          =   array(
                                                    '{BID}'     =>  $bookid ,
                                                    '{RNAME}'   =>  $stage_name ,
                                                    '{RID}'   =>  $stage_name ,
                                                );
                    
                    $vendorxmlpath          =   Config::get( 'constants.PACKAGE_PATH.S650.EPROOFPACKAGE.BOOK.VENDORXML');
                    
                    $vendorxmlpath          =   $cmn_obj->arr_key_value_replace( $bookidreplace , $vendorxmlpath , true );
                    $vendorfolarr           =   explode( '/' , $vendorxmlpath );
                    unset( $vendorfolarr[count($vendorfolarr)-1] );
                    $vendorfolderpath   =       implode( '/' , $vendorfolarr );
                    
                    if( empty( $bookdata->ADDITIONAL_EPROOF_RECIPIENT ) ){
                        
                        $tokenkey           =   $cmn_obj->generateRandomString( 16 , 'api_eproof_packaging' , 'TOKEN_KEY'  );                         
                        $insertdata['TOKEN_KEY']    =      $tokenkey;
                        
                        //insert eproof package error data
                        $insertdata['JOB_ID']       =       $jobId;
                        $insertdata['METADATA_ID']  =       $metadataID;
                        $insertdata['ROUND']        =       $roundId;
                        $insertdata['created_at']   =       Carbon::now();
                        $insertdata['START_TIME']   =       Carbon::now();
                        $insertdata['STATUS']       =       "3";
                        $insertdata['PACKAGE_ID']   =       'Failure Package '.$bookid.'_'.$stage_name.'_'.$tokenkey.'_'.date('Y_m_d_h_i_s').'.zip';
                        $insertdata['REMARKS']      =       "ReadMetaChk : E-Proof recipient email is not found";
						
                        //check exist data
                        $wheredata  =   [   
                                            'ROUND'  =>  $roundId,  
                                            'JOB_ID'=>$jobId
                                        ];
                        
                        $checkExist     =   apiEproofPackagingModel::where( $wheredata )->orderBy('ID','desc')->first();
                        
                        if( empty( $checkExist ) ){
                            
                            apiEproofPackagingModel::insert( $insertdata );
                            
                        }else{
                            
                            $checkExist->STATUS     =   "3";
                            $checkExist->updated_at =   Carbon::now();
                            $checkExist->REMARKS    =   "ReadMetaChk :E-Proof recipient email is not found";
                            $checkExist->save();
                            
                        }
                        
                        $response['errMsg']     =   'E-Proof recipient email is not found';
                        return $response;
                        
                    }
                    
                    $successfileresponse    =   false;
                    
                    if( $ftpObj->exists( $vendorfolderpath.'/'.$filename ) ){
                        $ftpObj->delete( $vendorfolderpath.'/'.$filename );
                    }
                    
                    if( !$ftpObj->exists( $vendorfolderpath.'/'.$filename ) ){
                        $successfileresponse    =	$ftpObj->put( $vendorfolderpath.'/'.$filename , $xmlstring );
                    }else{
                        $response       =   $this->successResponse;
                    }
                    
                    if( $successfileresponse ==     true ){
                        
                        //$response   =   $this->successResponse;
                        //$this->deactivateExistingEntry( $metadataID , $roundId );
                        //return $response;

                    }else{
                        return $response;
                    }
                    
                    $response       =   $this->successResponse;
                    return $response;
                    
            }
            
            return $response;
            
        } catch( \Exception $e ){           
          
            $response['errMsg']     =   $e->getMessage();
            return false;
            
        } 
        
    }
    
}