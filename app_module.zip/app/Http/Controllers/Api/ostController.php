<?php

namespace App\Http\Controllers\Api;
use App\Jobs\ostEmailAlert;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\ServiceManager as ServiceModel;
use App\Models\chapterClientNameModel;
use App\Models\Ost as Ost;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use File;
use Validator;
use Carbon\Carbon;
use DB;

class ostController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    protected $initreqt;
    
    public function __construct(){
        $this->initreqt     =   1;
    }
    public function clientChapterName($clientname,$bookId,$metaid,$chapterdata,$chapterType,$checkactiveornot){
        $url        =   "";
        $osturl     =   ($checkactiveornot !=   null?$checkactiveornot->SERVICE_URL.$checkactiveornot->SERVICE_PARAMS:Config::get('constants.OST_URL'));
        if(!empty($metaid)){
            if($chapterType     ==  1 || $chapterType     ==  3){
                $bookname   =   $bookId.$clientname;
                $url        =   $osturl.$bookname;
            }else{
                $chapterstr =   explode('_',$chapterdata[0]->CHAPTER_NO);
                $url        =   $osturl.$bookId.'_'.$chapterstr[1].$clientname;
            }
        }else{
            $bookname   =   $bookId.$clientname;
            $url        =   $osturl.$bookname;
        }
        return $url;
    }
    public function ostTrackingStatus($jobId = null,$roundId = null,$process_type= 'RECEIPT',$metaid = null) {
        try {
            $checkactiveornot   =   ServiceModel\ServiceManagerEnumModel::Active()->where('CODE',Config::get('constants.SERVICE_ENUM.OST'))->first();
            $result['status']   =   0;
            $result['errMsg']   =   "Failure";
            $result['msg']      =   "Failure";
            $clientcode     =   "";
            $chapterType    =   "";
            $chapterdata    =   [];
            if(!empty($metaid)){
                $chapterdata    =   taskLevelMetadataModel::searchchapterDetails($jobId,$metaid);
                $chapterType    =   (count($chapterdata)>=1?$chapterdata[0]->FM_ARTICLE_BM:'');
                switch($chapterType){
                    case 1:
                        $clientcode     =   Config::get('constants.CLIENT_CHAPTER_NAME.FM');
                    break;
                    case 2:
                        $clientcode     =   Config::get('constants.CLIENT_CHAPTER_NAME.CHAPTER');
                    break;
                    case 3:
                        $clientcode     =   Config::get('constants.CLIENT_CHAPTER_NAME.BM');
                    break;
                    case 4:
                        $clientcode     =   Config::get('constants.CLIENT_CHAPTER_NAME.PART');
                    break;
                }
            }else{
                $clientcode             =   Config::get('constants.CLIENT_CHAPTER_NAME.BOOK');
            }
            
            $getclientname  =   chapterClientNameModel::where('COMPONENT_CODE',$clientcode)->Ostactive()->first();
            $selectField    =   "job.JOB_ID,job.BOOK_ID,job.JOB_TITLE,concat(u.FIRST_NAME,' ',u.LAST_NAME) AS PM_NAME,concat(u1.FIRST_NAME,' ',u1.LAST_NAME) AS AM_NAME,u.USER_ID as USER_ID,u.EMAIL AS PM_EMAIL,u1.EMAIL AS AM_EMAIL,u.EMPLOYEE_ID as PM_EMPLOYEE_ID,u1.EMPLOYEE_ID as AM_EMPLOYEE_ID";
            $bookdetails   =   jobModel::getjobInfoaandUserdetails($jobId,$selectField);
            
            if($getclientname   ==  null || $bookdetails == null){
                $result['errMsg']   =   "Client name configuration not found";
                return $result;
            }
            
            $url        =   $this->clientChapterName($getclientname->NAME,$bookdetails->BOOK_ID,$metaid,$chapterdata,$chapterType,$checkactiveornot);
            
            if(count($bookdetails)>=1 && $bookdetails->PM_EMAIL == null && $url !=    null){
                $result['errMsg']   =   "PM Email is not found";
                $result['msg']      =   "Failure";
                return $result;
            }
            
            $cmn_obj            =   new  CommonMethodsController();
            $returns_response   =   $cmn_obj->getcUrlExecution(  $url,1 );
            if(count($returns_response)>=1 && isset($returns_response['http_code']) && $returns_response['http_code'] == 200 && isset($returns_response['2']) && isset($returns_response['2']->FIELD2)){
                $wherefid   =   ['OST_STAGE_ID'=>$roundId,'NAME'=>$returns_response['2']->FIELD2];
                $findexist  =   Ost\ostConfigStatusModel::Active()->where($wherefid)->first();
                if($findexist == null){
                    $this->sendEmail($bookdetails,$roundId,$process_type,$metaid,$returns_response,$type = "invalidResponse");
                    $result['errMsg']   =   "OST Tracking Invalid Response data";
                    $result['msg']      =   "Success";
                    $result['status']   =   "0";
                    return $result;
                }else{
                    $insertdata     =   [];
                    $insertdata['JOB_ID']       =   $jobId;
                    $insertdata['ROUND_ID']     =   $roundId;
                    $insertdata['METADATA_ID']  =   $metaid;
                    $insertdata['PROCESS_TYPE'] =   $process_type;
                    $insertdata['OST_CONFIG_ID']=   $findexist->ID;
                    $insertdata['CREATED_BY']   =   isset(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID');
                    //check exist
                    $whereost   =   ['JOB_ID'=>$jobId,'ROUND_ID'=>$roundId,'PROCESS_TYPE'=>$process_type];
                    $existoststauts     =   Ost\ostTrackingSystemModel::where($whereost)
                                            ->where(function ($query) use ($metaid) {
                                                                    if (trim($metaid) != '') {
                                                                        return $query->Where('METADATA_ID', $metaid);
                                                                    }
                                                                })->first();
                    if($existoststauts  ==  null){
                        Ost\ostTrackingSystemModel::insertGetId($insertdata);
                    }else{
                        $existoststauts->UPDATED_BY     =   isset(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID');
                        $existoststauts->OST_CONFIG_ID  =   $findexist->ID;
                        $existoststauts->save();
                    }
                    $result['errMsg']   =   "Got data successfully";
                    $result['msg']      =   "Success";
                    $result['status']   =   "1";
                    return $result;
                }
            }
            
            if(count($returns_response)>=1 && isset($returns_response['http_code']) && $returns_response['http_code'] == 200 && !isset($returns_response['2']) && !isset($returns_response['2']->FIELD2)){
                $this->sendEmail($bookdetails,$roundId,$process_type,$metaid,$returns_response,$type = "invalidResponse");
                $result['errMsg']   =   "OST Tracking Invalid Response data";
                $result['msg']      =   "Failure";
                $result['status']   =   "0";
                return $result;
            }
            //page exit after retry
            if($this->initreqt == 3){
                $this->sendEmail($bookdetails,$roundId,$process_type,$metaid,$returns_response,$type = "notreached");
                $result['errMsg']   =   "OST Tracking Web Service is not reached";
                $result['msg']      =   "Failure";
                return $result;
            }
            //page not access retry
            if(count($returns_response)>=1 && isset($returns_response['http_code']) && $returns_response['http_code'] != 404 && $returns_response['http_code'] != 200 && $this->initreqt <=  2){
                $this->initreqt++;
                $this->ostTrackingStatus($jobId,$roundId,$process_type,$metaid);
            }
            //page not found return
            if(count($returns_response)>=1 && isset($returns_response['http_code']) && $returns_response['http_code'] == 404){
                $this->sendEmail($bookdetails,$roundId,$process_type,$metaid,$returns_response,$type = "notreached");
                $result['errMsg']   =   "Url Not found";
                $result['msg']      =   "Failure";
                return $result;
            }
            
            } catch (\Exception $e) {
            $result = array('status' => 0, 'errMsg' => $e->getMessage(),'msg'=>"Failure");
            return $result;
        }
    }
    
    public function insertEmailLog($job_info,$roundId,$process_type,$metaid,$typeofalert){
        $insertdata     =   [];
        $insertdata['JOB_ID']       =   $job_info->JOB_ID;
        $insertdata['ROUND_ID']     =   $roundId;
        $insertdata['METADATA_ID']  =   $metaid;
        $insertdata['PROCESS_TYPE'] =   $process_type;
        $insertdata['EMAIL_TYPE']   =   ($typeofalert == "notreached"?2:($typeofalert ==   "invalidResponse"?3:1));
        $insertdata['CREATED_BY']   =   isset(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID');
        return Ost\ostTrackingEmailLogModel::insertGetId($insertdata);
    }
    
    public function sendEmail($job_info,$roundId,$process_type,$metaid,$returns_response,$type) 
    {   
        $lastInsertedId     =   $this->insertEmailLog($job_info,$roundId,$process_type,$metaid,$type);
        if($lastInsertedId ==   null){
            $result['errMsg']   =   "Inserted failed try again";
            $result['msg']      =   "Failure";
            $result['status']   =   "0";
            return $result;
        }
        
        $mailArray          =   $mailData   =   [];
        $book_id            =   $job_info->BOOK_ID;
        $jobId              =   $job_info->JOB_ID;
        if( !empty( $job_info->PM_EMAIL ) ){
           $mailData['ToName']      =   $job_info->PM_NAME;
           $mailArray['ToMail']     =   $job_info->PM_EMAIL;
        }else{
            $mailData['ToName']     =   $job_info->AM_NAME;
            $mailArray['ToMail']    =   $job_info->AM_EMAIL;
        }
        
        $contentdata    =   "";
        if($type    ==  "notreached"){
            $contentdata    =   'Unable to access the OST site '.Config::get('constants.OST_SITE');
            $mailData['data']       =   $contentdata;
        }else{
            $whereost   =   ['ost_config_status.IS_ACTIVE'=>1,'ost_config_status.OST_STAGE_ID'=>$roundId,'process_enum.IS_ACTIVE'=>1,'process_enum.NAME'=>$process_type];
            $existoststauts         =   Ost\ostConfigStatusModel::select(DB::raw('ost_config_status.NAME'))->join('process_enum','process_enum.ID','=','ost_config_status.PROCESS_ENUM_ID')
                                            ->where($whereost)->first();
            $mailData['oststatus']  =   ($existoststauts != null?$existoststauts->NAME:'');
            $mailData['currentstatus']  =   (isset($returns_response['2']->FIELD2)?$returns_response['2']->FIELD2:'');   
            $contentdata            =   "<p></p><p>OST status is not matching with the current upload</p><p><b>OST Status: </b> ".$mailData['oststatus']." </p><p><b>Current Status: </b>" .$mailData['currentstatus']. "</p>";
        }
        
        $mailData['BookId']         =   $job_info->BOOK_ID;
        $mailData['BookTitle']      =   $job_info->JOB_TITLE;
        $mailArray['Data']          =   $mailData;
        $mailArray['EMAIL_LOG_ID']  =   $lastInsertedId;
        $mailArray['TemplateName']  =   ($type == "notreached"?'emailtemplate.Ost.ostnotreachmail':'emailtemplate.Ost.ostinvalidresponsemail');
        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']        =   "vinoth.t@spi-global.com";
        $mailArray['Subject']       =   "OST is not accessible";
//        $mailArray['CcMail']        =   array('shamu.shihabudeen@spi-global.com','mohan.m@spi-global.com','ananth.b@spi-global.com'); 
        $wheredatamail              =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
        $updatedata['TO_EMAIL']     =   $mailArray['ToMail'];
//        $updatedata['CC_EMAIL']     =   implode(',',$mailArray['CcMail']);
        $updatedata['BODY_CONTENT'] =   $contentdata;
        Ost\ostTrackingEmailLogModel::where($wheredatamail)->update($updatedata);
//        $Response                   =   $this->sendMailBladeTemplate($mailArray);    
        $emailJob = (new ostEmailAlert($mailArray))->onQueue('high');
                dispatch($emailJob);
        $result                     =   array('result'=>200,'status'=>1,'errMsg'=>"Mail sent successfully");   
        return $result;
    }
        
    public function sendMailBladeTemplate($mailArray) {
        try {
            if (is_array($mailArray)) {
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '3';
                        Ost\ostTrackingEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                        Ost\ostTrackingEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/ostmail.log');
            Log::info( json_encode( $exception->getMessage() ) );
        }        
    }
}
