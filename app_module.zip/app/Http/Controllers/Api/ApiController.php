<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\apiActivemqModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiMetaExtractor;
use App\Models\apsRemainderEmailonoffModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\workflowServerMapPathModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Http\Controllers\taskLevelMetadataController;
use App\Http\Controllers\customization\customizationController;
use App\Models\stageManager;
use App\Models\customizationModel;
use App\Http\Controllers\users\usersController;
use App\Mail\Jobdownloadfailed;
use App\Models\apiProductionFileTransfer;
use App\Http\Controllers\workflow\serverMapPathController;
use App\Http\Controllers\Api\revisedJobController;
use App\Http\Controllers\bookinfo\bookinfoController;
use App\Http\Controllers\Api\productionFileTransferController;
use App\Http\Controllers\Api\JsCompareController;

#use Ixudra\Curl\Facades\Curl;
#use Ixudra\Curl\CurlService;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Carbon\Carbon;

class ApiController extends Controller
{
    
    public function download(Request $request) {
        
       try{
        set_time_limit(0); 
        ini_set('max_execution_time',0); 
        $requestData        =       $request->getContent();
	
        $jobSheetResponse   =       array();
        Log::useDailyFiles( storage_path().'/Api/download.log' );
        Log::info($requestData);
        
        $apiData            =       json_decode($requestData);
		
        $data               =       $apiData->Download;
       
        $revised_response   =       array();
        $time               =       date('Y-m-d H:i:s');
        $logdata            =       array();
        $assignProcess      =       0;
        $roundid                      =       '';
        $roundname                    =       '';
            
        $js_cpy_const       =       Config::get('serverconstants.DEFAULT_JOBSHEET_COPY_PATH');
        $cmn_obj            =       new CommonMethodsController();
        $defaultCopyPath    =       $cmn_obj->backslashPathPrepare( $js_cpy_const , true );
        $revisedJs          =       false;
        
        $default_jobsheet_path	=	'';
        $stageNumeric           =       '';
        $fullJobSheetJsonData   =       '';
        $jobsheetDetails        =       array();
        $book_id                =       '';
        
        $roundname_arr          =       \Config::get('constants.ROUND_ID');
        
        if( !empty( $apiData  ) ){
            $stageNumeric           =       $apiData->Download->Stage;
            $downloadroundname      =       'S'.$stageNumeric;
            $roundFrm               =       'S'.$stageNumeric; 
            $roundid                =       $roundname_arr[$roundFrm];
            $roundname              =       $roundname_arr[$roundid];
            $book_id                =       $apiData->Download->BookID;
        }else{
            throw new \Exception( 'Invalid download json received.' );
        }
        
        if( $downloadroundname !== 'S600' ){
         
            $reviController     =       new revisedJobController();
            $revisedJs          =       $reviController->revisingJobsheetAtDownload( $apiData , $revised_response );
			
		
		
            if( $revisedJs  ){ 
                extract( $revised_response );
				
				
                $this->updateJobInfoTable( $apiData , $jobId , $round , $metaid );
                $jobSheetResponse['jobsheet_location']      =       $default_jobsheet_path;
                $jobSheetResponse['apiStatus']              =       'success';
                //request for jobsheet download start
                $sendrequestjobsheetdownloaddata['ROUND_ID']    =   $round;
                $sendrequestjobsheetdownloaddata['JOB_ID']      =   $jobId;
                $sendrequestjobsheetdownloaddata['JOBSHEET_LOCATION']   =   $default_jobsheet_path;
                $sendrequestjobsheetdownloaddata['BOOK_ID']     =   $book_id;
                $sendrequestjobsheetdownloaddata['METADATA_ID'] =   (!empty($metaid)?$metaid:"");
                $sendrequestjobsheetdownloaddata['PROCESS_TYPE']=   Config::get('constants.REVISED_PROCESS_TYPE.REVISED_RECEIPT');
				
					/** S600 jobsheet order update **/
			if(isset($apiData->MetadataExtraction->JobSheet->ChapterSequenceNumber)){
							$this->chapterSequenceOrderupdate($apiData->MetadataExtraction->JobSheet->ChapterSequenceNumber,$jobId);
			}
				
				
                $sendrequestjobsheetdownload    =   $this->jobsheetdownloadRequest('',$sendrequestjobsheetdownloaddata);
                //request for jobsheet download end
                return response()->json( $jobSheetResponse );
            }
            
        }
        
        if( !empty( $apiData ) ) {
          
            $assignProcess        =       $this->getDownloadedJobsheetInformation( $apiData , $fullJobSheetJsonData , $jobsheetDetails , $logdata );
            
            /** Chapter level Download **/
            if ( empty( $roundid ) || $logdata['META_EXTRACTION_STATUS'] == 0 ) {
                
                $jobSheetResponse['apiStatus']              =   'success';
                $jobSheetResponse['status']                 =   '1';
                $jobSheetResponse['jobsheet_location']      =   '';    
                return response()->json( $jobSheetResponse );
                
            }
                  if($roundname == 'S200' || $roundname == 'S300'){
                    
                    $obj_pfl        = new productionFileTransferController();
                    $round_arr      = \Config::get('constants.ROUND_ID');
                    
                    $round_         = $round_arr[$roundname];
                    $others         = array();
                   
                    $chapDetails    =    $this->chapterDownload($logdata, $jobsheetDetails, $others);
               
                    if(empty($chapDetails) && !empty($jobsheetDetails->SeriesID)) {
                       
                        $jobsheetDetails    =   $this->mapSeriesTitleToRegular($apiData);
                       
                        $chapDetails        =    $this->chapterDownload($logdata, $jobsheetDetails, $others);
                      
                        $this->createJobRelatedInstance($apiData,$chapDetails);
                        $chapDetails        =    $this->chapterDownload($logdata, $jobsheetDetails, $others);
                    }
                    
                    $jobId          =    $chapDetails['jobId']->JOB_ID;
                    $chapterId      =    $chapDetails['chapterNo'];
                    $round_arr      =    \Config::get('constants.ROUND_ID');

                    $logdata['ROUND']           = $round_arr[$roundname];
                    $logdata['METADATA_ID']     = $chapDetails['metaId'];
                    $logdata['IS_COMPLETED']    = 1;
                    $logdata['REQUEST_LOG']     = $requestData;
                    $logdata['CREATED_DATE']    = $time;
                   
                    DB::table('api_download')->insert( $logdata );
                    // check workflow is exist or not for current round and book
                    $getdefaultworkflowid       =   [];
                    if($roundname == 'S300'){
                        $getdefaultworkflowid     =   \Config::get('constants.S300_DEFAULT_WORKFLOW_LIST');
                        $this->assignDefaultWorkFlowCommon($jobId,$round_arr[$roundname],$getdefaultworkflowid); 
                    }

                    
                    //s300 add data to remainder on off data show s300 download items
                    $jobinfoData    =   jobModel::getJobdetailsRawQuery( $jobId,'job_info.EPROOFING_SYSTEM' );
                    $remaindertype  =   (!empty($jobinfoData)?$jobinfoData->EPROOFING_SYSTEM:'');
                    if(!empty($remaindertype))
                    {
                        $whereonoff     =   ['ROUND_ID'=>$round_arr[$roundname],'METADATA_ID'=>$chapDetails['metaId'],'JOB_ID'=>$jobId,'REMAINDER_TYPE'=>$remaindertype];
                        $checkexist     =   apsRemainderEmailonoffModel::active()->where($whereonoff)->get();
                        //in active old data
                        if(count($checkexist)>=1)
                        {
                            apsRemainderEmailonoffModel::where($whereonoff)->update(['IS_ACTIVE'=>'0']);
                        }
                        //insert new data
                        $insertrem['ROUND_ID']          =   $round_arr[$roundname];
                        $insertrem['METADATA_ID']       =   $chapDetails['metaId'];
                        $insertrem['JOB_ID']            =   $jobId;
                        $insertrem['REMAINDER_TYPE']    =   $remaindertype;
                        $insertrem['CREATED_BY']        =   Config::get('constants.ADMIN_USER_ID');
                        $insertrem['CREATED_DATE']      =   Carbon::now();
                        apsRemainderEmailonoffModel::insertGetId($insertrem);
                    }
                    
                    /**Assign Workflow **/ 
                    if(!empty($jobId) && $roundname == 'S200'){
                        $this->assignDefaultWorkFlows($jobId, $round_arr[$roundname]);
                        $js_cpy_const = Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
                    }else if( !empty($jobId) && $roundname == 'S300' ){
                        $js_cpy_const = Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
                    }
                    
                    $cmn_obj = new CommonMethodsController();
                    $defaultCopyPath = $cmn_obj->backslashPathPrepare($js_cpy_const, true);
                    
                    //request for jobsheet download start
                    $sendrequestjobsheetdownloaddata['ROUND_ID']    =   $round_arr[$roundname];
                    $sendrequestjobsheetdownloaddata['JOB_ID']      =   $jobId;
                    $sendrequestjobsheetdownloaddata['JOBSHEET_LOCATION']   =   $default_jobsheet_path;
                    $sendrequestjobsheetdownloaddata['METADATA_ID'] =   $chapDetails['metaId'];
                    $sendrequestjobsheetdownloaddata['BOOK_ID']     =   $book_id;
                    $sendrequestjobsheetdownloaddata['PROCESS_TYPE']=   Config::get('constants.REVISED_PROCESS_TYPE.RECEIPT');
                    $sendrequestjobsheetdownload    =   $this->jobsheetdownloadRequest('',$sendrequestjobsheetdownloaddata);
                    //request for jobsheet download end
                    
                    $inp_rep_arr = array( 
                        '{BID}' => $jobsheetDetails->BookID, 
                        '{RID}' => $roundname, 
                        '{CID}' => $chapDetails['chapterNo'] ,
                        'BOOK_ID' => $book_id,
                        'ROUND_NAME' => $roundname,
                        'STAGE_NAME' => $roundname
                    );
                    
                    $default_jobsheet_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
                     
                    /**  S200 jobsheet download **/
                    $jobSheetResponse['apiStatus'] = 'success';
                    $transApi      = $obj_pfl->chapterFileDownload( $jobId , $round_ , $chapterId , $chapDetails['metaId'] );
                    
                    $jobDetails = jobModel::select(DB::raw('JOB_ID'))->where('BOOK_ID',$data->BookID )->first();
                    $job_id = $jobDetails->JOB_ID;
                    $amData =   jobModel::getJobdetailsRawQuery( $job_id,'job.PM,job_info.AM,job_info.AM_NAME,job_info.AM_MAIL' );
                    
                        if (!empty($amData)) {
                            $amDetails['PM'] = $amData->PM;
                            $amDetails['AM'] = $amData->AM;
                            $amDetails['AM_NAME'] = $amData->AM_NAME;
                            $amDetails['AM_MAIL'] = $amData->AM_MAIL;
                            $amDetails['AUTHOR_NAME'] = $apiData->MetadataExtraction->JobSheet->AuthorName;
                            $amDetails['ISSN_PRINT'] = $apiData->MetadataExtraction->JobSheet->BookPrintISBN;
                            $amDetails['ISSN_ONLINE'] = $apiData->MetadataExtraction->JobSheet->BookElectronicISBN;

                            $jobDet = $apiData->MetadataExtraction->JobSheet;
                            $metaid     =       $chapDetails['metaId'];
                            $this->promateJobNotificationMail( $amDetails, $jobDet, $time , $roundname , $chapDetails );
                            
                        }

                    
                } else {
                    
                    /** Book Level Download **/
                    $logdata['ROUND']           =   $roundid;
                    $logdata['REQUEST_LOG']     =   $requestData;
                    $logdata['CREATED_DATE']    =   $time; 

                    $inp_rep_arr = array(
                        'BOOK_ID'       =>  $book_id,
                        'ROUND_NAME'    =>  $roundname,
                        'STAGE_NAME'    =>  $roundname
                    );
                    
                    $default_jobsheet_path = $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
                    
                    if ($roundname_arr[$roundid] == $roundname && ( $roundname == 'S50' || $roundname == 'S600' || $roundname == 'S650' ) )  {

                        $assignProcess = 0;
                        $amDetails = array();
                        
                        $cnt_mail = ( $apiData->MetadataExtraction->JobSheet->ContactPersonContactEmail );
                        $jobDetails = jobModel::select(DB::raw('JOB_ID'))->where('BOOK_ID',$logdata['BOOK_ID'] )->first();
                        $jobId  =   $job_id = $jobDetails->JOB_ID;
                        $amData =   jobModel::getJobdetailsRawQuery( $job_id,'job.PM,job_info.AM,job_info.AM_NAME,job_info.AM_MAIL' );
                        $round_arr = \Config::get('constants.ROUND_ID');
                        $round_ = $round_arr[$roundname];
                        //request for jobsheet download start
                        $sendrequestjobsheetdownloaddata['ROUND_ID']    =   $roundid;
                        $sendrequestjobsheetdownloaddata['JOB_ID']      =   $job_id;
                        $sendrequestjobsheetdownloaddata['JOBSHEET_LOCATION']   =   $default_jobsheet_path;
                        $sendrequestjobsheetdownloaddata['METADATA_ID'] =   "";
                        $sendrequestjobsheetdownloaddata['BOOK_ID']     =   $book_id;
                        $sendrequestjobsheetdownloaddata['PROCESS_TYPE']=   Config::get('constants.REVISED_PROCESS_TYPE.RECEIPT');
                        $sendrequestjobsheetdownload    =   $this->jobsheetdownloadRequest('',$sendrequestjobsheetdownloaddata);
                        //request for jobsheet download end
						
								/** S600 jobsheet order update **/
						if(isset($apiData->MetadataExtraction->JobSheet->ChapterSequenceNumber)){
										$this->chapterSequenceOrderupdate($apiData->MetadataExtraction->JobSheet->ChapterSequenceNumber,$jobId);
						}
            
                        if (!empty($amData)) {

                            $amDetails['AM'] = $amData->AM;
							$amDetails['PM'] = $amData->PM;
                            $amDetails['AM_NAME'] = $amData->AM_NAME;
                            $amDetails['AM_MAIL'] = $amData->AM_MAIL;
                            $amDetails['AUTHOR_NAME'] = $apiData->MetadataExtraction->JobSheet->AuthorName;
                            $amDetails['ISSN_PRINT'] = $apiData->MetadataExtraction->JobSheet->BookPrintISBN;
                            $amDetails['ISSN_ONLINE'] = $apiData->MetadataExtraction->JobSheet->BookElectronicISBN;
                            
                            if($roundname == 'S600'){
                                $getdefaultworkflowid     =   \Config::get('constants.S600_DEFAULT_WORKFLOW_LIST');
                                $this->assignDefaultWorkFlowCommon( $jobId , $round_arr[$roundname] , $getdefaultworkflowid ); 
                                $logdata['JOB_ID']    =   $jobId;
                            }
                            
                            if($roundname == 'S650'){
                                $getdefaultworkflowid     =   \Config::get('constants.S650_DEFAULT_WORKFLOW_LIST');
                                $this->assignDefaultWorkFlowCommon( $jobId , $round_arr[$roundname] , $getdefaultworkflowid ); 
                                $logdata['JOB_ID']    =   $jobId;
                            }
							
                            
                            $jobDet = $apiData->MetadataExtraction->JobSheet;
                            $logdata['IS_COMPLETED'] = 1;
                            DB::table('api_download')->insert($logdata);
                    
                            $obj_pfl = new \App\Http\Controllers\Api\productionFileTransferController();
                            $round_arr = \Config::get('constants.ROUND_ID');
                            $round_ = $round_arr[$roundname];
                            $transApi = $obj_pfl->locationChangeRequest($job_id, $round_  );
							
			    $this->promateJobNotificationMail( $amDetails, $jobDet, $time , $roundname );
                            
                        }
                        
                    } else {
                        
                        DB::table('api_download')->insert($logdata);
                        
                    }

                    if ( $assignProcess == 1 ) {

                        $jobSheetResponse = $this->Jobinformation($jobsheetDetails);
                        $location = '';
                       
                        if (!empty($jobSheetResponse['fileMovementPath'])) {

                            $jobSheetResponse['fileMovementPath'] = Config::get('constants.' . $jobSheetResponse['fileMovementPath'] . '_PRODUCTION_SERVER');
                            $jobSheetResponse['fileMovementPath'] = $jobSheetResponse['fileMovementPath'] . $data->BookID;

                            if ($location != '') {
                                $jobSheetResponse['BookID'] = $data->BookID;
                            }
                            
                        }
                        
                    } else {
                        $jobSheetResponse['apiStatus'] = 'success';
                    }
                    
                    if($roundid == '104'){
                        $jobDetails     =   jobModel::select(DB::raw('JOB_ID'))->where('BOOK_ID',$book_id )->first();
                        if(!empty($jobDetails->JOB_ID)){
                            $this->assignPreProductionWorkflowToJob($jobDetails->JOB_ID,$roundid);
                            $cestimationID = 	\Config::get( 'constants.STAGE_COLLEECTION.CE_ESTIMATION' ).','.\Config::get( 'constants.STAGE_COLLEECTION.SPICAST' ).','.\Config::get( 'constants.STAGE_COLLEECTION.CUC' ).','.\Config::get( 'constants.STAGE_COLLEECTION.AUTO_REFERENCE_PDF' );
                            $enableStage    =   "UPDATE task_level_userdefined_workflow SET  IS_AUTO = 1 WHERE ROUND = '".$roundid."' AND JOB_ID = '".$jobDetails->JOB_ID."' AND STAGE IN($cestimationID)";
                            $updateStatus   =   DB::update($enableStage);
                        }
                    }
                } //s5 and s50 download
            } else {
                $jobSheetResponse['apiStatus'] = 'failed';
                //return json_encode($jobSheetResponse);
            }
            
            $metaId = '';
            if(isset($logdata['METADATA_ID']) && !empty($logdata['METADATA_ID']) ){
                $metaId  = $logdata['METADATA_ID'];
            }
            
            if( isset( $jobsheetDetails ) ){
                //milestone entry
                $this->handleJobRoundMileStone( $jobsheetDetails , $stageNumeric, $metaId, $fullJobSheetJsonData );
            }
            
           // $jscompareObj           =   new JsCompareController();
         //   $jsResponse             =   $jscompareObj->jobsheetCompare($default_jobsheet_path,$roundid);
            
			
            $jobSheetResponse['jobsheet_location']     =       $default_jobsheet_path;
        
        }catch(\Exception $e){
            
            $errMsg         =           $e->getTraceAsString();
            $jobSheetResponse['apiStatus']      =       'success';
            $jobSheetResponse['status']         =       '1';
            $jobSheetResponse['errMsg']         =       $errMsg;
            $jobSheetResponse['jobsheet_location']     =       $default_jobsheet_path;
            
            Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
            Log::info( json_encode( $jobSheetResponse) );
            Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
            
        }
        
        return response()->json($jobSheetResponse);
        
    }
    
    public function jobsheetdownloadRequest($retryID = null,$jobsheetDetails = null){
        
        $cmn_obj                 =       new CommonMethodsController();
        $jobSheetResponse['REMARKS']    =   'Failure';
        $jobSheetResponse['status']     =   '0';
        $jobSheetResponse['errMsg']     =   "Job Sheet file not found in download";   
        try{
        //insert to api table - 
            $user_id    =   Session::get('users')['user_id'];
            $cmn_obj    =   new CommonMethodsController();
            $token_key  =   $cmn_obj->generateRandomString( 16 , 'api_production_file_transfer'  );
            $josheetDownload    =   Config::get('constants.JOBSHEET_DOWNLOAD');
            $data       =   [];
            $data['ZIPFilePath']        =   "\\\\spiazuremagnusfs.file.core.windows.net\\spiazuremagnusfs\\CLIENTS\\SPRINGER\\BOOKS\\WATCHFOLDER\\DOWNLOAD\\WATCH_DOG\\OUT\\08\\10\\BookTitleID=439601_EditionNumber=1_Language=En_2019-04-16_12-18-11-.zip";
            $data['DestinationPath']    =   "\\\\spiazuremagnusfs.file.core.windows.net\\spiazuremagnusfs\\CLIENTS\\SPRINGER\\BOOKS\\WATCHFOLDER\\DOWNLOAD\\WATCH_DOG\\OUT\\08\\10\\test_jobsheet_download_from_vinoth.xml";
            
            $inp_arr    =   array( 
                                    'TOKEN_KEY' => $token_key , 
                                    'PROCESS_NAME' => $josheetDownload, 
                                    'JOB_ID'    =>  "" , 
                                    'ROUND'     =>  "" , 
                                    'USER_ID'   =>  $user_id , 
                                    'START_TIME' => date( 'Y-m-d H:m:i' ) , 
                                    'STATUS'	=> 1 , 
                                    'JOBSHEET_LOCATION'=>'',
                                    'REQUEST_LOG'   => json_encode( $data )
                                );
            
            $processtyperequest     =   "";
            $metaid     =   null;
            $wherejobsheet  =   [];
            if($retryID !=  null && $retryID !=  ""){
                
                $existdata  =   apiProductionFileTransfer::join('job','job.JOB_ID','=','api_production_file_transfer.JOB_ID')->findorfail($retryID);
                $inp_arr['JOB_ID']              =   $existdata->JOB_ID;
                $wherejobsheet['ROUND']     =   $inp_arr['ROUND']               =   $existdata->ROUND;
                $inp_arr['JOBSHEET_LOCATION']   =   $existdata->JOBSHEET_LOCATION;
                $wherejobsheet['BOOK_ID']   =   $existdata->BOOK_ID;
                if($existdata->METADATA_ID !=   ''){
                    $wherejobsheet['METADATA_ID']   =   $metaid     =   $inp_arr['METADATA_ID']   =   $existdata->METADATA_ID;
                }
                $processtyperequest     =   $inp_arr['PROCESS_TYPE']        =   $existdata->PROCESS_TYPE;
            }
            
            if(empty($retryID) && $jobsheetDetails !=  ""){
                $inp_arr['JOB_ID']              =   $jobsheetDetails['JOB_ID'];
                $wherejobsheet['ROUND']         =   $inp_arr['ROUND']               =   $jobsheetDetails['ROUND_ID'];
                $inp_arr['JOBSHEET_LOCATION']   =   $jobsheetDetails['JOBSHEET_LOCATION'];
                $wherejobsheet['BOOK_ID']       =   $jobsheetDetails['BOOK_ID'];
                $processtyperequest     =   $inp_arr['PROCESS_TYPE']        =   $jobsheetDetails['PROCESS_TYPE'];
                if(isset($jobsheetDetails['METADATA_ID']) && $jobsheetDetails['METADATA_ID'] !=   ''){
                    $wherejobsheet['METADATA_ID']   =   $metaid     =   $inp_arr['METADATA_ID']   =   $jobsheetDetails['METADATA_ID'];
                }
            }
            
            $jobsheetzippath    =   ApiDownloadModel::select(DB::Raw('DOWNLOAD_PATH'))->where($wherejobsheet)->orderBy('ID','desc')->first();
            if(!empty($jobsheetzippath)){
                $data['ZIPFilePath']=   $jobsheetzippath->DOWNLOAD_PATH;
                if(!empty($metaid)){
                    $metainformation    =   taskLevelMetadataModel::select(DB::Raw('task_level_metadata.CHAPTER_NO,metadata_info.METADATA_ID'))
                            ->join('metadata_info','metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')
                            ->where('metadata_info.METADATA_ID',$metaid)->first();
                    $getclientchpname   =   app('App\Http\Controllers\Api\autoPageController')->getPagingFileNameing($wherejobsheet['BOOK_ID'],$metainformation->CHAPTER_NO,$metainformation->METADATA_ID);
                }else{
                    $getclientchpname   =   app('App\Http\Controllers\Api\autoPageController')->getPagingFileNameing($wherejobsheet['BOOK_ID'],'','');
                }
                
                $sheetnaming            =   Config::get('constants.JOBSHEET_SUFFIX_CONVENTION')[$wherejobsheet['ROUND']];
                $data['DestinationPath']=   $inp_arr['JOBSHEET_LOCATION'].$getclientchpname['fmbmpartjobsheetname'].$sheetnaming;
            $returns_response           =   $cmn_obj->RestfulPostcUrlExecution( $data ,  Config::get('constants.PRODUCTION_TOOLS_SETUP.JOBSHEET_DOWNLOAD_SERVICE'),1,"text" );
                $sendinputjobmethod     =   false;
            if(!empty($retryID)){
                if($returns_response['http_code'] != 200){
                        $sendinputjobmethod             =   true;
                    $jobSheetResponse['REMARKS']    =   'Failure';
                    $jobSheetResponse['errMsg']     =   $returns_response['curl_err'];
                    $updatedata['STATUS']           =   3;
                    $updatedata['REMARKS']          =   $returns_response['curl_err'];
                    apiProductionFileTransfer::where('ID',$retryID)->update($updatedata);
                }
                
                if($returns_response['http_code'] == 200){
                    $updatedata['STATUS']           =   (isset($returns_response[0]) && $returns_response[0] == "Success"?2:3);
                        $updatedata['REMARKS']          =   (isset($returns_response[0]) && $returns_response[0] == "Success"?"Success":$returns_response[0]);
                    apiProductionFileTransfer::where('ID',$retryID)->update($updatedata);
                }
                
                if($updatedata['STATUS'] !=    3){
                        $jobSheetResponse['REMARKS']    =   'Success';
                        $jobSheetResponse['status']     =   '1';
                        $jobSheetResponse['errMsg']     =   "Successfully retriggered jobsheet download";
                    $meta_obj   =   new MetaExtractorController();
                    $inp_update     =   $meta_obj->sendInputForJobsheetUpdate( $existdata->JOB_ID , $existdata->ROUND , $processtyperequest ,$metaid );
                    if(is_object($inp_update)){
                        $readdata   =   $inp_update->getData();
                        if($readdata->status    ==  0){
                            $jobSheetResponse['REMARKS']    =   'Failure';
                            $jobSheetResponse['errMsg']     =   $readdata->errMsg;
                    }
                }else{
                            $sendinputjobmethod     =   $inp_update;
                        }
                    }else{
                        $sendinputjobmethod             =   true;
                    $jobSheetResponse['errMsg']     =   "Retriggered jobsheet download failed";
                    return response()->json($jobSheetResponse);
                }
            }
            
            $getlastinsertedid  =   apiProductionFileTransfer::insertGetId($inp_arr);
            
                if(!empty($getlastinsertedid) && empty($retryID)){
                $existdata  =   apiProductionFileTransfer::findorfail($getlastinsertedid);
                if($returns_response['http_code'] != 200){
                        $sendinputjobmethod             =   true;
                    $jobSheetResponse['REMARKS']    =   'Failure';
                    $jobSheetResponse['errMsg']     =   $returns_response['curl_err'];
                    $updatedata['STATUS']           =   3;
                    $updatedata['REMARKS']          =   $returns_response['curl_err'];
                    apiProductionFileTransfer::where('ID',$getlastinsertedid)->update($updatedata);
                    return $jobSheetResponse;
                }
                if($returns_response['http_code'] == 200){
                    $updatedata['STATUS']           =   (isset($returns_response[0]) && $returns_response[0] == "Success"?2:3);
                        $updatedata['REMARKS']          =   (isset($returns_response[0]) && $returns_response[0] == "Success"?"Success":$returns_response[0]);
                    apiProductionFileTransfer::where('ID',$getlastinsertedid)->update($updatedata);
                }
                
                if($updatedata['STATUS'] !=    3){
                        $jobSheetResponse['REMARKS']    =   'Success';
                        $jobSheetResponse['status']     =   '1';
                        $jobSheetResponse['errMsg']     =   "Successfully retriggered jobsheet download";
                    $meta_obj   =   new MetaExtractorController();
                    $inp_update     =   $meta_obj->sendInputForJobsheetUpdate( $existdata->JOB_ID , $existdata->ROUND , $processtyperequest ,$metaid );
                    if(is_object($inp_update)){
                        $readdata   =   $inp_update->getData();
                        if($readdata->status    ==  0){
                            $jobSheetResponse['REMARKS']    =   'Failure';
                            $jobSheetResponse['errMsg']     =   $readdata->errMsg;
                            return $jobSheetResponse;
                        }
                    }
                }else{
                            $sendinputjobmethod     =   $inp_update;
                        }
                    }else{
                        $sendinputjobmethod             =   true;
                    $jobSheetResponse['errMsg']     =   "Retriggered jobsheet download failed";
                    }
                }
            
                
        }catch(\Exception $e){
            $errMsg =   $e->getMessage();
            $jobSheetResponse['REMARKS']    =   'Failure';
            $jobSheetResponse['status']     =   '0';
            $jobSheetResponse['errMsg']     =   $errMsg;
        }
        if($retryID !=  null){
            if($sendinputjobmethod  ==  true){
            return response()->json($jobSheetResponse);
        }else{
                return $sendinputjobmethod;
            }
        }else{
            if($sendinputjobmethod  ==  true){
            return $jobSheetResponse;
            }else{
                return $sendinputjobmethod;
            }
        }
    }
    
    public function getDownloadedJobsheetInformation( $apiData , &$fullJobSheetJsonData , &$jobsheetDetails , &$logdata ){
        
        $assignProcess      =   0;
        
        foreach( $apiData as $key => $data ){

            if($key == 'Download') {                
              $book_id                      =       $logdata['BOOK_ID']           =       $data->BookID;
              $logdata['FILE_NAME']         =       $data->FileName;
              $stageNumeric                 =       $data->Stage;
              
               if(isset($data->FilePath)){
                $logdata['DOWNLOAD_PATH'] 	= 	$data->FilePath;
              }
              $logdata['DOWNLOAD_START']           =           $data->StartDate;
              $logdata['DOWNLOAD_END']             =           $data->EndDate;
              $logdata['DOWNLOAD_STATUS']          =           ($data->Status=='Success'?1:0);
              $logdata['REMARKS']                  =           $data->Remarks;
              
            }
            if($key == 'ZIPExtraction') {
                $logdata['ZIP_EXTRACTION_START']      =   $data->StartDate;
                $logdata['ZIP_EXTRACTION_END']        =   $data->EndDate;
                $logdata['ZIP_EXTRACTION_STATUS']     =   ($data->Status=='Success'?1:0);
                $logdata['REMARKS']                   =   $data->Remarks;
            }
            if($key == 'MetadataExtraction') {
                
                $logdata['META_EXTRACTION_START']    =           $data->StartDate;
                $logdata['META_EXTRACTION_END']      =           $data->EndDate;
                $logdata['META_EXTRACTION_STATUS']   =           ($data->Status=='Success'?1:0);
                $logdata['REMARKS']                  =           $data->Remarks;

                if($logdata['META_EXTRACTION_STATUS'] == 1){
                    $assignProcess = 1;
                    $jobsheetDetails                 =           $data->JobSheet;
                    if(isset($data->OriginalJobSheet->JobSheet)){
                       $fullJobSheetJsonData = $data->OriginalJobSheet->JobSheet;
                    }

                }
                
                
            }
            
        }

        if( isset( $logdata['META_EXTRACTION_STATUS'] ) ){
            
            if ( $logdata['META_EXTRACTION_STATUS'] == 0 ) {
                
                DB::table('api_download')->insert( $logdata );
                $this->jobdownloadfailedmailalert( $apiData );

            }
            
        }

        return $assignProcess;   
        
    }
    
    public function jobdownloadfailedmailalert($apiData){
        $mailcontent['Title']       =   'Download failed';
        $mailcontent['BookId']      =   $apiData->Download->BookID;
        $mailcontent['FileName']    =   $apiData->Download->FileName;
        $mailcontent['BookId']      =   $apiData->Download->BookID;
        $mailcontent['ToName']      =   'Vinoth';
        $mailcontent['mailcontent'] =   $apiData->Download->BookID.' Download failed';
        Mail::to('vinoth.t@spi-global.com')
//                    ->cc($moreUsers)
//                    ->bcc($evenMoreUsers)
            ->queue(new Jobdownloadfailed($mailcontent));
    }
    
    public function triggerProofPackaging( $chpter_info , $roundid ){
        
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        $metaid                 =       $chpter_info['metaId'];
       
        $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
        $job_id                 =       $tasklev_info[0]->JOB_ID;    
        $bookInfo               =       jobModel::getJobdetails( $job_id );
        $jobLevelProofing       =       $bookInfo->EPROOFING_SYSTEM;
        $haseProof              =       false;
        
        if( $tasklev_info->count() && $jobLevelProofing == 1)
            $haseProof               =       ( $tasklev_info[0]->EPROOFING_SYSTEM == 1 ) ? true : false;
        
        if( $haseProof ){
            //triggering the eproof package
            $jobid              =       $chpter_info['jobId'];
            $eprCntrl        = new \App\Http\Controllers\eproof\eproofController();
            $eprCntrl->doEproofVendorpackagecreate( $jobid , $metaid , $round );
        }
        
    }
    
    public function handleJobRoundMileStone( $jobdetails , $stage, $metaId, $fullJobSheetJsonData = "" ){
             
        $bookid                     =       $jobdetails->BookID;
        $round_arr                  =       \Config::get('constants.ROUND_NAME');              
        $roundid                    =       $round_arr['S'.$stage];
        
        $bookdetails                =       bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                                ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                                ->where('job.BOOK_ID', 'like' , '%'.$bookid.'%')
                                                ->get()->last();
        
        $jobId                      =       (count($bookdetails)>=1?$bookdetails['JOB_ID']:'');
        
        if( empty($jobId ) )
            return false;
        
        $jbObj                      =       new jobModel();
        
        //updating created date for updated 
        $jbObj->updateIfExist( array() , $jobId );
        
        $time       =       date( 'Y-m-d H:i:s' );
        
        //insert into jobround milestone entry
        if(!empty($metaId)){
            
            $milestone_inp      =   array(  
                                            'JOB_ID' => $jobId , 'ROUND_ID'     =>  $roundid    ,
                                            'METADATA_ID'       =>  $metaId,
                                            'RECEIVED_DATE'     =>  $time , 
                                            'CREATED_DATE'      =>  $time ,                                         
                                        );
            
        }else{
            $milestone_inp      =   array(  
                                            'JOB_ID' => $jobId , 'ROUND_ID'     =>  $roundid    , 
                                            'RECEIVED_DATE'     =>  $time , 
                                            'CREATED_DATE'      =>  $time ,                                         
                                        );
        }
        
        if(!empty($fullJobSheetJsonData)){
            $milestone_inp['FULL_JOBSHEET_JSON_DATA'] = json_encode($fullJobSheetJsonData);
        }
        return DB::table('job_round_milestone')->insert( $milestone_inp );
                      
    }
    
    public function createJobRelatedInstance($responseData,$chapDetails){
        $bookId                             = $responseData->MetadataExtraction->BookID;
        $jobSheetInfo                       =   $this->mapSeriesTitleToRegular($responseData);
        
        if(empty($chapDetails)){
            $jobResponse                        =   $this->Jobinformation($jobSheetInfo->JobSheet);
        }
        
        $bookdetaills                       =       jobModel::where('BOOK_ID',$bookId)->first();
        $jobId                              =       (count($bookdetaills)>=1?$bookdetaills->JOB_ID:'');
       
        if(empty($chapDetails['metaId'])) {
            $taskLevelMetaObj                   =    new taskLevelMetadataModel();
         
            $responseData                       =   $taskLevelMetaObj->insertChapterInfo($jobSheetInfo->JobSheet,$jobId);   
        }
        
        return true;
       
    }
    
    public function mapSeriesTitleToRegular($responseData){
      
        $jobSheetInfo                       = $responseData->MetadataExtraction;
        $bookId                             = $responseData->MetadataExtraction->BookID;
        $jobSheetInfo->JobSheet->BookID     = $responseData->MetadataExtraction->BookID;
        $jobSheetInfo->JobSheet->BookTitle  = (!empty($responseData->MetadataExtraction->JobSheet->SeriesTitle)?$responseData->MetadataExtraction->JobSheet->SeriesTitle:"Title jobSeriers");
        //$jobSheetInfo->JobSheet->BookType   = 'Seriers';
        $jobSheetInfo->JobSheet->BookTitleEditorName = $responseData->MetadataExtraction->JobSheet->EditorName;
        $jobSheetInfo->JobSheet->BookPrintISBN       = $responseData->MetadataExtraction->JobSheet->SeriesPrintISSN;
        $jobSheetInfo->JobSheet->BookElectronicISBN  = $responseData->MetadataExtraction->JobSheet->SeriesEISSN;
        $jobSheetInfo->JobSheet->ChapterTitle       = $responseData->MetadataExtraction->JobSheet->SeriesTitle;
        
        return $jobSheetInfo;
        
    }
    
    public function Jobinformation($data){
        try{
        $mailPmSend             = '';
        $jobId                  =   '';
        $jobInfoId              =   '';
        $jobData                =   array();
        $responsData            =   array();
        
        $time                       = 	date('Y-m-d H:i:s');      
        $jobData['JOB_TITLE']       =   $data->BookTitle;
        $jobData['JOB_REF']         =   $data->BookID;
        $jobData['JOB_TYPE']        =   $data->BookType;
        $jobData['BOOK_ID']         =   $data->BookID;
        $jobData['CREATED_DATE']    =   $time;
        
        $bookInfoObj                =   new bookinfoController();
        
        $jobInfoData['ISSN_ONLINE']        =   (isset($data->BookElectronicISBN)?$data->BookElectronicISBN:'');
        $jobInfoData['ISSN_PRINT']         =   (isset($data->BookPrintISBN)?$data->BookPrintISBN:'');
        $jobInfoData['AUTHOR_NAME']        =   (isset($data->AuthorName)?$data->AuthorName:'');
        $jobInfoData['AUTHOR_EMAIL']       =   (isset($data->AuthorContactEmail)?$data->AuthorContactEmail:'');
        
        $jobInfoData['EDITOR_NAME']        =   (isset($data->EditorName)?$data->EditorName:'');
        $jobInfoData['EDITOR_EMAIL']       =   (isset($data->EditorContactEmail)?$data->EditorContactEmail:'');
        
        $jobInfoData['PE_NAME']            =    (isset($data->ContactPersonName)?$data->ContactPersonName:'');
        $jobInfoData['PE_LOCATION']        =    (isset($data->ContactPersonContactCity)?$data->ContactPersonContactCity:'');
        $jobInfoData['PE_MAIL']            =    (isset($data->ContactPersonContactEmail)?$data->ContactPersonContactEmail:'');
        $jobInfoData['DOI']                =    (isset($data->BookDOI)?$data->BookDOI:'');
        $jobInfoData['JOURNAL_ACRONYM']    =    (isset($data->BookID)?$data->BookID:'');
        
        //Additional information given
        $jobInfoData['NO_PART_COUNT']       =        (isset($data->PartCount)?$data->PartCount:0);
        $jobInfoData['NO_APAGE_COUNT']      =        (isset($data->APageObjectsCount)?$data->APageObjectsCount:0);
        $jobInfoData['NO_CHAPTER_COUNT']    =        (isset($data->ChapterCount)?$data->ChapterCount:0);
        
        
        $jobInfoData['PUBLISHER_IMPRINT_NAME']          =        ( $data->PublisherImprintName );
        $jobInfoData['PRODUCTION_EDITOR']               =        (isset($data->ProductionEditor)?$data->ProductionEditor:'');
        $jobInfoData['PRODUCTION_EDITOR_EMAIL']         =        (isset($data->ProductionEditorEmail)?$data->ProductionEditorEmail:'');
        $jobInfoData['LANGUAGE']                        =        (isset($data->Language)?$data->Language:'');
        $jobInfoData['TOC_LEVELS']                      =        (isset($data->TocLevels)?$data->TocLevels:'');
        $jobInfoData['NUMBERING_STYLE']                 =        (isset($data->NumberingStyle)?$data->NumberingStyle:'');
        $jobInfoData['NUMBERING_DEPTH']                 =        (isset($data->NumberingDepth)?$data->NumberingDepth:'');
        $jobInfoData['CONTAINS_ESM']                    =       ( $data->ContainsESM == 'No') ? 'No' : 'Yes';
        $jobInfoData['BOOK_MULTI_VOLUME_COUNT']         =        (isset($data->BookMultiVolumeCount)?$data->BookMultiVolumeCount:'');
        $jobInfoData['PURCHASE_ORDER_NUMBER']           =        (isset($data->PurchaseOrderNumber)?$data->PurchaseOrderNumber:'');
        $jobInfoData['PRODUCTION_CLASSIFICATION']       =        (isset($data->ProductionClassification)?$data->ProductionClassification:'');
        $jobInfoData['NO_PAGES']                        =        (isset($data->ManuscriptNumberOfPages)?$data->ManuscriptNumberOfPages:'');
        $jobInfoData['NO_OF_IMAGES']                    =        (isset($data->NoofImages[0])?$data->NoofImages[0]:'');
        $jobInfoData['BLACK_WHITE_IMAGES']              =        (isset($data->BlackWhiteImages)?$data->BlackWhiteImages:'');
        $jobInfoData['AUTHOR_INFORMATION_STYLE']        =        (isset($data->AuthorInformationStyle)?$data->AuthorInformationStyle:'');
        $jobInfoData['ABSTRACT_IN_DOCUMENT_LANGUAGE']   =        (isset($data->AbstractInDocumentLanguage)?$data->AbstractInDocumentLanguage:'');
	$jobInfoData['TITLE_UPPERCASE']                 =        (isset($data->TitleUpperCase)?$data->TitleUpperCase:'');
        $jobInfoData['KEYWORDS_IN_DOCUMENT_LANGUAGE']   =        (isset($data->KeywordsInDocumentLanguage)?$data->KeywordsInDocumentLanguage:'');
        $jobInfoData['CLASSIFICATION_STYLE']            =        (isset($data->ClassificationStyle)?$data->ClassificationStyle:'');
        $jobInfoData['BIBLIOGRAPHY_STYLE']              =        (isset($data->BibliographyStyle)?$data->BibliographyStyle:'');
        $jobInfoData['CITATION_STYLE']                  =        (isset($data->CitationStyle)?$data->CitationStyle:'');
        $jobInfoData['LAYOUT']                          =        (isset($data->Layout)?$data->Layout:'');
        $jobInfoData['START_PAGE']                      =        (isset($data->StartPage)?$data->StartPage:'');
        $jobInfoData['RUNNING_HEAD']                    =        (isset($data->RunningHead)?$data->RunningHead:'');
        $jobInfoData['LOGO_ON_FIRST_PAGE']              =       ( $data->LogoOnFirstPage == 'No') ? 'No' : 'Yes';
        $jobInfoData['PROFILE']                         =        (isset($data->Profile)?$data->Profile:'');$data->Profile;
        $jobInfoData['COLOR_IMAGES_IN_PRINT']           =        (isset($data->ColorImagesInPrint)?$data->ColorImagesInPrint:'');
        $jobInfoData['LAYOUT_COLOR_COUNT']              =        (isset($data->LayoutColorCount)?$data->LayoutColorCount:'');
        $jobInfoData['PRINTING_COLOR_COUNT']            =        (isset($data->PrintingColorCount)?$data->PrintingColorCount:'');
        $jobInfoData['COPY_EDITING_LEVEL']              =        (isset($data->CopyEditingLevel)?$data->CopyEditingLevel:'');
        $jobInfoData['COPYRIGHT_HOLDER_NAME']           =        (isset($data->CopyrightHolderName)?$data->CopyrightHolderName:'');
        $jobInfoData['COPYRIGHT_YEAR']                  =        (isset($data->CopyrightYear)?$data->CopyrightYear:'');
        $jobInfoData['BOOK_SUB_TITLE']                  =        (isset($data->BookSubTitle)?$data->BookSubTitle:'');
        $jobInfoData['FORMAT_TRIM_SIZE']                =        (isset($data->FormatTrimSize)?$data->FormatTrimSize:'');
       
        $stage_deadlines                                =       array(
                                                                    'S5'    => str_replace(',','.',$data->Stage5), 
                                                                    'S50'   => str_replace(',','.',$data->Stage50) , 
                                                                    'S200'  => str_replace(',','.',$data->Stage200) , 
                                                                    'S300'  => str_replace(',','.',$data->Stage300) , 
                                                                    'S600'  => str_replace(',','.',$data->Stage600) , 
                                                                    'S650'  => str_replace(',','.',$data->Stage650) 
                                                                );
                
        $series_coln        =        array( 
                                            array( 'SerieId' => $data->SeriesID , 'SeriesTitle' => $data->SeriesTitle , 
                                                'SeriesEISSN' => $data->SeriesEISSN , 'SeriesPrintISSN' => $data->SeriesPrintISSN 
                                            )
                                     );
        
        $jobInfoData['STAGE_DEADLINES_COLLECTION']      =       json_encode( $stage_deadlines );
        //$jobInfoData['STAGE_RECEIVED_COLLECTION']     =       $data->'';
        $jobInfoData['SERIES_INFORMATION']              =       json_encode( $series_coln );
        
        $jobInfoData['PUBLISHER_LOCATION']              =       $data->PublisherLocation;
        $jobInfoData['PUBLISHER_NAME']                  =       $data->PublisherName;
        
        //$amDetails                         =   $this->getAmDetails($data->ContactPersonContactEmail);
        $amData         =         ApiModel::getAmUserDetails($data->ContactPersonContactEmail);
		
         if(count($amData)!=0){
             
            $jobInfoData['AM']              =       $amData->USER_ID;
            $jobInfoData['AM_NAME']         =       $amData->amName;
            $jobInfoData['AM_MAIL']         =       $amData->amEmail;  
            $prdarea_code                   =       $amData->PRODUCTION_AREA;
            $getPrdlc                       =       DB::table('production_area_location')->select()->where( 'ID' , $prdarea_code )->get()->first();
            
            //$jobInfoData['JOB_ASSIGNED_DATE'] =  $time;  
            $mailPmSend = 1;
            
        }else{
            
            $jobInfoData['AM'] =  '';
            $jobInfoData['AM_NAME'] =  '';
            $jobInfoData['AM_MAIL'] =  '';
            $jobInfoData['LOCATION'] =  '';  
            //$jobInfoData['JOB_ASSIGNED_DATE'] =  $time;  
            $mailPmSend = 0;
            
        }
        
        $jobConstant        =   Config::get('constants.JOB_CODE_PATTERN');
        $book_jobtype       =   '2'; //default set a xml as per priya confirmation
        $book_jobcode       =  $jobConstant[2];
        
        $jobCodeInfo        =   $bookInfoObj->generateJobCodeInformation($jobid='' , $book_jobcode , $book_jobtype);
        
        if(!empty($jobCodeInfo)){
             $jobData['JOB_CODE_ID']    =  $jobCodeInfo['JOB_CODE_ID'];
             $jobData['JOB_CODE_TYPE']  =  $jobCodeInfo['JOB_CODE_TYPE'];
             $jobData['JOB_REF']        =  $jobCodeInfo['JOB_REF'];
        }
        
        //check exist boookid is exist or not
        
        $checkexsitBook     =   DB::table('job')->where( ['BOOK_ID'=>$jobData['BOOK_ID'],'IS_ACTIVE'=>1] )->first();
        if(empty($checkexsitBook)){
			
            $jobId                  =   DB::table('job')->insertGetId( $jobData );         
            $jobInfoData['JOB_ID']  =   $jobId;

            if(!empty($jobInfoData['JOB_ID'])) {
                $jobInfoId              =   DB::table('job_info')->insertGetId( $jobInfoData );

                $reportData['JOB_ID']       =   $jobId;
                $reportData['ACTION']       =   '1';
                $repSuccess             =   app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData,'job');
            } 
            $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobId,'104','insert','download','');
            // PENTAHO REPORT  END

           if(!empty($jobId)){
               $responsData['apiStatus']        = 'success';
               $responsData['fileMovementPath'] = '';
               $updateFlag                      = ApiModel::updateDownloadLog($data->BookID);
               $fileData                        =   array();
               $fileData['JOB_ID']              =   $jobId;
               $fileData['BOOK_ID']             =   $data->BookID;
               $fileData['LOCATION_PATH']       =   '';//Config::get('constants.'.$responsData['fileMovementPath'].'_PRODUCTION_SERVER');
               $fileData['CREATED_DATE']        =   $time;
               $fileData['STATUS']              =   1;
               //DB::table('api_file_upload')->insert( $fileData ); 
            } else {
                $responsData['apiStatus']       =   'failed';
                $responsData['fileMovementPath']    =   '';
            }
            if($mailPmSend == 1)
                    $this->newJobNotificationMail($jobInfoData,$data,$time);
            if($mailPmSend == 0)   
                    $this->jobNotAssignedNotificationMail($jobInfoData,$data,$time);
        }else{
            $responsData['apiStatus']        = 'success';
            $responsData['fileMovementPath'] = '';
        }
        return $responsData;  

 	}catch(\Exception $e){
          //echo "<pre>"; print_r($e->getMessage());exit;
        }		
    }
        
    public function movejobfiles(Request $request){
        $requestData        =   $request->getContent();
        $apiData            =   json_decode($requestData);
        $time               = 	date('Y-m-d H:i:s');
        $result              = 'failed';
        if(!empty($apiData) && !empty($apiData->BookID)) {
            $bookRecord       =  ApiModel::getBookID($apiData->BookID);
           
            if(!empty($bookRecord)){
                $bookId                     = $apiData->BookID;
                $updateData['START_TIME']   = $apiData->StartTime;
                $updateData['END_TIME']     = $apiData->EndTime;
                $updateData['REMARKS']      = $apiData->Remarks;
                $updateData['STATUS']       = ($apiData->Status =='Success'?2:3);

                $data                       =  ApiModel::updateFileUPloadDetails($bookId,$updateData); 
                $result                     = 'Success';
            }else {
                $result  = 'Invalid Book Info';
            }
        }else{
              $result  = 'Invalid Argument';
        }
         
       return $result;
        
    }
    
    public function jobfilemovement(Request $request){
      $requestData        =    $request->getContent();
    
    // log something to storage/logs/debug.log
     Log::useDailyFiles(storage_path().'/Api/download.log');
     Log::info($requestData);
        
    }
    
    public function newJobNotificationMail($amDetails, $jobsheetDetails, $time){
        try{
        $mailArray = $mailData = array();

        $mailData['Title']              =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
        $mailData['HeadLine']           =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_HEAD_TITLE');
        $mailData['ToName']             =   $amDetails['AM_NAME'];
        $mailData['authorname']         =   $amDetails['AUTHOR_NAME'];
        $mailData['editorname']         =   $jobsheetDetails->EditorName;
        $mailData['BookId']             =   $jobsheetDetails->BookID;
        $mailData['BookTitle']          =   $jobsheetDetails->BookTitle;
        $mailData['BookIsbn']           =   $amDetails['ISSN_ONLINE'];
        $mailData['PrintIsbn']          =   $amDetails['ISSN_PRINT'];
        $mailData['ProductionEditorName']   =   $amDetails['PRODUCTION_EDITOR'];
        $mailData['ContactPersonName']  =   $jobsheetDetails->ContactPersonName;
        $mailData['PublisherName']      =   $jobsheetDetails->PublisherName;
        $mailData['ProductionClassification']   =   $jobsheetDetails->ProductionClassification;
        $mailData['ReceivedDate']       =   $time;
        $mailData['mailcontent']        =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ARRIVED_CONTENT');
        $mailArray['Data']              =   $mailData;
        $mailArray['TemplateName']      =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_JOB_ASSIGN_TEMP');
       // $mailData['Title'] = 'New Quote Created';
        $mailArray['Subject']           =   'New Title Arrival -'.$jobsheetDetails->BookID;
        $mailArray['FromMail']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']            =   $amDetails['AM_MAIL'];
       // $mailArray['CcMail']            =   Config::get('constants.CC_EMAIL_LIST');
        $mailArray['BccMail']            =   Config::get('constants.BCC_EMAIL_LIST');
        return $Response = $this->sendMailBladeTemplate($mailArray);
        }catch(\Exception $e){
           return true;
        }
        

    }
    
    public function jobNotAssignedNotificationMail($amDetails, $jobsheetDetails, $time){
    	try{
	        $mailArray = $mailData = array();
	        $mailData['Title']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
	        $mailData['HeadLine']       =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_HEAD_TITLE');
	        $mailData['ToName']         =   'Mohan';
	        $mailData['authorname']     =   $amDetails['AUTHOR_NAME'];
	        $mailData['editorname']     =   $jobsheetDetails->EditorName;
	        $mailData['BookId']         =   $jobsheetDetails->BookID;
	        $mailData['BookTitle']      =   $jobsheetDetails->BookTitle;
	        $mailData['BookIsbn']       =   $amDetails['ISSN_ONLINE'];
	        $mailData['ContactPersonName']  =   (empty($jobsheetDetails->ContactPersonName)?'':$jobsheetDetails->ContactPersonName);
	        $mailData['PublisherName']      =   $jobsheetDetails->PublisherName;
	        $mailData['ProductionClassification']   =   $jobsheetDetails->ProductionClassification;
	        $mailData['mailcontent']    =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NO_AM_NAME_CONTENT');
	        $mailData['ReceivedDate']   =   $time;
	        $mailArray['Data']          =   $mailData;
	        $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_JOB_ASSIGN_TEMP');
	       // $mailData['Title'] = 'New Quote Created';
	        $mailArray['Subject']       =   'New Title Arrival -'.$jobsheetDetails->BookID;
	        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
	        $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
	        $mailArray['ToMail']        =   'mohan.m@spi-global.com';
	       // $mailArray['CcMail']        =   Config::get('constants.CC_EMAIL_LIST');
	        $mailArray['BccMail']        =   Config::get('constants.BCC_EMAIL_LIST');
       
	        return $Response = $this->sendMailBladeTemplate($mailArray);
	}catch(\Exception $e){
           return true;
        }

    }
    
      public function promateJobNotificationMail($amDetails, $jobsheetDetails, $time , $roundname = 'S50' , $chapDetails = array() ){
       
        $mailArray = $mailData = array();
        
        if(!empty($amDetails['PM'])){
            
           $pm_userid       =       $amDetails['PM'];
           $usrC_obj        =       new usersController();
           $user_arr        =       $usrC_obj->getUserInfoByUserId($pm_userid); 
           $pm_name         =       $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
           $pm_mail         =       $user_arr->EMAIL;
           
           $mailData['ToName']      =        $pm_name;
           $mailArray['ToMail']     =        $pm_mail;
           
            if( $roundname != 'S200' )
                $mailArray['CcMail']     =        $amDetails['AM_MAIL'];
            
        }else{
             $mailData['ToName']         =   $amDetails['AM_NAME'];
             $mailArray['ToMail']        =   $amDetails['AM_MAIL'];
        }

        $mailData['Title']          =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
        $mailData['HeadLine']       =   $jobsheetDetails->BookID.' - Promoted to '.$roundname;
        $mailData['authorname']     =   $amDetails['AUTHOR_NAME'];
        $mailData['editorname']     =   $jobsheetDetails->EditorName;
        $mailData['BookId']         =   $jobsheetDetails->BookID;
        $mailData['BookTitle']      =   $jobsheetDetails->BookTitle;
        
        $mailData['BookIsbn']       =   $amDetails['ISSN_ONLINE'];
        $mailData['ContactPersonName']  =   (empty($jobsheetDetails->ContactPersonName)?'':$jobsheetDetails->ContactPersonName);
        $mailData['PublisherName']      =   $jobsheetDetails->PublisherName;
        $mailData['ProductionClassification']   =   $jobsheetDetails->ProductionClassification;
        $mailData['ReceivedDate']   =   $time;
        $mailData['mailcontent']    =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ARRIVED_CONTENT');
        $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.NEW_JOB_ASSIGN_TEMP');;
        $mailArray['Subject']       =   'New Title Arrival -'.$jobsheetDetails->BookID.' - Stage: '.$roundname;
        $mailArray['CcMail']      	=   Config::get('constants.CC_EMAIL_LIST');
        
        if( $roundname == 'S600' || $roundname == 'S650' ){
            $mailArray['Subject']       =   'Book Title - '.$jobsheetDetails->BookID.' - Promoted to Stage: '.$roundname;
        }
        
        if( !empty( $chapDetails ) ){
            
            $metaid             =       $chapDetails['metaId'];
            $chapterno          =       $chapDetails['chapterNo'];
            
            $smal_chapname      =       strtolower( $chapterno );
            $chapterfirstText   =       'chapter';
            
            if( ( strpos(  $smal_chapname  , $chapterfirstText )  !== false ) )
                $chapterno          =       preg_replace( '/\D/', '', $chapDetails['chapterNo'] );
            
            $mailData['chapterno']      =   $chapterno;
            $mailData['mailcontent']    =   \Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_CHAPTER_ARRIVED_CONTENT');
            $chapterfirstText           =   ucfirst($chapterfirstText); 
            $mailData['HeadLine']       =   $jobsheetDetails->BookID.' ( '.$chapterfirstText.':'. $chapterno.' ) - Promoted to '.$roundname;
            
            if( $roundname == 'S300' )
                $mailArray['Subject']       =       "Chapter Received - ".preg_replace('/\D/', '', $roundname)."  BookID: $jobsheetDetails->BookID Stage: ".preg_replace('/\D/', '', $roundname)." $chapterfirstText: $chapterno";
            
            if( $roundname == 'S200' )
                $mailArray['Subject']       =       "ChapterPromotion BookID: $jobsheetDetails->BookID Stage: ".preg_replace('/\D/', '', $roundname)." $chapterfirstText: $chapterno";
            
        }
        
        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['BccMail']       =   Config::get('constants.BCC_EMAIL_LIST');
        $mailArray['Data']          =   $mailData;
       
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
    
    
    public function assignPMmail($amDetails, $jobsheetDetails){
        
        $mailArray = $mailData = array();
        $mailData['Title']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.NEW_TITLE_ACK_NAME');
        $mailData['HeadLine']   =   'Job has assigned';
        $mailData['ToName']     =   'Shamu';
        $mailData['AM_NAME']    =   $amDetails['AM_NAME'];
        $mailData['BookID']     =   $jobsheetDetails->BookID;
        $mailData['BookTitle']  =   $jobsheetDetails->BookTitle;
        $mailArray['Data']      =   $mailData;
        $mailArray['TemplateName']  =   Config::get('constants.MAIL_TEMPLATE_NAME.JOB_ASSIGN_TEMP');;
       // $mailData['Title'] = 'New Quote Created';
        $mailArray['Subject']   =   $jobsheetDetails->BookID.'/Acknowledgement';
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail']    =   'shamu.shihabudeen@spi-global.com';
       // $mailArray['CcMail']      =       Config::get('constants.CC_EMAIL_LIST');
        $mailArray['BccMail']       =       Config::get('constants.BCC_EMAIL_LIST');
        
        return $Response            =       $this->sendMailBladeTemplate($mailArray);

    }
    
    public function sendMailBladeTemplate($mailArray) {
        try{
        $mailArray['ToMail']  =  'ananth.b@spi-global.com';
        $mailArray['BccMail']  =  'ananth.b@spi-global.com';
        $Response['Status'] =   1;
        $Response['Msg']    =   'Success';
                
        if (is_array($mailArray)) {
            
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                
                $message->subject( $mailArray['Subject'] );
                $message->from($mailArray['FromMail'] , $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }
                
                if (array_key_exists('BccMail', $mailArray)) {
                    $message->bcc($mailArray['BccMail']);
                }

                $message->getSwiftMessage();
                
            });

            /*if (Mail::failures()) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['MsgText'] = Mail::failures();
				 $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }*/
            
            }
        }catch(\Exception $e){
                
        }
        return $Response;
    }
    
    public function chapterDownload($logdata, $jobsheetDetails, $others){
       
        //450217_1_En
        $jobDetails     =       ApiModel::getJobDetails($jobsheetDetails->BookID);
    
        if(empty($jobDetails))
            return array();
      
        $taskLevelObj   =       taskLevelMetadataModel::getMetadatadetailsJob($jobDetails->JOB_ID);
      
        $processType    =   'chapter';
		 if(isset($jobsheetDetails->JobSheet)){
            $articleNo      =   $jobsheetDetails->JobSheet->ChapterID;
            if(empty($articleNo) && !empty($jobsheetDetails->JobSheet->PartID)){
              $articleNo    =     $jobsheetDetails->JobSheet->PartID;
              $processType  =     'part';
            }
		}else{
			$articleNo      =   $jobsheetDetails->ChapterID;
           
           if(empty($articleNo) && !empty($jobsheetDetails->PartID)){
              $articleNo    =     $jobsheetDetails->PartID;
              $processType  =     'part';
            }
		}
      
        $metaId         =   '';
        $chapterNo      =   '';     
        
        if(!empty($taskLevelObj)) {
            
            foreach ($taskLevelObj  as $key => $data){
                
                if($processType == 'chapter'){
                    
                    if($data->FM_ARTICLE_BM == '2' || $data->FM_ARTICLE_BM == '1' || $data->FM_ARTICLE_BM == '3'){
                        
                       $chapterNos = explode('_',$data->CHAPTER_NO) ;
                      
                       if(!empty($chapterNos['1']) && $chapterNos['1'] == $articleNo ){
                           $metaId      =   $data->METADATA_ID;
                           $chapterNo   =   $data->CHAPTER_NO;
                       }else{
                           if(!empty($chapterNos['0']) && $chapterNos['0'] == $articleNo){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
                       }
                    }
                }
				
				 if($processType == 'part'){
                    
                    if($data->FM_ARTICLE_BM == '4'){
                      
                       $chapterNos = explode('_',$data->CHAPTER_NO) ;
                     
                       if(!empty($chapterNos['1']) && $chapterNos['1'] == $articleNo ){
                           $metaId      =   $data->METADATA_ID;
                           $chapterNo   =   $data->CHAPTER_NO;
                       }else{
                           if(!empty($chapterNos['0']) && $chapterNos['0'] == $articleNo){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
						   
                           $partId   =  '';
                           $partId   = 'PART'.$articleNo;
						
                           if(empty($metaId) && !empty($chapterNos['0']) && $chapterNos['0'] == $partId){
                                $metaId      =   $data->METADATA_ID;
                                $chapterNo   =   $data->CHAPTER_NO;
                           }
                                                      
                       }
                    }
                }
                /** Part and other information need work **/
            }
        }
       
        /** Update current Round **/
        if(!empty($metaId)){
             $round_arr                         = \Config::get('constants.ROUND_ID');
             /** get S200 round id **/
             $updateData['CURRENT_ROUND']       = $round_arr['S200'];
             $updateData['CURRENT_QUANTITY']    = '5';
            
             $updateQry  =   DB::table('task_level_metadata')
			->where('METADATA_ID', $metaId )
			->update( $updateData );
        }
        
        $returnData['metaId']       =   $metaId ;
        $returnData['chapterNo']    =   $chapterNo ;
        $returnData['jobId']        =   $jobDetails;
        
        return $returnData;
        
    }
    
    public function getApiStatusOfJobSheet(){
        
        $obj_extractor      =       new apiMetaExtractor();
        $data               =       $obj_extractor->getJobsheetStatus(); 
        return response()->json( $data );
        
    }
    
    public function watchingApiTableStatus( Request $request ){
        
        $input_arr      =       $request->all();
        extract( $input_arr );
             
        $whereCondi     =       array( 'TOKEN_KEY' => $token  );
       
        if( isset( $metaid ) ){
            $whereCondi['METADATA_ID'] =   $metaid;
        }
        
        if( isset( $jobid ) ){
            $whereCondi['JOB_ID'] =   $jobid;
        }
        
        $getRec         =       DB::table( $table )->where( $whereCondi )->get()->first();
        
        $returns        =       array( 'status' => $getRec->STATUS , 'remarks' => $getRec->REMARKS );
        
        return response()->json( $returns );
        
    }
    
    public function assignDefaultWorkFlows($jobId ,$roundId){
        if(empty($jobId) || empty($roundId))
            return false;
        
        $jobinfoData    =   jobModel::getJobdetailsRawQuery( $jobId,'job.JOB_TYPE,job_info.PRODUCTION_SYSTEM,job_info.JOBSHEET_LESS' );
        $jobType        =   $jobinfoData->JOB_TYPE;
        
        $jobProductionType  =   $jobinfoData->PRODUCTION_SYSTEM;
        
        if($jobinfoData->JOBSHEET_LESS == 1){
             $autoStageList = \Config::get('constants.DEFAULT_S200_AUTO_STAGE_WORKFLOW_ID');
            
            $updateData2['IS_AUTO']       = '1';
            $updateQry2  =   DB::table('task_level_userdefined_workflow')
			->where('JOB_ID', $jobId )
                        ->whereIn( 'STAGE' , $autoStageList  )
			->update( $updateData2 );
            return true;
        }
        
        $workflowIds = \Config::get('constants.DEFAULT_WORKFLOW_LIST');
        
        $customizationModelObj  =       new customizationModel();
        $userId                 =   \Config::get('constants.ADMIN_USER_ID'); //admin User id
       
        $status['status']       =   0;
        foreach($workflowIds as $wfMid){ 
            $workflowList           =       $customizationModelObj->getUserdefinedInformation($jobId,$roundId,$wfMid);
            
            if($workflowList['0']->total == '0'){
                $roundSequence      =       '0';
                $workflowCount      =       $customizationModelObj->getWorkflowCount($jobId);
                $roundSequence      =       $workflowCount +1;
                $userDefineData     =       $customizationModelObj->insertUserdefineData($jobId,$roundId,$wfMid,$userId,$roundSequence);
                $status['status']   =   2;
            }
        }
        
        if( $status['status'] == '2'){
            if($jobType == 'S200 Of Series' || $jobType == 'Series' ){
                $defaultWorkflowId = \Config::get('constants.OFF_SERIES_DEFAULT_WORKFLOW');
            }else{
                $defaultWorkflowId = \Config::get('constants.DEFAULT_WORKFLOW');
            }
           
            if($jobProductionType == '2'){
                $defaultWorkflowId = \Config::get('constants.DEFAULT_CONVENTIONAL_WORKFLOW');
            }
            
            $updateData['WORKFLOW_TYPE']       = $defaultWorkflowId;
            $updateData['EMBBED_TYPE']         = 1;
            $updateQry  =   DB::table('job_info')
			->where('JOB_ID', $jobId )
			->update( $updateData );
           
            $serverpathCopyJOBId    =   \Config::get('constants.DEFAULT_S200_WORKFLOW_COPYJOB_ID');
            $sql =  "INSERT INTO `workflow_server_map` ( `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`, `JOB_ID`, `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ`)
                    select `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`,'".$jobId."', `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ` from workflow_server_map where job_id =  '$serverpathCopyJOBId'";
            $dtlList = DB::insert($sql);
            
            $autoStageList = \Config::get('constants.DEFAULT_S200_AUTO_STAGE_WORKFLOW_ID');
            
            $updateData2['IS_AUTO']       = '1';
            $updateQry2  =   DB::table('task_level_userdefined_workflow')
			->where('JOB_ID', $jobId )
                        ->whereIn( 'STAGE' , $autoStageList  )
			->update( $updateData2 );
        
            
        } 
       
        return true;
    }
    

    public function assignDefaultWorkFlowCommon( $jobId , $roundId , $getdefaultworkflowid  =   [] , $defaultCopyJobid = null  ){
        $servermapObj		=		new serverMapPathController();
        $servermapObj->assignDefaultWorkFlowCommon( $jobId , $roundId , $getdefaultworkflowid , $defaultCopyJobid  );
    }
	

    public function assignworkflow(){
        $data       =   $this->assignPreProductionWorkflowToJob(6401,104);
       
    }
   
	public  function assignPreProductionWorkflowToJob($jobId,$roundId) { 
      
        $jobModelObj            =   new jobModel();
        $jobDetails             =   $jobModelObj->getJobdetails($jobId);
        $workflowId             =   '';
        if($jobDetails->COPY_EDITING_LEVEL == '0'){
            
            $customizationModelObj  = new customizationModel();
            $wfdata                 =   $customizationModelObj->getWorkflowByCategoryByEmbbed($roundId,$jobDetails->COPY_EDITING_LEVEL);
           
            if(!empty($wfdata)){
                $workflowId         =   $wfdata->WORKFLOW_MASTER_ID;
            }
        }
        if(empty($workflowId)){
             $workflowMasterId       =  \Config::get('constants.DEFAULT_PRE_PRODUCTION_WORKFLOW_LIST');
        }else{
             $workflowMasterId       =   $workflowId;
        }
           
        $userId                 =  \Config::get('constants.ADMIN_USER_ID'); //admin User id
        $serverpathCopyJOBId       =  \Config::get('constants.DEFAULT_PRE_PRODUCTION_WORKFLOW_COPYJOB_ID'); //admin User id
        $customizationModelObj  =       new customizationModel();
        $workflowList           =       $customizationModelObj->getUserdefinedInformation($jobId,$roundId,$workflowMasterId);
        $status['status']   	=   0;
        if($workflowList['0']->total == '0'){
            
            $workflowCount      =       $customizationModelObj->getWorkflowCount($jobId);
            $roundSequence      =       $workflowCount +1;
            $userDefineData     =       $customizationModelObj->insertUserdefineData($jobId,$roundId,$workflowMasterId,$userId,$roundSequence);
            
            $status['status']   =   2;
           
            $sql =  "INSERT INTO `workflow_server_map` ( `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`, `JOB_ID`, `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ`)
                    select `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`,'".$jobId."', `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ` from workflow_server_map where job_id =  '$serverpathCopyJOBId'";
          
            $dtlList = DB::insert($sql);
           // return response()->json($status); 
            
        }
        if($status['status'] == '2'){
            
            if(empty($workflowMasterId)){
               $workflowMasterId                  =  \Config::get('constants.DEFAULT_PRE_PRODUCTION_WORKFLOW_LIST');  
            }
           
            $updateData['WORKFLOW_TYPE']          = $workflowMasterId;
			
            $updateQry  =   DB::table('job_info')
			->where('JOB_ID', $jobId )
			->update( $updateData );
        
        }
       
        return true;
    }
    
	public function updateJobInfoTable($apiData, $jobId = '', $round = '', $metaid = ''){
		$Response = array();
                
		try{	
                  
			if(!empty($apiData)) {
				$fullJobSheetJsonData = '';
				$logdata            =       array();
				foreach($apiData as $key=>$data){
					if($key == 'Download') {                
						$book_id = $data->BookID;
						$stageNumeric = $data->Stage; 
					}
					if($key == 'MetadataExtraction') {
						$logdata['META_EXTRACTION_STATUS']   =           ($data->Status=='Success'?1:0);
						if($logdata['META_EXTRACTION_STATUS'] == 1){
							$assignProcess = 1;
							$jobsheetDetails = $data->JobSheet;
							if(isset($data->OriginalJobSheet)){
								$fullJobSheetJsonData = $data->OriginalJobSheet->JobSheet;
							}
						}
					}
				}
                               
				$data = $jobsheetDetails;
				$mailPmSend = '';
				$jobInfoId = '';
				$responsData = array();
					
				$time = date('Y-m-d H:i:s');
				
				$jobInfoData['ISSN_ONLINE'] = (isset($data->BookElectronicISBN)?$data->BookElectronicISBN:'');
				$jobInfoData['ISSN_PRINT'] = (isset($data->BookPrintISBN)?$data->BookPrintISBN:'');
				$jobInfoData['AUTHOR_NAME'] = (isset($data->AuthorName)?$data->AuthorName:'');
				$jobInfoData['AUTHOR_EMAIL'] = (isset($data->AuthorContactEmail)?$data->AuthorContactEmail:'');
					
				$jobInfoData['EDITOR_NAME'] = (isset($data->EditorName)?$data->EditorName:'');
				$jobInfoData['EDITOR_EMAIL'] = (isset($data->EditorContactEmail)?$data->EditorContactEmail:'');
					
				$jobInfoData['PE_NAME'] = (isset($data->ContactPersonName)?$data->ContactPersonName:'');
				$jobInfoData['PE_LOCATION'] = (isset($data->ContactPersonContactCity)?$data->ContactPersonContactCity:'');
				$jobInfoData['PE_MAIL'] = (isset($data->ContactPersonContactEmail)?$data->ContactPersonContactEmail:'');
				$jobInfoData['DOI'] = (isset($data->BookDOI)?$data->BookDOI:'');
				$jobInfoData['JOURNAL_ACRONYM'] = (isset($data->BookID)?$data->BookID:'');
					
				//Additional information given
				$jobInfoData['NO_PART_COUNT'] = (isset($data->PartCount)?$data->PartCount:0);
				$jobInfoData['NO_APAGE_COUNT'] = (isset($data->APageObjectsCount)?$data->APageObjectsCount:0);
				$jobInfoData['NO_CHAPTER_COUNT'] = (isset($data->ChapterCount)?$data->ChapterCount:0);        
					
				$jobInfoData['PUBLISHER_IMPRINT_NAME'] = ( $data->PublisherImprintName );
				$jobInfoData['PRODUCTION_EDITOR'] = (isset($data->ProductionEditor)?$data->ProductionEditor:'');
				$jobInfoData['PRODUCTION_EDITOR_EMAIL'] = (isset($data->ProductionEditorEmail)?$data->ProductionEditorEmail:'');
				$jobInfoData['LANGUAGE'] = (isset($data->Language)?$data->Language:'');
				$jobInfoData['TOC_LEVELS'] = (isset($data->TocLevels)?$data->TocLevels:'');
				$jobInfoData['NUMBERING_STYLE'] = (isset($data->NumberingStyle)?$data->NumberingStyle:'');
				$jobInfoData['NUMBERING_DEPTH'] = (isset($data->NumberingDepth)?$data->NumberingDepth:'');
				$jobInfoData['CONTAINS_ESM'] = ( $data->ContainsESM == 'No') ? 'No' : 'Yes';
				$jobInfoData['BOOK_MULTI_VOLUME_COUNT'] = (isset($data->BookMultiVolumeCount)?$data->BookMultiVolumeCount:'');
				$jobInfoData['PURCHASE_ORDER_NUMBER'] = (isset($data->PurchaseOrderNumber)?$data->PurchaseOrderNumber:'');
				$jobInfoData['PRODUCTION_CLASSIFICATION'] = (isset($data->ProductionClassification)?$data->ProductionClassification:'');
				$jobInfoData['NO_PAGES'] = (isset($data->ManuscriptNumberOfPages)?$data->ManuscriptNumberOfPages:'');
				$jobInfoData['NO_OF_IMAGES'] = (isset($data->NoofImages[0])?$data->NoofImages[0]:'');
				$jobInfoData['BLACK_WHITE_IMAGES'] = (isset($data->BlackWhiteImages)?$data->BlackWhiteImages:'');
				$jobInfoData['AUTHOR_INFORMATION_STYLE'] = (isset($data->AuthorInformationStyle)?$data->AuthorInformationStyle:'');
				$jobInfoData['ABSTRACT_IN_DOCUMENT_LANGUAGE'] = (isset($data->AbstractInDocumentLanguage)?$data->AbstractInDocumentLanguage:'');
				$jobInfoData['TITLE_UPPERCASE'] = (isset($data->TitleUpperCase)?$data->TitleUpperCase:'');
				$jobInfoData['KEYWORDS_IN_DOCUMENT_LANGUAGE'] = (isset($data->KeywordsInDocumentLanguage)?$data->KeywordsInDocumentLanguage:'');
				$jobInfoData['CLASSIFICATION_STYLE'] = (isset($data->ClassificationStyle)?$data->ClassificationStyle:'');
				$jobInfoData['BIBLIOGRAPHY_STYLE'] = (isset($data->BibliographyStyle)?$data->BibliographyStyle:'');
				$jobInfoData['CITATION_STYLE'] = (isset($data->CitationStyle)?$data->CitationStyle:'');
				$jobInfoData['LAYOUT'] = (isset($data->Layout)?$data->Layout:'');
				$jobInfoData['START_PAGE'] = (isset($data->StartPage)?$data->StartPage:'');
				$jobInfoData['RUNNING_HEAD'] = (isset($data->RunningHead)?$data->RunningHead:'');
				$jobInfoData['LOGO_ON_FIRST_PAGE'] = ( $data->LogoOnFirstPage == 'No') ? 'No' : 'Yes';
				$jobInfoData['PROFILE'] = (isset($data->Profile)?$data->Profile:'');$data->Profile;
				$jobInfoData['COLOR_IMAGES_IN_PRINT'] = (isset($data->ColorImagesInPrint)?$data->ColorImagesInPrint:'');
				$jobInfoData['LAYOUT_COLOR_COUNT'] = (isset($data->LayoutColorCount)?$data->LayoutColorCount:'');
				$jobInfoData['PRINTING_COLOR_COUNT'] = (isset($data->PrintingColorCount)?$data->PrintingColorCount:'');
				$jobInfoData['COPY_EDITING_LEVEL'] = (isset($data->CopyEditingLevel)?$data->CopyEditingLevel:'');
				$jobInfoData['COPYRIGHT_HOLDER_NAME'] = (isset($data->CopyrightHolderName)?$data->CopyrightHolderName:'');
				$jobInfoData['COPYRIGHT_YEAR'] = (isset($data->CopyrightYear)?$data->CopyrightYear:'');
				$jobInfoData['BOOK_SUB_TITLE'] = (isset($data->BookSubTitle)?$data->BookSubTitle:'');
				$jobInfoData['FORMAT_TRIM_SIZE'] = (isset($data->FormatTrimSize)?$data->FormatTrimSize:'');
					
				$stage_deadlines = array(
					'S5'    => str_replace(',','.',$data->Stage5), 
					'S50'   => str_replace(',','.',$data->Stage50), 
					'S200'  => str_replace(',','.',$data->Stage200), 
					'S300'  => str_replace(',','.',$data->Stage300), 
					'S600'  => str_replace(',','.',$data->Stage600), 
					'S650'  => str_replace(',','.',$data->Stage650) 
				);
							
				$series_coln = array( 
					array( 'SerieId' => $data->SeriesID, 'SeriesTitle' => $data->SeriesTitle, 'SeriesEISSN' => $data->SeriesEISSN, 'SeriesPrintISSN' => $data->SeriesPrintISSN )
				);
					
				$jobInfoData['STAGE_DEADLINES_COLLECTION'] = json_encode( $stage_deadlines );
				//$jobInfoData['STAGE_RECEIVED_COLLECTION'] = $data->'';
				$jobInfoData['SERIES_INFORMATION'] = json_encode( $series_coln );
					
				$jobInfoData['PUBLISHER_LOCATION'] = $data->PublisherLocation;
				$jobInfoData['PUBLISHER_NAME'] = $data->PublisherName;
					
				//$amDetails = $this->getAmDetails($data->ContactPersonContactEmail);
				$amData = ApiModel::getAmUserDetails($data->ContactPersonContactEmail);
				/*	
				if(count($amData)!=0){             
					$jobInfoData['AM'] = $amData->USER_ID;
					$jobInfoData['AM_NAME'] = $amData->amName;
					$jobInfoData['AM_MAIL'] = $amData->amEmail;  
					$prdarea_code = $amData->PRODUCTION_AREA;
					$getPrdlc = DB::table('production_area_location')->select()->where( 'ID' , $prdarea_code )->get()->first();
						
					//$jobInfoData['JOB_ASSIGNED_DATE'] =  $time;  
					$mailPmSend = 1;
						
				}else{
						
					$jobInfoData['AM'] =  '';
					$jobInfoData['AM_NAME'] =  '';
					$jobInfoData['AM_MAIL'] =  '';
					$jobInfoData['LOCATION'] =  '';  
					//$jobInfoData['JOB_ASSIGNED_DATE'] =  $time;  
					$mailPmSend = 0;
				}*/
					
				//$jobInfoData['JOB_ID'] = $jobId; 
                                
				$getJobCount = DB::table('job_info')->where('JOB_ID', $jobId)->count();
				
				if(!empty($jobId) && $getJobCount > 0){
					
					$res   = DB::table('job_info')->where('JOB_ID', $jobId)->where('JOURNAL_ACRONYM', $jobInfoData['JOURNAL_ACRONYM'])->update($jobInfoData);
                                       
                                        $reportData['JOB_ID']       =   $jobId;
                                        $reportData['ACTION']       =   '2';
                                       
                                        $repSuccess                 =   app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData,'job');
                                        
					//milestone entry
					$this->handleJobRoundMileStone( $jobsheetDetails , $stageNumeric, $metaid, $fullJobSheetJsonData );
					
					$Response['Status'] = 0;
					$Response['Msg'] = 'Successfully update job_info table data.';
					Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
					Log::info( json_encode( $Response) );
					Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
					return true;
				}else{
					$Response['Status'] = 1;
					$Response['Msg'] = 'Failure';
					$Response['ErrorMsg'] = "Job Id is not found in job_info table.";
					Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
					Log::info( json_encode( $Response) );
					Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
					return false;
				}
			}else{
				$Response['Status'] = 1;
				$Response['Msg'] = 'Failure';
				$Response['ErrorMsg'] = "API Data is empty";
				Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
				Log::info( json_encode( $Response) );
				Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
				return false;
			}
		}catch( \Exception $e ){ 
			$Response['Status'] = 1;
			$Response['Msg'] = 'Failure';
			$Response['ErrorMsg'] = $e->getMessage();
			Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
			Log::info( json_encode( $Response) );
			Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
			return false;
		}
	}
        
      public function ostDownload(Request $request) {
        
       try{  
         
        $requestData        =       $request->getContent();
        $cmn_obj            =       new CommonMethodsController();
        
        
        Log::useDailyFiles(storage_path().'/Api/ostdownload.log');
        Log::info($requestData);
        
        $apiData            =       json_decode($requestData);
       
        $jobSheetResponse   =       array();
        
        $roundFrm            =       'S'.$apiData->Stage;   
        $round_arr           =       \Config::get('constants.ROUND_ID');
        $response            =       array();
        
        $response['default_jobsheet_path']      =       '';
        
        $bookId              =       $apiData->bookId;
        
        $round               =       $round_arr[$roundFrm];
        
        $out_validation     =       array();  
        
       $bookdetails         =       DB::select( 'select * from job j left join api_download apd on apd.BOOK_ID = j.BOOK_ID where apd.ROUND = '.$round.' and apd.BOOK_ID = "'.$bookId.'"' );           
       $table_name         =       'api_production_file_transfer';
       $base_url           =       \Config::get('constants.BASE_URL');
        $ret_url           =       $base_url.'/api/ostDownlodCallback';
       if(!empty($bookdetails)){
           $token_key          =        $cmn_obj->generateRandomString( 16 , $table_name  );
          
            $jobId              =       $bookdetails['0']->JOB_ID;
            $revisedJs          =       app('App\Http\Controllers\Api\revisedJobController')->revisingProcessJobLevelforOst($jobId,$round );
            $Response['Status'] = 2;
            $Response['Msg']    = 'Success';
            $Response['copyjobsheetPath'] = $revisedJs;
            $Response['WorkflowAPI']    = array(
                                                                'Url'   =>  $ret_url , 
                                                                'parameter' => array( 
                                                                                        array( 'key' => 'process' , 'value'=> 'ost_download' , 'type' => 'fixed' ) ,  
                                                                                        array( 'key' => 'tokenkey' , 'value'=> $token_key , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'jobid' , 'value'=> $jobId , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'round' , 'value'=> $round , 'type' => 'fixed' ) , 
                                                                                        array( 'key' => 'status' ,  'type' => 'boolean' ) , 
                                                                                        array( 'key' => 'remarks' ,  'type' => 'string' ) , 
                                                                                        array( 'key' => 'endtime' ,  'type' => 'data-time' , 'value' => 'yyyy-MM-dd HH-mm-ss' ) 
                                                                                ),
                                                            );   
           
            $api_pft            =       new apiProductionFileTransfer();
            
            $inp_arr    =       array( 
                                        'TOKEN_KEY' => $token_key , 
                                        'PROCESS_NAME' => 'OST_DOWNLOAD' , 
                                        'JOB_ID'    =>  $jobId, 
                                        'ROUND'     =>  $round , 
                                        'START_TIME' => date( 'Y-m-d H:m:i' ) ,
                                        'REQUEST_LOG'   => json_encode($Response),
					'STATUS'	=> 1
                                    );
            
            $api_pft->insertNew($inp_arr);
       
       }else{
            $Response['Status'] = 1;
            $Response['Msg'] = 'Failure';
            $Response['ErrorMsg'] = 'Invalid Book id';
            $Response['copyjobsheetPath'] = '';
           
       }
       Log::useDailyFiles(storage_path().'/Api/ostdownload.log');
       Log::info($Response);
      
       return response()->json($Response);      
        
       }catch( \Exception $e ){ 
            $Response['Status'] = 1;
            $Response['Msg'] = 'Failure';
            $Response['ErrorMsg'] = $e->getMessage();
            Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
            Log::info( json_encode( $Response) );
            Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
            return false;
       }
       
     }
     
   public function ostDownlodCallback(Request $request){
         
        $inputarr           =           (array)json_decode( $request->getContent() );
        $process            =           strtolower($inputarr['process']);
        $status             =           $inputarr['status'];

        Log::useDailyFiles(storage_path().'/Api/production_file_trans_output.log');
        Log::info(json_encode( $inputarr) );
     
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
     
        $jobId          =       $job_id         =       $inputarr['jobid']; ;
        $round          =       $inputarr['round'];
        $token_key      =       $inputarr['tokenkey'];
                 
        $inpArr['REMARKS']       =      $inputarr['remarks'];
        $inpArr['END_TIME']     =       date( 'Y-m-d H:m:i' );
        $errMsg =   '';        
        
        $api_pft        =       new apiProductionFileTransfer();
        $rec            =       $api_pft->getApiRequest( $jobId , $round , $token_key );
                  
         if(is_object( $rec )){
             
              $inpArr['STATUS']       =       $status;
            $rowid                  =       $rec->ID;
            $api_pft->updateIfExist($inpArr, $rowid);
            
            $response['status']         =       1;
            $response['msg']            =       'Success';
            $response['errMsg']         =       'signal received';
            
        
         }else{
            
            $response['status']         =       0;
            $response['msg']            =       'Failed...';
            $response['errMsg']         =       'Invalid Try';
            
        }
        
        
        return response()->json( $response );

   }
   
   public function chapterSequenceOrderupdate($seqData, $jobId){
	   
	   $taskLevelObj   =       taskLevelMetadataModel::getMetadatadetailsJob($jobId);
	   $currentDate    =   		date( 'Y-m-d H:i:s' );
	   
	   $syncUpdate2['UPDATED_AT']    	=      $currentDate;
	   $syncUpdate2['STATUS']      		=      0;
			
	   DB::table('part_mapping')->where('JOB_ID',$jobId)->update( $syncUpdate2 );
	  
	   
	   foreach($taskLevelObj as $key => $value){
		$chapterList[strtoupper($value->CHAPTER_NO)]  =  $value->taskmetaid;
		
	   }
	   
	  
	   $partCom  = array();
	   
	   if($seqData['0']->Component  == 'FM1' || $seqData['0']->Component  == 'Fm1'){
			  $sequence = 0; 
		}else{
			 $sequence = 1; 
		}
	   
	 
	   foreach($seqData as $key2 => $value2){
		   
		   if($value2->Component == 'FM1' || $value2->Component == 'BM1'){
			   $seqComp		= $value2->Component; 
		   }else{
				$seqComp		=	$value2->Component.'_'.$value2->Number;
		   }
		   
		   $seqUpdate[$chapterList[strtoupper($seqComp)]] = $key2;
		   
		   $metaId   						=	$chapterList[strtoupper($seqComp)];
		   
		    $syncUpdate['LAST_MOD_DATE']    =      $currentDate;
			$syncUpdate['CHAPTER_SEQ']      =      $sequence;
			
			DB::table('task_level_metadata')->where('METADATA_ID',$metaId)->update( $syncUpdate );
		   
		   $sequence	=	 $sequence +1;
		   
		   
		   if(strtoupper($value2->Component) == 'CHAPTER'){
			   
			   if($value2->Part != ''){
				$insData 						= array();
				$insData['JOB_ID']                =   $jobId;
                $insData['CHAPTER_METADATA_ID']   =   $chapterList['CHAPTER_'.$value2->Number];
                $insData['PART_METADATA_ID']      =   $chapterList['PART_'.$value2->Part];
                $insData['CREATED_BY']            =   Config::get('constants.ADMIN_USER_ID');
				$insData['CREATED_AT']            =    $currentDate;
				$insData['STATUS']            	  =   1;
				
				
				 DB::table('part_mapping')->insertGetId( $insData );
				//$partCom[$chapterList['PART_'.$value2->Part]][] = $chapterList['CHAPTER_'.$value2->Number];
				
			   }
		   }
		   //$chapterList[ucwords($value->CHAPTER_NO)]  =  $value->taskmetaid;
	   }
	   return true;
   }
    
}
