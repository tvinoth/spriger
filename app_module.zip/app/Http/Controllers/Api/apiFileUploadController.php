<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiFileUpload;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\productionLocationModel;
use App\Models\ServiceManager as ServiceModel;
use App\Models\jobModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Models\jobRevisedModel;
use Session;
use Illuminate\Support\Facades\Storage;
use Mail;
use Validator;
use DB; 
use Log;
use Carbon\Carbon;
use Config;
use Illuminate\Support\Facades\Crypt;

class apiFileUploadController extends Controller
{
    
    public function storeResponse( Request $request ){
           
        $inputarr       =       (array)json_decode( $request->getContent() );
        
        Log::useDailyFiles(storage_path().'/Api/jobsheet_upload_output.log');
        Log::info($inputarr);
       
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $process        =       strtolower($inputarr['process']);
        $status         =       $inputarr['status'];
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
     
        $jobId          =       $job_id         =       $inputarr['jobid'];
        $book_id        =       $inputarr['bookid']; 
        $round          =       $inputarr['round'];
        $token_key      =       $inputarr['tokenkey'];

       
        $str_remarks    =   $inpArr['REMARKS']       =      $inputarr['remarks'];
        $inpArr['END_TIME']     =       date( 'Y-m-d H:i:s' );
        $errMsg =   '';        
        
        $rec 	=	$getRec       =         DB::table('api_file_upload as afu')
                                                        ->where('JOB_ID', '=', $jobId )
                                                        ->where('ROUND', '=', $round )                                            
                                                        ->where('TOKEN_KEY', '=', $token_key )   
                                                        ->where('STATUS', '=', '1.5' )
                                                        ->orderBy('afu.ID', 'desc')
                                                        ->get()->first();

        $api_pft        	=       new apiFileUpload();
        $rec            	=       $api_pft->getApiRequest( $jobId , $round , $token_key );
		
        if(is_object( $rec )){

            $inpArr['STATUS']       =       $status;
            $rowid      =       $rec->ID;
            $api_pft->updateIfExist($inpArr, $rowid);
            
            //active mq
            if(Config::get('constants.PROCESS_TYPE')   ==  $rec->PROCESS_TYPE){
                $successfileresponse    =   app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetailsClosure($jobId,$round,'insert','',Config::get('constants.STAGE_COLLEECTION.SUCCESS_REDO'),Config::get('constants.PROCESS_TYPE'));
            }
            
            $response['status']         =       1;
            $response['msg']            =       'Success';
            $response['errMsg']         =       'signal received';

        }else{
            
            $response['status']         =       0;
            $response['msg']            =       'Failed...';
            $response['errMsg']         =       'Invalid Try';
            
        }
        
        return response()->json( $response );
        
    }
    
    
    public function storeResponseS200( Request $request ){
           
        $inputarr       =       (array)json_decode( $request->getContent() );
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        
        Log::useDailyFiles(storage_path().'/Api/'. $round_arr[$inputarr['round']].'_jobsheet_upload_output.log');
        Log::info($inputarr);
       
        $process        =       strtolower($inputarr['process']);
        $status         =       $inputarr['status'];
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
     
        $jobId          =       $job_id         =       $inputarr['jobid'];
        $book_id        =       $inputarr['bookid']; 
        $round          =       $inputarr['round'];
        $chapterid      =       $inputarr['chapterid'];
        $token_key      =       $inputarr['tokenkey'];

       
        $str_remarks    =   $inpArr['REMARKS']       =      $inputarr['remarks'];
        $inpArr['END_TIME']     =       date( 'Y-m-d H:i:s' );
        $errMsg =   '';        
        
        $rec 	=	$getRec       =         DB::table('api_file_upload as afu')
                                                        ->where('JOB_ID', '=', $jobId )
                                                        ->where('ROUND', '=', $round )                                            
                                                        ->where('METADATA_ID', '=', $chapterid )                                            
                                                        ->where('TOKEN_KEY', '=', $token_key )   
                                                        ->where('STATUS', '=', '1.5' )
                                                        ->orderBy('afu.ID', 'desc')
                                                        ->get()->first();

        $api_pft        =       new apiFileUpload();
        	
        if(is_object( $rec )){

            $inpArr['STATUS']       =       $status;
            $rowid      =       $rec->ID;
            $api_pft->updateIfExist($inpArr, $rowid);
			
            $response['status']         =       1;
            $response['msg']            =       'Success';
            $response['errMsg']         =       'signal received';

        }else{
            
            $response['status']         =       0;
            $response['msg']            =       'Failed...';
            $response['errMsg']         =       'Invalid Try';
            
        }
        
        return response()->json( $response );
        
    }
    
    public function sendRequestReceiptJobSheetUpload( $jobid  ,  $round, $processType = 'RECEIPT' , $chapterid    =   null ){
        
        $roundname_arr      =       \Config::get('constants.ROUND_NAME');
        $roundid_arr        =       \Config::get('constants.ROUND_ID');
        $roundname  =   $roundname_arr[$round];
        if( $roundname == 'S5' )
            return $this->sendRequestS5JobSheetUpload( $jobid , $roundname , $processType );
        if( $roundname == 'S50' )
           return $this->sendRequestS50JobSheetUpload($jobid , $roundname, $processType );
        if( $roundname == 'S200' ){
           return $this->sendRequestS200JobSheetUpload($jobid , $roundname, $processType,$chapterid );
        }
        if( $roundname == 'S300' ){
            return $this->sendRequestS200JobSheetUpload($jobid , $roundname, $processType,$chapterid );
        }
        if( $roundname == 'S650' )
            return $this->sendRequestS5JobSheetUpload( $jobid , $roundname , $processType );
        
    }
    
    // This method will return zip output path with filename , zip output folder path , genrated zip filename with timestamp
    public function getClientUploadZipCreationInformation( $bookId , $jobid , $round,$type  =   "book" ){
        
        if($type    ==  "book")
        {
            $where_api_dwnld        =      array(  
                                            'BOOK_ID'       =>          $bookId  , 
                                            'ROUND'         =>          $round 
                                         );
        }
        else
        {
            $where_api_dwnld        =      array(  
                                            'METADATA_ID'   =>      $type, 
                                            'ROUND'         =>      $round 
                                         );
        }
        
        $getlocationftp         =           productionLocationModel::getDefaultProductionLocationInfo( );
        $hostserver             =           $getlocationftp->FTP_HOST;
        $hostpath               =           $getlocationftp->FILE_SERVER_PATH;
        
        $zip_info               =           array();
        $api_downlod_rec        =           DB::table('api_download')
                                                            ->select()
                                                            ->where( $where_api_dwnld  )
                                                            ->orderBY('ID', 'DESC')
                                                            ->get()                                                
                                                            ->first();
        
        $zip_file_name          =       '';             
        $zip_out_const          =       \Config::get('serverconstants.ZIP_BACKUPS_BEFORE_UPLOAD');  
        $zip_out_const          =       $hostserver.$hostpath.$zip_out_const;
        $zip_out                =       str_replace( '/' , '\\' ,     $zip_out_const   ); 
        $zip_out                =       str_replace( '//' , '\\' ,    $zip_out ); 
        $zip_out                =       str_replace( '\\\\' , '\\' ,  $zip_out );
        $zip_out                =       '\\\\'.$zip_out;   
        
        
        if( !empty( $api_downlod_rec ) && ( count( $api_downlod_rec ) > 0) ){                   
            $str                =      $book_zipfile    =   $api_downlod_rec->FILE_NAME;
            $remove_last_len    =      -23;
            $strleng            =      strlen( $book_zipfile ) - $remove_last_len;
            $book_zipfile       =      substr( $book_zipfile ,  $remove_last_len , $strleng );
            $book_zipfile       =      str_replace( $book_zipfile , '' , $str );
            $ext                =      '.zip';
            $cur_time           =      date('Y-m-d_H-i-s');
            $zip_file_name      =      $book_zipfile.$cur_time.$ext;
            $zip_info           =   [];
            $zip_info['ZIP_NAME']                   =       $zip_file_name;    
            $zip_info['ZIP_OUTPUT_FOLDER_PATH']     =       $zip_out; 
            $zip_info['ZIP_OUTPUT_FILE_PATH']       =       $zip_out.$zip_file_name; 
       // return $zip_info;
        }
        
       return $zip_info; 
    }
        
    public function sendRetryRequest( $jobId = null , $round = 114 ){
        
        $input_arr      =      array();        
        $time = date( 'Y-m-d H:i:s' );	
        
        $response['status']  =      0;
        $response['msg']     =     'Failed';
        $response['errMsg']  =     'Try again after some times';
        
        try
        {            
            $api_tbl_input      =       array( 'JOB_ID' => $jobId , 'ROUND' => $round  , 'START_TIME' => $time );
            $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
            $api_tbl_input['BOOK_ID']    =       $bookId             =       $jobDetails[0]->BOOK_ID;
            
            $getResponse        =        apiFileUploadController::insertNew( $api_tbl_input );
            
            if( $getResponse  ==  2  ){                  
                $response['status']  =     1;
                $response['msg']     =     'Success';
                $response['errMsg']  =     'Api request send  successfully';                
            }
            
        }catch( \Exception $e ){            
             $response['errMsg']    =   $e->getMessage();             
        }
        
        return $response;
             
    }
  
    public function sendRequestS5JobSheetUpload( $jobId  , $round =   'S5', $processType = 'RECEIPT' ){        
        
        $input_arr      =       array();        
        $time           =       date( 'Y-m-d H:i:s' );	
        
        $response['status']  =      0;
        $response['msg']     =     'Failed';
        $response['errMsg']  =     'Try again after some times';
        $round_arr           =      \Config::get('constants.ROUND_ID');
        
        if( $round ==  $round_arr['S5']  || $round == 'S5' ){
           $roundname           =      $round =   'S5';
        }
        
        if( $round ==  $round_arr['S600']  || $round == 'S600' ){
           $roundname           =      $round =   'S600';
        }
        
        if( $round ==  $round_arr['S650']  || $round == 'S650' ){
           $roundname           =      $round =   'S650';
        }
        
        $round               =       $round_arr[$round];
        $processType_alter   =      $processType;
		
        //try
        //{
        
            $table_name         =       'api_file_upload';            
            $cmn_obj            =       new CommonMethodsController();
            $token_key          =       $cmn_obj->generateRandomString( 16 , $table_name  ); 
            
            $api_tbl_input_upload      =       array(   'JOB_ID'     =>      $jobId ,
                                                        'ROUND'      =>      $round  , 
                                                        'START_TIME' =>      $time ,
                                                        'TOKEN_KEY'  =>      $token_key , 
                                                        'STATUS'     =>      1.5 , 
                                                        'PROCESS_TYPE' =>    $processType_alter
                                                    );
           
            $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
            $book_id            =       $api_tbl_input_upload['BOOK_ID']    =       $bookId             =       $jobDetails[0]->BOOK_ID;
            $job_id             =       $jobId;     
            $locationFlag       =       1;
            $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
           
            if( empty( $getlocationftp ) ){
                $getlocationftp     =      productionLocationModel::getDefaultProductionLocationInfo();
                $locationFlag    = 0;
            }
            
            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            if($locationFlag  == 1)
                $hostpassword       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
            else{
                $hostpassword       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
            }
            
            $hostpath           =       ($getlocationftp->FTP_PATH);
                    
            
            $root_path              =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
            
            $roundname              =       $round_arr[$round];     
            
            $inp_rep_arr            =       array( 
                                                'BOOK_ID'       =>      $book_id , 
                                                'ROUND_NAME'    =>      $roundname                        
                                            );
            
            $jbst_path              =           \Config::get('constants.UPDATED_JOBSHEET_PATH');     
            $cmn_obj                =           new CommonMethodsController();
            $raw_path               =           $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jbst_path );
            
            $zip_info               =       $this->getClientUploadZipCreationInformation( $bookId , $jobId , $round );
            
            $travers_filesname      =       '';
            $process_enum           =       array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 ,  'WRONG_INSTRUCTION' => 4 , 'CORRECTION' => 5  , 'REVISED_RECEIPT' =>  6 );
            $ptype                  =       $process_enum[$processType];

            $array_cond_metaextractor       =       array( 'JOB_ID' => $jobId , 'ROUND' => $round , 'PROCESS_TYPE' => $ptype );
            
            $api_meta_extractor     =       DB::table('api_meta_extractor')
                                            ->select()
                                            ->where( $array_cond_metaextractor )
                                            ->orderBy('ID' , 'desc')
                                            ->get()                                                
                                            ->first();
            $travers_filesname      =       $api_meta_extractor->ZIP_NAME;
            
            $jobsheet_file_path     =       $zip_info['ZIP_OUTPUT_FOLDER_PATH'].$travers_filesname; 
            $base_url               =       \Config::get('constants.BASE_URL');
            
            $ftp_host               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
            $ftp_username           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
            $ftp_password           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
            $jobsheet_upload_path   =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.path');
            $ftp_type               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
            $fingerPrint            =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');
            // PENTAHO REPORT  START
            $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobId,$round,'update','download','');
            // PENTAHO REPORT  END
            $ret_url                =       $base_url.'/api/jobsheetUploadCallback';
            
            $uploadMeta = "";            
            $uploadMeta .= "<uploadMeta>";
            $uploadMeta .= "<bookid>" . $bookId . "</bookid>";
            $uploadMeta .= "<stage>" . $roundname . "</stage>";
            $uploadMeta .= "<uploadtype>JOBSHEET_UPLOAD</uploadtype>";
            $uploadMeta .= "<sourceFile>";
            $uploadMeta .= "<filepath>" .$jobsheet_file_path."</filepath>";
            $uploadMeta .= "</sourceFile>";
            $uploadMeta .= "<destPath>";
            $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
            $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
            $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
            $uploadMeta .= "<path>".$jobsheet_upload_path."</path>";
            $uploadMeta .= "<username>".$ftp_username."</username>";
            $uploadMeta .= "<password>".$ftp_password."</password>";
            $uploadMeta .= "</destPath>";
            $uploadMeta .= '<WorkflowAPI>
                                <Url value="'.$ret_url.'"/>
                                <parameter key="process" value="upload" type="fixed"/>
                                <parameter key="jobid" value="'.$job_id.'" type="fixed"/>
                                <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                <parameter key="round" value="'.$round.'" type="fixed"/>
                                <parameter key="status" type="boolean"/>
                                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                <parameter key="remarks" type="string"/>
            </WorkflowAPI>';
            $uploadMeta .= "</uploadMeta>";
            
            $ftpObj 	= 	Storage::createFtpDriver([
								'host'     => $hostserver , 
								'username' => $hostusername ,
								'password' => $hostpassword , // 
								'port'     => '21',
								'timeout'  => '30',
							]);

            $content 	= 	$uploadMeta;
            $filename 	=	$book_id.'_s5_jobsheet_upload_meta.xml';
            
            Log::useDailyFiles(storage_path().'/Api/s5_jobsheet_upload_input.log');
            Log::info( $content );
            
            $successfileresponse 	=	$ftpObj->put(Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/'.$filename, $content);
            
            if( $successfileresponse ){               

                if( $processType == 'RECEIPT' ){

                        $inputhwerearr	=	array();

                        $inputhwerearr['ROUND']		=	$round;
                        $inputhwerearr['JOB_ID']	=	$job_id;
                        $jbrevised 		=	new jobRevisedModel();
                        $isRevised		=	$jbrevised::where( $inputhwerearr )->get();

                        if(  count( $isRevised ) > 1 ){
                                $processType		=	$api_tbl_input['PROCESS_TYPE']	=	'REVISED_RECEIPT';
                        }

                }
			
                $getResponse        =       apiFileUpload::insertNew( $api_tbl_input_upload );                
                $acknow_data        =       array(  
                                                    'JOB_ID'    =>      $job_id ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    'PROCESS_TYPE_DIFF' =>      $processType , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                                );
               
			
                //clientAck insert
                apiClientAcknowledgement::insertNew( $acknow_data );
                
                if( $getResponse ){                  
                    $response['status'] =   1;
                    $response['msg']    =   'Success';
                    $response['errMsg'] =   'jobsheet upload meta posted successfully';                
                }                
            }
            
        //}catch( \Exception $e ){            
        //    $response['errMsg']    =   $e->getMessage();             
        //}        
        
        return response()->json( $response );
        
    }
    
    public function sendRequestS50JobSheetUpload( $jobId  , $round =   'S50', $processType = 'RECEIPT' ){        
        
        $input_arr      =       array();        
        $time           =       date( 'Y-m-d H:i:s' );	
       
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Try again after some times';
        $response['msgstatus']      =       '';
        $roundname                  =       $round  =   'S50';
        
        $round_arr                  =       \Config::get('constants.ROUND_ID');
        $round                      =       $round_arr[$round];
        $round_name_arr             =       \Config::get('constants.ROUND_NAME');      
        $round_name                 =       $round_name_arr[$round];
        
        try
        {
            $table_name             =       'api_file_upload';            
            $cmn_obj                =       new CommonMethodsController();
            $token_key              =       $cmn_obj->generateRandomString( 16 , $table_name  ); 
            
            $api_tbl_input          =       array( 
                                                'JOB_ID'        =>      $jobId , 
                                                'ROUND'         =>      $round  ,
                                                'START_TIME'    =>      $time ,
                                                'TOKEN_KEY'     =>      $token_key , 
                                                'STATUS'        =>      1.5 ,
                                                'PROCESS_TYPE'  =>      $processType
                                            );
            
            $jobDetails             =       DB::table('job')->where('JOB_ID', $jobId )->get();
            $book_id                =       $api_tbl_input['BOOK_ID']    =       $bookId             =       $jobDetails[0]->BOOK_ID;
            
            $job_id                 =       $jobId;           
            $getlocationftp         =       productionLocationModel::doGetLocationname( $jobId );   
            
            //need to dynamicaly bind the production location based on table location
            $hostserver             =       $getlocationftp->FTP_HOST;
            $hostusername           =       $getlocationftp->FTP_USER_NAME;
            $hostpassword           =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath               =       ($getlocationftp->FTP_PATH);
                        
            $root_path              =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
           
            $roundname              =       $round_arr[$round];                 
            $inp_rep_arr            =       array( 
                                                    'BOOK_ID'       =>      $book_id , 
                                                    'ROUND_NAME'    =>      $roundname                        
                                            );
            
            $jbst_path              =       \Config::get('constants.UPDATED_JOBSHEET_PATH');     
            $cmn_obj                =       new CommonMethodsController();
            $raw_path               =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jbst_path );
            
            $zip_info               =       $this->getClientUploadZipCreationInformation( $bookId , $jobId , $round );
           
            $travers_filesname      =       '';
           
            $process_enum           =       array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 , 'WRONG_INSTRUCTION' => 4 , 'CORRECTION' => 5  , 'REVISED_RECEIPT' =>  6 );
            $ptype                  =       $process_enum[$processType];
            if($ptype == 2){
                  $nptype = 3;
            }else{
                  $nptype = $ptype;
            }
            $array_cond_metaextractor       =       array( 'JOB_ID' => $jobId , 'ROUND' => $round , 'PROCESS_TYPE' => $nptype );
            
            $api_meta_extractor     =       DB::table('api_meta_extractor')
                                                    ->select()
                                                    ->where( $array_cond_metaextractor )
                                                    ->orderBy('ID' , 'desc')
                                                    ->get()                                                
                                                    ->first();
            
            
            $travers_filesname      =       $api_meta_extractor->ZIP_NAME;  
            $jobsheet_file_path     =       $zip_info['ZIP_OUTPUT_FOLDER_PATH'].$travers_filesname;             
            $base_url               =       \Config::get('constants.BASE_URL');
            
             
            $ftp_host               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
            $ftp_username           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
            $ftp_password           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
            $jobsheet_upload_path   =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.path');
            $ftp_type               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
            $fingerPrint            =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');
            $ret_url                =       $base_url.'/api/jobsheetUploadCallback';
            // PENTAHO REPORT  START
            $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobId,$round,'update','download','');
            // PENTAHO REPORT  END
            
            $uploadMeta = "";            
            $uploadMeta .= "<uploadMeta>";
            $uploadMeta .= "<bookid>" . $bookId . "</bookid>";
            $uploadMeta .= "<stage>" . $roundname . "</stage>";
            $uploadMeta .= "<uploadtype>JOBSHEET_UPLOAD</uploadtype>";
            $uploadMeta .= "<sourceFile>";
            $uploadMeta .= "<filepath>" .$jobsheet_file_path."</filepath>";
            $uploadMeta .= "</sourceFile>";
            $uploadMeta .= "<destPath>";
            $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
            $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
            $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
            $uploadMeta .= "<path>".$jobsheet_upload_path."</path>";
            $uploadMeta .= "<username>".$ftp_username."</username>";
            $uploadMeta .= "<password>".$ftp_password."</password>";
            $uploadMeta .= "</destPath>";
            $uploadMeta .= '<WorkflowAPI>
                                <Url value="'.$ret_url.'"/>
                                <parameter key="process" value="upload" type="fixed"/>
                                <parameter key="jobid" value="'.$job_id.'" type="fixed"/>
                                <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                <parameter key="round" value="'.$round.'" type="fixed"/>
                                <parameter key="status" type="boolean"/>
                                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                <parameter key="remarks" type="string"/>
                            </WorkflowAPI>';
            $uploadMeta .= "</uploadMeta>";
            
            $ftpObj 	= 	Storage::createFtpDriver([
                                                            'host'     => $hostserver , 
                                                            'username' => $hostusername ,
                                                            'password' => $hostpassword , // 
                                                            'port'     => '21',
                                                            'timeout'  => '30',
							]);

            $content 	= 	$uploadMeta;
            $filename 	=	$book_id.'_s50_jobsheet_upload_meta.xml';
            //echo \Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/'.$filename;exit;
            Log::useDailyFiles(storage_path().'/Api/s50_jobsheet_upload.log');
            Log::info( $uploadMeta );
     
            $successfileresponse            =       $ftpObj->put(Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/'.$filename, $content);
            
            if( $successfileresponse ){
               
				if( $processType == 'RECEIPT' ){
					$jbrevised 		=	new jobRevisedModel();
					$inputhwerearr	=	array();					
					$inputhwerearr['ROUND']		=	$round;
					$inputhwerearr['JOB_ID']	=	$job_id;
					$isRevised		=	$jbrevised::where( $inputhwerearr )->get();
					if(  count( $isRevised ) > 1 ){
						$processType		=	$api_tbl_input['PROCESS_TYPE']	=	'REVISED_RECEIPT';
					}
					
				}
			
                $getResponse                =       apiFileUpload::insertNew( $api_tbl_input );
                
                $acknow_data                =       array(  
                                                    'JOB_ID'    =>      $job_id ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    'PROCESS_TYPE_DIFF' =>      $processType , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                            );
                // OST TRACKING SYSTEM
                $checkactiveornot   =   ServiceModel\ServiceManagerEnumModel::Active()->where('CODE',Config::get('constants.SERVICE_ENUM.OST'))->first();
                if(Config::get('constants.OST_ACTIVE')    ==  1 && $checkactiveornot != null){
                    if($processType     ==  "RECEIPT" || $processType     ==  Config::get('constants.PROCESS_TYPE') && ($round     ==  Config::get('constants.ROUND_ID')['S5'] || $round     ==  Config::get('constants.ROUND_ID')['S50'])){        
                        $successfileresponse    =       app('App\Http\Controllers\Api\ostController')->ostTrackingStatus($job_id,$round,$processType,'');
                        if(isset($successfileresponse['status']) && $successfileresponse['status'] == 0){
                            $acknow_data['STATUS']    =   "3";
                            $acknow_data['END_TIME']  =   Carbon::now();
                            $acknow_data["REMARKS"]   =   $successfileresponse['errMsg'];
                            $getResponse    =   apiClientAcknowledgement::insertNew( $acknow_data );  
                            $response['status'] =   0;
                            $response['msg']    =   'Failed';
                            $response['errMsg'] =   $successfileresponse['errMsg'];                
                            return response()->json( $response );
                        }
                    }
                }
                //clientAck insert
                apiClientAcknowledgement::insertNew( $acknow_data );
                
                if( $getResponse >= 1  ){                  
                    $response['status']     =       1;
                    $response['msg']        =       'Success';
                    $response['errMsg']     =       'jobsheet upload meta posted successfully';                
                    $response['msgstatus']  =       apiFileUpload::whereid($getResponse)->first();
                }
                
            }
            
        }catch( \Exception $e ){            
             $response['errMsg']    =   $e->getMessage();             
        }        
        return $response;         
    }
    
    public function sendRequestS200JobSheetUpload( $jobId  , $round =   'S200', $processType = 'RECEIPT', $chapterid )
    {        
        $input_arr                  =   array();        
        $time                       =   date( 'Y-m-d H:i:s' );	    
        $response['status']         =   0;
        $response['msg']            =   'Failed';
        $response['errMsg']         =   'Try again after some times';
        $response['msgstatus']      =   '';
        $round                      =   Config::get('constants.ROUND_ID')[$round];
        $round_name                 =   Config::get('constants.ROUND_NAME')[$round];
		
        // try
        //{
			
            $table_name             =       'api_file_upload';            
            $cmn_obj                =       new CommonMethodsController();
            $token_key              =       $cmn_obj->generateRandomString( 16 , $table_name  ); 
            $processType_alter 		=		$processType;
			
            $api_tbl_input          =       array( 
                                                'JOB_ID'        =>      $jobId , 
                                                'ROUND'         =>      $round  ,
                                                'START_TIME'    =>      $time ,
                                                'TOKEN_KEY'     =>      $token_key , 
                                                'STATUS'        =>      1.5 ,
                                                'METADATA_ID'   =>      $chapterid,
                                                'PROCESS_TYPE'  =>      $processType_alter
                                            );
            
            $jobDetails             =       DB::table('job')->where('JOB_ID', $jobId )->first();
            $book_id                =   "";
            if(count($jobDetails)>=1)
            {
                $book_id            =       $api_tbl_input['BOOK_ID']    =  $jobDetails->BOOK_ID;
            }
                    
            $getlocationftp         =       productionLocationModel::doGetLocationname( $jobId ); 
            
             if( empty( $getlocationftp ) )
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            
            if(count($getlocationftp)>=1)
            { 
                //need to dynamicaly bind the production location based on table location
                $hostserver         =   $getlocationftp->FTP_HOST;
                $hostusername       =   $getlocationftp->FTP_USER_NAME;
                $hostpassword       =   \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath           =   $getlocationftp->FTP_PATH;
                
                $root_path              =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                $jbst_path              =   Config::get('constants.UPDATED_JOBSHEET_PATH'); 
                $inp_rep_arr            =   array( 
                                                'BOOK_ID'       =>      $book_id , 
                                                'ROUND_NAME'    =>      $round_name                        
                                            );
                $cmn_obj                =   new CommonMethodsController();
                $raw_path               =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jbst_path );
             
                $zip_info               =   $this->getClientUploadZipCreationInformation( $book_id , $jobId , $round , $chapterid );
                
                $travers_filesname      =   '';
                
                $process_enum           =   array( 'RECEIPT' =>  1 , 'NOTIFICATION' => 2 , 'WRONG_INSTRUCTION' => 4 , 'CORRECTION' => 5  , 'REVISED_RECEIPT' =>  6 );
                $ptype                  =   $process_enum[$processType];
                
                $array_cond_metaextractor   =   array( 'JOB_ID' => $jobId , 'ROUND' => $round ,'METADATA_ID'=>$chapterid, 'PROCESS_TYPE' => $ptype );
				
                $api_meta_extractor     =       DB::table('api_meta_extractor')
                                                        ->where( $array_cond_metaextractor )
                                                        ->orderBy('ID' , 'desc')                                               
                                                        ->first();
				
                if(count($api_meta_extractor)==0){
					
                    $response['status']     =   0;
                    $response['msg']        =   'Filure';
                    $response['errMsg']     =   'Zip name is empty';                
                    $response['msgstatus']  =   "";
                    return response()->json($response);
					
                }
				
                $travers_filesname      =   $api_meta_extractor->ZIP_NAME;  
                $jobsheet_file_path     =   $zip_info['ZIP_OUTPUT_FOLDER_PATH'].$travers_filesname;             
                 
                $ftp_host               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
                $ftp_username           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
                $ftp_password           =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
                $jobsheet_upload_path   =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.path');
                $ftp_type               =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
                $fingerPrint            =       \Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.fingerprint');

                
                $ret_url                =   url('/').'/api/jobsheetUploadCallbackS200';
                
                $uploadMeta = "";            
                $uploadMeta .= "<uploadMeta>";
                $uploadMeta .= "<bookid>" . $book_id . "</bookid>";
                $uploadMeta .= "<stage>" . $round_name . "</stage>";
                $uploadMeta .= "<uploadtype>JOBSHEET_UPLOAD</uploadtype>";
                $uploadMeta .= "<sourceFile>";
                $uploadMeta .= "<filepath>" .$jobsheet_file_path."</filepath>";
                $uploadMeta .= "</sourceFile>";
                $uploadMeta .= "<destPath>";
                $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
                $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
                $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
                $uploadMeta .= "<path>".$jobsheet_upload_path."</path>";
                $uploadMeta .= "<username>".$ftp_username."</username>";
                $uploadMeta .= "<password>".$ftp_password."</password>";
                $uploadMeta .= "</destPath>";
                $uploadMeta .= '<WorkflowAPI>
                                    <Url value="'.$ret_url.'"/>
                                    <parameter key="process" value="upload" type="fixed"/>
                                    <parameter key="jobid" value="'.$jobId.'" type="fixed"/>
                                    <parameter key="chapterid" value="'.$chapterid.'" type="fixed"/>
                                    <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                    <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                    <parameter key="round" value="'.$round.'" type="fixed"/>
                                    <parameter key="status" type="boolean"/>
                                    <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                    <parameter key="remarks" type="string"/>
                                </WorkflowAPI>';
                $uploadMeta .= "</uploadMeta>";
                
                $ftpObj 	= 	Storage::createFtpDriver([
                                                                'host'     => $hostserver , 
                                                                'username' => $hostusername ,
                                                                'password' => $hostpassword , // 
                                                                'port'     => '21',
                                                                'timeout'  => '30',
                                                            ]);

                $content 	= 	$uploadMeta;
                
                $filename 	=	$chapterid.'_'.$round_name.'_jobsheet_upload_meta.xml';

                Log::useDailyFiles(storage_path().'/Api/'.$round_name.'_jobsheet_upload.log');
                Log::info( $uploadMeta );
                
                //echo Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/'.$filename;exit;
                $successfileresponse        =   $ftpObj->put(Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/'.$filename, $content);
                
                if($successfileresponse == true)
                {
					 
				if( $processType == 'REVISED_RECEIPT' ){
					
					$inputhwerearr	=	array();					
					$inputhwerearr['ROUND']		=	$round;
					$inputhwerearr['JOB_ID']	=	$jobId;
					$inputhwerearr['METADATA_ID']	=	$chapterid;
					
					$jbrevised 		=	new jobRevisedModel();
					$isRevised		=	$jbrevised::where( $inputhwerearr )->get();
					
					if(  count( $isRevised ) > 1 ){
						$processType		=	$api_tbl_input['PROCESS_TYPE']	=	'REVISED_RECEIPT';
					}
					
				}
				
                    $getResponse            =   apiFileUpload::insertNew( $api_tbl_input );
                    $acknow_data            =   array(  
                                                    'JOB_ID'    =>      $jobId ,
                                                    'ROUND'     =>      $round ,
                                                    'BOOK_ID'   =>      $book_id  , 
                                                    'METADATA_ID'=> $chapterid,
                                                    'PROCESS_TYPE_DIFF' =>      $processType , 
                                                    'FILE_NAME_IN_LOG'  =>      $travers_filesname , 
                                                    'STATUS'  => '1.5' 
                                                );
                    //clientAck insert
                    apiClientAcknowledgement::insertNew( $acknow_data );
                    
					if( $getResponse >= 1  ){
                        $response['status']     =       1;
                        $response['msg']        =       'Success';
                        $response['errMsg']     =       'jobsheet upload meta posted successfully';                
                        $response['msgstatus']  =       apiFileUpload::whereid($getResponse)->first();
                    }
					
                    return response()->json($response);
                }
                return response()->json($response);
            }
            $result         =   array('result'=>400,'errMsg'=>'Unable to connect to production Server...','msg'=>'Failure');   
            return response()->json($result); 
            
            //}catch( \Exception $e ){            
            //$response['errMsg']    =   $e->getMessage();             
            //}  
            
        return $response;         
    }
    
}