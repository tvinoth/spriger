<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiReferencePdfModel;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Models\jobModel;
use App\Models\apiEsm;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\Api\esmFileNameController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class esmController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_esm_pdf';
    public $apiModel        =       'apiReferencePdfModel';
    public  $common_obj;
    public function __construct()
    {
        
        $this->cmn_obj      =       new CommonMethodsController();
    }
    public function customConstructor( $jobid ){ 
        
        $checkoutObj        =   new jobModel();
     
        $stageDetails       =   $checkoutObj->getJobdetails($jobid);
       
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails;
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['round']          =       '104';
        $metainfo['chapterno']      =       $jbstg_rec->BOOK_ID;
        $metainfo['chaptername']    =       $jbstg_rec->BOOK_ID;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['metaid']         =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       config::get('constants.STAGE_COLLEECTION.ESM_VALIDATION');
        $metainfo['emsval_tags']   =       1;
       
      
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD ); 
        $this->ftpInfo              =       $getlocationftp;
        $this->tokenkey             =       $this->cmn_obj->generateRandomString( 16 , 'api_reference_pdf' , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        return  $metainfo;
        
    }
    
     public function storeResponse( Request $request ){
         
        
        $inputarr           =       json_decode( $request->getContent() );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $inputarr           =       (array)$inputarr;
        $esmfileObj         =       new esmFileNameController();
        
        Log::useDailyFiles(storage_path().'/Api/esm.log');
        Log::info( json_encode( $inputarr ) );
       
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Try again after sometimes';
        
        $rules      =   $this->validationRuleForResponseSignal(); 
        $validator  =   Validator::make( $inputarr , $rules );
       /// $test  = $esmfileObj->startProcess($inputarr['jobid'], '4209');
       
            if ($validator->fails()) {
                
               $response['errMsg']      =       'Required field validation error occured.';
               
            }else{ 
                
                $token_key      =      $inputarr['tokenkey'];
                $sig_obj        =      new apiEsm();
                
               
           
                if($inputarr['process'] == 'esmclient'){
                    $getRec         =      $sig_obj::getApiRequestByTokenKeyByProcess( $token_key );
                }else{
                    $getRec         =      $sig_obj::getApiRequestByTokenKey( $token_key );
                }
                
                if(!empty( $getRec ) ){
                    
                    $this->prepareUpdationValues( $inputarr , $inpArr );
                  
                    foreach($inputarr['FileValidationList'] as $key => $data){
                       
                       if($inputarr['process'] == 'esmclient') {
                           
                           $vidstatus       =   3;
                           
                           if($data->Status == 1 && $data->Remarks == 'Success'){
                               $vidstatus   =   2;
                           }
                           
                            $setArr     =      array( 
                                                'UPDATED_DATE'          => $inpArr['END_TIME'] ,
                                                'VID_GENERATION_STATUS' => $vidstatus,
                                                'VID_REMARKS'           => $data->Remarks,
                                                'CLIENT_ID'             => $data->ClientVideoID 

                                                );
                        
                       }else{
                           $remarks     =   '';
                           if($data->FileSizeValidation != '2'){
                             $remarks  .= 'File Size';
                           }
                           if($data->VideoDurationValidation != '2'){
                            if(!empty($remarks)){
                                $remarks  .= ', ';
                            }
                            $remarks  .= 'Video Duration';
                           }
                           if($data->VideoResolutionValidation != '2'){
                            if(!empty($remarks)){
                                $remarks  .= ', ';
                            }
                            $remarks  .= 'Video Resolution';
                           }
                           
                            if(empty($remarks)){
                               $cusRemarks  =    $data->Remarks;
                            }else{
                                $cusRemarks  =  "Failed in ".$remarks;
                            }
                         
                           $setArr     =      array( 
                                                 'UPDATED_DATE'                 => $inpArr['END_TIME'] , 
                                                 'IS_VALID'                     => $data->Status ,
                                                 'VIDEO_DURATION'               => $data->VideoDuration ,
                                                 'FILE_SIZE'                    => $data->VideoSize ,
                                                 'VIDEO_RESOLUTION'             => $data->VideoAspectRatio ,
                                                 'FILE_SIZE_VALIDATION'         => $data->FileSizeValidation ,
                                                 'VIDEO_DURATION_VALIDATION'    => $data->VideoDurationValidation ,
                                                 'VIDEO_RESOLUTION_VALIDATION'  => $data->VideoResolutionValidation ,
                                                 'VALID_REMARKS'                => $cusRemarks ,
                                                );
                           
                          
                       }    
                        $updateQry  =   DB::table('metadata_esm')
                                        ->where('ID', $data->VideoMetadataID )
                                        ->update( $setArr ); 
                        $metadataId[]   =   $data->VideoMetadataID ;
                        
                    }
                    
                    $rowid              =           $getRec->ID;
                    
                    if($inputarr['process'] == 'esmclient') {
                        $lwr_up_status      =           $sig_obj->updateIfExistVID( $inpArr, $rowid );
                    }else{
                        $lwr_up_status      =           $sig_obj->updateIfExist( $inpArr, $rowid );
                    }
                    
                    /** Call video id generation webservice **/
                    if(!empty($getRec->METADATA_ID) && $inputarr['process'] == 'esmvalidation'){
                        $esmfileObj->startProcess($inputarr['jobid'], $getRec->METADATA_ID);
                    }else{
                        $jobesmdata    =    $sig_obj->getMetaEsmDetailsByJobId($inputarr['jobid']);
                        foreach($jobesmdata as $esmData){
                          $esmfileObj->startProcess($inputarr['jobid'], $esmData->METADATA_ID);
                        }
                    }
                    
                    if( $lwr_up_status ){
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal Received Successfully';
                        
                    }else{
                        $response['errMsg']         =       'Signal update Query got Failed';
                    }

                }else{
                    $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
                }
                
            }
            echo json_encode( $response );
    }
    
    
    
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        ($inputarr['status']   ==  2?'2':'3');
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
    
        
    public function startProcess(Request $request){
        
        $requestData        =       $request->getContent();
       
        Log::useDailyFiles(storage_path().'/Api/reference.log');
        Log::info($requestData);
	
        $inputdata          =   file_get_contents('php://input');

        $jsondecodedata     =   json_decode($inputdata,true);
        
        if(count($jsondecodedata)>=1)
        {
            $jobId            =   $jsondecodedata['jobid'];
            
            $metaId           =   isset($jsondecodedata['metaId'])?$jsondecodedata['metaId']:'';
           
            $response           =   array();
            $watchPath          =   '';
            $wrkflwMapPath      =   new workflowServerMapPathModel();
            $this->customConstructor( $jobId );
            $metainfo           =   $this->metainfo;
          
            $esmDedatils        =   $this->getMetaEsmDetails($jobId, $metaId);
            
            $metainfo['chapter_info_data']  =   $esmDedatils;
           
            $this->metainfo =       $metainfo;
            extract( $metainfo );
           // try{
                $platform       =   '3b2';
                //$path           =   $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                $watchPath      =   '\\172.24.191.59\e\ftp\SP_BOOKS';
                $ftpDefault     =   $this->ftpInfo;
                $jbstgid        =   '1361';
                $content        =   $this->prepareAutoPageMeta( $jbstgid , $platform,null );
                
                $metafileInput['metafilename']      =   $this->getMetafilename();
                $metafileInput['metaContent']       =   $this->cmn_obj->formatXmlString( $content );
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
                $api_tbl_input['STATUS']   =   '1.5';
                $api_tbl_input['START_TIME']   =   date( 'Y-m-d H:i:s' );
                $api_tbl_input['created_at']   =   date( 'Y-m-d H:i:s' );
                if(!empty($metaId)){
                    $api_tbl_input['METADATA_ID']   =   $metaId;
                }
                $this->callWebservice( $api_tbl_input , $response , $metafileInput );

           /* }catch( \Exception $e ){

                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
            }*/
        }else{
            $response['status']     =   0;
            $response['Msg']        =   'failed';
            $response['errMsg']     =   'No data found';
        }
        return response()->json( $response );
    }
    
    
    public function getMetafilename(){
        extract(  $this->metainfo );
        $inp_rep_arr    =       array(  
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_{TKEY}_referencepdf.xml';
        return $this->cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =   Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_REFERENCE_PDF');
        if( !empty(  $path['workingpathCredential'] ) ){    
            $recServer  =   $path['workingpathCredential'];
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =   (object)$cr_data; 
            $this->ftpInfo              =   $metaPostInfo['ftpInfo'];
            if( !empty( $path['detail'] ) ){
                $watchPath              =   $path['detail'];
                $workpath               =   str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath               =   str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                $workpath               =   preg_replace('/[0-9]/', '', $workpath);
                $workpath               =   str_replace('//', '', $workpath);
            }
        }
        return $workpath;
    }
    
    public function callWebservice($api_tbl_input , &$response = array() , $metaFileInput){
        
        $inserid                     =   DB::table('api_esm_validate')->insertGetId( $api_tbl_input );
        $artWebUrl          =     \Config::get('constants.ESM_VALIDATE');
        $response2           =      $this->cmn_obj->RestfulPostcUrlExecution($metaFileInput['metaContent'],$artWebUrl,0,"");
        $response            =      array();
                
        if($response2['0']== 'Success'){
           // $inserid                     =   DB::table('api_esm_validate')->insertGetId( $api_tbl_input );
            $response['status']         =   1;
            $response['msg']            =   'Success';
            $response['errMsg']         =   'Meta Posted Successfully to webservice';
           
        }else{
             $response['status']         =   0;
            $response['msg']            =   'failed';
            $response['errMsg']         =   'web service got failed';
        }
        return $response;
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){
        
        $ftpobj                     =   $metaFileInput['ftpInfo']; 
        $ftpInfo['HOST']            =   $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =   $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =   $ftpobj->FTP_PASSWORD;
        $filename                   =   $metaFileInput['metafilename'];
        $whereToWrite               =   $metaFileInput['watch_folder'];
        $getMetaFormat              =   $this->cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
       
        $errorstr                   =   '';
        $postMetaStatus             =   app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

        if( !$postMetaStatus ){
            $response['errMsg']     =   'File posted to WatchFolder got Failed';
        }

        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $insert_ret                     =   apiReferencePdfModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   1;
                $response['msg']            =   'Success';
                $response['errMsg']         =   'Meta Posted Successfully to Watchfolder';
                return true;
            }else{
                $response['errMsg']         =   'api table Record insertion failed';
            }

        }else{

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $api_tbl_input['END_TIME']      =   date('Y-m-d H:i:s');
            $api_tbl_input['STATUS']        =   3;
            $api_tbl_input['REMARKS']       =   $errorstr;

            $insert_ret                     =   apiReferencePdfModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   0;
                $response['msg']            =   'Failed';
                $response['errMsg']         =   $response['errMsg'];
                return true;
            }else{
                $response['errMsg']         =   'api table Record insertion failed';
            }
        }

       return false;

   }

    public function prepareAutoPageMeta( $jbstageid , $platform = '3b2' , $type = null){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        
        $preparedXml        =       '';  
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );
               
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
       /* $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );*/
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();   
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        
        return $xmlStr;
    }
    
    public function prepareSourceDestFileTags($input_rec, $returns   =   'xml',$typeofdoc){
        
        $figure_arr     =   array();
        $figure_str     =   '';
        $figure         =   '';
        
        if(isset($input_rec['chapter_info_data']) && count($input_rec['chapter_info_data'])>=1){
            if($typeofdoc     ==  "source")
            {
                foreach( $input_rec['chapter_info_data'] as $key => $value ){
                    $replaceslash           =   $this->cmn_obj->backslashPathPrepare($value['filepath'],true);
                    if( $returns == 'xml' ){
                        
                        $figure_str         .=  '<file src="'.$replaceslash.'" metaid="'.$value['MetaId'].'" vid="'.$key.'"/>'.PHP_EOL;
                    }

                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
           
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;    
            if( $returns == 'xml' )
                $figure     =   $figure_str;
        }
        
        return $figure;
    }
    
    public function getMetaEsmDetails($jobId,$metaId = ''){
        if(empty($this->metainfo))
        $this->customConstructor($jobId);
        extract( $this->metainfo );
        $ftpDetail      =   $this->ftpInfo;
        $esmfilePath   =    '//'.$ftpDetail->FTP_HOST.$ftpDetail->FILE_SERVER_PATH.Config::get('constants.EMS_DESTINATION_PATH').'{CID}';
        $esmfilePath   =    str_ireplace('BOOK_ID', $bookid, $esmfilePath);
        
        $esmDetails     =       array();
        
        if(!empty($metaId)){
            $metaDetails   =   DB::table('metadata_esm as esm')->select(DB::raw('esm.*,tm.*'))
                                ->join( 'task_level_metadata as tm' , 'tm.METADATA_ID', '=', 'esm.METADATA_ID')
                                ->where('esm.JOB_ID',$jobId)
                                ->where('esm.METADATA_ID',$metaId)
                                ->where('esm.IS_DELETED',0)
                                ->get();
          
            
        }else{
        $metaDetails   =   DB::table('metadata_esm as esm')->select(DB::raw('esm.*,tm.*'))
                                ->join( 'task_level_metadata as tm' , 'tm.METADATA_ID', '=', 'esm.METADATA_ID')
                                ->where('esm.JOB_ID',$jobId)
                                ->where('esm.IS_DELETED',0)
                                ->get();
        }
        $esmDetails     =   [];
        foreach($metaDetails as $key => $data){
           // $esmfilePath
            $esmfilePath1  = str_ireplace('{CID}', $data->CHAPTER_NO, $esmfilePath);
            $esmDetails[$data->ID]['MetaId'] = $data->METADATA_ID;
            $esmDetails[$data->ID]['filename'] = $data->ORGINAL_FILE_NAME;
            $esmDetails[$data->ID]['clientid']   = $data->CLIENT_ID;
            $esmDetails[$data->ID]['FILE_FORMAT']   = $data->FILE_FORMAT;
            $esmDetails[$data->ID]['filepath'] = $esmfilePath1.'/'.$data->ORGINAL_FILE_NAME;
        }
        
        return $esmDetails;
        
    }
    
}