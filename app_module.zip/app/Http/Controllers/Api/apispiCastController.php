<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiSpicastModel;
use App\Models\jobInfoModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class apispiCastController extends Controller
{  
    public function spicasttoolreponse(Request $request)
    {      
//        $array  =   array(
//            'Spicastdetails'=>
//                array(array('SpiCastId'=>2722,'SNo'=>1,'ChapterName'=>'FM','Words'=>3026,'Pages'=>7,'Characters'=>12369,'Lines'=>290,'ArtPages'=>10,'Blanks'=>50,'TotalPages'=>100),
//            array('SpiCastId'=>2721,'SNo'=>2,'ChapterName'=>'chapter 4x.docx','Words'=>302,'Pages'=>7,'Characters'=>12,'Lines'=>29,'ArtPages'=>5,'Blanks'=>5,'TotalPages'=>50),
//            array('SpiCastId'=>2720,'SNo'=>3,'ChapterName'=>'chapter 5x.docx','Words'=>302,'Pages'=>7,'Characters'=>123,'Lines'=>2,'ArtPages'=>10,'Blanks'=>5,'TotalPages'=>50)),
//            'workflow'=>array('token'=>'tccVGyZHtV','status'=>1,'job_id'=>6271,'round'=>104,'end_time'=>'2018-03-22 11:53:35','remarks'=>array('feedback'=>"Error occured during Image DLL")));
//        $url    =   url('/').'/api/apiSpicastToolresponse';
//        $data   =   json_encode($array);
//        $getToolresponse   =   json_decode($data);
//        print_r($data); exit;
        $getToolresponse    =  json_decode(file_get_contents('php://input'));        //print_r($getToolresponse); exit;
        if(count($getToolresponse)>=1)
        {
            if(count($getToolresponse->workflow)>=1)
            {			
                $request['token']       =   $getToolresponse->workflow->token;
                $request['status'] 	=   $getToolresponse->workflow->status;
                $request['job_id'] 	=   $getToolresponse->workflow->job_id;
                $request['round'] 	=   $getToolresponse->workflow->round;
                $request['end_time']    =   $getToolresponse->workflow->end_time;
                $validation             =   Validator::make($request->all(), [
                                                    'token' 	=> 'required',
                                                    'status' 	=> 'required|numeric',
                                                    'job_id' 	=> 'required',
                                                    'round' 	=> 'required',
                                                    'end_time' 	=> 'required'
                                            ]);
                if ($validation->fails())
                {
                    return response()->json($validation->errors());
                }
                $status 		=   trim($getToolresponse->workflow->status);
                $jobId              =   $request['job_id'];
                if($status  ==  0)
                {
                    //update ce estimation tool response
                    $token              =   trim($getToolresponse->workflow->token);
                    $status 		=   trim($getToolresponse->workflow->status);
                    $endtime 		=   trim($getToolresponse->workflow->end_time);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   '3';
                    $updatedata['RESPONSE_LOG'] =   file_get_contents('php://input');
                    if(isset($getToolresponse->workflow->remarks->text))
                    {
                        $updatedata['REMARKS']  =	trim($getToolresponse->workflow->remarks->text);
                    }
                    $updatemeta         =   apiSpicastModel::doupdate($token,$updatedata);
                    if($updatemeta)
                    {
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'','fileid'=>'');
                        return response()->json($result);
                    }else
                    {
                        $errormetaid    =   "";
                        $result         =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token','fileid'=>$errormetaid.' File id is not matching ');
                        return response()->json($result);
                    }
                }
                //update metainfo table
                $filesread 		=	$getToolresponse->Spicastdetails;
                if(count($filesread)>=1)
                {
                    $errormetaid    =   "";
                    $updatemeta     =	false;
                    $updatemetadata =	[];
                    $jobtimedata    =   [];
                    $romanpage      =   0;
                    $arabicpage     =   0;
                    foreach($filesread as $key=>$jsonvalue)
                    {
                        $metaID         =   trim($jsonvalue->SpiCastId);
//                        $getmetainfo 	=   apiCeestimationModel::checkMetaidexist($metaID);
                        $getchapinfo 	=   taskLevelMetadataModel::where('METADATA_ID',$metaID)->first();
                        if(count($getchapinfo)>=1)
                        {
                            $fmaddfourpages         =   "";
                            //read fm
                            if(in_array(substr(strtolower($getchapinfo->CHAPTER_NO),0,2),Config::get('constants.FRONT_MATTER')))
                            {
                                $fmaddfourpages     =   "success";
                                $romanpage          +=  trim($jsonvalue->TotalPages+4);
                            }
                            else
                            {
                                $arabicpage         +=  trim($jsonvalue->TotalPages);
                            }
                            $updatemetadata     =   array(
                                                        'SPICAST_WORDS'=>trim($jsonvalue->Words),
                                                        'SPICAST_PAGES'=>trim($jsonvalue->Pages),
                                                        'SPICAST_CHARACTERS'=>trim($jsonvalue->Characters),
                                                        'SPICAST_LINES'=>trim($jsonvalue->Lines),
                                                        'SPICAST_ARTPAGES'=>trim($jsonvalue->ArtPages),
                                                        'SPICAST_BLANKS'=>trim($jsonvalue->Blanks),
                                                        'SPICAST_TOTALPAGES'=>trim($jsonvalue->TotalPages),
                                                        'LAST_MOD_DATE'=>Carbon::now()
                                                    );
                            $updatemeta 	=   apiCeestimationModel::updatemetainfo($updatemetadata,$metaID);
                            taskLevelMetadataModel::where('METADATA_ID',$metaID)->update(['QUANTITY'=>trim($jsonvalue->TotalPages)]);
                            unset($updatemetadata);
                        }
                        else
                        {
                                $errormetaid    .=  $metaID.',';
                        }
                    }
                    //update arabic and roman page 
                    $updatejobinfodata  =   ['NO_ARABIC_PAGES'=>$arabicpage,'NO_ROMAN_PAGES'=>$romanpage];
                    $updatejobinfo      =   jobInfoModel::where('JOB_ID',$jobId)->update($updatejobinfodata);
                    
                    $reportData['JOB_ID']       =   $jobId;
                    $reportData['ACTION']       =   '2';
                    $repSuccess                 =   app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData,'job');
                    
                    
                    //update ce estimation tool response
                    $token              =   trim($getToolresponse->workflow->token);
                    $status 		=   trim($getToolresponse->workflow->status);
                    $endtime 		=   trim($getToolresponse->workflow->end_time);
                    $updatedata             =   [];
                    $updatedata['END_TIME'] =   $endtime;
                    $updatedata['STATUS']   =   '2';
                    $updatedata['RESPONSE_LOG'] =   file_get_contents('php://input');
                    if(count($getToolresponse->workflow->remarks)>=1)
                    {
                        $updatedata['REMARKS']  =	trim($getToolresponse->workflow->remarks->feedback);
                    }
                    $errormetaid        =   rtrim($errormetaid,',');
                    $updatemeta         =   apiSpicastModel::doupdate($token,$updatedata);
                    if($updatemeta)
                    {
                        $metaObj           =   new taskLevelMetadataModel();
                        $spicastStageID    =   $metaObj->getspicastStageID($jobId);
                        if(count($spicastStageID)>=1 && !empty($spicastStageID)){
                            $spicastStId       =   $spicastStageID['0']->JOB_STAGE_ID;
                            $roundId           =    $spicastStageID['0']->JOB_ROUND_ID;
                            $time                       = 	date('Y-m-d H:i:s'); 
                            $setArr        =   array( 'CHECK_IN'  => $time , 'STATUS' => '24');
                            $updateQry     =   DB::table('job_stage')
                                    ->where('JOB_STAGE_ID', $spicastStId )
                                    ->update( $setArr );
                            app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobId,$roundId,'update',$spicastStId);
                        }
                        
                        $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'','fileid'=>'');
                        return response()->json($result);
                    }
                    $result 		=   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token','fileid'=>$errormetaid.' File id is not matching ');
                    return response()->json($result);
                }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Given Files are empty try again','token'=>'','fileid'=>'');
            return response()->json($result);
            }
            $result 			=   array('status'=>0,'msg'=>'Error','errMsg'=>'Work flow data is empty','token'=>'','fileid'=>'');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'','fileid'=>'');
        return response()->json($result);
    }
}