<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager; 
use App\Models\jobStage;
use App\Models\apiPdfCompare;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Models\taskLevelArtMetadataModel;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\taskLevelMetadataModel;
use App\Models\apiAutoPage;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\autoPageController;
use App\Models\requiredConstants;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class pdfcompareController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_pdfcompare';
    public $apiModel        =       'apiPdfCompare';
    
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
        
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        
        $ihp_stg        =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_PDFCOMPARE' );
        $epsi_stg       =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_EPSILON_COMPARE' );
        
        
        if( $jbstg_rec->STAGE_ID ==  $ihp_stg )
            $processtype    =       1;
        
        if( $jbstg_rec->STAGE_ID ==  $epsi_stg )
            $processtype    =       2;
        
        $metainfo['processtype']    =       $processtype;
       
        $getlocationftp          	=       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo  =   $metaPostInfo;
        $cmn_obj              =       new CommonMethodsController();
        $tablename  =   $this->tablename;
        $this->tokenkey          =       $cmn_obj->generateRandomString( 16 , $tablename , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        
        $iteration_sfx      =   $jbstg_rec->ITERATION_ID;
        $iteration_sfx      =   ($iteration_sfx > 1 )  ? ($iteration_sfx-1) : $iteration_sfx;
        
        $made_inp           =   array( 'iterationMinusone' => $iteration_sfx );
        $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp ) );
                
        return  $this->metainfo;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess( $jbstgid ){
        
        $re_response 	= 		$response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        $this->customConstructor( $jbstgid );
        
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
     
        try{
            
            $checkoutObj        =   	new checkoutModel();
            $stageDetails       =   	$checkoutObj->getStageInfo($jobstgid);
            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundname          =       $round_arr[$round];
            
            $jbstg_rec          =   	$stageDetails[0];
            $iterationvalu      =   	0;
            $ftpDefault         =   	$this->ftpInfo;
          
            $tskLvlObj          =   	taskLevelMetadataModel::getMetadatadetailsChapter( $metaid );
            $tskLvlObj2         =   	taskLevelMetadataModel::getMetadatadetailsChapterBook( $metaid );
			$prcError           =   	$checkoutObj->getPrcErrorExist($metaid, $round);
			
			if(count($prcError) >=1){
				$iterationvalu   = '3';
			}

            if( count( $tskLvlObj )  ){
                
                $chaptype       =    $tskLvlObj[0]->FM_ARTICLE_BM;

                //fm bm part need to skip do movetonext stage automaticaly
				if( $processtype == 2 )
					$iterationMinusone  =   'final';
                    
				$re_response    =       $this->backupthePdfIfPresent( $ftpDefault , $iterationMinusone );                    
                
                if( $re_response ){                
                    $response['status'] 	=   	1;
                    $response['msg']    	=   	'success';
                    $response['errMsg'] 	=   	'pdf file backup done successfully';
                }
				
				$skipround  	= 		array( 'S300' );
			  
                if( ( $iterationvalu > 1 && ( $chaptype == 2 || !in_array( $roundname , $skipround ) ) ) || $processtype == 2 ){  

                    //IHP Handling condition satisfied  or It should be a epsilon creation

                    $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                    $watchPath      =       $this->getWatchFolderPath( $path );
                    
                    $content        =       $this->prepareAutoStageMeta( $jbstgid );

                    $metafileInput['metafilename']      =       $this->getMetafilename();
                    $metafileInput['metaContent']       =       $content;
                    $metafileInput['watch_folder']      =       $watchPath;
                    $metafileInput['ftpInfo']           =       $ftpDefault;

                    $api_tbl_input                      =       array();

                    $api_tbl_input['METADATA_ID']   =   $metaid;
                    $api_tbl_input['ROUND']         =   $round;
                    $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                    $api_tbl_input['REQUEST_LOG']   =   $content;

                    $pdfcompare     =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_PDFCOMPARE' );

                    if( $stageid == $pdfcompare ){
                        $api_tbl_input['PROCESS_TYPE']      =   1;
                    }else{
                         $api_tbl_input['PROCESS_TYPE']     =   2;
                    }
                  
                    $this->postDataToTool( $api_tbl_input , $response , $metafileInput );

                }else{
                    $stageManagerContObj        =       new stageMangerController();
                    $moveStageResponse  		=       $stageManagerContObj->moveNextStage($jbstg_rec);
                }

            }
			
			if( count( $tskLvlObj2 ) ){
				 
			    $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
				$watchPath      =       $this->getWatchFolderPath( $path );				
				$content        =       $this->prepareAutoStageMeta( $jbstgid );

				$metafileInput['metafilename']      =       $this->getMetafilename();
				$metafileInput['metaContent']       =       $content;
				$metafileInput['watch_folder']      =       $watchPath;
				$metafileInput['ftpInfo']           =       $ftpDefault;
				$api_tbl_input                      =       array();
				$api_tbl_input['METADATA_ID']   	=	    $metaid;
				$api_tbl_input['ROUND']         	=   	$round;
				$api_tbl_input['TOKEN_KEY']     	=   	$this->tokenkey;
				$api_tbl_input['REQUEST_LOG']   	=   	$content;

				$pdfcompare     =   \Config::get( 'constants.STAGE_COLLEECTION.AUTO_PDFCOMPARE' );

				if( $stageid == $pdfcompare ){
					$api_tbl_input['PROCESS_TYPE']      =   1;
				}else{
					 $api_tbl_input['PROCESS_TYPE']     =   2;
				}
			  
				$this->postDataToTool( $api_tbl_input , $response , $metafileInput );
				
			 }
			 
            
        }catch( \Exception $e ){
            
            $response['status'] =   0;
            $response['Msg']    =   'failed';
            $response['errMsg']    =   'Something went wrong, try again after sometimes';
            
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
        }
        
        return json_encode( $response );
        
    }
    
    public function getMetafilename(){
        
        extract(  $this->metainfo );
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $cmn_obj            =        new CommonMethodsController();
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
        $filename           =        $chapterno2.'@'.$bookid.'.xml';

        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PDF_COMPARE');
          
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];

            $cr_data['FTP_HOST']        =       $recServer['host'];
            $cr_data['FTP_USER_NAME']   =       $recServer['username'];
            $cr_data['FTP_PASSWORD']    =       $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
            
                $watchPath          =       $path['detail'];
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                $empdir        =   Session::get('users')['emp_id'];  
                //remove user directory 
                $workpath           =       str_replace(  $empdir , '', $workpath);
                $workpath           =       str_replace('//', '', $workpath);
               
            }
        
        }
        
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

       $cmn_obj                    =       new CommonMethodsController();
       $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
       if( isset( $ftpobj['ftpInfo'] ) )
           $ftpobj= $ftpobj['ftpInfo'];
       
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
       
       //echo '<pre>';
       //echo htmlspecialchars($getMetaFormat);
       //exit;
       
       $errorstr           =            '';
       $postMetaStatus     =            app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
      
       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           $insert_ret                     =       apiPdfCompare::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiPdfCompare::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

        return json_encode( $response );
        exit;
        
   }

    public function prepareAutoStageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid );
        $preparedXml        =       '';    

        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );

                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
   
    public function backupthePdfIfPresent( $ftpObj , $bckupFileSufix ){
        
        $constname          =       'PDF_COMPARE_PATH';
        
        $return_const       =       array();
        $const_obj          =       new requiredConstants();
        $records            =       $const_obj->getRequiredConstants($constname);
        $records_epsi       =       $const_obj->getRequiredConstants( 'PDF_COMPARISON_FILE_PATH' );
        $pdfcomparpath      =       null;
        $response           =       false;
        
        if( count( $records ) && count($records_epsi) ){
            
            $pdfcomparpath      =   	$records->CONSTANT_VALUE;
            $epsipath           =   	$records_epsi->CONSTANT_VALUE;
            
            extract(  $this->metainfo );
            
            $round_arr           =      \Config::get('constants.ROUND_ID');
            $exploded_arr        =      explode( '\\' ,  $epsipath );
            $filename_arr        =      $exploded_arr[count($exploded_arr)-1];
            $filename_ext        =      explode( '.' , $filename_arr );
            $bckupFileSufix      =      trim($bckupFileSufix);
            
            $fileName            =      $filename_ext[0].'_'.$bckupFileSufix.'.'.$filename_ext[1];
            if( isset( $ftpObj['ftpInfo'] ) )
                $ftpObj             =       $ftpObj['ftpInfo'];
            
            $hostserver         =       $ftpObj->FTP_HOST;
            $hostusername       =       $ftpObj->FTP_USER_NAME;
            $hostpassword       =       $ftpObj->FTP_PASSWORD;
            
            $cid                =       preg_replace( '/\D/', '', $chapterno );
            $ckey               =       preg_replace("/[0-9_]/", '', $chapterno);
            
            $crd                =       'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver.'\\';   
            $src_path           =       $defaultCopyPath    =       $pdfcomparpath;
            
            $pagingname         =       $bookid.'_'.$cid.'_'.  ucfirst( strtolower( $ckey ) );
			
            $apc_obj            =       new autoPageController();
			$paging_collect     =       $apc_obj->getPagingFileNameing( $bookid , $chapterno ,  $metaid );
			extract( $paging_collect );  
            $cmn_obj            =       new CommonMethodsController();
            
            $rpl_array          =       array(  
                                                '{BID}' => $bookid , '{CID}' => $cid ,'{CNAME}' => $chapterno , 
                                                '{RID}' => $round_arr[$round] , '{RNAME}' => $round_arr[$round] , 
                                                '{PAGING_FILENAMING}' => $pagingfilnaming
                                            );
            
            $src_path           =       $cmn_obj->arr_key_value_replace( $rpl_array  , $src_path  );
            $dest_path          =       $defaultCopyPath.'COMPARED_PDF_BACKUP\\'.$fileName;
            $dest_path          =       $cmn_obj->arr_key_value_replace( $rpl_array  , $dest_path  );
            
            $FilePath           =       null;
            $ftpObj             =       Storage::createFtpDriver([
                                            'host'     => $hostserver, 
                                            'username' => $hostusername,
                                            'password' => $hostpassword, 
                                            'port'     => '21',
                                            'timeout'  => '30',
                                        ]);
            
           
            $serverDirFiles     =   $ftpObj->allFiles( $src_path );
            
            foreach($serverDirFiles as $value){
                if(pathinfo($value)['extension'] == 'pdf'){
                    $FilePath    =   $value;
                }
            }
            
            if( !empty( $FilePath )){

                $FilePath       =       substr( $FilePath ,  strrpos ( $FilePath , '/' )+1 );   
                $src_path       =       substr( $src_path , 0 ,   strrpos ( $src_path , '\\' )+1  );
                $src_path       =       $src_path.$FilePath;    
                
                $ftpObj         =       new ftpFileHandlerController( $hostserver, $hostusername , $hostpassword );
                $response       =       $ftpObj->ftpSingleFileCopyOrMove(  $crd.$src_path , $crd.$dest_path , false );
                
            }
        
        }
       
        return $response;
        
    }
       
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){

       if( isset( $optional_param_json ) ){
           if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
               $addionalParam      =       json_decode( $optional_param_json );
               
               if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                   $autopageInput      =       (array)$addionalParam; 
                   $exitsing_meta      =        $this->metainfo;

                   foreach( $addionalParam as $key => $value ){          
                        $this->metainfo[ $key ]     = $value;                              
                   }

               }
           }
       }

   }     
    
   
    public function getArtMetaDataTags( $jbstgid ){
        
        $xmlStr     =   '<ArtMetaData>';
       
            extract( $this->metainfo );            
            $getartfigure       =       DB::table( 'task_level_art_metadata' )
                                            ->whereIn( 'METADATA_ID' , array( $metaid )  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();   

            $xmlStr         .=          app('App\Http\Controllers\artProcess\artProcessController')->prepareFigureTags( $getartfigure );
            $xmlStr        .=          '</ArtMetaData>';
         
        return $xmlStr;
        
    }
      
    public function replaceRequireKeysToValues( $xmlStr ){
        
        $cmn_obj             =       new CommonMethodsController();
        $inp_rep_arr         =      $this->getRequiredReplacables();
        $xmlStr     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlStr );
        return $xmlStr;
    }
    
    
}
