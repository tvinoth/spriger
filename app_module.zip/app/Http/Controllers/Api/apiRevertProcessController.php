<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiFileUpload;
use App\Models\apiFtpUpload;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\productionLocationModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\workflowServerMapPathModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\Api\autostageController;
use Session;
use Illuminate\Support\Facades\Storage;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Illuminate\Support\Facades\Crypt;
use App\Http\Controllers\custom\errorController;

class apiRevertProcessController extends Controller
{
    
    public function revertChapters( Request $request ){
        
		ini_set( 'max_execution_time' , 0 );
		
        $metaid         =   $request->input( 'metaid' );
        $roundfrom      =   $request->input( 'roundfrom' );
        $roundto        =   $request->input( 'roundto' );
        
        $response       =   array();
        
        try{
            
            #clear the apiTable entries
            #clear the s300 round entries
            #update the  s200 jobstage status
            
            $metaid    =    explode( ','  , $metaid );
            
            foreach( $metaid as $key => $value ){
                
                $step1_query          =   '';//$this->cleartheApitableEntriesofS300( $value );
                $step2_query          =   $this->clearTheJobRoundJobStage( $value , $roundfrom  );
                $response['details'][$value]['step1']  =  $step1_query;  
                $response['details'][$value]['step2']  =  $step2_query;  
                
                if( $step2_query ){
                    //$response['details'][$value]['step3']  =    $this->updateToS200WorkflowStage( $metaid );
                }
                
            }
            
            
        } catch (\Exception $ex) {
            
            $response       =   array(
                'status' => 0 , 
                'msg' => 'failed' , 
                'errMsg' => $ex->getTraceAsString()
            );
         
        }
        
        return response()->json( $response );
    }
    
    
    public function cleartheApitableEntriesofS300( $metaid ){
        
        $roundfrom      =   '118';
        $roundto        =   '116';
        
        $runstatus      =   ' Query Exec : cleartheApitableEntriesofS300'.PHP_EOL.PHP_EOL;
        
        $query1     =   "delete from api_client_acknowledgement where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query2     =   "update api_client_acknowledgement set status = '1.5' ,end_time = NULL where metadata_id = '$metaid' and round = '$roundto' and process_type_diff = 5 ORDER BY ID DESC limit 1";

        $query3     =   "delete from api_ftp_upload where metadata_id = '$metaid' and round = '$roundfrom'";  

        $query4     =   "delete from api_file_upload where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query5     =   "delete from api_meta_extractor where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query6     =   "delete from api_correction_download where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query7     =   "delete from api_download where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query8     =   "delete from api_eproof_packaging  where metadata_id = '$metaid' and round = '$roundfrom'"; 

        $query9     =   "delete from api_production_file_transfer where metadata_id = '$metaid' and round = '$roundfrom'"; 
	
        $querystr           =   $query1.PHP_EOL;
        $querystr       .=   $query2.PHP_EOL;
        $querystr       .=   $query3.PHP_EOL;
        $querystr       .=   $query4.PHP_EOL;
        $querystr       .=   $query5.PHP_EOL;
        $querystr       .=   $query6.PHP_EOL;
        $querystr       .=   $query7.PHP_EOL;
        $querystr       .=   $query8.PHP_EOL;
        $querystr       .=   $query9.PHP_EOL;
        
	$runstatus      .=   ' query1 : '.DB::delete( $query1 ).PHP_EOL;	
	$runstatus      .=   ' query2 : '.DB::update( $query2 ).PHP_EOL.PHP_EOL;	
	$runstatus      .=   ' query3 : '.@DB::delete( $query3 ).PHP_EOL;	
	$runstatus      .=   ' query4 : '.DB::delete( $query4 ).PHP_EOL;	
	$runstatus      .=   ' query5 : '.DB::delete( $query5 ).PHP_EOL;	
	$runstatus      .=   ' query6 : '.DB::delete( $query6 ).PHP_EOL;	
	$runstatus      .=   ' query7 : '.DB::delete( $query7 ).PHP_EOL;	
	$runstatus      .=   ' query8 : '.DB::delete( $query8 ).PHP_EOL;	
	$runstatus      .=   ' query9 : '.DB::delete( $query9 ).PHP_EOL;	
	
        
        Log::useDailyFiles( storage_path().'/Api/Revertion_api_query.log' );
        
        Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
        Log::info( $querystr );
        Log::info( str_repeat( '------' , 50 ) .PHP_EOL );
        Log::info( $runstatus );
        Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
        sleep( 10 );
        
        return $runstatus;
        
    }
    
    
    public function clearTheJobRoundJobStage( $metaid , $round = 118 ){
        
        $jobroundTable        =      "select JOB_ROUND_ID from job_round where METADATA_ID = '$metaid'  and ROUND_ID = '$round'";
        
        $jobroundObj          =      DB::select( $jobroundTable );
        $jbroundstrin         =      array();
        $runstatus            =      '';
        $querystr             =      '';
        $returnMeta           =      array();
        
        if( count( $jobroundObj ) ){
            
            $jobroundObj        =   $jobroundObj[0];
            
            foreach( $jobroundObj as $key => $value_roundid ){
                $jbroundstrin[] = $value_roundid;
            }
            
            $stringround        =   implode( ',' , $jbroundstrin );
            
            $jobstage_id_obj    =   "select JOB_STAGE_ID from job_stage where job_round_id in ( $stringround )";
            $stageentry     =   DB::select( $jobstage_id_obj );
            
            if( count( $stageentry )){
                
                $stageentry =   $stageentry[0];
                
                foreach($stageentry as $key => $valuestgid ){
                    $jsbstgid_ar[]  =   $valuestgid;
                }
                
                $jbstgidstr     =   implode( ',' , $jsbstgid_ar );
                DB::delete( "delete from job_resource where job_stage_id in( $jbstgidstr )" );
                DB::delete( "delete from job_work_log where job_stage_id in( $jbstgidstr )" );
                
                
            }
            #jobstage clear 
            $_query1        =       "delete from job_stage where job_round_id in ( $stringround )";
            
            $query1status   =       @DB::delete( $_query1 );
            $runstatus      .=      ' _query1 : '.$query1status.PHP_EOL;	
            
            //if( $query1status ){
                $jbroundstrin_str       =   implode( ',' , $jbroundstrin );
                $_query2        =       "delete from job_round where job_round_id in ($jbroundstrin_str)";
                $query2status   =       @DB::delete( $_query2 );
                $runstatus      .=      ' _query2 : '.$query2status.PHP_EOL;	
             
            //}
            
            $querystr            =   $_query1.PHP_EOL;
            $querystr           .=   $_query2.PHP_EOL;
           
            
            Log::useDailyFiles( storage_path().'/Api/Revertion_production_query.log' );
        
            Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
            Log::info( $querystr );
            Log::info( str_repeat( '------' , 50 ) .PHP_EOL );
            Log::info( $runstatus );
            Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
            sleep( 10 );
        
            return true;
        }
        
        return false;
        
    }
    
    public function updateToS200WorkflowStage( $metaid , $round = 118 ){
        
        return true;
        $jobroundTable        =      "select JOB_ROUND_ID from job_round where METADATA_ID = '$metaid'  and ROUND_ID = '$round'";
        
        $jobroundObj          =      DB::select( $jobroundTable );
        $jbroundstrin         =      array();
        $runstatus            =      '';
        $querystr             =      '';
        $returnMeta           =      array();
        
        
        if( count( $jobroundObj ) == 0 ){
            
        }
            
        
    }
    
}