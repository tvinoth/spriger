<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiLowRes;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelMetadataModel;
use App\Models\checkoutModel;
use App\Models\projectModel;
use App\Models\artCategoryLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\dynamicConstantController;
use App\Http\Controllers\artProcess\artProcessController;
use App\Http\Controllers\Api\autostageController;
use App\Models\productionLocationModel;
use App\Models\bookinfoModel;
use App\Models\apsProductionFilePathValidationModel;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\custom\errorController;
use App\Models\jobModel;
use Illuminate\Support\Facades\Crypt;
use DOMDocument;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use File;
use Config;
use Storage;

class lowResController extends Controller
{    

    public $tablename       =       'api_low_res';
    public $apiModel        =       'apiLowRes';


    public function __construct() {
        parent::__construct();       
    }
    
    public function storeResponse( Request $request ){
       
        $inputarr           =       json_decode( $request->getContent() );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $inputarr           =       (array)$inputarr;
       
        Log::useDailyFiles(storage_path().'/Api/lowres_response.log');
        Log::info( json_encode( $inputarr ) );
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Try again after sometimes';
        
        $rules      =   $this->validationRuleForResponseSignal(); 
        $validator                  =       Validator::make( $inputarr , $rules );
      
            if ($validator->fails()) {
                
               $response['errMsg']      =       'Required field validation error occured.';
               
            }else{ 
                
                $token_key      =      $inputarr['tokenkey'];
               
                
                $sig_obj        =      new apiLowRes();
                $getRec         =      apiLowRes::getApiRequestByTokenKey( $token_key );
                 
                if(!empty( $getRec )){
                    
                    $this->prepareUpdationValues( $inputarr , $inpArr );
                    
                    $rowid              =           $getRec->ID;
                    $lwr_up_status      =           $sig_obj->updateIfExist( $inpArr, $rowid );
                    
                    if( $lwr_up_status ){
                        
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal Received Successfully';
                        
                    }else{
                        
                        $response['errMsg']         =       'Signal update Query got Failed';
                        
                    }

                }else{
                    $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
                }
                
            }
            echo json_encode( $response );
    }
	
    public function getRecipientEmailID( $metaid , $round  ){
        
        $inputarr['metaid']     =   $metaid;
        $inputarr['round']     =   $round;
        
        if(count($inputarr)>=1){ 
            
            $chapterxmlpath     =   $this->getChapterXmlPath(); 
            $metadatainfo       =   $this->getrecordsmetadata($inputarr['metaid'],$inputarr['round'],$chapterxmlpath);
			Log::useDailyFiles( storage_path().'/Api/receipientEmailUpdate.log' );
			Log::info( json_encode( $metadatainfo  ) );
			
            $checkmsg           =   array_search( 'Success' , $metadatainfo);
            
            if(!empty($checkmsg) && isset($metadatainfo['Emailid']) && $metadatainfo['Emailid']     !=  ''){
            
				if( is_array( $metadatainfo['Emailid'] ) ){
					$metadatainfo['Emailid']	=	$metadatainfo['Emailid'][0];
				}
				
                $updatedata     =   ['EPROOFING_RECIPIENT'=>$metadatainfo['Emailid']];
				$updatemsg      =   taskLevelMetadataModel::where(['METADATA_ID'=>$inputarr['metaid']])->update( $updatedata );
                
                if( $updatemsg ){				
				
                    $response  = array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Successfully updated' );					
					Log::info( json_encode( $response ) );
		
                    return ( $response );
                }
                
            }
            
        }
        
        $response  = array( 'status' => 0 , 'msg' => 'failed' , 'errMsg' => 'Successfully updated' );
		
		//Log::useDailyFiles( storage_path().'/Api/receipientEmailUpdate.log' );
		//Log::info( json_encode( $metadatainfo  ) );
		Log::info( json_encode( $response ) );
		
        return ( $response );
        
    }
    
    public function getChapterXmlPath(){
        return Config::get('constants.PACKAGE_PATH.XMLFILE_S600');
    }
    
    public function getrecordsmetadata($metadataID,$roundID,$chapterxmlpath)
    {
        $getroundname       =   Config::get('constants.ROUND_NAME.'.$roundID);
        $validatemetaid     =   taskLevelMetadataModel::where('METADATA_ID',$metadataID)->first();
        if(count($validatemetaid)   ==  0)
        {
            $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>'Invalid metadata ID');
            return $result;
        }
        $cmn_obj            =   new CommonMethodsController();
        $jobId              =   (count($validatemetaid)>=1?$validatemetaid->JOB_ID:"");
        $chapterno          =   (count($validatemetaid)>=1?$validatemetaid->CHAPTER_NO:"");
        $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
        $bookdata           =   jobModel::getjobInfodetails($jobId);
        $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
        if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($validatemetaid)>=1)
        {
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            // Do the FTP connection
            $ftpObj             =   $cmn_obj->doLaravelftpconnection($getlocationftp);
            $ftp_root_dir       =   $chapterxmlpath;
            
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chapterno ,$metadataID ); 
            extract( $paging_collect );
            
            $inp_rep_arr              =   array(  
                                            '{BID}'     =>      $bookid ,                 
                                            '{RNAME}'   =>      \Config::get('constants.ROUND_NAME.'.$roundID ),
                                            '{RID}'   =>      \Config::get('constants.ROUND_NAME.'.$roundID ),
                                            '{CID}'     =>      $chapterno ,
                                            '{PAGING_FILENAMING}'   =>  $pagingfilnaming , 
                                            '{CNO}'		=>       preg_replace( '/\D/', '', $chapterno )
                                        );
            
            $open_path              =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $ftp_root_dir );
            $getchapterpaths        =   [];
            $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver;   
            $jobsheetlocationpath   =   $crd.'/'.$open_path;
            
            $checkchpxmlexistornot  =   $ftpObj->has($open_path);
            if(empty($checkchpxmlexistornot))
            {
                $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>'Chapter xml not found');
                return  $result;
            }
            
            $result                 =   array('status'=>0,'msg'=>'failed','Emailid'=>'');
            
            $metadataXml            =   file_get_contents( $jobsheetlocationpath );
            $xml                    =   simplexml_load_string(  $metadataXml , 'SimpleXMLElement' , LIBXML_NOCDATA );
            $metadataDetails        =   json_decode( json_encode((array)$xml ), TRUE );
			
			if( isset( $metadataDetails['ChapterHeader']['AuthorGroup']['Author'] ) ){
				
				$getauthorcount         =   count($metadataDetails['ChapterHeader']['AuthorGroup']['Author']);
				if(count($getauthorcount)>=1)
				{
					$authorinfo         =   $metadataDetails['ChapterHeader']['AuthorGroup']['Author'];
					
					foreach($authorinfo as $key => $authordata ){
						
						// check corresponding erecipient email id
						if(isset($authorinfo[$key]['@attributes']['CorrespondingAffiliationID'])){
							$result     =   array('status'=>1,'msg'=>'Success','Emailid' => $authorinfo[$key]['Contact']['Email']);
						}else if( isset(  $authordata['Email'] ) ){
							$result     =   array('status'=>1,'msg'=>'Success','Emailid' =>  $authordata['Email'] );
						}
						
					}
				}
				
			}
            return $result;
        }
    }
    
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        $rules['metaid']            =       'required';
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        //$output['REMARKS']          =        $inputarr['remarks'];
        $output['REMARKS']          =        json_encode( $inputarr['Artwork'] );
        $output['RESPONSE_LOG']     =        json_encode( $inputarr['Artwork'] );
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function lowresRequiredValidation( $metaid  , $round ){
        
        //create low res folder
        //validate lowres required 
        //create lowres
		
		
			$bgExe              =       "select *from task_level_art_metadata where METADATA_ID = $metaid";
			$getRec             =   DB::select( $bgExe );
			if(!empty($getRec)){
				return true;
			}else{
				return false;
			}
			
        
            $s200_round                 =   \Config::get('constants.ROUND_ID.S200');
            $low_res_dest_path          =   \Config::get('dynamicConstant.PACKAGE_PATH.LOWRESIMAGEFOLDER');
            $roundArray                 =   \Config::get('constants.ROUND_NAME');
            $roundName                  =   $roundArray[$round];
          
            if($round == $s200_round){
                $low_res_dest_path          =   \Config::get('constants.LOWRESIMAGEFOLDER');
				
            }
            $tsklMeta       =       new taskLevelMetadataModel();
            $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
            
            $metadata       =       $meta_info->toArray();
            $metadata       =       $metadata[0];

            $jobid          =       $insertData['JOB_ID']  =       ( $metadata['JOB_ID'] );
            $bookInfo       =       jobModel::getJobdetails( $jobid );
            $chapterno      =       $metadata['CHAPTER_NO'];
            $cmn_obj        =       new CommonMethodsController();
            
            $inp_rep_arr    =       array( '{CID}' => $chapterno  , '{BID}' =>  $bookInfo->BOOK_ID,'{RNAME}' =>$roundName );
            $inputpathPdf   =       $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $low_res_dest_path )  , false );
           
            $getlocationftp         =       productionLocationModel::doGetLocationname( $jobid );

            if( empty( $getlocationftp ) )            
               $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();

            $host                   =       $getlocationftp->FTP_HOST.'/';
            $ftp_path               =       $getlocationftp->FTP_PATH;
            $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
            $metaPostInfo['ftpInfo']=       $getlocationftp;

            $hostserver             =       $getlocationftp->FTP_HOST;
            $hostusername           =       $getlocationftp->FTP_USER_NAME;
            $hostpassword           =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath               =       $getlocationftp->FTP_PATH;
            $hostuserfieserver      =       $getlocationftp->FILE_SERVER_USER_NAME;
            $hostpasswordfieserver  =       $getlocationftp->FILE_SERVER_PASSWORD;

            // Do the FTP connection
            
            $ftpObj             =           Storage::createFtpDriver([
                                                'host'     => $hostserver, 
                                                'username' => $hostusername,
                                                'password' => $hostpassword, // 
                                                'port'     => '21',
                                                'timeout'  => '30',
                                            ]); 

            
            //$file_ob              =           $ftpObj->get( $_file_path ); create lowres folder
            
            $getbookinfo            =           taskLevelMetadataModel::getbookChapteranduserinfo( $jobid , $metaid );
                       
            $wheredata              =           [ 'ROUND_ID' => $round , 'FILE_PATH_TYPE' => 'jobsheet' ];
            
            $getjobsheetpath        =           apsProductionFilePathValidationModel::Active()->where($wheredata)->first();
          
            //check jobsheet and lowres pdf file
            $lowresfieldisavailornot =       $this->doCheckLowResrequiredornot( $getjobsheetpath, $getbookinfo , $getlocationftp );
          
            if(!empty($lowresfieldisavailornot) && $lowresfieldisavailornot ){
                
                return true;
                
            }
            
        return false;
        
    }
    
    public function triggerLowres( Request $request ){
        
        $metaid = $request->input( 'metaid' );
        $round  = $request->input( 'round' );
        //$this->ownConstruction();
        return $this->lowResCreationBgProcessInitialize( $metaid , $round );
        
    }
    
     public function startProcess( $jobStageId, $others= array() ){
		 
		try{
			
			$response       			=       array();
			$checkoutObj                =       new checkoutModel();
			$stageDetails               =       $checkoutObj->getStageInfo( $jobStageId );
			$stageDetailsObj            =       $stageDetails[0]; 
		   
			$round   					= 		$stageDetailsObj->ROUND_ID;
			$metaid  					= 		$stageDetailsObj->METADATA_ID;
		  
			$this->lowResCreationBgProcessInitialize( $metaid , $round , $stageDetailsObj  , $response );
			
			
		}catch( \Exception $e ){
            
           $response['status']     =       0;
           $response['Msg']        =       'failed';
           $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
           $err_handle     =       new errorController();
           $err_handle->handleApplicationErrors( $e );
     
        }
		
		return json_encode( $response );
		
    }
    
    public function lowrescreation(){
       
        $res    =   $this->startProcess( '14934' );
    }
    
    public function lowResCreationBgProcessInitialize( $metaid , $round, $stageDetails= array() , &$response = array() ){
       
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Meta file post got failed';
        
        $apiTableData               =       array();
        $dataToPost                 =       array();
	
        $lowResstatus       =       $this->lowresRequiredValidation( $metaid  , $round  );
       
        if( $lowResstatus ){
            
            $tlam           =       new taskLevelArtMetadataModel();
            $art_coll       =       $tlam->getArtChapterwisefigureInfo( $metaid );
            $artMetaid      =       $art_coll->pluck( 'ART_METADATA_ID' )->toArray();
			
            if( empty( $artMetaid ) ){
                $response['errMsg']     =   $response['errMsg'].' , There is no art to proceed this activity ';
                return response()->json( $response );
            }
			
            $artMetaid      =       implode( ',' ,  $artMetaid );

            $input_arr['artMetaidCollect']     =       $artMetaid;
            $input_arr['round']                =       $round;

            try{
                
                if(!empty($stageDetails )){
                    $returnResponse                  =       $this->prepareLowResMetaContentByStage( $input_arr  , $apiTableData , $dataToPost , $stageDetails );
                }else{
                    $returnResponse                  =       $this->prepareLowResMetaContent( $input_arr  , $apiTableData , $dataToPost );
                }
				
				
                if( !empty( $returnResponse ) ){
                    
                    $this->postDataToTool( $dataToPost  , $apiTableData  , $response , $returnResponse );
                    
                }     
                
            }catch( \Exception $e ){
                
                $response['errMsg']     =       $e->getMessage();
                
            }

        }else{
            
            $autoStageObj       =   new autostageController();
            $response           =   $autoStageObj->stageCompletionProcess($metaid,$round);
            $response           =   array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Process moved  Successfully' );    
	
            
        }
		
        //return json_encode( $response );
        
        
    }
   
    public function prepareLowResMetaContent( $input , &$apitable , &$output ){
       
        extract( $input );
        $artMetas      =       explode( ',' ,  $artMetaidCollect );
       
        $cmn_obj       =       new CommonMethodsController();
        $time          =       date( 'Y-m-d H:i:s' );
        $token         =       $cmn_obj->generateRandomString( 16 , 'api_low_res' , 'TOKEN_KEY' );
        $metaPostInfo  =       array(); 
        $tlam          =       new taskLevelArtMetadataModel();
        $tlm           =       new taskLevelMetadataModel();
       
        try{
            
        $getartfigure       =       taskLevelArtMetadataModel::getArtpdfcreationfigureInfo( $artMetas );
        
        if(!$getartfigure->count())  {
            return false;
        }
        
        $metaid             =       ( $getartfigure[0]->METADATA_ID );
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        
        $apitable           =       array( 
                                        'METADATA_ID'         =>      $metaid , 
                                        'ROUND'               =>      $round  ,   
                                        'START_TIME'          =>      $time   ,
                                        'PROCESS_TYPE'        =>      1       ,
                                        'TOKEN_KEY'           =>      $token
                                    );
       
        
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        if(empty( $jobinfo )) { 
            return false;
        }
        
        $job_id             =       $jobinfo[0];
        
        if(empty( $chapterlist )){  
            return false;
        }
        
        $chapter_name            =       $chapterlist[0];
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo2                =       $bi_obj->getBookinfodetails( $job_id );
		
        $bookinfo                =       $bookinfo2->pluck('BOOK_ID')->toArray(); 
		
        if(empty( $bookinfo )){  
            return false;
        }
        
        $book_id                 =       $bookinfo[0];
        $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $host                   =       $getlocationftp->FTP_HOST.'/';
        $ftp_path               =       $getlocationftp->FTP_PATH;
        $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
        $metaPostInfo['ftpInfo']=       $getlocationftp;
        
        $artQcPath              =       $file_ser_path.\Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
		
        $inp_rep_arr            =       array( 
                                            '{RID}'         =>      'S200'   , 
                                        );

        $artQcPath              =       $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artQcPath )  , true );
		
        $artPreProPath          =       $file_ser_path.\Config::get('serverconstants.ART_PREPROCESSING_PATH');
            $chpPath            	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE');
        $destPath               =       \Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.LOWRESIMAGEFOLDER');
        
        $roundname              =       $round_arr[$round];
        if($roundname == 'S200' && $bookinfo2['0']->APPLICATION == 'InDesign'){
          $chpPath            	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE_S200');  
        }
        
        $chapterno2         	=       preg_replace( '/\D/', '', $chapter_name );
		
        $chpNameArr         =       explode( '_' , $chapter_name );
        
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
        extract( $paging_collect );
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname   ,
                                            '{BID}'         =>      $book_id ,   '{RID}'         =>      $roundname   ,      
                                            '{CID}'         =>      $chapter_name , '{CNO}' => $chapterno2 , 
                                            '{PAGING_FILENAMING}'  => $pagingfilnaming
                                        );

        $chpPath                    =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$chpPath )  , true );
        $destPath                   =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$destPath )  , true );
        $artQcPath                  =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $artQcPath )  , true );
        $artPreProPath              =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artPreProPath )  , true );
       
        $chpxmlname         =       $pagingfilnaming.'.xml';
        
        $getartfigure       =       DB::table( 'task_level_art_metadata' )->whereIn( 'ART_METADATA_ID' , $artMetas  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();  
        
        $var_arr            =	    get_defined_vars();
        
        $artProcessCont     =       new artProcessController();
        $upload_meta        =       $artProcessCont->lowResCreationMetaFilePreparation( $var_arr );
        
        $metaPostInfo['watch_folder']         =      \Config::get('constants.PRODUCTION_TOOLS_SETUP.LOWRES_WATCH_FOLDER');
        $metaPostInfo['metaContent']          =      $upload_meta;
        $metaPostInfo['metafilename']         =      $book_id.'_'.$chapter_name.'.xml';
        
        }catch( \Exception $e ){            
          
           $response        =       array( $e->getMessage() );
           return response()->json($response);
           
        }
        
        return $metaPostInfo;
        
    }
    
    
      public function prepareLowResMetaContentByStage( $input , &$apitable , &$output, $stageDetails ){
       
        extract( $input );
        $artMetas      =       explode( ',' ,  $artMetaidCollect );
       
        $cmn_obj       =       new CommonMethodsController();
        $time          =       date( 'Y-m-d H:i:s' );
        $token         =       $cmn_obj->generateRandomString( 16 , 'api_low_res' , 'TOKEN_KEY' );
        $metaPostInfo  =       array(); 
        $tlam          =       new taskLevelArtMetadataModel();
        $tlm           =       new taskLevelMetadataModel();
       
        try{
            
        $getartfigure       =       taskLevelArtMetadataModel::getArtpdfcreationfigureInfo( $artMetas );
        
        if(!$getartfigure->count())  {
            return false;
        }
        
        $metaid             =       ( $getartfigure[0]->METADATA_ID );
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        
        $apitable           =       array( 
                                        'METADATA_ID'         =>      $metaid , 
                                        'ROUND'               =>      $round  ,   
                                        'START_TIME'          =>      $time   ,
                                        'PROCESS_TYPE'        =>      1       ,
                                        'TOKEN_KEY'           =>      $token
                                    );
       
        
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        
        if(empty( $jobinfo )) { 
            return false;
        }
        
        $job_id             =       $jobinfo[0];
        
        if(empty( $chapterlist )){  
            return false;
        }
        
        $chapter_name            =       $chapterlist[0];
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo )){  
            return false;
        }
        
        $book_id                 =       $bookinfo[0];
        $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $host                   =       $getlocationftp->FTP_HOST.'/';
        $ftp_path               =       $getlocationftp->FTP_PATH;
        $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
        $metaPostInfo['ftpInfo']=       $getlocationftp;
        
        $artQcPath              =       $file_ser_path.\Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
        $round_arr              =       \Config::get('constants.ROUND_NAME');
        
        $inp_rep_arr            =       array( 
                                            '{RID}'         =>      $round_arr[$round] , 
                                        );

        $artQcPath              =       $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artQcPath )  , true );
		
        $artPreProPath          =       $file_ser_path.\Config::get('serverconstants.ART_PREPROCESSING_PATH');
		$chpPath            	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE');
        $destPath               =       \Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.LOWRESIMAGEFOLDER');
       
        $roundname              =       $round_arr[$round];
		
        if($roundname == 'S200'){
          $chpPath            	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE_S200');  
        }
		
        if($roundname == 'S300'){
            $chpPath        	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE_S300'); 
            $destPath       	=       \Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.LOWRESIMAGEFOLDER_ROUND');
        }
        
        if($roundname == 'S600'){
            $chpPath        	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE_S600'); 
            $destPath       	=       \Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.LOWRESIMAGEFOLDER_ROUND');
        }
        
        if($roundname == 'S650'){
            $chpPath        	=   	\Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.XMLFILE_S650'); 
            $destPath       	=       \Config::get('constants.FILE_SERVER_ROOT_DIR').\Config::get('constants.PACKAGE_PATH.LOWRESIMAGEFOLDER_ROUND');
        }
		
        $chapterno2         =       preg_replace( '/\D/', '', $chapter_name );
		$chpNameArr         =       explode( '_' , $chapter_name );
        
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $chapter_name , $metaid ); 
        extract( $paging_collect );
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname   ,
                                            '{BID}'         =>      $book_id ,   '{RID}'         =>      $roundname   ,      
                                            '{CID}'         =>      $chapter_name , '{CNO}' => $chapterno2 , 
                                            '{PAGING_FILENAMING}'  => $pagingfilnaming
                                        );

        $chpPath                    =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$chpPath )  , true );
        $destPath                   =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$destPath )  , true );
        $artQcPath                  =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $artQcPath )  , true );
        $artPreProPath              =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artPreProPath )  , true );
       
        $chpxmlname         =       $pagingfilnaming.'.xml';
        
        $getartfigure       =       DB::table( 'task_level_art_metadata' )->whereIn( 'ART_METADATA_ID' , $artMetas  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();  
        
        $var_arr            =	    get_defined_vars();
       
        $artProcessCont     =       new artProcessController();
        $upload_meta        =       $artProcessCont->lowResCreationMetaFilePreparationByStage( $var_arr );
        
        $metaPostInfo['watch_folder']         =      \Config::get('constants.PRODUCTION_TOOLS_SETUP.LOWRES_WATCH_FOLDER');
        $metaPostInfo['metaContent']          =      $upload_meta;
        $metaPostInfo['metafilename']         =      $book_id.'_'.$chapter_name.'.xml';
  
        }catch( \Exception $e ){            
          
           $response        =       array( $e->getMessage() );
           return response()->json($response);
           
        }
        
        return $metaPostInfo;
        
    }
    
    public function postDataToTool( $data , $api_tbl_input , &$response = array() , $metaFileInput ){
        
        $cmn_obj                    =       new CommonMethodsController();
        $ftpobj                     =       $metaFileInput['ftpInfo']; 
        $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =       \Crypt::decryptString($ftpobj->FTP_PASSWORD);
        
        $filename                   =       $metaFileInput['metafilename'];
        $whereToWrite               =       $metaFileInput['watch_folder'];
        $getMetaFormat              =       $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
      
		//echo '<pre>';
		//echo htmlspecialchars( $getMetaFormat );
		//exit;

        ini_set( 'max_execution_time' , 0);
        $autoStgCont                =       new autostageController();
        $postMetaStatus             =       $autoStgCont->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite );
            
        if( !$postMetaStatus ){
            $response['errMsg']     =      'File posted to WatchFolder got Failed';
        }
            
        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['updated_at']    =       date('Y-m-d H:i:s');
            $api_tbl_input['PROCESS_TYPE']  =       1;
            $api_tbl_input['STATUS']        =       1.5;
            $api_tbl_input['REQUEST_LOG']   =       $getMetaFormat;
            
            $insert_ret                     =       apiLowRes::insertNew( $api_tbl_input );
            
            if( $insert_ret ){
                $response['status']             =       1;
                $response['msg']                =       'Success';
                $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
                return true;
            }else{
                $response['errMsg']             =       'api table Record insertion failed';
            }

        }
           
        return false;
        
    }
    
    public function doDeltapdfvalidation( $jbstgid ) {
        
        try{
            
            $checkoutObj        =   new checkoutModel();
            $stageDetails       =   array();
            $stageDetails       =   $checkoutObj->getStageInfo($jbstgid);
            $stageDetails       =       $stageDetails[0];
            $metadataID     =  $stageDetails->METADATA_ID;
            $roundID        =  $stageDetails->ROUND_ID;
            
            $request                =   [];
            $request['metadataID']  =   $metadataID;
            $request['roundID']     =   $roundID;
            $validation             =   Validator::make($request, [
                                                                    'metadataID' => 'required|numeric',
                                                                    'roundID' => 'required|numeric'
                                                                ]);

            if ($validation->fails())
            {
                $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>$validation->errors());
                return response()->json($result);
            }
            $getroundname       =   Config::get('constants.ROUND_NAME.'.$roundID);
            $validatemetaid     =   taskLevelMetadataModel::where('METADATA_ID',$metadataID)->first();
            if(count($validatemetaid)   ==  0)
            {
                $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>'Invalid metadata ID');
                return response()->json($result);
            }
            $jobId              =   (count($validatemetaid)>=1?$validatemetaid->JOB_ID:"");
            $chaptername  = $chapterno          =   (count($validatemetaid)>=1?$validatemetaid->CHAPTER_NO:"");
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($validatemetaid)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                
                $ftp_root_dir       =   Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
                $inp_rep_arr        =   array( 
                                            '{BID}'       =>  $bookid , 
                                            '{RID}'    =>  $getroundname,
                                            '{CID}'    =>  $chapterno
                                         );
                $cmn_obj            =   new CommonMethodsController();
                $open_path          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $ftp_root_dir );
                $open_path          =   $hostpath.$open_path;
				
                $serverDirallFiles  =   $ftpObj->allFiles($open_path);
                $getchapterpaths    =   [];
                $jobsheetname       =   "";
                if(count($serverDirallFiles)>=1)
                {
                    $readfileextenstion =   Config::get('constants.DOCUMENT_TYPE.meta');
                    foreach($serverDirallFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        { 
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            if(strpos($spiltchapter,'.') !== false)
                            {
                                $nameofchapterextn  =   substr(strrchr($spiltchapter, "."), 1);
                                $splitname          =   explode('.',$spiltchapter);
                                if(in_array($nameofchapterextn,$readfileextenstion))
                                {
                                    $jobsheetname   =   $spiltchapter;
                                }
                            }
                        }
                    }
                }
                if(empty($jobsheetname))
                {
                    $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>'Jobsheet not found');
                    return json_encode($result);
                }
                $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver;   
                $jobsheetlocationpath   =   $crd.$open_path.$jobsheetname;
			   
                $metadataXml            =   file_get_contents( $jobsheetlocationpath );
				
                $xml                    =   simplexml_load_string(  $metadataXml , 'SimpleXMLElement' , LIBXML_NOCDATA );
                $metadataDetails        =   json_decode( json_encode((array)$xml ), TRUE );
		
                $validtagselem              =   isset( $metadataDetails['ChapterJobSheet'] ) ? 'ChapterJobSheet' : 'PartJobSheet';
                
                if(count($metadataDetails)>=1 && isset( $metadataDetails["$validtagselem"]['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['DeltaPDF'] ) )
                {
                    $validatepdf        =   $metadataDetails["$validtagselem"]['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['DeltaPDF'];
                    $returndeltapdfattr =   (isset($validatepdf)?$validatepdf:false);
                 
					if(strtolower($returndeltapdfattr)  ==  "yes")
                    {
						$pdffile_dir    =   Config::get('constants.PACKAGE_PATH.DELTAPDFFILE');
                        if(strpos(trim($chapterno),'_') !==  false){
                            $chapterno  =   explode('_',$chapterno);
                        }          
						
						$pagObj             =       new autoPageController();
						$paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chaptername , $metadataID ); 
						extract( $paging_collect );
						
                        $inp_rep_arr    =   array( 
                                                    '{BID}' =>  $bookid , 
                                                    '{CNO}' =>  (isset($chapterno)?$chapterno[1]:$chapterno) , 
                                                    '{PAGING_FILENAMING}'   =>  $pagingfilnaming
											 );
												 
                        $cmn_obj        =   new CommonMethodsController();
                        $pdffile_path   =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $pdffile_dir );
                        $checkdeltapdfexistornot    =   $ftpObj->has($pdffile_path);
						
                        if(empty($checkdeltapdfexistornot) && $checkdeltapdfexistornot != 1){
                            $result     =   array('status'=>0,'msg'=>'Error','errMsg'=> 'Delta Pdf File is Required ,' );
                            return json_encode($result);
                        }else{
                            $result     =   array('status'=>1,'msg'=>'Success','errMsg'=>$returndeltapdfattr );
                            return json_encode($result);
                        }
						
                    }else{
						$result     =   array('status'=>1,'msg'=>'Success','errMsg'=>$returndeltapdfattr );
                        return json_encode($result);
					}
					
                    $result             =   array('status'=>0,'msg'=>'Error','errMsg'=> $returndeltapdfattr );
                    return json_encode($result);
                }
				
                $result             =   array('status'=>0 , 'msg'=>'Error' , 'errMsg'=> 'Invalid xml jobsheet found , required parameter is missing in jobsheet..,');
				
                return json_encode($result);
				
            }
            $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>'Record not found');
            return json_encode($result);
        }
        catch (Exception $ex) {
			
            $result             =   array('status'=>0,'msg'=>'Error','errMsg'=>$ex->getMessage());
            return json_encode($result);
        }
    }
    
    public function doCheckLowResrequiredornot($getjobsheetpath,$getbookinfo,$getlocationftp)
    {
        $validatedelta          =   false;
        
        if(count($getjobsheetpath)>=1 && count($getlocationftp)>=1 && count($getbookinfo)>=1)
        {
            $hostserver         =   $getlocationftp->FTP_HOST;
            $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   $getlocationftp->FTP_PATH;
            $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
            
            $cname      =       $chapternumber      =   $getbookinfo[0]->CHAPTER_NO;
            $chapterno          =   preg_replace( '/\D/', '', $chapternumber );
            $ckey               =   preg_replace("/[0-9_]/", '', $chapternumber);
            
            /*if( !strpos( 'chapter' , strtolower( $ckey ) ) ){
                $chapterno  =   $cname;
            }*/
			
			if( substr_count(strtoupper( $chapterno ) , 'CHAPTER' ) == 0){
                    $chapterno       =       ucfirst(strtolower(str_replace('_','',$chapterno)));
             	}
       
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $getbookinfo[0]->BOOK_ID , $chapternumber , $getbookinfo[0]->METADATA_ID); 
			
			
            extract( $paging_collect );
            
            $array              =   array(  
                                            '{BID}' =>  $getbookinfo[0]->BOOK_ID, 
                                            '{RNAME}' =>  Config::get('constants.ROUND_NAME.'.$getjobsheetpath->ROUND_ID),
                                            '{CNO}' =>  $chapterno ,
                                            '{CNAME}' =>  $cname ,
                                            '{PAGING_FILENAMING}'   =>  $pagingfilnaming
                                        );
            
            $cmn_obj            =   new CommonMethodsController();         
            $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $array , $getjobsheetpath->FILE_PATH );
           
            $isfileavailable    =   $ftpObj->has($jobsheetpath);
            
            if($isfileavailable ==  true){
                
                $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver;   
                $jobsheetlocationpath   =   $crd.$jobsheetpath;
                $metadataXml            =   file_get_contents( $jobsheetlocationpath );
                $getjobsheetcontent     =   $cmn_obj->xml2arrayorobject($metadataXml);
               
                if(count($getjobsheetcontent)>=1){
                    
                    $validated_lowres      =   (isset($getjobsheetcontent['ChapterJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['OnlineMediaObjects'])?$getjobsheetcontent['ChapterJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['OnlineMediaObjects']:'');
                    if( strtolower( $validated_lowres ) !== 'no'   ){
                        return true;
                    }
                    
                }
            }
            
        }
        
        return $validatedelta;
        
    }
    
    public function doCheckfileisexistornot( $getbookinfo , $getlocationftp , $roundid , $typeoffile )
    {
        $validatedelta          =   false;
        $wheredelta             =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>$typeoffile];
        $getfilepath            =   apsProductionFilePathValidationModel::Active()->where($wheredelta)->first();
        if(count($getfilepath)>=1 && count($getlocationftp)>=1 && count($getbookinfo)>=1)
        {
            $hostserver         =   $getlocationftp->FTP_HOST;
            $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   $getlocationftp->FTP_PATH;
            
            $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);

            $chapternumber      =   $getbookinfo[0]->CHAPTER_NO;
            $chapterno          =   preg_replace( '/\D/', '', $chapternumber );
            $ckey               =   preg_replace("/[0-9_]/", '', $chapternumber);
            
            
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $getbookinfo[0]->BOOK_ID , $chapternumber ); 
            extract( $paging_collect );
            
            $array              =   array(  
                                            '{BID}'     =>      $getbookinfo[0]->BOOK_ID,                 
                                            '{RNAME}'   =>      Config::get('constants.ROUND_NAME.'.$getfilepath->ROUND_ID),
                                            '{CNO}'     =>      $chapterno , 
                                            '{CID}'     =>      $chapternumber ,
                                            '{PAGING_FILENAMING}'   =>  $pagingfilnaming
                                        );
            
            $cmn_obj            =   new CommonMethodsController();         
            $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $array , $getfilepath->FILE_PATH );
            
            $isfileavailable    =   $ftpObj->has($jobsheetpath);
            
            if($isfileavailable ==  true){
                $validatedelta  =   true;
            }else{
                //echo $jobsheetpath;
            }
            
        }
        
        return $validatedelta;
    }
}
