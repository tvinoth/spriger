<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiMetaExtractor;
use App\Models\apiProductionFileTransfer;
use App\Models\taskLevelMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Filesystem\Filesystem;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\eproof\eproofController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Models\jobModel;
use App\Http\Controllers\dynamicConstantController;
use App\Models\jobRevisedModel;
use App\Http\Controllers\aps\apsController;
use App\Models\workflowModel;
use App\Models\checkoutModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Http\Controllers\production\movetoproductionController;
use App\Models\apiEproofPackagingModel;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\projectModel;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\Api\eproofController as apiEproofCnt;
use App\Http\Controllers\fileHandler\fileManagerServiceController;
use App\Models\jobStage;
//use App\Http\Controllers\api;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Carbon\Carbon;

ini_set('max_execution_time', 0 );

class productionFileTransferController extends Controller
{
    protected $table = 'api_production_file_transfer';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    public $workflow     =   array( 
        
            'process' => '' ,
            'round' =>  '' , 
            'bookid'    =>  '' , 
            'jobid'     => '',
            'token' =>  '' , 
            'status'    => '' , 
            'endtime'   =>  '' , 
            'remarks' => ''
        
    );
      
    public function storeResponse( Request $request ){
         
        try{
            
            $inputarr           =           (array)json_decode( $request->getContent() );
			
			
            $round_arr          =           \Config::get('constants.ROUND_NAME');
            $round_id_arr       =           \Config::get('constants.ROUND_ID');
            $process            =           strtolower($inputarr['process']);
            $status             =           $inputarr['status'];

        Log::useDailyFiles(storage_path().'/Api/production_file_trans_output.log');
        Log::info(json_encode( $inputarr) );
            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';

            $jobId          =       $job_id         =       $inputarr['jobid']; ;
            $book_id        =       $inputarr['bookid']; 
            $round          =       $inputarr['round'];
            $token_key      =       $inputarr['tokenkey'];

            $inpArr['REMARKS']      =      $inputarr['remarks'];
            $inpArr['END_TIME']     =       date( 'Y-m-d H:m:i' );
            $errMsg         =       '';        

            $api_pft        =       new apiProductionFileTransfer();
            $rec            =       $api_pft->getApiRequest( $jobId , $round , $token_key );

            if( is_object( $rec ) ){

                $inpArr['STATUS']       =       $status;
                $rowid                  =       $rec->ID;
                $api_pft->updateIfExist($inpArr, $rowid);

                $response['status']         =       1;
                $response['msg']            =       'Success';
                $response['errMsg']         =       'signal received';

                if($status == 2){

                    $jobModelObj  =   new jobModel();
                    $jobDetails   =   $jobModelObj->getJobdetails( $jobId );

                    if($round == '116' ){
                         $bookId       =   $jobDetails->BOOK_ID;
                         $this->copyJobsheetForOfSeries($rec,$jobDetails);
                    }

                }
                
                
                $processtyperequest     =   (isset($inputarr['revised_receipt']) && $inputarr['revised_receipt'] != '' && $inputarr['revised_receipt'] ==   "REVISED_RECEIPT"?"REVISED_RECEIPT":"RECEIPT");
                $wheredownloaddata      =   ['JOB_ID'=>$job_id,'ROUND'=>$round];
                // check exist downloaded or not
                $downloadrec    =   $api_pft->where($wheredownloaddata)->orderBy('ID','desc')->first();
                if( $round == $round_id_arr['S50'] && $status == 2 ){
                    $meta_obj		=	new MetaExtractorController();
                    if(!empty($downloadrec) && $downloadrec->STATUS !=  3){
                        $meta_obj->sendInputForJobsheetUpdate( $jobId , $round , $processtyperequest );
                    }
                    if(empty($downloadrec)){
                        $meta_obj->sendInputForJobsheetUpdate( $jobId , $round , $processtyperequest );                
                    }
                }

                if( $round == $round_id_arr['S600'] && $status == 2 ){

                    $meta_obj		=	new MetaExtractorController();
                    if(!empty($downloadrec) && $downloadrec->STATUS !=  3){
                        $meta_obj->sendInputForJobsheetUpdate( $jobId , $round , $processtyperequest );
                    }
                    if(empty($downloadrec)){
                        $meta_obj->sendInputForJobsheetUpdate( $jobId , $round , $processtyperequest );                     
                    }
                    
                    $movetoobj          =       new movetoproductionController();

                    //if this is based on chapter level means , need to give additional param of metaid
                    if(isset( $rec->METADATA_ID ) && !empty( $rec->METADATA_ID  ) ){
                        $s600flag       =       $movetoobj->s600MoveToproduction( $jobId , $round  , $rec->METADATA_ID );
                    }else{
                        $s600flag       =       $movetoobj->s600MoveToproduction( $jobId , $round );
						
                    }

                }            
                
                if( $round == $round_id_arr['S650'] && $status == 2 ){
                    
                    $apiEproofCnt           =       new apiEproofCnt();
                    $bookInfo               =       jobModel::getJobdetails( $jobId );
                    $jobLevelProofing       =       $bookInfo->EPROOFING_SYSTEM;
                    $checkstatus            =       false;
                    
                    if( $jobLevelProofing == 1 )
                        $checkstatus                =    $apiEproofCnt->startEproofPackagingS650( $jobId , $round );            
                    
                }
                
                if(!empty($jobId) && 'S300' == $round_arr[$round]){ 

                    $taskLevelMetaObj       =       new taskLevelMetadataModel();
                    $metaid                 =       $rec->METADATA_ID;
                    $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $rec->METADATA_ID );

                    $job_id                 =       $tasklev_info[0]->JOB_ID;    
                    $bookInfo               =       jobModel::getJobdetails( $jobId );
                    $jobLevelProofing       =       $bookInfo->EPROOFING_SYSTEM;
                    $haseProof              =       false;
                    $chapCompo              =   \Config::get('constants.ARTICLE_CHAPTER');
                    $fmbmpartVal            =       intval( $tasklev_info[0]->FM_ARTICLE_BM );

                    if( $tasklev_info->count() && $jobLevelProofing == 1 )
                        $haseProof               =       ( $tasklev_info[0]->EPROOFING_SYSTEM == 1 ) ? true : false;

                    if( $haseProof && $fmbmpartVal == $chapCompo ){

                        $inputArr			=	array();

                        //$returnstaseproof	=	$this->alreadyEproofTriggered( $tasklev_info[0] );

                        //if( !$returnstaseproof ){

                        $jobsheetPresent	=	$this->checkS300JobsheetFound( $tasklev_info[0] );

                        if( $jobsheetPresent ){  
                            //triggering the eproof package
                            
                            $eprCntrl        = 		 new eproofController();
                            $test       	 =       $eprCntrl->doEproofVendorpackagecreate( $jobId , $rec->METADATA_ID , $round , 'package' );

                        }else{

                            $this->insertEproofPackageFailureEntry( $tasklev_info[0] );
                            $response['errMsg']         =       'Jobsheet not found , waiting time crossed';

                        }

                                            //}

                    }else{

                        $chapCompo  =   \Config::get('constants.ARTICLE_CHAPTER');

                        if( $fmbmpartVal !== $chapCompo ){

                            $wrftype        =   0;
                            $masterid       =           \Config::get('constants.WORKFLOW.S300.MASTER_ID');   
                            $quanity        =           10;
							
							$chapter_arr         	=       taskLevelMetadataModel::select( DB::raw( 'task_level_metadata.*,metadata_info.*' ) )
											->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
											->where('task_level_metadata.METADATA_ID', $metaid )
											->get()->first();    
											
							if( !empty( $chapter_arr ) ){
								if( !empty( $chapter_arr['END_PAGE'] ) ){
									$quanity    =   $chapter_arr['END_PAGE'];
								}
							}
							
                            $duedate        =           date( 'Y-m-d H:i:s' );

                            $wrkflw_mdl     =           new workflowModel();
                            $wfdata         =           $wrkflw_mdl->getWorkflosByMasterIdAndType( $masterid , $wrftype );
                            $workflowid     =           $wfdata->WORKFLOW_ID;
                            $mvtoProd       =           new movetoproductionController();
                            $response_      =           $mvtoProd->taskLevelMoveToProductionProcedure( $jobId , $round , $workflowid , $metaid , $quanity , $duedate , $wrftype  );

                            $jbstgObj		=	new jobStage();
                            $getCurrnt_stage        =	$jbstgObj->getCurrentJobStageInfo( $metaid , $round , 27  );						

                            if( count( $getCurrnt_stage ) ){

                                $jbstgInfo		=	$getCurrnt_stage[0];
                                $job_round_id           =       $jbstgInfo->JOB_ROUND_ID;
                                $job_stage_id           =       $jbstgInfo->JOB_STAGE_ID;

                                $checkoutObj            =       new checkoutModel();
                                $stageDetails           =       $checkoutObj->getStageInfo($job_stage_id);
                                $stageData              =	$stageDetails[0];

                                $jobRoundId             =       $stageData->JOB_ROUND_ID;
                                $roundId                =       $stageData->ROUND_ID;
                                $stageSequence          =       $stageData->STAGE_SEQ;
                                $workflowId             =       $stageData->WORKFLOW_ID;  
                                $iteration              =       $stageData->ITERATION_ID;
                                $jobId                  =       $stageData->JOB_ID;
                                $curjobstgid            =       $stageData->JOB_STAGE_ID;        
                                $outputQuantity         =   	$stageData->OUTPUT_QUANTITY;
                                $nexstageDetails        =       $checkoutObj->getNextStageDetails($jobRoundId, $stageSequence, $iteration, $workflowId);

                                if(!empty($nexstageDetails)){

                                    $nextJobStageId 	=   $nexstageDetails->JOB_STAGE_ID;
                                    $nextStageId        =   $nexstageDetails->STAGE_ID;
                                    $userDefData    	=   taskLevelUserdefinedWorkflow::getUserDefineStageDetails( $jobId, $workflowId , $round , $nextStageId );
                                    $stageType      	=   $userDefData->IS_AUTO;

                                    $updateStageParam       =   array( 'STATUS'=>'23' , 'CHECK_OUT' => date( 'Y-m-d H:i:s' ) , 'INPUT_QUANTITY' => $outputQuantity);
                                    $updateQry              =   DB::table('job_stage')
                                                                    ->where('JOB_STAGE_ID', $nextJobStageId )
                                                                    ->update( $updateStageParam );

                                    $jobRoundValue1         =   array('STATUS'=>'23','CURRENT_STAGE' => $nextStageId);
                                    $updateQry              =   DB::table('job_round')
                                                                    ->where('JOB_ROUND_ID', $jobRoundId )
                                                                    ->update( $jobRoundValue1 );

                                    $jobRoundValue2           =      array( 'CURRENT_STAGE' => $nextStageId , 'CURRENT_ROUND' => $round );
                                    $updateQry                =      DB::table('task_level_metadata')
                                                                        ->where( 'METADATA_ID', $metaid )
                                                                        ->update( $jobRoundValue2 );


                                    $stgMgCntrlr		=		new stageMangerController();
                                    $ret_status     =   $stgMgCntrlr->handlingAutoStages( $nextStageId , $nextJobStageId ); 
                                    //$returns        =       projectModel::skipStage( 1 , $job_stage_id, $quanity, $job_round_id , 1  );

                                }
                            }
                        }
                    }
					
					 //JS Compare
					$getRequestedRow					= array();		
					$getRequestedRow['JOB_ID']  		= $jobId;
					$getRequestedRow['ROUND']  			= $round;
					$getRequestedRow['METADATA_ID']  	= $metaid;
					$getRequestedRow['PROCESS_TYPE_DIFF']  	= 'RECEIPT';
					
					$jscomper				=	(object)$getRequestedRow;
				 
				//	$successfileresponse    =   app('App\Http\Controllers\Api\JsCompareController')->jsCompareProcess($jscomper);
                   
                }

            }else{

                $response['status']         =       0;
                $response['msg']            =       'Failed...';
                $response['errMsg']         =       'Invalid Try';

            }

            return response()->json( $response );

        }catch( \Exception $e ) {

            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );

            $errMsg         =   $this->oopsErrorResponse;
            $msg            =   '';
            $response       =	array(  'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  $errMsg );

            return response()->json( $response );

        }
        
    }
    
    public function alreadyEproofTriggered( $inputObj ){

            $metadataID 		=		$inputObj->METADATA_ID;
            $jobId				=		$inputObj->JOB_ID;		

            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundId			=		$round_arr['S300'];

            $wheredata  		=   	['METADATA_ID' => $metadataID,'ROUND'=>$roundId,'PROCESS_TYPE'=>"1",'JOB_ID'=>$jobId ];
            $checkExist     	=   	apiEproofPackagingModel::where($wheredata)->orderBy('ID','desc')->first();

            if(empty($checkExist)){
                    return false;
            }else{
                    return true;
            }

    }
    
    public function insertEproofPackageFailureEntry( $inputObj ){

    $cmn_obj            =   	new CommonMethodsController();               
            $tokenkey           =   	$cmn_obj->generateRandomString( 16 , 'api_eproof_packaging' , 'TOKEN_KEY'  );     
            $metadataID 		=		$inputObj->METADATA_ID;
            $jobId				=		$inputObj->JOB_ID;		

            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $roundId			=		$round_arr['S300'];

            //insert eproof package error data
            $insertdata['JOB_ID']       =   $jobId;
            $insertdata['METADATA_ID']  =   $metadataID;
            $insertdata['ROUND']        =   $roundId;
            $insertdata['created_at']   =   Carbon::now();
            $insertdata['START_TIME']   =   Carbon::now();
            $insertdata['TOKEN_KEY']    =   $tokenkey;
            $insertdata['STATUS']       =   "3";
            $insertdata['PACKAGE_ID']   =   'Failure_Package_'.$metadataID.'_'.$roundId.'_'.$tokenkey.'_'.date('Y_m_d_h_i_s').'.zip';
            $insertdata['REMARKS']      =   "Failure to Trigger Eproof Package : Jobsheet Not Found";

            //check exist data
            $wheredata  	=   ['METADATA_ID' => $metadataID,'ROUND'=>$roundId,'PROCESS_TYPE'=>"1",'JOB_ID'=>$jobId ];
            $checkExist     =   apiEproofPackagingModel::where($wheredata)->orderBy('ID','desc')->first();

            if(empty($checkExist)){

                    apiEproofPackagingModel::insert($insertdata);

            }else{
                    $checkExist->STATUS     =   $insertdata['STATUS'];
                    $checkExist->updated_at =   Carbon::now();
                    $checkExist->REMARKS    =   $insertdata['REMARKS'];
                    $checkExist->save();
            }

            $response['errMsg']     =   $insertdata['REMARKS'];

            return $response;

    }
	
    public function checkS300JobsheetFound( $inputObj ){


            $metaId 	=		$inputObj->METADATA_ID;
            $jobId		=		$inputObj->JOB_ID;
            $cmn_obj    =       new CommonMethodsController();
            $bookInfo   =       jobModel::getJobdetails( $jobId );
            $getlocationftp 	= 		productionLocationModel::doGetLocationname( $jobId );
            $round_arr          =       \Config::get('constants.ROUND_NAME');
            $locationFlag		=		1;

            if( empty( $getlocationftp ) ){          
                    $getlocationftp  =     (object)  productionLocationModel::getDefaultProductionLocationInfo();
                    $locationFlag = 0;
            }

            $round	 			 =		 $round_arr['S300'];
            $hostserver          =       $getlocationftp->FTP_HOST;
            $hostusername        =       $getlocationftp->FTP_USER_NAME;

            if( $locationFlag == 0 ){
                    $hostpassword  = \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            }else{
                    $hostpassword        =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
            }

            $hostpath            =       $getlocationftp->FTP_PATH;
            $roundname           =       $round_arr[$round];
            $root_path           =       \Config::get('constants.FILE_SERVER_ROOT_DIR');
            $js_cpy_const 		 = 		 \Config::get('serverconstants.PRODUCTION_JOBSHEET_PATH');
    	    $sheetnaming 		 =		 \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
            $defaultCopyPath 	 = 		 $cmn_obj->backslashPathPrepare($js_cpy_const, true);
            $jobDetails          =        DB::table('job')->where('JOB_ID', $jobId )->get();
            $bookid				 =		 $jobDetails[0]->BOOK_ID;
            $chapterno			 =		 $inputObj->CHAPTER_NO;

            $inp_rep_arr = array( 
                    '{BID}' => $bookid, 
                    '{RID}' => $roundname, 
                    '{CID}' => $chapterno ,
                    'BOOK_ID' => $bookid,
                    'ROUND_NAME' => $roundname,
                    'STAGE_NAME' => $roundname
            );

            $chapterno2         =        preg_replace( '/\D/', '', $chapterno );

            $default_jobsheet_path = 	 $cmn_obj->arr_key_value_replace($inp_rep_arr, $defaultCopyPath);
    $xml_name			 =		 $bookid.'_'.$chapterno2.$sheetnaming[$round];
            $jobsheet_file_path  =       $cmn_obj->backslashPathPrepare( $default_jobsheet_path , true );
            $jobsheet_file_path  =       $jobsheet_file_path.$xml_name;    


            $ftpObj              =       new ftpFileHandlerController( $hostserver, $hostusername , $hostpassword );
            $fileCheck_path      =       str_replace( '\\\\'.$hostserver.str_replace( '/' , '\\' , $root_path  ) , '' , $jobsheet_file_path );
			$k		=	0;
			
			if (false) { recheck: }
			
            $fileExistCheck      =       $ftpObj->ftpFileExist(  $fileCheck_path );

            if( !$fileExistCheck ){

                    $response['status'] =   0;
                    $response['msg']    =   'Failed';
                    $response['errMsg'] =   'Jobsheet not found!, kindly check!';  

                    if($k <= '10'){
                            sleep(10);
                            $k = $k+1;
                            goto recheck;
                    }

                    return false;
            }else{
                    return true;
            }

    }
	
    public function fileTransferLog( $job_id , $round  , $processtype  = 1 , $meta_id = null ){
        
        $bookdetaills   =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid         =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $base_url       =       \Config::get('constants.BASE_URL');
                
        $input_arr  =   array( 
            'book_id'       =>      $bookid , 
            'filepath'      =>      '' , 
            'callbackUrl'   =>      $base_url.'api/productionFileTransferCallback'
        );
        
        $table_name     =       'api_production_file_transfer';
        $book_id        =       $input_arr['book_id'];
        $ret_url        =       $input_arr['callbackUrl'];        
        $cmn_obj        =       new CommonMethodsController();
        $token_key      =       $cmn_obj->generateRandomString( 16 , $table_name  );        
        $api_pft        =       new apiProductionFileTransfer();
        
        $process_list   =       \Config::get('constants.PRE_PRODUCTION_PROCESS_TYPE');
        $process_name   =       $process_list[$processtype];
        
        $inp_arr        =       array( 
            
                                    'TOKEN_KEY'     =>  $token_key , 
                                    'PROCESS_NAME'  =>  $process_name , 
                                    'JOB_ID'        =>  $job_id , 
                                    'METADATA_ID'   =>  $meta_id , 
                                    'ROUND'         =>  $round , 
                                    'START_TIME'    =>  date( 'Y-m-d H:m:i' )
                                );
        
        $user_id        =       Session::get('users')['user_id'];
        
        
        if( !empty( $user_id ) ){
            $inp_arr['USER_ID'] =   $user_id;
        }
        
        $api_pft->insertNew($inp_arr);
        
        //File copy work for users [ UserWork Dir ]
        
        $successfileresponse        =       true;
        
        $response 	=	array(  
                                        'status'    =>  1   ,
                                        'msg'   =>  'Success' , 
                                        'errMsg'   =>  'ftp request successfully' , 
                                        'params'    =>  array( 'token_key' => $token_key )
                                     );
        
        if( !$successfileresponse ){
            
            //update is active to false for invalid request
            $inpArr     =       array();
            $records            =       $api_pft->getApiRequest( $job_id , $round  , $token_key );
            $rowid              =       $records->ID;
            $inpArr =   array( 'END_TIME'   => date( 'Y-m-d H:m:i' ) , 'IS_ACTIVE' => 0 , 'REMARKS' => 'file transfer failed .');
            $api_pft->updateIfExist($inpArr, $rowid);
            $response 	=	array(  
                                        'status'    =>  0     ,
                                        'msg'   =>  'Failed' , 
                                        'errMsg'   =>  'file transfer failed' ,
                                        'params'   => array( 'token_key' => '' )
                                     );
         
        }
       
        return $response;
        
    }
   
    public function locationChangeRequest_old( $job_id , $round ){
        
        $bookdetaills   =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid         =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $base_url       =       \Config::get('constants.BASE_URL');
        
        $input_arr  =   array( 
            'book_id'   =>    $bookid, 
            'filepath'   =>  '' , 
            'callbackUrl'   =>  $base_url.'api/productionChangeCallback'
        );
        
        $table_name =       'api_production_file_transfer';
        
        $book_id    =       $input_arr['book_id'];
        $ret_url    =       $input_arr['callbackUrl'];
        $cmn_obj    =       new CommonMethodsController();
        $token_key      =      $cmn_obj->generateRandomString( 16 , $table_name  );
          
        
        $uploadMeta =   '<uploadMeta>
                <bookid>'.$book_id.'</bookid>                             
                <stage>S5</stage>
                <uploadtype>bflux</uploadtype>
                <sourcePath>
                    <ftpType>ftp</ftpType>
                    <ftpSite>ftp1.spipublisherservices.com</ftpSite>
                    <fingerPrint></fingerPrint>
                    <path>/springer_magnus_ftp_download_test/in</path>
                    <username>PDFWorkflow</username>
                    <password>$p1pdf</password>
                </sourcePath>    
                <destPath>
                                <ftpType>ftp</ftpType>
                                <ftpSite>ftp1.spipublisherservices.com</ftpSite>
                                <fingerPrint></fingerPrint>
                                <path>/springer_magnus_ftp_download_test/out</path>
                                <username>PDFWorkflow</username>
                                <password>$p1pdf</password>
                </destPath>
                <WorkflowAPI>
                                <Url value="'.$ret_url.'"/>
                                <parameter key="process" value="upload" type="fixed"/>
                                <parameter key="job_id" value="'.$job_id.'" type="fixed"/>
                                <parameter key="book_id" value="'.$book_id.'" type="fixed"/>
                                <parameter key="book_id" value="'.$token_key.'" type="fixed"/>
                                <parameter key="round" value="'.$round.'" type="fixed"/>
                                <parameter key="status" type="boolean"/>
                                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                <parameter key="remarks" type="string"/>
                </WorkflowAPI>
                </uploadMeta>';
        
        
        $ftpObj 	= 	Storage::createFtpDriver([
								'host'     => Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST'), 
								'username' => Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME'),
								'password' => Crypt::decryptString(Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD')), // 
								'port'     => '21',
								'timeout'  => '30',
							]);
        
        $content 	= 	$uploadMeta;
        
        $filename 	=	$book_id.'_upload_meta_'.date('Y-m-d H-m-s').'.xml';
        $successfileresponse 	=	$ftpObj->put(Config::get('constants.WATCH_PRD_CHANGE_WATCH_FOLDER').'/'.$filename, $content);
        
        $response 	=	array('result'=>200,'msg'=>'Success');
        return response()->json($response);
        
    }
    
    public function locationChangeRequest( $job_id , $round , $metaid = null,$processtype = 'RECEIPT'){
        
        $bookdetaills       =       jobModel::where('JOB_ID',$job_id)->first();
        $bookid             =       (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $base_url           =       \Config::get('constants.BASE_URL');
        
        $input_arr          =       array( 
                                            'book_id'   =>    $bookid, 
                                            'filepath'   =>  '' , 
                                            'callbackUrl'   =>  $base_url.'/api/productionFileTransferCallback'
                                        );
        
        $table_name         =       'api_production_file_transfer';
        $jobId              =       $job_id;
        $book_id            =       $input_arr['book_id'];
        $ret_url            =       $input_arr['callbackUrl'];
        
        $file_copy_to       =       '';

        $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
        
            if( count( $getlocationftp ) ){

            //need to dynamicaly bind the production location based on table location
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       ($getlocationftp->FTP_PATH);
            $production_file_server_ip  =   $hostserver.$hostpath;
            
            $cn_user            =       $hostusername;
            $cn_pass            =       $hostpassword;
            $credentials        =       '<>'.$cn_user.'<>'.$cn_pass;
            $root               =       \Config::get('constants.FILE_SERVER_ROOT_DIR');

            $rawpath            =       \Config::get('constants.SPLIT_SOURCE_PATH');
            $copyEditingpath    =       \Config::get('serverconstants.COPY_EDITING_PRODUCTION_PATH');

            $s50Round           =       \Config::get('constants.JOB_ASSIGNED_CONST');
            $roundname_arr      =       \Config::get('constants.ROUND_NAME');
            $roundname          =       $roundname_arr[$round];

            $inp_rep_arr        =   array( 
                                            'BOOK_ID'        =>      $book_id , 
                                            'ROUND_NAME'     =>      $roundname ,
                                            '{BID}'          =>      $book_id , 
                                            '{RID}'          =>      $roundname , 
                                         );

            if( !is_null( $metaid )  ){            
                $chaptername                =       '';
                $tlm                        =       new taskLevelMetadataModel();
                $taskLevelInfo              =       $tlm->getMetadatadetailsChapter( $metaid );
                $chapterlist                =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray();
                $inp_rep_arr['{CID}']       =       $chapterlist[0];
                $inp_rep_arr['CID']         =       $chapterlist[0];            
            }

            $cmn_obj                        =       new CommonMethodsController();
            
            switch( $roundname ){
                case 'S200':
                    $copyEditingpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $copyEditingpath );
                    $file_copy_to       =       $hostserver.$root.$hostpath.$copyEditingpath;
                    break;
                case 'S300':
                    $rawpath            =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S300');
                    $rawpath            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $file_copy_to       =       $hostserver.$root.$rawpath;
                    break;
                case 'S600':
                    $rawpath            =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S600');
                    $rawpath            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $file_copy_to       =       $hostserver.$root.$rawpath;
                    break;
                case 'S650':
                    $rawpath            =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S650');
                    $rawpath            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $file_copy_to       =       $hostserver.$root.$rawpath;
                    break;
                default : 
                        $rawpath            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                        $file_copy_to       =       $hostserver.$root.$hostpath.$rawpath;
                    break;
            }
            
            $file_copy_to           =       str_replace( '//' , '/' , $file_copy_to );
            $file_copy_to           =       str_replace( '/' , '\\' , $file_copy_to );            
            $file_copy_to           =       '\\\\'.$file_copy_to;
            
            $status  = 0;

            try{            

                $token_key          =        $cmn_obj->generateRandomString( 16 , $table_name  );
                $api_link           =        \Config::get('constants.PRODUCTION_TOOLS_SETUP.PRODUCTION_FILE_TRANSFER_API_ASYNC');
                $project_type       =       'BWF';   

                $getBookzip         =       DB::table('api_download')->select()->where( 'BOOK_ID' , $book_id  )->orderBy('ID', 'desc')->first();
                $roundname_arr      =       \Config::get('constants.ROUND_NAME');
                $roundname          =       $roundname_arr[$round];

                $input_arr          =       array( "{$project_type}BookID"  =>   $book_id ,
                                                'Stage'     =>  $roundname , 
                                                'Filename'  =>   $getBookzip->FILE_NAME  ,  //'BookTitleID=393764_EditionNumber=1_Language=En_2017-12-29_08-31-07.zip', 
                                                'FileServerPath'    =>  $file_copy_to ,
                                                'WorkflowAPI'       =>  array(
                                                                    'Url'   =>  $ret_url , 
                                                                    'parameter' => array( 
                                                                                            array( 'key' => 'process' , 'value'=> 'production_file_copy' , 'type' => 'fixed' ) ,  
                                                                                            array( 'key' => 'tokenkey' , 'value'=> $token_key , 'type' => 'fixed'  ) , 
                                                                                            array( 'key' => 'jobid' , 'value'=> $job_id , 'type' => 'fixed'  ) , 
                                                                                            array( 'key' => 'bookid' , 'value'=> $book_id , 'type' => 'fixed'  ) , 
                                                                                            array( 'key' => 'round' , 'value'=> $round , 'type' => 'fixed' ) , 
                                                                                            array( 'key' => 'status' ,  'type' => 'boolean' ) , 
                                                                                            array( 'key' => 'remarks' ,  'type' => 'string' ) , 
                                                                                            array( 'key' => 'endtime' ,  'type' => 'data-time' , 'value' => 'yyyy-MM-dd HH-mm-ss' ) 
                                                                                    )
                                                                )   
                                            );
                // if revised receipt add below parameter's
                if($processtype     ==  "REVISED_RECEIPT"){
                    $input_arr['WorkflowAPI']['parameter'][]  =   array( 'key' => 'revised_receipt' , 'value'=> $processtype , 'type' => 'fixed' );
                }
                
                $curl       =       $api_link;
                $data       =       $input_arr;

                $status     =       0;

                //insert to api table - 
                $api_pft    =       new apiProductionFileTransfer();
                $user_id    =       Session::get('users')['user_id'];

                $inp_arr    =       array( 
                                            'TOKEN_KEY' => $token_key , 
                                            'PROCESS_NAME' => 'PRODUCTION_CHANGE' , 
                                            'JOB_ID'    =>  $job_id , 
                                            'ROUND'     =>  $round , 
                                            'USER_ID'   =>  $user_id , 
                                            'START_TIME' => date( 'Y-m-d H:m:i' ) , 
                                            'STATUS'	=> 1 , 
                                            'REQUEST_LOG'   =>  json_encode( $data )
                                        );

                if( !is_null( $metaid )  ){
                    $inp_arr['METADATA_ID'] =  $metaid; 
                }

                $api_pft->insertNew($inp_arr);
                
                $api_response           =       $cmn_obj->RestfulPostcUrlExecution( json_encode( $data ) , $curl ,"");
                $code                   =       ( $api_response['http_code'] );
                $msg                    =       '';
                $errMsg                 =       '';

                if( $code == 200 ){

                    $status      =    ( $api_response[0]  == 'Success' )  ? 1 : 0;
                    $msg         =      'Request send successfully';

                }else{

                    $inpArr['STATUS']       =       0;
                    $inpArr['END_TIME']     =       date( 'Y-m-d H:m:i' );
                    $errMsg                 =       'Webservice is not available..';
                    $inpArr['REMARKS']      =       $errMsg;

                    $rec        =       $api_pft->getApiRequest( $jobId , $round , $token_key );
                    $rowid      =       $rec->ID;

                    $api_pft->updateIfExist($inpArr, $rowid);
                    throw new \Exception( $errMsg );

                }

                $response 	=	array( 'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  $errMsg );

            }catch(\Exception $e) {

                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
                
                $errMsg         =   $this->oopsErrorResponse;
                $msg            =   '';
                $response 	=	array(  'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  $errMsg );
                
                return $response;
                
            }

        }else{
            
            $response 	=	array(  'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  'Not able to get assigned location' );
          
        }
        
       return $response;
        
   }
    
    public function rawFileDownloadRequest( $job_id , $round , $metaid = null ){
        
        $bookdetails       =       jobModel::getJobdetails($job_id);
        if(empty($bookdetails)){
            $response 	=	array( 'result' => 404  ,'status' => 0  , 'msg'=> 'Failure'  , 'errMsg' =>  'Job Details is not found!' );
            return $response;
        }
        $bookid             =       $bookdetails->BOOK_ID;
        
        $base_url           =       \Config::get('constants.BASE_URL');
        
        $input_arr          =       array( 
                                            'book_id'   =>    $bookid, 
                                            'filepath'   =>  '' , 
                                            'callbackUrl'   =>  url('/').'/api/productionFileTransferCallback'
                                        );
        
        $table_name         =       'api_production_file_transfer';
        $jobId              =       $job_id;
        $book_id            =       $input_arr['book_id'];
        $ret_url            =       $input_arr['callbackUrl'];
        $file_copy_to       =       '';

        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        if(empty($getlocationftp) || $getlocationftp == null){
            $getlocationftp     =   productionLocationModel::getDefaultProductionLocationInfo();    
        }
        
        $cmn_obj                        =       new CommonMethodsController();
        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ($getlocationftp->FTP_PATH);

        $production_file_server_ip  =   $hostserver.$hostpath;
        $cn_user        =       $hostusername;
        $cn_pass        =       $hostpassword;
        $credentials    =       '<>'.$cn_user.'<>'.$cn_pass;
        $root           =       Config::get('constants.FILE_SERVER_ROOT_DIR');
        $roundname_arr  =       \Config::get('constants.ROUND_NAME');
        $roundname      =       $roundname_arr[$round];

        $inp_rep_arr        =   array( 
                                        'BOOK_ID'        =>      $book_id , 
                                        'ROUND_NAME'     =>      $roundname ,
                                        '{BID}'          =>      $book_id , 
                                        '{RID}'          =>      $roundname , 
                                     );
        
        $getuserid  =   Session::get('users')['emp_id'].'/';
        //(empty($this->empId)? Session::get('users')['emp_id'] : $this->empId.'/');
        
        $userdir        =       Config::get('serverconstants.USER_WORK_PATH');
        $userdirpath    =   $userdir.$getuserid.$bookid;
        $file_copy_to   =   $hostserver.$root.$hostpath.$userdirpath;
        
        $file_copy_to           =       str_replace( '//' , '/' , $file_copy_to );
        $file_copy_to           =       str_replace( '/' , '\\' , $file_copy_to );            
        $file_copy_to           =       '\\\\'.$file_copy_to;
        $status  = 0;
        $result     =   404;
        try{            
            
            $token_key          =        $cmn_obj->generateRandomString( 16 , $table_name  );
            $api_link           =        \Config::get('constants.PRODUCTION_TOOLS_SETUP.PRODUCTION_FILE_TRANSFER_API_ASYNC');
            $project_type       =       'BWF';   
            
            $getBookzip     =   DB::table('api_download')->select()->where( 'BOOK_ID' , $book_id  )->orderBy('ID', 'desc')->first();
            $roundname_arr    =   \Config::get('constants.ROUND_NAME');
            $roundname    =   $roundname_arr[$round];
          
            $input_arr          =       array( "{$project_type}BookID"  =>   $book_id ,
                                            'Stage'     =>  $roundname , 
                                            'Filename'  =>   $getBookzip->FILE_NAME  ,  //'BookTitleID=393764_EditionNumber=1_Language=En_2017-12-29_08-31-07.zip', 
                                            'FileServerPath'    =>  $file_copy_to ,
                                            'WorkflowAPI'       =>  array(
                                                                'Url'   =>  $ret_url , 
                                                                'parameter' => array( 
                                                                                        array( 'key' => 'process' , 'value'=> 'production_file_copy' , 'type' => 'fixed' ) ,  
                                                                                        array( 'key' => 'tokenkey' , 'value'=> $token_key , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'jobid' , 'value'=> $job_id , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'bookid' , 'value'=> $book_id , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'round' , 'value'=> $round , 'type' => 'fixed' ) , 
                                                                                        array( 'key' => 'status' ,  'type' => 'boolean' ) , 
                                                                                        array( 'key' => 'remarks' ,  'type' => 'string' ) , 
                                                                                        array( 'key' => 'endtime' ,  'type' => 'data-time' , 'value' => 'yyyy-MM-dd HH-mm-ss' ) 
                                                                                )
                                                            )   
                                        );

            
            $curl       =       $api_link;
            $data       =       $input_arr;
        
            $status     =       0;
            
            //insert to api table - 
            $api_pft    =       new apiProductionFileTransfer();
            $user_id                 =           Session::get('users')['user_id'];
            
            $inp_arr    =       array( 
                                        'TOKEN_KEY' => $token_key , 
                                        'PROCESS_NAME' => 'PRODUCTION_CHANGE' , 
                                        'JOB_ID'    =>  $job_id , 
                                        'ROUND'     =>  $round , 
                                        'USER_ID'   =>  $user_id , 
                                        'START_TIME' => date( 'Y-m-d H:m:i' ) , 
					'STATUS'	=> 1 , 
                                        'REQUEST_LOG'   => json_encode( $data )
                                    );
            
            if( !is_null( $metaid )  ){
               $inp_arr['METADATA_ID'] =  $metaid; 
            }
            
            $getlastinsertedid  =   $api_pft->insertRecord($inp_arr);
            
            //Log::useDailyFiles(storage_path().'/Api/production_file_trans_input.log');
            //Log::info( json_encode($data) );
           
            $api_response           =       $cmn_obj->RestfulPostcUrlExecution( json_encode( $data ) , $curl ,"");
            $code                   =       ( $api_response['http_code'] );
            $msg                    =       '';
            $errMsg                 =       '';
            $result                 =       '404';

            if( $code == 200 ){
                
                $status      =    ( $api_response[0]  == 'Success' )  ? 1 : 0;
                $msg         =      'Request send successfully';
                $result      =      200;
            }else{
                $inpArr['STATUS']       =       0;
                $inpArr['END_TIME']     =       date( 'Y-m-d H:m:i' );
                $errMsg =   'Webservice is not available..';
                $inpArr['REMARKS']      =       $errMsg;
                $rec        =       $api_pft->getApiRequest( $jobId , $round , $token_key );
                $rowid      =       $rec->ID;
                
                $api_pft->updateIfExist($inpArr, $rowid);
                throw new \Exception( $errMsg );
            }

            $response 	=	array( 'status' => $status ,'msg'=> $msg ,'result' => $result , 'errMsg' =>  $errMsg , 'lastID' => $getlastinsertedid );
        
        }catch(\Exception $e) {
            
             
            $errMsg    =   $e->getMessage();
            $msg        =   '';
            $response 	=	array(  'status' => $status  , 'msg'=> $msg  ,'result' => $result, 'errMsg' =>  $errMsg ,'lastID' => "" );
          
        }
        
       return $response;
        
   }
   
   public static function checkToolStatus(Request $request) {
        $inpArray               =   array(); 
	$id                     =   $request->input('ID');
	$result                 =   apiProductionFileTransfer::find(  $id  ); 
        if($result !=   '')
        {
            if($result->STATUS  ==  3)
            {
                $response       =   array('result'=>400,'errMsg'=>"Tool response is failed because ".$result->REMARKS); 
                return response()->json($response);	
            }
            if($result->STATUS  ==  1)
            {
                $response       =   array('result'=>500,'errMsg'=>"Waiting for tool response"); 
                return response()->json($response);	
            }
            if($result->STATUS  ==  2)
            {
                $response       =   array('result'=>200,'errMsg'=>"Request is received from tool now file will be open wait a moment "); 
                return response()->json($response);	
            }
        }
        $response       =   array('result'=>404,'errMsg'=>'No data found in production file transfer'); 
        return response()->json($response);
    }
    
    /*
     *  To transfer file for split process
     *  input params are : 
     *   process type : 
     *  1 -> raw to userwork  , 
     *  2 -> user work to destination , 
     *  3 -> user work to temp path  , 
     *  4 -> temp path to destination
     *  
     *  JOBID , ROUND , 
     * 
     */
     
   
    public function splitFileTransfer( $job_id , $round  , $processtype  = 1 ){
        $bookdetaills   =   jobModel::where('JOB_ID',$job_id)->first();
        $bookid         =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $base_url       =       \Config::get('constants.BASE_URL');
                
        $input_arr  =   array( 
            'book_id'       =>      $bookid, 
            'filepath'      =>      '' , 
            'callbackUrl'   =>      $base_url.'api/productionFileTransferCallback'
        );
        
        $table_name     =       'api_production_file_transfer';
        $book_id        =       $input_arr['book_id'];
        $ret_url        =       $input_arr['callbackUrl'];        
        $cmn_obj        =       new CommonMethodsController();
        $token_key      =       $cmn_obj->generateRandomString( 16 , $table_name  );        
        $api_pft        =       new apiProductionFileTransfer();
        
        $inp_arr        =       array( 
                                    'TOKEN_KEY' => $token_key , 
                                    'PROCESS_NAME' => 'SPLIT CHECKOUT' , 
                                    'JOB_ID' => $job_id , 
                                    'ROUND' => $round , 
                                    'START_TIME' => date( 'Y-m-d H:m:i' )
                                );
        
        $api_pft->insertNew($inp_arr);
        //File copy work for users [ UserWork Dir ]
        
        $successfileresponse        =       true;
        
        $response 	=	array(  
                                        'status'    =>  1   ,
                                        'msg'   =>  'Success' , 
                                        'errMsg'   =>  'ftp request successfully' , 
                                        'params'    =>  array( 'token_key' => $token_key )
                                     );
        
        if( !$successfileresponse ){
            
            //update is active to false for invalid request
            $inpArr     =       array();
            $records            =       $api_pft->getApiRequest( $job_id , $round  , $token_key );
            $rowid              =       $records->ID;
            $inpArr =   array( 'END_TIME'   => date( 'Y-m-d H:m:i' ) , 'IS_ACTIVE' => 0 , 'REMARKS' => 'file transfer failed .');
            $api_pft->updateIfExist($inpArr, $rowid);
            $response 	=	array(  
                                        'status'    =>  0     ,
                                        'msg'   =>  'Failed' , 
                                        'errMsg'   =>  'file transfer failed' ,
                                        'params'   => array( 'token_key' => '' )
                                     );
         
        }
       
        return $response;
        
    }
   
    public function splitInputFileDownload( Request $request ){
        
       
        $input_params       =       $request->all();
        $job_id             =       $input_params['job_id'];
        $src_path           =       ( $input_params['src_path'] ) ;
        $dest_path          =       ( $input_params['dest_path'] ) ;
        $tokenkey           =       $input_params['tokenkey'];
        
        //need to dynamicaly bind the production location based on table location
        
        //$host       =     Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_HOST');
        //$usr        =     Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_USERNAME');
        // $psw        =     Crypt::decryptString(Config::get('constants.JOBSHEET_RAW_LOCATION.FTP_PASSWORD'));
        //$crd        =     Config::get('constants.FILE_SERVER_CREDENTIALS'); 
	
        $getlocationftp     =           productionLocationModel::doGetLocationname( $job_id );

        //need to dynamicaly bind the production location based on table location

        $host   =   $hostserver         =       $getlocationftp->FTP_HOST;
        $usr    =   $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $psw        =   $hostpassword       =       Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath           =       ( $getlocationftp->FTP_PATH );
        $crd        =       'ftp://'.$usr.':'.$psw.'@'; 
        
        $api_rec        =       DB::table('api_production_file_transfer')->select()->where( 'TOKEN_KEY' , 'LIKE' , '%'.$tokenkey.'%')->get()->first();
        
        if( empty( $api_rec ) ){
            return response()->json( array( 'status' => 0 ,  'msg'=> 'Invalid try, try again after sometimes') );
        }
        
        try{
            
            if( $api_rec->STATUS !== 2 ) {
                $ftpObj         =       new ftpFileHandlerController($host, $usr, $psw);
                $response       =       $ftpObj->ftp_dir_copy( $crd.$src_path , $dest_path );
            }else{
                $response    =   array('success');
            }
            
        } catch (Exception $ex) {
            
            $response   =   array(
                                'status' => 0, 
                                'msg'   => 'Failed' ,  
                                'errMsg'    => $ex->getMessage()
                                );
                
            return response()->json( $response,400 );
            
        }
        
        if( in_array( 'failed' , $response ) ){
            
            foreach ($response as $key => $value ){
                if( $value == 'success' ){
                    unset( $response[$key] );
                }
            }
            
            $response   =       array( 'status' => 'failed'  , $response );
            
        }else{
            
            //$tokenkey
            $setArr     =   array( 'STATUS' => 2 );
            $updateQry  =   DB::table('api_production_file_transfer')
			->where('TOKEN_KEY', $tokenkey )
			->update( $setArr );
            
            $response    =       array( 'status' => 'success' , $response );
            
        }
        
        return response()->json($response);
        
    }
    
    /*
     * parameters are 
    */
    
    public function inputFileDownload( Request $request ){
        
        $input_params       =       $request->all();
        
        $jobId      =       $job_id       =       $input_params['job_id'];
        
        $src_path           =       ( $input_params['src_path'] ) ;
        $dest_path          =       ( $input_params['dest_path'] ) ;
        
        //need to dynamicaly bind the production location based on table location
        
        $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
        
        $host   =   $hostserver         =       $getlocationftp->FTP_HOST;
        $usr    =   $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $psw    =   $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        
        $hostpath           =       ($getlocationftp->FTP_PATH);
        $crd                =       'ftp://'.$usr.':'.$psw.'@';   
        
	try{
            
            $ftpObj         =       new ftpFileHandlerController($host, $usr, $psw);
            $response       =       $ftpObj->ftp_dir_copy( $crd.$src_path , $dest_path );
            
        } catch (Exception $ex) {
            
            $response   =   array(
                                'status' => 0, 
                                'msg'   => 'Failed' ,  
                                'errMsg'    => $ex->getMessage()
                                );
                
            return response()->json( $response );
            
        }
        
        if( in_array( 'failed' , $response ) ){
            
            foreach ($response as $key => $value ){
                if( $value == 'success' ){
                    unset( $response[$key] );
                }
            }
            
            $response   =       array( 'status' => 'failed'  , $response );
            
        }else{
            $response    =       array( 'status' => 'success' , $response );
        }
        
        return response()->json($response);
        
    }
    
    public function copyjobsheetTest(){
        
      $jobsheet =     $this->copyJobsheet('6484','114','468937_1_En');
      echo "<pre>";print_r($jobsheet);exit;
    }
    
    
    public function copyProcessJobsheet($jobId, $round, $bookId,$processType,$backup=1) {
        
        try{
        $rawPath            =       \Config::get('serverconstants.RAW_PATH');
        $jobSheetPath       =       \Config::get('serverconstants.JOBSHEET_PATH');
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $jobSheetfile       =       \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $jobSheetBackup     =       \Config::get('constants.JOBSHEET_BACKUP_FOLDER');
        $locationFlag		=		1;
        
        $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
        
        if( empty( $getlocationftp ) ){
            $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
            $locationFlag       =		0;
            $getlocationftp->FTP_PASSWORD   =   \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
        }
		
        if(is_object($getlocationftp)){
            $getlocationftp   =    (array) $getlocationftp;
        }
        
        $ftpObj             =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
    
        if($locationFlag == 0){
            $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
            $sourcepathwithoutip    =   $getlocationftp['FTP_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        }else{
            $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
            $sourcepathwithoutip    =   $getlocationftp['FTP_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        }
	
        if($backup == '2'){
			$sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
            $sourcepathwithoutip    =   $getlocationftp['FTP_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
		}
		
        $descPath           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$processType.'/'.$bookId.$jobSheetfile[$round];
        $descPathHost       =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$processType.'/'.$bookId.$jobSheetfile[$round];
      
   
        //$backupDir          =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
       
        $descPathDir        =       $getlocationftp['HOST_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$processType.'/';
        $descCopyPathDir    =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$processType.'/';
        $filecopy           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
		
        //$descPathDir  = '/SP_BOOKS/JOBSHEET/468864_1_En/S5/RECEIPT/';
       
        $ftpObj->ftp_make_dir($descPathDir);
        $status                 =    $ftpObj->ftp_file_exist($sourcepathwithoutip);
        
        if($status  ==  true){
            $content            =   file_get_contents($sourcePath);
            if(!empty($content)) {
                if($backup == 1 || $backup == 2){
                    $DesfileExistPath       =   str_ireplace($getlocationftp['HOST'],'',$descPathHost);
                    
                    $status                 =    $ftpObj->ftp_file_exist($DesfileExistPath);
                    if($status == true){
                         $backupDir          =   $descPathDir.$jobSheetBackup;

                         $datetime           =   date('Y-m-d H-i-s');
                         $backupDir         .=   $datetime;
                         
                         $statu             = $ftpObj->ftp_make_dir($backupDir);
                         $content2            =   file_get_contents($descPath);

                         if(!empty($content2)){

                             $backupCopy           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$processType.'/'.$jobSheetBackup.$datetime.'/'.$bookId.$jobSheetfile[$round];


                             $state                 =        $ftpObj->ftp_file_put($backupCopy,$content2);
                         }
                    }
                }

                $response           =   $ftpObj->ftp_file_put($descPath,$content);

            }
        }else{
            return false;
        }
        
       }catch( \Exception $e ){
		  
		   
           return $e->getMessage();
       }
       
        return true;
       
    }
    
     public function copyChapterLevelProcessJobsheet($jobId, $round, $bookId,$chapterName,$processType) {
         
        try{
			
        $backup             =       1;
        $rawPath            =       \Config::get('serverconstants.RAW_PATH');
        $jobSheetPath       =       \Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $jobSheetfile       =       \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $jobSheetBackup     =       \Config::get('constants.JOBSHEET_BACKUP_FOLDER');
       
          $locationFlag		=		1;
        $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
        $cmn_obj                =       new CommonMethodsController();
        
        if( empty( $getlocationftp ) ){
            $locationFlag           =       0;
            $getlocationftp         =       productionLocationModel::getDefaultProductionLocationInfo();
            $getlocationftp->FTP_PASSWORD   =   \Crypt::decryptString( $getlocationftp->FTP_PASSWORD);
        }
        $getlocationftp  = (array)$getlocationftp;
        
       
        $chapterNos                 = 	explode('_',$chapterName) ;
        $chapterIdOnly              =	$chapterName;

        if(isset($chapterNos['1']) && !empty($chapterNos['1'])){
            $chapterIdOnly          =   $chapterNos['1'];
        }
        
        
       $jobsheetFileName        =    $bookId.'_'.$chapterIdOnly.$jobSheetfile[$round];
       
        $ftpObj             =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
        $ftpObj2             =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
        
        $inp_rep_arr        =       array('{BID}' => $bookId ,'{CID}' =>$chapterName,'{RID}'=>$round_arr[$round]);
        $jobSheetPath         =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $jobSheetPath );
		
        $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$chapterName.'/'.$jobsheetFileName;
       
        $descPath           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$processType.'/'.$jobsheetFileName;
        
        $descPathHost       =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$processType.'/'.$jobsheetFileName;
		
        $descPathDir        =       $getlocationftp['HOST_PATH'].$jobSheetPath.$processType.'/';
	   
        $descCopyPathDir    =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$processType.'/';
     
        $ftpObj->ftp_make_dir($descPathDir);
        
        $content            =   @file_get_contents( $sourcePath );
		
        if( empty( $content ) ){

            if( $round == 116 ){
                $rawPath	=	'JOBSHEET/';
            }
            $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$chapterName.'/'.$jobsheetFileName;
            if( $round == 119 ){
                $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/S300/'.$chapterName.'/'.$jobsheetFileName;
            }
            
            $content            =   	file_get_contents( $sourcePath );

        }
		
        if(!empty($content)) {
            if($backup == 1){
                $DesfileExistPath       =   str_ireplace($getlocationftp['HOST'],'',$descPathHost);
               
                $status                 =    $ftpObj->ftp_file_exist($DesfileExistPath);
                if($status == true){
                     $backupDir          =   $descPathDir.$jobSheetBackup;
                 
                     $datetime           =   date('Y-m-d H-i-s');
                     $backupDir         .=   $datetime;

                     $statu             = $ftpObj->ftp_make_dir($backupDir);
                     $content2            =   file_get_contents($descPath);
                   
                     if(!empty($content2)){
                       
                         $backupCopy           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$processType.'/'.$jobSheetBackup.$datetime.'/'.$jobsheetFileName;;
                                               
                         $state                 =        $ftpObj->ftp_file_put($backupCopy,$content2);
						 
                     }
                    }
            }
            
            $response           =   $ftpObj->ftp_file_put($descPath,$content);
			
			
        }
       }catch( \Exception $e ){
		   
           return $e->getMessage();
		   
       }
       
        return true;
       
    }
    
    
    public function copyJobsheet($jobId, $round, $bookId,$backup=0) {
        
        
        $rawPath            =       \Config::get('serverconstants.RAW_PATH');
        $jobSheetPath       =       \Config::get('serverconstants.JOBSHEET_PATH');
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $jobSheetfile       =       \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $jobSheetBackup     =       \Config::get('constants.JOBSHEET_BACKUP_FOLDER');
                
        $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
        
        if( empty( $getlocationftp ) )
                $getlocationftp     =       productionLocationModel::getDefaultProductionLocationInfo();
        
       
        $ftpObj             =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
        $ftpObj2             =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
    
       // echo "<pre>";print_r($getlocationftp);exit;
        $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        $descPath           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        $descPathHost       =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        
       
        //$backupDir          =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
       // echo $descPathHost;exit;
        $descPathDir        =       $getlocationftp['HOST_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/';
        $descCopyPathDir    =       $getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/';
        $filecopy           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
        
        $ftpObj->ftp_make_dir($descPathDir);
        $content            =   file_get_contents($sourcePath);
        if(!empty($content)) {
            if($backup == 1){
                $DesfileExistPath       =   str_ireplace($getlocationftp['HOST'],'',$descPathHost);
                $status                 =    $ftpObj->ftp_file_exist($DesfileExistPath);
                if($status == true){
                     $backupDir          =   $descPathDir.$jobSheetBackup;
                     $datetime           =   date('Y-m-d H-i-s');
                     $backupDir         .=   $datetime;

                     $statu             = $ftpObj->ftp_make_dir($backupDir);
                     $content2            =   file_get_contents($descPath);
                     if(!empty($content2)){
                         $backupCopy           =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$jobSheetBackup.$datetime.'/'.$bookId.$jobSheetfile[$round];
                         $state                 =        $ftpObj->ftp_file_put($backupCopy,$content2);
                     }
                    }
            }
            
            $response           =   $ftpObj->ftp_file_put($descPath,$content);
        }
       
        return true;
       
    }
    
    public function copyJobsheetForOfSeries($rec,$jobDetails) {
        
        $jobId              =      $rec->JOB_ID;
        $round              =      $rec->ROUND;
        $bookId             =      $jobDetails->BOOK_ID;
        $metaId             =      $rec->METADATA_ID;
        $rawPath            =       \Config::get('serverconstants.RAW_PATH');
        $jobSheetPath       =       \Config::get('serverconstants.JOBSHEET_PATH');
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $jobSheetfile       =       \Config::get('constants.JOBSHEET_SUFFIX_CONVENTION');
        $copyEdingPreprocess=       \Config::get('serverconstants.S50_COPY_EDITING_PATH');
        $defaultProductionLocation  = \Config::get('constants.DEFAULT_PRODUCTION_LOCATION');
        $chapterJobsheetPath        =  \Config::get('serverconstants.PRODUCTION_CHAPTER_JOBSHEET_PATH');
        $cmn_obj                =       new CommonMethodsController();
        
        $metaModelObj               =   taskLevelMetadataModel::where('METADATA_ID',$metaId)->first();
        
       // $metaDetails                =   $metaModelObj->getMetadatadetailsChapter($metaId);
        $chapterId                  =   $metaModelObj->CHAPTER_NO;
		$chapterNos                 = 	explode('_',$metaModelObj->CHAPTER_NO) ;
		$chapterIdOnly 				=	$chapterId;
        
		if(isset($chapterNos['1']) && !empty($chapterNos['1'])){
            $chapterIdOnly          =   $chapterNos['1'];
	    }
        
        $jobLocation   =    $getlocationftp     =       productionLocationModel::getJobLocationServerPath( $jobId );
        
        if(empty($getlocationftp)){
            $getlocationftp     =      (array) productionLocationModel::getJobLocationServerPathWithDefaultProductionLocation( $jobId, $defaultProductionLocation);
        }
        $ftpObj                 =       new ftpFileHandlerController($getlocationftp['HOST'],$getlocationftp['FTP_USERNAME'],$getlocationftp['FTP_PASSWORD']);
      
       // $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$rawPath.$bookId.'/'.$round_arr[$round].'/'.$bookId.$jobSheetfile[$round];
     
        $sourcePath         =       $getlocationftp['SERVER_PATH'].$copyEdingPreprocess;
        $inp_rep_arr        =       array('{BID}' => $bookId ,'{CID}' =>$chapterId,'{RID}'=>$round_arr[$round]);
        $sourcePath         =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $sourcePath );
        $sourcePath         =       $getlocationftp['FTP_PATH_CREDENTIAL'].$sourcePath;
       // echo $sourcePath;exit;
        $fileList           =       $ftpObj->getDirectoryFiles($sourcePath);
        $sourceJobsheetPath =   '';
        
        foreach($fileList as $key=>$data){
           $exData  =    explode('/',$data);
		   $pos     =    strpos(end($exData),'JobSheet_200' );
           if ($pos !== false) {
               $sourceJobsheetPath = $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['HOST'].$data;
			 
           } 
        }
		
		
	
        if(!empty($sourceJobsheetPath)){
            $content                    =   file_get_contents($sourceJobsheetPath);
			
            $rawJobsheetPath            =   $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round].'/'.$chapterId.'/'.$bookId.'_'.$chapterIdOnly.$jobSheetfile[$round];
			$rootFolder					=	 $getlocationftp['HOST_PATH'].$jobSheetPath.$bookId.'/'.$round_arr[$round];
			$ftpObj->ftp_make_dir($rootFolder);
			
            $rawPath                    =   $ftpObj->ftpSingleFileCopyOrMove($sourceJobsheetPath,$rawJobsheetPath);
          
            $chapterFolderPath          = $chapterJobsheetPath        =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $chapterJobsheetPath );
            $chapterJobsheetPath        =   $getlocationftp['FTP_PATH_CREDENTIAL'].$getlocationftp['SERVER_PATH'].$chapterJobsheetPath.$bookId.'_'.$chapterIdOnly.$jobSheetfile[$round];
		
            //$rootFolder					=	$chapterFolderPath;

            $folderPath					=	array_filter(explode('/',$chapterFolderPath));

            $folderPath1					=	$getlocationftp['HOST_PATH'];
            foreach($folderPath as  $key => $folder){
                    $folderPath1 .= $folder.'/';
                    $ftpObj->ftp_make_dir($folderPath1);

            }
			
            $jobsheetPath               =   $ftpObj->ftpSingleFileCopyOrMove($sourceJobsheetPath,$chapterJobsheetPath);
           
            if(!empty($jobLocation)){
                sleep(40);
                $MeUpdateObj                =  new  MetaExtractorController();
                $MeUpdateObj->sendInputForJobsheetUpdate( $jobId , $round , 'RECEIPT' , $metaId  );
            }
        }
       
        return true;
       
    }
    
    public function chapterFileDownload( $job_id , $round ,$chapterNo,$metaId){
        
        $bookdetaills       =       jobModel::getJobdetailsRawQuery( $job_id,'job.BOOK_ID' );
        $bookid             =       (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
        $base_url           =       \Config::get('constants.BASE_URL');
        
        $input_arr          =       array( 
                                            'book_id'   =>    $bookid, 
                                            'filepath'   =>  '' , 
                                            'callbackUrl'   =>  $base_url.'/api/productionFileTransferCallback'
                                        );
        
        $table_name         =       'api_production_file_transfer';
        $jobId              =       $job_id;
        $book_id            =       $input_arr['book_id'];
        $ret_url            =       $input_arr['callbackUrl'];
        $file_copy_to       =       '';
        $locationFlag       =       1;
        $getlocationftp     =           productionLocationModel::doGetLocationname( $jobId );
        
        if( empty( $getlocationftp ) ){            
                $getlocationftp  =       productionLocationModel::getDefaultProductionLocationInfo();
                $locationFlag    =      0;
        }

        //need to dynamicaly bind the production location based on table location
        $hostserver         =       $getlocationftp->FTP_HOST;
        $hostusername       =       $getlocationftp->FTP_USER_NAME;
        if($locationFlag == 0){
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        }else{
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        }
        $hostpath           =       ($getlocationftp->FTP_PATH);

        $production_file_server_ip  =   $hostserver.$hostpath;
        $cn_user        =       $hostusername;
        $cn_pass        =       $hostpassword;
        $credentials    =       '<>'.$cn_user.'<>'.$cn_pass;
        $root           =       Config::get('constants.FILE_SERVER_ROOT_DIR');
        
        $s50Round       =       Config::get('constants.JOB_ASSIGNED_CONST');
        $roundname_arr  =       \Config::get('constants.ROUND_NAME');
        $roundname      =       $roundname_arr[$round];
        
        $rawpath        =       Config::get('serverconstants.S50_COPY_EDITING_PATH');
        $file_copy_to           =       $hostserver.$root.$hostpath.$rawpath;
        
		/*
			if( $roundname == 'S300' ){
				$jbstsrawpath   =       \Config::get('dynamicConstant.JOBSHEET_RAW_VIEW_PATH.S300'); 
				$rawpath        =        $jbstsrawpath;
				$file_copy_to           =       $hostserver.$root.$rawpath;
			}
        */
		
        $cmn_obj                =       new CommonMethodsController();
        $inp_rep_arr            =       array(
                                            '{BID}' => $book_id , '{RID}' => $roundname , '{CID}' =>    $chapterNo , 
                                            'BOOK_ID' =>  $book_id  , 'ROUND_NAME' => $roundname , 'CID' => $chapterNo
                                        );
        
        $file_copy_to           =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $file_copy_to );
        $file_copy_to           =   str_ireplace('//','/',$file_copy_to);
       
        $file_copy_to           =       str_replace( '//' , '/' , $file_copy_to );
        $file_copy_to           =       str_replace( '/' , '\\' , $file_copy_to );            
        $file_copy_to           =       '\\\\'.$file_copy_to;
        $status  = 0;
        
        try{            
            
            $token_key      =      $cmn_obj->generateRandomString( 16 , $table_name  );
            $api_link           =        \Config::get('constants.PRODUCTION_TOOLS_SETUP.PRODUCTION_FILE_TRANSFER_API_ASYNC');
            $project_type       =       'BWF';   
            
            if(!empty($metaId)){
                $getBookzip     =   DB::table('api_download')->select()->where( 'BOOK_ID' , $book_id  )->where('METADATA_ID' , $metaId )->orderBy('ID', 'desc')->first();
            }else{
                $getBookzip     =   DB::table('api_download')->select()->where( 'BOOK_ID' , $book_id  )->orderBy('ID', 'desc')->first();
            }
            
            $roundname_arr    =   \Config::get('constants.ROUND_NAME');
            $roundname    =   $roundname_arr[$round];
          
            $input_arr          =       array( "{$project_type}BookID"  =>   $book_id ,
                                            'Stage'     =>  $roundname , 
                                            'Filename'  =>   $getBookzip->FILE_NAME  ,  //'BookTitleID=393764_EditionNumber=1_Language=En_2017-12-29_08-31-07.zip', 
                                            'FileServerPath'    =>  $file_copy_to ,
                                            'WorkflowAPI'       =>  array(
                                                                'Url'   =>  $ret_url , 
                                                                'parameter' => array( 
                                                                                        array( 'key' => 'process' , 'value'=> 'production_file_copy' , 'type' => 'fixed' ) ,  
                                                                                        array( 'key' => 'tokenkey' , 'value'=> $token_key , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'jobid' , 'value'=> $job_id , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'bookid' , 'value'=> $book_id , 'type' => 'fixed'  ) , 
                                                                                        array( 'key' => 'round' , 'value'=> $round , 'type' => 'fixed' ) , 
                                                                                        array( 'key' => 'status' ,  'type' => 'boolean' ) , 
                                                                                        array( 'key' => 'remarks' ,  'type' => 'string' ) , 
                                                                                        array( 'key' => 'endtime' ,  'type' => 'data-time' , 'value' => 'yyyy-MM-dd HH-mm-ss' ) 
                                                                                )
                                                            )   
                                        );

            
            $curl       =       $api_link;
            $data       =       $input_arr;
            $status     =       0;
            
            //insert to api table - 
            $api_pft    =       new apiProductionFileTransfer();
            $inp_arr    =       array( 
                                        'TOKEN_KEY'     => $token_key , 
                                        'PROCESS_NAME'  => 'CHAPTER_FILE_DOWNLOAD' , 
                                        'JOB_ID'        =>  $job_id , 
                                        'METADATA_ID'   =>  $metaId,
                                        'ROUND'     =>  $round , 
                                        'START_TIME' => date( 'Y-m-d H:m:i' ) , 
					'STATUS'	=> 1
                                    );
        
            $api_pft->insertNew($inp_arr);
            
            Log::useDailyFiles(storage_path().'/Api/production_file_trans_input.log');
            Log::info( json_encode($data) );
     
            $api_response           =       $cmn_obj->RestfulPostcUrlExecution( json_encode( $data ) , $curl,"" );
            $code       =       ( $api_response['http_code'] );
            $msg        =       '';
            $errMsg     =       '';

            if( $code == 200 ){
                
                $status      =    ( $api_response[0]  == 'Success' )  ? 1 : 0;
                $msg         =      'Request send successfully';
                
            }else{
                
                $inpArr['STATUS']       =       0;
                $inpArr['END_TIME']     =       date( 'Y-m-d H:m:i' );
                $errMsg =   'Webservice is not available..';
                $inpArr['REMARKS']      =       $errMsg;
                
                
                $rec        =       $api_pft->getApiRequest( $jobId , $round , $token_key );
                $rowid      =       $rec->ID;
               
                $api_pft->updateIfExist($inpArr, $rowid);
                throw new \Exception( $errMsg );
                
            }

            $response 	=	array( 'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  $errMsg );
        
        }catch(\Exception $e) {
        
            $errMsg    =   $e->getMessage();
            $msg        =   '';
            $response 	=	array(  'status' => $status  , 'msg'=> $msg  , 'errMsg' =>  $errMsg );
          
        }
        
       return $response;
        
   }
   
   
   
	public function testFileCopy( $metaid = null , $round = null , $jbstgid = null ){
		
		
		$filServic				=		new fileManagerServiceController( $metaid, $round , $jbstgid );
		
		
		
		$fileCopyPath['src']    =   	array( 
												   array('path' => \Config::get('constants.PACKAGE_PATH.XMLFILE'), 'mandatory' => 'Y' ) ,  
												   array('path' => \Config::get('constants.PACKAGE_PATH.PITSTOPSTOPFILE') , 'mandatory' => 'Y') , 
												   array('path' => \Config::get('constants.PACKAGE_PATH.DELTAPDFFILE') , 'mandatory' => 'N'), 
												   array('path' => \Config::get('constants.PACKAGE_PATH.AUTHORPDFLOCATION') , 'mandatory' => 'N'), 
												   array('path' => \Config::get('constants.PACKAGE_PATH.PROOFPDFFILE') , 'mandatory' => 'N' ), 
												   array('path' => \Config::get('constants.PACKAGE_PATH.PDFFILE') , 'mandatory' => 'Y' ), 
												   array('path' => \Config::get('constants.PACKAGE_PATH.PAGECOUNT') , 'mandatory' => 'Y' ), 
												   array('path' => \Config::get('constants.PACKAGE_PATH.METAPDFLOCATION') , 'mandatory' => 'Y' ), 
												);
		$fileCopyPath['dest']   =   	array( 
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}.xml' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_OnlinePDF_log.pdf' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_delta.pdf' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_Author.pdf' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_ProofFeedback.pdf' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_OnlinePDF.pdf' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_pgcount.xml' ) ,
										   array( 'path' => \Config::get( 'constants.PAGINATION_FILEPATH.S200' ).'{PAGING_FILENAMING}_MetaPDF.xml' ) ,
										);
		
		$status   = $filServic->fileCopy( $fileCopyPath );
		
		dd( $status );
		
	}
   
}