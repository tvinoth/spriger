<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiMetaExtractor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\MetaExtractorController;
use App\Http\Controllers\taskLevelMetadataController;
use App\Http\Controllers\customization\customizationController;
use App\Models\stageManager;
use App\Models\customizationModel;


#use Ixudra\Curl\Facades\Curl;
#use Ixudra\Curl\CurlService;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
use Carbon\Carbon;

ini_set('max_execution_time', 300);

class correctionDownloadController extends Controller
{
    
    public function storeResponse(Request $request) {
        
        try{
            
            $inputarr           =       json_decode( $request->getContent() );
            $jobSheetResponse   =       array();
            $filteredInp        =       (array)$inputarr->Download;
            
            Log::useDailyFiles(storage_path().'/Api/correction_download.log');
            Log::info( json_encode( $inputarr) );
            $rules['BookID']            =       'required';
            $rules['FileName']          =       'required';
            $rules['StartDate']         =       'required';
            $rules['EndDate']           =       'required';
            $rules['ProcessType']       =       'required';
            $rules['Remarks']           =       'required';
            $rules['Status']            =       'required';

            $response['status']         =       0;
            $response['msg']            =       'Failed';
            $response['errMsg']         =       'Try again after sometimes';

            $validator                  =       Validator::make( $filteredInp , $rules );
     
            if ($validator->fails()) {
                $response['errMsg']  =       'Required field validation error occured.';
            }else{   
                
                $response['status']      =       1;
                $response['msg']         =       'Success';
                $response['errMsg']      =       'Successfully received';
            
                $extractorCntrl         =        new \App\Http\Controllers\Api\MetaExtractorController();
                $extractorCntrl->sendInputForJobsheetUpdate( 6391 , 118 , 'CORRECTION' , 3194 );
                
            }

        }catch( \Exception $e ){
            
            $response['status']      =       0;
            $response['msg']         =       'Error';
            $response['errMsg']      =       $e->getMessage();
            
        }
        
        return json_encode( $response );
             
    }
    
    
}
