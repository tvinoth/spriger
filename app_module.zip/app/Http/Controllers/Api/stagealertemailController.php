<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\jobModel;
use App\Models\stageModel;
use App\Models\roundModel;
use App\Models\checkoutModel;
use App\Models\emailSetupStagewiseModel;
use App\Models\taskLevelMetadataModel;
use App\Models\magnusMailLogModel;
use App\Http\Controllers\CommonMethodsController;
use App\Jobs\StageemailAlert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Session;
use Storage;
use Carbon\Carbon;
use Validator;
use File;
use Mail;
use DB;
use Log;
use Config;

class stagealertemailController extends Controller
{   
    public function doSendemailalertstage($jobID,$roundID,$stageID,$chapterID   =   '' , $status_str = 'success' )
    {
         $result         =   array('result'=>1,'errMsg'=>'Email send successfully');   
                return response()->json($result);
        try{
            $data               =   array();
            $data['pageTitle']  =   'INDEXING';
            $data['user_name']  =   Session::get('users')['user_name'];
            $data['role_name']  =   Session::get('users')['role_name'];
            $bookdata           =   jobModel::getjobalertemailInfodetails($jobID,$roundID,$stageID);
            $wheredata          =   [];
            $wheredata['ROUND_ID']  =   $roundID;
            $wheredata['STAGE_ID']  =   $stageID;
            if($chapterID !=    '' && $chapterID != 0){
                $chapterinfo    =   taskLevelMetadataModel::select(DB::Raw('CHAPTER_NO,metadata_info.FM_ARTICLE_BM'))->join('metadata_info','metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')->where('task_level_metadata.METADATA_ID',$chapterID)->first();
                // check if chapter exist or not
                if($chapterinfo     ==  null){
                    $result         =   array('result'=>500,'errMsg'=>'No data found...');   
                    return response()->json($result);
                }
                $componentId    =   "";
                switch($chapterinfo->FM_ARTICLE_BM){
                    case 1:
                        $componentId    =   1;
                        break;
                    case 2:
                        $componentId    =   2;
                        break;
                    case 3:
                        $componentId    =   4;
                        break;
                    case 4:
                        $componentId    =   3;
                        break;
                    default:
                        $componentId    =   1;
                        break;
                }
                $wheredata['COMPONENT_TYPE_ID']  =   $componentId;
            }
            
            $checkemailtempconfi=   emailSetupStagewiseModel::Active()->where($wheredata)->first();
            $getstageinfodata   =   checkoutModel::getStageInfo($stageID);
            if(count($bookdata)>=1 && $checkemailtempconfi != null)
            {
                $getchapterType     =   $checkemailtempconfi->COMPONENT_TYPE_ID;
                $data               =   [];
                $bookid             =   $bookdata[0]->BOOK_ID;
                $data['pageName']   =   $bookdata[0]->STAGE_NAME.' - '.$bookdata[0]->BOOK_ID;
                $data['jobid']      =   $jobID;
                $data['chapid']     =   $chapterID;
                $data['roundid']    =   $roundID;
                $data['Title']      =   $checkemailtempconfi->EMAIL_SUBJECT." - ".$bookdata[0]->STAGE_NAME.' Completed';
                $data['bodycontent']    =   '';
                $mailArray['TemplateName']  =   'emailtemplate.stagecompleteemailalert.stagecompleted-emailalert';
                $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
                $mailArray['Subject']       =   $checkemailtempconfi->EMAIL_SUBJECT;
                //get pm mail id
                $pmid               =   $bookdata[0]->PM;
                $pmmailid[]         =   $bookdata[0]->EMAIL;
                
                if(strpos($checkemailtempconfi['TO_EMAIL'],',') !==  false)
                {
                    $toemailarray           =   explode(',',$checkemailtempconfi['TO_EMAIL']);
                    $mailArray['ToMail']    =   array_merge($toemailarray,$pmmailid);
                }else{
                    $mailArray['ToMail']    =   array_merge($pmmailid,[$checkemailtempconfi['TO_EMAIL']]);
                }
                
                if(strpos($checkemailtempconfi['CC_EMAIL'],',') !==  false)
                {
                    $ccemailarray           =   explode(',',$checkemailtempconfi['CC_EMAIL']);
                    $mailArray['CcMail']    =   $ccemailarray;
                }else{
                    $mailArray['CcMail']    =   (array)$checkemailtempconfi['CC_EMAIL'];
                }
//                if(!is_array($mailArray['CcMail']))
//                {
//                    $mailArray['CcMail']    =   (array)$checkemailtempconfi['CC_EMAIL'];
//                }
//                //ART team email merge
//                $artteam_email              =   config::get('constants.STAGE_ALERT_EMAIL.ART_TEAM');
//                //CE team email merge
//                $ceteam_email               =   config::get('constants.STAGE_ALERT_EMAIL.CE_TEAM');
//                //Indexing team email merge
//                $indexingteam_email         =   config::get('constants.STAGE_ALERT_EMAIL.INDEXING_TEAM');
//                $mailArray['CcMail']        =   array_merge($mailArray['CcMail'],$artteam_email,$ceteam_email,$indexingteam_email);
                $mailArray['ToMail']        =   array_unique($mailArray['ToMail']);
                $mailArray['CcMail']        =   array_unique($mailArray['CcMail']);
                if(in_array('',$mailArray['CcMail'])){
                    unset($mailArray['CcMail']);
                }
                if(empty($chapterID) && count($getstageinfodata)>=1){
                    $chapterID      =   $getstageinfodata[0]->METADATA_ID;
                }
                $filepathloc        =   $checkemailtempconfi->EMAIL_TEMP_PATH;
                if(file_exists(public_path().'/'.$filepathloc)){
                    $logfiles       =   file_get_contents(public_path().'/'.$filepathloc );
                    $bodycontent    =   stripslashes(nl2br($logfiles));
                    $data['bodycontent']    =   $this->docontentreplaceoriginalinfo($bookdata,$chapterID,$bodycontent);
                }
                $mailArray['Data']          =   $data;
//                $emailJob = (new StageemailAlert($mailArray));
//                dispatch($emailJob);
//                StageemailAlert::dispatch($mailArray);
                if(count($mailArray['ToMail']) !=   0){
                    $this->doemailsentemp($mailArray);
                }
                $result         =   array('result'=>1,'errMsg'=>'Email send successfully');   
                return response()->json($result);
//                return view('emailtemplate.stagecompleteemailalert.stagecompleted-emailalert')->with($data);
            }
            $result         =   array('result'=>500,'errMsg'=>'No data found...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>$e->getMessage());   
            return response()->json($result);
        }
    }
    public function docontentreplaceoriginalinfo($bookdata,$chapterID,$bodycontent)
    {
        $chapterno          =   "";
        if(!empty($chapterID))
        {
            $chapterinfo    =   taskLevelMetadataModel::where('METADATA_ID',$chapterID)->first();
            $chapterno      =   (count($chapterinfo)>=1?$chapterinfo->CHAPTER_NO:'');
        }
        $inp_rep_arr        =   array( 
                                        '[bookid]'      =>      $bookdata[0]->BOOK_ID , 
                                        '[to_name]'     =>      $bookdata[0]->PM_NAME ,
                                        '[contact_personname]'     =>      Config::get('constants.CLIENTNAME') ,
                                        '[chapter_no]'  =>      $chapterno,
                                        '[stage_name]'  =>      $bookdata[0]->STAGE_NAME,
                                        '[round_name]'  =>      $bookdata[0]->NAME,
                                        '[am_name]'     =>      $bookdata[0]->AM_NAME,
                                        '[pm_name]'     =>      $bookdata[0]->PM_NAME,
                                    );
        
        
        $cmn_obj        =       new CommonMethodsController();
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $bodycontent ); 
    }
    
    public function doemailsentemp($mailArray)
    {
        if (is_array($mailArray)) {
            $mailArray  =   $mailArray;
            $insertdata['JOB_ID']       =   $mailArray['Data']['jobid'];
            $insertdata['METADATA_ID']  =   $mailArray['Data']['chapid'];
            $insertdata['ROUND_ID']     =   $mailArray['Data']['roundid'];
            $insertdata['MAIL_TYPE']    =   'STAGEALERT';
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }
                if (array_key_exists('file', $mailArray)) {
                    $message->attach($mailArray['file'],$mailArray['attachfile']);
                }                
                $message->getSwiftMessage();
            });
            
            $insertdata['JOB_ID']       =   $mailArray['Data']['jobid'];
            $insertdata['METADATA_ID']  =   $mailArray['Data']['chapid'];
            $insertdata['ROUND_ID']     =   $mailArray['Data']['roundid'];
            $insertdata['MAIL_TYPE']    =   'STAGEALERT';
            
            if (Mail::failures()) {
                $Response['Status']     =   2;
                $Response['Msg']        =   'Failure';
                $Response['MsgText']    =   Mail::failures();
                $insertdata['MAIL_SENT']    =   '0';
                magnusMailLogModel::insertGetId($insertdata);
            } else {
                $Response['Status']     =   1;
                $Response['Msg']        =   'Success';
                $insertdata['MAIL_SENT']    =   '1';
                magnusMailLogModel::insertGetId($insertdata);
            }
            return $Response;
        }
    }
}