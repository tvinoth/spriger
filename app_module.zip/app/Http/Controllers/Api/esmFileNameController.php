<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiReferencePdfModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Models\jobsheetViewpathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class esmFileNameController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_esm_filename';
    public $apiModel        =       'apiReferencePdfModel';
    public  $common_obj;
    public function __construct()
    {
        parent::__construct();
        $this->cmn_obj      =       new CommonMethodsController();
    }
    
    public function customConstructor( $jobid , $metaId){ 
        
        $checkoutObj        =   new jobModel();
        $metaDeatilsObj     =   new taskLevelMetadataModel();
        $stageDetails       =   $checkoutObj->getJobdetails($jobid);
        $metaDetailsful     =   $metaDeatilsObj->getMetadatadetailsChapter($metaId);
        $metaDetails          =    ($metaDetailsful != null?$metaDetailsful['0']:[]);
        if(count($stageDetails) == 0){
            return array();
        }
        $jobshhet_obj       =   new jobrevisedController();
        $jbstg_rec      =       $stageDetails;
        $metainfo   =   [];
        $jobshhet_obj->jobSheetReturn($jobid , $metaId , $stageDetails , $metaDetails,$metainfo);
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['round']          =       '104';
        $metainfo['metaid']         =       $metaId;
        $metainfo['chapterno']      =       $metaDetails->CHAPTER_NO;
        $metainfo['chaptername']    =       $metaDetails->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['stageid']        =       config::get('constants.STAGE_COLLEECTION.ESM_FILE_NAME');
        $metainfo['emsval_tags']   =       2;
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
        if(!empty($getlocationftp )){
            $getlocationftp->FTP_PASSWORD  = \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
                        
        }
        
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        $this->ftpInfo              =       $getlocationftp;
        $this->tokenkey             =       $this->cmn_obj->generateRandomString( 16 , 'api_esm_filename' , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        return  $metainfo;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        ($inputarr['status']   ==  1?'2':'3');
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
    
    public function esmvidRetry(Request $request){
     
        $requestData        =       $request->getContent();
        $inputdata          =   file_get_contents('php://input');

        $jsondecodedata     =   json_decode($inputdata,true);
        if(count($jsondecodedata)>=1)
        {
            $jobId            =   $jsondecodedata['jobid'];
            $metaId           =   isset($jsondecodedata['metaId'])?$jsondecodedata['metaId']:'';
           $res               =  $this->startProcess($jobId,$metaId );
           return $res;
        }
    }
            
   public function vidmanual(){
       
       $this->startProcess(6496,4233);
   }         
        
    public function startProcess($jobID,$metaId){
        
//        $jsondecodedata     =   $inputdata;
        if(!empty($jobID))
        {
            $jbstgid            =   $jobID;
            $chapterdata        =   '';
            $response           =   array();
            $watchPath          =   '';
            $wrkflwMapPath      =   new workflowServerMapPathModel();
            $this->customConstructor( $jobID, $metaId );
            $metainfo           =   $this->metainfo;
            
            $esmDedatils        =   $this->getMetaEsmDetails($jobID,$metaId);
            
            if(empty($esmDedatils)){
                return false;
            }
            $metainfo['chapter_info_data']  =   $esmDedatils;
           
            $this->metainfo =       $metainfo;
            extract( $metainfo );
            try{
                $platform       =   '3b2';
                $jbstgid        =   config::get('constants.STAGE_COLLEECTION.ESM_FILE_NAME');
               
                $ftpDefault     =   $this->ftpInfo;
                
                $content        =   $this->prepareAutoPageMeta( $jbstgid , $platform,null );
                
                $metafileInput['metafilename']      =   $this->getMetafilename();
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =    Config::get('constants.PRODUCTION_TOOLS_SETUP.ESM_FILE_NAME');
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();
                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
                $this->postDataToTool( $api_tbl_input , $response , $metafileInput );

            }catch( \Exception $e ){
                         print_r($e->getMessage());
                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
            }
        }else{
            $response['status']     =   0;
            $response['Msg']        =   'failed';
            $response['errMsg']     =   'No data found';
        }
        return response()->json( $response );
    }
    
    public function getMetafilename(){
        extract(  $this->metainfo );
        $inp_rep_arr    =       array(  
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_'.$chapterno.'_{TKEY}_esmvalidation.xml';
        return $this->cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
    }
    
   
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){
        
        
        $ftpobj                     =   $metaFileInput['ftpInfo']; 
        $ftpInfo['HOST']            =   $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =   $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =   $ftpobj->FTP_PASSWORD;
        $filename                   =   $metaFileInput['metafilename'];
        $whereToWrite               =   $metaFileInput['watch_folder'];
        $getMetaFormat              =   $this->cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
      
        $errorstr                   =   '';
        $postMetaStatus             =   app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

        if( !$postMetaStatus ){
            $response['errMsg']     =   'File posted to WatchFolder got Failed';
        }

        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            
           // $insert_ret                     =   apiReferencePdfModel::insertNew( $api_tbl_input );
            $insert_ret                        =   DB::table('api_esm_filename')->insertGetId( $api_tbl_input );
            
            if(!empty($this->metainfo['chapter_info_data'])){
                foreach($this->metainfo['chapter_info_data'] as $key => $value){
                    $setArr['VID_GENERATION_STATUS'] = '1';
                    $updateQry  =   DB::table('metadata_esm')
                                            ->where('ID', $key )
                                            ->update( $setArr ); 
                }
            }
          
            if( $insert_ret ){
                $response['status']         =   1;
                $response['msg']            =   'Success';
                $response['errMsg']         =   'Meta Posted Successfully to Watchfolder';
                return true;
            }else{
                $response['errMsg']         =   'api table Record insertion failed';
            }

        }else{

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $api_tbl_input['END_TIME']      =   date('Y-m-d H:i:s');
            $api_tbl_input['STATUS']        =   3;
            $api_tbl_input['REMARKS']       =   $errorstr;

            $insert_ret                        =   DB::table('api_esm_filename')->insertGetId( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   0;
                $response['msg']            =   'Failed';
                $response['errMsg']         =   $response['errMsg'];
                return true;
            }else{
                $response['errMsg']         =   'api table Record insertion failed';
            }
        }

       return false;

   }

    public function prepareAutoPageMeta( $jbstageid , $platform = '3b2' , $type = null){
             $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        
        $preparedXml        =       '';  
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );
               
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
       /* $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );*/
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();   
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        
        return $xmlStr;
    }
    
    public function prepareSourceDestFileTags($input_rec, $returns   =   'xml',$typeofdoc){
        
        $figure_arr     =   array();
        
        $jsPath         =   $this->cmn_obj->backslashPathPrepare($input_rec['jobSheetPath'],true);
        $figure_str     =   '<jsfile type="jobsheet" src="'.$jsPath.'"/>';
       
        $figure         =   '';
       
        if(isset($input_rec['chapter_info_data']) && count($input_rec['chapter_info_data'])>=1){
            if($typeofdoc     ==  "source")
            {
                foreach( $input_rec['chapter_info_data'] as $key => $value ){
                    $replaceslash           =   $this->cmn_obj->backslashPathPrepare($value['filepath'],true);
                    if( $returns == 'xml' ){
                        
                        $figure_str         .=  '<file type="meta" src="'.$replaceslash.'" metaid="'.$value['MetaId'].'" vid="'.$key.'"/>'.PHP_EOL;
                    }

                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
           
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;    
            if( $returns == 'xml' )
                $figure     =   $figure_str;
        }
       
        return $figure;
    }
    
    public function getMetaEsmDetails($jobId, $metaId){
       
        extract( $this->metainfo );
        
        $esmDetails     =   array();
        $ftpDetail      =   $this->ftpInfo;
        $esmfilePath   =    '//'.$ftpDetail->FTP_HOST.$ftpDetail->FILE_SERVER_PATH.Config::get('constants.EMS_DESTINATION_PATH').'{CID}';
        $esmfilePath   =    str_ireplace('BOOK_ID', $bookid, $esmfilePath);
        
        $metaDetails   =   DB::table('metadata_esm as esm')->select(DB::raw('esm.*,tm.*'))
                                ->join( 'task_level_metadata as tm' , 'tm.METADATA_ID', '=', 'esm.METADATA_ID')
                                ->where('esm.JOB_ID',$jobId)
                                ->where('esm.METADATA_ID',$metaId)
                                ->where('esm.IS_VALID',2)
                                ->where('esm.VID_GENERATION_STATUS',0)
                                ->where('esm.IS_DELETED',0)
                                ->get();
        
        foreach($metaDetails as $key => $data){
           // $esmfilePath
            $esmfilePath1  = str_ireplace('{CID}', $data->CHAPTER_NO, $esmfilePath);
            $esmDetails[$data->ID]['MetaId'] = $data->METADATA_ID;
            $esmDetails[$data->ID]['filename'] = $data->ORGINAL_FILE_NAME;
            $esmDetails[$data->ID]['filepath'] = $esmfilePath1.'/'.$data->ORGINAL_FILE_NAME;
        }
        
        return $esmDetails;
        
    }
    
}