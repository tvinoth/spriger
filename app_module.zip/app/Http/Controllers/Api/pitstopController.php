<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\figureValidationModel;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\apipdfcreationModel;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\checkoutModel;
use App\Models\stageManager;
use App\Models\jobStage;
use App\Models\apiPitstop;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\apiAutoPage;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\autostageController;
use App\Http\Controllers\Api\bookMergeController;
use App\Http\Controllers\Api\autoPageController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class pitstopController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_pitstop';
    public $apiModel        =       'apiPitstop';
    
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);
        
        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $jobid 		=	$metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $round                      =       $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        $producttype                =       'ONLINE';
		
     switch( $jbstg_rec->STAGE_ID ){
        
            case \Config::get('constants.STAGE_COLLEECTION.AUTO_DP') :
                $producttype                =       'ONLINE';
                break;
            case \Config::get('constants.STAGE_COLLEECTION.COVER_DP') :
                $producttype                =       'PRINT';
                break;
            case \Config::get('constants.STAGE_COLLEECTION.AUTO_DP_PRINT_CONTRI') :
                $producttype                =       'PRINT';
                break;
            case \Config::get('constants.STAGE_COLLEECTION.AUTO_DP_PRINT_MONO') :
                $producttype                =       'BOOK_PRINT';
                break;
            case \Config::get('constants.STAGE_COLLEECTION.COMPONENT_COVER_DP_MYCOPY') :
                $producttype                =       'PRINT';
                break;
			case \Config::get('constants.STAGE_COLLEECTION.COMPONENT_DP_MYCOPY') :
				$producttype                =       'PRINT';
				break;
			case \Config::get('constants.STAGE_COLLEECTION.COVER_DP_SOFTCOPY') :
				$producttype                =       'PRINT';
				break;
			case \Config::get('constants.STAGE_COLLEECTION.S600_BB_DP_PRINT') :
				$producttype                =       'PRINT';
				break;
            case \Config::get('constants.STAGE_COLLEECTION.S600_BB_DP_ONLINE') :
                $producttype                =       'ONLINE';
				break;
            case \Config::get('constants.STAGE_COLLEECTION.S600_BB_DP_MYCOPY') :
                $producttype                =       'PRINT';
	     break;
            
        }
		
    	$jbmdl				=		new jobModel();
    	$jb_info            =       $jbmdl->getJobdetails( $jobid );
    	$made_inp2 			=		array();
			
		if( $producttype == 'PRINT' ){
			
			if( isset( $jb_info->IS_BLEED ) && !empty( $jb_info->IS_BLEED ) ){
					
				if( $jb_info->IS_BLEED == 0 && strtoupper ( $jb_info->APPLICATION ) == '3B2'){						
					$made_inp2           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED'  );						
				}else if( $jb_info->IS_BLEED == 1 && strtoupper ( $jb_info->APPLICATION ) == '3B2' ){						
					$made_inp2          =   array( 'producttype'   =>  'PRINT_BLEED' );						
				}else{						
					$made_inp2           =   array( 'producttype'   =>  'PRINT'  );						
				}
					
			}else if(  strtoupper ( $jb_info->APPLICATION ) == '3B2' ){					
					$made_inp2           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED'  );						
			}else{					
					$made_inp2           =   array( 'producttype'   =>  'PRINT' );
			}
		
		}
		
        $getlocationftp          =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
            $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        
        $this->ftpInfo  =   $metaPostInfo;
        $cmn_obj              =       new CommonMethodsController();
        $this->tokenkey          =       $cmn_obj->generateRandomString( 16 , 'api_pitstop' , 'TOKEN_KEY' );
        
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        
        $sql = 'SELECT j.BOOK_ID,js.JOB_STAGE_ID, ji.APPLICATION,mi.FM_ARTICLE_BM,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.STATUS as CURRENTSTATUS,js.Rollback_Remarks,js.CHECK_OUT,js.CHECK_IN,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID
                FROM job_stage js
                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                JOIN job j ON j.JOB_ID = jr.JOB_ID
                JOIN job_info ji ON j.JOB_ID = ji.JOB_ID
                JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                JOIN metadata_info mi ON mi.METADATA_ID = tlm.METADATA_ID
                LEFT OUTER
                JOIN round_enum r ON r.ID = jr.ROUND_ID
                LEFT OUTER
                JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                WHERE js.JOB_STAGE_ID IN ('.$jobStageId.')';
      
        $getRecs        =   DB::select( $sql );
        $getRecs        =   $getRecs[0];
      
            //only for autopage            
            $cusomcondition  =      array( 'METADATA_ID' => $jbstg_rec->METADATA_ID , 'ROUND' => $jbstg_rec->ROUND_ID , 'JOB_ID' => $jbstg_rec->JOB_ID );
            $apiAtPgObj      =      new apiAutoPage();
            $apirecordAP     =      $apiAtPgObj::select( )->where( $cusomcondition )->orderBy( 'ID' , 'desc' )->get()->first();
            $gotostage       =   '';
            
            if( count( $getRecs ) ){
               
                $platform         =     $getRecs->APPLICATION;
                $covercompo       =     ($getRecs->FM_ARTICLE_BM == 5) ? true : false;
                       
                if( $platform == 'InDesign' || $covercompo){
                    $platform = 'ADOBE INDESIGN';
                }
                
                $mode           =       'D/P';
                $extension_ps     =     'ps';
                
                switch ( $platform ){
                    case 'ADOBE INDESIGN':
                        $extension_ps   =       'pdf';
                       break;
                    case '3B2':
                        $extension_ps     =     'ps';
                       break;
                    case 'LATEX':
                        $extension_ps     =     '';
                       break;
                }
              
                $made_inp           =   array( 'platform' => $platform , 'mode' => $mode , 'location' => 'SERVER' , 
                    'pitstopsrcext' => $extension_ps , 'comptype' => $getRecs-> FM_ARTICLE_BM ,
                    'producttype'   =>  $producttype , 'roundidinfo' => $round
                );
                
		$made_inp		=		array_merge( $made_inp , $made_inp2 );
				
                $this->assignAdditonalOptionToMetaInfo( json_encode( $made_inp ) );
                
            }
        
        return  $this->metainfo;
        
    }
    
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){
       
       if( isset( $optional_param_json ) ){
           if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
               $addionalParam      =       json_decode( $optional_param_json );
               
               if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                   
                   $autopageInput      =       (array)$addionalParam; 
                   $exitsing_meta      =        $this->metainfo;

                   foreach( $addionalParam as $key => $value ){          
                        $this->metainfo[ $key ]     = $value;                              
                   }
                   
				$autopageInput2     =   $autopageInput;
				$autopageInput2['platform']     =   'PITSTOP';
				
			   //find production location tools machine name
				$bgConObj      		=   new bgprocessController();
				$toolsinfo     		=   $bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput2 );          
				$distillerinfo     	=   $bgConObj->getDistillerPathInformation( $exitsing_meta  , $autopageInput );  
				
				$distillerPath	     	=   	'';
				$dpSuccess				=		'';
				$dpFailed				=		'';
				$dpLine		    	 	=   	'';
				$dpHighIn		     	=   	'';
				$dpHighLine		     	=   	'';
				$dpXmpIn		     	=   	'';
								
				if( count( $distillerinfo ) && !empty( $distillerinfo )){	
				
					$distillerPath      =   	$distillerinfo->SERVER_IP.$distillerinfo->OPTIONAL_PARAMS;				
					$dpSuccess      	=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_SUCCESS;				
					$dpFailed      		=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_FAILURE;				
					$dpLine      		=   	$distillerinfo->SERVER_IP.$distillerinfo->LINENUMBER;				
					$dpHighIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_IN;				
					$dpHighLine      	=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_LINENUMBER;				
					$dpXmpIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->XMPIN;				
					
				}
				
				$this->metainfo['toolsmachine_name']          =    	isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : '';
				$this->metainfo['distillerapppath']           =    	$distillerPath;
				$this->metainfo['distillerapppathSuccess']    =    	$dpSuccess;
				$this->metainfo['distillerapppathFail']       =    	$dpFailed;
				$this->metainfo['distillerapppathLine']       =    	$dpLine;
				$this->metainfo['distillerapppathHighresin']  =    	$dpHighIn;
				$this->metainfo['distillerapppathHighresLine']   	=    $dpHighLine;
				$this->metainfo['distillerapppathXmpin']       		=    $dpXmpIn;

               }
           }
       }

   }     
    
    public function assignAdditonalOptionToMetaInfoOverWrite( $optional_param_json ){

       if( isset( $optional_param_json ) ){
           if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
               $addionalParam      =       json_decode( $optional_param_json );
               
               if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                   
                   $autopageInput      =       (array)$addionalParam; 
                   $exitsing_meta      =        $this->metainfo;

                   foreach( $addionalParam as $key => $value ){          
                        $this->metainfo[ $key ]     = $value;                              
                   }
                   
               }
           }
       }

   }     
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess( $jbstgid ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        $this->customConstructor( $jbstgid );
        
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
         
        try{
            
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
            
            $watchPath      =       $this->getWatchFolderPath( $path );
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoStageMeta( $jbstgid );
           
            $metafileInput['metafilename']      =   $this->getMetafilename();
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input      =       array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
            
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
        }catch( \Exception $e ){
          
            $response['status']     =       0;
            $response['Msg']        =       'failed';
            $response['errMsg']     =       'Something went wrong, try again after sometimes';
            
            $err_handle             =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
        }
        
        return json_encode( $response );
        
    }
    
    public function getMetafilename( $prdtype = null ){
        
        extract(  $this->metainfo );
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $pagObj             =       new autoPageController();
        $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chapterno , $metaid ); 
        extract( $paging_collect );
        
        $cmn_obj            =        new CommonMethodsController();
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
        //$filename           =        $chapterno2.'@'.$bookid.'.xml';
        $filename       =   $pagingfilnaming.'@DP.xml';
        if( !is_null( $prdtype ) ){
          $filename   =   $pagingfilnaming.'@DP_'.strtolower($prdtype).'.xml';
          //$filename           =        $chapterno2.'@'.$bookid.'_'.strtolower($prdtype).'.xml';
        }
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH');
          
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
            
                $watchPath          =       $path['detail'];
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                $empdir        =   Session::get('users')['emp_id'];  
                //remove user directory 
                $workpath           =       str_replace(  $empdir , '', $workpath);
                $workpath           =       str_replace('//', '', $workpath);
               
            }
        
        }
        
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

       $cmn_obj                    =       new CommonMethodsController();
       $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
	   if( is_array( $ftpobj )  ){
		   $ftpobj 		=	$ftpobj['ftpInfo'];
	   }
	   
       $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
       $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
       $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
    
	   //echo '<pre>';
	   //echo htmlspecialchars( $getMetaFormat );
	   //exit;
	   
       $errorstr           =            '';
       $autoStgObj         =            new autostageController();
        
		$whereToWrite2		=			 $whereToWrite.'/BACKUP_Pitstop/';
		$curtimefomr		=			 '_'.date( 'Y_m_d_H_i_s' ).'.xml';
		$filename2		    =			 str_replace( '.xml' , $curtimefomr , $filename );
               
        $postMetaStatus     =            $autoStgObj->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
		
		if( !strpos(  $whereToWrite2 , 'USER' ) )
            $postMetaStatus2     =            $autoStgObj->writeMetafiletoWatchFolder( $filename2 , $getMetaFormat , $ftpInfo , $whereToWrite2 , $errorstr ); 
		
       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           $insert_ret                     =       apiPitstop::insertNew( $api_tbl_input );
		   
		   //get pagecount information 
		   $metaid			=		$api_tbl_input['METADATA_ID'];
		   $round			=		$api_tbl_input['ROUND'];
		   
		   $insQry = "insert into cron_fetchpagecount ( METADATA_ID , ROUND , STATUS  ) values ( '$metaid','$round',0 )";
		   DB::insert($insQry);
			
           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiPitstop::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

        return json_encode( $response );
        exit;
        
    }

    public function startOnlineProcessComponentwise( $metaid , $round ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        
        $getjobstage    =       new jobStage();
        $apnStage       =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN' );
        
        $requiredStg     =       $getjobstage->getCurrentJobStageInfoByStage( $metaid , $round , $apnStage );
        
        if( count( $requiredStg ) ){
            
            $jbstgid    =       $requiredStg[0]->JOB_STAGE_ID;
            $this->customConstructor( $jbstgid );
            $onlinestage        =   	\Config::get( 'constants.STAGE_COLLEECTION.S600_DP_ONLINE' );;
            $made_inp           =   	array( 'producttype'   =>  'ONLINE' , 'stageid' => $onlinestage );
            
			$this->assignAdditonalOptionToMetaInfoOverWrite( json_encode( $made_inp ) );
			$exitsing_meta		=		$this->metainfo;
			$autopageInput		=	 	$this->metainfo ;
			$autopageInput2     =    	$autopageInput;
				   
		    //find production location tools machine name
			$bgConObj      		=   	new bgprocessController();
			$toolsinfo     		=   	$bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput2 );          
			$distillerinfo      =   	$bgConObj->getDistillerPathInformation( $exitsing_meta  , $autopageInput );  
			
			$distillerPath	     	=   	'';
				$dpSuccess				=		'';
				$dpFailed				=		'';
				$dpLine		    	 	=   	'';
				$dpHighIn		     	=   	'';
				$dpHighLine		     	=   	'';
				$dpXmpIn		     	=   	'';
								
				if( count( $distillerinfo ) && !empty( $distillerinfo )){	
				
					$distillerPath      =   	$distillerinfo->SERVER_IP.$distillerinfo->OPTIONAL_PARAMS;				
					$dpSuccess      	=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_SUCCESS;				
					$dpFailed      		=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_FAILURE;				
					$dpLine      		=   	$distillerinfo->SERVER_IP.$distillerinfo->LINENUMBER;				
					$dpHighIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_IN;				
					$dpHighLine      	=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_LINENUMBER;				
					$dpXmpIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->XMPIN;				
					
				}
				
				$this->metainfo['toolsmachine_name']          =    	isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : '';
				$this->metainfo['distillerapppath']           =    	$distillerPath;
				$this->metainfo['distillerapppathSuccess']    =    	$dpSuccess;
				$this->metainfo['distillerapppathFail']       =    	$dpFailed;
				$this->metainfo['distillerapppathLine']       =    	$dpLine;
				$this->metainfo['distillerapppathHighresin']  =    	$dpHighIn;
				$this->metainfo['distillerapppathHighresLine']   	=    $dpHighLine;
				$this->metainfo['distillerapppathXmpin']       		=    $dpXmpIn;

		   
			$metainfo       =       $this->metainfo;
			$this->assignAdditonalOptionToMetaInfo(json_encode( $metainfo ) );
			$metainfo       =       $this->metainfo;
           
            extract( $metainfo );
         
            try{
				
                //$path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH').'IN/SERVER/';
                $watchPath      =       $workpath;//$this->getWatchFolderPath( $path );
                $ftpDefault     =       $this->ftpInfo;
                $content        =       $this->prepareAutoStageMeta( $jbstgid );
                
                $metafileInput['metafilename']      =   $this->getMetafilename( 'online' );
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();

                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
                $api_tbl_input['PRODUCT_TYPE']  =   7;

                $this->postDataToTool( $api_tbl_input , $response , $metafileInput );

            }catch( \Exception $e ){

                $response['status']     =       0;
                $response['Msg']        =       'failed';
                $response['errMsg']     =       'Something went wrong, try again after sometimes';
                //var_dump( $e->getTraceAsString() );exit;
                $err_handle             =       new errorController();
                $err_handle->handleApplicationErrors( $e );

            }

        }
        
        return json_encode( $response );
        
    } 
   
    public function startPrintProcessComponentwise( $metaid , $round ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        
        $getjobstage    =       new jobStage();
        $apnStage       =       \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN' );
        
        $requiredStg     =       $getjobstage->getCurrentJobStageInfoByStage( $metaid , $round , $apnStage );
        
        if( count( $requiredStg ) ){
            
            $jbstgid    =       $requiredStg[0]->JOB_STAGE_ID;
            $jobid      =       $requiredStg[0]->JOB_ID;
			
            $this->customConstructor( $jbstgid );
            $onlinestage        =   	\Config::get( 'constants.STAGE_COLLEECTION.S600_DP_PRINT' );
			
			$jbmdl				=		new jobModel();
			$jb_info           	=       $jbmdl->getJobdetails( $jobid );
                
			if( isset( $jb_info->IS_BLEED ) && !empty( $jb_info->IS_BLEED ) ){
				
				if( $jb_info->IS_BLEED == 0 && strtoupper ( $jb_info->APPLICATION ) == '3B2'){
					
					$made_inp           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED' , 'stageid' => $onlinestage );
					
				}else if( $jb_info->IS_BLEED == 1 && strtoupper ( $jb_info->APPLICATION ) == '3B2' ){
					
					$made_inp           =   array( 'producttype'   =>  'PRINT_BLEED' , 'stageid' => $onlinestage );
					
				}else{
					
					$made_inp           =   array( 'producttype'   =>  'PRINT' , 'stageid' => $onlinestage );
					
				}
				
			}else if(  strtoupper ( $jb_info->APPLICATION ) == '3B2' ){
				
					$made_inp           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED' , 'stageid' => $onlinestage );
					
			}else if(  strtoupper ( $jb_info->APPLICATION ) == 'INDESIGN' ){
				
			     $made_inp           =   array( 'producttype'   =>  'PRINT' , 'stageid' => $onlinestage );
					
			}else{
				
				$made_inp           =   array( 'producttype'   =>  'PRINT' , 'stageid' => $onlinestage );
				
			}
			
			$this->assignAdditonalOptionToMetaInfoOverWrite( json_encode( $made_inp ) );
			$exitsing_meta		=		$this->metainfo;
			$autopageInput		=	 	$this->metainfo ;
			$autopageInput2     =    	$autopageInput;
				   
		    //find production location tools machine name
			$bgConObj      		=   	new bgprocessController();
			$toolsinfo     		=   	$bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput2 );          
			$distillerinfo      =   	$bgConObj->getDistillerPathInformation( $exitsing_meta  , $autopageInput );  
			
			$distillerPath	     	=   	'';
				$dpSuccess				=		'';
				$dpFailed				=		'';
				$dpLine		    	 	=   	'';
				$dpHighIn		     	=   	'';
				$dpHighLine		     	=   	'';
				$dpXmpIn		     	=   	'';
								
				if( count( $distillerinfo ) && !empty( $distillerinfo )){	
				
					$distillerPath      =   	$distillerinfo->SERVER_IP.$distillerinfo->OPTIONAL_PARAMS;				
					$dpSuccess      	=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_SUCCESS;				
					$dpFailed      		=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_FAILURE;				
					$dpLine      		=   	$distillerinfo->SERVER_IP.$distillerinfo->LINENUMBER;				
					$dpHighIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_IN;				
					$dpHighLine      	=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_LINENUMBER;				
					$dpXmpIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->XMPIN;				
					
				}
				
				$this->metainfo['toolsmachine_name']          =    	isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : '';
				$this->metainfo['distillerapppath']           =    	$distillerPath;
				$this->metainfo['distillerapppathSuccess']    =    	$dpSuccess;
				$this->metainfo['distillerapppathFail']       =    	$dpFailed;
				$this->metainfo['distillerapppathLine']       =    	$dpLine;
				$this->metainfo['distillerapppathHighresin']  =    	$dpHighIn;
				$this->metainfo['distillerapppathHighresLine']   	=    $dpHighLine;
				$this->metainfo['distillerapppathXmpin']       		=    $dpXmpIn;

		   
			$metainfo       =       $this->metainfo;
			$this->assignAdditonalOptionToMetaInfo(json_encode( $metainfo ) );
			 
            $metainfo       =       $this->metainfo;
	    extract( $metainfo );
            try{
                //$path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH').'IN/SERVER/';
                $watchPath      =       $workpath;//$this->getWatchFolderPath( $path );
                $ftpDefault     =       $this->ftpInfo;
                $content        =       $this->prepareAutoStageMeta( $jbstgid );

                $metafileInput['metafilename']      =   $this->getMetafilename( 'print' );
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();

                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
                $api_tbl_input['PRODUCT_TYPE']  =   6;

                $this->postDataToTool( $api_tbl_input , $response , $metafileInput );

            }catch( \Exception $e ){

                $response['status']     =       0;
                $response['Msg']        =       'failed';
                $response['errMsg']     =       'Something went wrong, try again after sometimes';
                //var_dump( $e->getTraceAsString() );exit;
                $err_handle             =       new errorController();
                $err_handle->handleApplicationErrors( $e );

            }
        
        }
        
        return json_encode( $response );
        
    }
   
    public function prepareAutoStageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
         
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid );
        $preparedXml        =       '';    

        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );

                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
    
    public function getArtMetaDataTags( $jbstgid ){
        
        $xmlStr     =   '<ArtMetaData>';
       
            extract( $this->metainfo );            
            $getartfigure       =       DB::table( 'task_level_art_metadata' )
                                            ->whereIn( 'METADATA_ID' , array( $metaid )  )
                                            ->orderBy('ART_METADATA_ID','desc')
                                            ->get();   

            $xmlStr        .=          app('App\Http\Controllers\artProcess\artProcessController')->prepareFigureTags( $getartfigure );
            $xmlStr        .=          '</ArtMetaData>';
         
        return $xmlStr;
        
    }
      
    public function replaceRequireKeysToValues( $xmlStr ){
        
        $cmn_obj             =       new CommonMethodsController();
        $inp_rep_arr         =      $this->getRequiredReplacables();
        $xmlStr     =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $xmlStr );
        return $xmlStr;
    }
    
    public function storeResponseCallbackForS600( $inputarr , &$returns ){
        
        $response['status']         =       1;
        $response['msg']            =       'Success';
        $response['errMsg']         =       'Signal received successfully...';   
        $response['param']          =       array( 'Am in testing mode' );
         
    }
    
	public function startBookDbComponentwise( $metaid , $round, $process ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        
        $getjobstage    =       new jobStage();
        $apnStage       =       \Config::get( 'constants.STAGE_COLLEECTION.BOOK_BUILDING' );
        
        $requiredStg     =       $getjobstage->getCurrentJobStageInfoByStage( $metaid , $round , $apnStage );
		
        if( count( $requiredStg ) ){
            
            $jbstgid    =       $requiredStg[0]->JOB_STAGE_ID;
          
			
            if($process  == 'online'){
				
                $onlinestage        =   \Config::get( 'constants.STAGE_COLLEECTION.S600_BB_DP_ONLINE' );
                $made_inp          =   array( 'producttype'   =>  'BOOK_ONLINE' , 'stageid' => $onlinestage );
                $productionType     =   1;
                
            }elseif($process  == 'print'){
				
                $onlinestage        =   \Config::get( 'constants.STAGE_COLLEECTION.S600_BB_DP_PRINT' );
                $made_inp           =   array( 'producttype'   =>  'BOOK_PRINT' , 'stageid' => 1382 );				
                $productionType     =   2;
				
            }elseif($process  == 'mycopy'){
				
                $onlinestage        =   \Config::get( 'constants.STAGE_COLLEECTION.S600_BB_DP_MYCOPY' );
                $made_inp           =   array( 'producttype'   =>  'PRINT' , 'stageid' => $onlinestage );
                $productionType     =  3;
				
            }elseif($process  == 'scopy'){
				
                $onlinestage        =   \Config::get( 'constants.STAGE_COLLEECTION.S600_BB_DP_SOFTCOPY' );
                $made_inp           =   array( 'producttype'   =>  'PRINT' , 'stageid' => $onlinestage );
                $productionType     =  4;
				
            }
			
		$jbmdl				=		new jobModel();
		$jb_info            =       $jbmdl->getJobdetails( $requiredStg[0]->JOB_ID );
		$made_inp2 			=		array();
			
		if( strpos( $made_inp['producttype'] , 'PRINT' ) &&  strtoupper ( $jb_info->APPLICATION ) == '3B2' && false ){
				
			if( isset( $jb_info->IS_BLEED ) && !empty( $jb_info->IS_BLEED ) ){
					
				if( $jb_info->IS_BLEED == 0 && strtoupper ( $jb_info->APPLICATION ) == '3B2'){
						
					//$made_inp2           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED'  );
					$made_inp['producttype'] = 'BOOK_PRINT_WITHOUT_BLEED' ;
						 
				}else if( $jb_info->IS_BLEED == 1 && strtoupper ( $jb_info->APPLICATION ) == '3B2' ){
						
					//$made_inp2          =   array( 'producttype'   =>  'PRINT_BLEED' );
					$made_inp['producttype'] = 'PRINT_BLEED' ;
						
				}else{
						
					//$made_inp2           =   array( 'producttype'   =>  'PRINT'  );
					$made_inp['producttype'] = 'PRINT' ;
						
				}
					
			}else if(  strtoupper ( $jb_info->APPLICATION ) == '3B2' ){
					$made_inp['producttype'] = 'PRINT_WITHOUT_BLEED' ;
					//$made_inp2           =   array( 'producttype'   =>  'PRINT_WITHOUT_BLEED'  );
						
			}else{
				$made_inp['producttype'] = 'PRINT' ;
				//$made_inp2           =   array( 'producttype'   =>  'PRINT' );
					
			}
			
		}
		

			$this->customConstructor( $jbstgid );
			$exitsing_meta	=	$this->metainfo;
			$this->assignAdditonalOptionToMetaInfoOverWrite( json_encode( $made_inp ) );
				
			$autopageInput		=	 $this->metainfo ;
			$autopageInput2     =    $autopageInput;
		    
			$autopageInput2['platform']	=	'PITSTOP';
			$autopageInput2['mode']		=	'';
		    
		   //find production location tools machine name
			$bgConObj      =   new bgprocessController();
			
			$toolsinfo     =   $bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput2 );          
			$distillerinfo     =   $bgConObj->getDistillerPathInformation( $exitsing_meta  , $autopageInput );  
			
			$distillerPath	     	=   	'';
				$dpSuccess				=		'';
				$dpFailed				=		'';
				$dpLine		    	 	=   	'';
				$dpHighIn		     	=   	'';
				$dpHighLine		     	=   	'';
				$dpXmpIn		     	=   	'';
								
				if( count( $distillerinfo ) && !empty( $distillerinfo )){	
				
					$distillerPath      =   	$distillerinfo->SERVER_IP.$distillerinfo->OPTIONAL_PARAMS;				
					$dpSuccess      	=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_SUCCESS;				
					$dpFailed      		=   	$distillerinfo->SERVER_IP.$distillerinfo->PITSTOP_FAILURE;				
					$dpLine      		=   	$distillerinfo->SERVER_IP.$distillerinfo->LINENUMBER;				
					$dpHighIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_IN;				
					$dpHighLine      	=   	$distillerinfo->SERVER_IP.$distillerinfo->HIGHRES_LINENUMBER;				
					$dpXmpIn      		=   	$distillerinfo->SERVER_IP.$distillerinfo->XMPIN;				
					
				}
				
				$this->metainfo['toolsmachine_name']          =    	isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : '';
				$this->metainfo['distillerapppath']           =    	$distillerPath;
				$this->metainfo['distillerapppathSuccess']    =    	$dpSuccess;
				$this->metainfo['distillerapppathFail']       =    	$dpFailed;
				$this->metainfo['distillerapppathLine']       =    	$dpLine;
				$this->metainfo['distillerapppathHighresin']  =    	$dpHighIn;
				$this->metainfo['distillerapppathHighresLine']   	=    $dpHighLine;
				$this->metainfo['distillerapppathXmpin']       		=    $dpXmpIn;

			$metainfo       =       $this->metainfo;
			//dd( $metainfo );
			$this->assignAdditonalOptionToMetaInfo(json_encode( $metainfo ) );
         
            extract( $metainfo );
         
            try{
                //$path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PAGE_WATCH_PATH').'IN/SERVER/';
                $watchPath      =       $workpath;//$this->getWatchFolderPath( $path );
                $ftpDefault     =       $this->ftpInfo;
                $content        =       $this->prepareAutoStageMeta( $jbstgid );
                
                $metafileInput['metafilename']      =   $bookid.'_'.$process.'@DP.xml';
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();

                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
                $api_tbl_input['PRODUCT_TYPE']  =   $productionType;
				
                $this->postDataToTool( $api_tbl_input , $response , $metafileInput );

            }catch( \Exception $e ){

                $response['status']     =       0;
                $response['Msg']        =       'failed';
                $response['errMsg']     =       'Something went wrong, try again after sometimes';
                //var_dump( $e->getTraceAsString() );exit;
                $err_handle             =       new errorController();
                $err_handle->handleApplicationErrors( $e );

            }

        }
        
        return json_encode( $response );
        
    }
    
    public function bookmergeDpResponse($inputarr , &$returns ){
     
      $bookMergeObj       = new bookMergeController();
        
      $response            = $bookMergeObj->bookmergeDpStatusUpdate($inputarr);
       return true;
    }
    
    
    public function pitstopupdate(){
        
        return true;
    }
    
}