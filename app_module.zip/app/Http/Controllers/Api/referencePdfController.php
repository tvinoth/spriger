<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiReferencePdfModel;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class referencePdfController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_reference_pdf';
    public $apiModel        =       'apiReferencePdfModel';
    public  $common_obj;
    public function __construct()
    {
        $this->cmn_obj      =       new CommonMethodsController();
    }
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);

        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        $metainfo['ref_pdf_tags']   =       1;
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );
        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD ); 
        $this->ftpInfo              =       $getlocationftp;
        $this->tokenkey             =       $this->cmn_obj->generateRandomString( 16 , 'api_reference_pdf' , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $this->metainfo             =       $metainfo;
        return  $metainfo;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        ($inputarr['status']   ==  1?'2':'3');
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess(Request $request){
       
        $inputdata          =   file_get_contents('php://input');
		
//        $newchapterdata     =   ['//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/FM1.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_1.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_10.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_2.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_3.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_4.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_5.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_6.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_7.docx',
//    '//172.24.191.59/e/ftp/SP_BOOKS/FILE-PROCESS/PRE_PROCESSING/463130_1_En/SPLIT/CHAPTER_8.docx'];
//        $inputdata          =   ['jobstageid'   =>  4231,'chapterdata'=>$newchapterdata];
        $jsondecodedata     =   json_decode($inputdata,true);
//        $jsondecodedata     =   $inputdata;
        if(count($jsondecodedata)>=1)
        {
            $jbstgid            =   $jsondecodedata['jobstageid'];
            $chapterdata        =   $jsondecodedata['chapterdata'];
            $response           =   array();
            $watchPath          =   '';
            $wrkflwMapPath      =   new workflowServerMapPathModel();
            $this->customConstructor( $jbstgid );
            $metainfo           =   $this->metainfo;
            $metainfo['chapter_info_data']  =   $chapterdata;
            $this->metainfo =       $metainfo;
            extract( $metainfo );
            //try{
                $platform       =   '3b2';
                $path           =   $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
                $watchPath      =   $this->getWatchFolderPath( $path );
                $ftpDefault     =   $this->ftpInfo;
                
                $content        =   $this->prepareAutoPageMeta( $jbstgid , $platform,null );
                $metafileInput['metafilename']      =   $this->getMetafilename();
                $metafileInput['metaContent']       =   $content;
                $metafileInput['watch_folder']      =   $watchPath;
                $metafileInput['ftpInfo']           =   $ftpDefault;
                $api_tbl_input      =       array();
                $api_tbl_input['METADATA_ID']   =   $metaid;
                $api_tbl_input['JOB_ID']        =   $jobid;
                $api_tbl_input['ROUND']         =   $round;
                $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
                $api_tbl_input['REQUEST_LOG']   =   $content;
				
                $returnresponse     =   $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
                if(isset($returnresponse['status']) && $returnresponse['status'] == 1){
                    $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($jobid,$round,'insert',$jbstgid);
                }

           /* }catch( \Exception $e ){

                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
            }*/
        }else{
            $response['status']     =   0;
            $response['Msg']        =   'failed';
            $response['errMsg']     =   'No data found';
        }
        return response()->json( $response );
    }
    
    public function getMetafilename(){
        extract(  $this->metainfo );
        $inp_rep_arr    =       array(  
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_{TKEY}_referencepdf.xml';
        return $this->cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =   Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_REFERENCE_PDF');
        if( !empty(  $path['workingpathCredential'] ) ){    
            $recServer  =   $path['workingpathCredential'];
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =   (object)$cr_data; 
            $this->ftpInfo              =   $metaPostInfo['ftpInfo'];
            if( !empty( $path['detail'] ) ){
                $watchPath              =   $path['detail'];
                $workpath               =   str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath               =   str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                $workpath               =   preg_replace('/[0-9]/', '', $workpath);
                $workpath               =   str_replace('//', '', $workpath);
            }
        }
        return $workpath;
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){
        
        $ftpobj                     =   $metaFileInput['ftpInfo']; 
        $ftpInfo['HOST']            =   $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =   $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =   $ftpobj->FTP_PASSWORD;
        $filename                   =   $metaFileInput['metafilename'];
        $whereToWrite               =   $metaFileInput['watch_folder'];
        $getMetaFormat              =   $this->cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
        $errorstr                   =   '';
        $postMetaStatus             =   app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );

        if( !$postMetaStatus ){
            $response['errMsg']     =   'File posted to WatchFolder got Failed';
        }

        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $insert_ret                     =   apiReferencePdfModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   1;
                $response['msg']            =   'Success';
                $response['errMsg']         =   'Meta Posted Successfully to Watchfolder';
            }else{
                $response['status']         =   0;
                $response['errMsg']         =   'api table Record insertion failed';
            }
            return $response;
        }else{

            $api_tbl_input['START_TIME']    =   date('Y-m-d H:i:s');
            $api_tbl_input['END_TIME']      =   date('Y-m-d H:i:s');
            $api_tbl_input['STATUS']        =   3;
            $api_tbl_input['REMARKS']       =   $errorstr;

            $insert_ret                     =   apiReferencePdfModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']         =   0;
                $response['msg']            =   'Failed';
                $response['errMsg']         =   $response['errMsg'];
                return $response;
            }else{
                $response['status']         =   0;
                $response['errMsg']         =   'api table Record insertion failed';
            }
        }

       return false;

   }

    public function prepareAutoPageMeta( $jbstageid , $platform = '3b2' , $type = null){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        $preparedXml        =       '';  
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );
                
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                        
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }
                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        $bg_Obj                  =       new bgprocessController();   
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        return $xmlStr;
    }
    
    public function prepareSourceDestFileTags($input_rec, $returns   =   'xml',$typeofdoc){
        $figure_arr     =   array();
        $figure_str     =   '';
        $figure         =   '';
        if(isset($input_rec['chapter_info_data']) && count($input_rec['chapter_info_data'])>=1){
            if($typeofdoc     ==  "source")
            {
                foreach( $input_rec['chapter_info_data'] as $key => $value ){
                    $replaceslash           =   $this->cmn_obj->backslashPathPrepare($value,true);
                    if( $returns == 'xml' ){
                        
                        $figure_str         .=  '<File src="'.$replaceslash.'" metaid="'.$key.'"/>'.PHP_EOL;
                    }

                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
            
            if($typeofdoc     ==  "dest")
            {
                foreach($input_rec['chapter_info_data'] as $key => $value ){
                    if(strpos($value,'/') !== 	false){
                        $doc_exntension         =   substr(strrchr($value, "."), 0);
                        $total_leng             =   (strlen($value))-(strlen($doc_exntension));
                        $pdfnamedest            =   substr($value, 0,$total_leng);
                        
                        $pdfnamedest            =   str_replace(strtoupper('split'),'REFERENCE_PDF',$pdfnamedest);
                        $replaceslash           =   $this->cmn_obj->backslashPathPrepare($pdfnamedest,true);
                        if( $returns == 'xml' ){
                            $figure_str         .=  '<File src="'.$replaceslash.'" metaid="'.$key.'"/>'.PHP_EOL;
                        }
                    }
                
                    if( $returns !== 'xml' ){
                        $figure_arr[$key]['File']   =   $value;
                    }
                }
            }
            
            if( $returns == 'json' )
                $figure     =   $figure_arr;    
            if( $returns == 'xml' )
                $figure     =   $figure_str;
        }
        return $figure;
    }
    
}