<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiReferencePdfModel;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use App\Models\bgprocessPathSetup;
use App\Models\workflowServerMapPathModel;
use App\Models\jobsheetViewpathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\jobrevised\jobrevisedController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\Api\autostageController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class indexValidationController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_auto_stage';
    public $apiModel        =       'apiIndexValidationModel';
    public  $common_obj;
    public function __construct()
    {
        parent::__construct();
        $this->cmn_obj      =       new CommonMethodsController();
    }
    
    
 public function indexvalCallback(Request $request) {
        
        parse_str($request->getQueryString(),$getToolresponse);
        Log::useDailyFiles(storage_path().'/Api/spiceReturnSignal.log');
        Log::info( $request->getQueryString() );
		
        try{
        
            if(count($getToolresponse)>=1){	
                
                $getToolresponse    =   (object)$getToolresponse;
                $endtime['0']       = '{0:yyyy-MM-dd HH-mm-ss}';
                $endtime['1']       = $getToolresponse->endtime;
				
                $request['token']       =   $getToolresponse->tokenkey;
                $request['status']      =   $getToolresponse->status;
                $request['round']       =   $getToolresponse->round;
                $request['endtime']     =   $endtime;
			
				
                $request['metaid']      =   $getToolresponse->metaid;
				
                $getToolresponse->endtime  = $endtime;

                $validation             =   Validator::make($request->all(), [
                                                                                        'token' 	=> 'required',
                                                                                        'status' 	=> 'required|numeric',
                                                                                        'round' 	=> 'required|numeric',
                                                                                        'metaid' 	=> 'required|numeric',
                                                                                        'endtime' 	=> 'required'
                                                                        ]);

                if ($validation->fails())
                {
                    return response()->json($validation->errors());
                }
               
                $cmn_obj                =       new CommonMethodsController();
                $curl                   =       Config('app.url').'/api/autoStageCallback';
                
                $api_response           =       $cmn_obj->RestfulPostcUrlExecution( json_encode( $getToolresponse ) , $curl, 0 ,"");
                
                if($api_response['status'] == '1'){
                    return response()->json($api_response);
                }else{
                    return response()->json($api_response);
                }

            }
        
       }catch( \Exception $e ){
			
			$result         =           array('status'=>0 , 'msg'=>'Bad Request' , 'errMsg'=>  $e->getMessage().'[ Reason : invalid input]');
			return response()->json($result);
       }
		
        $result         =           array('status'=>0 , 'msg'=>'Bad Request' , 'errMsg'=>'Bad request Sending try again. [ Reason : invalid input type ]','token'=>'');
        return response()->json($result);
        
    }   
 
     public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        $rules['metaid']            =       'required';  ///- reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['jobstageid']        =       'required';
        $rules['round']             =       'required|numeric';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required|numeric';
        
        return $rules;
    }
	
   public function manualvalidation(){
       //10525
       $this->startProcess(12868);
   }         
        
    public function startProcess($jobStageId){
       Log::useDailyFiles( storage_path().'/Api/indexval.log' );
       Log::info($jobStageId);
        if(!empty($jobStageId))
        {
            $jbstgid            =   $jobStageId;
            $chapterdata        =   '';
            $response           =   array();
            $watchPath          =   '';
            $autoStageObj       =   new autostageController();
           
            try{
                 $response            =   $autoStageObj->doindexValidationRequest($jobStageId);
                 return $response;
                 
            }catch( \Exception $e ){
            
                $response['status'] =   0;
                $response['Msg']    =   'failed';
                $response['errMsg']    =   'Something went wrong, try again after sometimes';
                $err_handle     =       new errorController();
                $err_handle->handleApplicationErrors( $e );
            }
        }else{
            $response['status']     =   0;
            $response['Msg']        =   'failed';
            $response['errMsg']     =   'No data found';
        }
        return response()->json( $response );
    }
    
    

    
}