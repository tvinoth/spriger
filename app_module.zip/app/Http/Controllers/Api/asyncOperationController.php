<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\fileHandler;
use Session;
use Mail;
use Illuminate\Support\Facades\Crypt;
use Validator;
use DB; 
use Log;
use Config;
use Request;
use Storage;

class asyncOperationController extends Thread { 


    public function run() {
		
        if ($this->arg) {
            $sleep = mt_rand(1, 10);
            printf('%s: %s  -start -sleeps %d' . "\n", date("g:i:sa"), $this->arg , $sleep); 
            sleep($sleep);
            printf('%s: %s  -finish' . "\n", date("g:i:sa"), $this->arg);
        }
		
    }
	
	public function triggerEvent(){
			
		// Create a array
		$stack = array();

		//Initiate Multiple Thread
		foreach ( range("A", "D") as $i ) {
			$stack[] = new AsyncOperation($i);
		}

		// Start The Threads
		foreach ( $stack as $t ) {
			$t->start();
		}
			
	}
}
