<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apsProofingStatusModel;
use App\Jobs\StageemailAlert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use Log;
use Config;
use Session;

class ApiApsController extends Controller
{  
    public function ApsCallback(Request $request)
    {      
        $contents           =   $request->getContent();
//        Log::useDailyFiles(storage_path().'/Api/apslog');
//        Log::info($contents);
        $getToolresponse    =   json_decode($contents);
        if(count($getToolresponse)>=1)
        {
            $request['tokenkey']=   $getToolresponse->tokenkey;
            $request['status'] 	=   $getToolresponse->status;
            $request['jobid'] 	=   $getToolresponse->jobid;
            $request['chapterid']   =   $getToolresponse->chapterid;
            $request['round'] 	=   $getToolresponse->round;
            $request['process'] =   $getToolresponse->process;
            $request['endtime'] =   $getToolresponse->endtime;
            $validation         =   Validator::make($request->all(), [
                                                'tokenkey' 	=> 'required',
                                                'status' 	=> 'required',
                                                'chapterid' 	=> 'required',
                                                'process' 	=> 'required',
                                                'jobid' 	=> 'required',
                                                'round' 	=> 'required',
                                                'endtime' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                return response()->json($validation->errors());
            }
            $userid                     =   Config::get('constants.ADMIN_USER_ID');
            //update cuc tool response
            $token                      =   trim($getToolresponse->tokenkey);
            if(is_array($getToolresponse->endtime) && isset($getToolresponse->endtime[1])){
                $endtime                =   $getToolresponse->endtime[1];
            }else{
                $endtime                =   $getToolresponse->endtime;
            }
            
            $job_id                     =   trim($getToolresponse->jobid);
            $updatedata                 =   [];
            $updatedata['END_TIME']     =   $endtime;
            $updatedata['REMARKS']      =   trim($getToolresponse->remarks);
            $updatedata['STATUS']       =   trim($getToolresponse->status);
            $updatedata['RESPONSE_LOG'] =   $contents;
            $wheredata                  =   ['TOKEN'=>$token,'METADATA_ID'=>$getToolresponse->chapterid,'JOB_ID'=>$job_id];
            $getdata                    =   ['TOKEN'=>$token,'STATUS'=>Config::get('constants.STATUS_ENUM.INPROGRESS')];
            $getproofingdata            =   apsProofingStatusModel::where($getdata)->first();
            //get 
            if(count($getproofingdata)>=1)
            {
                $updatemeta             =   apsProofingStatusModel::where($wheredata)->update($updatedata);
                if($updatemeta)
                {
                    /*if($getToolresponse->status     ==  Config::get('constants.STATUS_ENUM.SUCCESS'))
                    {
                        $array              =   array(  
                                                '<link>'        =>      $getproofingdata->PROOFING_URL,
                                                '<link1>'       =>      $getproofingdata->PROOFING_URL,
                                            );
                        $cmn_obj            =   new CommonMethodsController();         
                        $mailcontent        =   $cmn_obj->arr_key_value_replace( $array , $getproofingdata->EMAIL_CONTENT );
                        //update mail content
                        $updatemeta                 =   apsProofingStatusModel::where($wheredata)->update(['EMAIL_CONTENT'=>$mailcontent]);
                        $data['bodycontent']        =   $mailcontent; 
                        $data['Title']              =   $getproofingdata->SUBJECT_LINE;
                        $mailArray['TemplateName']  =   'emailtemplate.apsmailsetupalert.aps-emailalert';
                        $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                        $mailArray['FromName']      =   $getproofingdata->FROM_NAME;
                        $mailArray['Subject']       =   $getproofingdata->SUBJECT;
                        $toemail                    =   $getproofingdata->TO_EMAIL;
                        $ccemail                    =   $getproofingdata->CC_EMAIL;
                        if(strpos($toemail,',') !==  false)
                        {
                            $toemailarray           =   explode(',',$toemail);
                            $mailArray['ToMail']    =   array_unique($toemailarray);
                        }else{
                            $mailArray['ToMail']    =   $toemail;
                        }
                        $mailArray['ToMail']        =   "vinoth.t@spi-global.com";
//                        if(strpos($ccemail,',') !==  false)
//                        {
//                            $ccemailarray           =   explode(',',$ccemail);
//                            $mailArray['CcMail']    =   array_unique($ccemailarray);
//                        }else{
//                            $mailArray['CcMail']    =   $ccemail;
//                        }
//                        if(empty($mailArray['CcMail']))
//                        {
//                            unset($mailArray['CcMail']);
//                        }
                        $fileattachcont                 =   public_path().'/apsAttachmentfile/';
                        if(file_exists(public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL))
                        {
                            $mailArray['file']          =   (public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL);
                            $mailArray['attachfile']    =   array('as' => $getproofingdata->MAIL_ATTACHMENT_URL, 'mime' => 'text/plain');
                        }
            
                        $mailArray['Data']              =   $data;
//                        $emailJob   =   (new StageemailAlert($mailArray));
//                        dispatch($emailJob);
//                        if(file_exists(public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL))
//                        {
//                            unlink(public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL);
//                        }
                    }*/
                    $result                 =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                    return response()->json($result);
                }
            }
            $result                     =   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'');
        return response()->json($result);
    }
}