<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCeestimationModel;
use App\Models\productionLocationModel;
use App\Models\apitapsModel;
use App\Models\tapsmetadataModel;
use App\Models\taskLevelArtMetadataModel;
use App\Models\taskLevelMetadataModel;
use App\Models\metadataInfoModel;
use App\Models\spicastProfileModel;
use App\Models\jobModel;
use App\Models\jobStage;
use App\Models\checkoutModel;
use App\Models\bookinfoModel;
use App\Models\jobRound;
use App\Models\apiWomatSignal;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config; 

class womatSignalController extends Controller
{  
    public $curl;
    
    public function storeResponse( Request $request ){

      $inputarr           =       json_decode( $request->getContent() );
      $round_arr          =       \Config::get('constants.ROUND_NAME');
     
      Log::useDailyFiles(storage_path().'/Api/womatreturnsignal.log');
      Log::info(json_encode( $inputarr ) );
      
      $inputarr     =       ( (array)$inputarr );
      extract( $inputarr );
      $womat_sig_obj       =      new apiWomatSignal();
      $getRec              =      apiWomatSignal::getApiRequestByTokenKey( $tokenKey );
     
      if( !empty( $getRec ) ){
        $rowid              =       $getRec->ID;
        $setArrCa           =       array('STATUS' => $status , 'END_TIME'  => $endtime , 'REMARKS' =>  $remarks  );
        apiWomatSignal::updateIfExist( $setArrCa  , $rowid );     
        $response['status']         =       1;
        $response['msg']            =       'Success';
        $response['errMsg']         =       'Signal received successfully';
        
      }else{
        $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
      }
      
      return response()->json( $response );
      
    }
    
	public function updateJobcode( Request $request ){

		$inputarr           = 	json_decode( $request->getContent() );
		$response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Signal trigger got failed.';
		if(is_object($inputarr)){
			$request['bookid'] 	=   isset($inputarr->bookid)?$inputarr->bookid:'';
			$request['jobcode']	=   isset($inputarr->jobcode)?$inputarr->jobcode:'';
			Log::useDailyFiles(storage_path().'/Api/updateJobcodesignal.log');
			Log::info(json_encode( $inputarr ) );
			$validation             =   Validator::make($request->all(), [
														'bookid' 	=> 'required',
														'jobcode' 	=> 'required'
												]);
			if ($validation->fails())
			{
				$response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
			}
			$getRec 	=	jobModel::select(DB::Raw('BOOK_ID,JOB_ID'))->where('BOOK_ID',$request['bookid'])->first();		
			if( !empty( $getRec ) ){
				$rowid              =       $getRec->ID;
				$getRec->JOB_CODE_ID 	=	$request['jobcode'];    
				$getRec->save();
				$response['status']         =  	1;
				$response['msg']            =   'Success';
				$response['errMsg']         =   'Signal received successfully';
			}
		}
		return response()->json( $response );
    }
	
    public function sendingSignalToWomatForArt( $metaid , $round ){
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Signal trigger got failed.';
        
        $apiTableData               =       array();
        $this->curl                 =       \Config::get('constants.WOMAT.WOMAT_ART_COMPLETED_SIGNAL');
        
        $dataToPost                 =       array();
		
        $tlam          	=       new taskLevelArtMetadataModel();
        $art_coll       =	$tlam->getArtChapterwisefigureInfo( $metaid );
        $artMetaid	=	$art_coll->pluck( 'ART_METADATA_ID' )->toArray();
        $artMetaid	=	implode( ',' ,  $artMetaid );

        $input_arr['artMetaidCollect']     =       $artMetaid;
        $input_arr['round']                =       $round;
        $input_arr['process_type']         =       'ART_COMPLETED';
        
        try{
            
            $statusChk                  =       $this->prepareArtSignalMeta( $input_arr  , $apiTableData , $dataToPost  );
           
            if( $statusChk ){

                $statusOfTool           =       $this->postDataToTool( $dataToPost  , $apiTableData  , $response );

                if( $statusOfTool ){
                    $response['status']     =       1;
                    $response['msg']        =       'Success';
                    $response['errMsg']     =       'Signal communication got success.';        
                }

            }
        
        }catch( \Exception $e ){
            $response['errMsg']     =       $e->getMessage();
        }
        
        return response()->json( $response );
        
    }
    
    public function prepareArtSignalMeta( $input , &$apitable , &$output ){
       
        extract( $input );
        
        $artMetas      =       explode( ',' ,  $artMetaidCollect );
       
        $cmn_obj       =       new CommonMethodsController();
        $time          =       date( 'Y-m-d H:i:s' );
        $token         =       $cmn_obj->generateRandomString( 16 , 'api_womat_signal' , 'TOKEN_KEY' );
        
        $apitable      =       array( 
                                    'ART_METADATA_ID'     =>      $artMetaidCollect , 
                                    'ROUND'               =>      $round  ,   
                                    'START_TIME'          =>      $time ,
                                    'PROCESS_TYPE'        =>      $process_type ,
                                    'TOKEN_KEY'           =>      $token
                                );
        
        $tlam          =       new taskLevelArtMetadataModel();
        $tlm           =       new taskLevelMetadataModel();
       
        try{
            
        $getartfigure       =       taskLevelArtMetadataModel::getArtpdfcreationfigureInfo($artMetas);
        
        if(!$getartfigure->count())  
            throw new \Exception( 'art information not found' );
        
        $metaid             =       ( $getartfigure[0]->METADATA_ID );
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        if(empty( $chapterlist ))  
            throw new \Exception( 'chapter level information is not found' );
        
        $chapter_name            =       $chapterlist[0];
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
        
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                 =       $bookinfo[0];

        $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $host                   =       $getlocationftp->FTP_HOST.'/';
        $ftp_path               =       $getlocationftp->FTP_PATH;
        $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
        $artPath                =       $file_ser_path.\Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
        $pdfPath                =       $file_ser_path.\Config::get('serverconstants.ART_PDF_PRODUCTION_PATH');
        $lowResPath             =       $file_ser_path.\Config::get('serverconstants.TAPS_CHAPTER_PATH');
        
        $roundname              =       $round_arr[$round];
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname     ,
                                            '{BID}'         =>      $book_id ,   '{RID}' => $roundname   ,      
                                            '{CID}'         =>      $chapter_name
                                        );

        $artPath                 =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artPath )  , true );
        $pdfPath                 =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$pdfPath )  , true );
        $lowResPath                 =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$lowResPath )  , true );
        
        $base['chaptername']     =      $chapter_name;
        $base['round']           =      $roundname;
        $base['artProcess']      =      'completed';
        $base['process']         =      $process_type;
        $base['artPath']         =      $artPath;
        $base['pdfPath']         =      $pdfPath;
        $base['lowResPath']         =      $lowResPath;
        
        $data['womatArtSignal']     =        array();
       
       // $prpe       =           app('App\Http\Controllers\artProcess\artProcessController')->prepareFigureTags($getartfigure , 'array');
        
        if( count( $getartfigure ) ){
            
            foreach( $getartfigure as $key   =>  $value){
                
                $prpe[$key]['filename']  =   $value->FILE_NAME;
                $prpe[$key]['query']  =   '';
                $prpe[$key]['graphicalabstract']  =   '';
                $prpe[$key]['inputMode']  =   $value->INPUT_MODE;
                $prpe[$key]['complexity']  =   $value->COMPLEXITY;
                $prpe[$key]['printColor']  =   $value->OUTPUTCOLOR;
                $prpe[$key]['webColor']  =   '';
                $prpe[$key]['inputColor']  =   $value->INPUTCOLOR;
                $prpe[$key]['workInvolved']  =   $value->WORK_INVOLVED;
                $prpe[$key]['figureType']  =   $value->FIGURE_TYPE;
                $prpe[$key]['fileType']  =   $value->INPUT_FILE;
                $prpe[$key]['remarks']  =   $value->REMARKS;
                $prpe[$key]['inputDPI']  =   '';
                  
            }
            
        }else{
            throw new \Exception( 'Art Data not Found for given metaid.' );
        }
        
        
        $wrkflw['metaid']        =       $metaid;
        $wrkflw['url']           =       url('/').'/api/womatArtCallback';
        $wrkflw['round']         =       $round;
        $wrkflw['tokenKey']      =       $token;
        $wrkflw['status']        =       '';
        $wrkflw['endtime']       =       '';
        $wrkflw['remarks']       =       '';
        
        $data['womatArtSignal']['basicInfo']      =       $base;
        $data['womatArtSignal']['figureInDetails']        =       $prpe;
        $data['womatArtSignal']['workflow']      =       $wrkflw;
        
        $output                  =      $data;
        
        }catch( \Exception $e ){
           throw new \Exception( $e->getMessage() );
        }
        
        return true;
        
    }
     
    public function postDataToTool( $data , $api_tbl_input , &$response = array() ){
        
        $cmn_obj                 =       new CommonMethodsController();
        $curl                    =       $this->curl;
        
        $api_tbl_input['updated_at']    =       Carbon::now();
        $api_tbl_input['STATUS']        =       1.5;
        $api_tbl_input['created_at']    =       Carbon::now();
        $insert_ret     =        apiWomatSignal::insertNew( $api_tbl_input );
       
        Log::useDailyFiles(storage_path().'/Api/womat_'.strtolower( $api_tbl_input['PROCESS_TYPE']).'_signal.log');
        Log::info( json_encode( $data ) );
        Log::info( '======================================' );
        ini_set('max_execution_time', 0);
       
        $returns_response        =       $cmn_obj->PostcUrlExecution( $data , $curl );
        $res_arr                 =       $res_arr1                 =       json_encode( $returns_response );
        $res_arr                 =       (array) json_decode( $res_arr );
        
        $response['status']             =       1;
        $response['msg']                =       'success';//$res_arr['Status'];
        $response['errMsg']             =       'Api request processed successfully'; 
        $response['remarks']            =       $res_arr1; 
        
        if( $insert_ret == 2 ){
            return $api_status;
        }
        
        return false;
        
    }
    
    public function sendingSignalToWomatForLowRes( $metaid , $round ){
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Signal trigger got failed.';
        
        $apiTableData               =       array();
        $this->curl                 =       \Config::get('constants.WOMAT.WOMAT_ART_COMPLETED_SIGNAL');
        
        $dataToPost                 =       array();
		
        $tlam          	=       new taskLevelArtMetadataModel();
        $art_coll       =	$tlam->getArtChapterwisefigureInfo( $metaid );
        $artMetaid	=	$art_coll->pluck( 'ART_METADATA_ID' )->toArray();
        $artMetaid	=	implode( ',' ,  $artMetaid );

        $input_arr['artMetaidCollect']     =       $artMetaid;
        $input_arr['round']                =       $round;
        $input_arr['process_type']         =       'LOW_RES_COMPLETED';
        try{
            
            $statusChk                  =       $this->prepareArtSignalMeta( $input_arr  , $apiTableData , $dataToPost  );
           
            if( $statusChk ){

                $statusOfTool           =       $this->postDataToTool( $dataToPost  , $apiTableData  , $response );

                if( $statusOfTool ){
                    $response['status']     =       1;
                    $response['msg']        =       'Success';
                    $response['errMsg']     =       'Signal communication got success.';        
                }

            }
        
        }catch( \Exception $e ){
            $response['errMsg']     =       $e->getMessage();
        }
        
        return response()->json( $response );
        
    }
    
    public function prepareLowResSignalMeta( $input , &$apitable , &$output ){
       
        extract( $input );
        
        $artMetas      =       explode( ',' ,  $artMetaidCollect );
       
        $cmn_obj       =       new CommonMethodsController();
        $time          =       date( 'Y-m-d H:i:s' );
        $token         =       $cmn_obj->generateRandomString( 16 , 'api_womat_signal' , 'TOKEN_KEY' );
        
        $apitable      =       array( 
                                    'ART_METADATA_ID'     =>      $artMetaidCollect , 
                                    'ROUND'               =>      $round  ,   
                                    'START_TIME'          =>      $time ,
                                    'PROCESS_TYPE'        =>      2 ,
                                    'TOKEN_KEY'           =>      $token
                                );
        
        $tlam          =       new taskLevelArtMetadataModel();
        $tlm           =       new taskLevelMetadataModel();
       
        try{
            
        $getartfigure       =       taskLevelArtMetadataModel::getArtpdfcreationfigureInfo($artMetas);
        
        if(!$getartfigure->count())  
            throw new \Exception( 'art information not found' );
        
        $metaid             =       ( $getartfigure[0]->METADATA_ID );
        $taskLevelInfo      =       $tlm->getMetadatadetailsChapter( $metaid );
        $chapterlist        =       $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        
        $jobinfo            =       $taskLevelInfo->pluck('JOB_ID')->toArray(); 
        if(empty( $jobinfo ))  
            throw new \Exception( 'job table information is not found' );
        
        $job_id             =       $jobinfo[0];
        if(empty( $chapterlist ))  
            throw new \Exception( 'chapter level information is not found' );
        
        $chapter_name            =       $chapterlist[0];
        $round_arr               =       \Config::get('constants.ROUND_NAME');
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $job_id );
        
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                 =       $bookinfo[0];

        $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $host                   =       $getlocationftp->FTP_HOST.'/';
        $ftp_path               =       $getlocationftp->FTP_PATH;
        $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
        $artPath                =       $file_ser_path.\Config::get('serverconstants.ART_QC_PRODUCTION_PATH');
        $pdfPath                =       $file_ser_path.\Config::get('serverconstants.ART_PDF_PRODUCTION_PATH');
        
        $roundname              =       $round_arr[$round];
        
        $inp_rep_arr            =       array( 
                                            'BOOK_ID'       =>      $book_id ,   'ROUND_NAME'    =>      $roundname     ,
                                            '{BID}'         =>      $book_id ,   '{RID}' => $roundname   ,      
                                            '{CID}'         =>      $chapter_name
                                        );

        $artPath                 =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$artPath )  , true );
        $pdfPath                 =      $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $host.$pdfPath )  , true );
        
        $base['chaptername']     =      $chapter_name;
        $base['round']           =      $roundname;
        $base['artProcess']      =      'completed';
        $base['artPath']         =      $artPath;
        $base['pdfPath']         =      $pdfPath;
        
        $data['womatArtSignal']     =        array();
       
        if( count( $getartfigure ) ){
            
            foreach( $getartfigure as $key   =>  $value){
                
                $prpe[$key]['filename']  =   $value->FILE_NAME;
                $prpe[$key]['query']  =   '';
                $prpe[$key]['graphicalabstract']  =   '';
                $prpe[$key]['inputMode']  =   $value->INPUT_MODE;
                $prpe[$key]['complexity']  =   $value->COMPLEXITY;
                $prpe[$key]['printColor']  =   $value->OUTPUTCOLOR;
                $prpe[$key]['webColor']  =   '';
                $prpe[$key]['inputColor']  =   $value->INPUTCOLOR;
                $prpe[$key]['workInvolved']  =   $value->WORK_INVOLVED;
                $prpe[$key]['figureType']  =   $value->FIGURE_TYPE;
                $prpe[$key]['fileType']  =   $value->INPUT_FILE;
                $prpe[$key]['remarks']  =   $value->REMARKS;
                $prpe[$key]['inputDPI']  =   '';
                  
            }
            
        }else{
            throw new \Exception( 'Art Data not Found for given metaid.' );
        }
        
        $wrkflw['metaid']        =       $metaid;
        $wrkflw['url']           =       url('/').'/api/womatArtCallback';
        $wrkflw['round']         =       $round;
        $wrkflw['tokenKey']      =       $token;
        $wrkflw['status']        =       '';
        $wrkflw['endtime']       =       '';
        $wrkflw['remarks']       =       '';
        
        $data['womatArtSignal']['basicInfo']      =       $base;
        $data['womatArtSignal']['figureInDetails']        =       $prpe;
        $data['womatArtSignal']['workflow']      =       $wrkflw;
        
        $output                  =      $data;
        
        }catch( \Exception $e ){
           throw new \Exception( $e->getMessage() );
        }
        
        return true;
        
    }
    
}