<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\apiCucbackgroundprocessModel;
use App\Models\taskLevelMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use Log;
use Config;
use Session;

class apiCucController extends Controller
{  
    public function cucCallback(Request $request)
    {      
        header('Content-Type: application/json');
        $contents           =   file_get_contents('php://input');
        $returnstr          =   ['&#xD;','<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">','</string>'];
        foreach($returnstr as $removestr)
        {
            if(strpos($contents,$removestr) !== false)
            {
                $contents   =   str_replace($removestr, "", $contents);
            }
        }
        Log::useDailyFiles(storage_path().'/Api/cucresponse.log');
        Log::info($contents);
        $getToolresponse    =   json_decode($contents);
        if(count($getToolresponse)>=1)
        {
            $request['tokenkey']=   $getToolresponse->tokenkey;
            $request['status'] 	=   $getToolresponse->status;
            $request['jobid'] 	=   $getToolresponse->jobid;
            $request['round'] 	=   $getToolresponse->round;
            $request['endtime'] =   $getToolresponse->endtime;
            $validation         =   Validator::make($request->all(), [
                                                'tokenkey' 	=> 'required',
                                                'status' 	=> 'required',
                                                'jobid' 	=> 'required',
                                                'round' 	=> 'required',
                                                'endtime' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                return response()->json($validation->errors());
            }
            $userid         =   Config::get('constants.ADMIN_USER_ID');
            if (Session()->has('users')) {
                $userid     =   Session::get('users')['user_id'];
            }
                    
            //update cuc tool response
            $token              =   trim($getToolresponse->tokenkey);
            $status 		=   trim($getToolresponse->status);
            $endtime 		=   trim($getToolresponse->endtime);
            $job_id 		=   trim($getToolresponse->jobid);
            $updatedata         =   [];
            $updatedata['END_TIME'] =   $endtime;
            $updatedata['REMARKS']  =	trim($getToolresponse->remarks);
            $updatedata['STATUS']   =   ($status    ==  "failure"?'3':'2');
            $updatedata['RESPONSE_LOG'] =   $contents;
            $updatemeta         =   apiCucbackgroundprocessModel::doupdate($token,$updatedata);
            if($updatedata['STATUS']    ==  2)
            {
                $query_stmt     =   "CALL jobtimesheetentry('".$job_id."', '".Config::get('constants.ROUND_NAME.CUC')."', '".Config::get('constants.STAGE_COLLEECTION.CUC')."', '1','".$userid."', 'update')";
                $moveDetails    =   DB::select( $query_stmt );
                $spicastStageID =   taskLevelMetadataModel::getcucStageID($job_id);
                if(count($spicastStageID)>=1)
                {
                    $spicastStId        =   $spicastStageID['0']->JOB_STAGE_ID;
                    $roundId            =   $spicastStageID['0']->JOB_ROUND_ID;
                    $setArr             =   array( 'CHECK_IN'  => Carbon::now() , 'STATUS' => Config::get('constants.STATUS_ENUM_COLLEECTION.COMPLETED'));
                    $updateQry          =   DB::table('job_stage')
                                        ->where('JOB_STAGE_ID', $spicastStId )
                                        ->update( $setArr );
                    app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($job_id,$roundId,'update',$spicastStId);
                }
            }
            if($updatemeta)
            {
                $result         =   array('status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');
                return response()->json($result);
            }
            $result 		=   array('status'=>0,'msg'=>'Error','errMsg'=>'Response received  not updated Successfully','token'=>$token.' is not valid token');
            return response()->json($result);
        }
        $result                         =   array('status'=>0,'msg'=>'Bad Request','errMsg'=>'Bad request Sending try again...','token'=>'');
        return response()->json($result);
    }
}