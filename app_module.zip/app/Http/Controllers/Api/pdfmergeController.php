<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Models\productionLocationModel;
use App\Models\checkoutModel;
use App\Models\apiPdfmergeModel;
use App\Models\bgprocessPathSetup;
use App\Models\apiAutoPage;
use App\Models\workflowServerMapPathModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\checkout\checkOutController;
use App\Http\Controllers\checkout\stageMangerController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Carbon\Carbon;
use Validator;
use DB; 
use File;
use Log;
use Config;

class pdfmergeController extends Controller{  
    
    public $tokenkey;
    public $metainfo        =       array();
    public $ftpInfo         =       array();
    
    public $tablename       =       'api_pdfmerge';
    public $apiModel        =       'apiPdfmergeModel';
    
    public function customConstructor( $jobStageId ){ 
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);

        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec                  =       $stageDetails[0];
        
        $jobid		=	$metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $roundid                    =       $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $cmn_obj                    =       new CommonMethodsController();
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , 'api_pdfmerge' , 'TOKEN_KEY' );
        $returnstr                  =       false;
       
        if( in_array( $roundid  , array( \Config::get( 'constants.ROUND_NAME.S650' ) , \Config::get( 'constants.ROUND_NAME.S600') ) ) ){            
            $returnstr      =       $this->getAllChapterPdfSourcePath( $jobid , $roundid , $jbstg_rec , $getlocationftp );
        }
		
        
        if( $returnstr ){
            //$jsonstr    =       json_encode( array(  'authorpdfComponentpaths' => $returnstr ) );
			$metainfo['authorpdfComponentpaths']  = $returnstr;
            //$this->assignAdditonalOptionToMetaInfo( $jsonstr );        
        }
        
        $metainfo['tokenkey']       =       $this->tokenkey;
		
        $this->metainfo             =       $metainfo;
        return  $metainfo;
        
    }
       
    public function getAllChapterPdfSourcePath( $jobid , $roundid , $jbstg_rec , $getlocationftp){
        
        $prfStr             =       '';
        
        $componentSupport   =       array( 
                                        \Config::get('constants.ARTICLE_FM') , 
                                        \Config::get('constants.ARTICLE_CHAPTER') , 
                                        \Config::get('constants.ARTICLE_BM') , 
                                        \Config::get('constants.ARTICLE_PART') , 
                                    ); 
        
        $chapter_arr         =       taskLevelMetadataModel::select( DB::raw('task_level_metadata.*,metadata_info.*') )
                                        ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                        ->where( 'task_level_metadata.JOB_ID' , $jobid )
                                        ->where( 'task_level_metadata.UNIT_OF_MEASURE', 70 )
                                        ->whereIn('metadata_info.FM_ARTICLE_BM', $componentSupport  )
                                        ->orderBy('task_level_metadata.CHAPTER_SEQ' , 'asc' )
                                        ->get();    
        
        $return_str             =       ''; 
        $autoPgeContObj         =       new autoPageController();
        
        $bookId      =       $jbstg_rec->BOOK_ID;
        $rouundid    =      $jbstg_rec->ROUND_ID;
        
        $cmn_obj     =      new CommonMethodsController();
        $apnStage    =      \Config::get( 'constants.STAGE_COLLEECTION.AUTO_APN');
       
       if( count( $chapter_arr ) ){
           
           $return_str      = '';
           
           foreach( $chapter_arr as $index => $value  ){
               
               $chatperId       =       $value->CHAPTER_NO;
               $metaid          =       $value->METADATA_ID;
               $paginginfo      =       $autoPgeContObj->getPagingFileNameing( $bookId , $chatperId , $metaid );
               $pagingfilnaming =       '';
               $chapnoonly      =       preg_replace( '/\D/', '', $chatperId );
               
                if( !strpos( strtoupper( $chatperId ) , 'CHAPTER' ) ){
                    $chapnoonly =   $chatperId;
                }
                
               extract( $paginginfo );
               $roundID   =       $rouundid;
               
               $cno         =       '';
               $ctitle      =       $value->CHAPTER_NAME;
               $cseq        =       $value->CHAPTER_SEQ;
               $comptype    =       'chapter';
               
               $compfmpdf_path  =       \Config::get('constants.PAGINATION_ONLINE_PDF_PATH');
               $comppdf_path    =       \Config::get('constants.APN_ONLINE_PDF_PATH');
               $destaut_path    =       \Config::get('constants.AUTHOR_PDF_DESTI_PATH');
               $roundname       =       \Config::get('constants.ROUND_ID.118');
               $roundarr        =       \Config::get('constants.ROUND_ID');
			   
               $serverip        =       $getlocationftp->FTP_HOST;
               $rootdir         =       $getlocationftp->FILE_SERVER_PATH;
               
               $inp_rep_arr            =    array(
                                                '{BID}' => $bookId , '{RID}' => $roundarr[$roundID] , '{RNAME}' =>  $roundarr[$roundID] ,
                                                '{CID}' => $chatperId , '{PAGING_FILENAMING}' => $pagingfilnaming , 
                                                '{CNO}' => $chapnoonly , 
                                                '{SIP}' => $serverip , '{RDIR}' => $rootdir  ,
                                                '{APNFINDROUND}' => $roundname ,
                                            );
               
               $comppdf_path          =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $comppdf_path );
               $compfmpdf_path        =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $compfmpdf_path );
			   
               $comppdf_path          =       $cmn_obj->backslashPathPrepare( $comppdf_path , true );
               $compfmpdf_path        =       $cmn_obj->backslashPathPrepare( $compfmpdf_path , true );
               
               //$apndesti            =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $apndesti );
               //$apndesti            =       $cmn_obj->backslashPathPrepare( $apndesti , true );
			   $tempContentFormat		=		'';
			   
                if( $value->FM_ARTICLE_BM ==  \Config::get('constants.ARTICLE_FM') || $value->FM_ARTICLE_BM ==  \Config::get('constants.ARTICLE_BM')  ){
					
					//$tempContentFormat   =       '<pdfFile path="'.$compfmpdf_path.'"/>'.PHP_EOL;
					
				}else{
			   
					$tempContentFormat   =       '<pdfFile path="'.$comppdf_path.'"/>'.PHP_EOL;
                }
			   
               $return_str  .=  $tempContentFormat;
               
           }
           
           if( empty( $return_str ) ){
               return false;               
           }
           
       }else{
           
           return false;
           
       }
       
        
        return $return_str;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        ($inputarr['status']   ==  1?'2':'3');
        
        return $output;
    }
       
    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){
        
        if( isset( $optional_param_json ) ){
            if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
                $addionalParam      =       json_decode( $optional_param_json );
                $location           =       '';
                if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                    
                    $autopageInput      =       (array)$addionalParam; 
                    $exitsing_meta      =   $this->metainfo;
                   
                    foreach( $addionalParam as $key => $value ){  
                        $this->metainfo[ $key ]     = $value;     
                    }
                 
                }
            }
        }
        
    }
    
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
        
    public function startProcess( $jbstgid ){
        
        $response       =       array();
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        $this->customConstructor( $jbstgid );
        $metainfo       =       $this->metainfo;
        extract( $metainfo );
         
        try{
            
            $platform       =       '3b2';
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid );
            $watchPath      =       $this->getWatchFolderPath( $path );
            
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoPageMeta( $jbstgid , $platform );
            
            $metafileInput['metafilename']      =   $this->getMetafilename();
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input      =       array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            //$api_tbl_input['PLATFORM']      =   $platform;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
            
			
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
        }catch( \Exception $e ){
            
            $response['status'] =   0;
            $response['Msg']    =   'failed';
            $response['errMsg']    =   'Something went wrong, try again after sometimes';
            
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );
      
        }
        
        return response()->json( $response );
        
    }
    
    public function getMetafilename(){
        
        extract(  $this->metainfo );
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $this->tokenkey ,
                                    );
        
        $filename       =       $bookid.'_{CNAME}_{TKEY}_pdfmerge.xml';
        $cmn_obj        =       new CommonMethodsController();
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.AUTO_PDF_MERGE');
          
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
			if( $recServer['host'] !== 'NA' && $recServer['host']  !== 'NA' && $recServer['pasword']  !== 'NA'  ){
			
				$cr_data['FTP_HOST']        =   $recServer['host'];
				$cr_data['FTP_USER_NAME']   =   $recServer['username'];
				$cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
				$metaPostInfo['ftpInfo']    =       (object)$cr_data; 
				
				$this->ftpInfo              =       $metaPostInfo['ftpInfo'];
				
				if( !empty( $path['detail'] ) ){
				
					$watchPath          =       $path['detail'];
					$workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
					$workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
					
					//remove user directory 
					$workpath           =       preg_replace('/[0-9]/', '', $workpath);
					$workpath           =       str_replace('//', '', $workpath);
					
				}
        
			}
		
        }
		
        return $workpath;
        
    }
    
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){

        $cmn_obj                    =       new CommonMethodsController();
        $ftpobj                     =       $metaFileInput['ftpInfo']; 
       
        if( is_array($ftpobj) && isset( $ftpobj['ftpInfo'] ) ){
            $ftpobj	=		$ftpobj['ftpInfo'];
        }
		
		$ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;

        $filename           =           $metaFileInput['metafilename'];
        $whereToWrite       =           $metaFileInput['watch_folder'];
        $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
		
		//echo '<pre>';
		//echo htmlspecialchars( $getMetaFormat );
		//exit;
		
        $errorstr           =            '';
        $postMetaStatus     =            app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
		
        if( !$postMetaStatus ){
            $response['errMsg']     =      'File posted to WatchFolder got Failed';
        }

        if( !empty( $postMetaStatus ) ){

            $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
            $insert_ret                     =       apiPdfmergeModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']             =       1;
                $response['msg']                =       'Success';
                $response['errMsg']             =       'Meta Posted Successfully to Watchfolder';
                //return true;
            }else{
                $response['errMsg']             =       'api table Record insertion failed';
            }

        }else{

            $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
            $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
            $api_tbl_input['STATUS']         =       3;
            $api_tbl_input['REMARKS']         =      $errorstr;

            $insert_ret                      =       apiPdfmergeModel::insertNew( $api_tbl_input );

            if( $insert_ret ){
                $response['status']             =       0;
                $response['msg']                =       'Failed';
                $response['errMsg']             =       $response['errMsg'];
                //return true;
            }else{
                $response['errMsg']             =       'api table Record insertion failed';
            }

        }
 
       return json_encode( $response ); 

   }

    public function prepareAutoPageMeta( $jbstageid , $platform = '3b2' , $type = null ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        
        $preparedXml        =       '';  
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){
                
                $processname         =       $svalue->PROCESS_NAME;
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid );
                
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid );
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();
                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }

                }

            }
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
					
		
        $bg_Obj                  =       new bgprocessController();   
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo ); 
        return $xmlStr;
    }
    
}