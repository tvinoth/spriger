<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\apiMetaExtractor;
use App\Models\taskLevelMetadataModel;
use App\Models\ServiceManager as ServiceModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\productionLocationModel;
use App\Models\autoStageModel;
use App\Models\jobInfoModel;
use App\Models\jobStage;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Http\Controllers\custom\errorController;
use App\Models\bgprocessPathSetup; 
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\checkoutModel;
use App\Models\apiFileUpload;
use App\Models\bookinfoModel;
use App\Models\workflowServerMapPathModel;
use App\Models\apiPackaging;
use App\Models\apiDataset;
use Carbon\Carbon;
use App\Http\Controllers\Api\apiFileUploadController;
use App\Http\Controllers\Api\lowResController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\bookinfo\bookinfoController;
use App\Http\Controllers\Api\autostageController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\Api\bookMergeController;
use Mail;
use SoapClient;
use Session;
use Storage;
use Illuminate\Support\Facades\Crypt;
use Validator;
use DB; 
use File;
use Log;
use Config;


ini_set( 'max_execution_time' , 0 );

class packageController extends Controller
{
    protected   $table      =   'api_dataset';
    public      $timestamps =   true;
    protected   $dateFormat =   'Y-m-d H:i:s';
    public      $updatable_data         =      array();
    public      $errFlag                =      false;
    public      $autoTriggerUpload      =      true;
    public      $curl;
   
    public $tablename       =       'api_eproof_packaging';
    public $apiModel        =       'apiPackaging';
    
    public function storeResponse( Request $request ){
         
        $inputarr       =       (array)json_decode( $request->getContent() );
        
        Log::useDailyFiles(storage_path().'/Api/package_creation_resonse.log');
        Log::info( json_encode( $inputarr ) );
         
        $round_arr      =       \Config::get('constants.ROUND_NAME');
        $process        =       strtolower($inputarr['process']);
        
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Unable to update, Invalid Token key posted!';

        $inputarr     =       ( (array)$inputarr );
        extract( $inputarr );
        $womat_sig_obj       =      new apiDataset();
        $getRec              =      apiDataset::getApiRequestByTokenKey( $tokenkey );
        $initGetReci		 =	false;
       if( !empty( $getRec ) ){
         
         $endtime  =  $endtime[1];
                  
         $rowid              =       $getRec->ID;
         $setArrCa           =       array('STATUS' => $status , 'END_TIME'  => $endtime , 'REMARKS' =>  $remarks  );
         
         if(isset( $finalZipName ) && !empty( $finalZipName ) ){
            $setArrCa['NEW_PACKAGE_NAME']       =   $finalZipName;
			$initGetReci		=	true;
         }
         
         if(isset( $startprocess ) ){
            $setArrCa['PACKAGE_RESUME_AT']       =   $startprocess;
         }
		 
		 if(isset( $errordetails ) ){
            $setArrCa['ERROR']       =   $errordetails;
         }
         
         /* As per new packaging logic below condition not required  - it may use at emergency case
            if( strpos( $remarks , 'ReadMetaChk' ) && false){
               $setArrCa['STATUS']   =   1;
               if( ($status%2) == 0){
                  $setArrCa['VALIDATION_STATUS']   =    2;
               }else{
                   $setArrCa['VALIDATION_STATUS']   =   1;
               } 
            }
         */
         
         $update_status     =   apiDataset::updateIfExist( $setArrCa  , $rowid );     
         
         $response['status']         =       1;
         $response['msg']            =       'Success';
         $response['errMsg']         =       'Signal received successfully';
         
         if( $status == 2 ){
            $stgCom     =   new autostageController();
            $stgCom->stageCompletionProcess( $metaid , $round );  
         }else{
            $update_jobstg_Query = 'update job_stage set Rollback_Remarks="'.$remarks.'" where job_stage_id= '.$jobstageid.' limit 1';
            DB::update( $update_jobstg_Query );
         }
		 
		 if( $getRec->ROUND == 116 && $initGetReci ){			 
			$lwres_obj              =       new lowResController();
			$return_receipt         =       $lwres_obj->getRecipientEmailID( $metaid , $round );
		 }
         
       }else{
         $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
       }

       return response()->json( $response );
        
    }
    
    public function triggerProofPackaging( $chpter_info , $roundid ){
        
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        $metaid                 =       $chpter_info['metaId'];
       
        $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
        $job_id                 =       $tasklev_info[0]->JOB_ID;    
        $bookInfo               =       jobModel::getJobdetails( $job_id );
        $jobLevelProofing       =       $bookInfo->EPROOFING_SYSTEM;
        
        $haseProof              =       false;
        
        if( $tasklev_info->count() && $jobLevelProofing == 1)
            $haseProof               =       ( $tasklev_info[0]->EPROOFING_SYSTEM == 1 ) ? true : false;
        
        if( $haseProof ){
            //triggering the eproof package
            $jobid              =       $chpter_info['jobId'];
            $eprCntrl        = new \App\Http\Controllers\eproof\eproofController();
            $eprCntrl->doEproofVendorpackagecreate( $jobid , $metaid , $roundid );
        }
        
    }
	
    public function customConstructor( $jobStageId ){
        
        $checkoutObj        =   new checkoutModel();
        $workflowPath       =   new workflowServerMapPathModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);

        if(count($stageDetails) == 0){
            return array();
        }
        
        $jbstg_rec      =       $stageDetails[0];
        
        $metainfo['jobid']          =       $jbstg_rec->JOB_ID;
        $metainfo['stageid']        =       $jbstg_rec->STAGE_ID;
        $roundid    =       $metainfo['round']          =       $jbstg_rec->ROUND_ID;
        $metainfo['roundname']          =       $jbstg_rec->ROUND_NAME;
        $metaid     =       $metainfo['metaid']         =       $jbstg_rec->METADATA_ID;
        $metainfo['chapterno']      =       $jbstg_rec->CHAPTER_NO;
        $metainfo['chaptername']    =       $jbstg_rec->CHAPTER_NAME;
        $metainfo['bookid']         =       $jbstg_rec->BOOK_ID;
        $metainfo['jobstgid']       =       $jobStageId;
        $metainfo['workflowid']     =       $jbstg_rec->WORKFLOW_ID;
        $wrkmstrid		=	$metainfo['wrkflwmstrid']   =       $jbstg_rec->WORKFLOW_MASTER_ID;
        $metainfo['platform']       =       '3b2';
        
        $getlocationftp             =       productionLocationModel::doGetLocationname( $metainfo['jobid'] );

        if( empty( $getlocationftp ) )            
           $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
        
        $metaPostInfo['ftpInfo']    =       $getlocationftp;   
        $this->ftpInfo              =       $metaPostInfo;
        $cmn_obj                    =       new CommonMethodsController();
        
        $tablename                  =       $this->tablename;
        $this->tokenkey             =       $cmn_obj->generateRandomString( 16 , $tablename , 'TOKEN_KEY' );
        $metainfo['tokenkey']       =       $this->tokenkey;
        $typeofopertn               =       'package';
		//$this->getPackageOperationType( $metainfo['metaid'] , $metainfo['round'] );
        $metainfo['packageoperation']   =   'package';
        $this->getPageCountInformation( $metaid , $roundid );
        
		$this->getWorkflowBasedPaginationPath( $metaid , $roundid , $wrkmstrid , $metainfo );
		
        $metainfo['pageinformation']   =    $this->getPageCountInformationXmlTags( $metaid , $roundid ); 
        $metainfo['arttags']   =    1;
        
        $made_inp           =   array( 'jobsheetpath' => '' , 'pdfpath' =>'' );
        $bookMergeObj       =   new bookMergeController();
        
        if($roundid  == '119' || $roundid  == '120'){
            $bookData                       =  $bookMergeObj->bookMergepackageInfo(  $jobStageId );
            
            $metainfo['jobsheetpath']       = 	$bookData['jspath'];
            $metainfo['S600packagedata']    = 	$bookData['packdata'];
            $metainfo['bookartdata']        = 	$bookData['artdetails'];
			$metainfo['bookartillusdata']        = $bookData['artIllusdetails'];
			$metainfo['indexComponent']     = 	$bookData['indexComponent'];           
        }
	
        $this->metainfo                 =       $metainfo;
	
        return  $metainfo;
        
    }
    
	public function getWorkflowBasedPaginationPath( $metaid , $round , $wrkmstrid , &$metainfo ){
	 
		$conventional	= false; $fm = false; $bm= false; $part = false;
		
		if($round  == '116'){
			$cmn_obj                    =       new CommonMethodsController();
			extract( $metainfo );
			$pacg			    =		\Config::get( 'constants.STAGE_COLLEECTION.PACKAGING' );
			$getBatConv			=		DB::table('workflow_master')->select('workflow_master_id')
																			->where( 'workflow_master_id' , '=' , $wrkmstrid )
																			->where( 'workflow_master_name' , 'LIKE' , "%CONVEN%" )->get()->first();

			$medaInfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$metaid )
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get()->first();  
																
			//$medaInfo			=		DB::table( 'metadata_info' )->select('PRODUCTION_SYSTEM')
																			//->where( 'METADATA_ID' , '=' , $metaid )
																			//->get()->first();
				
				
			if( count( $medaInfo ) ){
				
				if( isset( $medaInfo->PRODUCTION_SYSTEM ) ){
					if( $medaInfo->PRODUCTION_SYSTEM == 2 || $medaInfo->PRODUCTION_SYSTEM == '2' ){
						$conventional	=	true;
					}
				}				
			}

			if( count( $getBatConv ) ){
				$conventional	=	true;
			}
			
		    $apc_obj    		=   	new autoPageController();
			$paging_collect     =       $apc_obj->getPagingFileNameing( $bookid , $chapterno ,  $metaid );
			extract( $paging_collect );
			
			$comptype              =       $medaInfo->FM_ARTICLE_BM;
			
			if( $comptype == \Config::get('constants.ARTICLE_BM') ){
				$bm = true;
			}
			
			if( $comptype == \Config::get('constants.ARTICLE_FM') ){
				$fm = true;
			}
			
			if( $comptype == \Config::get('constants.ARTICLE_PART') ){
				$part = true;
			}
            
			if( !$conventional && false ){
				
				$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.TAPSOUT' );
				$workflowdeltapath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.TAPSOUTSPICE' );
				$workflowPagintnpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.TAPSOUT' );
				
				if( $fm  ){
					//$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.TAPSOUT' );	
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.DOWNLOADEDXML' );							
				}else if( $bm ){					
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.DOWNLOADEDXML' );				
				}else if( $part ){
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.TAPSOUT' );				
				}
				
			}else{
				
				$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
				$workflowdeltapath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
				$workflowPagintnpath  	=   \Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
				
				if( $fm  ){
					//$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.DOWNLOADEDXML' );	
				}else if( $bm ){
					//$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.DOWNLOADEDXML' );	
				}else if( $part ){
					$workflowchapterpath  	= 	\Config::get( 'constants.PAGINATION_FILEPATH.S200_PACKAGE.CE_EDIT' );
				}
				
			}
			
			$round_arr      		=       \Config::get('constants.ROUND_NAME');
			
			$inp_rep_arr    		=   array( 
                                                '{BID}'     =>  $bookid ,
                                                '{RID}'     =>  $round_arr[$round] ,
                                                '{CID}'     =>  $chapterno ,
                                                'SP_BOOKS/'   =>  '' ,
                                                '{PAGING_FILENAMING}'   =>  $pagingfilnaming ,
									 );
               
			
			$workflowPagintnpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $workflowPagintnpath );
			$workflowPagintnpath    =       $cmn_obj->backslashPathPrepare( $workflowPagintnpath , false );
			$workflowchapterpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $workflowchapterpath );
			$workflowchapterpath    =       $cmn_obj->backslashPathPrepare( $workflowchapterpath , false );
			$workflowdeltapath    =       	$cmn_obj->arr_key_value_replace( $inp_rep_arr , $workflowdeltapath );
			$workflowdeltapath    =       	$cmn_obj->backslashPathPrepare( $workflowdeltapath , false );
					
			$metainfo['workflowPagintnpath']  = 	$workflowPagintnpath;
			$metainfo['workflowChapterpath']  = 	$workflowchapterpath;
			$metainfo['workflowDeltapath']  	= 	$workflowdeltapath;
			
		}
	  
	}
	
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';  - reason for comment [ 600 , 650 ]
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
        $rules['jobstageid']        =       'required';
        $rules['round']             =       'required|numeric';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required|numeric';
        
        return $rules;
    }
    
    public function getPackageOperationType( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT ID , DATASET_ID , REMARKS FROM api_dataset where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
            }else{
                return 'package';
            }
            
        }
        
        return 're-package';
    }
    
    public function getRePackageID( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT ID , DATASET_ID , REMARKS FROM api_dataset where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet->DATASET_ID;
            }
            
        }
        
        return false;
    }
    
    public function getTokenKeyIDPrev( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT * FROM api_dataset where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet->TOKEN_KEY;
            }
            
        }
        
        return false;
    }
    
    public function getLastPackageInfo( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT * FROM api_dataset where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet;
            }
            
        }
        
        return false;
    }
	
    public function getLastPackageInfo2( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT * FROM api_dataset where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID asc LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet;
            }
            
        }
        
        return false;
    }
    
    public function startProcess( $jbstgid , $optional_param_json  = '' ){
        
        $response       =       array(  'status' => 0 , 'msg' => 'Failed' , 'errMsg' => 'Oop! Something went wrong , Try again...' );
        $watchPath      =       '';
        $wrkflwMapPath  =       new workflowServerMapPathModel();
        $cmn_obj        =       new CommonMethodsController();
        
        $this->customConstructor( $jbstgid );     
        
        if( $optional_param_json == '' )
            $optional_param_json        =       '{"contactinform":1}'; 
       
        $this->optionalParam            =       $optional_param_json;     

		
        $this->assignAdditonalOptionToMetaInfo( $optional_param_json );    
        
        $metainfo           =       $this->metainfo;
        
        
        $packagename        =       '';
        $packagename_old    =       '';
        $tokenkeyold        =       '';
        
        extract( $metainfo );
        
        //addional data feed
        $biObj          =   new bookinfoController();
        $startProcess   =   0;
        
        if( $packageoperation == 're-package' || $packageoperation == 'package' ){
            
            $packageInfo	=	$this->getLastPackageInfo( $metaid , $round );
            
            if( $packageInfo ){
                
                $tokenkeyold		=		$packageInfo->TOKEN_KEY;
                $packagename    	=       $packageInfo->DATASET_ID;
                $packagename		=		str_replace( '.zip' , '' , $packagename );
                $packagename_old	=       $packagename;
                $packagename    	=       $biObj->prepareSpringerNamingConvention( $jobid , $metaid , $round , false , false , true );
                $startProcess   	=       isset( $packageInfo->PACKAGE_RESUME_AT ) ? $packageInfo->PACKAGE_RESUME_AT : 0;
                
            }else{
                
                //throw new \Exception('Invalid try.');
                
            }
            
        }
		
        if( $packageoperation == 'package' ){ 
            
            $packagename         =      $biObj->prepareSpringerNamingConvention( $jobid , $metaid , $round , false , false , true );
            $packagename_old     =      $packagename;
            $tokenkeyold         =      $this->tokenkey;
            
        }
        
        if( $startProcess == 10 || $startProcess == '10' ){
                $startProcess	=	6;
        }
		
        $metaprepare_input      =       array( 
                                                'packagzipname'     =>  $packagename , 
                                                'packagename_old'   =>  $packagename_old , 
                                                'tokenkey_old'      =>  $tokenkeyold  , 
                                                'packageoperation'  =>  $packageoperation ,
                                                'resumepackageat'      =>  $startProcess
                                        );
        
        $json_again     =   json_encode( $metaprepare_input );
        $this->assignAdditonalOptionToMetaInfo( $json_again );    
       
     //   try{
            
                $checkactiveornot   =   ServiceModel\ServiceManagerEnumModel::Active()->where('CODE',Config::get('constants.SERVICE_ENUM.OST'))->first();
                
                if(Config::get('constants.OST_ACTIVE')    ==  1 && $checkactiveornot != null){
                    if($round     ==  Config::get('constants.ROUND_ID')['S200'] || $round     ==  Config::get('constants.ROUND_ID')['S300']){
                        
                        $successfileresponse    =       app('App\Http\Controllers\Api\ostController')->ostTrackingStatus($jobid,$round,'PACKAGING',$metaid);

                        if(isset($successfileresponse['status']) && $successfileresponse['status'] == 0){
                            $response['status'] =   0;
                            $response['Msg']    =   'Failed';
                            $response['errMsg'] =   $successfileresponse['errMsg'];   
                            //check exist
                            $wheredata      =   ['JOB_ID'=>$jobid,'METADATA_ID'=>$metaid,'ROUND'=>$round];
                            $checkexist     =   apiDataset::where($wheredata)->orderBy('ID','desc')->first();
                            
                            if($checkexist ==   null){
                                $insertdata     =   [];
                                $insertdata['DATASET_ID']   =   "Data validation error_".date( 'Y-m-d H:i:s' );
                                $insertdata['JOB_ID']       =   $jobid;
                                $insertdata['ROUND']        =   $round;
                                $insertdata['METADATA_ID']  =   $metaid;
                                $insertdata['STATUS']       =   '3';
                                $insertdata['REMARKS']      =   $successfileresponse['errMsg'];
                                apiDataset::insertGetId($insertdata);
                                
                            }else{
                                $checkexist->STATUS     =   "3";
                                $checkexist->REMARKS    =   $successfileresponse['errMsg'];
                                $checkexist->save();
                            }
                            return response()->json( $response );
                        }
                    }
            }
            
            $path           =       $wrkflwMapPath->getWorkflowServerMapPath( $jbstgid , 0,0,1 );
           
            $watchPath      =       $this->getWatchFolderPath( $path );
            $ftpDefault     =       $this->ftpInfo;
            $content        =       $this->prepareAutoStageMeta( $jbstgid );
        
            $metafileInput['metafilename']      =   $this->getMetafilename( $metainfo , $path );
            $metafileInput['metaContent']       =   $content;
            $metafileInput['watch_folder']      =   $watchPath;
            $metafileInput['ftpInfo']           =   $ftpDefault;
            $api_tbl_input                      =   array();

            $api_tbl_input['METADATA_ID']   =   $metaid;
            $api_tbl_input['JOB_ID']        =   $jobid;
            $api_tbl_input['ROUND']         =   $round;
            $api_tbl_input['DATASET_ID']    =   $packagename;
            $api_tbl_input['TOKEN_KEY']     =   $this->tokenkey;
            $api_tbl_input['REQUEST_LOG']   =   $content;
		   
            $this->postDataToTool( $api_tbl_input , $response , $metafileInput );
            
            if($api_tbl_input['ROUND'] == Config::get('constants.ROUND_ID')['S200']){
                
                  //$successfileresponse    =   app('App\Http\Controllers\Api\JsCompareController')->jsCompareProcess($process='compare',$round,$jobid,$metaid);
            }
			
       /* }catch( \Exception $e ){
            
            $response['reason'] =   $e->getMessage();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $e );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]'; 
        }*/
        return json_encode( $response );
    }
     
    public function postDataToTool( $api_tbl_input , &$response = array() , $metaFileInput ){
        
        $cmn_obj       =       new CommonMethodsController();
        $ftpobj        =       $metaFileInput['ftpInfo']; 
       
        if( !isset( $ftpobj->FTP_HOST ) ){
            if( isset( $ftpobj['ftpInfo'] ) )
               $ftpobj= $ftpobj['ftpInfo'];
        }

        $ftpInfo['HOST']            =       $ftpobj->FTP_HOST;
        $ftpInfo['FTP_USERNAME']    =       $ftpobj->FTP_USER_NAME;
        $ftpInfo['FTP_PASSWORD']    =       $ftpobj->FTP_PASSWORD;
		
       $filename           =           $metaFileInput['metafilename'];
       $whereToWrite       =           $metaFileInput['watch_folder'];
       $getMetaFormat      =           $cmn_obj->formatXmlString( $metaFileInput['metaContent'] );
		
        $show              =        0;          
        
        if( $show ){
            echo '<pre>';
            echo htmlspecialchars($getMetaFormat);
            exit;
        }
     
       $errorstr            =            '';
       $stgCom              =           new autostageController();
       $postMetaStatus      =           $stgCom->writeMetafiletoWatchFolder( $filename , $getMetaFormat , $ftpInfo , $whereToWrite , $errorstr );
      
       if( !$postMetaStatus ){
           $response['errMsg']     =      'File posted to WatchFolder got Failed';
       }

       if( !empty( $postMetaStatus ) ){

           $api_tbl_input['START_TIME']    =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']        =       1.5;
           $insert_ret                     =       apiPackaging::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       1;
               $response['msg']                =       'Success';
               $response['errMsg']             =       'Packaging BG - process Initialized.';
               return true;
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }else{
           
           $api_tbl_input['START_TIME']     =       date('Y-m-d H:i:s');
           $api_tbl_input['END_TIME']       =       date('Y-m-d H:i:s');
           $api_tbl_input['STATUS']         =       3;
           $api_tbl_input['REMARKS']         =      $errorstr;
           
           $insert_ret                      =       apiPackaging::insertNew( $api_tbl_input );

           if( $insert_ret ){
               $response['status']             =       0;
               $response['msg']                =       'Failed';
               $response['errMsg']             =       $response['errMsg'];
               
           }else{
               $response['errMsg']             =       'api table Record insertion failed';
           }

       }

        return json_encode( $response );
        exit;
        
   }

    public function assignAdditonalOptionToMetaInfo( $optional_param_json ){
        
        if( isset( $optional_param_json ) ){
            if( !is_null( $optional_param_json ) && !empty( $optional_param_json )){
                $addionalParam      =       json_decode( $optional_param_json );
                
                if( !is_null( $addionalParam ) && !empty( $addionalParam ) ){
                    $autopageInput      =       (array)$addionalParam; 
                    $exitsing_meta      =   $this->metainfo;
        
                    foreach( $addionalParam as $key => $value ){  
                        $this->metainfo[ $key ]     = $value;                              
                    }
                    
                //find production location tools machine name
                 $bgConObj      =   new bgprocessController();
                 $toolsinfo     =   $bgConObj->getToolsMachineInformation( $exitsing_meta  , $autopageInput );                
                 $this->metainfo['toolsmachine_name']       =    isset( $toolsinfo['toolsmachine_name']) ? $toolsinfo['toolsmachine_name'] : '';
                 
                }
            }
        }
        
        ////only package s300 temparary predicting of previous stage information to proceed this operation
        if( !isset( $optional_param_json ) ){
                   
        }
        
    }     
    
    public function getMetafilename( $metainfo , $path ){
        
        extract(  $metainfo );   
        
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
	
        $apc_obj    		=   	new autoPageController();
        $paging_collect     =       $apc_obj->getPagingFileNameing( $bookid , $chapterno ,  $metaid );
        extract( $paging_collect );
        
        $inp_rep_arr    =       array( 
                                        '{CNAME}'       =>      $chapterno , 
                                        '{TKEY}'        =>      $tokenkey ,
                                    );
        
        $chapterno2         =        preg_replace( '/\D/', '', $chapterno );
        $filename           =        $pagingfilnaming.'@'.$roundname.'_'.$tokenkey.".xml";
        
        $cmn_obj            =        new CommonMethodsController();
        
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $filename );
        
    }
    
    public function getWatchFolderPath( $path ){
        
        $workpath       =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.EPROOF_PACKAGE_FOLDER');
               
        if( !empty(  $path['workingpathCredential'] ) ){    
            
            $recServer  =   $path['workingpathCredential'];
            
            $cr_data['FTP_HOST']        =   $recServer['host'];
            $cr_data['FTP_USER_NAME']   =   $recServer['username'];
            $cr_data['FTP_PASSWORD']    =   $recServer['pasword'];
            $metaPostInfo['ftpInfo']    =       (object)$cr_data; 
            
            $this->ftpInfo              =       $metaPostInfo['ftpInfo'];
            
            if( !empty( $path['detail'] ) ){
               
                $watchPath          =       $path['detail'];
                $workpath           =       str_replace( $cr_data['FTP_HOST'].'/' , '' , $watchPath['work'] );            
                $workpath           =       str_replace( $cr_data['FTP_HOST'] , '' , $workpath );            
                
                //remove user directory 
                $workpath           =       preg_replace('/[0-9]/', '', $workpath);
                $workpath           =       str_replace('//', '', $workpath);
             
            }
        
        }  
        
        return $workpath;
        
    }
   
    public function prepareAutoStageMeta( $jbstageid ){
        
        $roundname          =       '';
        extract( $this->metainfo );
        
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        
        if($round  == 119 || $round  == 120){
            $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapterBook( $metaid );
        }else{
            $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
        }
       
	$fmbmpartVal            =       intval( $tasklev_info[0]->FM_ARTICLE_BM );
        
        $wrkmstid       =       null;
        $jbstgObj       =       new jobStage();
        $jbstginfo      =       $jbstgObj->getJobStageInfoByJobStageId( $jbstageid );
        $noncorrection  =       \Config::get('constants.WORKFLOW.S300.MASTER_ID');
        
        if( count( $jbstginfo ) ){
            $wrkmstid       =       $jbstginfo->WORKFLOW_MASTER_ID;
        }
        
        if( $fmbmpartVal == 2 && intval( $wrkmstid ) !== intval( $noncorrection ) ){
            $type =  'INITIALIZE';
        }else if( $wrkmstid == $noncorrection &&  $fmbmpartVal == 2 ){
            $type =  'NONCORRECTION';
        }else{
            $type =  'FMBMPART';
        }
        
        if($round  == 119 || $round  == 120){
            $type =  'INITIALIZE';
        }
         
        $bgp                =       new bgprocessPathSetup();
        $processCollect     =       $bgp->getChunkProcessName( $round , $stageid , $type );
        $preparedXml        =       '';    
        
        if( count( $processCollect ) ){
            
            foreach( $processCollect as $skey => $svalue ){

                $processname         =       $svalue->PROCESS_NAME;                
                $parent_info         =       $bgp->getBgProcessSetup( $round , $processname , $stageid , $type  );
               
                if( count( $parent_info ) ){

                    $bgprocess           =       $bgp->getBgProcessMetaDirectXmlArray( $round , $processname , $stageid , $type );
                    $xmlStr              =       true;
                    $cmn_obj             =       new CommonMethodsController();

                    if( !empty( $bgprocess ) ){
                        $preparedXml         .=       $bgprocess;
                    }else{
                        $preparedXml         .=       "<$parent_info->TAG_NAME/>";
                    }

                }

            }
            
        }else{
            
            throw new \Exception( 'Metadata configuration is not yet done.' );
            
        }
        
        $mode                   =       '';
        $cmn_obj                =       new CommonMethodsController();
            
        $requiredparam          =       array(  
                                                'jobid'     =>  $jobid , 
                                                'jbstageid' =>  $jobstgid , 
                                                'metaid'    =>  $metaid, 
                                                'tokenkey'  =>  $this->tokenkey, 
                                                'round'     =>  $round , 
                                                'bookid'    =>  $bookid
                                            );
       
        $xmlStr =   '<WorkflowMetadata>'
                        .$preparedXml
                    .'</WorkflowMetadata>';
        
        $bg_Obj                  =       new bgprocessController();        
        $xmlStr                  =       $bg_Obj->replaceRequireKeysToValues( $xmlStr , $this->metainfo );
        
        return $xmlStr;
        
    }
    
    public function inputfilePresentValidation( $inputfiles , $getlocationftp ){
        
        $response["status"]     =       1;
        $response["msg"]        =       "success";
		return $response;
        $params =   array();
        
            $hostserver         =       $getlocationftp->FTP_HOST;
            $hostusername       =       $getlocationftp->FTP_USER_NAME;
            $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =       $getlocationftp->FTP_PATH;

            $ftpObj             =       \Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                        ]);

            if( count( $inputfiles ) && !empty( $inputfiles ) && is_array( $inputfiles ) ){

                foreach( $inputfiles as $input_key => $path_value_arr ){

                    foreach( $path_value_arr as $ind_inp => $path_value ){

                        if( empty( $path_value ) ){
                            continue;
                        }

                        $path_value =       str_replace( '\\' , '/' , $path_value );
                        $path_value =       str_replace( '////' , '/' , $path_value );
                        $path_value =       str_replace( '//' , '/' , $path_value );

                        $file_path          =       str_replace( "$hostserver$getlocationftp->FILE_SERVER_PATH" , '' , $path_value  );
                        $file_path          =       str_replace( '//' , '/' , $file_path );
                        
                        if( substr( $file_path , 0 , 1) == '/' ){
                            $file_path      = substr($file_path, 1 );
                        }

                        $file_path          =       $hostpath.$file_path;
                        $isfileavailable    =       $ftpObj->has( $file_path );
                        
                        if( $isfileavailable ==  true ){                            
                            //$params["$ind_inp"]     =   "success";                            
                        }else{
                            $params["$ind_inp"]     =       "file is not found";
                            $response["status"]     =       0;
                            $response["msg"]        =       "failed";
                        }
                        $params = array_map('utf8_encode', $params);
                        $response["errMsg"]     =       json_encode( $params );

                    }

                }

            }
        
        return $response;
    }

    public function getPageCountInformation( $metaid , $round ){
        
        $response['status']     =   0;
        $response['msg']        =   'Failed';
        $response['errMsg']     =   'page count information update not done , due to invalid input.';
        
        if( !empty( $metaid ) && !empty( $round ) ){
            
            try{
            
                $round_arr      =       \Config::get('constants.ROUND_NAME');
                $path           =       '';

                $tsklMeta       =       new taskLevelMetadataModel();
                $cmn_obj        =       new CommonMethodsController();
                   
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                
                if( count( $meta_info ) ){
                    
                    $meta_obj       =       $meta_info[0];
                    
                    $jobId          =       $meta_obj->JOB_ID;
                    $chapterno      =       $meta_obj->CHAPTER_NO;
                    
                    switch( $round ){

                        case $round_arr['S200'] :                            
                            $path       =   \Config::get('dynamicConstant.PAGE_COUNT_FILE_PATH.S200');
                            break;

                        case $round_arr['S300'] :                            
                            $path       =   \Config::get('dynamicConstant.PAGE_COUNT_FILE_PATH.S200');
                            break;

                    }
                    
                    $dirpath        =       $path;
                    
                    $getlocationftp     =       productionLocationModel::doGetLocationname( $jobId );
                    $hostserver         =       $getlocationftp->FTP_HOST;
                    $hostusername       =       $getlocationftp->FTP_USER_NAME;
                    $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    $hostpath           =       $getlocationftp->FTP_PATH;
                    $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                    $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                    
                    // Do the FTP connection
                    $ftpObj             =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
                    
                    $jobDetails         =       DB::table('job')->where('JOB_ID', $jobId )->get();
                    $bookid             =       $jobDetails[0]->BOOK_ID;
                    
                    $apc_obj            =       new autoPageController();
                    $paging_collect     =       $apc_obj->getPagingFileNameing( $bookid , $chapterno ,  $metaid );
                    extract( $paging_collect );
        
                    $inp_rep_arr    =   array( 
                                                '{BID}'     =>  $jobDetails[0]->BOOK_ID ,
                                                '{RID}'     =>  $round_arr[$round] ,
                                                '{CID}'     =>  $chapterno ,
                                                '{PAGING_FILENAMING}'   =>  $pagingfilnaming
                                        );
                    
                    $dirpath    =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $dirpath );
                    $filexit    =       $ftpObj->has( $dirpath );
                    
                    if( $filexit ){
                        
                        $filecontent    =       $ftpObj->get($dirpath);
                        
                        $xmlstr         =       simplexml_load_string( $filecontent , "SimpleXMLElement", LIBXML_NOCDATA);
                        $json           =       json_encode($xmlstr);
                        $array_val      =       json_decode( $json, TRUE);
                        
                        if( $array_val ){
                            
                            $pageinf   =    $array_val['PageCount'];
                            
                            $update_metainfo        =   array( 
                                                            'START_PAGE'    =>      $pageinf['Startpage'] ,
                                                            'END_PAGE'      =>      $pageinf['Endpage'] , 
                                                            'BLANK_PAGE'    =>      $pageinf['Blankpage'] 
                                                        );
                            
                            //As per shamu confirmation [29/3/2019] - update quanity value will overwrite castoff value
                            
                            $update_meta        =       array( 'QUANTITY' => $pageinf['Totalpage'] );
                            
                            $pagecountinfo      =       array_merge( $update_metainfo , $update_meta );
                            
                            $metainfoupdate     =       DB::table('metadata_info')->where( 'METADATA_ID' , '=' , $metaid )->update( $update_metainfo );
                            $metaupdate         =       taskLevelMetadataModel::where( 'METADATA_ID' , '=' , $metaid )->update( $update_meta );
                            
                            $response['status']     =       1;
                            $response['msg']        =       'Success';
                            $response['errMsg']     =       'Page Count Information updated successfully.';
                            
                            $response['pagecountinfo']     =       $pagecountinfo;
        
                        }else{
                            
                           $response['errMsg']     =       'pagecount value fetching got failed';
                           
                        }
                        
                    }else{
                        
                        $response['errMsg']     =       'pagecount file not available.';
        
                    }
                    
                    
                }else{
                    
                    $response['errMsg']     =       'pagecount information update got failed.';
        
                }
                
                
            }  catch ( \Exception $e ){
                
                $response['errMsg']     =   'pagecount information update got failed.';
                $response['reason'] =   $e->getMessage();
                
                $err_handle     =       new errorController();
                $errorid        =       $err_handle->handleApplicationErrors( $e );

                $errMsgPrev     =       $response['errMsg'];            
                $response['errorid']    =   $errorid;
                $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]'; 
                return response()->json( $response );
            
            }
            
        }
        
        return response()->json( $response );
        
    } 
    
    public function getPageCountInformationXmlTags( $metaid , $round ){
        
        $return_str         =       '';
        
        $strtpge    =       '';
        $endpge     =       '';
        $blnkpge    =       '';
        $totpge     =       '';
            
        if( !empty( $metaid ) && !empty( $round ) ){
        
            $tsklMeta           =       new taskLevelMetadataModel();
            $cmn_obj            =       new CommonMethodsController();
            $meta_info          =       $tsklMeta->getMetadatadetailsChapter( $metaid );
              
            if( count( $meta_info ) ){                
                $metainfoObj        =   $meta_info[0];                
                $strtpge    =       $metainfoObj->START_PAGE;
                $endpge     =       $metainfoObj->END_PAGE;
                $blnkpge    =       $metainfoObj->BLANK_PAGE;
                $totpge     =       $metainfoObj->QUANTITY;                
            }
           
        }       
        
        $return_str  =      "<Startpage>$strtpge</Startpage>"
                            ."<Endpage>$endpge</Endpage>"
                            ."<blankpage>$blnkpge</blankpage>"
                            ."<totalpage>$totpge</totalpage>";

        return $return_str;
        
    }
    
    }
