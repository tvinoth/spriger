<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ApiModel;
use App\Models\jobModel;
use App\Models\teamModel;
use App\Models\stageModel;
use App\Models\roundModel;
use App\Models\UserModel;
use App\Models\QmsModel;
use App\Models\taskLevelMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\custom\errorController;
use App\Models\apiZipExtraction;
#use Ixudra\Curl\Facades\Curl;
#use Ixudra\Curl\CurlService;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;

class zipExtractionController extends Controller
{ 	
    
    //input would be 
    //$process_type ,  $jobid , $round , 
    //$downloadSrcpath , $downloadDestpath
    
    public function sendExtractZipRequest( $input_arr = array() , &$response ){
        
        $cmn_obj                 =       new CommonMethodsController();
        
        $response['Msg']         =      'Failure';
        $response['status']      =      '0';
        $response['errMsg']      =      "Oops something went wrong";   
        
        try{
            
            extract( $input_arr );
            //insert to api table - 
            $cmn_obj        =       new CommonMethodsController();
            $token_key      =       $cmn_obj->generateRandomString( 16 , 'api_zip_extraction'  );
            $data           =       [];
            
            $data['ZIPFilePath']        =   $downloadSrcpath;
            $data['DestinationPath']    =   $downloadDestpath;
            
            $inp_arr        =       array( 
                                        'TOKEN_KEY'     =>  $token_key , 
                                        'PROCESS_NAME'  =>  $process_type , 
                                        'JOB_ID'        =>  $jobid , 
                                        'ROUND_ID'      =>  $round , 
                                        'START_TIME'    =>  date( 'Y-m-d H:i:s' ) , 
                                        'STATUS'        =>  0 ,
                                        'REQUEST_LOG'   =>  json_encode( $data )
                                    );
            
            if( isset( $metaid ) ){
                $inp_arr['METADATA_ID'] =   $metaid;
            }
            
            $processtyperequest     =       "";
            $webserviceUrl          =       \Config::get('constants.PRODUCTION_TOOLS_SETUP.SERVICE_URL_PONDY').'ExtractJobsheet';
            $returns_response       =       $cmn_obj->RestfulPostcUrlExecution( $data , $webserviceUrl , 1);
            $getlastinsertedid      =       apiZipExtraction::insertGetId($inp_arr);
            
            if($getlastinsertedid){
                
                $existdata  =   apiZipExtraction::findorfail( $getlastinsertedid );
                $returns_response[0]    =   'Success';
                
                if($returns_response['http_code'] != 200 && false ){
                    
                    $jobSheetResponse['REMARKS']    =       'Failure';
                    $jobSheetResponse['errMsg']     =       $returns_response['curl_err'];
                    $updatedata['STATUS']           =       3;
                    $updatedata['REMARKS']          =       $returns_response['curl_err'];
                    
                    apiZipExtraction::where( 'ID' , $getlastinsertedid )->update( $updatedata );
                    
                    $response['Msg']        =   'Failure';
                    $response['status']     =   '0';
                    $response['errMsg']     =   "Zip extraction web service not working ";   
                    
                }
                
                if($returns_response['http_code'] == 200 || true ){
                    
                    $updatedata['STATUS']           =   ( isset( $returns_response[0] ) && $returns_response[0] == "Success" ? 2 : 3 );
                    $updatedata['REMARKS']          =   ( isset( $returns_response[0] ) && $returns_response[0] == "Success" ? $returns_response[0] : $returns_response[0] );
                    apiZipExtraction::where('ID',$getlastinsertedid)->update($updatedata);
                    
                    $response['Msg']        =   'Success';
                    $response['status']     =   ( isset( $returns_response[0] ) && $returns_response[0] == "Success" ? 1 : 0 );
                    $response['errMsg']     =   $updatedata['REMARKS'];
                    
                }
                
            }
                
        }catch(\Exception $e){
            
            $errMsg                 =       $e->getMessage();
            $response['Msg']        =       'Failure';
            $response['status']     =       '0';
            $response['errMsg']     =       $errMsg;
            
            $err_handle             =       new errorController();
            $errorid                =       $err_handle->handleApplicationErrors( $e );
            
        }
        
        return response()->json( $response );
        
    }
    
    

}