<?php
namespace App\Http\Controllers\customization;

use App\Http\Controllers\Controller;
use App\Models\customizationModel;
use App\Models\bookinfoModel;
use App\Models\roundModel;
use App\Models\stageModel;
use App\Models\jobModel;
use App\Models\userDefinedWorkflowRuleModel;
use App\Models\workflowMasterModel;
use App\Models\workflowServerMapPathModel;
use App\Models\taskLevelUserdefinedWorkflow;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Carbon\Carbon;
use Validator;
use PDF;
use DB; 
use Config;

class customizationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    /**
     * Show the project-setup.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['pageTitle']  =   'Customization';
        $data['pageName']   =   'Customization';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('customization.index')->with($data);
    }
    public function stageList()
    {
	$data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['pageTitle']  =   'Stage List';
        $data['pageName']   =   'Stage List';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('customization.stage-list')->with($data);
    }
    public function roundList()
    {
        $data= array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['pageTitle'] = 'Round List';
        $data['pageName']  = 'Round List';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('customization.round-list')->with($data);
    }
    
    public function workflowList(){
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('customization.workflow-list')->with($data);
    }
    public function preset()
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['pageTitle'] = 'Preset List';
        $data['pageName']  = 'Preset List';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('customization.preset')->with($data);
        
    }
	public function getStageDetail(Request $request) {
		$stageDtl = customizationModel::getStageDetail($request->input('stageId'), $request->input('opt')); 

		$response["stage"] = $stageDtl;
		if($request->input('opt') != 'All') {
			$stageRole = customizationModel::getStageRole($request->input('stageId'));
			$response["role"] = $stageRole;
		}
		return response()->json($response);
	}
	public function getRoundMasterDetail(Request $request) {
		$roundDtl = customizationModel::getRoundMasterDetail($request->input('roundId'), $request->input('opt'));      
		$response["round"] = $roundDtl;
		
		return response()->json($response);
	}
	
	public function getWorkflowList(Request $request) {
		$dtl = customizationModel::getWorkflowList();      
		$response["workflow"] = $dtl;		
		return response()->json($response);
	}
	public function deleteRound(Request $request) {
		$inpArr = array();
		$inpArr['roundId'] = $request->input('roundId');
		$dtl = customizationModel::deleteRound($inpArr); 
		return response()->json($dtl);
	}
	public function saveRound(Request $request) {
		$inpArr = array();
		
		$inpArr['roundId'] = $request->input('roundId');
		$inpArr['userId'] = $this->loginUserId;
		$inpArr['roundCode'] = $request->input('roundCode');
		$inpArr['roundName'] = $request->input('roundName');
		$inpArr['description'] = $request->input('description');
		
		$dtl = customizationModel::saveRound($inpArr); 
		return response()->json($dtl);
	}
	public function getWorkflowAndStages(Request $request) {
            $dtl = customizationModel::getWorkflowAndStages($request->input('workflowMasterId')); 
            return response()->json($dtl);
	}
	public function getWorkflowAndStagesForbgsetup(Request $request) {
            $dtl = customizationModel::getWorkflowAndStagesForbgsetup($request->input('workflowMasterId')); 
            return response()->json($dtl);
	}
	public function deleteWorkflow(Request $request) {
		$dtl = customizationModel::deleteWorkflow($request->input('workflowMasterId')); 
		return response()->json($dtl);		
	}
	public function getCircle(Request $request) {
		$dtl = customizationModel::getCircle(); 
		return response()->json($dtl);		
	}
	public function getSubCircle(Request $request) {
		$dtl = customizationModel::getSubCircle($request->input('circleId')); 
		return response()->json($dtl);		
	}
        
        
	public function getAssignedStages(Request $request) {
             $wfdata     =   $request->getContent();
             $wfid       =  json_decode($wfdata);
             
             $workflowMasterDetails['wfMasterDetails']     =   customizationModel::getWorkflowMaster($wfid->workflowId);
             $circleId                                     =    $workflowMasterDetails['wfMasterDetails']['0']->CIRCLE_ID;
             
             $workflowDeails                                =  customizationModel::getMasterWorkflowDetails($wfid->workflowId);
             
             $workflowMasterDetails['assignedStages']       =  customizationModel::getAssignedStages($workflowDeails['0']->WORKFLOW_ID); 
             
             $workflowMasterDetails['subcircle']            = customizationModel::getSubCircle($circleId); 
            
             return response()->json($workflowMasterDetails);		
	}
        
        
	public function saveWorkflow(Request $request) {
            
                DB::beginTransaction();
		$inpArr = array();
                $wfdata     =  json_decode( $request->getContent() );
               
                $time                               =    date( 'Y-m-d H:i:s' );
                $userId                             =      $this->loginUserId;
               
                if(!empty($wfdata->wfEG)){
                    $wm['CIRCLE_ID']                    =   $wfdata->wfEG;
                }
                
                 if(!empty($wfdata->wfCluster)){
                    $wm['SUB_CIRCLE_ID']                =   $wfdata->wfCluster;
                 }
                $wm['CODE']                         =   $wfdata->wfCode;
                $wm['WORKFLOW_MASTER_NAME']         =   $wfdata->wfName;
                $wm['DESCRIPTION']                  =   $wfdata->wfDesc;
                $wm['LAST_MOD_DATE']                =   $time;
                $wm['LAST_MOD_BY']                  =   $userId;
                
                if($wfdata->action == 'edit'){
                    if(!empty($wfdata->wfMasterId)){
                        $workflowMasterId                   =   $wfdata->wfMasterId;
                        $workflowMasterResponse             =  DB::table('workflow_master')->where('WORKFLOW_MASTER_ID','=',$wfdata->wfMasterId)->update($wm);
                        
                        $workflowname['WORKFLOW_NAME']      =   $wfdata->wfName; 
                        $workflowname['LAST_MOD_DATE']      =   $time;
                        $workflowname['LAST_MOD_BY']        =   $userId;
                        $workflowId                         =   $wfdata->wfId;
                        $workflowUpdateRes                  =  DB::table('workflow')->where('WORKFLOW_ID','=',$wfdata->wfId)->where('WORKFLOW_TYPE','=','0')->update($workflowname);
                    }
                    
                }else{
                    $wm['CREATED_DATE']                 =   $time;
                    $wm['CREATED_BY']                   =   $userId;
                    $workflowMasterId                   =  DB::table('workflow_master')->insertGetId($wm);
                }
                
                if(!empty($workflowMasterId)){
                    if($wfdata->action == 'edit'){
                        
                        DB::table('workflow_stage_activity')->where('WORKFLOW', '=', $workflowId)->delete();
                        
                    }else{
                        $wf['WORKFLOW_MASTER_ID']                    =   $workflowMasterId;
                        $wf['WORKFLOW_NAME']                         =   $wfdata->wfName;
                        $wf['WORKFLOW_TYPE']                         =   '0';
                        $wf['LAST_MOD_DATE']                         =   $userId;
                        $wf['LAST_MOD_BY']                           =   $time;

                        $workflowId     =  DB::table('workflow')->insertGetId($wf);
                    }
                    
                    if(!empty($workflowId)){
                       
                        foreach($wfdata->wfStage as $key=>$data){
                            $key = $key+1;
                            $menuInsert = array();
                            $menuInsert['WORKFLOW']         =   $workflowId;
                            $menuInsert['STAGE']            =   $data->STAGE_ID;
                            $menuInsert['STAGE_SEQ']        =   $key;
                            $menuInsert['LAST_MOD_DATE']    =   $time;
                            $menuInsert['LAST_MOD_BY']      =   $userId;

                            $stageList[] =  $menuInsert;
                            
                        }
                        
                        DB::table('workflow_stage_activity')->insert($stageList);
                         
                        DB::commit();
                        $result         =   array('errMsg'=>'success');   
                        return response()->json($result);

               
                    }else{
                        DB::rollback();
                    $result         =   array('errMsg'=>'failed');   
                    return response()->json($result); 
                    }
                    
                }else{
                    DB::rollback();
                    $result         =   array('errMsg'=>'failed');   
                    return response()->json($result); 
                }
		
	}
        
	public static function getPresetMasterDetail(Request $request) {
		$dtl = customizationModel::getPresetMasterDetail($request->input('presetId'), $request->input('opt'));      
		$response["preset"] = $dtl;		
		return response()->json($response);
	}
	public static function deletePreset(Request $request) {
		$inpArr = array();
		$inpArr['presetId'] = $request->input('presetId');
		$dtl = customizationModel::deletePreset($inpArr); 
		return response()->json($dtl);
	}
	public static function savePreset(Request $request) {
		$inpArr = array();
		
		$inpArr['presetId'] = $request->input('presetId');
		$inpArr['userId'] = $this->loginUserId;
		$inpArr['presetName'] = $request->input('presetName');
		$inpArr['presetType'] = $request->input('presetType');
		
		$dtl = customizationModel::savePreset($inpArr); 
		return response()->json($dtl);
	}
        
        public function package() {
            $data               =   array();
            $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_TRANS'),$data);
            return view('customization.package')->with($data);
        }
    
    public static function getpackageList(){

        $packageModelObj                 =   new     customizationModel();
        $response['packagelist']                        =   $packageModelObj->getPackageList( );
        return response()->json($response);
     }
	
    public static function  getMenuList(){
        $customizationModelObj                 =   new     customizationModel();
        $response['menulist']         =   $customizationModelObj->getMenuList( );
        $response['packageCode']      =   $customizationModelObj->generatePackageCode();
        return response()->json($response);     

    }
        
    public function getMenuDesign(){

        $data       =       array();
        $data['base_url']     =       '';
        return view( 'layouts.menus' )->with($data);

    }

    public  function savePackage(Request $request){
             $result         =   array('errMsg'=>'failed');   
             
            try {
           //    return response()->json($result);
            DB::beginTransaction();

            $packageDetails     =   json_decode($request->getContent());
            
            $time                =  date( 'Y-m-d H:m:i' );
            $userId              =  $this->loginUserId;
            $transactionPackage['CODE']             = $packageDetails->packagecode;
           
            $transactionPackage['NAME']             = $packageDetails->packageName;
            $transactionPackage['DESCRIPTION']      = $packageDetails->packageDesc;
            $transactionPackage['CREATED_DATE']     = $time;
            $transactionPackage['CREATED_BY']       = $userId;
            $transactionPackage['LAST_MOD_DATE']    = $time;
            $transactionPackage['LAST_MOD_BY']      = $userId;
            
            if($packageDetails->actionType == 'edit'){ //update data
               
               $pId                            = $packageDetails->packageId;
               $updateData['NAME']             = $packageDetails->packageName;  
               $updateData['DESCRIPTION']      = $packageDetails->packageDesc;
               $updateData['LAST_MOD_DATE']    = $time;
               $updateData['LAST_MOD_BY']      = $userId;
               
               $customizationModelObj        =   new customizationModel();
               $existingRecord               =   $customizationModelObj->getPackageListById($pId);
               
               if($existingRecord['0']->code != $packageDetails->packagecode || $existingRecord['0']->name != $packageDetails->packageName ||$existingRecord['0']->description != $packageDetails->packageDesc ){
                   $transactionId =  DB::table('transaction_package')->where('TRANSACTION_PACKAGE_ID','=',$pId)->update($updateData);
               }
               
               DB::table('transaction_package_item')->where('TRANSACTION_PACKAGE_ID', '=', $pId)->delete();
               $transactionId  = $pId;
               
            }else{ //Insert data
                $transactionId =  DB::table('transaction_package')->insertGetId($transactionPackage);
            }
            if(!empty($transactionId)){
                if(!empty($packageDetails->packageList)) {

                    foreach($packageDetails->packageList as $key => $data){
                        $menuInsert = array();
                        $menuInsert['TRANSACTION_PACKAGE_ID']   =   $transactionId;
                        $menuInsert['TRANSACTION_MENU_ID']      =   $data->id;
                        $menuInsert['CREATED_DATE']             =   $time;
                        $menuInsert['CREATED_BY']               =   $userId;

                        $menuList[] =  $menuInsert;
                    }

                    DB::table('transaction_package_item')->insert($menuList);
                    DB::commit();
                    $result         =   array('errMsg'=>'success');   
                    return response()->json($result);
                }
            }else {
               DB::rollback();
               $result         =   array('errMsg'=>'failed');   
               return response()->json($result);
            }
            
            }catch( \Exception $e ){    
               
                $result         =   array('errMsg'=>'failed');   
               return response()->json($result);
            }
            

        }
        
    public  function validatepackagename( Request $request ){
           
              $packageDetails     =   json_decode($request->getContent());
              if(empty($packageDetails->packagename)){
                 $result         =   array('msg'=>'empty');   
              }else{
                $customizationModelObj                 =   new     customizationModel();
                $response                              =   $customizationModelObj->getpackageName($packageDetails->packagename );

                if(empty($response->NAME)){
                   $result         =   array('msg'=>'valid');   
                } else {
                   $result         =   array('msg'=>'invalid');     
                }
              }
              return response()->json($result);
              
          }
          
    public  function getPackageMenuList(Request $request){
            $package     =   json_decode($request->getContent());
           
            $customizationModelObj                 =   new     customizationModel();
            
            $response['assignMenulist']   =   $customizationModelObj->getAssignedPackageMenuList( $package->packageId);
           
            foreach($response['assignMenulist'] as $key=>$data){
                $existId[] = $data->id;
            }
           
            if(!empty($existId)){
                $response['menulist']         =   $customizationModelObj->getUnassignMenuList($existId );
            }else{
				$response['menulist']         =   $customizationModelObj->getallassignMenuList();
			}
            
            $response['packageDetails']   =   $customizationModelObj->getPackageListById($package->packageId);
         
            return response()->json($response);       

            
        } 
        
    public  function getPackageDetails(Request $request){
            $package     =   json_decode($request->getContent());
           
            $customizationModelObj                 =   new     customizationModel();
            
            $response['assignMenulist']   =   $customizationModelObj->getAssignedPackageMenuList( $package->packageId);
            $response['packageDetails']   =   $customizationModelObj->getPackageListById($package->packageId);
         
            return response()->json($response);       

            
        }
        
    public  function deletepackage(Request $request){
            $package                               =   json_decode($request->getContent());
            $customizationModelObj                 =   new     customizationModel();
            
            $status                       =   $customizationModelObj->deletepackage( $package->packageId);
           
           if($status == 'true'){
              $result         =   array('msg'=>'success');    
           }else{
                $result         =   array('msg'=>'failed');    
           }
              
            return response()->json($result);       
            
        }
        
    public function getWorkflowPackageCode(Request $request){
          
            $customizationModelObj                 =   new     customizationModel();
            $response['packageCode']               =   $customizationModelObj->generateWorkflowCode();
             return response()->json($response); 
        }
        
    public function validateworkflowname( Request $request ){
           
        $packageDetails     =   json_decode($request->getContent());
        if(empty($packageDetails->workflowname)){
           $result         =   array('msg'=>'empty');   
        }else{
          $customizationModelObj                 =   new     customizationModel();
          if(isset($packageDetails->wftype) && !empty($packageDetails->wftype == 'parallel') ){

               $response                              =   $customizationModelObj->getParallelworkflowName($packageDetails->workflowname,$packageDetails->wfmasterId );
          }else{
              $response                              =   $customizationModelObj->getworkflowName($packageDetails->workflowname );
          }

          if(empty($response->WORKFLOW_MASTER_NAME)){
             $result         =   array('msg'=>'valid');   
          } else {
             $result         =   array('msg'=>'invalid');     
          }
        }
        return response()->json($result);
              
    }
          
    public function getParallelWorkflowDetails(Request $request){
        $data               =   json_decode($request->getContent());
        $wfmId              =   $data->workflowId;
       // $wfmId              =   '12';
        $customizationModelObj       =   new     customizationModel();
        $responseData                    =   $customizationModelObj->getWorkflowInformation($wfmId);
        $masterDetails               =   array();
        $workflownameDetails         =   array();
        if(!empty($responseData)){

            foreach($responseData as $key => $wfdata){
                if($wfdata->WORKFLOW_TYPE == 0){
                    $masterDetails = $wfdata;
                }else{
                   $workflow['WORKFLOW_NAME']  = $wfdata->WORKFLOW_NAME;
                   $workflow['WORKFLOW_ID']    = $wfdata->WORKFLOW_ID;
                   $workflownameDetails[]      = $workflow;
                }
            }
        }

        $response['workflowMasterDetails']  = $masterDetails;
        $response['workflowDetails']        = $workflownameDetails;

        return response()->json($response);       

    }
    public function getMasterWorkflowAssignStages(Request $request) {
        $data = json_decode($request->getContent());
        $wfmId = $data->workflowMasterId;
        $customizationModelObj = new customizationModel();
        $responseData = $customizationModelObj->getMasterWorkflowAssignStages($wfmId);
        return response()->json($responseData);
    }

    public function saveParallelWorkflow(Request $request) {
            
                DB::beginTransaction();
		$inpArr = array();
                $wfdata     =  json_decode( $request->getContent() );
                $workflowMasterId   =   $wfdata->wfMasterId;
                $action             =   $wfdata->wftype;
               
                $time                               =   date( 'Y-m-d H:m:i' );
                $userId                             =   $this->loginUserId;
               
                if(!empty($workflowMasterId)){
                    
                    if($action != 'new'){
                        $workflowId                                 =   $action;
                        $wfupdate['WORKFLOW_NAME']                  =   $wfdata->wfName;
                        $wfupdate['START_STAGE']                    =   $wfdata->wfStartStage->STAGE_ID;
                        $wfupdate['END_STAGE']                      =   $wfdata->wfendstage->STAGE_ID;
                        $wfupdate['LAST_MOD_DATE']                  =   $time;
                        $wfupdate['LAST_MOD_BY']                    =   $userId;
                        
                        DB::table('workflow')->where('WORKFLOW_ID', '=', $workflowId)->update($wfupdate);
                        DB::table('workflow_stage_activity')->where('WORKFLOW', '=', $workflowId)->delete();
                        
                    }else{
                        $wf['WORKFLOW_MASTER_ID']                    =   $workflowMasterId;
                        $wf['WORKFLOW_NAME']                         =   $wfdata->wfName;
                        $wf['WORKFLOW_TYPE']                         =   '2';
                        $wf['START_STAGE']                           =   $wfdata->wfStartStage->STAGE_ID;
                        $wf['END_STAGE']                             =   $wfdata->wfendstage->STAGE_ID;
                        $wf['LAST_MOD_DATE']                         =   $userId;
                        $wf['LAST_MOD_BY']                           =   $time;

                        $workflowId     =  DB::table('workflow')->insertGetId($wf);
                    }
                    
                    if(!empty($workflowId)){
                       
                        foreach($wfdata->wfStage as $key=>$data){
                            $key = $key+1;
                            $menuInsert = array();
                            $menuInsert['WORKFLOW']         =   $workflowId;
                            $menuInsert['STAGE']            =   $data->STAGE_ID;
                            $menuInsert['STAGE_SEQ']        =   $key;
                            $menuInsert['LAST_MOD_DATE']    =   $time;
                            $menuInsert['LAST_MOD_BY']      =   $userId;

                            $stageList[] =  $menuInsert;
                        }
                        
                        DB::table('workflow_stage_activity')->insert($stageList);
                         
                        DB::commit();
                        $result         =   array('errMsg'=>'success');   
                        return response()->json($result);

               
                    }else{
                        DB::rollback();
                    $result         =   array('errMsg'=>'failed');   
                    return response()->json($result); 
                    }
                    
                }else{
                    DB::rollback();
                    $result         =   array('errMsg'=>'failed');   
                    return response()->json($result); 
                }
		
	}
        
    public function getAssignParallelWorkflowDetails(Request $request){
        
        $inpArr     = array();
        $wfdata     =  json_decode( $request->getContent() );
        $workflowId =  $wfdata->workflow;
        
        $customizationModelObj  = new customizationModel();
        
        $responseData['workflowDetails']          =   $customizationModelObj->getWorkflowDetails($workflowId);
        $masterWorkflowStages                     =   $customizationModelObj->getMasterWorkflowAssignStages($responseData['workflowDetails']['0']->WORKFLOW_MASTER_ID);
        
        $assignedStageDetails                     =   $customizationModelObj->getAssignedStages($workflowId);
        $responseData['assignedStage']            =   $assignedStageDetails['assignedStage'];
        $responseData['stage']                    =   $assignedStageDetails['stage'];
        $responseData['masterWorkflowStages']     =   $masterWorkflowStages;
        
        return response()->json($responseData); 
        
    }
    
    public function assignWorkflowToJob(Request $request,$jobId) {
        
        $data 			=	array();
        $data['pageTitle'] 	= 	'Assign Workflow';
        $data['pageName']  	=	'Assign Workflow';
        $data['user_name'] 	=  	$this->userName;
        $data['role_name'] 	=  	$this->roleName;
        
        $booksOpt               =       '';
        $roundOpt               =       '';
       
        
        $letterFormat_arr       =       \Config::get('constants.INTRODUCTORY.LETTER_FORMAT');
        
       /* $customizationModelObj  =       new customizationModel();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'DESCRIPTION' ) ); 
        
        $workflowList           =       $customizationModelObj->getWorkflowList();
      
        $data['roundList']      =      $roundinfo;
        
        $data['workflowList']   =      $workflowList;*/
        
        return view( 'customization.workflow-assign-job' )->with( $data );
        
    }
    
    public function getJobassignworkflow(Request $request){
        
        $customizationModelObj  =       new customizationModel();
        $roundinfo              =       roundModel::getAllRoundInfo( array( 'ID' , 'NAME' ) ); 
        
        $workflowList           =       $customizationModelObj->getWorkflowList();
      
        $data['roundList']      =      $roundinfo;
        
        $data['workflowList']   =      $workflowList;
          return response()->json($data); 
        
    }
    
    public function saveWorkflowToJob(Request $request) {
        
        $wfdata                 =  json_decode( $request->getContent() );
        $jobId                  =   $wfdata->jobId;
        $roundId                =   $wfdata->roundId;
        $workflowMasterId       =   $wfdata->wfMid;
        $userId                 =   $this->loginUserId;
        
        $customizationModelObj  =       new customizationModel();
        $workflowList           =       $customizationModelObj->getUserdefinedInformation($jobId,$roundId,$workflowMasterId);
        
        if($workflowList['0']->total == '0'){
            
            $workflowCount      =       $customizationModelObj->getWorkflowCount($jobId);
            $roundSequence      =       $workflowCount +1;
            $userDefineData     =       $customizationModelObj->insertUserdefineData($jobId,$roundId,$workflowMasterId,$userId,$roundSequence);
            
            $status['status']   =   2;
            return response()->json($status); 
            
        } else {
            
            $status['status']   =   1;
            return response()->json($status); 
        }
        
            $status['status']   =   0;
            return response()->json($status); 
    }
    
    
     public function getAssignedWorkflowToJob(Request $request){
        
        $inpArr     = array();
        $wfdata     =  json_decode( $request->getContent() );
  
      
        $customizationModelObj  = new customizationModel();
        
        $responseData['workflowDetails']          =   $customizationModelObj->getjobAssignedWorkflow($wfdata->jobId);
             
        return response()->json($responseData); 
        
    }
    
    
    public function workflowServerMapPath(Request $request, $jobId, $wfMid, $roundId){
        
        
    }
    
    
    public function workFlowRuleSetup($wfMid,$jobid,$roundId){
        $customObj  =   new customizationModel();
        $wfDetails  =   $customObj->getWorkflowAndStagesassignbyrule($wfMid,$jobid,$roundId);
        $workflow   =   array();
        foreach($wfDetails['workflow'] as $key=>$data1){
             //echo "<pre>";print_r($data1);exit;
            $data1->Stages  = $wfDetails['stage'][$data1->WORKFLOW_ID];
            foreach($data1->Stages as $key => $stageData){
                $ruleData  =   $customObj->getWorkflowRuleByStage($wfMid,$jobid,$roundId,$data1->WORKFLOW_ID,$stageData->STAGE_ID);
                $data1->Stages[$key]->rule = $ruleData;
            }
            $workflow[$data1->WORKFLOW_ID] = $data1;
        }
        $masterwrkflow          =   [];
        $parallelwrkflow        =   [];
        foreach($workflow as $wrkflw)
        {
            if($wrkflw->WORKFLOW_TYPE == 0)
            {
                foreach($wrkflw->Stages as $maskey=>$value)
                {
                    $masterwrkflow[$maskey]['stageid']      =   $value->STAGE_ID;
                    $masterwrkflow[$maskey]['stagename']    =   $value->STAGE_NAME;
                }
            }
            if($wrkflw->WORKFLOW_TYPE != 0)
            {
                foreach($wrkflw->Stages as $parlkey=>$value)
                {
                    $parallelwrkflow[$parlkey]['stageid']    =   $value->STAGE_ID;
                    $parallelwrkflow[$parlkey]['stagename']  =   $value->STAGE_NAME;
                }
            }
        }
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['user_name']      =   $this->userName;
        $data['role_name']      =   $this->roleName; 
        $data['workflowData']   =   $workflow;
        $data['masterwrkflow']  =   $masterwrkflow;
        $data['parallelwrkflow']=   $parallelwrkflow;
        $data['workmasterid']   =   $wfMid;
        $bookid                 =   jobModel::find($jobid);
        $masterwkrflwname       =   workflowMasterModel::find($wfMid);
        $data['workjobid']      =   $jobid;
        $data['bookid']         =   (count($bookid)>=1?$bookid->BOOK_ID:'');
        $data['masterworkflowname']     =   (count($masterwkrflwname)>=1?$masterwkrflwname->WORKFLOW_MASTER_NAME:'');
        $data['workroundid']    =   $roundId;
        $data['message']        =   '';
        $data['backurl']        =   url('/').'/book_infodetails/'.$jobid;
        return view('customization.WorkflowRuleSetupView')->with($data);
    }
    
//    public function getworkFlowRuleSetup(Request $request){
//        $wfMid      =   $request->input('workflowmasterID');
//        $customObj  =   new customizationModel();
//        $wfDetails  =   $customObj->getWorkflowAndStages($wfMid);
//        $workflow   =   array();
//        foreach($wfDetails['workflow'] as $key=>$data1){
//            $data1->Stages  = $wfDetails['stage'][$data1->WORKFLOW_ID];
//            $workflow[$data1->WORKFLOW_ID] = $data1;
//        }
//        $masterwrkflow          =   [];
//        $parallelwrkflow        =   [];
//        foreach($workflow as $wrkflw)
//        {
//            if($wrkflw->WORKFLOW_TYPE == 0)
//            {
//                foreach($wrkflw->Stages as $value)
//                {
//                    $masterwrkflow[]    =   $value->STAGE_NAME;
//                }
//            }
//            if($wrkflw->WORKFLOW_TYPE != 0)
//            {
//                foreach($wrkflw->Stages as $value)
//                {
//                    $parallelwrkflow[]  =   $value->STAGE_NAME;
//                }
//            }
//        }
//        $data['workflowData']       =   $workflow;
//        $data['masterwrkflow']      =   $masterwrkflow;
//        $data['parallelwrkflow']    =   $parallelwrkflow;
//        return response()->json($data);
//    }
    
    public function doWorkflowruleadd(Request $request)
    {
        try
        {
            $stageid        =   $request->input('stageid');
            $workflowid     =   $request->input('workflowid');
            $rule           =   $request->input('rule');
            $gotorule       =   $request->input('gotorule');
            $stagenames     =   $request->input('stagenames');
            $isAuto         =   $request->input('isAuto');
            $isSkip         =   $request->input('isSkip');
            $getworkflowmasterid     =   $request->input('getworkflowmasterid');
            $workjobid      =   $request->input('workjobid');
            $workroundid    =   $request->input('workroundid');
            $storedata      =   [];
            $filtered       =   collect($workflowid)->filter(function ($value, $key) {
                if($value   ==  ''){
                    return true;
                }
            });
            if(count($filtered)     !=  0)
            {
                return redirect()->back()->withInput()->withErrors("Invalid data sending kindly check it...");
            }
            
            $validation     = 	Validator::make($request->all(), [
                                                                'getworkflowmasterid' => 'required|numeric',
                                                                'workjobid' => 'required|numeric',
                                                                'workroundid' => 'required|numeric'
                                                            ]);

            if ($validation->fails())
            {
                return redirect()->back()->withErrors($validation->errors());
            }
            $addworkflowrule    =   '';
            $storesubdata       =   [];
            $subrowdata         =   [];
            $subgotorowdata     =   [];
            if(count($workflowid)>=1)
            {
                DB::beginTransaction();
                $dynamickey     =   0;
                $isautovalue    =   0;
                $taskleveluserdefinedid     =   "";
                foreach($workflowid     as  $key=>$valueofworkfowid){
                    $wheretaskleveldata     =   ['WORKFLOW'=>$valueofworkfowid,'JOB_ID'=>$workjobid,'ROUND'=>$workroundid,'WORKFLOW_MASTER_ID'=>$getworkflowmasterid,'STAGE'=>$key];
                    $tasklvelworkflowid     =   taskLevelUserdefinedWorkflow::where($wheretaskleveldata)->first();
                    $taskleveluserdefinedid =   (count($tasklvelworkflowid)>=1?$tasklvelworkflowid->TASK_LEVEL_USERDEFINED_WORKFLOW_ID:'');
                    $storedata['TASK_LEVEL_USERDEFINED_WORKFLOW_ID']    =   $taskleveluserdefinedid;
                    $isautovalue                                        =   (isset($isAuto[$key])?$isAuto[$key]:0);
                    $storedata['IS_AUTO']                               =   $isautovalue;
                    $storedata['IS_SKIP']                               =   (isset($isSkip[$key])?$isSkip[$key]:0);
                    $storedata['STAGE_ID']                              =   $stageid[$key];
                    $storedata['IS_PARENT']                             =   true;
                    $storedata['RULE_TYPE']                             =   ($rule[$dynamickey] == null?'0':$rule[$dynamickey]);
                    $storedata['GOTO_STAGE_ID']                         =   ($gotorule[$dynamickey] == null?'':$gotorule[$dynamickey]);
                    $storedata['CREATED_BY']                            =   $this->loginUserId;
                    $storedata['CREATED_DATE']                          =   Carbon::now();
                    $storedata['IS_ACTIVE']                             =   1;
                    $addworkflowrule                                    =   userDefinedWorkflowRuleModel::store($storedata);
                    if($isautovalue     ==  1 || $isautovalue     ==  0)
                    {
                        taskLevelUserdefinedWorkflow::where('TASK_LEVEL_USERDEFINED_WORKFLOW_ID',$taskleveluserdefinedid)->update(['IS_AUTO'=>$isautovalue]);
                    }
                    if($request->has('subgotorule')) {
                        foreach($request->input('subgotorule') as $subgotorule){
                            foreach($subgotorule as $subgotokey=>$value){
                                if($subgotokey  ==  $stagenames[$key]){
                                    $subgotorowdata[]       =   $value;
                                }
                            }
                        }
                    }
                    if($request->has('subrule')) {
                        foreach($request->input('subrule') as $subrule){
                            foreach($subrule as $subgotokey=>$value){
                                if($subgotokey  ==  $stagenames[$key]){
                                    $subrowdata[]   =   $value;
                                }
                            }
                        }
                    }
                    if(count($subrowdata)>=1)
                    {
                        foreach($subrowdata as $subrowkey=>$subrowvalue)
                        {
                            $storesubdata['TASK_LEVEL_USERDEFINED_WORKFLOW_ID']     =    $taskleveluserdefinedid;
                            $storesubdata['IS_AUTO']                                =    (isset($isAuto[$key])?$isAuto[$key]:0);
                            $storesubdata['IS_SKIP']                                =    (isset($isSkip[$key])?$isSkip[$key]:0);
                            $storesubdata['STAGE_ID']                               =    $stageid[$key];
                            $storesubdata['IS_CHILD']                               =    true;
                            $storesubdata['RULE_TYPE']                              =    $subrowvalue;
                            $storesubdata['GOTO_STAGE_ID']                          =    $subgotorowdata[$subrowkey];
                            $storesubdata['CREATED_BY']                             =    $this->loginUserId;
                            $storesubdata['CREATED_DATE']                           =    Carbon::now();
                            $addchildworkflowrule                                   =    userDefinedWorkflowRuleModel::store($storesubdata);
                            unset($storesubdata);
                        }
                        unset($subgotorowdata);
                        unset($subrowdata);
                        $subrowdata         =   [];
                        $subgotorowdata     =   [];
                    }
                    $dynamickey++;
                }
                if($addworkflowrule>=1){
                     //delete exist user defined role
                    if($request->has('allruleids')) {
                        $allreuleids    =   $request->get('allruleids');
                        if(count($allreuleids)>=1)
                        {
                            userDefinedWorkflowRuleModel::wherein('ID',$allreuleids)->delete();
                        }
                    }
                    DB::commit();
                    return redirect()->back()->with("message","Workflow rule is added successfully...");
                }else{
                    DB::rollback();
                }
            }
            return redirect()->back()->withInput()->withErrors("Workflow rule is not added successfully try again...");
        } catch (\Exception $ex) {
            DB::rollback();
//            return $ex->getMessage();
            return redirect()->back()->withInput()->withErrors("Workflow rule is not added successfully try again...");
        }
    }
    
    public function workFlowRuleSetupremove(Request $request){
        $getid      =   $request->get('userdefid');
        $validation = 	Validator::make($request->all(), [
                                                            'userdefid' => 'required|numeric'
                                                        ]);

        if($validation->fails())
        {
            return response()->json($this->oopsErrorResponse,404);
        }
        $deleted    =   userDefinedWorkflowRuleModel::find($getid)->delete();
        if($deleted)
        {
            return response()->json($this->deletedResponse,200);
        }
        return response()->json($this->deletedFailedResponse,404);
    }
    
    public function deleteJobassignedWorkflow(Request $request)
    {
        try{
            $validation     =   Validator::make($request->all(), [
                                                    'wkrflwmasterId'=> 'required|numeric',
                                                    'wrkflowjobId' 	=> 'required|numeric',
                                                    'wrkflwround' 	=> 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $getworkflowmasterid    =   $request->input('wkrflwmasterId');
            $workjobid              =   $request->input('wrkflowjobId');
            $workroundid            =   $request->input('wrkflwround');
            $wheretaskleveldata     =   ['JOB_ID'=>$workjobid,'ROUND'=>$workroundid,'WORKFLOW_MASTER_ID'=>$getworkflowmasterid];
            $tasklvelworkflowid     =   taskLevelUserdefinedWorkflow::where($wheretaskleveldata)->get();
            if(count($tasklvelworkflowid)>=1)
            {
                $gettaskeveluserid  =   $tasklvelworkflowid->pluck('TASK_LEVEL_USERDEFINED_WORKFLOW_ID')->toArray();
                if(count($gettaskeveluserid)>=1)
                {
                    $deleteuserdefinedrole  =   userDefinedWorkflowRuleModel::wherein('ID',$gettaskeveluserid)->delete();
                    if($deleteuserdefinedrole){
                        $whereservermap     =   ['JOB_ID'=>$workjobid,'ROUND_ID'=>$workroundid,'WORKFLOW_MASTER_ID'=>$getworkflowmasterid];
                        workflowServerMapPathModel::where($whereservermap)->get();
                        return response()->json($this->deletedResponse);
                    }
                    return response()->json($this->deletedFailedResponse);
                }
            }
            return response()->json($this->notfoundResponse);
        }catch(\Exception $ex){
            $response   =   $this->notfoundResponse;
            $response['errMsg']     =   $ex->getMessage();
            return response()->json($response);
        }
    }
    
    
    
}