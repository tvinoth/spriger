<?php
namespace App\Http\Controllers\spicast;
use App\Http\Controllers\Controller;
use App\Models\jobModel;
use App\Jobs\Spicastbackgroundprocessqueue;
use App\Models\taskLevelMetadataModel;
use App\Models\productionLocationModel;
use App\Models\apiSpicastModel;
use App\Models\jobInfoModel;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Models\spicastProfileModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Session;
use Storage;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Artisan;
use DB; 
class spicastController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index()
    {
        $data               = 	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.BOOKINFO'),$data);
        $data['pageTitle']  = 	'Castoff';
        $data['pageName']   = 	'Castoff';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('spicast.spicast')->with($data);
    }
    
    public function getAllJoblist(Request $request)
    {
	$data                   =   jobModel::getSpicastdetails();
	$response["spicast"]    =   $data;
	return response()->json($response);
    }
    
    public function spicastView(Request $request,$jobId = null)
    {
        try
        {
            if($jobId 	==  null)
            {
                return redirect('/spicast');
            }
            if($request->method()   ==  "POST")
            {
    //            ini_set('extension', 'php_fileinfo.dll');
                $validation 	= 	Validator::make($request->all(), [
                                                                            'clientname' => 'required|max:100',
                                                                            'profilename' => 'required|numeric',
                                                                            'titlename' => 'required|max:100',
                                                                            'isbnname' => 'required',
                                                                            'authoremailid' => 'required|email',
                                                                            'spicastfile' => 'required|file'
                                                                    ]);

                if ($validation->fails())
                {
                    $response 	=	array('result'=>400,'errMsg'=>'All fields are required','validation'=>$validation->errors());
                    return response()->json($response);
                }
                $clientname     =   $request->input('clientname');
                $profilename    =   $request->input('profilename');
                $titlename      =   $request->input('titlename');
                $isbnname       =   $request->input('isbnname');
                $authoremailid  =   $request->input('authoremailid');
                $spicastfile    =   $request->file('spicastfile');
                if($spicastfile->getClientOriginalExtension() !=    "zip")
                {
                    return redirect()->back()->withErrors($validation->errors());
                }
                $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
                ini_set('post_max_size','100M');
                ini_set('upload_max_filesize','100M');
                if(count($getlocationftp)>=1)
                {
                    $hostserver     =   $getlocationftp->FTP_HOST;
                    $hostusername   =   $getlocationftp->FTP_USER_NAME;
                    $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                    $hostpath       =   $getlocationftp->FTP_PATH;
                    // Do the FTP connection
                    $ftpObj             =   Storage::createFtpDriver([
                                                        'host'     => $hostserver, 
                                                        'username' => $hostusername,
                                                        'password' => $hostpassword, // 
                                                        'port'     => '21',
                                                        'timeout'  => '30',
                                                ]);
                    $root               =   \Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
                    $ceroot             =   \Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
                    $castofffile        =   \Config::get("constants.BACKSLAH_CASTOFF_DESTINATION_PATH")."\\";
                    $datetime           =   date('dmyHms');
                    $filename           =   $datetime.$spicastfile->getClientOriginalName();
                    $spicastpath        =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').Config::get('constants.SPICAST_ZIP_FILE').$filename;
                    $locationspicast    =   Config::get('constants.FILE_SERVER_ROOT_DIR').Config::get('constants.SPICAST_ZIP_FILE');
                    $zipfileurl         =   "\\"."\\".$hostserver.$ceroot.$root.Config::get('constants.BACKSLAH_SPICAST_ZIP_FILE')."\\".$filename;
                    $fileupload         =   $ftpObj->put(Config::get('constants.SPICAST_ZIP_FILE').$filename,$spicastfile -> getClientOriginalName());
                    if($fileupload)
                    {
                        $spicast                        =   [];
                        $spicast['JOB_ID']              =   $jobId;
                        $spicast['SPICAST_PROFILE_ID']  =   $profilename;
                        $spicast['CLIENT_NAME']         =   $clientname;
                        $spicast['SPICAST_TITLE']       =   $titlename;
                        $spicast['SPICAST_ISBN']        =   $isbnname;
                        $spicast['SPICAST_EMAIL']       =   $authoremailid;
                        $spicast['SPICAST_PATH']        =   $spicastpath;
                        $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
                        $spicast['START_TIME']          =   Carbon::now();
                        $spicast['created_at']          =   Carbon::now();
                        $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
                        $storespicast                   =   apiSpicastModel::store($spicast);
                        // check layout is have or not for current book
                        $getlayoutprofile               =   jobInfoModel::where('JOB_ID',$jobId)->first();
                        $layoutprofile                  =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                        if(empty($layoutprofile))
                        {
                            $updatedata                 =   array('STATUS'=>'3','REMARKS'=>'Layout not added for this book');
                            $updatespicast              =   apiSpicastModel::where('ID',$storespicast->ID)->update($updatedata);
                        }
                        $baseurl                        =   url('/').'/api/apiSpicastToolresponse';
                        $getbook                        =   jobModel::where('JOB_ID',$jobId)->first();
                        $bookid                         =   (count($getbook)>=1?$getbook->BOOK_ID:'');
//                        $cucuserworkfolder              =   Config::get('constants.CUC_USER_WORK_FOLDER');
                        $ftp_path_                      =   \Config::get('serverconstants.PRE_PROCESSING_PATH');
                        $crd                            =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
                        $stagename                      =   Config::get('constants.STAGE_NAME.CUC');
                        $chapter_path                   =   $crd.$hostserver.$hostpath.$ftp_path_.$bookid.'/'.$stagename;
                        $ftpserver                      =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
                        $serverDirallFiles              =   $ftpserver->getDirectoryFiles( $chapter_path );    
                        if(count($serverDirallFiles)>=1)
                        {
                            $chapterfiles               =   [];
                            $readchapterfile            =   Config::get('constants.READ_TYPEOF_PM_FM');
                            foreach($serverDirallFiles as $key=>$jsonvalue)
                            {
                                if(strpos($jsonvalue,'/') !== 	false)
                                {
                                    $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                                    if(in_array(substr(strtolower($spiltchapter),0,2),$readchapterfile))
                                    {
                                        $chapterfiles[]     =   $spiltchapter;
                                    }
                                }
                            }                            
                            $serverDirFiles     =   taskLevelMetadataModel::getSpicastInfo($jobId);
                            $chapteravailfiles  =   [];
                            foreach($serverDirFiles as $files) 
                            {
                                if(in_array($files->CHAPTER_NO,$chapterfiles))
                                {
                                    $chapteravailfiles[$files->METADATA_ID]     =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\'.$stagename.'\\'.$files->CHAPTER_NO;
                                }
                            }
                            if(count($storespicast)>=1)
                            {
                                $xml                = 	new \XMLWriter();
                                $xml->openMemory();
                                $xml->startDocument();
                                $xml->startElement('Metadata');
                                $xml->setIndent(true);
                                $xml->startElement('Spicastdetails');

                                foreach($chapteravailfiles as $key=>$files) 
                                {
                                    $xml->startElement("Spicast"); 
                                    $xml->writeAttribute("spicast_id", $key); 
                                    $xml->text($files);
                                    $xml->endElement();  
                                }
                                $xml->endElement();
                                $xml->startElement('Zipfilelocation');
                                $xml->text($zipfileurl);
                                $xml->endElement();
                                $xml->startElement('Workflow');
                                //url parameter
                                $xml->startElement('Url');
                                $xml->writeAttribute('value', $baseurl);
                                $xml->writeAttribute('method', "post");
                                $xml->endElement();

                                //id parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "token");
                                $xml->writeAttribute('type', "fixed");
                                $xml->writeAttribute('value', $storespicast->TOKEN);
                                $xml->endElement();

                                //status parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "status");
                                $xml->endElement();

                                //end time parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "end_time");
                                $xml->writeAttribute('value', "Y-m-d H:m:i");
                                $xml->writeAttribute('type', "fixed");
                                $xml->endElement();

                                //jobid parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "job_id");
                                $xml->writeAttribute('value', $storespicast->JOB_ID);
                                $xml->writeAttribute('type', "fixed");
                                $xml->endElement();

                                //round parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "round");
                                $xml->writeAttribute('value', $storespicast->ROUND);
                                $xml->writeAttribute('type', "fixed");
                                $xml->endElement();

                                //remarks parameter
                                $xml->startElement('parameter');
                                $xml->writeAttribute('key', "remarks");
                                $xml->writeAttribute('value', '');
                                $xml->endElement();

                                $xml->endElement();
                                $xml->endElement();
                                $xml->endDocument();

                                $content 	= 	$xml->outputMemory();
                                $filename 	=	$bookid.'_SPICAST.xml';
                                $successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICAST_WATCH_FILE').'/'.$filename, $content);
                                //Session::put('status', 'Spicast added successfully'); 
                                $response 	=	array('result'=>200,'errMsg'=>'Castoff added successfully','validation'=>'');
                                return response()->json($response);
                            }
                        }
                        $response 	=	array('result'=>400,'errMsg'=>$bookid.' directory is empty...','validation'=>'');
                        return response()->json($response);
                    }
                    $response 	=	array('result'=>400,'errMsg'=>'Castoff not added successfully try again.','validation'=>'');
                    return response()->json($response);
                }else
                {
                    $response 	=	array('result'=>400,'errMsg'=>'File production location not found','validation'=>'');
                    return response()->json($response);
                }
            }
            $data                   =   array();
            $data['pageTitle']      =   'Castoff Details';
            $data['pageName']       =   'Castoff Details';
            $data['user_name']      =   Session::get('users')['user_name'];
            $data['role_name']      =   Session::get('users')['role_name'];
            return view('spicast.spicast-details')->with($data);
        }
        catch(\Exception $e )
        {
            $response 	=	array('result'=>400,'errMsg'=>$e->getMessage(),'validation'=>'');
            return response()->json($response);
        }
    }
    
    public function queuetest()
    {
           $spicast     =     $this->spicastBackgroundProcess('6611');
    }
    
    
    
    public function spicastBackgroundProcess($jobId,$copyEditing=0)
    {
        $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
        
        $response           =   array('result'=>404,'status'=>0,'msg'=> 'Production file is not connecting...');
        if(count($getlocationftp)>=1)
        {
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            $getbook            =   jobModel::getJobdetails($jobId);
            $getchapterfiles    =   [];
            $bookid             =   (count($getbook)>=1?$getbook->BOOK_ID:'');
            //check file exist or not
            //get artfiles word files start
            $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
            $readchapterfile    =   Config::get('constants.READ_CHAPTER_EXTENSTION');
            $readfmfile         =   Config::get('constants.FRONT_MATTER');
            $readbmfile         =   Config::get('constants.BACK_MATTER');
            $readparts          =   Config::get('constants.READ_TYPEOF_PART');
            $getartdirpath      =   $crd.$hostserver.$getlocationftp->FTP_PATH.Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.ART_SOURCE_PATHS');
            $ftpartObj          =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $getAtrDirFiles     =   $ftpartObj->getDirectoryFiles($getartdirpath);
            $artchaptersonly    =   [];
            $moveimageswithfm   =   [];
            $moveimageswithbm   =   [];
            $moveimageswithpart =   [];
            
           
            if(count($getAtrDirFiles)>=1 && !empty($getAtrDirFiles))
            {
                foreach($getAtrDirFiles as $key=>$jsonvalue)
                {
                    if(strpos($jsonvalue,'/') !== 	false)
                    {
                        $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                       
                        if(in_array(substr(strtolower($spiltchapter),0,2),$readchapterfile))
                        {
                            $artchaptersonly[]      =   $spiltchapter;
                        }
                        //read fm
                        if(in_array(substr(strtolower($spiltchapter),0,2),$readfmfile))
                        {
                            $artchaptersonly[]      =   $spiltchapter;
                        }
                        //read bm
                        if(in_array(substr(strtolower($spiltchapter),0,2),$readbmfile))
                        {
                            $artchaptersonly[]      =   $spiltchapter;
                        }
                        //read part
                        if(in_array(substr(strtolower($spiltchapter),0,2),$readparts))
                        {
                            $artchaptersonly[]      =   $spiltchapter;
                        }
                    }
                }
            }
            //get artfiles word files end
           
            //get copy editing word files start
            $getdirpath         =   $crd.$hostserver.$getlocationftp->FTP_PATH.Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.COPY_EDITING').'/';
          
            if($copyEditing == 1){
                $getdirpath         =   $crd.$hostserver.$getlocationftp->FTP_PATH.Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.STAGE_NAME.SPLIT').'/';
            }
                
            $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $serverDirFiles     =   $ftpObj->getDirectoryFiles($getdirpath);
            
           
            //get copy editing word files end
            $spicastfilestatus  =   (count($getbook)>=1?$getbook->SPICAST_FILE_STATUS:'');
            if($spicastfilestatus != 1)
            {
                if(count($artchaptersonly)>=1)
                {
                    $getchapterfiles    =   $this->doChapterfileCreation($bookid,$artchaptersonly,$getartdirpath,$hostserver, $hostusername , $hostpassword );
                }
                
                if(count($serverDirFiles)>=1 && is_array($serverDirFiles))
                {
                    $splitname          =   "";
                    $chapterfiles       =   [];
                    $chaptercount       =   [];
                    $partfiles          =   [];
                    $chapterfilesonly   =   [];
                    $fmfilesonly        =   [];
                    $bmfilesonly        =   [];
                    $partfilesonly      =   [];
                    $chapterfilesextention      =   [];
                    $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                    
                    $spicastbackgroundfile  =   Config::get('constants.SPICAST_BACKGROUND_FILE');
                    $spicastbackexcelfile   =   Config::get('constants.SPICAST_EXCEL_FILE');
                    $spicastbackprofilefile =   Config::get('constants.SPICAST_PROFILE_FILE');
                    //excel file creation
                    
                    $ftpObj->make_directory($spicastbackexcelfile);
                    //profile file creation
                    $ftpObj->make_directory($spicastbackprofilefile);
                   if($copyEditing == 1 ){
                      
                       $tasklevelModelObj     =   new taskLevelMetadataModel();
                       $chapterDetails            = $tasklevelModelObj->getMetadatadetailsJob($jobId);
                       if(!empty($chapterDetails)){
                           $pathDetails['withcredential']       = $getdirpath;
                           $pathDetails['withcredentialhost']   = $crd.$hostserver;
                           $pathDetails['withoutcredential']    = $getlocationftp->FTP_PATH.Config::get('constants.ART_DESTINATION_PATH').$bookid.'/SPLIT/';
                           $response                            =   $this->chapterfilesCreation($bookid,$chapterDetails,$pathDetails,$hostserver, $hostusername , $hostpassword)  ;
                       }
                       
                       $getchapterfiles     =   $response['copyed'];
                      
                   }else{
                       
                        foreach($serverDirFiles as $key=>$jsonvalue)
                        {

                            if(strpos($jsonvalue,'/') !== 	false)
                            {
                                
                                
                                $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                               
                                //read chapter
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readchapterfile))
                                {
                                    $chapterfilesonly[]     =   $spiltchapter;
                                }


                                //read fm
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readfmfile))
                                {
                                    $fmfilesonly[]          =   $spiltchapter;
                                }
                                //read bm
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readbmfile))
                                {
                                    $bmfilesonly[]          =   $spiltchapter;
                                }
                                //read part
                                if(in_array(substr(strtolower($spiltchapter),0,2),$readparts))
                                {
                                    $partfilesonly[]        =   $spiltchapter;
                                }
                            }
                        }

                        if(count($fmfilesonly)>=1)
                        {
                            $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$fmfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                        }
                        if(count($chapterfilesonly)>=1)
                        {
                            $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                        }
                        if(count($bmfilesonly)>=1)
                        {
                            $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$bmfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                        }
                        if(count($partfilesonly)>=1)
                        {
                            $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$partfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                        }
                    
                   }
                   
                   
                    if(count($getchapterfiles)>=1)
                    {
                       
                        if(count(array_unique($getchapterfiles)) === 1)  
                        {
                           
                            $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>'1');
                            $updated    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                        }
                        else
                        {
                            $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>'0');
                            $updated    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                        }
                    }
                    if(count($getchapterfiles)== 0)
                    {
                        $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>'0');
                        $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                    }
                }
                else
                {
                    $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>'0');
                    $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                }
            }
            $getbook            =   jobModel::getJobdetails($jobId);
            
            $UserDetails = DB::table('user AS u')
                ->where('u.USER_ID', $getbook->PM)
                ->select(DB::raw('u.EMAIL'))
                ->first();
            
            $spicastxmlstatus   =   (count($getbook)>=1?$getbook->SPICAST_XML_STATUS:'');
            $getprofilelayout   =   (count($getbook)>=1?$getbook->LAYOUT_PROFILE:'');
            $spicastfilestatus  =   (count($getbook)>=1?$getbook->SPICAST_FILE_STATUS:'');
            $titlename          =   (count($getbook)>=1?$getbook->JOB_TITLE:'');
            $getlayout          =   spicastProfileModel::where('SPICAST_ID',$getprofilelayout)->first();
            $profilename        =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
            $clientname         =   (count($getlayout)>=1?$getlayout->CLIENT_NAME:'');
            $peemilid           =   (count($UserDetails)>=1?$UserDetails->EMAIL:'');
            $isbnname           =   (count($getbook)>=1?$getbook->ISSN_ONLINE:'');
            $wheredata          =   array('JOB_ID'=>$jobId,'ROUND'=>Config::get('constants.ROUND_ID.S5'));
            $getspicastlastest  =   apiSpicastModel::where($wheredata)->latest()->first();
           
            if(count($getspicastlastest)    ==  0)
            {
                $spicast                        =   [];
                $spicast['JOB_ID']              =   $jobId;
                $spicast['SPICAST_PROFILE_ID']  =   $getprofilelayout;
                $spicast['CLIENT_NAME']         =   $clientname;
                $spicast['SPICAST_TITLE']       =   $titlename;
                $spicast['SPICAST_ISBN']        =   $isbnname;
                $spicast['SPICAST_EMAIL']       =   $peemilid;
                $spicast['SPICAST_PATH']        =   '';
                $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
                $spicast['START_TIME']          =   Carbon::now();
                $spicast['created_at']          =   Carbon::now();
                $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
                $spicast['REMARKS']             =   '';
                $storespicast                   =   apiSpicastModel::store($spicast);
                $getspicastlastest              =   apiSpicastModel::where('ID',$storespicast->ID)->latest()->first();
            }
            
            
            
            if(empty($getprofilelayout))
            {
                $updatedata     =   array('STATUS'=>'3','REMARKS'=>'Layout not added for this book');
                if(count($getspicastlastest)>=1)
                $updatespicast  =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
            }
            if($spicastxmlstatus    ==  '' || $spicastxmlstatus    ==  0)
            {
                $updatedata     =   array('STATUS'=>'3','REMARKS'=>'Spicast Xml Is not posted try again');
                if(count($getspicastlastest)>=1)
                $updatespicast  =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
                $response           =   array('result'=>200,'status'=>1,'msg'=> 'success');
            }
            if($spicastfilestatus    ==  '' || $spicastfilestatus    ==  0)
            {
                $updatedata     =   array('STATUS'=>'3','REMARKS'=>'Spicast file is not copied properly try again');
                if(count($getspicastlastest)>=1)
                $updatespicast  =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
                $response           =   array('result'=>200,'status'=>1,'msg'=> 'success');
            }
            //xml creation
            if($spicastxmlstatus !=     1 && $getprofilelayout  != '' && $spicastfilestatus  ==  1)
            {
                $xmlcreation    =   $this->doXmlcreation($jobId,$hostpath,$hostserver, $hostusername , $hostpassword,$getspicastlastest ,$peemilid);
            }
            $response           =   array('result'=>200,'status'=>1,'msg'=> 'success');
//            return $response;
        }
//        return $response;
    }
    
    public function doXmlcreation($jobId,$hostpath,$hostserver, $hostusername , $hostpassword,$getspicastlastest,$peemilid )
    {
        // Do the FTP connection
        $ftpObjlaravel      =   Storage::createFtpDriver([
                                                                                'host'     => $hostserver, 
                                                                                'username' => $hostusername,
                                                                                'password' => $hostpassword, // 
                                                                                'port'     => '21',
                                                                                'timeout'  => '30',
                                                                ]);
        
        $root               =   Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
        $ceroot             =   Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
        $castofffile        =   Config::get("constants.BACKSLAH_SPICAST_BACKGROUND_FILE")."\\";
        $castoffexcel       =   Config::get("constants.BACKSLAH_SPICAST_EXCEL_FILE");
        $castoffprofile     =   Config::get("constants.BACKSLAH_SPICAST_PROFILE_FILE");
        $baseurl            =   url('/').'/api/apiSpicastToolresponse';
        $getbook            =   jobModel::getJobdetails($jobId);
        $getchapterfiles    =   [];
        $bookid             =   (count($getbook)>=1?$getbook->BOOK_ID:'');
        $joblayout          =   (count($getbook)>=1?$getbook->LAYOUT_PROFILE:'');
        $getlayout          =   spicastProfileModel::where('SPICAST_ID',$joblayout)->first();
        $profilename        =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
        $clientname         =   (count($getlayout)>=1?$getlayout->CLIENT_NAME:'');
        $titlename          =   (count($getbook)>=1?$getbook->JOB_TITLE:'');
        $isbnname           =   (count($getbook)>=1?$getbook->ISSN_ONLINE:'');
        $ftp_path_          =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $spicastemailid     =   Config::get('constants.SPICASTOFF_EMAILID');
        $spicastxmlfilename =   Config::get('constants.SPICAST_XML_FILE');
        $bccemailid         =   'mohan.m@spi-global.com';
//        $chapter_path       =   $crd.$hostserver.$hostpath.$ftp_path_.$bookid.'/'.$stagename;
        $chapter_path       =   $ftp_path_.'/'.$bookid;
        $sourcepthurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\';    
        $excelpathurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castoffexcel.'\\';    
        $profilepathurl     =   "\\"."\\".$hostserver.$ceroot.$root.$castoffprofile.'\\'.$spicastxmlfilename;    
        $temppathurl        =   "C:\WATCH_FOLDERS_MAGNUS\SPiCast\Temp";  
//        $ftpserver          =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
//        $serverDirallFiles  =   $ftpserver->getDirectoryFiles( $chapter_path );    
        $serverDirallFiles  =   $ftpObjlaravel->allDirectories( $chapter_path );
        $result             =   array('message'=>'failed');
        $getallchapters     =   taskLevelMetadataModel::getSpicastInfo($jobId);
        $chapterlist        =   $getallchapters->pluck('CHAPTER_NO')->toArray(); 
        $getoriginalchapter =   [];
        $getoriginalchapterextn     =   [];
        if(count($serverDirallFiles)>=1)
        {
            $readfileextenstion     =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
            foreach($serverDirallFiles as $key=>$jsonvalue)
            {
                if(strpos($jsonvalue,'/') !== 	false)
                {
                    $spiltchapter       =   substr(strrchr($jsonvalue, "/"), 1);
                    if(in_array($spiltchapter,$chapterlist))
                    {
                        $serverDirFiles     =   $ftpObjlaravel->allFiles($chapter_path.'/'.$spiltchapter);
                        if(count($serverDirFiles)>=1)
                        {
                            foreach($serverDirFiles as $key=>$valueimg)
                            {
                                if(strpos($valueimg,'/') !== 	false)
                                {
                                    $chapterdocname     =   substr(strrchr($valueimg, "/"), 1);
                                    if(strpos($chapterdocname,'.') !== false)
                                    {
                                        $splitname      =   explode('.',$chapterdocname);
                                        if(in_array(trim($splitname[1]),$readfileextenstion) && in_array(trim($splitname[0]),$chapterlist))
                                        {
                                            $getoriginalchapter[]       =   $chapterdocname;
                                            $getoriginalchapterextn[]   =   trim($splitname[0]);
                                        }
                                    }
                                    else
                                    {
                                        $getoriginalchapter[]       =   $spiltchapter;
                                        $getoriginalchapterextn[]   =   "";
                                    }
                                }
                            }
                        }
                    }
                }
            }
//            $spicast                        =   [];
//            $spicast['JOB_ID']              =   $jobId;
//            $spicast['SPICAST_PROFILE_ID']  =   $joblayout;
//            $spicast['CLIENT_NAME']         =   $clientname;
//            $spicast['SPICAST_TITLE']       =   $titlename;
//            $spicast['SPICAST_ISBN']        =   $isbnname;
//            $spicast['SPICAST_EMAIL']       =   $peemilid;
//            $spicast['SPICAST_PATH']        =   '';
//            $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
//            $spicast['START_TIME']          =   Carbon::now();
//            $spicast['created_at']          =   Carbon::now();
//            $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
//            $storespicast                   =   apiSpicastModel::store($spicast);
            // check layout is have or not for current book
            $getlayoutprofile               =   jobInfoModel::where('JOB_ID',$jobId)->first();
            $layoutprofile                  =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
            if(empty($layoutprofile))
            {
                $updatedata                 =   array('STATUS'=>'3','REMARKS'=>'Layout not added for this book');
                $updatespicast              =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
            }else{
                $updatedata                 =   array('STATUS'=>'1.5','REMARKS'=>'');
                $updatespicast              =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
            }
            $serverDirFiles =   taskLevelMetadataModel::getSpicastInfo($jobId);
            $xml            = 	new \XMLWriter();
            $xml->openMemory();
            $xml->startDocument();
            $xml->startElement('SPiCast');
            $xml->setIndent(true);
            //client tag
            $xml->startElement('client');
            $xml->text($clientname);
            $xml->endElement();
            //profile tag
            $xml->startElement('profile');
            $xml->text($profilename);
            $xml->endElement();
            //input tag
            $xml->startElement('input');
                $xml->startElement("sourcepath"); 
                $xml->text($sourcepthurl);
                $xml->endElement();  
                $xml->startElement("excelpath"); 
                $xml->text($sourcepthurl);
                $xml->endElement();  
                $xml->startElement("profilepath"); 
                $xml->text($profilepathurl);
                $xml->endElement();  
            $xml->endElement();
            
            $xml->startElement('temppath');
                $xml->text($temppathurl);
            $xml->endElement();
            //mail tag
            $xml->startElement('mail');
            $xml->writeAttribute("titleid", $jobId); 
            $xml->writeAttribute("logid", $getspicastlastest->ID); 

                $xml->startElement("from"); 
                $xml->text($spicastemailid);
                $xml->endElement();  

                $xml->startElement("to"); 
                $xml->text($peemilid);
                $xml->endElement();  

                $xml->startElement("bcc"); 
                $xml->text($bccemailid);
                $xml->endElement();  

                $xml->startElement("bookId"); 
                $xml->text($bookid);
                $xml->endElement();
                
                $xml->startElement("isbn"); 
                $xml->text($isbnname);
                $xml->endElement();
                
                $xml->startElement("titlename"); 
                $xml->text($titlename);
                $xml->endElement();

            $xml->endElement();
            //chapter create 
            $xml->startElement('Spicastdetails');
            foreach($getoriginalchapterextn as $key=>$files) 
            {
                $wheredata          =   array('JOB_ID'=>$jobId,'CHAPTER_NO'=>$files);
                $getmetadata        =   taskLevelMetadataModel::where($wheredata)->first();
                $metadataID         =   (count($getmetadata)>=1?$getmetadata->METADATA_ID:'');
                $xml->startElement("Spicast"); 
                $xml->writeAttribute("spicast_id", $metadataID); 
                $xml->text($getoriginalchapter[$key]);
                $xml->endElement();  
            }
            $xml->endElement();
            //url parameter
            $xml->startElement('Url');
            $xml->writeAttribute('value', $baseurl);
            $xml->writeAttribute('method', "post");
            $xml->endElement();

            //id parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "token");
            $xml->writeAttribute('type', "fixed");
            $xml->writeAttribute('value', $getspicastlastest->TOKEN);
            $xml->endElement();

            //status parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "status");
            $xml->endElement();

            //end time parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "end_time");
            $xml->writeAttribute('value', "Y-m-d H:m:i");
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //jobid parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "job_id");
            $xml->writeAttribute('value', $getspicastlastest->JOB_ID);
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //round parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "round");
            $xml->writeAttribute('value', $getspicastlastest->ROUND);
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //remarks parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "remarks");
            $xml->writeAttribute('value', '');
            $xml->endElement();

            $xml->endElement();
            $xml->endElement();
            $xml->endDocument();

            $content 	= 	$xml->outputMemory();
            $filename 	=	$bookid.'_SPICAST.xml';
            $successfileresponse 	=	$ftpObjlaravel->put(Config::get('constants.SPICAST_WATCH_FILE').'/'.$filename, $content);
            if($successfileresponse ==     true)
            {
                $result             =   array('message'=>'success');
                $updatespicastdata  =   array('SPICAST_XML_STATUS'=>'1');
                $xmlstatusupdate    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
            }
            else
            {
                $result             =   array('message'=>'failed');
                $updatespicastdata  =   array('SPICAST_XML_STATUS'=>'0');
                $xmlstatusupdate    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
            }
            return $result;
        }
        return $result;
    }
    // fm and bm creation
    public function dofrontbackfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword )
    {
        
        
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
        $spicastbackgroundfile    =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $filedocxnotfound   =   []; 
        $chapterfiles       =   [];
        $result             =   [];
        $copystagename      =   Config::get('constants.STAGE_NAME.COPY_EDITING');
        foreach($chapterfilesonly as $key=>$valueoffiles)
        {
          
            $serverDirFiles =   $ftpObj->getDirectoryFiles($getdirpath.$valueoffiles);
           
            if(count($serverDirFiles)>=1)
            {
                foreach($serverDirFiles as $key=>$jsonvalue)
                {
                    if(strpos($jsonvalue,'/') !== 	false)
                    {
                        $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                        
                        if(strpos($spiltchapter,'.') !== false)
                        {
                            $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                            $chapterfilesextention[]=   $originalchapter;
                           
                            if(in_array(strtolower($originalchapter),$readfileextenstion))
                            {
                               
                                $splitname          =   explode('.',$spiltchapter);
                              
                                if(true)
                                {
                                    $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                    $replacecrd     =   str_replace($crd,'',$replacecrd);
                                    $sourcefile     =   $replacecrd.$valueoffiles.'/'.$spiltchapter;
                                    $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.'/'.$spiltchapter;
                                    
                                    $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid);
                                    $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                   
                                   
                                    if($getsuccessorfile !==     true)
                                    {
                                        $result[]   =    'failed'; 
                                    }
                                    else
                                    {
                                        $result[]   =    'success'; 
                                    }
                                }
                            }else{ $filedocxnotfound[]     =   $spiltchapter;}
                        }
                    }
                }
            }
            else
            {
                $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles);
            }
        }
        return $result;
    }
    
     public function chapterfilesCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword )
    {
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
        $spicastbackgroundfile    =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $filedocxnotfound   =   []; 
        $chapterfiles       =   [];
        $result             =   [];
        $copystagename      =   Config::get('constants.STAGE_NAME.COPY_EDITING');
        
        
        foreach($chapterfilesonly as $key=>$valueoffiles)
        {
           // $getdirpath         =          
            //$chapterName        =   $getdirpath.$valueoffiles->CHAPTER_NO;
            $fileExist          =   $getdirpath['withoutcredential'].$valueoffiles->CHAPTER_NO;
           
            $fileExist          =   $ftpObj->ftpFileExist($fileExist.'.docx');
            $filecopy           =   '';
            if($fileExist == true ){
                $filecopy       =   $valueoffiles->CHAPTER_NO.'.docx';
            }else {
                $fileExist          =   $ftpObj->ftpFileExist($fileExist.'.doc');
                if($fileExist == true){
                    $filecopy       =   $valueoffiles->CHAPTER_NO.'.doc';
                }else{
                    $copyedFiles['filenotfound'][]     =   $valueoffiles->CHAPTER_NO;
                }
            }
          
            if(!empty($filecopy)){
                $destpath       =   $getdirpath['withcredentialhost'].'/'.$spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles->CHAPTER_NO;
                $scrPath        =   $getdirpath['withcredential'].$filecopy;
                $response       =   $ftpObj->ftpSingleFileCopyOrMove($scrPath,$destpath.'/'.$filecopy );
                if($response == true){
                    $copyedFiles['copyed'][$filecopy]  =   'success';
                }else{
                    $copyedFiles['copyed'][$filecopy]  =   'failed';
                }
                
            }
            
        }
        return $copyedFiles;
    }
    
    //chapter cretion 
    public function doChapterfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword )
    {
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
        $spicastbackgroundfile    =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
//        $spicastimgextn     =   Config::get('constants.SPICAST_IMAGE_FILEXTN'); 
        $spicastimgextn     =   Config::get('constants.ART_IMAGE_VALIDATION_FILEXTN'); 
        $spicastimgfilename =   Config::get('constants.SPICAST_IMAGES_FILE'); 
        $chapterfiles       =   [];
        $result             =   [];
        foreach($chapterfilesonly as $key=>$valueoffiles)
        {
            $serverDirFiles     =   $ftpObj->getDirectoryFiles($getdirpath.$valueoffiles);
            if(count($serverDirFiles)>=1)
            {
                foreach($serverDirFiles as $key=>$jsonvalue)
                {
                    if(strpos($jsonvalue,'/') !== 	false)
                    {
                        $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                        if(strpos($spiltchapter,'.') !== false)
                        {
                            $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                            /*$chapterfilesextention[]=   $originalchapter;
                            if(in_array(strtolower($originalchapter),$readfileextenstion))
                            {
                                $splitname          =   explode('.',$spiltchapter);
                                if($valueoffiles    ==  trim($splitname[0]))
                                {
                                    $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                    $replacecrd     =   str_replace($crd,'',$replacecrd);
                                    $sourcefile     =   $replacecrd.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid);
                                    $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                    if($getsuccessorfile !==     true)
                                    {
                                        $result[]   =    'failed'; 
                                    }
                                }
                            }*/
                            if(in_array(strtoupper($originalchapter),$spicastimgextn))
                            {
                                $splitname      =   explode('.',$spiltchapter);
                                $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                $replacecrd     =   str_replace($crd,'',$replacecrd);
                                $sourcefile     =   $replacecrd.$valueoffiles.'/'.$splitname[0].'.'.$splitname[1];
                                $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.$spicastimgfilename.$splitname[0].'.'.$splitname[1];
                                $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.$spicastimgfilename);
                                $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                if($getsuccessorfile !==     true)
                                {
                                    $result[]   =    'failed'; 
                                }
                                else
                                {
                                    $result[]   =    'success'; 
                                }
                                $chapterfiles[]     =   trim($splitname[0]);
                            }
                        }
                    }
                }
            }
            else
            {
                $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles);
            }
        }
        return $result;
    }
    
    public function dofilecopyprocess($hostserver, $hostusername , $hostpassword ,$sourcefile,$desfile)
    {
        $ftplarvelObj       =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
        if($ftplarvelObj->has($desfile))
        {
            $ftplarvelObj->delete($desfile);
            $putfile    =	$ftplarvelObj->copy($sourcefile,$desfile,0777);
        }
        else
        {
            $putfile    =	$ftplarvelObj->copy($sourcefile,$desfile,0777);
        }
        return $putfile;
    }
    public function doUpdatefiledfilemove($jobId,$updatedata    =   [])
    {
        $updatejobinfo  =   jobInfoModel::where('JOB_ID',$jobId)->update($updatedata);
        return $updatejobinfo;
    }
	
//    public function spicastBackgroundProcess($jobId = null)
//    {
//        try
//        {
//            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
//            if(count($getlocationftp)>=1)
//            {
//                $hostserver     =   $getlocationftp->FTP_HOST;
//                $hostusername   =   $getlocationftp->FTP_USER_NAME;
//                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
//                $hostpath       =   $getlocationftp->FTP_PATH;
//                // Do the FTP connection
//                $ftpObj             =   Storage::createFtpDriver([
//                                                    'host'     => $hostserver, 
//                                                    'username' => $hostusername,
//                                                    'password' => $hostpassword, // 
//                                                    'port'     => '21',
//                                                    'timeout'  => '30',
//                                            ]);
//                $root               =   Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
//                $ceroot             =   Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
//                $castofffile        =   Config::get("constants.BACKSLAH_CASTOFF_DESTINATION_PATH")."\\";
//                $baseurl            =   url('/').'/api/apiSpicastToolresponse';
//                $getbook            =   jobModel::getJobdetails($jobId);
//                $bookid             =   (count($getbook)>=1?$getbook->BOOK_ID:'');
//                $joblayout          =   (count($getbook)>=1?$getbook->LAYOUT_PROFILE:'');
//                $getlayout          =   spicastProfileModel::where('SPICAST_ID',$joblayout)->first();
//                $profilename        =   (count($getbook)>=1?$getlayout->PROFILE_NAME:'');
//                $clientname         =   (count($getbook)>=1?$getlayout->CLIENT_NAME:'');
//                $peemilid           =   (count($getbook)>=1?$getbook->PE_MAIL:'');
//                $titlename          =   (count($getbook)>=1?$getbook->JOB_TITLE:'');
//                $isbnname           =   (count($getbook)>=1?$getbook->ISSN_ONLINE:'');
//                $ftp_path_          =   Config::get('serverconstants.PRE_PROCESSING_PATH');
//                $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
//                $stagename          =   Config::get('constants.STAGE_NAME.CUC');
//                $spicastemailid     =   Config::get('constants.SPICASTOFF_EMAILID');
//                $bccemailid         =   'mohan.m@spi-global.com';
//                $chapter_path       =   $crd.$hostserver.$hostpath.$ftp_path_.$bookid.'/'.$stagename;
//                $sourcepthurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\'.$stagename.'\\';    
//                $excelpathurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\'.$stagename.'\\';    
//                $profilepathurl     =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\'.$stagename.'\\';    
//                $ftpserver          =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
//                $serverDirallFiles  =   $ftpserver->getDirectoryFiles( $chapter_path );    
//                if(count($serverDirallFiles)>=1)
//                {
//                    
//                    $spicast                        =   [];
//                    $spicast['JOB_ID']              =   $jobId;
//                    $spicast['SPICAST_PROFILE_ID']  =   $joblayout;
//                    $spicast['CLIENT_NAME']         =   $clientname;
//                    $spicast['SPICAST_TITLE']       =   $titlename;
//                    $spicast['SPICAST_ISBN']        =   $isbnname;
//                    $spicast['SPICAST_EMAIL']       =   $peemilid;
//                    $spicast['SPICAST_PATH']        =   '';
//                    $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
//                    $spicast['START_TIME']          =   Carbon::now();
//                    $spicast['created_at']          =   Carbon::now();
//                    $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
//                    $storespicast                   =   apiSpicastModel::store($spicast);
//                    // check layout is have or not for current book
//                    $getlayoutprofile               =   jobInfoModel::where('JOB_ID',$jobId)->first();
//                    $layoutprofile                  =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
//                    if(empty($layoutprofile))
//                    {
//                        $updatedata                 =   array('STATUS'=>'2','REMARKS'=>'Layout not added for this book');
//                        $updatespicast              =   apiSpicastModel::where('ID',$storespicast->ID)->update($updatedata);
//                    }
//                    
//                    $xml            = 	new \XMLWriter();
//                    $xml->openMemory();
//                    $xml->startDocument();
//                    $xml->startElement('SPiCast');
//                    $xml->setIndent(true);
//                    //client tag
//                    $xml->startElement('client');
//                    $xml->text($clientname);
//                    $xml->endElement();
//                    //profile tag
//                    $xml->startElement('profile');
//                    $xml->text($profilename);
//                    $xml->endElement();
//                    //input tag
//                    $xml->startElement('input');
//                        $xml->startElement("sourcepath"); 
//                        $xml->text($sourcepthurl);
//                        $xml->endElement();  
//                        $xml->startElement("excelpath"); 
//                        $xml->text($excelpathurl);
//                        $xml->endElement();  
//                        $xml->startElement("profilepath"); 
//                        $xml->text($profilepathurl);
//                        $xml->endElement();  
//                    $xml->endElement();
//                    //mail tag
//                    $xml->startElement('mail');
//                    $xml->writeAttribute("titleid", $jobId); 
//                    $xml->writeAttribute("logid", $storespicast->ID); 
//                        
//                        $xml->startElement("from"); 
//                        $xml->text($spicastemailid);
//                        $xml->endElement();  
//                        
//                        $xml->startElement("to"); 
//                        $xml->text($peemilid);
//                        $xml->endElement();  
//                        
//                        $xml->startElement("bcc"); 
//                        $xml->text($bccemailid);
//                        $xml->endElement();  
//                        
//                        $xml->startElement("subject"); 
//                        $xml->text($profilepathurl);
//                        $xml->endElement();  
//                        
//                    $xml->endElement();
//                    
//                    //url parameter
//                    $xml->startElement('Url');
//                    $xml->writeAttribute('value', $baseurl);
//                    $xml->writeAttribute('method', "post");
//                    $xml->endElement();
//
//                    //id parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "token");
//                    $xml->writeAttribute('type', "fixed");
//                    $xml->writeAttribute('value', $storespicast->TOKEN);
//                    $xml->endElement();
//
//                    //status parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "status");
//                    $xml->endElement();
//
//                    //end time parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "end_time");
//                    $xml->writeAttribute('value', "Y-m-d H:m:i");
//                    $xml->writeAttribute('type', "fixed");
//                    $xml->endElement();
//
//                    //jobid parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "job_id");
//                    $xml->writeAttribute('value', $storespicast->JOB_ID);
//                    $xml->writeAttribute('type', "fixed");
//                    $xml->endElement();
//
//                    //round parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "round");
//                    $xml->writeAttribute('value', $storespicast->ROUND);
//                    $xml->writeAttribute('type', "fixed");
//                    $xml->endElement();
//
//                    //remarks parameter
//                    $xml->startElement('parameter');
//                    $xml->writeAttribute('key', "remarks");
//                    $xml->writeAttribute('value', '');
//                    $xml->endElement();
//
//                    $xml->endElement();
//                    $xml->endElement();
//                    $xml->endDocument();
//
//                    $content 	= 	$xml->outputMemory();
//                    $filename 	=	$bookid.'_SPICAST.xml';
//                    $successfileresponse 	=	$ftpObj->put(Config::get('constants.SPICAST_WATCH_FILE').'/'.$filename, $content);
//                    //Session::put('status', 'Spicast added successfully'); 
//                    $response 	=	array('result'=>200,'errMsg'=>'Castoff added successfully');
//                    return $response;
//                }
//            }
//            $response 	=	array('result'=>400,'errMsg'=>'production location not found');
//            return $response;
//        }
//        catch(\Exception $e )
//        {
//            $response 	=	array('result'=>400,'errMsg'=>$e->getMessage(),'validation'=>'');
//            return response()->json($response);
//        }
//    }
    
    public function castoffDetails(Request $request)
    {
        if ($request->input('jodId') == null) 
        {
            $response = array('result' => 400, 'msg' => 'Bad Request sending kindly reload page');
            return response()->json($response, 400);
        }
        $jobId                      =   $request->input('jodId');
        $getresultofjob             =   jobModel::getJobdetails($jobId);
        $data                       =   [];
        if(count($getresultofjob)>=1)
        {
            $data['projectId']      =   $jobId;
            $data['book_title']     =   (count($getresultofjob)>=1?$getresultofjob->JOB_TITLE:'');
            $data['book_id']        =   (count($getresultofjob)>=1?$getresultofjob->BOOK_ID:'');
            $data['ISSN_ONLINE']    =   (count($getresultofjob)>=1?$getresultofjob->ISSN_ONLINE:'');
            $data['AUTHOR_EMAIL']   =   (count($getresultofjob)>=1?$getresultofjob->PE_MAIL:'');
            $data['profiles']       =   spicastProfileModel::getSpicastlist();
        }
        return response()->json($data);
    }
}
    
