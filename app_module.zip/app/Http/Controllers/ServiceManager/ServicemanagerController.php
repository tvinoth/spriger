<?php

namespace App\Http\Controllers\ServiceManager;

use App\Http\Controllers\Controller;
use App\Models\ServiceManager as ServiceModel;
use App\Models\componentCategoryModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Validation\Rule;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB;

class ServicemanagerController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request) {
        $data = array();
        $sourceview = componentCategoryModel::Promotionactive()->get();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_SERVICE_MANAGER'),$data);
        return view('ServiceManager.index')->with($data);
    }
    
    public function view(){
        try {
            $servicedata    =   ServiceModel\ServiceManagerEnumModel::select(DB::Raw("ID,SERVICENAME,SERVICE_URL,SERVICE_TYPE,SERVICE_PARAMS,IS_ACTIVE,CREATED_DATE"))->orderBy('ID','desc')->get();      
            $serviceurl     =   ServiceModel\ServiceManagerUrlModel::select(DB::Raw("ID as URL_ID,NAME,IS_ACTIVE,CREATED_DATE"))->get();      
            $data               =   $this->successResponse;
            $data['servicedata']=   $servicedata;
            $data['serviceurl'] =   $serviceurl;
            return response()->json($data);
        } catch (\Exception $e) {
            return response()->json($this->insertedFailedResponse);
        }
    }
    
    
    public function add(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'servicename' => ['required',Rule::unique('service_manager_enum')->where(function ($query) use ($request) {
                                            return $query->where('IS_ACTIVE', 1);
                                        })]
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }

            $servicename    =   $request->input('servicename');
            $getlastid      =   ServiceModel\ServiceManagerEnumModel::select(DB::Raw('ID'))->orderBy('ID','desc')->first();
            $code           =   "#SERVICE";
            if($getlastid !=    null){
                $lastidval  =   $getlastid->ID+1;
                $code       =   $code.$lastidval;
            }else{
                $code       =   $code."1";
            }
            $adddata        =   new ServiceModel\ServiceManagerEnumModel();
            $adddata['SERVICENAME']   =   trim($servicename);
            $adddata['CODE']    =   trim($code);
            $adddata->save();
            if($adddata){
                return response()->json($this->insertedResponse);
            }
            return response()->json($this->insertedFailedResponse);
        } catch (\Exception $e) {
            return response()->json($this->insertedFailedResponse);
        }
    }
    
    public function update(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'serviceurl'    =>  'required',
                        'updateexistidval'  =>  'required|numeric',
                        'serviceparam'  =>  'required',
                        'servicestatus'  =>  'required|numeric',
                        'servicename' => ['required',Rule::unique('service_manager_enum')->where(function ($query) use ($request) {
                                            return $query->where('IS_ACTIVE', 1)->where('ID','<>',$request->input('updateexistidval'));
                                        })],
                        'servicetype'    =>  'required|numeric',
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }

            $existId        =   $request->input('updateexistidval');
            $updatedata     =   ServiceModel\ServiceManagerEnumModel::find($existId);   
            if($updatedata !=   null){
                $updatedata['SERVICENAME']      =   trim($request->input('servicename'));
                $updatedata['SERVICE_URL']      =   trim($request->input('serviceurl'));
                $updatedata['SERVICE_TYPE']     =   trim($request->input('servicetype'));
                $updatedata['SERVICE_PARAMS']   =   trim($request->input('serviceparam'));
                $updatedata['IS_ACTIVE']        =   trim($request->input('servicestatus'));
                $updatedata->save();
                $data       =   ServiceModel\ServiceManagerEnumModel::select(DB::Raw("ID,SERVICENAME,SERVICE_URL,SERVICE_TYPE,SERVICE_PARAMS,IS_ACTIVE,CREATED_DATE"))->where('ID',$existId)->first();
                $response   =   $this->updatedResponse;
                $response['validation']     =   $data;
                return response()->json($response);
            }
            return response()->json($this->notfoundResponse);
        } catch (\Exception $e) {
            return response()->json($this->notfoundResponse);
        }
    }
    
    public function delete(Request $request) 
    {
        try{
            $response   =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'serviceid'  => 'required|numeric'
                                                ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $getId          =   $request->input('serviceid');
            $deletedata     =   ServiceModel\ServiceManagerEnumModel::find($getId);
            if($deletedata != null)
            {
                $response   =   $this->deletedResponse;
                $deletedata->delete();
                return response()->json($response);
            }
            return response()->json($response);
        }catch( \Exception $e ){
            return response()->json($response);
        }
    }
}
