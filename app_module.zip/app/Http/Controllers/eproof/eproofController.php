<?php
namespace App\Http\Controllers\eproof;
use App\Http\Controllers\Controller;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\productionLocationModel;
use App\Models\jobInfoModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\CountriesModel;
use App\Models\taskLevelMetadataModel;
use App\Models\apiProofingStatus;
use App\Models\apiEproofPackagingModel;
use App\Models\apsProofingStatusModel;
use App\Models\apiFtpUpload;
use App\Models\apsRemainderEmailonoffModel;
use App\Models\emailRemainderCorrectionHistoryModel;
use App\Models\emailRemainderLogModel;
use App\Models\remainderEmailTemplateModel;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use App\Console\Commands\Eproofremaindermail;
use Session;
use Mail;
use Storage;
use Carbon\Carbon;
use Validator;
use File;
use DB;
use Log;
use Config;

class eproofController extends Controller
{   
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function doEproofVendorpackagecreate( $jobId , $metadataID , $roundId , $typeofpprcoess ,$proofingtype = null)
    {
        try
        {   
            $response           =   $this->notfoundResponse;
            $usrC_obj           =   new usersController();
            $bookdata           =   jobModel::getjobInfodetails($jobId);
            $wheredata          =   ['METADATA_ID'=>$metadataID,'JOB_ID'=>$jobId];
            $getchapter         =   taskLevelMetadataModel::where($wheredata)->first();
            $tapsdata           =   [];
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1 && count($bookdata)>=1 && count($getchapter)>=1)
            {
                if($proofingtype != '' && $proofingtype != 0){
                    $getchapter->EPROOFING_SYSTEM   =   $proofingtype;
                    $getchapter->save();
                }
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]); 
                
                $stage_name         =   Config::get('constants.ROUND_NAME.'.$roundId);
                $getoriginalchapter =   [];
                $getartpaths        =   [];
                $getchapterpaths    =   [];	

                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->setIndent(true);
                    $xml->startElement('eProofResponse');
                    $xml->writeAttribute("timestamp", Carbon::now()); 
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    $xml->startElement('ChapterID');
                    $xml->text($getchapter->CHAPTER_NO);
                    $xml->endElement();

                    $currentuser_id     =   $bookdata->PM;
                    $user_arr           =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
                    $additional_email   =   $getchapter->ADDITIONAL_RECIPIENT;
                    $email_collect      =   explode( ',' , $additional_email );
                    $new_arr            =   array_map('trim',$email_collect);
                    $additional_email   =   ( implode( ', ',$new_arr) );

                    //VENDOR DETAILS
                    if(count($user_arr)>=1)
                    {
                        $xml->startElement('VendorDetails');
                        $xml->startElement("Name"); 
                        $xml->text('SPi_Global');
                        $xml->endElement();
                        $xml->startElement("ProjectManagerName"); 
                        $xml->text($user_arr->FIRST_NAME.' '.$user_arr->LAST_NAME);
                        $xml->endElement();
                        $xml->startElement("Phone"); 
                        $xml->text($user_arr->PERSONAL_PHONE);
                        $xml->endElement(); 
                        $xml->startElement("Fax"); 
                        $xml->text($user_arr->FAX);
                        $xml->endElement(); 
                        $xml->startElement("Email"); 
                        $xml->text($user_arr->EMAIL);
                        $xml->endElement(); 
                        $xml->startElement("AdditionalEmail"); 
                        $xml->text( $additional_email );
                        $xml->endElement(); 
                    }
                    else {
                        $xml->startElement('VendorDetails');
                        $xml->startElement("Name"); 
                        $xml->text('');
                        $xml->endElement(); 
                        $xml->startElement("ProjectManagerName"); 
                        $xml->text('');
                        $xml->endElement();
                        $xml->startElement("Phone"); 
                        $xml->text('');
                        $xml->endElement(); 
                        $xml->startElement("Fax"); 
                        $xml->text('');
                        $xml->endElement(); 
                        $xml->startElement("Email"); 
                        $xml->text('');
                        $xml->endElement(); 
                        $xml->startElement("AdditionalEmail"); 
                        $xml->text('');
                        $xml->endElement(); 
                    }
                    
                    $xml->endElement();
                    $xml->endDocument();
                    $content 	= 	$xml->outputMemory();
                    $filename 	=	'VendorDetails.xml';
                    $bookidreplace          =   array(
                                                    '{BID}'     =>  $bookid,
                                                    '{RNAME}'   =>  $stage_name,
                                                    '{CNAME}'   =>  $getchapter->CHAPTER_NO
                                                 );
                    
                    $vendorxmlpath          =   Config::get( 'constants.VENDORXML_FILE');
                    $cmn_obj                =   new CommonMethodsController();
                    $vendorxmlpath          =   $cmn_obj->arr_key_value_replace( $bookidreplace , $vendorxmlpath , true );
                    
                    if( empty( $getchapter->EPROOFING_RECIPIENT ) ){
                        
                        $tokenkey           =   $cmn_obj->generateRandomString( 16 , 'api_eproof_packaging' , 'TOKEN_KEY'  );                         
                        $insertdata['TOKEN_KEY']    =      $tokenkey;
                        //insert eproof package error data
                        $insertdata['JOB_ID']       =   $jobId;
                        $insertdata['METADATA_ID']  =   $metadataID;
                        $insertdata['ROUND']        =   $roundId;
                        $insertdata['created_at']   =   Carbon::now();
                        $insertdata['START_TIME']   =   Carbon::now();
                        $insertdata['STATUS']       =   "3";
                        $insertdata['PACKAGE_ID']       =   'Failure Package '.$metadataID.'_'.$roundId.'_'.$tokenkey.'_'.date('Y_m_d_h_i_s').'.zip';
                        $insertdata['REMARKS']      =   "ReadMetaChk : E-Proof recipient email is not found";
						
                        //check exist data
                        $wheredata  =   ['METADATA_ID'=>$metadataID,'ROUND'=>$roundId,'PROCESS_TYPE'=>"1",'JOB_ID'=>$jobId,'PACKAGE_ID'=>""];
                        $checkExist     =   apiEproofPackagingModel::where($wheredata)->orderBy('ID','desc')->first();
                        
                        if(empty($checkExist)){
                            
                            apiEproofPackagingModel::insert($insertdata);
                            
                        }else{
                            $checkExist->STATUS     =   "3";
                            $checkExist->updated_at =   Carbon::now();
                            $checkExist->REMARKS    =   "ReadMetaChk :E-Proof recipient email is not found";
                            $checkExist->save();
                        }
                        $response['errMsg']     =   'E-Proof recipient email is not found';
                        return response()->json($response,404);
                    }
                    
                    $successfileresponse    =	$ftpObj->put($vendorxmlpath.'/'.$filename, $content);
                    
                    if($successfileresponse ==     true){
                        
                        $this->deactivateExistingEntry( $metadataID , $roundId );
                        
                        $eprCntrl           =      new bgprocessController();
                        $successfileresponse    =   $eprCntrl->doPrepareeproofpackageMetaXmlFormat(  $metadataID , $roundId ,  'package' , $jobId, $optional = array(  'level' => 1 , 'metacollect' => array() ),$typeofpprcoess );
                        
                        //$successfileresponse    =   app('App\Http\Controllers\bgprocess\bgprocessController')->doPrepareeproofpackageMetaXmlFormat(  $metadataID , $roundId ,  'package' , $jobId, $optional = array(  'level' => 1 , 'metacollect' => array() ) );
                        
                        return response()->json($successfileresponse);

                    }else{
                        
                        $result             =   array('message'=>'failed');
                        
                    }
                    $response       =   $this->successResponse;
                    $response['errMsg']     =   'Eproof package xml posted sucessfuly...';
                    return response()->json($response);
            }
            return response()->json($response,404);
        } 
        catch( \Exception $e )
        {           
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        } 
    }
    
    public function deactivateExistingEntry( $metaid, $round ){
        
        try{
            
            $query1  = "UPDATE api_eproof_packaging SET IS_ACTIVE = 0 WHERE METADATA_ID = $metaid AND ROUND=$round AND STATUS >= 2 LIMIT 1";
            $query2  = "UPDATE api_ftp_upload SET IS_ACTIVE = 0 WHERE METADATA_ID = $metaid AND ROUND=$round AND PROCESS_TYPE = 2 AND STATUS >= 2 LIMIT 1";
            $query3  = "UPDATE api_client_acknowledgement SET IS_ACTIVE = 0 WHERE METADATA_ID = $metaid AND ROUND=$round AND PROCESS_TYPE = 5 AND FILE_NAME_IN_LOG LIKE '%eProof_Contri%' AND STATUS >= 2 LIMIT 1";

            DB::update( $query1 );
            DB::update( $query2 );
            DB::update( $query3 );
            
            return true;
            
        }  catch ( \Exception $e  ){
            
            $errMsg         =           $e->getMessage();
            Log::useDailyFiles( storage_path().'/Api/status_deactivate.log' );
            Log::info($query1);
            Log::info($query2);
            Log::info($query3);
            Log::info( str_repeat( '****' , 50 ) .PHP_EOL );
            Log::info( $errMsg );
            Log::info( $e->getTraceAsString() );
            Log::info( str_repeat( '======' , 50 ) .PHP_EOL );
            return false;
        }
    }
    
    public function domailsendproofrecipient(Request $request) 
    {
        try{
            $response       =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'metadtaid'     => 'required|numeric'
                                                ]);
            if ($validation->fails()){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $metadataid         =   $request->input('metadtaid');
            $jobid              =   $request->input('jobid');
            $mailArray          =   $mailData   =   [];
            
            $job_info           =   jobModel::getJobdetails($jobid);
            $getrecipientmail   =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
            if(count($job_info)>=1 && count($getrecipientmail)>=1)
            {
                $mailsendFlag       =   false;
                $mailtoAmFlag       =   false;
                $mailtoPmFlag       =   false;
                $pm_userid          =   $job_info->PM;
                $am_userid          =   $job_info->AM;
                $jobId              =   $job_info->JOB_ID;
                if( !empty( $pm_userid ) ){

                   $usrC_obj        =   new usersController();
                   $user_arr        =   $usrC_obj->getUserInfoByUserId($pm_userid); 
                   $pm_name         =   $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
                   $pm_mail         =   $user_arr->EMAIL;

                   $mailData['ToName']      =   $pm_name;
                   $mailData['prdl']        =   $pm_name;
                   $mailArray['ToMail']     =   $pm_mail;
                   $data_in['user_id']      =   $pm_userid;  

                }else if( !empty( $am_userid )){

                    $am_name                =   $job_info->AM_NAME;
                    $am_mail                =   $job_info->AM_MAIL;

                    $mailData['ToName']     =   $am_name;
                    $mailArray['ToMail']    =   $am_userid;
                    $data_in['user_id']     =   $am_userid;  
                }else{
                    return false;
                }
                $mailArray['ToMail']        =   $getrecipientmail->EPROOFING_RECIPIENT;
                $round  =   "104";
                $pickroundname  =   [ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
                $stagename      =   (isset($pickroundname[$round])?$pickroundname[$round]:'');
                $mailData['Title']      =   '';
                $mailData['HeadLine']   =  '';  
                // 'Client Acknowledgement Received - '.$in_data['status_txt'];
                $mailData['BookId']         =   $job_info->BOOK_ID;
                $mailData['BookTitle']      =   $job_info->JOB_TITLE;
                $mailData['authorname']     =   $job_info->AUTHOR_NAME;
                $mailData['editorname']     =   $job_info->EDITOR_NAME;
                $mailData['BookIsbn']       =   $job_info->ISSN_ONLINE;
                $mailData['ReceivedDate']   =   $job_info->JOB_ASSIGNED_DATE;
                $mailData['AUTHORNAME']     =   (count($job_info)>=1?$job_info->AUTHOR_NAME:'');
                $mailData['INSERT_DATE']    =   (count($job_info)>=1?$job_info->CREATED_DATE:'');
                $mailData['BOOK_TITLE']     =   (count($job_info)>=1?$job_info->JOB_TITLE:'');
                $mailData['ADDTHRESSDAYS']  =   Carbon::now()->addDay(+3);
                $mailData['PMNAME']         =   $mailData['ToName'];
                $mailData["IMPRINT_NAME"]   =   (count($job_info)>=1?$job_info->PUBLISHER_IMPRINT_NAME:'');
                $mailArray['Data']          =   $mailData;
                $mailArray['TemplateName']  =   'emailtemplate.eproof.firstremaindermail';
                $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
                $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
                $titlewordname              =   $job_info->JOB_TITLE;
                if(is_array($findwordcount) && isset($findwordcount[2]))
                {
                    $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
                }
                $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_ONLINE.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
                $mailArray['CcMail']        =   array('shamu.shihabudeen@spi-global.com','mohan.m@spi-global.com','ananth.b@spi-global.com'); 
//                $mailArray['CcMail']        =   (count($job_info)>=1?$job_info->PE_MAIL:''); 
                $Response                   =   $this->sendMailBladeTemplate($mailArray);  
                $response       =   $this->mailSentResponse;
                $response['errMsg']     =   "Mail sent successfully";
                return response()->json($response);
            }
        }
        catch( \Exception $e ){
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response,404);
        }
    }
    
    public function domailsenduploadsuccessproofrecipient( $jobid ,$metaid  ) 
    {   
        try{
            $response       =   $this->notfoundResponse;
            $validation     =   Validator::make($request->all(), [
                                                    'metadtaid'     => 'required|numeric'
                                                ]);
            if ($validation->fails()){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $metadataid         =   $metaid;
            $jobid              =   $jobid;
            
            $totalUsers         =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
            $mailArray          =   $mailData   =   [];
            $job_info           =   jobModel::getJobdetails($jobid);
            $data_in['book_id'] =   $book_id    =   $job_info->BOOK_ID;
            $getrecipientmail   =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
            
            if(count($job_info)>=1 && count($getrecipientmail)>=1){
                $mailsendFlag       =   false;
                $mailtoAmFlag       =   false;
                $mailtoPmFlag       =   false;
                $pm_userid          =   $job_info->PM;
                $am_userid          =   $job_info->AM;
                $jobId              =   $job_info->JOB_ID;
                if( !empty( $pm_userid ) ){
                   $usrC_obj        =   new usersController();
                   $user_arr        =   $usrC_obj->getUserInfoByUserId($pm_userid); 
                   $pm_name         =   $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
                   $pm_mail         =   $user_arr->EMAIL;
                   $mailData['ToName']      =   $pm_name;
                   $mailData['prdl']        =   $pm_name;
                   $mailArray['ToMail']     =   $pm_mail;
                   $data_in['user_id']      =   $pm_userid;  
                }else if( !empty( $am_userid )){
                    $am_name                =   $job_info->AM_NAME;
                    $am_mail                =   $job_info->AM_MAIL;
                    $mailData['ToName']     =   $am_name;
                    $mailArray['ToMail']    =   $am_userid;
                    $data_in['user_id']     =   $am_userid;  
                }else{
                    return false;
                }
                
                $mailArray['ToMail']        =   $getrecipientmail->EPROOFING_RECIPIENT;
                $round          =   Config::get('constants.ROUND_NAME.S300');
                $pickroundname  =   [ '104' => 'Stage: 5' , '114' => 'Stage: 50' , '116' => 'Stage: 200' , '118' => 'Stage: 300','119' => 'Stage: 600' , '120' => 'Stage: 650'];
                $stagename      =   (isset($pickroundname[$round])?$pickroundname[$round]:'');
                $mailData['Title']      =   '';
                // 'Client Acknowledgement Received - '.$in_data['status_txt'];
                $mailData['BookId']         =   $job_info->BOOK_ID;
                $mailData['BookTitle']      =   $job_info->JOB_TITLE;
                $mailData['authorname']     =   $job_info->AUTHOR_NAME;
                $mailData['editorname']     =   $job_info->EDITOR_NAME;
                $mailData['BookIsbn']       =   $job_info->ISSN_ONLINE;
                $mailData['ReceivedDate']   =   $job_info->JOB_ASSIGNED_DATE;
                $mailData['ToName']         =   "vinoth";
                $mailData['AUTHORNAME']     =   (count($job_info)>=1?$job_info->AUTHOR_NAME:'');
                $mailData['INSERT_DATE']    =   (count($job_info)>=1?$job_info->CREATED_DATE:'');
                $mailData['BOOK_TITLE']     =   (count($job_info)>=1?$job_info->JOB_TITLE:'');
                $mailData['ADDTHRESSDAYS']  =   Carbon::now()->addDay(+3);
                $mailData['PMNAME']         =   $mailData['ToName'];
                $mailData["IMPRINT_NAME"]   =   (count($job_info)>=1?$job_info->PUBLISHER_IMPRINT_NAME:'');
                $mailArray['Data']          =   $mailData;
                $mailArray['TemplateName']  =   'emailtemplate.eproof.eproofuploadpackagesuccessmail';
                $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
                $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
                $titlewordname              =   $job_info->JOB_TITLE;
                
                if(is_array($findwordcount) && isset($findwordcount[2]))
                {
                    $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
                }
                $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_ONLINE.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
                $mailArray['CcMail']        =   array('shamu.shihabudeen@spi-global.com','mohan.m@spi-global.com','ananth.b@spi-global.com'); 
                //$mailArray['CcMail']        =   (count($job_info)>=1?$job_info->PE_MAIL:''); 
                //$mailArray['CcMail']        =   array('shamu.shihabudeen@spi-global.com','mohan.m@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com'); 
                $Response                   =   $this->sendMailBladeTemplate($mailArray);   
                $response       =   $this->mailSentResponse;
                $response['errMsg']     =   "Mail sent successfully";
                return response()->json($response);
            }
        }
        catch( \Exception $e ){
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response,404);
        }
    }
        
    public function sendMailBladeTemplate($mailArray) {
        try {
            if (is_array($mailArray)) {
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '3';
                        emailRemainderLogModel::where($wheredatamail)->update($updatedata);
                    }
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                        emailRemainderLogModel::where($wheredatamail)->update($updatedata);
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/failedemailremainder.log');
            Log::info( json_encode( $exception->getMessage() ) );
        }        
    }
    //EMAIL REMAINDER SETUP PAGES
    public function emailremaindersetup(Request $request){
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PROOF_EMAIL'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data["userId"]     =   $this->loginUserId;
        return view('email_remainder.remainder-index')->with( $data );
    }
    
    public function getemailremainderlist(Request $request){
		
        $Req            =   (object) $request->input();
        $orderColumn    =   3; //created date column
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn=   $Req->order[0]['column'];
        }

        $sorting        =   'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting    =   $Req->order[0]['dir'];
        }
            
        $start  =   '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start      =   $Req->start;
        }

        $length     =   false;
        if (isset($Req->length) && $Req->length != -1) {
            $length =   $Req->length;
        }

        $searchStr  =   '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr  =   trim($Req->search['value']);
        }
        
        $data                   =   taskLevelMetadataModel::getremaindermailsetupjoblist($start,$length,$searchStr,$orderColumn,$sorting);
        $bookdata               =   array();
        if(isset($data['bookdetails']) && count($data['bookdetails'])>=1){
            foreach ($data['bookdetails'] as $row) {
                $tempArray      =   array();
                $tempArray['BOOK_ID']       =   $row->BOOK_ID;
                $showauthorname             =   ($row->AUTHOR_NAME   ==  ""?$row->EDITOR_NAME:$row->AUTHOR_NAME);
                if($row->EPROOFING_SYSTEM   !==  '--')
                    $tempArray['JOB_TITLE'] =   '<span  class="pointer" ng-click="openchapterlistdetails('."'".$row->JOB_ID."'".','."'".$row->EPROOFING_SYSTEM."'".')">'.$row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span></span>';               
                else
                    $tempArray['JOB_TITLE'] =   $row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span>';  
                $tempArray['EPROOF']        =   $row->EPROOFING_SYSTEM;
                $tempArray['PM_NAME']       =   $row->PM_NAME;
                $tempArray['CREATED_DATE']  =   $row->CREATED_DATE;
                array_push($bookdata, $tempArray);
            }
        }
            
        $Response                       =   array();
        $Response["draw"]               =   $Req->draw;
        $Response["recordsTotal"]       =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["recordsFiltered"]    =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["data"]               =   $bookdata;
        return response()->json($Response);
        
        $response["emaillist"]  =   $data;
        $response["userId"]     =   Session::get('users')['user_id'];
        return response()->json($response);
    }
    
    public function viewEmailremainderchapterlist(Request $request,$jobID,$type)
    {
        if($type    !=  "E-PROOF" && $type    !=  "APS"){
            return redirect('emailremaindersetup');
        }
		
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PROOF_EMAIL'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $bookdata           =   jobModel::where('JOB_ID',$jobID)->first();
        $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
        $data['pageName']   =   $type.' Email Reminder Setup - '.$bookid;
        $data['jobid']      =   $jobID;
        $data['backurl']    =   url('/').'/emailremaindersetup';
        return view('email_remainder.email-remainder')->with( $data );
    }
    
    public function getemailremainderChapterlist( Request $request ){
		
        $jobID              =   	$request->input('jodId');
        $remaindertype      =   	$request->input('remaindertype');
        
		if( empty( $jobID ) || empty( $remaindertype )){
            return response()->json( $this->oopsErrorResponse , 400 );
        }
		
        $response           =   [];
        $roundid            =   $this->round_ID_300;
        $roundid2            =  120;
		
		$recset			=		DB::select( 'select *from task_level_metadata where job_id = '.$jobID.' and unit_of_measure = 556 limit 1' );
		$metaid			=		$recset[0]->METADATA_ID;
		
        
		if($remaindertype   ==  'E-PROOF' ){ 
            $data           =   taskLevelMetadataModel::getremaindermailsetupchapterlist( $jobID , $roundid );
			$data2           =   	taskLevelMetadataModel::getremaindermailsetupjoblist2( $jobID , $roundid2 , $metaid ); 
			if( isset( $data2[0] ) )
				array_unshift( $data , $data2[0] );
        }else{
            $data           =   apsProofingStatusModel::getapsremaindermailsetupchapterlist( $jobID , $roundid );
        }
        
        $response["emailremainderlist"]     =   	$data;
        $response["user_id"] 				=   	$this->loginUserId;
        
		return response()->json( $response );
		
    }
	
    public function validateDate( $date , $format = 'Y-m-d' , $type ){
		
        $d  =   \DateTime::createFromFormat($format, $date);
        $today  =   Carbon::now();
        $validformat    =   'invalidformat';
		
        switch($type)
        {
            case 'dateformat':
            if($d && $d->format($format) === $date)
            {
                $validformat    =   'correctformat';
            }
            else
            $validformat        =   'invalidformat';
            break;
            case 'greaterdate':
            if(Carbon::parse($date)->gt(Carbon::now()))
            {
                $validformat    =   'correctformat';
            }
            else
            $validformat        =   'invalidformat';
            break;
        }
		
        return $validformat;
		
    }

    public function doUpdateCorrectionRemainder( Request $request ){
		
        try{
            $response       =   $this->oopsErrorResponse;
            $response['validation']  =   [];
            $response['remainderitem']  =   "";
          
            $todaydate      =   Carbon::Parse(Carbon::now())->format('Y-m-d');
            $validation     =   Validator::make($request->all(), [
                                                    'metadataid'=> 'required|numeric',
                                                    'roundid'   => 'required|numeric',
                                                    'apsid'     => 'required|numeric',
                                                    'typeofproof'   => 'required',
//                                                    'first_correction_duedate' => 'nullable|date|date_format:Y-m-d|after:'.$todaydate,
                                                    'second_correction_duedate' => 'nullable|date|date_format:Y-m-d',
                                                    'third_correction_duedate' => 'nullable|date|date_format:Y-m-d',
//                                                    'correction_duedate'  => 'required|date|date_format:Y-m-d|after:'.$todaydate,
//                                                    'first_correction_duedate'  => 'required',
//                                                    'second_correction_duedate'  => 'required',
//                                                    'third_correction_duedate'  => 'required'
                                                ]);
            if ($validation->fails())
            {
//                $showerror          =   [];
//                foreach ($validation->messages()->all('<li>:message</li>') as $message)
//                {
//                    $showerror[]    =   $message;
//                }
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
          
           
            
            $validateformat         =   [];
            //check date format is valid or not
            if (Input::has('first_correction_duedate') && !empty(Input::has('first_correction_duedate')))
            {
                $validateformat[]   =   $this->validateDate($request->input('first_correction_duedate'),'Y-m-d','dateformat');
            }
            if (Input::has('second_correction_duedate') && !empty(Input::has('second_correction_duedate')))
            {
                $validateformat[]   =   $this->validateDate($request->input('second_correction_duedate'),'Y-m-d','dateformat');
            }
            if (Input::has('third_correction_duedate') && !empty(Input::has('third_correction_duedate')))
            {
                $validateformat[]   =   $this->validateDate($request->input('third_correction_duedate'),'Y-m-d','dateformat');
            }
            if(Input::has('correction_duedate') && !empty(Input::has('correction_duedate'))){
                $validateformat[]   =   $this->validateDate($request->input('correction_duedate'),'Y-m-d','dateformat');
            }
			
			//if (Input::has('correction_duedate') && !empty(Input::has('correction_duedate')))
			//{
			//if ($this->validateDate($request->input('correction_duedate'),'Y-m-d','greaterdate')    ==  'invalidformat') {
			//$response['errMsg']   =   'Correction due date should be greater than today date';
			//return response()->json($response);
			//}
			//}
						
            if(count($validateformat)>=1) {
                if(array_search('invalidformat',$validateformat) != ''){
                    $response['errMsg']   =   'Correction due date should be greater than today date';
                    return response()->json( $response );
                }
            }
                                    
            $metadataId                 =   $request->input('metadataid');
            $roundid                    =   $request->input('roundid');
            $apsid                      =   $request->input('apsid');
            $correction_duedate         =   $request->input('correction_duedate');
            $first_correction_duedate   =   $request->input('first_correction_duedate');
            $second_correction_duedate  =   $request->input('second_correction_duedate');
            $third_correction_duedate   =   $request->input('third_correction_duedate');
            $remainder_type             =   $request->input('typeofproof');
            
             if( $first_correction_duedate == $second_correction_duedate || $second_correction_duedate == $third_correction_duedate || $third_correction_duedate == $first_correction_duedate){
                $response['errMsg']   =   'Reminder date should not be same';
				return response()->json($response);
              }
            
            $updatedata                 =   [];
            $updatedata['CORRECTION_DUE']           =   $correction_duedate;
            $updatedata['FIRST_CORRECTION_DUE']     =   $first_correction_duedate;
            $updatedata['SECOND_CORRECTION_DUE']    =   $second_correction_duedate;
            $updatedata['THIRD_CORRECTION_DUE']     =   $third_correction_duedate;
            $updatedata['UPDATED_BY']               =   $this->loginUserId;
            
			//update in proofing tsatus table
            if($remainder_type  ==  1)
            $updatecorrection           =   apiProofingStatus::where('ID',$apsid)->update($updatedata);
            else
            $updatecorrection           =   apsProofingStatusModel::where('ID',$apsid)->update($updatedata);    
            
			if($updatecorrection){
				
                $insertdata['METADATA_ID']          =   $metadataId;
                $insertdata['ROUND']                =   $roundid;
                $insertdata['CORRECTION_DUE']       =   $correction_duedate;
                $insertdata['FIRST_CORRECTION_DUE'] =   $first_correction_duedate;
                $insertdata['SECOND_CORRECTION_DUE']=   $second_correction_duedate;
                $insertdata['THIRD_CORRECTION_DUE'] =   $third_correction_duedate;
                $insertdata['REMAINDER_TYPE']       =   $remainder_type;
                $insertdata['CREATED_BY']           =   $this->loginUserId;
				
                $storeitem  =   emailRemainderCorrectionHistoryModel::insertGetId( $insertdata );
				
                if($remainder_type  ==  1){
					$proofrec   =   apiProofingStatus::where('ID',$apsid)->first();
                }else{
					$proofrec   =   apsProofingStatusModel::where('ID',$apsid)->first();
				}
                $response   =   $this->updatedResponse;
                $response['errMsg']         =   "Remainder(s) has been updated successfully";
                $response['validation']  =   [];
                $response['remainderitem']  =   $proofrec;
                
				return response()->json($response);
				
            }
            return response()->json($response,400);
        }catch( \Exception $e ){
            echo "<pre>";print_r($e->getMessage());
            return response()->json($response);
        }		
    }
    
    public function delete( Request $request ){
        $rowid                          =   $request->input( 'ID' );
        $statusid                       =   $request->input( 'STATUSID' );
        $typeofremainder                =   $request->input( 'EMAILTYPE' );
        $rules['ID']                    =   'required';
        $rules['STATUSID']              =   'required';
        $rules['EMAILTYPE']             =   'required';
        $response   =   $this->failedResponse;
        $response['errormsg']           =   'danger';
        $response['statusvalue']        =   "";
        $validator                      =   Validator::make( $request->all(), $rules );
        if ($validator->fails()) { 
            $response['msg']            =   'Required field validation error occured.';
        }else{
            $updatedata['UPDATED_BY']   =   $this->loginUserId;
            $updatedata['UPDATED_DATE'] =   Carbon::now();
            $response['msg']            =   'Status not updated succesfully';
            $response['errormsg']       =   'Status not updated succesfully';
            switch($typeofremainder)
            {
                case 1:
                $updatedata         =   ['FIRST_REMAINDER_EMAIL_STATUS'=>$statusid,'SECOND_REMAINDER_EMAIL_STATUS'=>$statusid,'THIRD_REMAINDER_EMAIL_STATUS'=>$statusid];         
                break;
                case 2:
                $updatedata         =   ['SECOND_REMAINDER_EMAIL_STATUS'=>$statusid,'THIRD_REMAINDER_EMAIL_STATUS'=>$statusid];         
                break;
                case 3:
                $updatedata         =   ['THIRD_REMAINDER_EMAIL_STATUS'=>$statusid];         
                break;
            }
            $deletedmsg                 =   apsRemainderEmailonoffModel::where(['ID'=>$rowid])->update($updatedata);
            if($deletedmsg)
            {
                $response   =   $this->updatedResponse;
                $response['statusvalue']=   $statusid;
                $response['errormsg']   =   "Status updated succesfully";
            }
        }
        return response()->json($response); 		
    }
     
    public function dogetundoremainder(Request $request){
       
	   try{
		   
            $response       =   $this->notfoundResponse;
            $response['remainderitem']   =   "";
            $validation     =   Validator::make($request->all(), [
                                                    'apsid'     => 'required|numeric',
                                                    'typeofproof' => 'required|numeric'
                                                ]);
            if( $validation->fails() ){
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
			
            $apsid          =   $request->input('apsid');
            $typeofproof    =   $request->input('typeofproof');
            
			if($typeofproof ==  1){
				$proofrec       =   apiProofingStatus::select(DB::Raw('ID as APSID,ROUND AS ROUND_ID,DATE_FORMAT(CORRECTION_DUE, "%Y-%m-%d") as CORRECTION_DUE,DATE_FORMAT(FIRST_CORRECTION_DUE, "%Y-%m-%d") as FIRST_CORRECTION_DUE,DATE_FORMAT(SECOND_CORRECTION_DUE, "%Y-%m-%d") as SECOND_CORRECTION_DUE,DATE_FORMAT(THIRD_CORRECTION_DUE, "%Y-%m-%d") as THIRD_CORRECTION_DUE'))->where('ID',$apsid)->first();
            }else{
				$proofrec       =   apsProofingStatusModel::select(DB::Raw('ID as APSID,ROUND AS ROUND_ID,DATE_FORMAT(CORRECTION_DUE, "%Y-%m-%d") as CORRECTION_DUE,DATE_FORMAT(FIRST_CORRECTION_DUE, "%Y-%m-%d") as FIRST_CORRECTION_DUE,DATE_FORMAT(SECOND_CORRECTION_DUE, "%Y-%m-%d") as SECOND_CORRECTION_DUE,DATE_FORMAT(THIRD_CORRECTION_DUE, "%Y-%m-%d") as THIRD_CORRECTION_DUE'))->where('ID',$apsid)->first();
            }
			
			if($proofrec) {
                $response   =   $this->successResponse;
                $response['remainderitem']  =   $proofrec;
                $response['errMsg']         =   "Undo is successfully done";
                return response()->json($response);
            }
			
            return response()->json( $response , 400 );
			
        }catch( \Exception $e ){
            return response()->json($response);
        }
		
    }
    
    public function viewremainderemailtemp(Request $request){
        
        $data 			=   array();
        $jobId                  =   "6271";
        $bookdetails 		=   bookinfoModel::getBookinfodetails($jobId);
        $data['Title']          =   "Remainder Mail";
        $data['ToName'] 	=   "vinoth";
        $data['HeadLine'] 	=   "vinoth";
        $data['BookId']         =   (count($bookdetails)>=1?$bookdetails[0]->BOOK_ID:'');
        $data['BookTitle']      =   (count($bookdetails)>=1?$bookdetails[0]->JOB_TITLE:'');
        $data['BookIsbn'] 	=   (count($bookdetails)>=1?$bookdetails[0]->ISBN_ONLINE:'');
        $data['authorname'] 	=   (count($bookdetails)>=1?$bookdetails[0]->BOOK_ID:'');
        $data['editorname'] 	=   (count($bookdetails)>=1?$bookdetails[0]->JOB_ID:'');
        $data["ReceivedDate"]   =   Carbon::now();
        $data["prdl"]           =   "Chennai";
        return view('emailtemplate.eproof.remaindermail')->with( $data );
    }
    
    public function firstremainderemailtemp(){
		
        $getremainderchapterlist    =   taskLevelMetadataModel::getremaindermaillist();
        
		if(count($getremainderchapterlist)>=1){
			
            foreach($getremainderchapterlist as $key=>$remaindervalue)
            {
                $metadataid         =   $remaindervalue->METADATA_ID;
                $jobid              =   $remaindervalue->JOB_ID;
                $round              =   $remaindervalue->ROUND;
                $PROOFING_URL       =   $remaindervalue->PROOFING_URL;
                $correction_date    =   $remaindervalue->CORRECTION_DUE;
                $mailArray          =   $mailData   =   [];
                $mailArray['JOB_ID']        =   $jobid;
                $mailArray['METADATA_ID']   =   $metadataid;
                $mailArray['ROUND_ID']      =   $round;
                $job_info           =   jobModel::getJobdetails($jobid);
                $getrecipientmail   =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
                $getemailcontent    =   remainderEmailTemplateModel::where('TEMP_TYPE',true)->first();
                if(count($job_info)>=1 && count($getrecipientmail)>=1 && count($getemailcontent)>=1)
                {
                    $mailsendFlag       =   false;
                    $mailtoAmFlag       =   false;
                    $mailtoPmFlag       =   false;
                    $pm_userid          =   $job_info->PM;
                    $am_userid          =   $job_info->AM;
                    $jobId              =   $job_info->JOB_ID;
                    if( !empty( $pm_userid ) ){
                       $usrC_obj        =   new usersController();
                       $user_arr        =   $usrC_obj->getUserInfoByUserId($pm_userid); 
                       $pm_name         =   $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
                       $pm_mail         =   $user_arr->EMAIL;
                       $mailData['ToName']      =   $pm_name;
                       $mailData['prdl']        =   $pm_name;
                       $mailArray['ToMail']     =   $pm_mail;
                       $data_in['user_id']      =   $pm_userid;  
                    }else if( !empty( $am_userid )){
                        $am_name                =   $job_info->AM_NAME;
                        $am_mail                =   $job_info->AM_MAIL;
                        $mailData['ToName']     =   $am_name;
                        $mailArray['ToMail']    =   $am_userid;
                        $data_in['user_id']     =   $am_userid;  
                    }
                    
                    $mailArray['ToMail']        =   $getrecipientmail->EPROOFING_RECIPIENT;
                    $mailData['BookId']         =   $job_info->BOOK_ID;
                    $mailData['Title']          =   'PACKAGE CORRECTION REMAINDER EMAIL';
                    $mailData['BookTitle']      =   $job_info->JOB_TITLE;
                    $mailData['authorname']     =   $job_info->AUTHOR_NAME;
                    $mailData['editorname']     =   $job_info->EDITOR_NAME;
                    $mailData['BookIsbn']       =   $job_info->ISSN_ONLINE;
                    $mailData['ReceivedDate']   =   $job_info->JOB_ASSIGNED_DATE;
                    $mailData['AUTHORNAME']     =   $job_info->AUTHOR_NAME;
                    $mailData['BOOK_TITLE']     =   $job_info->JOB_TITLE;
                    //get proof sent data
                    $whereproof                 =   ['PROCESS_TYPE'=>Config::get('constants.REMINDER_PROCESS_TYPE.E_PROOF'),'ROUND'=>Config::get('constants.ROUND_ID.S300'),'METADATA_ID'=>$metadataid];
                    $proofData                  =   apiFtpUpload::select(DB::Raw('END_TIME'))->where($whereproof)->orderBy('ID','desc')->first();
        //            echo Carbon::parse($mailData['INSERT_DATE'])->format('l jS \\of F Y h:i:s A');
                    $proofdate                  =   ($proofData != null?$proofData->END_TIME:$correction_date);  
                    $mailData['INSERT_DATE']    =   Carbon::parse($proofdate)->format('jS F Y');
                    
                    $mailData["IMPRINT_NAME"]   =   $job_info->PUBLISHER_IMPRINT_NAME;
                    $usrC_obj                   =   new usersController();
                    $currentuser_id             =   $job_info->PM;
                    $user_arr                   =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
                    $mailData['ToName']         =   (count($user_arr)>=1?$user_arr->LAST_NAME:'').' '.(count($user_arr)>=1?$user_arr->FIRST_NAME:'');
                    $mailData['PMNAME']         =   $mailData['ToName'];
                    $mailData['FAX']            =   (count($user_arr)>=1?$user_arr->FAX:''); 
                    $mailData['T_ADDRESS']      =   (count($user_arr)>=1?$user_arr->T_ADDRESS:''); 
                    $mailData['T_CITY']         =   (count($user_arr)>=1?$user_arr->T_CITY:''); 
                    $mailData['T_STATE']        =   (count($user_arr)>=1?$user_arr->T_STATE:''); 
                    $mailData['T_ZIP']          =   (count($user_arr)>=1?$user_arr->T_ZIP:''); 
                    $mailData['P_COUNTRY']      =   (count($user_arr)>=1?$user_arr->P_COUNTRY:''); 
                    $mailData['EMAIL']          =   (count($user_arr)>=1?$user_arr->EMAIL:''); 
                    $mailData['WORK_PHONE']     =   (count($user_arr)>=1?$user_arr->WORK_PHONE:''); 
                    $mailData['PERSONAL_PHONE'] =   (count($user_arr)>=1?$user_arr->PERSONAL_PHONE:''); 
                    $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
                    $titlewordname              =   $job_info->JOB_TITLE;
                    if(is_array($findwordcount) && isset($findwordcount[2]))
                    {
                        $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
                    }
                    //get  country name
                    $countryname                =   CountriesModel::find($mailData['P_COUNTRY']);
                    $countryname                =   (count($countryname)>=1?$countryname->name:'');
                    $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_PRINT.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
                    $emailbodycontent           =   $getemailcontent->BODY;
                    $firstrememailbodycontent   =   $getemailcontent->FIRST_REMAINDER;
                    $secondrememailbodycontent  =   $getemailcontent->SECOND_REMAINDER;
                    $thirdrememailbodycontent   =   $getemailcontent->THIRD_REMAINDER;
                    $forwardbodycontent         =   $getemailcontent->FORWARD_TEMP;
                    $emailtextreplace           =   array(
                                                        '[BOOK_TITLE]'      =>  $mailData['BookTitle'],
                                                        '[AUTHORNAME]'      =>  ($mailData['authorname']    ==  ''?$mailData['editorname']:$mailData['authorname']),
                                                        '[CORRECTION_LINK]' =>  $PROOFING_URL,
                                                        '[INSERT_DATE]'     =>  $mailData['INSERT_DATE'],
                                                        '[CORRECTION_INSERT_DATE]' =>  $mailData['INSERT_DATE'],
                                                        '[PMNAME]'          =>  $mailData['PMNAME'],
                                                        '[IMPRINT_NAME]'    =>  $mailData["IMPRINT_NAME"],
                                                        '[T_ADDRESS]'       =>  ($mailData['T_ADDRESS']     ==  ''?'':"<p>".$mailData['T_ADDRESS']."</p>"),
                                                        '[T_CITY]'          =>  ($mailData['T_CITY']        ==  ''?'':"<p>".$mailData['T_CITY']."</p>"),
                                                        '[T_STATE]'         =>  ($mailData['T_STATE']       ==  ''?'':"<p>".$mailData['T_STATE']."</p>"),
                                                        '[T_ZIP]'           =>  ($mailData['T_ZIP']         ==  ''?'':"<p>".$mailData['T_ZIP']."</p>"),
                                                        '[P_COUNTRY]'       =>  ($countryname               ==  ''?'':"<p>".$countryname."</p>"),
                                                        '[WORK_PHONE]'      =>  ($mailData['WORK_PHONE']    ==  ''?'':"<p>T: ".$mailData['WORK_PHONE']."</p>"),
                                                        '[FAX]'             =>  ($mailData['FAX']           ==  ''?'':"<p>F: ".$mailData['FAX']."</p>"),
                                                        '[TOEMAIL]'         =>  $mailData['EMAIL']
                                                     );
                    
                    $cmn_obj                    =   new CommonMethodsController();
                    $emailbodyoriginalcontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $emailbodycontent , true );
                    $firstremainderemailbodycontent =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $firstrememailbodycontent , true );
                    $secondrememailbodycontent  =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $secondrememailbodycontent , true );
                    $thirdrememailbodycontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $thirdrememailbodycontent , true );
                    $checkexistemailid          =   $remaindervalue->APSEMAILLOG_ID;
                    $firstremainderalreadysent  =   $remaindervalue->FIRST_REMAINDER;
                    $secondremainderalreadysent =   $remaindervalue->SECOND_REMAINDER;
                    $thirdremainderalreadysent  =   $remaindervalue->THIRD_REMAINDER;
                    $firsttyperemainderemail    =   "";
                    $secondtyperemainderemail   =   "";
                    $thirdtyperemainderemail    =   "";
                    
                    $mailArray['TemplateName']  =   'emailtemplate.eproof.eproofpackagedefaultmail';
                    $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                    $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
                    $mailArray['Title']         =   "05_FS_FirstProofReminder – send at the end of the day when proof corrections should be returned";
                    $mailArray['ToMail']        =   "vinoth.t@spi-global.com";
                    
					if( strpos( $mailArray['ToMail'] , ',' )  !== false ) {
                        $toemailarray           =   explode(',',$mailArray['ToMail']);
                        $mailArray['ToMail']    =   array_unique($toemailarray);
                    }
                    
                    $mailArray['EMAIL_LOG_ID']  =   $checkexistemailid;
					//$noofdaysdiffenrece       =   Carbon::parse($correction_date)->diffInDays(Carbon::now());
                    $emailsplithrline           =   '<div class="hr" style="height:2px;border-bottom:2px solid #afa7a7;clear: both;">&nbsp;</div><br><br>';
                    $bodywholecontent           =   "";
                    
					// if correction is exist don't send mail
                    if( empty( $remaindervalue->CRCRECIVEDORNOT ) ){
                        if($remaindervalue->REM1    ==  1  && $remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1  && $firstremainderalreadysent   !=  1)
                        {
                            $mailArray['CcMail']        =   $job_info->PE_MAIL; 
                            $returncontentchangeddata   =   $this->ccEmailContentchanges($mailArray,$mailData,$job_info,$cmn_obj,$forwardbodycontent);
                            $forwardbodycontent         =   $returncontentchangeddata['forwardbodycontent'];
                            $mailArray['CcMail']        =   $returncontentchangeddata['ccmail'];
                            
                            
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['SECONDMAIL']     =   "";
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                            $mailData['FORWARDMAIL']    =   "";
//                            $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                            $bodywholecontent           .=   $firstremainderemailbodycontent;
//                            $bodywholecontent           .=   $forwardbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['FIRST_REMAINDER']   =   '1';
                            $mailArray['Data']          =   $mailData;
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            if(count($getapslogemail)>=1)
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
                            $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }
                        
                        if($remaindervalue->REM2    ==  1  && $remaindervalue->SECOND_REMAINDER_EMAIL_STATUS  ==  1 && $secondremainderalreadysent   !=  1)
                        {
                            $mailArray['CcMail']        =   "ananth.b@spi-global.com,vinoth.t@spi-global.com,$job_info->PE_MAIL"; 
                            $returncontentchangeddata   =   $this->ccEmailContentchanges($mailArray,$mailData,$job_info,$cmn_obj,$forwardbodycontent);
                            $forwardbodycontent         =   $returncontentchangeddata['forwardbodycontent'];
                            $mailArray['CcMail']        =   $returncontentchangeddata['ccmail'];
                            
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['FORWARDMAIL']    =   "";
                            if($remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $firstremainderemailbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            
                            $mailData['SECONDMAIL']     =   "";
                            $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                            $bodywholecontent           .=   $secondrememailbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['SECOND_REMAINDER']  =   '1';
                            $mailArray['Data']          =   $mailData;
                            
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            
			    if( count( $getapslogemail ) >= 1 ) {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
							
                            $getemaillogid              =   $this->doProcessMaillog( $checkexistemailid , $bodywholecontent , $mailArray );
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }
                        
                        if($remaindervalue->REM3    ==  1 && $remaindervalue->THIRD_REMAINDER_EMAIL_STATUS  ==  1 &&  $thirdremainderalreadysent   !=   1)
                        {   
                            $mailData['FIRSTMAIL']      =   "";
                            $mailData['SECONDMAIL']     =   "";
                            $mailArray['CcMail']        =   "ananth.b@spi-global.com,vinoth.t@spi-global.com,$job_info->PE_MAIL"; 
                            $returncontentchangeddata   =   $this->ccEmailContentchanges($mailArray,$mailData,$job_info,$cmn_obj,$forwardbodycontent);
                            $forwardbodycontent         =   $returncontentchangeddata['forwardbodycontent'];
                            $mailArray['CcMail']        =   $returncontentchangeddata['ccmail'];
                            
                            if($remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                                $bodywholecontent           .=   $firstremainderemailbodycontent;
                                $mailData['FORWARDMAIL']    =   "";
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            
                            if($remaindervalue->SECOND_REMAINDER_EMAIL_STATUS  ==  1){
                                $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                                $bodywholecontent           .=   $secondrememailbodycontent;
                                $mailData['FORWARDMAIL']    =   "";
                                $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                                $bodywholecontent           .=   $forwardbodycontent;
                            }
                            $mailData['THIRDMAIL']      =   "";
                            $mailData['THIRDMAIL']      .=  $thirdrememailbodycontent;                            
                            $bodywholecontent           .=   $thirdrememailbodycontent;
                            $bodywholecontent           =   $emailbodyoriginalcontent;
                            $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                            $mailArray['THIRD_REMAINDER']   =   '1';
                            $mailArray['Data']          =   $mailData;
                            // check exist eproof log email
                            $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.EPROOF')];
                            $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                            if(count($getapslogemail)>=1)
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                                $checkexistemailid      =   $getapslogemail->ID;
                            }
                            $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                            if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                            {
                                $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                            }
                            $Response                   =   $this->sendMailBladeTemplate($mailArray);
                        }
//                        return view('emailtemplate.eproof.eproofpackagedefaultmail')->with( $mailData );                        
                    }
                }
            }
        }
		
    }
    
    public function ccEmailContentchanges($mailArray,$mailData,$job_info,$cmn_obj,$forwardbodycontent){
        $emailforwardtextreplace        =   array(
                                            '[SUBJECT_EMAIL]'   =>  $mailArray['Subject'],
                                            '[FROM_EMAIL]'      =>  $mailData['EMAIL'],
                                            '[TIME_SENT_EMAIL]' =>  $mailData['INSERT_DATE'],
                                            '[TO_EMAIL]'        =>  $mailData['EMAIL'],
                                            '[CC_EMAIL]'        =>  $mailArray['CcMail']
                                         );
        $forwardbodycontent         =   $cmn_obj->arr_key_value_replace( $emailforwardtextreplace , $forwardbodycontent , true );
        
        $returndata['forwardbodycontent']   =   $forwardbodycontent;
        
        if(strpos($mailArray['CcMail'],',') !==  false)
        {
            $toemailarray           =   explode(',',$mailArray['CcMail']);
            if(in_array('',$toemailarray)){
                foreach($toemailarray as $invaliemailkey=>$value){
                    if(empty($value)){
                        unset($toemailarray[$invaliemailkey]);
                    }
                }
            }
            $mailArray['CcMail']    =   array_unique($toemailarray);
        }else{
            $mailArray['CcMail']    =   $mailArray['CcMail'];
        }
                            
        $returndata['ccmail']       =   $mailArray['CcMail'];
        return $returndata;
    }
    
    public function doProcessMaillog($checkexistemailid,$bodywholecontent = null,$mailArray)
    {
        $firsttyperemainderemail            =   (isset($mailArray['FIRST_REMAINDER'])?$mailArray['FIRST_REMAINDER']:0);
        $secondtyperemainderemail           =   (isset($mailArray['SECOND_REMAINDER'])?$mailArray['SECOND_REMAINDER']:0);
        $thirdtyperemainderemail            =   (isset($mailArray['THIRD_REMAINDER'])?$mailArray['THIRD_REMAINDER']:0);
        if(!empty($checkexistemailid)>=1)
        {
            $updatedata                         =   [];
            $updatedata['BODY_OF_MAIL']         =   $bodywholecontent;
            $updatedata['TO_EMAIL']             =   $mailArray['ToMail'];    
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $updatedata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else{
                $updatedata['CC_EMAIL']         =   $mailArray['CcMail'];
            }
            if(!empty($firsttyperemainderemail))
            {
                $updatedata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $updatedata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $updatedata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            emailRemainderLogModel::where('ID',$checkexistemailid)->update($updatedata);
            $lastemaillogid                     =   $checkexistemailid;
        }else{
            $insertdata                         =   [];
            $insertdata['JOB_ID']               =   $mailArray['JOB_ID'];
            $insertdata['METADATA_ID']          =   $mailArray['METADATA_ID'];
            $insertdata['ROUND']                =   $mailArray['ROUND_ID'];
            $insertdata['STATUS']               =   Config::get('constants.STATUS_ENUM.INPROGRESS');
            $insertdata['BODY_OF_MAIL']         =   $bodywholecontent;
            $insertdata['TO_EMAIL']             =   $mailArray['ToMail'];
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $insertdata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else
            {
                $insertdata['CC_EMAIL']         =   $mailArray['CcMail'];   
            }
            if(!empty($firsttyperemainderemail))
            {
                $insertdata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $insertdata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $insertdata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            $insertdata['CREATED_DATE']         =   Carbon::now();
            $insertdata['REMAINDER_TYPE']       =   Config::get('constants.REMAINDER_TYPE.EPROOF');
            $lastemaillogid                     =   emailRemainderLogModel::insertGetId($insertdata);
            $mailArray['EMAIL_LOG_ID']          =   $lastemaillogid;
        }
        return $mailArray;
    }
	
    public function eproofmailCron(){
        
		try{
			
			$eproofObj       =    new Eproofremaindermail();
			$eproofObj->handle();
			
		}catch(  \Exception $e ){
			
			echo $e->getTraceAsString();
			
		}
    }
    
    public function getLastPackageInfo( $metaid , $round ){
       
        if( !is_null( $metaid ) && !is_null( $round ) ){
            
            $records        =   DB::select( "SELECT * FROM api_eproof_packaging where METADATA_ID = $metaid AND ROUND= $round ORDER BY ID DESC LIMIT 1"  );
            if( count( $records ) ){
                $recSet     =   $records[0];
                return $recSet;
            }
            
        }
        
        return false;
    }
    
	
	public function getS650RemainderList(){
		
		$tsklel			=		new taskLevelMetadataModel();
		$return 		=		$tsklel->getS650RemainderList();
		
		return $return;
		
	}
	
    
}