<?php
namespace App\Http\Controllers\dashboard;

use App\Http\Controllers\Controller;
use App\Models\dashboardModel;
use App\Models\UserModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Validator;
use PDF;
use DB; 
use Config;

class dashboardController extends Controller
{
    public function __construct(){  
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if(Session::has('users')    ==  ''){
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(){
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.DASHBOARD'),$data);
        $rolerestrict           =   [\Config::get('constants.ADMIN_USER_ID')];
        $data['disablevalues']  =   ((in_array(Session::get('users')['user_id'],$rolerestrict)  ==  true)?1:0);
        return view('dashboard.dashboard')->with($data);
    }
    
    public function getUserDetail() {
        
        if(Session::has('users')) {
            
            $response['msg']        =   "success";
            $response['user_name']  =   $this->userName;
            $response['role_name']  =   $this->roleName;
            $response['user_id']    =   $this->loginUserId;
            $response['circle_id']  =   $this->circleId;
            $response['team_id']    =   $this->teamId;
            $roleid                 =   $response['role_id']    =   $this->roleId;
            //get all users
            $response['onlineuser']     =   count(UserModel::where('LOGIN_CURRENT_STATUS','1')->get());
            $response['offlineuser']    =   count(UserModel::where('LOGIN_CURRENT_STATUS','0')->where('IS_ACTIVE','!=','0')->get());
            $response['bloackeduser']   =   count(UserModel::where('IS_ACTIVE','0')->get());   
            $response['manager']        =   Session::get('users')['manager'];
            
            if( in_array( $roleid , \Config::get( 'constants.MANAGER_ROLE_ID' ) ) ){
                $response['manager'] = 1;
            }
            
        } else {
            $response['msg']        =   "failure";
	}
        
        return response()->json($response);
        
    }
    
    public function getAssignedFilesList(Request $request){	 
        $arrData    =   array();
        $arrData['user_id'] =   $this->loginUserId;
        $data               =   dashboardModel::getAssignedList($arrData);           
        $response["data"]   =   $data;
        return response()->json($response);		
    }
    
    public function getFilesCountList(Request $request) {
        $arrData['user_id']     =   $this->loginUserId;
        $arrData['circle_id']   =   $this->circleId;
        $arrData['manager']     =   $this->manager;
        $arrData['team_id']     =   $this->teamId;
        $data                   =   dashboardModel::getFilesCountList($arrData);
        $response["data"]       =   $data;
        return response()->json($response);	
    }  
    
    /*  
    public function redirectBatch(Request $request, $batchID) {
            if($batchID != '') {
                    $data = dashboardModel::getJobStageInfo($batchID); 
                    if(count($data) > 0) {	
                        $jobStg = '';
            for($i=0; $i<count($data); $i++) {
                                    $jobid = $data[0]->JOB_ID;	
                                    if($i > 0) {
                                            $jobStg .= ",";
                                    }
                                    $jobStg .= $data[0]->JOB_STAGE_ID;	
                            }
                            $url = "/checkout/".$jobid."/".$jobStg;
                    } else {
                            $url = "/dashboard"; //$url = "/dashboard.php?msg=t2fa";
                    }			
            } else {
                    $url = $_SERVER['HTTP_REFERER'];
            }
            header("location:".url('/').$url);	
            exit;
    } 
    */
    
    public function saveLoungeHours(Request $request) {
        $arrData['userId']  =   $this->loginUserId;
        $arrData['remark']  =   $request->input('remark');
        $arrData['reason']  =   $request->input('reason');
        $data   =   dashboardModel::saveLoungeHours($arrData);           
        return response()->json($data);
    }
    
    public function getLoungeHours(Request $request) {
        $arrData['userId']  =   $this->loginUserId;
        $data   =   dashboardModel::getLoungeHours($arrData);           
        return response()->json($data);
    }
    
    public function changePassword(Request $request) {
        $arrData['userId']  =   $this->loginUserId;
        $arrData['pwd']     =   $request->input('pwd');			
        $arrData['newPwd']  =   $request->input('newPwd');	
        $data = dashboardModel::changePassword($arrData);           
        return response()->json($data);
    }

    /*
    function assignedList(Request $request){
        if ($request->input() && $request->ajax()) {
            $Req = (object) $request->input();
             
            $arrData    =   array();
            $arrData['user_id']     = Session::get('users')['user_id'];
            $arrData['orderColumn'] = $Req->order[0]['column'];
            $arrData['sorting']     = $Req->order[0]['dir'];
            $arrData['start']       = $Req->start;
            $arrData['length']      = $Req->length;			
			$arrData['searchStr']   = $Req->search['value'];
            $arrData['recordsTotal']   = 'true';
            $arrData['useLimit']       = 'false';
            $recordsTotal = dashboardModel::getAssignedList($arrData);
            $arrData['useLimit']       = 'true';
            $arrData['recordsTotal']   = 'false';
            $data = dashboardModel::getAssignedList($arrData);
            foreach($data as $key => $val){
                
                $val->job_title;
                $val->chapter_count;
                $val->art_count; 
                $data[$key] = $val; 
            }
           
            $response = array();
            $response["draw"] = $_POST['draw'];
            $response["recordsTotal"] = count($recordsTotal);
            $response["recordsFiltered"] = count($recordsTotal);
            $response["data"] = $data;
            return response()->json($response);
        }
    }        
    function FileCountList(Request $request){
        if ($request->input() && $request->ajax()) {
            $Req = (object) $request->input();
            $arrData    =   array();
           
            $arrData['user_id']     = Session::get('users')['user_id'];
            
            $arrData['orderColumn'] = $Req->order[0]['column'];
            $arrData['sorting']     = $Req->order[0]['dir'];
            $arrData['start']       = $Req->start;
            $arrData['length']      = $Req->length;			
			$arrData['searchStr']   = $Req->search['value'];
            $arrData['recordsTotal']   = 'true';
            $arrData['useLimit']       = 'false';
            $recordsTotal = dashboardModel::getFileList($arrData);
            $arrData['useLimit']       = 'true';
            $arrData['recordsTotal']   = 'false';
            $data = dashboardModel::getFileList($arrData);
           
            foreach($data as $key => $val){
                $val->job_title;
                $val->chapter_count;
                $val->art_count;
                
                $data[$key] = $val;
            }
            
            $response = array();
            $response["draw"] = $_POST['draw'];
            $response["recordsTotal"] = count($recordsTotal);
            $response["recordsFiltered"] = count($recordsTotal);
            $response["data"] = $data;
            return response()->json($response);            
        }
    }
*/	
        
}