<?php
namespace App\Http\Controllers\prrreport;
use App\Http\Controllers\Controller;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\apiPrrreportModel;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Crypt;
use Session;
use Storage;

use File;
use Validator;
use Carbon\Carbon;
use PDF;
use Config;
use Mail;
use DB; 
use Excel;
use App\Http\Controllers\contact\contactController;
use App\Http\Controllers\CommonMethodsController;

class prrreportController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request)
    {
        $data               = 	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PRR_REPORT'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        return view('prrreport.prrreport')->with($data);
    }
    
    public function getPrrlist(Request $request)
    {
	$data               =   jobModel::getPrrreportdetails();
	$response["prr"]    =   $data;
	return response()->json($response);
    }
    
    public function doPrrReportDownload(Request $request)
    {
        if($request->method()   ==  "POST"){
            
            $validation 	= 	Validator::make($request->all(), [
                                                                        'jobid' => 'required|numeric',
                                                                        'bookid' => 'required'
                                                                ]);

            if ($validation->fails()){
                
                $result         =   array('result'=>0,'errMsg'=>'all fields are required','validationerror'=>$validation->errors());   
                return response()->json( $result , 401 );
                
            }
            
            $jobId              =   $request->input('jobid');
            $bookid             =   $request->input('bookid');
            $roundid            =   ($request->input('roundid')     ==  ''?116:$request->input('roundid'));
            $bookexist          =   jobModel::checkExistbookjob($jobId,$bookid);
            $getlocationftp     =   productionLocationModel::doGetLocationname( $jobId );
            
            if(count($getlocationftp)>=1 && count($bookexist)>=1){
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
                $downloadextn   =   Config::get('constants.PRR_REPORTDWONLOAD_EXTENSTION');
                $ftp_server     =   $hostserver;
                $ftp_user_name  =   $hostusername;
                $ftp_user_pass  =   $hostpassword;
                $get_s5round    =   Config::get('constants.ROUND_NAME')[$roundid];
                
                $downloadfilelocation   =   Config::get('constants.PRR_REPORTDWONLOAD_FOLDER');
                $downloadseachfile      =   Config::get('constants.PRR_REPORTDWONLOAD_SEARCH');
                $downloadoriginalloc    =   str_replace($downloadseachfile,$bookid,$downloadfilelocation);
                $getfilelink    =   "ftp://".$hostusername.":".$hostpassword."@".$hostserver."/".$downloadoriginalloc.$get_s5round."/";
                $fileupload     =   $ftpObj->allFiles($downloadoriginalloc.$get_s5round);
                
                if( count( $fileupload )>= 1){
                    $jsonfiles  =   [];
                    foreach($fileupload as $key=>$jsonvalue){
                        if(strpos($jsonvalue,'/') !== 	false){
                           $jsonfiles[$key] 	=       substr(strrchr($jsonvalue, "/"), 1);
                        }
                    }
                    $xlsxFilePath       =   [];
                    
                    foreach($jsonfiles as $values){
                        if(in_array(pathinfo($values)['extension'],$downloadextn)){
                            $xlsxFilePath[]    =   $values;
			}
                    }
                    
                    $getfile    =   '';
                    $result     =   substr($bookid, 0, 4);
                    foreach($xlsxFilePath as $matchvalues){
                        if(strpos($jsonvalue,$result) !==   false){
                            $getfile    =   $matchvalues;
                        }
                    }
                    
                    if(!empty($getfile)){
                        
                        if (!file_exists(public_path('spicastdownloadtemp/'))){
                            File::makeDirectory(public_path('spicastdownloadtemp/'), $mode = 0777, true, true);
                        }
                        
                        $getfilesdownload   =   $getfilelink.$getfile; 
                        $getftpfile     =   file_get_contents($getfilesdownload);
                        $putfile        =   file_put_contents(public_path('spicastdownloadtemp/'.$getfile), $getftpfile);
                        $ResponseData   =   array();
                        $inputarr       =   array();
                        
                        $jobObj     =   new jobModel();
                        $jobinfo    =   $jobObj->getJobdetails( $jobId );
                        
                        $contactContObj         =       new contactController();
                        $contactinformtags      =       $contactContObj->getContactInromationPm( $jobId  , $roundid , 'array' );
                        $pmname                 =       ( $contactinformtags['ContactPerson']['ContactPersonName']['FamilyName'] );
                        
                        unset( $contactinformtags['ContactPerson']['Contact']['Country'] );
                        unset( $contactinformtags['ContactPerson']['Contact']['Phone'] );
                        unset( $contactinformtags['ContactPerson']['Contact']['Fax'] );
                        unset( $contactinformtags['ContactPerson']['Contact']['Email'] );
                            
                        $address                =       implode( ', '  , $contactinformtags['ContactPerson']['Contact'] );
                        $inputarr['pmname']     =       $pmname;
                        $inputarr['address']    =       $address;
                        $inputarr['jobinfo']    =       $jobinfo;
                        
                                                   
                        Excel::load( public_path('spicastdownloadtemp/'.$getfile ) , function( $excel ) use ( $inputarr , &$ResponseData,$bookid){
                            
                            $jobinfo    =   $inputarr['jobinfo'];                            
                            $curretnsheet   =   $excel->getActiveSheet();
                            $curretnsheet->setCellValue( 'C99', date( 'Y-m-d' ) );
                            $curretnsheet->setCellValue( 'C100', $inputarr['pmname'] );
                            $curretnsheet->setCellValue( 'C101', $inputarr['address'] );
                            $curretnsheet->setCellValue( 'C85', $jobinfo->NO_PART_COUNT );
                            $curretnsheet->setCellValue( 'C86', $jobinfo->NO_CHAPTER_COUNT );
                            $curretnsheet->setCellValue( 'C87', $jobinfo->NO_APAGE_COUNT );
                            
                            $sheetnameexist  =   $excel->getSheetNames();
                            $sheetstr        =   "Problems";
                            $checkexistsheet    =   in_array($sheetstr,$sheetnameexist);
//                            $bookid     =   "416235_1_En";
                            $sheetdata   =   $this->getQueryCountByJob($bookid);
                            if(!empty($checkexistsheet)){
                                $excel->sheet($sheetstr, function($sheet) use ($sheetdata)
                                {	
                                    if(count($sheetdata)>=1){
                                        $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                                        $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                                        $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                                        $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                                        $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                                        $sheet->setWidth(array(
                                                                'A'     =>  25,
                                                                'B'     =>  15,
                                                                'C'     =>  30,
                                                                'D'     =>  25,
                                                                'E'     =>  25
                                                        ));
                                        $sheet->cells('A1:E1', function($cells) {
                                                $cells->setFontFamily('Arial');
                                                $cells->setFontSize(10);	
                                                $cells->setFontWeight('bold');	
                                                $cells->setAlignment('center');
                                                $cells->setValignment('center');
                                        });
                                        $t  =   5;    
                                        foreach($sheetdata as $val){
                                            $queryval       =   strip_tags($val['Query']);
                                            $queryAppend    =   html_entity_decode($queryval);
                                            $responseval    =   strip_tags($val['Response']);
                                            $responseAppend =   html_entity_decode($responseval);
                                            $sheet->row($t, array($val['Chapters'],
                                                                    $val['QueryCategory'],
                                                                    $queryAppend,
                                                                    $responseAppend
                                                                ));
                                            $t++;
                                        }
                                    }				
                                });
                            }
                        })->store('xlsx', public_path('spicastdownloadtemp/' ) );
                        
//                            Excel::create('New file', function($excel) use($bookid) {
//                            $sheetdata   =   $this->getQueryCountByJob($bookid);
//                            $excel->sheet('New sheet', function($sheet) use ($sheetdata) {
//                                $data['sheetdata']     =   $sheetdata;
//                            $sheet->loadView('export.index')->with('sheetdata',$sheetdata);
//                            });
//                            })->store('xlsx',public_path('spicastdownloadtemp/'));
//                                                    
                        //return response()->download(public_path('spicastdownloadtemp/'.$getfile))->deleteFileAfterSend(true);
                        $result             =   array('result'=>200,'errMsg'=>'File is downloaded','link'=>url('/').'/public/spicastdownloadtemp/'.$getfile);   
                        return response()->json($result);
                    }
                    $result             =   array('result'=>400,'errMsg'=>'Excel File is not avaiable');   
                    return response()->json($result,404);
                }
                $result             =   array('result'=>404,'errMsg'=>'PRR Report file is not avaiable');   
                return response()->json($result,404);
            }
            $result             =   array('result'=>404,'errMsg'=>'Production location or job data not found');   
            return response()->json($result,401);
        }
        $result         =   array('result'=>0,'errMsg'=>'Try again browser pop-up block issue');   
        return response()->json($result,401);
    }
    
    public function getQueryCountByJob($bookId){
        $curl                    =       Config::get('constants.QMS_JOB_QUERIES_URL').'?TitleAcronym='.$bookId.'&Type=Magnus';
        $data                    =       array( 'BOOK_ID' => $bookId );
        $cmn_obj                 =       new CommonMethodsController();
        $returns_response        =       json_decode($cmn_obj->getcUrlExecution(  $curl,0 ));
        $querychap               =       array();
        $key                        =   1;
        foreach($returns_response as $data){
//            if($data->Status == 'Open'){
                $chapters    =    explode(',',$data->Chapters);
                
                if(count($chapters)>=1){
                    foreach($chapters as $chap){
                        $querychap[$key]['Chapters']    =   $chap;
                        $querychap[$key]['QueryCategory']    =   $data->QueryCategory;
                        $querychap[$key]['Query']       =   $data->Query;
                        $querychap[$key]['Response']    =   $data->Response;
                        $key++;
                    }
                }else{
                    $querychap[$key]['Chapters']    =   $data->Chapters;
                    $querychap[$key]['QueryCategory']    =   $data->QueryCategory;
                    $querychap[$key]['Query']    =   $data->Query;
                    $querychap[$key]['Response']    =   $data->Response;
                }
//            }
            $key++;
        }
        return $querychap;
    }
    
    public function doPrrReportDelete(Request $request)
    {
        $success    =   File::cleanDirectory(public_path('spicastdownloadtemp/'));
    }
    
    public function doPrrReportSend(Request $request)
    {
        if($request->method()   ==  "POST")
        {
            $validation 	= 	Validator::make($request->all(), [
                                                                        'jobId' => 'required|numeric',
                                                                        'Mailid' => 'required',
                                                                        'file' => 'required|file'
                                                                ]);

            if ($validation->fails())
            {
                $result         =   array('result'=>0,'errMsg'=>'all fields are required','validationerror'=>$validation->errors());   
                return response()->json($result,401);
            }
            $jobId              =   $request->input('jobId');
            $getftpfile         =   $request->file('file');
            $bookdata           =   jobModel::where('JOB_ID',$jobId)->first();
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            ini_set('post_max_size','100M');
            ini_set('upload_max_filesize','100M');
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $root               =   \Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
                $ceroot             =   \Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
                $castofffile        =   \Config::get("constants.BACKSLAH_CASTOFF_DESTINATION_PATH")."\\";
                $datetime           =   date('d-m-y-H-m-s');
                $filename           =   $bookid.'_Production_Review_Report.'.$getftpfile->getClientOriginalExtension();
                $prr_path           =   str_replace( '/' , '\\' , Config::get('constants.PRR_REPORT_FILE') );
                $prreportpath       =   "\\"."\\".$hostserver."\\".$prr_path.$filename;
                $fileupload         =   $ftpObj->put(Config::get('constants.PRR_REPORT_FILE').$filename,File::get($getftpfile));
                if($fileupload)
                {
                    $spicast                        =   [];
                    $spicast['JOB_ID']              =   $jobId;
                    $spicast['PRR_REPORT_PATH']     =   $prreportpath;
                    $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
                    $spicast['START_TIME']          =   Carbon::now();
                    $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
                    $storespicast                   =   apiPrrreportModel::store($spicast);
                    $Response['Status']             =   1;
                    $Response['Msg']                =   'Success';
                    $jobdata                        =   [];
                    $jobdata['PRR_REPORT_STATUS']   =   "1";
                    $jobdata['LAST_MOD_DATE']       =   Carbon::now();
                    $jobdata['LAST_MOD_BY']         =   Session::get('users')['user_id'];
                    $bookexist                      =   jobInfoModel::updateJobdata($jobId,$jobdata);
                    $result     =   array('result'=>200,'errMsg'=>'PRR Report has been sent successfully!','response'=>$Response,'Prrreporrtpath'=>$prreportpath);   
                    return response()->json($result);
                }
                $response 	=   array('result'=>400,'errMsg'=>'PRR Report not has been sent successfully try again.','validation'=>'');
                return response()->json($response);
            }else
            {
                $response 	=   array('result'=>400,'errMsg'=>'File production location not found','validation'=>'');
                return response()->json($response);
            }
        }
        $result         =   array('result'=>0,'errMsg'=>'Invalid Access');   
        return response()->json($result,401);
    }
    
    /*public function doPrrReportSend(Request $request)
    {
        if($request->method()   ==  "POST")
        {
            $validation 	= 	Validator::make($request->all(), [
                                                                        'jobId' => 'required|numeric',
                                                                        'Mailid' => 'required',
                                                                        'file' => 'required|file'
                                                                ]);

            if ($validation->fails())
            {
                $result         =   array('result'=>0,'errMsg'=>'all fields are required','validationerror'=>$validation->errors());   
                return response()->json($result,401);
            }
            $jobId              =   $request->input('jobId');
            $getftpfile         =   $request->file('file');
            $bookexist          =   jobInfoModel::checkExistbookjob($jobId);
            if(count($bookexist)>=1)
            {
//                //echo $bookexist->PE_MAIL;exit;
//                if (!file_exists(public_path('prrreportemailtemp/'))) 
//                {
//                    File::makeDirectory(public_path('prrreportemailtemp/'), $mode = 0777, true, true);
//                }
//                $putfile        =   file_put_contents(public_path('prrreportemailtemp/'.$getftpfile->getClientOriginalName()), $getftpfile->getClientOriginalName());
                $mailData       =   array();
                $mailArray      =   array();
                $mailData['Title']      =   'PRR Report';
                $mailData['HeadLine']   =   'PRR Report';
                $mailData['ToName']     =   (count($bookexist)>=1?$bookexist->PE_NAME:'');
                $mailData['username']   =   Session::get('users')['user_name'];
                $mailArray['Data']      =   $mailData;
//                $mailArray['file']      =   file_get_contents(public_path('prrreportemailtemp/'.$getftpfile->getClientOriginalName()));
                $mailArray['file']      =   $getftpfile->getRealPath();
                $mailArray['attachfile']    =   array('as' => 'PRR Report.' . $getftpfile->getClientOriginalExtension(), 'mime' => $getftpfile->getMimeType());
                $mailArray['TemplateName']  =   'emailtemplate.download.prrNotification';
                $mailArray['Subject']   =   'PRR Activity/S5 Notification';
                $mailArray['FromMail']  =   'no-reply@spi-global.com';
                $mailArray['FromName']  =   'PRR Activity/S5 Notification';
//                $mailArray['ToMail']    =   $bookexist->PE_MAIL;
                $mailArray['ToMail']    =   'mohan.m@spi-global.com';
                $userid                 =   Session::get('users')['user_id'];
                $getusermailid          =   DB::table('user')->where('USER_ID',$userid)->first();
                
                if(count($getusermailid)>=1)
                {
                    if(!empty($getusermailid->EMAIL))
                    {
                        $mailArray['CcMail']    =   $getusermailid->EMAIL;
                    }
                }
                //$mailArray['CcMail']    =   array('vinoth.t@spi-global.com','ananth.b@spi-global.com');
                if (is_array($mailArray)) 
                {
                    Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) 
                    {
                        $message->subject($mailArray['Subject']);
                        $message->from($mailArray['FromMail'], $mailArray['FromName']);
                        $message->to($mailArray['ToMail']);
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                        if (array_key_exists('CcMail', $mailArray)) 
                        {
                            $message->cc($mailArray['CcMail']);
                        }
                        $message->getSwiftMessage();
                    });

                    if (Mail::failures()) 
                    {
                        $Response['Status']     =   2;
                        $Response['Msg']        =   'Failure';
                        $Response['MsgText']    =   Mail::failures();
                        $result             =   array('result'=>404,'errMsg'=>'Mail not has been sent');   
                        return response()->json($result,401);
                    } 
                    else 
                    {
                        $Response['Status']     =   1;
                        $Response['Msg']        =   'Success';
                        $jobdata                =   [];
                        $jobdata['PRR_REPORT_STATUS']   =   "1";
                        $jobdata['LAST_MOD_DATE']   =   Carbon::now();
                        $jobdata['LAST_MOD_BY']     =   Session::get('users')['user_id'];
                        $bookexist  =   jobInfoModel::updateJobdata($jobId,$jobdata);
                        //$success    =   File::cleanDirectory(public_path('prrreportemailtemp/'));
                        $result         =   array('result'=>200,'errMsg'=>'Email has been sent successfully!','response'=>$Response);   
                        return response()->json($result);
                    }
                }
                $result             =   array('result'=>404,'errMsg'=>'Mail not has been sent');   
                return response()->json($result,401);
            }
            $result             =   array('result'=>404,'errMsg'=>'Bad request sending');   
            return response()->json($result,401);
        }
        $result         =   array('result'=>0,'errMsg'=>'Invalid Access');   
        return response()->json($result,401);
    }*/
}
    
