<?php
namespace App\Http\Controllers\finance;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models as Models;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use DB; 
use Illuminate\Http\Response;
use App\Http\Requests;

class readJobSheetDataController extends Controller
{    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {  
		parent::__construct();
		$this->DateTime = Carbon::now('Asia/Kolkata');
        $this->currentDateTime = date('m-d-Y_H_i_s_A', strtotime($this->DateTime));
		
		$this->middleware(function ($request, $next) {
            $this->loginUserId = Session::get('users')['user_id'];
			if(Session::has('users')=='')
			{
				return redirect('/');
			}
            return $next($request);
        });        
        
    }
	
    public function index()
    {
		
    }
	
	public function getData(){
		echo "<pre>";print_r($this->getJobSheetData(1, 1, 'FormatTrimSize', 0));
	}
	
	public function getJobSheetData($jobID = '', $roundId = '',$metadataID = '', $key = '', $searchIndex = '', $arguments = ''){	
            
            if(!empty($roundId )){
                $getResp = DB::table('job_round_milestone')->where(array('JOB_ID' => $jobID,'ROUND_ID' => $roundId,'IS_ACTIVE' => 1))
                        ->where(function ($query) use ($metadataID) {
                            if (trim($metadataID) != '') {
                                return $query->Where('job_round_milestone.METADATA_ID', $metadataID);
                            }
                        })
                        ->orderBy('ID', 'desc')->first();
            }else{
                $getResp = DB::table('job_round_milestone')->where(array('JOB_ID' => $jobID,'IS_ACTIVE' => 1))
                        ->where(function ($query) use ($metadataID) {
                            if (trim($metadataID) != '') {
                                return $query->Where('job_round_milestone.METADATA_ID', $metadataID);
                            }
                        })->orderBy('ID', 'desc')
                        ->first();
            }
                if (count($getResp) > 0) {
			//$getJsonData = utf8_encode($getResp->JSON_DATA);		
			$getJsonData = $getResp->FULL_JOBSHEET_JSON_DATA;
			$jdata = $this->jsonValidator($getJsonData, true);
                        
                       	if($key === ''){
				return $jdata;
			}else if(is_bool($jdata) === true || is_array($jdata) && count($jdata) > 0){
				$resp = $this->array_key_search_deep($jdata, $key);
                               
				if($searchIndex === ''){
					return $resp;
				}else{					
					$index = (int) $searchIndex;
					if(isset($resp[$searchIndex])){
						if(!empty($arguments) ){
							if(isset($resp[$searchIndex][$arguments])){
								return $resp[$searchIndex][$arguments];
							}else{
								return $resp[$searchIndex];
							}
						}else{
							return $resp[$searchIndex];
						}
					}else{
						//return 'Your search index('.$index.') is not found.';
                                            return '';
					}
				}
			}else if(is_string($jdata)){
				return array($jdata);
			}else{
				//return 'This is not valid json.';
                            return '';
			}
		}else{
			//return "Data not found in database.";
                        return '';
		}
	
	}
	
	/*
	 *	Validate JSON String Using PHP
	 *  //JSON Validator function - echo (json_validator($sampleJSONData1) ? "JSON is Valid" : "JSON is Not Valid");
	 */
	public function jsonValidator($jsonStr = '',$return_data = false){
		if(!empty($jsonStr)){
			$getJsonData = $jsonStr;
			
			$jsonStrDecoded = json_decode($getJsonData,true);
			if(is_string($getJsonData) && (is_array(json_decode($getJsonData, true)) || is_object(json_decode($getJsonData, true)))&& (json_last_error() == JSON_ERROR_NONE)){
				return ($return_data ? $jsonStrDecoded : TRUE);
			}else{
				if ($error = json_last_error())
				{
					$errorReference = [
						JSON_ERROR_DEPTH => 'The maximum stack depth has been exceeded.',
						JSON_ERROR_STATE_MISMATCH => 'Invalid or malformed JSON.',
						JSON_ERROR_CTRL_CHAR => 'Control character error, possibly incorrectly encoded.',
						JSON_ERROR_SYNTAX => 'Syntax error.',
						JSON_ERROR_UTF8 => 'Malformed UTF-8 characters, possibly incorrectly encoded.',
						JSON_ERROR_RECURSION => 'One or more recursive references in the value to be encoded.',
						JSON_ERROR_INF_OR_NAN => 'One or more NAN or INF values in the value to be encoded.',
						JSON_ERROR_UNSUPPORTED_TYPE => 'A value of a type that cannot be encoded was given.',
					];
					$errStr = isset($errorReference[$error]) ? $errorReference[$error] : "Unknown JSON error occured ($error)";
					return "JSON decode error ($error): $errStr";
				}
				return false;
			}
		}else{
			return 'Json string is empty.';
		}
	}
	
	public function array_key_search_deep( $array, $key )
	{
		$results = array();
		if ( is_array($array) && count($array) > 0 )
		{
                   
			if ( isset($array[$key]) )
			{
                           
				if(is_array($array[$key]) && count($array[$key]) > 0 && isset($array[$key][0])){
					$results = array_merge( $results, $array[$key]);
				}else{
					$results[] = $array[$key];
				}
			} else {
                          
				foreach ($array as $subarray){ 
					if(is_array($subarray) && count($subarray) > 0) {
						$results = array_merge( $results, $this->array_key_search_deep($subarray, $key) );
					}
				}
			}
		}
		return $results;
	}
}