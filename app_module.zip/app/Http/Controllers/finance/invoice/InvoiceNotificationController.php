<?php

namespace App\Http\Controllers\finance\invoice;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Illuminate\Http\Response;
use App\Models\finance as Models;
use Config;
use DB;
use Mail;
use URL;

class InvoiceNotificationController extends \App\Http\Controllers\finance\master\EmailMasterController {

    public function __construct() {
        //        $this->middleware(function ($request, $next) {
//            $this->loginUserId = Session::get('users')['user_id'];
//            if (Session::has('users') == '') {
//                return redirect('/');
//            }
//            return $next($request);
//        });
        $this->DateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');
        $this->CONSTANT = Config::get('constants.FINANCE');
        parent::__construct();
    }

    public function testmail() {

        $mailArray = $mailData = array();

        $mailArray['Title'] = 'Test Mail';
        $mailArray['HeadLine'] = 'Test Mail Headline';
        $mailArray['ToName'] = ' Mathan';
        $mailArray['Body'] = "Hi This is testing email from application ";
        $mailArray['InfoText'] = " Please do not reply.";
        $mailArray['DateTime'] = date('Y-m-d H:i:s');

        $mailArray['Subject'] = 'Test Mail';
        $mailArray['FromMail'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_MAIL'];
        $mailArray['FromName'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_NAME'];
        $mailArray['ToMail'] = $this->CONSTANT['NOTIFICATION_EMAIL']['TO_MAIL'];
        $mailArray['CcMail'] = $this->CONSTANT['NOTIFICATION_EMAIL']['CC_MAIL'];
        $Response = $this->sendMailRawText($mailArray);
        dd($Response);
        exit;
    }

    public function InvoiceCreateEmailNotify($InvoiceID) {

        $selectArray = array('INVOICE_ID', 'REF_PREFIX', 'INVOICE_TITLE', 'CLIENT_ID', 'CLIENT_DIVISION_ID', 'CREATED_BY', 'CURRENT_STATUS', 'JOB_ID');
        $withArray = array('project', 'Customer', 'CustomerDivision', 'createdBy');

        $Invoice = Models\InvoiceModel::where('INVOICE_ID', $InvoiceID)->with($withArray)->select($selectArray)->first()->toJson();
       
        $Invoice = json_decode($Invoice);
        $InvoiceCurrentStatus = $Invoice->CURRENT_STATUS;
        
        $Leades = $this->getUserLeads($Invoice->created_by->USER_ID);
        if (count($Leades) == 0) {
            return true;
        } else if ($Leades->CL_WORK_EMAIL_ID == null || trim($Leades->CL_WORK_EMAIL_ID) == '') {
            return true;
        }

        $ToMail[] = $Leades->CL_WORK_EMAIL_ID;
        $AlternateLeades = $this->getUserLeadsAlternate($Leades->SUB_CIRCLE_ID);
        if (count($AlternateLeades) > 0) {
            foreach ($AlternateLeades as $al) {
                if ($al->WORK_EMAIL_ID != null || trim($al->WORK_EMAIL_ID) != '') {
                    $ToMail[] = $al->WORK_EMAIL_ID;
                }
            }
        }

        $CcMail = $Leades->WORK_EMAIL_ID;


        $LevelTrackingArray = $this->GetStatusTrack($InvoiceID, $InvoiceCurrentStatus);

        $mailArray = $mailData = array();
        $mailData['Title'] = 'New Invoice Created';
        $mailData['HeadLine'] = 'New Invoice Created';
        if (count($ToMail) == 1) {
            $mailData['ToName'] = ' ' . $Leades->CL_NAME;
        } else {
            $mailData['ToName'] = '';
        }
        $mailData['BodyText'] = "New Invoice '#### " . $Invoice->INVOICE_TITLE . "' has been generated and waiting for your approval.";
        $mailData['InfoText'] = " Please find the below link to view this.";
        $mailData['BtnUrl'] = URL::to('/invoice/' . $Invoice->INVOICE_ID . '/edit');
        $mailData['InvoiceID'] = '';
        $mailData['Action'] = 'Created';
        $mailData['ActionBy'] = $Invoice->created_by->NAME;
        $mailData['DateTime'] = $this->DateTime;
        $mailData['Project'] = $Invoice->project;
        $mailData['Customer'] = $Invoice->customer;
        $mailData['CustomerDivision'] = $Invoice->customer_division;
        //Level tracking
        $mailData['LevelTracking'] = $LevelTrackingArray['content'];
        $mailData['Li_Percentage'] = $LevelTrackingArray['li_percentage'];
        //
        $mailArray['TemplateName'] = 'finance.emailTemplate.InvoiceEmailMaster';
        $mailArray['Data'] = $mailData;
        $mailArray['Subject'] = 'New Invoice Created ';
        $mailArray['FromMail'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_MAIL'];
        $mailArray['FromName'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_NAME'];
        $mailArray['ToMail'] = $ToMail;
       
        if ($CcMail) {
            $mailArray['CcMail'] = $CcMail;
        }

        return $Response = $this->sendMailBladeTemplate($mailArray);
       
    }

    public function InvoiceUpdateEmailNotify($InvoiceID, $STATUS_NAME = '') {

        $selectArray = array('INVOICE_ID', 'REF_PREFIX', 'INVOICE_TITLE', 'CLIENT_ID', 'CLIENT_DIVISION_ID', 'CREATED_BY', 'LAST_MOD_BY', 'CURRENT_STATUS', 'JOB_ID');
        $withArray = array('project', 'Customer', 'CustomerDivision', 'createdBy', 'updatedBy');

        $Invoice = Models\InvoiceModel::where('INVOICE_ID', $InvoiceID)->with($withArray)->select($selectArray)->first()->toJson();
        $Invoice = json_decode($Invoice);
        $InvoiceCurrentStatus = $Invoice->CURRENT_STATUS;

        $GetInvoiceStatus = Models\InvoiceApprovalModel::where('IS_FINAL', 1)->select('REQUEST_LEVEL_ID', 'ORDER_SEQ')->first()->toArray();
        $InvoiceFianlLevel = $GetInvoiceStatus['REQUEST_LEVEL_ID'];
        $ORDER_SEQ = $GetInvoiceStatus['ORDER_SEQ'];


        $GetApprovedBeforeInvoiceStatus = Models\InvoiceApprovalModel::where('ORDER_SEQ', '<', $ORDER_SEQ)->select('REQUEST_LEVEL_ID', 'ORDER_SEQ')->limit(2)->orderBy('ORDER_SEQ', 'desc')->get()->toArray();
        $ApprovedBeforeInvoiceFianlLevel = $GetApprovedBeforeInvoiceStatus[0]['REQUEST_LEVEL_ID'];
        $ApprovedBeforeORDER_SEQ = $GetApprovedBeforeInvoiceStatus[0]['ORDER_SEQ'];

        $ApprovedBeforeInvoiceFianlLevel2 = $GetApprovedBeforeInvoiceStatus[1]['REQUEST_LEVEL_ID'];
        $ApprovedBeforeORDER_SEQ2 = $GetApprovedBeforeInvoiceStatus[1]['ORDER_SEQ'];


        $GetApprovalUsers = Models\InvoiceApprovalLogModel::where(array('INVOICE_ID' => $InvoiceID, 'IS_APPROVE' => 1, 'IS_ACTIVE' => 1,))->where('REQUEST_LEVEL_ID', '<', $InvoiceFianlLevel)->select('USER_ID')->groupBy('USER_ID')->get()->toArray();
        $ApprovedUsers = array();

        if (count($GetApprovalUsers) > 0) {
            foreach ($GetApprovalUsers as $ApprovalUser) {
                $ApprovedUsers[] = $ApprovalUser['USER_ID'];
            }
        }

        $ApprovedUsers = array_merge(array($Invoice->created_by->USER_ID, $Invoice->updated_by->USER_ID), $ApprovedUsers);
        $ApprovedUsers = array_unique($ApprovedUsers);
        
        // alternate
        $Leades = $this->getUserLeads($Invoice->created_by->USER_ID);
        $AlternateLeadeMail = [];
        if (isset($Leades->CL_WORK_EMAIL_ID) && $Leades->CL_WORK_EMAIL_ID != NULL && trim($Leades->CL_WORK_EMAIL_ID) != '') {
            $AlternateLeadeMail[] = $Leades->CL_WORK_EMAIL_ID;
        }
        $AlternateLeades = $this->getUserLeadsAlternate($Leades->SUB_CIRCLE_ID);
        if (count($AlternateLeades) > 0) {
            foreach ($AlternateLeades as $al) {
                if ($al->WORK_EMAIL_ID != null || trim($al->WORK_EMAIL_ID) != '') {
                    $AlternateLeadeMail[] = $al->WORK_EMAIL_ID;
                }
            }
        }
        //
        
        $ApprovedUsersEmail = $AlternateLeadeMail;
        if (count($ApprovedUsers) > 0) {
            foreach ($ApprovedUsers as $value) {
                $GetUser = DB::table('user')->whereIn('USER_ID', $ApprovedUsers)->where('IS_ACTIVE', 1)->select('WORK_EMAIL_ID')->get();
                if (count($GetUser) > 0) {
                    foreach ($GetUser as $U) {
                        if ($U->WORK_EMAIL_ID != NULL && trim($U->WORK_EMAIL_ID) != '')
                            $ApprovedUsersEmail[] = $U->WORK_EMAIL_ID;
                    }
                }
            }
        }

        if (( $InvoiceFianlLevel == $InvoiceCurrentStatus) || ($InvoiceCurrentStatus == $ApprovedBeforeInvoiceFianlLevel)) { // for finance
            $ToMail = $ApprovedUsersEmail;
            $CcMail = array_merge($this->CONSTANT['NOTIFICATION_EMAIL']['INVOICE_APPROVER_TO_MAIL'], $this->CONSTANT['NOTIFICATION_EMAIL']['INVOICE_APPROVER_CC_MAIL']);
            $ToName = ' Team';
        } else if (($InvoiceCurrentStatus == $ApprovedBeforeInvoiceFianlLevel2) && $InvoiceCurrentStatus != 0) { // for CL
            $ToMail = array_merge($this->CONSTANT['NOTIFICATION_EMAIL']['INVOICE_APPROVER_TO_MAIL'], $this->CONSTANT['NOTIFICATION_EMAIL']['INVOICE_APPROVER_CC_MAIL']);
            $CcMail = $ApprovedUsersEmail;
            $ToName = ' Finance Team';
        } else {

            $Leades = $this->getUserLeads($Invoice->updated_by->USER_ID);
            if (count($Leades) == 0) {
                return true;
            } else if ($Leades->CL_WORK_EMAIL_ID == NULL || trim($Leades->CL_WORK_EMAIL_ID) == '') {
                return true;
            }
            $ToMail = array($Leades->CL_WORK_EMAIL_ID);

            $AlternateLeades = $this->getUserLeadsAlternate($Leades->SUB_CIRCLE_ID);
            if (count($AlternateLeades) > 0) {
                foreach ($AlternateLeades as $al) {
                    if ($al->WORK_EMAIL_ID != null || trim($al->WORK_EMAIL_ID) != '') {
                        $ToMail[] = $al->WORK_EMAIL_ID;
                    }
                }
            }

            $CcMail = array();
            if ($Leades->WORK_EMAIL_ID != NULL && trim($Leades->WORK_EMAIL_ID) == '') {
                $CcMail[] = $Leades->WORK_EMAIL_ID;
            }

            $ToName = ' ' . $Leades->CL_NAME;
            if (count($ToMail) > 1) {
                $ToName = '';
            }
        }

        if (count($ToMail) == 0) {
            return true;
        }


        $LevelTrackingArray = $this->GetStatusTrack($InvoiceID, $InvoiceCurrentStatus);

        if ($STATUS_NAME == '') {
            $txt = ' Updated ';
        } else {
            $txt = ' ' . $STATUS_NAME . ' ';
        }

        $mailArray = $mailData = array();
        $REF_PREFIX = $Invoice->REF_PREFIX;
        if ($REF_PREFIX == '') {
            $REF_PREFIX = '####';
        }
        $mailData['Title'] = 'Invoice ' . $txt;
        $mailData['HeadLine'] = 'Invoice ' . $txt . $REF_PREFIX;
        $mailData['ToName'] = $ToName;
        $mailData['BodyText'] = " Invoice '" . $REF_PREFIX . "  " . $Invoice->INVOICE_TITLE . "'  is " . $txt . ".";
        $mailData['InfoText'] = " Please find the below link to view this.";
        $mailData['BtnUrl'] = URL::to('/invoice/' . $Invoice->INVOICE_ID . '/edit');
        $mailData['InvoiceID'] = $REF_PREFIX;
        $mailData['Action'] = 'Updated';
        $mailData['ActionBy'] = $Invoice->updated_by->NAME;
        $mailData['DateTime'] = $this->DateTime;
        $mailData['Project'] = $Invoice->project;
        $mailData['Customer'] = $Invoice->customer;
        $mailData['CustomerDivision'] = $Invoice->customer_division;

        //Level tracking
        $mailData['LevelTracking'] = $LevelTrackingArray['content'];
        $mailData['Li_Percentage'] = $LevelTrackingArray['li_percentage'];

        $mailArray['TemplateName'] = 'finance.emailTemplate.InvoiceEmailMaster';
        $mailArray['Data'] = $mailData;
        $mailArray['Subject'] = 'Invoice ' . $txt . $REF_PREFIX;
        $mailArray['FromMail'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_MAIL'];
        $mailArray['FromName'] = $this->CONSTANT['NOTIFICATION_EMAIL']['FROM_NAME'];
        $mailArray['ToMail'] = array_unique($ToMail);

        $CcMail = array_diff($CcMail, $ToMail);
        if (count($CcMail) > 0) {
            $mailArray['CcMail'] = array_unique($CcMail);
        }
        return $Response = $this->sendMailBladeTemplate($mailArray);
    }

    public function GetStatusTrack($InvoiceID, $InvoiceCurrentStatus) {
        $StatusList = DB::table('fin_invoice_approval_log')
                ->where('INVOICE_ID', $InvoiceID)
                ->orderBy('INVOICE_APPROVAL_LOG_ID', 'desc')
                ->limit(1)
                ->first();

        if (count($StatusList) == 1) {
            $LastApprovalStatus = $StatusList->IS_APPROVE;
            $LastRequestLevel = $StatusList->REQUEST_LEVEL_ID;
        }

        $InvoiceLevel = Models\InvoiceApprovalModel::orderBy('ORDER_SEQ', 'asc')->get()->toArray();
        $Li_Percentage = round(100 / (count($InvoiceLevel) + 1));
        $LevelTrackingArray = [];

        foreach ($InvoiceLevel as $IL) {
            $LevelTrackingTmpArray = [];

            $st = 'waiting';
            $color = 'silver';
            $tick = '&#9737;';
            $tick_style = 'font-size: 18px;';

            if ($IL['REQUEST_LEVEL_ID'] <= $InvoiceCurrentStatus) { //Complete
                $st = 'done';
                $color = 'yellowgreen';
                $tick = '&#10003;';
                $tick_style = 'font-size: 18px;';
            }


            if (count($StatusList) == 1 && $LastApprovalStatus == 0 && $IL['REQUEST_LEVEL_ID'] == $LastRequestLevel) { // reject
                $st = 'reject';
                $color = '#b50000';
                $tick = '&#10005;';
                $tick_style = 'font-size: 18px;';
            }

            $LevelTrackingTmpArray['st'] = $st;
            $LevelTrackingTmpArray['color'] = $color;
            $LevelTrackingTmpArray['tick'] = $tick;
            $LevelTrackingTmpArray['tick_style'] = $tick_style;
            $LevelTrackingTmpArray['level'] = $IL['LEVEL_NAME'];
            array_push($LevelTrackingArray, $LevelTrackingTmpArray);
        }

        $data = [];
        $data['content'] = $LevelTrackingArray;
        $data['li_percentage'] = $Li_Percentage;
        return $data;
    }

    //get leades for next level approval
    public function getUserLeads($UserID) {
        $getLeads = DB::table('user')
                ->join('user_team_map', 'user_team_map.USER_ID', '=', 'user.USER_ID')
                ->join('team', 'team.TEAM_ID', '=', 'user_team_map.TEAM_ID')
                ->join('sub_circle', 'sub_circle.SUB_CIRCLE_ID', '=', 'team.SUB_CIRCLE')
                ->join(DB::raw('user as user2'), 'user2.USER_ID', '=', 'sub_circle.SUB_CIRCLE_HEAD')
                ->where('user.USER_ID', $UserID)
                ->select('sub_circle.SUB_CIRCLE_ID', 'user.USER_ID', DB::raw('employeename(user.FIRST_NAME, user.MIDDLE_NAME,user.LAST_NAME) AS NAME'), 'user.WORK_EMAIL_ID', DB::raw('user2.USER_ID as CL_USER_ID, employeename(user2.FIRST_NAME, user2.MIDDLE_NAME,user2.LAST_NAME) as CL_NAME, user2.WORK_EMAIL_ID as CL_WORK_EMAIL_ID'))
                ->first();
        return $getLeads;
    }

    public function getUserLeadsAlternate($SubCircleId) {
        return [];
        /*
        $getLeads = DB::table('secondary_notification AS na')
                ->join(DB::raw('user as u'), 'u.USER_ID', '=', 'na.USER_ID')
                ->where('na.ROLE', 1) //1=subcircle
                ->where('na.ROW_ID', $SubCircleId)
                ->where('u.IS_ACTIVE', 1)
                ->select('u.USER_ID', DB::raw('employeename(u.FIRST_NAME, u.MIDDLE_NAME,u.LAST_NAME) AS NAME'), 'u.WORK_EMAIL_ID')
                ->get();
        return $getLeads;
         * 
         */
    }

}
