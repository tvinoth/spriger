<?php

namespace App\Http\Controllers\finance\invoice;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use DB;
use PDF;
use Illuminate\Http\Response;
use App\Models\finance as FinanceModel;
use Config;
use Session;
use Excel;
use GuzzleHttp;

class InvoiceController extends InvoiceNotificationController {

    public function __construct() {
//        $this->middleware(function ($request, $next) {
//            $this->loginUserId = Session::get('users')['user_id'];
//            if (Session::has('users') == '') {
//                return redirect('/');
//            }
//            return $next($request);
//        });

        $this->dateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');


        $this->CLIENT_ITEM_RATE = [ // client id 
            'SPRINGER_INVOICE' => [10885],
        ];
        $this->CONSTANT = Config::get('constants.FINANCE');

        parent::__construct();
    }

    public function add($appName = null) {

        $role = $this->permissionCheck(array('AL', 'AM', 'PM'));

        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.NEW_INVOICE'),$data);
		$newdata 			=	$this->addinvoiceAppwiseListjob($role,$appName);
		$data['appName'] 	=	$appName;
		$data 	=	array_merge($data,$newdata);
        return view('finance.invoice.invoiceAddView')->with($data);
    }
	
	public function addinvoiceAppwiseListjob($role,$appName){
		$jobid 	=	"";
		if(!empty($appName) && strtolower($appName) 	==	"oup"){
			$jobid 	=	"6807";
		// echo DB::connection('oup')->getDatabaseName();
			/*$data['myProjectList'] 	=	DB::connection('oup')->table('job')
										->join('job_info as ji','ji.JOB_ID','=','job.JOB_ID')
										->where('job.IS_ACTIVE',1)
										->where(function($query) use ($role){
											if ($role == 'PM') {
												$query->where('job.PM', Session::get('users.user_id'));
											}	
										})
										->select('job.JOB_ID', 'job.JOB_TITLE', 'job.ACRONYM as BOOK_ID')
										->get();
			
			$data['otherProjectList'] = DB::connection('oup')->table('job')
						->join('job_info as ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                        ->where('job.IS_ACTIVE', 1)
                        ->where(function ($query) use ($role) {
                            if ($role == 'PM') {
                                $query->where('job.PM', '<>', Session::get('users.user_id'));
							} else {
                                $query->where('job.IS_ACTIVE', -1); // temporary 
                            }
                        })
                        ->select('job.JOB_ID', 'job.JOB_TITLE', 'job.ACRONYM as BOOK_ID')->get();
			DB::disconnect('oup');*/
		}else{
		// $data['myProjectList'] = FinanceModel\JobModel::join('job_info as ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                        // ->where('job.IS_ACTIVE', 1)
                        // ->where(function ($query) use ($role) {
                            // if ($role == 'PM' || $role == 'AM') {
                                // $query->where('job.PM', Session::get('users.user_id'))
                                // ->orWhere('ji.AM', Session::get('users.user_id'));
                            // }
                        // })
                        // ->select('job.JOB_ID', 'job.JOB_TITLE', 'job.BOOK_ID')->get();

        // $data['otherProjectList'] = FinanceModel\JobModel::join('job_info as ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                        // ->where('job.IS_ACTIVE', 1)
                        // ->where(function ($query) use ($role) {
                            // if ($role == 'PM' || $role == 'AM') {
                                // $query->where('job.PM', '<>', Session::get('users.user_id'))
                                // ->where('ji.AM', '<>', Session::get('users.user_id'));
                            // } else {
                                // $query->where('job.IS_ACTIVE', -1); // temporary 
                            // }
                        // })
                        // ->select('job.JOB_ID', 'job.JOB_TITLE', 'job.BOOK_ID')->get();
		}
        $data['myProjectList'] = FinanceModel\JobModel::join('job_info as ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                        ->where('job.IS_ACTIVE', 1)
                        ->where(function ($query) use ($role) {
                            if ($role == 'PM' || $role == 'AM') {
                                $query->where('job.PM', Session::get('users.user_id'))
                                ->orWhere('ji.AM', Session::get('users.user_id'));
                            }
                        })
                        ->select('job.JOB_ID', 'job.JOB_TITLE', 'job.BOOK_ID')->where(function ($query) use ($jobid) {
                            if (!empty($jobid )) {
                                $query->where('job.JOB_ID', $jobid);
                            }
                        })->get();

        $data['otherProjectList'] = FinanceModel\JobModel::join('job_info as ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                        ->where('job.IS_ACTIVE', 1)
                        ->where(function ($query) use ($role) {
                            if ($role == 'PM' || $role == 'AM') {
                                $query->where('job.PM', '<>', Session::get('users.user_id'))
                                ->where('ji.AM', '<>', Session::get('users.user_id'));
                            } else {
                                $query->where('job.IS_ACTIVE', -1); // temporary 
                            }
                        })->select('job.JOB_ID', 'job.JOB_TITLE', 'job.BOOK_ID')->where(function ($query) use ($jobid) {
                            if (!empty($jobid )) {
                                $query->where('job.JOB_ID', $jobid);
                            }
                        })
                        ->select('job.JOB_ID', 'job.JOB_TITLE', 'job.BOOK_ID')->get();
		return 	$data;			
    }

    public function ajaxAddInvoice(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM'));

        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['projectId'] = 'required|numeric|min:2';
            $validationArray['projectName'] = 'required|min:2';
            $validationArray['billingAddId'] = 'required|numeric';
            $validationArray['invoiceType'] = 'required|numeric';
            $validationArray['clientId'] = 'required|numeric';
            $validationArray['subTotal'] = 'required|numeric';
            $validationArray['igst'] = 'required|numeric';
            $validationArray['finalTotal'] = 'required|numeric';

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $projectId = $request->input('projectId');
                $projectName = $request->input('projectName');

                $projectTrimType = $request->input('projectTrimType');
                $projectWorkType = $request->input('projectWorkType');
                $projectComposition = $request->input('projectComposition');
                $projectCeLevel = $request->input('projectCeLevel');

                $isbn = $request->input('isbn');
                $orderNo = $request->input('orderNo');
                $author = $request->input('author');
                $invoiceType = $request->input('invoiceType');
                $pspElement = $request->input('pspElement');
                $clientId = $request->input('clientId');
                $billTo = $request->input('billingAddId');
                $phone = $request->input('phone');
                $kindAttn = $request->input('kindAttn');

                $lineItem = $request->input('invoiceLineItem');
                $accountCodeTotal = $request->input('accountCodeTotal');

                $subTotal = $request->input('subTotal');
                $finalTotal = $request->input('finalTotal');
                $currencyId = $request->input('currencyId');

                $CompanyAddressID = 1;
                $PaymentDetailsID = 1;

                //line item
                $lineItemArray = $autoQtyServiceItem = [];
                for ($i = 0; $i < count($lineItem); $i++) {

                    $ITEM_DISPLAY_NAME = NULL;

                    // get invoice item isplay name
                    $serviceItemQuery = DB::table('fin_service_items AS fsi')
                            ->where('fsi.SERVICE_ITEM_ID', $lineItem[$i]['lineItemId'])
                            ->select('ITEM_DISPLAY_NAME');
                    if ($serviceItemQuery->count() > 0) {
                        $getServiceItemName = $serviceItemQuery->first();
                        if (!empty($getServiceItemName->ITEM_DISPLAY_NAME)) {
                            $ITEM_DISPLAY_NAME = $getServiceItemName->ITEM_DISPLAY_NAME;
                        }
                    }
                    //

                    $lineItemTempArray = [];
                    $lineItemTempArray['SERVICE_GROUP_ID'] = $lineItem[$i]['serviceGroupId'];
                    $lineItemTempArray['SERVICE_GROUP_NAME'] = $lineItem[$i]['serviceGroupName'];
                    $lineItemTempArray['SERVICE_ITEM_ID'] = $lineItem[$i]['lineItemId'];
                    $lineItemTempArray['ACCOUNT_CODE'] = $lineItem[$i]['accountCode'];
                    $lineItemTempArray['ITEM_REMARK'] = $lineItem[$i]['lineItemRemark'];
                    $lineItemTempArray['ITEM_CODE'] = $lineItem[$i]['itemCode'];
                    $lineItemTempArray['ITEM_DESCRIPTION'] = $lineItem[$i]['description'];
                    $lineItemTempArray['CLIENT_ITEM_CODE'] = NULL;
                    $lineItemTempArray['CLENT_ITEM_DESCRIPTION'] = $ITEM_DISPLAY_NAME;
                    $lineItemTempArray['RATE_FIELD'] = $lineItem[$i]['rateField'];

                    if ($lineItemTempArray['RATE_FIELD'] == 1) {
                        $lineItemTempArray['UNIT_QTY'] = $lineItem[$i]['unitQty'];
                        $lineItemTempArray['UNIT_ENUM_ID'] = $lineItem[$i]['unitType'];
                        $lineItemTempArray['QTY'] = $lineItem[$i]['qty'];
                    } else {
                        $lineItemTempArray['UNIT_QTY'] = $lineItemTempArray['UNIT_ENUM_ID'] = $lineItemTempArray['QTY'] = null;
                    }

                    $lineItemTempArray['RATE'] = $lineItem[$i]['price'];
                    $lineItemTempArray['AMOUNT'] = $lineItem[$i]['total'];

                    if ($lineItem[$i]['disablePriceEdit'] == 0) {
                        $lineItemTempArray['IS_EDITABLE'] = 1;
                    } else {
                        $lineItemTempArray['IS_EDITABLE'] = 0;
                    }

                    if ($lineItem[$i]['autoQty'] > 0) {
                        $autoQtyServiceItem[$lineItem[$i]['lineItemId']] = array('autoQty' => $lineItem[$i]['autoQty'], 'invQty' => $lineItem[$i]['qty']);
                    }

                    array_push($lineItemArray, $lineItemTempArray);
                }

                // account code
                $accountCodeArray = [];
                for ($i = 0; $i < count($accountCodeTotal); $i++) {
                    $accountCodeTempArray = [];
                    $accountCodeTempArray['CODE_DESCRIPTION'] = $accountCodeTotal[$i]['accountCode'];
                    $accountCodeTempArray['AMOUNT'] = $accountCodeTotal[$i]['accountTotal'];
                    array_push($accountCodeArray, $accountCodeTempArray);
                }



                //invoice estd qty adjustment
                $clientName_ItemRate = '';
                foreach ($this->CLIENT_ITEM_RATE as $clientRateKey => $clientRateValue) {
                    if (in_array($clientId, $clientRateValue)) {
                        $clientName_ItemRate = $clientRateKey;
                    }
                }


                /*
                  // Springer Estimate Qty
                  if ($clientName_ItemRate == 'SPRINGER_INVOICE') {

                  if (count($autoQtyServiceItem) > 0) {
                  foreach ($autoQtyServiceItem as $key => $value) {

                  $autoQty = $value['autoQty'];
                  $invQty = $value['invQty'];

                  if ($autoQty !== $invQty) {

                  $qtyDiff = ($autoQty - $invQty);
                  $estdQty = DB::table('fin_lineitem_stage_map AS lm')
                  ->join('fin_invoice_estd_qty AS iq', function ($query) use($clientId) {
                  return $query->on('iq.ROUND_ID', '=', 'lm.ROUND_ID')
                  ->on('iq.STAGE_ID', '=', 'lm.STAGE_ID')
                  ->where('iq.STATUS', 1)
                  ->where('iq.IS_ACTIVE', 1);
                  })
                  ->where('lm.SERVICE_ITEM_ID', $key)
                  ->where('lm.IS_ACTIVE', 1)
                  ->where('lm.CUSTOMER_ID', $clientId)
                  ->update(array('iq.ESTD_QTY' => $qtyDiff, 'QTY_SRC' => 2));
                  }
                  }
                  }
                  }
                  // end Springer Estimate Qty
                  //end invoice estd qty adjustment
                 * 
                 */


                DB::beginTransaction();
                try {

                    $project = FinanceModel\JobModel::where('JOB_ID', $projectId)->select('SUB_CIRCLE', 'TEAM', 'CUSTOMER_DIVISION_ID')->first();

                    $billToAddress = FinanceModel\CustomerAddressModel::find($billTo)->toJson();
                    $billToAddress = json_decode($billToAddress);

                    $currencyDetails = FinanceModel\CurrencyEnumModel::find($currencyId);

                    $paymentDetails = FinanceModel\PaymetDetailsModel::find($PaymentDetailsID)->toJson();
                    $CompanyAddress = FinanceModel\CompanyAddressModel::find($CompanyAddressID)->toJson();

                    $invoice = new FinanceModel\InvoiceModel();
                    $invoice->INVOICE_TITLE = $projectName;
                    $invoice->COMPANY_ADDRESS_ID = $CompanyAddressID;
                    $invoice->JOB_ID = $projectId;
                    $invoice->JOB_TITLE = $projectName;
                    $invoice->CLUSTER_ID = $project->SUB_CIRCLE;
                    $invoice->TEAM_ID = $project->TEAM;
                    $invoice->CLIENT_ID = $clientId;
                    $invoice->CLIENT_DIVISION_ID = $project->CUSTOMER_DIVISION_ID;
                    $invoice->CLIENT_ADDRESS_ID = $billTo;
                    $invoice->PAYMENT_DETAILS_ID = $PaymentDetailsID;
                    $invoice->CURRENCY_ID = $currencyId;
                    $invoice->CURRENCY_NAME = $currencyDetails->NAME;
                    $invoice->CURRENCY_SYMBOL = $currencyDetails->SYMBOL;
                    $invoice->SUB_TOTAL = $subTotal;
                    $invoice->TOTAL = $subTotal;
                    $invoice->FINAL_TOTAL = $finalTotal;

                    //tax
                    $clientCountry = $billToAddress->COUNTRY;
                    $indiaId = 4;
                    if ($clientCountry == $indiaId && ($clientState == 'TN' || $clientState == 'TAMIL NADU' || $clientState == 'TAMILNADU')) { // 4=india
                        $invoice->CGST_TAX_FIELD = 'CGST @9%';
                        $invoice->CGST_TAX_AMOUNT = $igstDomesticCentralTax;
                        $invoice->SGST_TAX_FIELD = 'SGST @9%';
                        $invoice->SGST_TAX_AMOUNT = $igstDomesticStateTax;
                        $invoice->TOTAL_TAX_FIELD = 'Total Tax @18%';
                        $invoice->TOTAL_TAX_AMOUNT = $igstDomesticTotalTax;
                    } else if ($clientCountry == $indiaId && $clientState != 'TN' && $clientState != 'TAMIL NADU' && $clientState != 'TAMILNADU') {
                        $invoice->IGST_TAX_FIELD = 'IGST @18%';
                        $invoice->IGST_TAX_AMOUNT = $igstDomesticTax;
                    } else if ($clientCountry != $indiaId) {
                        $invoice->IGST_TAX_FIELD = 'IGST @0%';
                        $invoice->IGST_TAX_AMOUNT = 0;
                    }
                    //

                    $invoice->CURRENT_STATUS = 0;
                    $invoice->INVOICE_TYPE = $invoiceType;
                    $invoice->CREATED_BY = $this->loginUserId;
                    $invoice->CREATED_DATE = $this->dateTime;
                    $invoice->save();
                    $invoiceId = $invoice->INVOICE_ID;

                    // invoice ref 
                    $invoiceRef = [];
                    $invoiceRef['INVOICE_ID'] = $invoiceId;
                    $invoiceRef['AUTHOR'] = $author;
                    $invoiceRef['ISBN'] = $isbn;
                    $invoiceRef['ORDER_NO'] = $orderNo;
                    $invoiceRef['PSP_ELEMENT'] = $pspElement;
                    $invoiceRef['TRIM_TYPE'] = $projectTrimType;
                    $invoiceRef['WORK_TYPE'] = $projectWorkType;
                    $invoiceRef['COMPOSITION_TYPE'] = $projectComposition;
                    $invoiceRef['CE_LEVEL'] = $projectCeLevel;
                    $invoiceRefInsert = DB::table('fin_invoice_ref')->insert($invoiceRef);

                    // services item mapping 
                    foreach ($lineItemArray as &$item) {
                        $item['INVOICE_ID'] = $invoiceId;
                    }
                    $lineItemInsert = DB::table('fin_invoice_items')->insert($lineItemArray);


                    // account code group
                    if (count($accountCodeArray) > 0) {
                        foreach ($accountCodeArray as &$item) {
                            $item['INVOICE_ID'] = $invoiceId;
                        }
                    }
                    $accountCodeInsert = DB::table('fin_invoice_account_code')->insert($accountCodeArray);


                    // invoice billing address mapping
                    if (count($billToAddress) > 0) {

                        $billToInsert = [];
                        $billToInsert['INVOICE_ID'] = $invoiceId;
                        $billToInsert['CUSTOMER_ADDRESS_ID'] = $billToAddress->CUSTOMER_ADDRESS_ID;
                        $billToInsert['CONTACT_NAME'] = $kindAttn;
                        $billToInsert['ADDRESS_LINE_1'] = $billToAddress->ADDRESS_LINE_1;
                        $billToInsert['ADDRESS_LINE_2'] = $billToAddress->ADDRESS_LINE_2;
                        $billToInsert['ADDRESS_LINE_3'] = $billToAddress->ADDRESS_LINE_3;
                        $billToInsert['PHONE'] = $phone;
                        $billToInsert['FAX'] = $billToAddress->FAX;
                        $billToInsert['CITY'] = $billToAddress->CITY;
                        $billToInsert['STATE'] = $billToAddress->STATE;
                        $billToInsert['COUNTRY'] = $billToAddress->COUNTRY;
                        $billToInsert['ZIP'] = $billToAddress->ZIP;
                        $billToInsert['EMAIL_ID'] = $billToAddress->EMAIL_ID;

                        DB::table('fin_invoice_billing_address')->insert($billToInsert);
                    }

                    // invoice_company_address mapping
                    $getCompanyAddressData = json_decode($CompanyAddress);
                    if (count($getCompanyAddressData) > 0) {

                        $companyAddressDataInsert = [];
                        $companyAddressDataInsert['COMPANY_ADDRESS_ID'] = $getCompanyAddressData->COMPANY_ADDRESS_ID;
                        $companyAddressDataInsert['INVOICE_ID'] = $invoiceId;
                        $companyAddressDataInsert['COMPANY_NAME'] = $getCompanyAddressData->COMPANY_NAME;
                        $companyAddressDataInsert['ADDRESS_LINE1'] = $getCompanyAddressData->ADDRESS_LINE1;
                        $companyAddressDataInsert['ADDRESS_LINE2'] = $getCompanyAddressData->ADDRESS_LINE2;
                        $companyAddressDataInsert['ADDRESS_LINE3'] = $getCompanyAddressData->ADDRESS_LINE3;
                        $companyAddressDataInsert['CITY'] = $getCompanyAddressData->CITY;
                        $companyAddressDataInsert['STATE'] = $getCompanyAddressData->STATE;
                        $companyAddressDataInsert['ZIP'] = $getCompanyAddressData->ZIP;
                        $companyAddressDataInsert['COUNTRY'] = $getCompanyAddressData->COUNTRY;
                        $companyAddressDataInsert['PHONE'] = $getCompanyAddressData->PHONE;
                        $companyAddressDataInsert['EMAIL_ID'] = $getCompanyAddressData->EMAIL_ID;
                        $companyAddressDataInsert['FAX'] = $getCompanyAddressData->FAX;
                        $companyAddressDataInsert['OTHER'] = $getCompanyAddressData->OTHER;
                        $companyAddressDataInsert['FINANCE_CONTACT'] = $getCompanyAddressData->FINANCE_CONTACT;
                        $companyAddressDataInsert['CIN'] = $getCompanyAddressData->CIN;
                        $companyAddressDataInsert['GSTIN'] = $getCompanyAddressData->GSTIN;
                        $companyAddressDataInsert['SAC_CODE'] = $getCompanyAddressData->SAC_CODE;

                        DB::table('fin_invoice_company_address')->insert($companyAddressDataInsert);
                    }

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['invoiceId'] = $invoiceId;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
            //Email Notification
            if ($Response['status'] == 1 && $this->CONSTANT['INVOICE_EMAIL_NOTIFICATION'] == true) {
                $this->InvoiceCreateEmailNotify($invoiceId);
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function lists($appName = null) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));

        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.INVOICE_MANAGE'),$data);
        $data['projectList'] = FinanceModel\JobModel::where('IS_ACTIVE', 1)->select('JOB_ID', 'JOB_TITLE', 'BOOK_ID')->where(function($query) use ($appName){
			if(!empty($appName)){
				$query->where('JOB_ID',6807);
			}
		})->get();
        /* $data['pMNameList'] = DB::table('job AS j')
          ->join('user AS u', 'u.USER_ID', '=', 'j.PM')
          ->where('j.IS_ACTIVE', 1)
          ->where('u.IS_ACTIVE', 1)
          ->orderBy(DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME)'), 'ASC')
          ->select(array('u.USER_ID', DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME) AS NAME')))
          ->get(); */
        $data['pMNameList'] = DB::table('role_enum AS re')
                ->join('user AS u', 'u.ROLE', '=', 're.ID')
                ->where('re.NAME', 'Project Manager')
                ->where('re.IS_ACTIVE', 1)
                ->where('u.IS_ACTIVE', 1)
                ->orderBy(DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME)'), 'ASC')
                ->select(array('u.USER_ID', DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME) AS NAME')))
                ->get();
        $data['invoiceStatus'] = FinanceModel\InvoiceApprovalModel::where('IS_ACTIVE', 1)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ')->get();
		$data['appName'] 	=	$appName;
        return view('finance.invoice.invoiceListView')->with($data);
    }

    public function getInvoiceList(Request $request) {


        if ($request->input()) {

            $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
            $REQ_LEVEL = $this->CONSTANT['ROLES_PRIVILEGES'][$role];
            $loginUserId = Session::get('users.user_id');

            $Req = (object) $request->input();
            $listType = $Req->listType;

            if ($listType != 'TABLE_VIEW' && $listType != 'EXCEL_EXPORT') {
                die('Access Denied');
            }

            $columnArray = array();
            $columnArray[] = 'i.REF_PREFIX';
            $columnArray[] = 'i.INVOICE_DATE';
            $columnArray[] = 'i.JOB_TITLE';
            $columnArray[] = 'c.CUSTOMER_NAME';
            $columnArray[] = 'i.FINAL_TOTAL';
            $columnArray[] = 'i.CURRENT_STATUS';
            $columnArray[] = 'i.CREATED_BY';
            $columnArray[] = 'i.CREATED_DATE';
            $columnArray[] = 'i.INVOICE_ID';
            $columnArray[] = 'i.JOB_ID';
            $columnArray[] = 'j.CUSTOMER_DIVISION_ID';
            $columnArray[] = 'j.BOOK_ID';

            $columnArray[] = 'i.CURRENCY_SYMBOL';
            $columnArray[] = 'i.IS_REQUEST_LEVEL_REJECT';
            $columnArray[] = 'i.IS_CANCELLED';
            $columnArray[] = 'is.LEVEL_NAME';

            $columnArray[] = DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME) AS CREATED_BY');
            $columnArray[] = 'ji.PE_LOCATION';
            $columnArray[] = 'fir.AUTHOR';



            $orderColumn = 8; //invoice id column
            if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
                $orderColumn = $Req->order[0]['column'];
            }

            $sorting = 'desc';
            if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
                $sorting = $Req->order[0]['dir'];
            }

            $start = '';
            if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
                $start = $Req->start;
            }

            $length = false;
            if (isset($Req->length) && $Req->length != -1) {
                $length = $Req->length;
            }

            $projectId = '';
            if (trim($Req->projectId) != '' && $Req->projectId > 0) {
                $projectId = $Req->projectId;
            }

            $startDate = $endDate = '';
            if (trim($Req->startDate) != '') {
                $startDate = $Req->startDate;
            }
            if (trim($Req->endDate) != '') {
                $endDate = $Req->endDate;
            }

            $invoiceStatus = '';
            if (trim($Req->invoiceStatus) != '') {
                $invoiceStatus = $Req->invoiceStatus;
            }

            $searchStr = '';
            if (isset($Req->search) && trim($Req->search['value']) != '') {
                $searchStr = trim($Req->search['value']);
            }





            $pMName = '';
            if (trim($Req->pMName) != '') {
                $pMName = $Req->pMName;
            }

			$appJobId = '';
            if (trim($Req->appJobId) != '') {
                $appJobId = $Req->appJobId;
            }

            if ($listType == 'TABLE_VIEW') {

                $recordsTotal = DB::table('fin_invoice AS i')
                        ->join('customer AS c', 'c.CUSTOMER_ID', '=', 'i.CLIENT_ID')
                        ->join('job AS j', 'j.JOB_ID', '=', 'i.JOB_ID')
                        ->join('job_info AS ji', 'ji.JOB_ID', '=', 'i.JOB_ID')
                        ->join('fin_invoice_ref AS fir', 'fir.INVOICE_ID', '=', 'i.INVOICE_ID')
                        ->join('user AS u', 'u.USER_ID', '=', 'i.CREATED_BY')
                        ->leftJoin('fin_request_level AS is', 'is.REQUEST_LEVEL_ID', '=', 'i.CURRENT_STATUS')
                        ->where('i.IS_ACTIVE', 1)
                        ->where(function ($query) use ($role) {
                            if ($role == 'PM' || $role == 'AM') {
                                $query->where('j.PM', Session::get('users.user_id'))
                                ->orWhere('ji.AM', Session::get('users.user_id'));
                            }
                        })
                        ->where(function ($query) use ($projectId) {
                            if (trim($projectId) != '' && $projectId > 0) {
                                return $query->where('i.JOB_ID', $projectId);
                            }
                        })
                        ->where(function ($query) use ($loginUserId) {
                            return $query->where('i.CREATED_BY', $loginUserId)
                                    ->orWhere('i.CLIENT_ID', '>', 0);
                        })
                        ->where(function ($query) use ($invoiceStatus) {
                            if ($invoiceStatus == 'REJECT') {
                                return $query->where('i.IS_REQUEST_LEVEL_REJECT', 1);
                            } else if (trim($invoiceStatus) != '' && $invoiceStatus >= 0 && $invoiceStatus != 'CANCELLED') {
                                return $query->where('i.CURRENT_STATUS', $invoiceStatus)->where('i.IS_CANCELLED', 0);
                            } else if (trim($invoiceStatus) != '' && $invoiceStatus == 'CANCELLED') {
                                return $query->where('i.IS_CANCELLED', 1);
                            }
                        })
                        ->where(function ($query) use ($startDate, $endDate) {
                            if (trim($startDate) != '' && trim($endDate) == '') {
                                return $query->whereRaw('date(i.CREATED_DATE) >= "' . $startDate . '"');
                            } else if (trim($endDate) != '' && trim($startDate) == '') {
                                return $query->whereRaw('date(i.CREATED_DATE) <= "' . $endDate . '"');
                            } else if (trim($startDate) != '' && trim($endDate) != '') {
                                $query->whereRaw('date(i.CREATED_DATE) BETWEEN  "' . $startDate . '" AND  "' . $endDate . '"');
                            }
                        })
                        ->where(function ($query) use ($pMName) {
                            if (trim($pMName) != '' && $pMName > 0) {
                                return $query->where('j.PM', $pMName)->orWhere('i.CREATED_BY', $pMName);
                            }
                        })->where(function ($query) use ($appJobId) {
                            if (!empty($appJobId )) {
                                $query->where('j.JOB_ID', 6807);
                            }
                        })
                        ->when($searchStr, function ($query) use ($searchStr) {
                            return $query->where('i.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                    ->orWhere('i.JOB_ID', 'like', '%' . $searchStr . '%')
                                    ->orWhere('j.BOOK_ID', 'like', '%' . $searchStr . '%')
                                    ->orWhere('j.PM', 'like', '%' . $searchStr . '%')
                                    ->orWhere(DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME)'), 'like', '%' . $searchStr . '%')
                                    ->orWhere('i.REF_PREFIX', 'like', '%' . $searchStr . '%')
                                    ->orWhere('c.CUSTOMER_NAME', 'like', '%' . $searchStr . '%');
                        })
                        ->count();
            }

            $columnArray[] = DB::raw('COUNT(fial.INVOICE_APPROVAL_LOG_ID) AS rejectCnt');

            $activeData = DB::table('fin_invoice AS i')
                    ->join('customer AS c', 'c.CUSTOMER_ID', '=', 'i.CLIENT_ID')
                    ->join('job AS j', 'j.JOB_ID', '=', 'i.JOB_ID')
                    ->join('job_info AS ji', 'ji.JOB_ID', '=', 'i.JOB_ID')
                    ->join('fin_invoice_ref AS fir', 'fir.INVOICE_ID', '=', 'i.INVOICE_ID')
                    ->join('user AS u', 'u.USER_ID', '=', 'i.CREATED_BY')
                    ->leftJoin('fin_request_level AS is', 'is.REQUEST_LEVEL_ID', '=', 'i.CURRENT_STATUS')
                    ->leftJoin('fin_invoice_approval_log AS fial', function($join) {
                        $join->on('fial.INVOICE_ID', '=', 'i.INVOICE_ID');
                        $join->on('fial.IS_APPROVE', '=', DB::raw('0'));
                    })
                    ->where('i.IS_ACTIVE', 1)
                    ->where(function ($query) use ($role) {
                        if ($role == 'PM' || $role == 'AM') {
                            $query->where('j.PM', Session::get('users.user_id'))
                            ->orWhere('ji.AM', Session::get('users.user_id'));
                        }
                    })
                    ->where(function ($query) use ($projectId) {
                        if (trim($projectId) != '' && $projectId > 0) {
                            return $query->where('i.JOB_ID', $projectId);
                        }
                    })
                    ->where(function ($query) use ($loginUserId) {
                        return $query->where('i.CREATED_BY', $loginUserId)
                                ->orWhere('i.CLIENT_ID', '>', 0);
                    })
                    ->where(function ($query) use ($invoiceStatus) {
                        if ($invoiceStatus == 'REJECT') {
                            return $query->where('i.IS_REQUEST_LEVEL_REJECT', 1);
                        } else if (trim($invoiceStatus) != '' && $invoiceStatus >= 0 && $invoiceStatus != 'CANCELLED') {
                            return $query->where('i.CURRENT_STATUS', $invoiceStatus)->where('i.IS_CANCELLED', 0);
                        } else if (trim($invoiceStatus) != '' && $invoiceStatus == 'CANCELLED') {
                            return $query->where('i.IS_CANCELLED', 1);
                        }
                    })
                    ->where(function ($query) use ($startDate, $endDate) {
                        if (trim($startDate) != '' && trim($endDate) == '') {
                            return $query->whereRaw('date(i.CREATED_DATE) >= "' . $startDate . '"');
                        } else if (trim($endDate) != '' && trim($startDate) == '') {
                            return $query->whereRaw('date(i.CREATED_DATE) <= "' . $endDate . '"');
                        } else if (trim($startDate) != '' && trim($endDate) != '') {
                            $query->whereRaw('date(i.CREATED_DATE) BETWEEN  "' . $startDate . '" AND  "' . $endDate . '"');
                        }
                    })
                    ->where(function ($query) use ($pMName) {
                        if (trim($pMName) != '' && $pMName > 0) {
                            return $query->where('j.PM', $pMName)->orWhere('i.CREATED_BY', $pMName);
                        }
                    })->where(function ($query) use ($appJobId) {
                            if (!empty($appJobId )) {
                                $query->where('j.JOB_ID', 6807);
                            }
                    })
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('i.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                ->orWhere('i.JOB_ID', 'like', '%' . $searchStr . '%')
                                ->orWhere('j.BOOK_ID', 'like', '%' . $searchStr . '%')
                                ->orWhere('j.PM', 'like', '%' . $searchStr . '%')
                                ->orWhere(DB::raw('employeename(u.FIRST_NAME,u.MIDDLE_NAME,u.LAST_NAME)'), 'like', '%' . $searchStr . '%')
                                ->orWhere('i.REF_PREFIX', 'like', '%' . $searchStr . '%')
                                ->orWhere('c.CUSTOMER_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->orderBy($columnArray[$orderColumn], $sorting)
                    ->when($length, function ($query) use ($length, $start) {
                        if (trim($start) != '' && $start >= 0) {
                            return $query->skip($start)->take($length);
                        }
                    })
                    ->select($columnArray)
                    ->groupBy('i.INVOICE_ID')
                    ->get();


            $data = array();
            foreach ($activeData as $row) {

                if ($row->IS_CANCELLED == 1) {
                    $CURRENT_STATUS = 'Cancelled';
                    $CURRENT_STATUS_LABEL = 'label-danger';
                } else if ($row->IS_REQUEST_LEVEL_REJECT == 1) {

                    $CURRENT_STATUS = 'Rejected (' . $row->rejectCnt . ')';
                    $CURRENT_STATUS_LABEL = 'label-danger';
                } else {

                    $CURRENT_STATUS = $row->LEVEL_NAME;
                    if (trim($CURRENT_STATUS) == '') {
                        $CURRENT_STATUS = 'Generated';
                    }
                    $CURRENT_STATUS_LABEL = $this->CONSTANT['INVOICE_STATUS_LABEL'][$row->CURRENT_STATUS];
                }


                $tempArray = array();

                $tempArray['INVOICE_NO'] = $row->REF_PREFIX;
                $tempArray['INVOICE_DATE'] = $row->INVOICE_DATE;
                $tempArray['JOB_ID'] = $row->JOB_ID;

                if ($listType == 'TABLE_VIEW') {
                    $tempArray['JOB_TITLE'] = $row->JOB_TITLE . ' (' . $row->BOOK_ID . ')';
                } else if ($listType == 'EXCEL_EXPORT') {
                    $tempArray['JOB_TITLE'] = $row->JOB_TITLE;
                    $tempArray['BOOK_ID'] = $row->BOOK_ID;
                    $tempArray['LOCATION'] = $row->PE_LOCATION;
                    $tempArray['AUTHOR'] = $row->AUTHOR;
                }

                $tempArray['CUSTOMER_NAME'] = $row->CUSTOMER_NAME;
                $tempArray['FINAL_TOTAL'] = $row->CURRENCY_SYMBOL . ' ' . $row->FINAL_TOTAL;

                if ($listType == 'TABLE_VIEW') {

                    $tempArray['INVOICE_ID'] = $row->INVOICE_ID;
                    $tempArray['CURRENT_STATUS'] = '<span class="label label-sm ' . $CURRENT_STATUS_LABEL . ' ">' . $CURRENT_STATUS . '</span>';

                    $enableEdit = false;
                    if (in_array($row->CURRENT_STATUS, $REQ_LEVEL) && $row->IS_CANCELLED == 0) {
                        $enableEdit = true;
                    }
					$editurlchange 	=	"";
					if($row->CUSTOMER_DIVISION_ID 	==	179){
						$editurlchange 	=	"/oup";	
					}
                    if ($enableEdit == true) {
                        $tempArray['ACTION'] = '<a title="edit Invoice" class="edit_action" href="' . url('fin/invoice/' . $row->INVOICE_ID . '/edit'.$editurlchange) . '"><button type="button" class="btn btn-white btn-success btn-bold btn-sm"><i class="fa fa-pencil "></i> Edit &nbsp;</button></a>';
                    } else {
                        $tempArray['ACTION'] = '<a title="View Invoice" class="edit_action" href="' . url('fin/invoice/' . $row->INVOICE_ID . '/edit'.$editurlchange) . '"><button type="button" class="btn btn-white btn-info btn-bold btn-sm"><i class="fa fa-eye "></i> View</button></a>';
                    }
                } else if ($listType == 'EXCEL_EXPORT') {
                    $tempArray['CURRENT_STATUS'] = $CURRENT_STATUS;
                }

                $tempArray['CREATED_BY'] = $row->CREATED_BY;
                $tempArray['CREATED_DATE'] = $row->CREATED_DATE;


                array_push($data, $tempArray);
            }

            if ($listType == 'TABLE_VIEW') {
                $Response = array();
                $Response["draw"] = $Req->draw;
                $Response["recordsTotal"] = $recordsTotal;
                $Response["recordsFiltered"] = $recordsTotal;
                $Response["data"] = $data;

                return response()->json($Response);
            } else if ($listType == 'EXCEL_EXPORT') {

                Excel::create('invoiceList', function($excel) use ($data) {
//                    $excel->setTitle('Invoice List');
//                    $excel->setCreator('Magnus')->setCompany('Spi Global');
//                    $excel->setDescription('Invoice List - Downloaded at ' . $this->dateTime);

                    $col = ['INVOICE_NO', 'INVOICE_DATE', 'JOB_ID', 'JOB_TITLE', 'BOOK_ID', 'LOCATION', 'AUTHOR', 'CUSTOMER_NAME', 'FINAL_TOTAL', 'CURRENT_STATUS', 'CREATED_BY', 'CREATED_DATE'];
                    array_unshift($data, $col);

                    if (count($data) > 0) {
                        $excel->sheet('Invoice List', function($sheet) use ($data) {

                            $titleStyle = array(
                                'font' => array(
                                    'name' => 'Calibri',
                                    'size' => 14,
                                    'bold' => true
                                )
                            );

                            $startCol = 'A';
                            $endCol = 'L';

                            $sheet->mergeCells($startCol . '1:' . $endCol . '1')->setBorder('A1', 'thin');
                            $sheet->mergeCells($startCol . '2:' . $endCol . '2')->setBorder('A2', 'thin');

                            $sheet->setBorder($startCol . '5:' . $endCol . '5', 'thin');
                            $sheet->setCellValue($startCol . '1', 'Magnus Invoice List', true);
                            $sheet->setCellValue($startCol . '2', 'Downloaded at ' . $this->dateTime, true);



                            $sheet->fromArray($data, null, 'A5', false, false);
                        });
                    }
                })->export('xls'); // or->download('xls');
            }
        }
    }

    public function edit(Request $request, $invoiceID,$appName = null) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        $REQ_LEVEL = $this->CONSTANT['ROLES_PRIVILEGES'][$role];
        $REQ_APPROVAL = $this->CONSTANT['ROLES_APPROVAL'][$role];
        $Invoice = FinanceModel\InvoiceModel::where('INVOICE_ID', $invoiceID)->select('REF_PREFIX', 'INVOICE_DATE', 'INVOICE_ID', 'IS_ACTIVE', 'CURRENT_STATUS')->first();
        if ($Invoice->IS_ACTIVE == 0) {
            return redirect('fin/invoice/list');
            die('Invoice Deleted');
        }

        $enableEdit = false;
        if (in_array($Invoice->CURRENT_STATUS, $REQ_LEVEL)) {
            $enableEdit = true;
        }

        //$sFilter = [3, 4, 5];
//        $nextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $Invoice->CURRENT_STATUS)->whereIn('REQUEST_LEVEL_ID', $sFilter)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();
        $nextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $Invoice->CURRENT_STATUS)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();
        $enableApproval = false;
        if (count($nextLevel) > 0) {
            if (in_array($nextLevel->REQUEST_LEVEL_ID, $REQ_APPROVAL)) {
                $enableApproval = true;
            }
        }

        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.INVOICE_MANAGE'),$data);
        $data['pageTitle'] = 'Edit Invoice';
        if ($Invoice->REF_PREFIX != null && trim($Invoice->REF_PREFIX) != '') {
            $data['pageName'] = 'Edit Invoice - ' . '<span style="color:red"> #' . $Invoice->REF_PREFIX . ' (' . date('d M Y', strtotime($Invoice->INVOICE_DATE)) . ')</span>';
        } else {
            $data['pageName'] = 'Edit Invoice';
        }

        $data['invoiceId'] = $invoiceID;
        $data['enableEdit'] = $enableEdit;
        $data['enableApproval'] = $enableApproval;

        $data['enablePdfFrame'] = 'none';
        $data['showHtmlContent'] = 'block';
        if ($role == 'AL') {
            $data['enablePdfFrame'] = 'block';
            $data['showHtmlContent'] = 'none';
        }
		$data['appName'] 	=	$appName;
        return view('finance.invoice.invoiceEditView')->with($data);
    }

    public function ajaxUpdateInvoice(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['invoiceId'] = 'required|numeric|min:2';
            $validationArray['projectId'] = 'required|numeric|min:2';
            $validationArray['projectName'] = 'required|min:2';
            $validationArray['billingAddId'] = 'required|numeric';
            $validationArray['invoiceType'] = 'required|numeric';
            $validationArray['clientId'] = 'required|numeric';
            $validationArray['subTotal'] = 'required|numeric';
            $validationArray['igst'] = 'required|numeric';
            $validationArray['finalTotal'] = 'required|numeric';

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $invoiceId = $request->input('invoiceId');
                $projectId = $request->input('projectId');
                $projectName = $request->input('projectName');
                $isbn = $request->input('isbn');
                $orderNo = $request->input('orderNo');
                $author = $request->input('author');
                $invoiceType = $request->input('invoiceType');
                $pspElement = $request->input('pspElement');
                $clientId = $request->input('clientId');
                $billTo = $request->input('billingAddId');
                $phone = $request->input('phone');
                $kindAttn = $request->input('kindAttn');

                $lineItem = $request->input('invoiceLineItem');
                $accountCodeTotal = $request->input('accountCodeTotal');

                $subTotal = $request->input('subTotal');
                $finalTotal = $request->input('finalTotal');
                $currencyId = $request->input('currencyId');

                $change_status = $request->input('isStatusChange');
                $invoiceStatus = $request->input('changeStatus');
                $reason = $request->input('rejectReason');

                $CompanyAddressID = 1;
                $PaymentDetailsID = 1;

                //line item
                $lineItemArray = [];
                for ($i = 0; $i < count($lineItem); $i++) {

                    $ITEM_DISPLAY_NAME = NULL;

                    // get invoice item isplay name
                    $serviceItemQuery = DB::table('fin_service_items AS fsi')
                            ->where('fsi.SERVICE_ITEM_ID', $lineItem[$i]['lineItemId'])
                            ->select('ITEM_DISPLAY_NAME');
                    if ($serviceItemQuery->count() > 0) {
                        $getServiceItemName = $serviceItemQuery->first();
                        if (!empty($getServiceItemName->ITEM_DISPLAY_NAME)) {
                            $ITEM_DISPLAY_NAME = $getServiceItemName->ITEM_DISPLAY_NAME;
                        }
                    }
                    //

                    $lineItemTempArray = [];
                    $lineItemTempArray['SERVICE_GROUP_ID'] = $lineItem[$i]['serviceGroupId'];
                    $lineItemTempArray['SERVICE_GROUP_NAME'] = $lineItem[$i]['serviceGroupName'];
                    $lineItemTempArray['SERVICE_ITEM_ID'] = $lineItem[$i]['lineItemId'];
                    $lineItemTempArray['ACCOUNT_CODE'] = $lineItem[$i]['accountCode'];
                    $lineItemTempArray['ITEM_CODE'] = $lineItem[$i]['itemCode'];
                    $lineItemTempArray['ITEM_DESCRIPTION'] = $lineItem[$i]['description'];
                    $lineItemTempArray['CLIENT_ITEM_CODE'] = NULL;
                    $lineItemTempArray['CLENT_ITEM_DESCRIPTION'] = $ITEM_DISPLAY_NAME;
                    $lineItemTempArray['RATE_FIELD'] = $lineItem[$i]['rateField'];

                    if ($lineItemTempArray['RATE_FIELD'] == 1) {
                        $lineItemTempArray['UNIT_QTY'] = $lineItem[$i]['unitQty'];
                        $lineItemTempArray['UNIT_ENUM_ID'] = $lineItem[$i]['unitType'];
                        $lineItemTempArray['QTY'] = $lineItem[$i]['qty'];
                    } else {
                        $lineItemTempArray['UNIT_QTY'] = $lineItemTempArray['UNIT_ENUM_ID'] = $lineItemTempArray['QTY'] = null;
                    }

                    $lineItemTempArray['RATE'] = $lineItem[$i]['price'];
                    $lineItemTempArray['AMOUNT'] = $lineItem[$i]['total'];

                    if (isset($change_status) && $change_status > 0) {
                        if ($invoiceStatus == $change_status) {
                            $lineItemTempArray['ITEM_REMARK'] = NULL;
                        } else {
                            $lineItemTempArray['ITEM_REMARK'] = $lineItem[$i]['lineItemRemark'];
                            if (!empty($lineItem[$i]['lineItemRemark'])) {
                                $reason .= ' ' . $lineItem[$i]['lineItemRemark'];
                            }
                        }
                    } else {
                        $lineItemTempArray['ITEM_REMARK'] = $lineItem[$i]['lineItemRemark'];
                    }
                    array_push($lineItemArray, $lineItemTempArray);
                }

                // account code
                $accountCodeArray = [];
                for ($i = 0; $i < count($accountCodeTotal); $i++) {
                    $accountCodeTempArray = [];
                    $accountCodeTempArray['CODE_DESCRIPTION'] = $accountCodeTotal[$i]['accountCode'];
                    $accountCodeTempArray['AMOUNT'] = $accountCodeTotal[$i]['accountTotal'];
                    array_push($accountCodeArray, $accountCodeTempArray);
                }
                DB::beginTransaction();
                try {
                    $GetInvoiceFinalStatus = FinanceModel\InvoiceApprovalModel::where('IS_FINAL', 1)->select('REQUEST_LEVEL_ID')->first()->toArray();
                    $InvoiceFinalLevel = $GetInvoiceFinalStatus['REQUEST_LEVEL_ID'];

                    $GetInvoiceStatus = FinanceModel\InvoiceApprovalModel::where('IS_FINAL', 0)->select('REQUEST_LEVEL_ID')->orderBy('ORDER_SEQ', 'desc')->take(2)->get()->toArray();
                    $InvoiceApprovedLevel = $GetInvoiceStatus[1]['REQUEST_LEVEL_ID'];



                    $project = FinanceModel\JobModel::where('JOB_ID', $projectId)->select('SUB_CIRCLE', 'TEAM', 'CUSTOMER_DIVISION_ID')->first();

                    $billToAddress = FinanceModel\CustomerAddressModel::find($billTo)->toJson();
                    $billToAddress = json_decode($billToAddress);

                    $currencyDetails = FinanceModel\CurrencyEnumModel::find($currencyId);

                    $paymentDetails = FinanceModel\PaymetDetailsModel::find($PaymentDetailsID)->toJson();
                    $CompanyAddress = FinanceModel\CompanyAddressModel::find($CompanyAddressID)->toJson();

                    $invoice = FinanceModel\InvoiceModel::find($invoiceId);
                    $invoice->INVOICE_TITLE = $projectName;
                    $invoice->COMPANY_ADDRESS_ID = $CompanyAddressID;
                    $invoice->JOB_ID = $projectId;
                    $invoice->JOB_TITLE = $projectName;
                    $invoice->CLUSTER_ID = $project->SUB_CIRCLE;
                    $invoice->TEAM_ID = $project->TEAM;
                    $invoice->CLIENT_ID = $clientId;
                    $invoice->CLIENT_DIVISION_ID = $project->CUSTOMER_DIVISION_ID;
                    $invoice->CLIENT_ADDRESS_ID = $billTo;
                    $invoice->PAYMENT_DETAILS_ID = $PaymentDetailsID;
                    $invoice->CURRENCY_ID = $currencyId;
                    $invoice->CURRENCY_NAME = $currencyDetails->NAME;
                    $invoice->CURRENCY_SYMBOL = $currencyDetails->SYMBOL;
                    $invoice->SUB_TOTAL = $subTotal;
                    $invoice->TOTAL = $subTotal;
                    $invoice->FINAL_TOTAL = $finalTotal;

                    //tax
                    $clientCountry = $billToAddress->COUNTRY;
                    $indiaId = 4;
                    if ($clientCountry == $indiaId && ($clientState == 'TN' || $clientState == 'TAMIL NADU' || $clientState == 'TAMILNADU')) { // 4=india
                        $invoice->CGST_TAX_FIELD = 'CGST @9%';
                        $invoice->CGST_TAX_AMOUNT = $igstDomesticCentralTax;
                        $invoice->SGST_TAX_FIELD = 'SGST @9%';
                        $invoice->SGST_TAX_AMOUNT = $igstDomesticStateTax;
                        $invoice->TOTAL_TAX_FIELD = 'Total Tax @18%';
                        $invoice->TOTAL_TAX_AMOUNT = $igstDomesticTotalTax;
                    } else if ($clientCountry == $indiaId && $clientState != 'TN' && $clientState != 'TAMIL NADU' && $clientState != 'TAMILNADU') {
                        $invoice->IGST_TAX_FIELD = 'IGST @18%';
                        $invoice->IGST_TAX_AMOUNT = $igstDomesticTax;
                    } else if ($clientCountry != $indiaId) {
                        $invoice->IGST_TAX_FIELD = 'IGST @0%';
                        $invoice->IGST_TAX_AMOUNT = 0;
                    }
                    //


                    if (isset($change_status) && $change_status > 0 && ($invoiceStatus == $change_status)) {

                        $invoice->CURRENT_STATUS = $invoiceStatus;

                        if ($InvoiceApprovedLevel == $invoiceStatus) { // invoice approved
                            $Prefix = FinanceModel\PrefixEnumModel::where('PREFIX_ENUM_ID', 5)->where('IS_ACTIVE', 1)->first()->toArray(); //5=invoice
                            $refPrefix = $Prefix['PREFIX_NAME'] . str_pad($Prefix['STARTING_VALUE'], 4, 0, STR_PAD_LEFT);
                            $invoice->REF_PREFIX = $refPrefix;
                            $invoice->INVOICE_DATE = $this->dateTime;
                        }

                        if ($InvoiceFinalLevel == $invoiceStatus) { // despatch
                            $invoice->IS_COMPLETED = 1;
                        }
                    }

                    $IS_REQUEST_LEVEL_REJECT = $invoice->IS_REQUEST_LEVEL_REJECT;
//                    //rejected status revert in first update
//                    if ($IS_REQUEST_LEVEL_REJECT == 1) {
//                        $invoice->IS_REQUEST_LEVEL_REJECT = 0;
//                    }
                    //approval level reject
                    if (isset($change_status) && $change_status > 0) {
                        if ($invoiceStatus == $change_status) {
                            $invoice->IS_REQUEST_LEVEL_REJECT = 0;
                        } else { // reject
                            $invoice->IS_REQUEST_LEVEL_REJECT = 1;

                            if ($invoice->REF_PREFIX == null && trim($invoice->REF_PREFIX) == '') {
                                $invoice->CURRENT_STATUS = 0;
                            }
                        }
                    }


                    $invoice->INVOICE_TYPE = $invoiceType;
                    $invoice->LAST_MOD_BY = $this->loginUserId;
                    $invoice->LAST_MOD_DATE = $this->dateTime;
                    $invoice->save();

                    // Project Closed - if final invoice
                    if ($invoiceType == 1 || $invoiceType == 3) {
                        if (isset($change_status) && $change_status > 0 && ($invoiceStatus == $change_status)) {
                            if ($InvoiceApprovedLevel == $invoiceStatus) { // invoice approved
                                $remarksTxt = 'Closed:' . 'Final Invoice Approved ref.' . $invoiceId . ' ##' . $this->loginUserId . ',' . strtotime($this->dateTime) . '<>';

                                $JobUpdate = FinanceModel\JobModel::find($invoice->JOB_ID);
                                $JobUpdate->STATUS = 2; //2-closed 
                                $JobUpdate->IS_INVOICED = 1;
                                $JobUpdate->REMARKS = $JobUpdate->REMARKS . $remarksTxt;
                                $JobUpdate->LAST_MOD_BY = $this->loginUserId;
                                $JobUpdate->LAST_MOD_DATE = $this->dateTime;
                                $JobUpdate->save();
                            }
                        }
                    }


                    // update invoice starting id - 
                    if (isset($change_status) && $change_status > 0 && ($InvoiceApprovedLevel == $invoiceStatus)) {
                        $PrefixUpdate = FinanceModel\PrefixEnumModel::find(5);
                        $PrefixUpdate->STARTING_VALUE = $Prefix['STARTING_VALUE'] + 1;
                        $PrefixUpdate->save();
                    }

                    //approval log
                    if (isset($change_status) && $change_status > 0) {
                        $statusLog = [];
                        $statusLog['INVOICE_ID'] = $invoiceId;
                        $statusLog['REQUEST_LEVEL_ID'] = $change_status;
                        $statusLog['USER_ID'] = $this->loginUserId;

                        if ($invoiceStatus == $change_status) {
                            $statusLog['IS_APPROVE'] = 1;
                        } else {
                            $statusLog['IS_APPROVE'] = 0;
                        }

                        $statusLog['CREATED_DATE'] = $this->dateTime;
                        $statusLog['CREATED_BY'] = $this->loginUserId;
                        $statusLog['REMARKS'] = $reason;
                        $statusLog['IS_ACTIVE'] = 1;
                        DB::table('fin_invoice_approval_log')->insert($statusLog);
                    }


                    // invoice ref 
                    $invoiceRef = [];
                    $invoiceRef['INVOICE_ID'] = $invoiceId;
                    $invoiceRef['AUTHOR'] = $author;
                    $invoiceRef['ISBN'] = $isbn;
                    $invoiceRef['ORDER_NO'] = $orderNo;
                    $invoiceRef['PSP_ELEMENT'] = $pspElement;
                    $invoiceRefUpdate = DB::table('fin_invoice_ref')->where('INVOICE_ID', $invoiceId)->update($invoiceRef);

                    // services item mapping 
                    DB::table('fin_invoice_items')->where('INVOICE_ID', $invoiceId)->delete();
                    foreach ($lineItemArray as &$item) {
                        $item['INVOICE_ID'] = $invoiceId;
                    }
                    $lineItemInsert = DB::table('fin_invoice_items')->insert($lineItemArray);

                    // account code group
                    DB::table('fin_invoice_account_code')->where('INVOICE_ID', $invoiceId)->delete();
                    if (count($accountCodeArray) > 0) {
                        foreach ($accountCodeArray as &$item) {
                            $item['INVOICE_ID'] = $invoiceId;
                        }
                    }
                    $accountCodeInsert = DB::table('fin_invoice_account_code')->insert($accountCodeArray);

                    // invoice billing address mapping
                    DB::table('fin_invoice_billing_address')->where('INVOICE_ID', $invoiceId)->delete();
                    if (count($billToAddress) > 0) {

                        $billToInsert = [];
                        $billToInsert['INVOICE_ID'] = $invoiceId;
                        $billToInsert['CUSTOMER_ADDRESS_ID'] = $billToAddress->CUSTOMER_ADDRESS_ID;
                        $billToInsert['CONTACT_NAME'] = $kindAttn;
                        $billToInsert['ADDRESS_LINE_1'] = $billToAddress->ADDRESS_LINE_1;
                        $billToInsert['ADDRESS_LINE_2'] = $billToAddress->ADDRESS_LINE_2;
                        $billToInsert['ADDRESS_LINE_3'] = $billToAddress->ADDRESS_LINE_3;
                        $billToInsert['PHONE'] = $phone;
                        $billToInsert['FAX'] = $billToAddress->FAX;
                        $billToInsert['CITY'] = $billToAddress->CITY;
                        $billToInsert['STATE'] = $billToAddress->STATE;
                        $billToInsert['COUNTRY'] = $billToAddress->COUNTRY;
                        $billToInsert['ZIP'] = $billToAddress->ZIP;
                        $billToInsert['EMAIL_ID'] = $billToAddress->EMAIL_ID;

                        DB::table('fin_invoice_billing_address')->insert($billToInsert);
                    }

                    // invoice_company_address mapping
                    DB::table('fin_invoice_company_address')->where('INVOICE_ID', $invoiceId)->delete();
                    $getCompanyAddressData = json_decode($CompanyAddress);
                    if (count($getCompanyAddressData) > 0) {

                        $companyAddressDataInsert = [];
                        $companyAddressDataInsert['COMPANY_ADDRESS_ID'] = $getCompanyAddressData->COMPANY_ADDRESS_ID;
                        $companyAddressDataInsert['INVOICE_ID'] = $invoiceId;
                        $companyAddressDataInsert['COMPANY_NAME'] = $getCompanyAddressData->COMPANY_NAME;
                        $companyAddressDataInsert['ADDRESS_LINE1'] = $getCompanyAddressData->ADDRESS_LINE1;
                        $companyAddressDataInsert['ADDRESS_LINE2'] = $getCompanyAddressData->ADDRESS_LINE2;
                        $companyAddressDataInsert['ADDRESS_LINE3'] = $getCompanyAddressData->ADDRESS_LINE3;
                        $companyAddressDataInsert['CITY'] = $getCompanyAddressData->CITY;
                        $companyAddressDataInsert['STATE'] = $getCompanyAddressData->STATE;
                        $companyAddressDataInsert['ZIP'] = $getCompanyAddressData->ZIP;
                        $companyAddressDataInsert['COUNTRY'] = $getCompanyAddressData->COUNTRY;
                        $companyAddressDataInsert['PHONE'] = $getCompanyAddressData->PHONE;
                        $companyAddressDataInsert['EMAIL_ID'] = $getCompanyAddressData->EMAIL_ID;
                        $companyAddressDataInsert['FAX'] = $getCompanyAddressData->FAX;
                        $companyAddressDataInsert['OTHER'] = $getCompanyAddressData->OTHER;
                        $companyAddressDataInsert['FINANCE_CONTACT'] = $getCompanyAddressData->FINANCE_CONTACT;
                        $companyAddressDataInsert['CIN'] = $getCompanyAddressData->CIN;
                        $companyAddressDataInsert['GSTIN'] = $getCompanyAddressData->GSTIN;
                        $companyAddressDataInsert['SAC_CODE'] = $getCompanyAddressData->SAC_CODE;

                        DB::table('fin_invoice_company_address')->insert($companyAddressDataInsert);
                    }

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['invoiceID'] = $invoiceId;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }

            $InvoiceCurrentStatus = DB::table('fin_invoice AS i')
                    ->leftJoin('fin_request_level AS qs', 'qs.REQUEST_LEVEL_ID', '=', 'i.CURRENT_STATUS')
                    ->where('i.INVOICE_ID', $invoiceId)
                    ->select(DB::raw('qs.LEVEL_NAME,qs.REQUEST_LEVEL_ID,i.CURRENT_STATUS'))
                    ->first();
            // Email Notification
            if ($Response['status'] == 1 && $this->CONSTANT['INVOICE_EMAIL_NOTIFICATION'] == true) {
                if (isset($change_status) && $change_status > 0) {
                    if ($statusLog['IS_APPROVE'] == 0 && $InvoiceCurrentStatus->CURRENT_STATUS == 0) {
                        $GetNextLevel = FinanceModel\InvoiceApprovalModel::select('LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();
                    } else if ($statusLog['IS_APPROVE'] == 0 && $InvoiceCurrentStatus->CURRENT_STATUS > 0) {
                        $GetNextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $InvoiceCurrentStatus->REQUEST_LEVEL_ID)->select('LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->first();
                    }
                    $statusAction = ($statusLog['IS_APPROVE'] == 1) ? ' Approved  ' . $InvoiceCurrentStatus->LEVEL_NAME : 'Reject  ' . $GetNextLevel->LEVEL_NAME;
                    $this->InvoiceUpdateEmailNotify($invoiceId, $statusAction);
                } else if ($IS_REQUEST_LEVEL_REJECT == 1) {
                    $this->InvoiceUpdateEmailNotify($invoiceId, '');
                }
            }
            //
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }


        return response()->json($Response);
    }

    //cancel invoice
    public function ajaxCancelInvoice(Request $request) {
        exit;
        $role = $this->permissionCheck(array('AL', 'FIN', 'PM'));
        $cancelReason = $request->input('cancelReason');
        $InvoiceID = $request->input('cancelInvoiceID');
        $requestedByWhom = $request->input('requestedByWhom');
        $mailDate = $request->input('requestedDate');
        $this->loginUserId = Session::get('users.user_id');

        /*
          $IfPartialInvoice = FinanceModel\InvoiceModel::where('INVOICE_ID', $InvoiceID)->where('INVOICE_TYPE', 2)->where('IS_ACTIVE', 1)->where('IS_CANCELLED', 0)->selectRaw("PARTIAL_INVOICE_SNO,QUOTATION_ID,JOB_ID")->first();

          if (count($IfPartialInvoice) > 0) {
          $IfNextPartialInvoiceGenerated = FinanceModel\InvoiceModel::where('JOB_ID', $IfPartialInvoice->JOB_ID)->where('PARTIAL_INVOICE_SNO', '>', $IfPartialInvoice->PARTIAL_INVOICE_SNO)->where('INVOICE_TYPE', 2)->where('IS_ACTIVE', 1)->where('IS_CANCELLED', 0)->selectRaw("INVOICE_ID")->first();
          //checking next partial invoice generated based on quote id
          if (count($IfNextPartialInvoiceGenerated) > 0) {
          $Response['status'] = 0;
          $Response['msg'] = 'Not able cancel this invoice...';
          return response()->json($Response);
          exit;
          }
          }
         * 
         */

        if ($InvoiceID <= 0) {
            $Response['status'] = 0;
            $Response['msg'] = 'Validation Error';
        } else {

            DB::beginTransaction();
            try {
                $Invoice = FinanceModel\InvoiceModel::find($InvoiceID);
                $Invoice->IS_CANCELLED = 1;
                $Invoice->CANCELLED_BY = $this->loginUserId;
                $Invoice->CANCELLED_REASON = $cancelReason;
                $Invoice->CANCELLED_DATE = $this->dateTime;
                $Invoice->CANCELLED_BY_WHOM = $requestedByWhom;
                $Invoice->CANCELLED_MAIL_DATE = $mailDate;
                $Invoice->save();

                if ($Invoice->INVOICE_TYPE == 1 || $Invoice->INVOICE_TYPE == 3) { //final invoice
                    $InvoiceProjectID = [];
                    $InvoiceProjectID[] = $Invoice->JOB_ID;

                    $remarksTxt = 'Open:' . 'Final Invoice Cancelled.' . $InvoiceID . ' ##' . $this->loginUserId . ',' . strtotime($this->dateTime) . '<>';
                    foreach ($InvoiceProjectID as $IPID) {
                        $JobUpdate = FinanceModel\JobModel::find($IPID);
                        $JobUpdate->STATUS = 1; //2-online 
                        $JobUpdate->IS_INVOICED = 0;
                        $JobUpdate->REMARKS = $JobUpdate->REMARKS . $remarksTxt;
                        $JobUpdate->LAST_MOD_BY = $this->loginUserId;
                        $JobUpdate->LAST_MOD_DATE = $this->dateTime;
                        $JobUpdate->save();
                    }
                }


                DB::commit();
                $Response['status'] = 1;
                $Response['Msg'] = 'Invoice Cancelled';
                // all good
            } catch (\Exception $e) {
                DB::rollback();
                $Response['status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['ErrorMsg'] = $e->getMessage();
            }
        }


        // Start Notification
        // Email Notification
        if ($Response['status'] == 1 && $this->CONSTANT['INVOICE_EMAIL_NOTIFICATION'] == true) {
            $this->InvoiceUpdateEmailNotify($InvoiceID, 'CANCELLED ');
        }
        // end Notification

        return response()->json($Response);
    }

    //delete invoice
    public function ajaxDeleteInvoice(Request $request) {
        exit;
        $role = $this->permissionCheck(array('AL', 'FIN', 'PM'));

        $deleteReason = $request->input('deleteReason');
        $InvoiceID = $request->input('deleteInvoiceID');
        $this->loginUserId = Session::get('users.user_id');

        if ($InvoiceID <= 0) {
            $Response['status'] = 0;
            $Response['msg'] = 'Validation Error';
        } else {

            DB::beginTransaction();
            try {
                $Invoice = FinanceModel\InvoiceModel::find($InvoiceID);
                $Invoice->IS_ACTIVE = 0;
                $Invoice->DELETE_REASON = $deleteReason;
                $Invoice->LAST_MOD_BY = $this->loginUserId;
                $Invoice->LAST_MOD_DATE = $this->dateTime;
                $Invoice->save();

                DB::commit();
                $Response['status'] = 1;
                $Response['Msg'] = 'Invoice Cancelled';
                // all good
            } catch (\Exception $e) {
                DB::rollback();
                $Response['status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['ErrorMsg'] = $e->getMessage();
            }
        }


        // Start Notification
        // Email Notification
        if ($Response['status'] == 1 && $this->CONSTANT['INVOICE_EMAIL_NOTIFICATION'] == true) {
            $this->InvoiceUpdateEmailNotify($InvoiceID, 'CANCELLED ');
        }
        // end Notification

        return response()->json($Response);
    }

    public function getInvoiceDetails(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        $this->loginUserId = Session::get('users.user_id');
        if ($request->input()) {

            $validationArray = [];
            $validationArray['invoiceId'] = 'required|numeric|min:2';
            $validator = Validator::make($request->all(), $validationArray);

            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['msg'] = 'Validation Error';
                $Response['errMsg'] = $validator->errors();
            } else {
//                $sFilter = [2, 3, 4, 5];
                $invoiceId = $request->input('invoiceId');

                $invoice = FinanceModel\InvoiceModel::where('INVOICE_ID', $invoiceId)->where('IS_ACTIVE', 1)->with(array('invoiceStatus', 'invoiceStatusName', 'InvoiceRef', 'InvoiceItems', 'Customer', 'CustomerDivision', 'customerBillingAddress', 'InvoiceBillingAddress', 'Cluster', 'Team', 'createdBy', 'updatedBy', 'cancelledBy', 'project'))->first();
//                $nextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $invoice->CURRENT_STATUS)->whereIn('REQUEST_LEVEL_ID', $sFilter)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();
                $nextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $invoice->CURRENT_STATUS)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();
                $Response['status'] = 1;
                $Response['msg'] = 'Success';
                $Response['data'] = $invoice;
                $Response['data']['invoice_next_status'] = $nextLevel;
                $Response['data']['approval_tracking'] = $this->ajaxGetInvoiceStatus($invoiceId);
                $Response['data']['invoice_status_label'] = $this->CONSTANT['INVOICE_STATUS_LABEL'][$invoice->CURRENT_STATUS];

                if ($invoice->CURRENT_STATUS == 0 && ( ($role == 'PM' || $role == 'ADMIN') || ( $role == 'AM' && $this->loginUserId == $invoice->CREATED_BY ) )) {
                    $Response['data']['disableItemfields'] = false;
                } else {
                    $Response['data']['disableItemfields'] = true;
                }
            }
            return response()->json($Response);
        }
    }

    // Get invoice status search by InvoiceID
    public function ajaxGetInvoiceStatus($ID) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        $StatusList = DB::table('fin_invoice_approval_log')
                ->join('user', 'user.USER_ID', '=', 'fin_invoice_approval_log.CREATED_BY')
                ->join('fin_request_level', 'fin_request_level.REQUEST_LEVEL_ID', '=', 'fin_invoice_approval_log.REQUEST_LEVEL_ID')
                ->where('fin_invoice_approval_log.INVOICE_ID', $ID)
                ->select('fin_invoice_approval_log.*', DB::raw('employeename(user.first_name, user.middle_name,user.last_name) AS NAME'), 'fin_request_level.LEVEL_NAME')
                ->orderBy('INVOICE_APPROVAL_LOG_ID', 'asc')
                ->get();

        if (count($StatusList) > 0) {
            $LastLevelIndex = count($StatusList) - 1;
            $LastApprovalStatus = $StatusList[$LastLevelIndex]->IS_APPROVE;
            $LastRequestLevel = $StatusList[$LastLevelIndex]->REQUEST_LEVEL_ID;
        }

        $GetInvoiceStatus = FinanceModel\InvoiceModel::select(array('INVOICE_ID', 'CURRENT_STATUS'))->where('INVOICE_ID', $ID)->first()->toArray();
        $InvoiceCurrentStatus = $GetInvoiceStatus['CURRENT_STATUS'];

        $InvoiceLevel = FinanceModel\InvoiceApprovalModel::where(array('REQUEST_MASTER_ID' => 2, 'IS_ACTIVE' => 1))->orderBy('ORDER_SEQ', 'asc')->get()->toArray();
        $stepCount = count($InvoiceLevel) + 1;

        $LevelTracking = '<ol class="progtrckr" data-progtrckr-steps="' . $stepCount . '">
                          <li class="progtrckr-done"><span>Generated</span> </li>';
        foreach ($InvoiceLevel as $IL) {
            $st = 'progtrckr-todo';
            if ($IL['REQUEST_LEVEL_ID'] <= $InvoiceCurrentStatus) {
                $st = 'progtrckr-done';
            }
            if (count($StatusList) > 0 && $LastApprovalStatus == 0 && $IL['REQUEST_LEVEL_ID'] == $LastRequestLevel) { // reject
                $st = 'progtrckr-todo reject-level';
            }
            $LevelTracking .= '<li class="' . $st . '"><span>' . $IL['LEVEL_NAME'] . '</span> </li>';
        }
        $LevelTracking .= '</ol>';
        $Response['LevelTracking'] = $LevelTracking;
        $Response['status'] = 1;
        $Response['StatusList'] = $StatusList;
        return $Response;
    }

    public function pdf($invoiceID, $pdfType = 0, $rowAdjustment = 10) {


        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));

        $Invoice = FinanceModel\InvoiceModel::where('INVOICE_ID', $invoiceID)->where('IS_ACTIVE', 1)->with(array('invoiceStatus', 'invoiceStatusName', 'InvoiceRef', 'InvoiceItems', 'InvoiceAccountCode', 'Customer', 'CustomerDivision', 'InvoiceBillingAddress', 'serviceItems'))->first();
        if (count($Invoice) == 0) {
            return redirect('fin/invoice/list');
            die('No Invoice Found');
        }

        if ($Invoice->IS_ACTIVE == 0) {
            return redirect('fin/invoice/list');
            die('Invoice Deleted');
        }
        $nextLevel = FinanceModel\InvoiceApprovalModel::where('REQUEST_LEVEL_ID', '>', $Invoice->CURRENT_STATUS)->select('REQUEST_LEVEL_ID', 'LEVEL_NAME')->orderBy('ORDER_SEQ', 'asc')->limit(1)->first();


        if (count($Invoice['InvoiceItems']) == 0) {
            return redirect('fin/invoice/list');
            die('No line item Found');
        }

        $collection = collect($Invoice['InvoiceItems']);
        $chunks = $collection->chunk($rowAdjustment);
        $lineItem = $chunks->toArray();



//        echo '<pre>';
//        print_r($lineItem);
//        exit;

        $data = [];
        $data['invoice'] = $Invoice;
        $data['lineItem'] = $lineItem;
        $data['invoice_next_status'] = $nextLevel;
        $data['invoice_status_label'] = $this->CONSTANT['INVOICE_STATUS_LABEL'][$Invoice->CURRENT_STATUS];


        if ($Invoice->REF_PREFIX != null && trim($Invoice->REF_PREFIX) != '') {
            $pageTitle = 'Invoice_' . $Invoice->REF_PREFIX;
        } else {
            $pageTitle = 'Project_' . $Invoice->JOB_ID;
        }

        $data['pageTitle'] = $pageTitle;
        $data['invoice'] = $Invoice;
        $data['totalAmtText'] = app('App\Http\Controllers\finance\master\NumberFormatController')->convertNumber($Invoice->FINAL_TOTAL);
        $data['rowAdjustment'] = round(200 / $rowAdjustment);

        $pdf = PDF::loadView('finance.invoice.springerPdfView', $data);
//        $pdf = PDF::loadView('finance.invoice.testPdf', $data);
//        $pdf->setOptions(['isPhpEnabled'=>true]);
        if ($pdfType == 0) {

//            $dom_pdf = $pdf->getDomPDF();
//            $canvas = $dom_pdf->get_canvas();
//            $canvas->page_text(0, 0, "Page {PAGE_NUM} of {PAGE_COUNT}", null, 10, array(0, 0, 0));

            return $pdf->stream();
        } else if ($pdfType == 1) {
            return $pdf->download($pageTitle . '_invoice.pdf');
        }
    }

    public function getInvoiceEstdQty(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));

        if ($request->input()) {

            $validator = Validator::make($request->all(), [
                        'jobId' => 'required|numeric|min:2',
            ]);

            $Response = [];
            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {

                try {
                    $projectId = $request->input('jobId');

                    $serviceItemId = [];
                    $serviceItemSrc = 'PRICING_GRID';
                    $postType = $request->input('postType');

                    if (trim($request->input('serviceItemId')) != '' && $request->input('serviceItemId') > 0) {
                        $serviceItemId[] = $request->input('serviceItemId');

                        if ($request->input('serviceItemSrc') == 2) {
                            $serviceItemSrc = 'EXTRA_ITEM';
                        }
                    }


                    $jobSelect = array('job.JOB_ID',
                        'job.JOB_TITLE',
                        'job.CUSTOMER_ID',
                        'job.CUSTOMER_DIVISION_ID',
                        'job.TEAM',
                        'ji.AUTHOR_NAME',
                        'ji.PRODUCTION_EDITOR',
                        'ji.PURCHASE_ORDER_NUMBER',
                        'ji.COPY_EDITING_LEVEL',
                        'ji.PRODUCTION_CLASSIFICATION',
                        'ji.ISSN_PRINT',
                    );

                    $project = FinanceModel\JobModel::with(array('customer', 'customerDivision', 'customerBillingAddress'))
                                    ->leftJoin('job_info AS ji', 'ji.JOB_ID', '=', 'job.JOB_ID')
                                    ->where('job.JOB_ID', $projectId)
                                    ->where('job.IS_ACTIVE', 1)
                                    ->select($jobSelect)->first();

                    $clientName_ItemRate = '';
                    foreach ($this->CLIENT_ITEM_RATE as $clientRateKey => $clientRateValue) {
                        if (in_array($project->CUSTOMER_ID, $clientRateValue)) {
                            $clientName_ItemRate = $clientRateKey;
                        }
                    }
					if($projectId 	==	6807){
						$clientName_ItemRate 	=	"OUP_INVOICE";
					}
                    $serviceItemRateId = $estdQty = $clientName_Fields = $projectType = [];

                    $autoQtyError = 0;
                    $autoErrorMsg = '';

					// get compsition category and ce-level
					$clientName_Fields['COMPOSITION_TYPE'] = 0;
					$clientName_Fields['CE_TYPE'] = 0;
                    // get Estimate Qty
                    if ($clientName_ItemRate == 'SPRINGER_INVOICE' && $serviceItemSrc == 'PRICING_GRID') {

                        $clientName_Fields['TRIM_TYPE_ID'] = $clientName_Fields['WORK_TYPE_ID'] = 0;

                        // get project trim type
                        if (trim($request->input('projectTrimType')) != '' && $request->input('projectTrimType') > 0) {
                            $clientName_Fields['TRIM_TYPE_ID'] = $request->input('projectTrimType');
                        } else {

                            $trimWidth = 150;
                            $trimHeight = 200;
                            $trimUnit = 'mm';

                            $trim = DB::table('fin_trim_size AS ts')
                                    ->where('ts.IS_ACTIVE', 1)
                                    ->where('ts.METRIC_UNITS', $trimUnit)
                                    ->whereRaw(' "' . $trimWidth . '" between ts.MIN_WIDTH and ts.MAX_WIDTH')
                                    ->whereRaw(' "' . $trimHeight . '" between ts.MIN_HEIGHT and ts.MAX_HEIGHT')
                                    ->get();
                            if (count($trim) != 1) {
                                $autoQtyError = 1;
                                $autoErrorMsg .= 'Trim size not matching <br>';
                            } else {
                                $clientName_Fields['TRIM_TYPE_ID'] = $trim[0]->TRIM_TYPE_ID;
                            }
                        }

                        // get project work type
                        if (trim($request->input('projectWorkType')) != '' && $request->input('projectWorkType') > 0) {
                            $clientName_Fields['WORK_TYPE_ID'] = $request->input('projectWorkType');
                        } else if ($project->TEAM == $this->CONSTANT['TEAM']['MB']) {
                            $clientName_Fields['WORK_TYPE_ID'] = $this->CONSTANT['WORK_TYPE']['COMPLEX']; // Complex Work
                        } else {

                            $pageCount = $figureCount = $tableCount = $equationCount = $boxCount = $workTypeId = 0;

                            //get page count
                            $getpageCount = DB::table('task_level_metadata AS t')->where(array('t.JOB_ID' => $projectId, 't.CURRENT_ROUND' => 120, 't.IS_ACTIVE' => 1))->select(DB::raw('SUM(t.CURRENT_QUANTITY) AS PAGE_COUNT'))->first()->PAGE_COUNT;
                            if ($getpageCount != '' && $getpageCount != null && $getpageCount > 0) {
                                $pageCount = $getpageCount;
                            }
                            //

                            if ($pageCount > 0) {
                                //get figure count
                                $getfigureCount = DB::table('task_level_art_metadata AS t')->where(array('t.JOB_ID' => $projectId, 't.IS_ACTIVE' => 1))->select('t.ART_METADATA_ID')->count();
                                $figureCount = $getfigureCount;

                                //get Table  & Equation & Box - Count
                                $otherCount = DB::table('metadata_info AS t')->join('task_level_metadata AS tm', 'tm.METADATA_ID', '=', 't.METADATA_ID')
                                                ->where(array('tm.JOB_ID' => $projectId, 'tm.IS_ACTIVE' => 1))
                                                ->select(DB::raw('SUM(t.NO_TABLES) AS TABLE_COUNT, SUM(t.NO_EQUATION)  AS EQUATION_COUNT , SUM(t.NO_BOX) AS BOX_COUNT'))->first();
                                if ($otherCount->TABLE_COUNT != '' && $otherCount->TABLE_COUNT != null && $otherCount->TABLE_COUNT > 0) {
                                    $tableCount = $otherCount->TABLE_COUNT;
                                }
                                if ($otherCount->EQUATION_COUNT != '' && $otherCount->EQUATION_COUNT != null && $otherCount->EQUATION_COUNT > 0) {
                                    $equationCount = $otherCount->EQUATION_COUNT;
                                }
                                if ($otherCount->BOX_COUNT != '' && $otherCount->BOX_COUNT != null && $otherCount->BOX_COUNT > 0) {
                                    $boxCount = $otherCount->BOX_COUNT;
                                }
                                //
                                // calculate work type
                                $calcWorkType = (($figureCount + $tableCount + $equationCount + $boxCount) / $pageCount) * 100;
                                $standardWork = 1;
                                $complexWork = 2;
                                if ($calcWorkType <= 20) {
                                    $workTypeId = $standardWork;
                                } else {
                                    $workTypeId = $complexWork;
                                }
                            } else {
                                $autoQtyError = 1;
                                $autoErrorMsg .= 'Work type not matching, Page count is ' . $pageCount . ' <br>';
                            }

                            $clientName_Fields['WORK_TYPE_ID'] = $workTypeId;
                            //
                        }



                        if (trim($project->PRODUCTION_CLASSIFICATION) != '') {
                            $categoryArray = explode("_", $project->PRODUCTION_CLASSIFICATION);
                            $category = $categoryArray[0];
                            if (isset($this->CONSTANT['SERVICE_ITEM']['CATEGORY'][$category])) {
                                $clientName_Fields['COMPOSITION_TYPE'] = $this->CONSTANT['SERVICE_ITEM']['CATEGORY'][$category];
                            }
                        }

                        if (trim($project->COPY_EDITING_LEVEL) != '') {
                            $ceLevel = $project->COPY_EDITING_LEVEL;
                            if (isset($this->CONSTANT['SERVICE_ITEM']['CE_LEVEL'][$ceLevel])) {
                                $clientName_Fields['CE_TYPE'] = $this->CONSTANT['SERVICE_ITEM']['CE_LEVEL'][$ceLevel];
                            }
                        }

                        // end get compsition category and ce-level
                        //print_r($serviceItemId); exit;

                        if ($autoQtyError == 0) {

                            $where = [];
                            $where['iq.IS_ACTIVE'] = 1;
                            $where['iq.STATUS'] = 1;
                            $where['iq.JOB_ID'] = $projectId;

                            $select = [];
                            $select[] = 'iq.ESTD_QTY';
                            $select[] = 'si.SERVICE_ITEM_ID';
                            $select[] = 'sr.SERVICE_ITEM_RATE_ID';
//                        DB::enableQueryLog();
                            $estdQty = DB::table('fin_invoice_estd_qty AS iq')
                                    ->join('fin_lineitem_stage_map AS lm', function ($query) use($project) {
                                        return $query->on('iq.ROUND_ID', '=', 'lm.ROUND_ID')
                                                ->on('iq.STAGE_ID', '=', 'lm.STAGE_ID')
                                                ->where('lm.CUSTOMER_ID', $project->CUSTOMER_ID)
                                                ->where('lm.IS_ACTIVE', 1);
                                    })
                                    ->join('fin_service_items AS si', 'si.SERVICE_ITEM_ID', '=', 'lm.SERVICE_ITEM_ID')
                                    ->leftJoin('fin_service_item_rate AS sr', function ($query) use($project, $clientName_Fields) {
                                        return $query->on('sr.SERVICE_ITEM_ID', '=', 'si.SERVICE_ITEM_ID')
                                                ->where('sr.CUSTOMER_ID', $project->CUSTOMER_ID)
                                                ->where(function ($query) use ($clientName_Fields) {
                                                    if ($clientName_Fields['TRIM_TYPE_ID'] > 0 && $clientName_Fields['WORK_TYPE_ID'] > 0) {
                                                        return $query->where('sr.TRIM_TYPE_ID', $clientName_Fields['TRIM_TYPE_ID'])
                                                                ->where('sr.WORK_TYPE_ID', $clientName_Fields['WORK_TYPE_ID']);
                                                    }
                                                })
                                                ->where('sr.IS_ACTIVE', 1)
                                                ->whereRaw(' "' . $this->date . '" between date(sr.START_DATE) and date(sr.END_DATE)');
                                    })
                                    ->where(function ($query) use ($serviceItemId) {
                                        if (count($serviceItemId) > 0) {
                                            return $query->whereIn('si.SERVICE_ITEM_ID', $serviceItemId);
                                        }
                                    })
                                    ->where($where)
                                    ->select($select)
                                    ->get();
//                            $queries = DB::getQueryLog();
                            // print_r($queries);    exit;      

                            if (count($estdQty) > 0) {
                                foreach ($estdQty as $eQ) {
                                    if ($eQ->SERVICE_ITEM_RATE_ID > 0) {
                                        $serviceItemRateId[] = $eQ->SERVICE_ITEM_RATE_ID;
                                    }
                                }
                            }
                        }
                    }
                    // end


                    $lineItemQuantity = [];
                    if (count($serviceItemRateId) > 0) {
                        foreach ($estdQty as $eQ) {
                            $lineItemQuantity[$eQ->SERVICE_ITEM_ID] = $eQ->ESTD_QTY;
                            $serviceItemId[] = $eQ->SERVICE_ITEM_ID;
                        }
                    }


                    // get quote template line items
                    $getQuoteItems = DB::table('fin_quote_template AS qt')->join('fin_quote_template_items AS qti', 'qti.QUOTE_TEMPLATE_ID', '=', 'qt.QUOTE_TEMPLATE_ID')
                            ->where(array('qt.TEAM_ID' => $project->TEAM, 'qt.IS_ACTIVE' => 1, 'qti.IS_ACTIVE' => 1))
                            ->select('qti.SERVICE_ITEM_ID')
                            ->get();


                    $quoteServiceItemId = [];
                    if (count($getQuoteItems) > 0) {
                        foreach ($getQuoteItems as $quoteItem) {
                            if (!array_key_exists($quoteItem->SERVICE_ITEM_ID, $lineItemQuantity)) {
                                $lineItemQuantity[$quoteItem->SERVICE_ITEM_ID] = 0;
                                if (!in_array($quoteItem->SERVICE_ITEM_ID, $serviceItemId)) {
                                    $quoteServiceItemId[] = $quoteItem->SERVICE_ITEM_ID;
                                }
                            }
                        }
                    }

                    if ($serviceItemSrc == 'PRICING_GRID') {
                        $quoteServiceItemId[] = $clientName_Fields['COMPOSITION_TYPE'];
                        $quoteServiceItemId[] = $clientName_Fields['CE_TYPE'];
                        // merge extra line item based on job
                        if (!array_key_exists($clientName_Fields['COMPOSITION_TYPE'], $lineItemQuantity)) {
                            $lineItemQuantity[$clientName_Fields['COMPOSITION_TYPE']] = 0;
                        }
                        if (!array_key_exists($clientName_Fields['CE_TYPE'], $lineItemQuantity)) {
                            $lineItemQuantity[$clientName_Fields['CE_TYPE']] = 0;
                        }
                    }



                    //
                    $where2 = [];
                    $where2['si.IS_ACTIVE'] = 1;

                    $select2 = [];
                    $select2[] = 'si.SERVICE_ITEM_ID';
                    $select2[] = 'si.ITEM_NAME';
                    $select2[] = 'si.ITEM_CODE';
                    $select2[] = 'si.RATE_FIELD';
                    $select2[] = 'si.ACCOUNT_CODE';
                    $select2[] = 'si.ITEM_SRC';
                    $select2[] = 'sr.UNIT_ENUM_ID';
                    $select2[] = 'sr.RATE';
                    $select2[] = 'sg.SECTION_NAME';
                    $select2[] = 'sg.SERVICE_GROUP_ID';

//                    DB::enableQueryLog();
                    // get quote template
                    $getQuoteTempItems = DB::table('fin_service_items AS si')
                            ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                            ->leftJoin('fin_service_item_rate AS sr', function ($query) {
                                return $query->on('sr.SERVICE_ITEM_ID', '=', 'si.SERVICE_ITEM_ID')
                                        ->where('sr.IS_ACTIVE', 1);
                            })
                            ->where(function ($query) use ($quoteServiceItemId, $postType) {
                                if (count($quoteServiceItemId) > 0 && $postType == 'ALL_MAPPED_LINE_ITEM') {
                                    return $query->whereIn('si.SERVICE_ITEM_ID', $quoteServiceItemId);
                                } else {
                                    $query->where('si.SERVICE_ITEM_ID', 0);
                                }
                            })
                            ->where(function ($query) use ($clientName_ItemRate, $clientName_Fields, $project, $serviceItemSrc) {
                                if ($clientName_ItemRate == 'SPRINGER_INVOICE' && $serviceItemSrc == 'PRICING_GRID') {

                                    return $query->where('sr.CUSTOMER_ID', $project->CUSTOMER_ID)
                                            ->where('sr.CUSTOMER_DIVISION_ID', $project->CUSTOMER_DIVISION_ID)
                                            ->where(function ($query) use ($clientName_Fields) {
                                                if ($clientName_Fields['TRIM_TYPE_ID'] > 0 && $clientName_Fields['WORK_TYPE_ID'] > 0) {
                                                    return $query->where('sr.TRIM_TYPE_ID', $clientName_Fields['TRIM_TYPE_ID'])
                                                            ->where('sr.WORK_TYPE_ID', $clientName_Fields['WORK_TYPE_ID']);
                                                }
                                            })
                                            ->whereRaw(' "' . $this->date . '" between date(sr.START_DATE) and date(sr.END_DATE)');
                                }
                            })
                            ->when('sr.SERVICE_ITEM_ID', function ($query) use ($clientName_ItemRate, $clientName_Fields, $serviceItemSrc) {
                                if ($clientName_ItemRate == '' && count($clientName_Fields) == 0) {
                                    return $query->groupBy('sr.SERVICE_ITEM_ID');
                                } else if ($clientName_ItemRate == 'SPRINGER_INVOICE' && $serviceItemSrc == 'PRICING_GRID' && ( $clientName_Fields['TRIM_TYPE_ID'] == 0 || $clientName_Fields['WORK_TYPE_ID'] == 0)) {
                                    return $query->groupBy('sr.SERVICE_ITEM_ID');
                                }
                            })
                            ->where($where2)
                            ->select($select2);

                    // get line items
                    $lineItem = DB::table('fin_service_items AS si')
                            ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                            ->leftJoin('fin_service_item_rate AS sr', function ($query) {
                                return $query->on('sr.SERVICE_ITEM_ID', '=', 'si.SERVICE_ITEM_ID')
                                        ->where('sr.IS_ACTIVE', 1)
                                        ->where('sr.CURRENT_STATUS', 1);
                            })
                            ->where(function ($query) use ($serviceItemId) {
                                if (count($serviceItemId) > 0) {
                                    return $query->whereIn('si.SERVICE_ITEM_ID', $serviceItemId);
                                }
                            })
                            ->where($where2)
                            ->where(function ($query) use ($clientName_ItemRate, $clientName_Fields, $project, $serviceItemSrc) {
                                if ($clientName_ItemRate == 'SPRINGER_INVOICE' && $serviceItemSrc == 'PRICING_GRID') {

                                    return $query->where('sr.CUSTOMER_ID', $project->CUSTOMER_ID)
                                            ->where('sr.CUSTOMER_DIVISION_ID', $project->CUSTOMER_DIVISION_ID)
                                            ->where(function ($query) use ($clientName_Fields) {
                                                if ($clientName_Fields['TRIM_TYPE_ID'] > 0 && $clientName_Fields['WORK_TYPE_ID'] > 0) {
                                                    return $query->where('sr.TRIM_TYPE_ID', $clientName_Fields['TRIM_TYPE_ID'])
                                                            ->where('sr.WORK_TYPE_ID', $clientName_Fields['WORK_TYPE_ID']);
                                                }
                                            })
                                            ->whereRaw(' "' . $this->date . '" between date(sr.START_DATE) and date(sr.END_DATE)');
                                }
                            })
                            ->select($select2)
                            ->when('sr.SERVICE_ITEM_ID', function ($query) use ($clientName_ItemRate, $clientName_Fields, $serviceItemSrc) {
                                if ($clientName_ItemRate == '' && count($clientName_Fields) == 0) {
                                    return $query->groupBy('sr.SERVICE_ITEM_ID');
                                } else if ($clientName_ItemRate == 'SPRINGER_INVOICE' && $serviceItemSrc == 'PRICING_GRID' && ( $clientName_Fields['TRIM_TYPE_ID'] == 0 || $clientName_Fields['WORK_TYPE_ID'] == 0)) {
                                    return $query->groupBy('sr.SERVICE_ITEM_ID');
                                }
                            })
                            ->union($getQuoteTempItems)
                            ->get();



                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                    $Response['lineItem'] = $lineItem;
                    $Response['lineItemQuantity'] = $lineItemQuantity;
                    $Response['project'] = $project;
                    $Response['projectType'] = $clientName_Fields;
                    $Response['clientItemRate'] = array('client' => $clientName_ItemRate, 'autoErrorMsg' => $autoErrorMsg);
                    // all good
                } catch (\Exception $e) {
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }

            return response()->json($Response);
        }
    }

    public function getServiceItems(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        if ($request->input()) {
            $Req = (object) $request->input();

            $columnArray = array();
            $columnArray[] = 'sg.SECTION_NAME';
            $columnArray[] = 'si.ITEM_NAME';
            $columnArray[] = 'si.ACCOUNT_CODE';
            $columnArray[] = 'si.SERVICE_ITEM_ID';
            $columnArray[] = 'sg.SERVICE_GROUP_ID';
            $columnArray[] = 'si.ITEM_CODE';

            $columnArray[] = 'si.ITEM_SRC';
            $columnArray[] = 'si.RATE_FIELD';

            $orderColumn = $Req->order[0]['column'];
            $sorting = $Req->order[0]['dir'];
            $start = $Req->start;

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = trim($Req->search['value']);

            $recordsTotal = DB::table('fin_service_items AS si')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->where('si.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('si.ACCOUNT_CODE', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->count();


            $activeData = DB::table('fin_service_items AS si')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->where('si.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('si.ACCOUNT_CODE', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->orderBy($columnArray[$orderColumn], $sorting)
                    ->when($length, function ($query) use ($length, $start) {
                        return $query->skip($start)->take($length);
                    })
                    ->select($columnArray)
                    ->get();


            $data = array();
            foreach ($activeData as $row) {
                $tempArray = array();
                $tempArray['SECTION_NAME'] = $row->SECTION_NAME;
                $tempArray['ITEM_NAME'] = $row->ITEM_NAME;
                $tempArray['ITEM_CODE'] = $row->ITEM_CODE;
                $tempArray['ACCOUNT_CODE'] = $row->ACCOUNT_CODE;
                $tempArray['SERVICE_ITEM_ID'] = $row->SERVICE_ITEM_ID;
                $tempArray['SERVICE_GROUP_ID'] = $row->SERVICE_GROUP_ID;
                $tempArray['ITEM_SRC'] = $row->ITEM_SRC;

                if ($row->ITEM_SRC == 1) {
                    $tempArray['ITEM_SRC_TYPE'] = 'Pricing Grid';
                } else if ($row->ITEM_SRC == 2) {
                    $tempArray['ITEM_SRC_TYPE'] = 'Additional Item';
                }

                if ($row->RATE_FIELD == 1) {
                    $tempArray['RATE_FIELD'] = 'Unit Type';
                } else {
                    $tempArray['RATE_FIELD'] = 'Flat Amount';
                }
                $tempArray['ACTION'] = '<a href="javascript:;" class="insertNewLineItem"><i class="fa fa-plus "></i> Add Item</a>';

                array_push($data, $tempArray);
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = $recordsTotal;
            $Response["recordsFiltered"] = $recordsTotal;
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function getUnitType(Request $request) {
        $role = $this->permissionCheck(array('AL', 'AM', 'PM', 'FIN'));
        $unitTypes = DB::table('fin_unit_enum')->where('IS_ACTIVE', 1)
                ->select(DB::raw('UNIT_ENUM_ID AS value, NAME as name'))
                ->orderBy('NAME')
                ->get();

        $Response = array();

        if (count($unitTypes) > 0) {
            $Response["status"] = 1;
            $Response["unitTypes"] = $unitTypes;
        } else {
            $Response["status"] = 2;
        }
        return response()->json($Response);
    }

    public function permissionCheck($roles = array()) {
        $roleId = Session::get('users')['role_id'];

        if ($roleId == 8) {
            return 'ADMIN';
        } else {
            if (count($roles) > 0) {
                $isAccess = false;
                foreach ($roles as $v) {
                    if (in_array($roleId, $this->CONSTANT['ROLES'][$v])) {
                        $isAccess = true;
                        return $v;
                        break;
                    }
                }

                if ($isAccess == false) {
                    die('Access Denied');
                }
            }
        }
    }

    public function pushMsgToActiveMq() {
        $req = [
            "sender" => "SPRINGER_FINANCE",
            "id" => "122564564",
            "tableName" => "invoice_details",
            "processType" => "insert",
            "fields" => [
                ["FK_TITLE_ID" => "101", "PK_INVOICE_ID" => "101", "INVOICE_DATE" => "2018-08-01", "INVOICE_NUMBER" => "INV101", "INVOICE_ITEM_DESCRIPTION" => "TEST ITEM"]
            ]
        ];

        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', 'http://172.24.137.75:8080/Exporter/Message/activemq', [
            GuzzleHttp\RequestOptions::JSON => $req
        ]);
        $response = $response->getBody()->getContents();
        $response = json_decode($response);

        echo '<pre>';
        print_r($response);
        exit;

//        {
//        "sender" : "SPRINGER_FINANCE",
//        "id": "122564564",
//        "tableName" : "invoice_details",
//        "processType" : "insert",
//        "fields" : [ {
//            "FK_TITLE_ID":"101", "PK_INVOICE_ID":"101", "INVOICE_DATE":"2018-08-01", "INVOICE_NUMBER":"INV101", "INVOICE_ITEM_DESCRIPTION":"TEST ITEM"}]
//        }
    }

}
