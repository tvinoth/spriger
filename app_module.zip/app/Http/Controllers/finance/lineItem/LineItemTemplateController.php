<?php

namespace App\Http\Controllers\finance\lineItem;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use DB;
use Illuminate\Http\Response;
use App\Models\finance as FinanceModel;
use Config;
use Session;

class LineItemTemplateController extends Controller {

    public function __construct() {
        //        $this->middleware(function ($request, $next) {
//            $this->loginUserId = Session::get('users')['user_id'];
//            if (Session::has('users') == '') {
//                return redirect('/');
//            }
//            return $next($request);
//        });
        $this->dateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');

        $this->CONSTANT = Config::get('constants.FINANCE');

        parent::__construct();
    }

    public function index() {
        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PRICING_TEMP'),$data);
        return view('finance.lineItem.lineItemTemplate')->with($data);
    }

    public function getTemplate(Request $request) {

        if ($request->input()) {
            $Req = (object) $request->input();

            $columnArray = array();
            $columnArray[] = 't.TEMPLATE_NAME';
            $columnArray[] = 'tm.TEAM_NAME';
            $columnArray[] = 't.CREATED_DATE';
            $columnArray[] = 't.QUOTE_TEMPLATE_ID';

            $orderColumn = $Req->order[0]['column'];
            $sorting = $Req->order[0]['dir'];
            $start = $Req->start;

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = trim($Req->search['value']);

            $recordsTotal = DB::table('fin_quote_template AS t')
                    ->join('team AS tm', 'tm.TEAM_ID', '=', 't.TEAM_ID')
                    ->where('t.IS_ACTIVE', 1)
                    ->where('tm.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('t.TEMPLATE_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('tm.TEAM_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->count();


            $activeData = DB::table('fin_quote_template AS t')
                    ->join('team AS tm', 'tm.TEAM_ID', '=', 't.TEAM_ID')
                    ->where('t.IS_ACTIVE', 1)
                    ->where('tm.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('t.TEMPLATE_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('tm.TEAM_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->orderBy($columnArray[$orderColumn], $sorting)
                    ->when($length, function ($query) use ($length, $start) {
                        return $query->skip($start)->take($length);
                    })
                    ->select($columnArray)
                    ->get();

            //
            $columnArray2 = [];
            $columnArray2[] = 'si.ITEM_NAME';
            $columnArray2[] = 'sg.SECTION_NAME';
            $columnArray2[] = 'si.SERVICE_GROUP_ID';
            $columnArray2[] = 'si.SERVICE_ITEM_ID';
            $columnArray2[] = DB::raw('CONCAT(sg.SECTION_NAME," :: ",si.ITEM_NAME) AS SERVICE_ITEM_NAME');


            //        
            $data = array();
            foreach ($activeData as $row) {

                $tempArray = array();
                $tempArray['TEMPLATE_NAME'] = $row->TEMPLATE_NAME;
                $tempArray['TEAM_NAME'] = $row->TEAM_NAME;
                $tempArray['CREATED_DATE'] = $row->CREATED_DATE;
                $tempArray['QUOTE_TEMPLATE_ID'] = $row->QUOTE_TEMPLATE_ID;

                $edit = '<a href="javascript:;" class="editTemplate" ><button type="button" class="btn btn-minier btn-primary" style="margin-right:10px"><i class="fa fa-pencil "></i></button></a>';
                $delete = '<a href="javascript:;" class="deleteTemplate" ><button type="button" class="btn btn-minier btn-danger"><i class="fa fa-trash "></i></button></a>';
                $tempArray['ACTION'] = $edit . ' ' . $delete;

                $lineItemList = DB::table('fin_quote_template_items AS ti')
                        ->join('fin_service_items AS si', 'si.SERVICE_ITEM_ID', '=', 'ti.SERVICE_ITEM_ID')
                        ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'ti.SERVICE_GROUP_ID')
                        ->where('ti.QUOTE_TEMPLATE_ID', $row->QUOTE_TEMPLATE_ID)
                        ->select($columnArray2)
                        ->get();
                $tempArray['QUOTE_TEMPLATE_ITEM'] = $lineItemList;

                array_push($data, $tempArray);
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = $recordsTotal;
            $Response["recordsFiltered"] = $recordsTotal;
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function getAllLineItems(Request $request) {

        $columnArray = [];
        $columnArray[] = 'si.ITEM_NAME';
        $columnArray[] = 'sg.SECTION_NAME';
        $columnArray[] = 'si.SERVICE_GROUP_ID';
        $columnArray[] = 'si.SERVICE_ITEM_ID';
        $columnArray[] = DB::raw('CONCAT(sg.SECTION_NAME," :: ",si.ITEM_NAME) AS SERVICE_ITEM_NAME');

        $lineItemList = DB::table('fin_service_items AS si')
                ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                ->where('si.IS_ACTIVE', 1)
                ->where('sg.IS_ACTIVE', 1)
                ->orderBy('si.ITEM_NAME', 'asc')
                ->select($columnArray)
                ->get();

        $teamList = DB::table('team AS t')
                ->where('t.IS_ACTIVE', 1)
                ->whereNotIn('TEAM_ID', function($query) {
                    $query->select('TEAM_ID')->from('fin_quote_template')->where('IS_ACTIVE', 1);
                })
                ->orderBy('t.TEAM_NAME', 'asc')
                ->select('t.TEAM_ID', 't.TEAM_NAME')
                ->get();


        $Response = [];
        if (count($lineItemList) > 0 && count($teamList) > 0) {
            $Response['status'] = 1;
            $Response['msg'] = 'Success';
            $Response['data']['lineItemList'] = $lineItemList;
            $Response['data']['teamList'] = $teamList;
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'No data found';
        }
        return response()->json($Response);
    }

    public function ajaxAddTemplate(Request $request) {

        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['team'] = 'required|numeric|min:1';
            $validationArray['templateName'] = 'required|min:2';
            $validationArray["templateItem.*"] = "required|min:1";

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $team = $request->input('team');
                $templateName = $request->input('templateName');
                $templateItem = $request->input('templateItem');

                DB::beginTransaction();
                try {

                    $templateInsert = $templateItemInsert = [];
                    $templateInsert['TEMPLATE_NAME'] = $templateName;
                    $templateInsert['TEAM_ID'] = $team;
                    $templateInsert['CREATED_BY'] = $this->loginUserId;
                    $templateInsert['CREATED_DATE'] = $this->dateTime;

                    $templateID = DB::table('fin_quote_template')->insertGetId($templateInsert);

                    $SERVICE_ITEM_ARRAY = [];
                    foreach ($templateItem as $item) {
                        if (!in_array($item['SERVICE_ITEM_ID'], $SERVICE_ITEM_ARRAY)) {
                            $tempArray = [];
                            $tempArray['QUOTE_TEMPLATE_ID'] = $templateID;
                            $tempArray['SERVICE_GROUP_ID'] = $item['SERVICE_GROUP_ID'];
                            $tempArray['SERVICE_ITEM_ID'] = $SERVICE_ITEM_ARRAY[] = $item['SERVICE_ITEM_ID'];
                            $tempArray['CREATED_BY'] = $this->loginUserId;
                            $tempArray['CREATED_DATE'] = $this->dateTime;
                            array_push($templateItemInsert, $tempArray);
                        }
                    }

                    DB::table('fin_quote_template_items')->insert($templateItemInsert);

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function ajaxUpdateTemplate(Request $request) {

        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['templateId'] = 'required|numeric|min:1';
            $validationArray['templateName'] = 'required|min:2';
            $validationArray["templateItem.*"] = "required|min:1";

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $templateID = $request->input('templateId');
                $team = $request->input('team');
                $templateName = $request->input('templateName');
                $templateItem = $request->input('templateItem');

                DB::beginTransaction();
                try {
                    $templateInsert = $templateItemInsert = [];
                    $templateInsert['TEMPLATE_NAME'] = $templateName;
                    $templateInsert['LAST_MOD_BY'] = $this->loginUserId;
                    $templateInsert['LAST_MOD_DATE'] = $this->dateTime;

                    DB::table('fin_quote_template')->where('QUOTE_TEMPLATE_ID', $templateID)->update($templateInsert);

                    DB::table('fin_quote_template_items')->where('QUOTE_TEMPLATE_ID', $templateID)->delete();
                    
                    $SERVICE_ITEM_ARRAY = [];
                    foreach ($templateItem as $item) {
                        if (!in_array($item['SERVICE_ITEM_ID'], $SERVICE_ITEM_ARRAY)) {
                            $tempArray = [];
                            $tempArray['QUOTE_TEMPLATE_ID'] = $templateID;
                            $tempArray['SERVICE_GROUP_ID'] = $item['SERVICE_GROUP_ID'];
                            $tempArray['SERVICE_ITEM_ID'] = $SERVICE_ITEM_ARRAY[] = $item['SERVICE_ITEM_ID'];
                            $tempArray['CREATED_BY'] = $this->loginUserId;
                            $tempArray['CREATED_DATE'] = $this->dateTime;
                            array_push($templateItemInsert, $tempArray);
                        }
                    }

                    DB::table('fin_quote_template_items')->insert($templateItemInsert);

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function ajaxDeleteTemplate(Request $request) {

        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['templateID'] = 'required|numeric|min:1';

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $templateID = $request->input('templateID');

                DB::beginTransaction();
                try {

                    $templateUpdate = [];
                    $templateUpdate['IS_ACTIVE'] = 0;
                    $templateUpdate['LAST_MOD_BY'] = $this->loginUserId;
                    $templateUpdate['LAST_MOD_DATE'] = $this->dateTime;
                    DB::table('fin_quote_template')->where('QUOTE_TEMPLATE_ID', $templateID)->update($templateUpdate);

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

}
