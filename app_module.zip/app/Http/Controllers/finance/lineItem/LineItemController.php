<?php

namespace App\Http\Controllers\finance\lineItem;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use DB;
use Illuminate\Http\Response;
use App\Models\finance as FinanceModel;
use Config;
use Session;

class LineItemController extends Controller {

    public function __construct() {
        //        $this->middleware(function ($request, $next) {
//            $this->loginUserId = Session::get('users')['user_id'];
//            if (Session::has('users') == '') {
//                return redirect('/');
//            }
//            return $next($request);
//        });
        $this->dateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');

        $this->CONSTANT = Config::get('constants.FINANCE');

        parent::__construct();
    }

    public function index() {
        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.ADDITIONAL_LINE_ITEM'),$data);
        $data['serviceGroupList'] = FinanceModel\ServiceGroupModel::where('IS_ACTIVE', 1)->select('SERVICE_GROUP_ID', 'SECTION_NAME')->get();
        $data['clientList'] = FinanceModel\CustomerModel::where('IS_ACTIVE', 1)->where('CUSTOMER_ID', 10885)->select('CUSTOMER_ID', 'CUSTOMER_NAME')->get();
        $data['unitTypeList'] = FinanceModel\UnitEnumModel::where('IS_ACTIVE', 1)->select('UNIT_ENUM_ID', 'NAME')->get();
        $data['currencyList'] = FinanceModel\CurrencyEnumModel::where('IS_ACTIVE', 1)->select('ID', 'NAME')->get();
        return view('finance.lineItem.additionalLineItem')->with($data);
    }

    public function ajaxAddLineItem(Request $request) {
        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['serviceGroup'] = 'required|numeric|min:1';
            $validationArray['itemName'] = 'required|min:2';
            $validationArray['itemType'] = 'required|numeric';

            if ($request->input('itemType') == 1) {
                $validationArray['unitType'] = 'required|numeric|min:1';
                $validationArray['currency'] = 'required|numeric';
                $validationArray['price'] = 'required|numeric';
            }

            $validator = Validator::make($request->all(), $validationArray);
            //exit;

            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $serviceGroup = $request->input('serviceGroup');
                $itemName = $request->input('itemName');
                $accountCode = $request->input('accountCode');
                $itemType = $request->input('itemType');
                $price = $request->input('price');

                if (trim($price) == '' || trim($price) == 0) {
                    $price = NULL;
                }

                if ($itemType == 1) {
                    $unitType = $request->input('unitType');
                    $client = $request->input('client');
                    $currency = $request->input('currency');
                } else {
                    $unitType = $client = $currency = NULL;
                }



                DB::beginTransaction();
                try {

                    $Prefix = FinanceModel\PrefixEnumModel::where('PREFIX_ENUM_ID', 2)->where('IS_ACTIVE', 1)->value('PREFIX_NAME');
                    $Last_ID = FinanceModel\ServiceItemsModel::max('SERVICE_ITEM_ID');

                    $item = new FinanceModel\ServiceItemsModel();
                    $item->ITEM_NAME = $itemName;
                    $item->SERVICE_GROUP_ID = $serviceGroup;
                    $item->ITEM_CODE = $Prefix . str_pad($Last_ID + 1, 4, 0, STR_PAD_LEFT);
                    $item->RATE_FIELD = $itemType;
                    $item->ACCOUNT_CODE = $accountCode;
                    $item->ITEM_SRC = 2; // additional line item
                    $item->CREATED_BY = $this->loginUserId;
                    $item->CREATED_DATE = $this->dateTime;
                    $item->save();
                    $itemId = $item->SERVICE_ITEM_ID;


                    if (($itemType == 1 || $itemType == 0) && $price != NULL) {
                        $itemRate = new FinanceModel\ServiceItemRateModel();
                        $itemRate->SERVICE_GROUP_ID = $serviceGroup;
                        $itemRate->SERVICE_ITEM_ID = $itemId;

                        $itemRate->UNIT_ENUM_ID = $unitType;
                        if ($client > 0 && trim($client) != '') {
                            $itemRate->CUSTOMER_ID = $client;
                            $itemRate->CUSTOMER_DIVISION_ID = 178;
                        }
                        $itemRate->CURRENCY_ID = $currency;
                        $itemRate->RATE = $price;
                        $itemRate->CREATED_BY = $this->loginUserId;
                        $itemRate->CREATED_DATE = $this->dateTime;
                        $itemRate->save();
                    }


                    DB::commit();
                    $Response['status'] = 1;
                    $Response['itemCode'] = $Prefix . str_pad($Last_ID + 1, 4, 0, STR_PAD_LEFT);
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function ajaxUpdateLineItem(Request $request) {
        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['serviceItemId'] = 'required|numeric|min:1';
            $validationArray['serviceGroup'] = 'required|numeric|min:1';
            $validationArray['itemName'] = 'required|min:2';
            $validationArray['itemType'] = 'required|numeric';

            if ($request->input('itemType') == 1) {
                $validationArray['unitType'] = 'required|numeric|min:1';
                $validationArray['currency'] = 'required|numeric';
                $validationArray['price'] = 'required|numeric';
            }

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {


                $serviceItemId = $request->input('serviceItemId');
                $serviceGroup = $request->input('serviceGroup');
                $itemName = $request->input('itemName');
                $accountCode = $request->input('accountCode');
                $itemType = $request->input('itemType');
                $price = $request->input('price');
                if (trim($price) == '' || trim($price) == 0) {
                    $price = NULL;
                }

                if ($itemType == 1) {
                    $unitType = $request->input('unitType');
                    $client = $request->input('client');
                    $currency = $request->input('currency');
                } else {
                    $unitType = $client = $currency = NULL;
                }




                DB::beginTransaction();
                try {

                    $item = FinanceModel\ServiceItemsModel::find($serviceItemId);
                    $item->ITEM_NAME = $itemName;
                    $item->SERVICE_GROUP_ID = $serviceGroup;
                    $item->RATE_FIELD = $itemType;
                    $item->ACCOUNT_CODE = $accountCode;
                    $item->LAST_MOD_BY = $this->loginUserId;
                    $item->LAST_MOD_DATE = $this->dateTime;
                    $item->save();

                    $updateData = array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->dateTime, 'LAST_MOD_BY' => $this->loginUserId);
                    $dltRate = FinanceModel\ServiceItemRateModel::where('SERVICE_ITEM_ID', $serviceItemId)->update($updateData);

                    if (($itemType == 1 || $itemType == 0) && $price != NULL) {
                        $itemRate = new FinanceModel\ServiceItemRateModel();
                        $itemRate->SERVICE_GROUP_ID = $serviceGroup;
                        $itemRate->SERVICE_ITEM_ID = $serviceItemId;

                        $itemRate->UNIT_ENUM_ID = $unitType;
                        if ($client > 0 && trim($client) != '') {
                            $itemRate->CUSTOMER_ID = $client;
                            $itemRate->CUSTOMER_DIVISION_ID = 178;
                        }
                        $itemRate->CURRENCY_ID = $currency;
                        $itemRate->RATE = $price;
                        $itemRate->CREATED_BY = $this->loginUserId;
                        $itemRate->CREATED_DATE = $this->dateTime;
                        $itemRate->save();
                    }


                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function ajaxDeleteLineItem(Request $request) {
        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');

            $validationArray = [];
            $validationArray['serviceItemId'] = 'required|numeric|min:1';
            $validator = Validator::make($request->all(), $validationArray);

            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {
                $serviceItemId = $request->input('serviceItemId');
                DB::beginTransaction();
                try {

                    $item = FinanceModel\ServiceItemsModel::find($serviceItemId);
                    $item->IS_ACTIVE = 0;
                    $item->LAST_MOD_BY = $this->loginUserId;
                    $item->LAST_MOD_DATE = $this->dateTime;
                    $item->save();

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

    public function getAdditionalServiceItems(Request $request) {

        if ($request->input()) {
            $Req = (object) $request->input();

            $columnArray = array();
            $columnArray[] = 'sg.SECTION_NAME';
            $columnArray[] = 'si.ITEM_NAME';
            $columnArray[] = 'si.ACCOUNT_CODE';
            $columnArray[] = 'si.SERVICE_ITEM_ID';
            $columnArray[] = 'sg.SERVICE_GROUP_ID';
            $columnArray[] = 'si.ITEM_CODE';

            $columnArray[] = 'si.ITEM_SRC';
            $columnArray[] = 'si.RATE_FIELD';

            $orderColumn = $Req->order[0]['column'];
            $sorting = $Req->order[0]['dir'];
            $start = $Req->start;

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = trim($Req->search['value']);

            $recordsTotal = DB::table('fin_service_items AS si')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->where('si.ITEM_SRC', 2)
                    ->where('si.IS_ACTIVE', 1)
                    ->where('sg.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('si.ACCOUNT_CODE', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->count();


            $activeData = DB::table('fin_service_items AS si')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->where('si.ITEM_SRC', 2)
                    ->where('si.IS_ACTIVE', 1)
                    ->where('sg.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('si.ACCOUNT_CODE', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->orderBy($columnArray[$orderColumn], $sorting)
                    ->when($length, function ($query) use ($length, $start) {
                        return $query->skip($start)->take($length);
                    })
                    ->select($columnArray)
                    ->get();


            $data = array();
            foreach ($activeData as $row) {
                $tempArray = array();
                $tempArray['SECTION_NAME'] = $row->SECTION_NAME;
                $tempArray['ITEM_NAME'] = $row->ITEM_NAME;
                $tempArray['ITEM_CODE'] = $row->ITEM_CODE;
                $tempArray['ACCOUNT_CODE'] = $row->ACCOUNT_CODE;
                $tempArray['SERVICE_ITEM_ID'] = $row->SERVICE_ITEM_ID;
                $tempArray['SERVICE_GROUP_ID'] = $row->SERVICE_GROUP_ID;

                if ($row->RATE_FIELD == 1) {
                    $tempArray['RATE_FIELD'] = 'Unit Type';
                } else {
                    $tempArray['RATE_FIELD'] = 'Flat Amount';
                }
                $edit = '<a href="javascript:;" class="editLineItem" ><button type="button" class="btn btn-minier btn-primary" style="margin-right:10px"><i class="fa fa-pencil "></i></button></a>';
                $delete = '<a href="javascript:;" class="deleteLineItem" ><button type="button" class="btn btn-minier btn-danger"><i class="fa fa-trash "></i></button></a>';

                $tempArray['ACTION'] = $edit . ' ' . $delete;
                array_push($data, $tempArray);
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = $recordsTotal;
            $Response["recordsFiltered"] = $recordsTotal;
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    public function getServiceItemDetails(Request $request, $serviceItemId) {
        $Response = [];
        $Response['status'] = 2;
        $Response['msg'] = 'Failure';
        if ($serviceItemId > 0) {

            $activeData = FinanceModel\ServiceItemsModel::with('getItemRate')->where('SERVICE_ITEM_ID', $serviceItemId)
                    ->where('ITEM_SRC', 2)
                    ->where('IS_ACTIVE', 1)
                    ->first();

            if (count($activeData) > 0) {
                $Response['status'] = 1;
                $Response['msg'] = 'Success';
                $Response['data'] = $activeData;
            }
        }
        return response()->json($Response);
    }

    //Stage Process - Line Item Mapping (management)
    public function stageProcessMap() {
        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.STAGE_PROCESS_MAPPING'),$data);
        $data['pageTitle'] = 'Stage Process - Line Item Mapping';
        $data['pageName'] = 'Stage Process - Line Item Mapping';
        $data['serviceItemList'] = FinanceModel\ServiceItemsModel::join('fin_service_group AS sg', 'fin_service_items.SERVICE_GROUP_ID', '=', 'sg.SERVICE_GROUP_ID')
                ->where('fin_service_items.IS_ACTIVE', 1)
                ->select('fin_service_items.SERVICE_ITEM_ID', 'fin_service_items.ITEM_NAME', 'sg.SERVICE_GROUP_ID', 'sg.SECTION_NAME')
                ->get();
        $data['roundList'] = DB::table('round_enum')->where('IS_ACTIVE', 1)->select('ID', 'NAME')->get();
        $data['stageList'] = DB::table('stage')->where('IS_ACTIVE', 1)->select('STAGE_ID', 'STAGE_NAME')->get();
        $data['clientList'] = FinanceModel\CustomerModel::where('IS_ACTIVE', 1)->where('CUSTOMER_ID', 10885)->select('CUSTOMER_ID', 'CUSTOMER_NAME')->get();
        return view('finance.lineItem.stageProcessMapping')->with($data);
    }

    //Stage Process - Line Item Mapping (list)
    public function getStageProcessMapping(Request $request) {

        if ($request->input()) {
            $Req = (object) $request->input();

            $columnArray = array();
            $columnArray[] = 'sg.SECTION_NAME';
            $columnArray[] = 'si.ITEM_NAME';
            $columnArray[] = 'r.NAME';
            $columnArray[] = 's.STAGE_NAME';

            $columnArray[] = 'sm.STAGE_MAPPING_ID';
            $columnArray[] = 'sm.CUSTOMER_ID';
            $columnArray[] = 'sm.ROUND_ID';
            $columnArray[] = 'sm.STAGE_ID';
            $columnArray[] = 'sm.SERVICE_ITEM_ID';

            $orderColumn = $Req->order[0]['column'];
            $sorting = $Req->order[0]['dir'];
            $start = $Req->start;

            if ($Req->length != -1) {
                $length = $Req->length;
            } else {
                $length = false;
            }

            $searchStr = trim($Req->search['value']);

            $recordsTotal = DB::table('fin_lineitem_stage_map AS sm')
                    ->join('fin_service_items AS si', 'si.SERVICE_ITEM_ID', '=', 'sm.SERVICE_ITEM_ID')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->join('round_enum AS r', 'r.ID', '=', 'sm.ROUND_ID')
                    ->join('stage AS s', 's.STAGE_ID', '=', 'sm.STAGE_ID')
                    ->where('sm.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('r.NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('s.STAGE_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->count();


            $activeData = DB::table('fin_lineitem_stage_map AS sm')
                    ->join('fin_service_items AS si', 'si.SERVICE_ITEM_ID', '=', 'sm.SERVICE_ITEM_ID')
                    ->join('fin_service_group AS sg', 'sg.SERVICE_GROUP_ID', '=', 'si.SERVICE_GROUP_ID')
                    ->join('round_enum AS r', 'r.ID', '=', 'sm.ROUND_ID')
                    ->join('stage AS s', 's.STAGE_ID', '=', 'sm.STAGE_ID')
                    ->where('sm.IS_ACTIVE', 1)
                    ->when($searchStr, function ($query) use ($searchStr) {
                        return $query->where('si.ITEM_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('sg.SECTION_NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('r.NAME', 'like', '%' . $searchStr . '%')
                                ->orWhere('s.STAGE_NAME', 'like', '%' . $searchStr . '%');
                    })
                    ->orderBy($columnArray[$orderColumn], $sorting)
                    ->when($length, function ($query) use ($length, $start) {
                        return $query->skip($start)->take($length);
                    })
                    ->select($columnArray)
                    ->get();


            $data = array();
            foreach ($activeData as $row) {
                $tempArray = array();
                $tempArray['SECTION_NAME'] = $row->SECTION_NAME;
                $tempArray['ITEM_NAME'] = $row->ITEM_NAME;
                $tempArray['ROUND_NAME'] = $row->NAME;
                $tempArray['STAGE_NAME'] = $row->STAGE_NAME;

                $tempArray['STAGE_MAPPING_ID'] = $row->STAGE_MAPPING_ID;
                $tempArray['CUSTOMER_ID'] = $row->CUSTOMER_ID;
                $tempArray['ROUND_ID'] = $row->ROUND_ID;
                $tempArray['STAGE_ID'] = $row->STAGE_ID;
                $tempArray['SERVICE_ITEM_ID'] = $row->SERVICE_ITEM_ID;

                $edit = '<a href="javascript:;" class="editMapping" ><button type="button" class="btn btn-minier btn-primary" style="margin-right:10px"><i class="fa fa-pencil "></i></button></a>';
                $delete = '<a href="javascript:;" class="deleteMapping" ><button type="button" class="btn btn-minier btn-danger"><i class="fa fa-trash "></i></button></a>';

                $tempArray['ACTION'] = $edit . ' ' . $delete;
                array_push($data, $tempArray);
            }

            $Response = array();
            $Response["draw"] = $Req->draw;
            $Response["recordsTotal"] = $recordsTotal;
            $Response["recordsFiltered"] = $recordsTotal;
            $Response["data"] = $data;

            return response()->json($Response);
        }
    }

    //Stage Process - Line Item Mapping (insert, update)
    public function ajaxAddUpdateStageMap(Request $request) {
        if ($request->input()) {

            $this->loginUserId = Session::get('users.user_id');
            $transType = $request->input('transType');

            $validationArray = [];
            if ($transType == 1) { // insert
                $validationArray['transType'] = 'required|numeric';
                $validationArray['client'] = 'required|numeric';
                $validationArray['serviceItem'] = 'required|numeric';
                $validationArray['round'] = 'required|numeric';
                $validationArray['stage'] = 'required|numeric';
            } else if ($transType == 2) { // update
                $validationArray['transType'] = 'required|numeric';
                $validationArray['client'] = 'required|numeric';
                $validationArray['serviceItem'] = 'required|numeric';
                $validationArray['round'] = 'required|numeric';
                $validationArray['stage'] = 'required|numeric';
                $validationArray['stageMapId'] = 'required|numeric';
            } else if ($transType == 3) { // delete
                $validationArray['transType'] = 'required|numeric';
                $validationArray['stageMapId'] = 'required|numeric';
            } else {
                $Response['status'] = 401;
                $Response['msg'] = 'Access Denied';
                return response()->json($Response);
            }

            $validator = Validator::make($request->all(), $validationArray);


            if ($validator->fails()) {
                $Response['status'] = 0;
                $Response['Msg'] = 'Validation Error';
                $Response['ErrMsg'] = $validator->errors();
            } else {

                DB::beginTransaction();
                try {

                    if ($transType == 1) {
                        $itemMap = new FinanceModel\LineItemStageMapModel();
                        $itemMap->ROUND_ID = $request->input('round');
                        $itemMap->STAGE_ID = $request->input('stage');
                        $itemMap->SERVICE_ITEM_ID = $request->input('serviceItem');
                        $itemMap->CUSTOMER_ID = $request->input('client');
                        $itemMap->CREATED_BY = $this->loginUserId;
                        $itemMap->CREATED_DATE = $this->dateTime;
                        $itemMap->save();
                    } else if ($transType == 2) {
                        $stageMapId = $request->input('stageMapId');
                        $itemMap = FinanceModel\LineItemStageMapModel::find($stageMapId);
                        $itemMap->ROUND_ID = $request->input('round');
                        $itemMap->STAGE_ID = $request->input('stage');
                        $itemMap->SERVICE_ITEM_ID = $request->input('serviceItem');
                        $itemMap->CUSTOMER_ID = $request->input('client');
                        $itemMap->LAST_MOD_BY = $this->loginUserId;
                        $itemMap->LAST_MOD_DATE = $this->dateTime;
                        $itemMap->save();
                    } else if ($transType == 3) {
                        $stageMapId = $request->input('stageMapId');
                        $itemMap = FinanceModel\LineItemStageMapModel::find($stageMapId);
                        $itemMap->IS_ACTIVE = 0;
                        $itemMap->LAST_MOD_BY = $this->loginUserId;
                        $itemMap->LAST_MOD_DATE = $this->dateTime;
                        $itemMap->save();
                    }

                    DB::commit();
                    $Response['status'] = 1;
                    $Response['msg'] = 'Success';
                } catch (\Exception $e) {
                    DB::rollback();
                    $Response['status'] = 2;
                    $Response['msg'] = 'Failure';
                    $Response['errorMsg'] = $e->getMessage();
                }
            }
        } else {
            $Response['status'] = 2;
            $Response['msg'] = 'Failure';
        }



        return response()->json($Response);
    }

}
