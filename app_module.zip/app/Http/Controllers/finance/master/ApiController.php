<?php

namespace App\Http\Controllers\finance\master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Illuminate\Http\Response;
use Config;
use DB;
use Mail;
use URL;

class ApiController extends Controller {

    public function __construct() {
        $this->dateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');
        $this->CONSTANT = Config::get('constants.FINANCE');
        parent::__construct();
    }

    public function activeMqResponse($mailArray) {
       
    }

}
