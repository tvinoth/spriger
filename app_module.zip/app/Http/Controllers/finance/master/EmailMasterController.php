<?php

namespace App\Http\Controllers\finance\master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Validator;
use Illuminate\Http\Response;
use Config;
use DB;
use Mail;
use URL;

class EmailMasterController extends Controller {

    public function __construct() {
        $this->dateTime = date('Y-m-d H:i:s');
        $this->date = date('Y-m-d');
        $this->CONSTANT = Config::get('constants.FINANCE');
        parent::__construct();
    }

    public function sendMailRawText($mailArray) {
        if (is_array($mailArray)) {
          
            Mail::raw($mailArray['Body'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }

                $message->getSwiftMessage();
            });



            if (Mail::failures()) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
                $Response['MsgText'] = Mail::failures();
            } else {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }

            return $Response;
        }
    }

    public function sendMailBladeTemplate($mailArray) {
        if (is_array($mailArray)) {

            try {
//                print_r($mailArray);
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }

                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status'] = 2;
                    $Response['Msg'] = 'Failure';
                    $Response['MsgText'] = Mail::failures();
                } else {
                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Success';
                }
            } catch (\Exception $e) {
                $Response['Status'] = 2;
                $Response['Msg'] = 'Failure';
            }
//            print_r($Response);
            return $Response;
        }

//        Mail::later(5, 'emailTemplate.finance.test2', ['first_name' => 'My Name'], function ($m) {
//            $m->from('gokul.fita@gmail.com', 'Gokul');
//            $m->to('mathankumar.p@spi-global.com')->subject('Test1459');
//            $m->getSwiftMessage();
//        });
//        dd(Mail::failures());
//        exit;
    }

}
