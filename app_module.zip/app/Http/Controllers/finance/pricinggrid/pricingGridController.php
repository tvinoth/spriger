<?php
namespace App\Http\Controllers\finance\pricinggrid;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\finance as FinanceModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use DB; 
use Config;
use Illuminate\Http\Response;
use File;
use App\Http\Requests;
use Illuminate\Support\Facades\Input;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Maatwebsite\Excel\Facades\Excel;
use PHPExcel_Calculation;
use Symfony\Component\Finder\SplFileInfo;

class pricingGridController extends Controller
{    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {  
		parent::__construct();
		$this->DateTime = Carbon::now('Asia/Kolkata');
        $this->currentDateTime = date('m-d-Y_H_i_s_A', strtotime($this->DateTime));
		
		$this->middleware(function ($request, $next) {
            $this->loginUserId = Session::get('users')['user_id'];
			if(Session::has('users')=='')
			{
				return redirect('/');
			}
            return $next($request);
        });        
        
    }
	
    public function index()
    {		
		$data               =   array();
                $this->displayMenuName(Config::get('menuconstants.MENU.UPLOAD_PRICING'),$data);
        $data['pageTitle']  = 	'Pricing Grid Upload';
        $data['pageName']   =   'Pricing Grid Upload';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
		$data['customerId'] = Config::get('constants.FINANCE.SPRINGER_CUSTOMER_ID');
		$data['customerDivisionId'] = Config::get('constants.FINANCE.SPRINGER_CUSTOMER_DIVISION_ID');		
		$data['customerList'] = FinanceModel\CustomerModel::where('IS_ACTIVE', 1)->whereIn('CUSTOMER_ID', $data['customerId'])->select('CUSTOMER_ID', 'CUSTOMER_NAME')->get();
		$data['defaultCustomerList'] = 	0;
		if(count($data['customerList']) >=  1){
			$data['defaultCustomerList'] = 	$data['customerList'][0]->CUSTOMER_ID;	
		}
		$data['customerDivisionList'] = FinanceModel\CustomerDivisionModel::where('IS_ACTIVE', 1)->whereIn('CUSTOMER_ID', $data['customerId'])->whereIn('CUSTOMER_DIVISION_ID', $data['customerDivisionId'])->select('CUSTOMER_DIVISION_ID', 'DIVISION_NAME')->get();
		$data['defaultCustomerDivisionList'] = 	0;
		if(count($data['customerDivisionList']) >=  1){
			$data['defaultCustomerDivisionList'] = 	$data['customerDivisionList'][0]->CUSTOMER_DIVISION_ID;	
		}
		//$data['customerIdSel'] = Config::get('constants.FINANCE.SPRINGER_CUSTOMER_ID_SEL');
		//$data['customerDivisionIdSel'] = Config::get('constants.FINANCE.SPRINGER_CUSTOMER_DIVISION_ID_SEL');	
        return view('finance.pricinggrid.pricingGridUploadView')->with($data);
    }
	
	public function getExcelCellValue($excelSheet, $columnIndexName, $rowNo) {
        if (!is_numeric($excelSheet->getCell($columnIndexName . $rowNo)->getValue()) && $excelSheet->getCell($columnIndexName . $rowNo)->getValue() != "Total") {
            return $excelSheet->getCell($columnIndexName . $rowNo)->getOldCalculatedValue();
        } else {
            return $excelSheet->getCell($columnIndexName . $rowNo)->getValue();
        }
    }

    public function getExactExcelCellValue($excelSheet, $columnIndexName, $rowNo) {
        $resp = $excelSheet->getCell($columnIndexName . $rowNo)->getOldCalculatedValue();
        if (empty($resp)) {
            return $excelSheet->getCell($columnIndexName . $rowNo)->getValue();
        } else {
            return $resp;
        }
    }
	
    /**
     * Upload new File
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function upload(Request $request)
    {
		DB::beginTransaction();
		if ($request->file('pricingGridExcelFile')) {
			$validator = Validator::make($request->all(), [
				"pricingGridExcelFile" => "required|mimes:xlsx|max:1000000",
				"startDate" => "required|min:1",
				"endDate" => "required|min:1",
				"customerId" => "required|min:1",
				"customerDivisionId" => "required|min:1"
            ]);
            $mimeCheck = $request->file('pricingGridExcelFile')->getClientOriginalExtension();
        
			if ($validator->fails()) {
				$Response['Status'] = 1;//400
                $Response['Msg'] = 'Validation Error';
                $Response['ErrorMsg'] = $validator->errors();
			} else {
                
                try {
					$startDate = $request->input('startDate');
					$endDate = $request->input('endDate');
					$customerId = $request->input('customerId');
					$customerDivisionId = $request->input('customerDivisionId');
					
					//$chkQuery = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->whereRaw('"'.$startDate.'" between `START_DATE` and `END_DATE`')->orwhereRaw('"'.$endDate.'" between `START_DATE` and `END_DATE`')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);
					$firstChkQuery = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);
					
					$secondChkQuery = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('start_date', '>=', $startDate)->where('end_date', '<=', $endDate)->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);
					
					$thirdChkQuery = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->whereRaw('(("'.$startDate.'" between `START_DATE` and `END_DATE`)')->orwhereRaw('("'.$endDate.'" between `START_DATE` and `END_DATE`))')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);
					
					$fourthChkQuery = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->whereRaw('("'.$startDate.'" between `START_DATE` and `END_DATE`)')->whereRaw('("'.$endDate.'" between `START_DATE` and `END_DATE`)')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);
					
					//$chkQuery = array();
					//echo count($firstChkQuery)."---".count($secondChkQuery)."---".count($thirdChkQuery)."---".count($fourthChkQuery);
					if((count($firstChkQuery) == 0 && count($secondChkQuery) == 0 && count($thirdChkQuery) == 0 && count($fourthChkQuery) == 0) || (count($firstChkQuery) == 1 && count($secondChkQuery) == 1 && count($thirdChkQuery) == 1 && count($fourthChkQuery) == 1)){
					
					$targetdirectory = 'uploadFiles/pricingGrid/' . date('Y', strtotime($this->DateTime));
					
                    $mime_org = $request->file('pricingGridExcelFile')->getClientOriginalExtension();

                    $file_name = $request->file('pricingGridExcelFile')->getClientOriginalName();
                    $file_name = pathinfo($file_name, PATHINFO_FILENAME); // filename without extension
                    $orgFileName = trim($file_name) . '.' . $mime_org;
					
                    $filename = str_replace('.', '_' . $this->currentDateTime . '.', $orgFileName);
					
                    $request->file('pricingGridExcelFile')->move($targetdirectory, $filename);
                    $target_path = $targetdirectory . '/' . $filename; //DocPath
					
					//uploded documents entry
                    if (isset($target_path) && $target_path != '') {
						$docUpdate = [];
                        $docUpdate['IS_ACTIVE'] = 0;
                        $docUpdate['LAST_MOD_DATE'] = $this->DateTime;
                        $docUpdate['LAST_MOD_BY'] = $this->loginUserId;
						$chkUploadDocuments = FinanceModel\UploadedDocumentsModel::where(array('CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId,'IS_ACTIVE' => 1))->select(['UPLOADED_DOCUMENT_ID'])->count();
						
						if($chkUploadDocuments > 0){
							//disable previous upload file
							//FinanceModel\UploadedDocumentsModel::where(array('CUSTOMER_ID' => Config::get('constants.FINANCE.SPRINGER_CUSTOMER_ID_SEL'),'IS_ACTIVE' => 1))->update($docUpdate);
							FinanceModel\UploadedDocumentsModel::where(array('CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId,'IS_ACTIVE' => 1))->update($docUpdate);
						}
						$startDate = $request->input('startDate');
						$endDate = $request->input('endDate');
						$customerId = $request->input('customerId');
						$customerDivisionId = $request->input('customerDivisionId');
						
                        $insertFinUploadedDocuments = new FinanceModel\UploadedDocumentsModel();
                        $insertFinUploadedDocuments->ORG_FILENAME = $orgFileName;
                        $insertFinUploadedDocuments->RENAME_FILENAME = $filename;
                        $insertFinUploadedDocuments->DOCUMENT_PATH = $targetdirectory;
                        $insertFinUploadedDocuments->DOCUMENT_FORMAT = $mime_org;
						$insertFinUploadedDocuments->START_DATE = $startDate;
						$insertFinUploadedDocuments->END_DATE = $endDate;   
						$insertFinUploadedDocuments->CUSTOMER_ID = $customerId;             
						$insertFinUploadedDocuments->CUSTOMER_DIVISION_ID = $customerDivisionId;             
                        $insertFinUploadedDocuments->CREATED_DATE = $this->DateTime;
                        $insertFinUploadedDocuments->CREATED_BY = $this->loginUserId;
                        $insertFinUploadedDocuments->save();
                        $DocumentID = $insertFinUploadedDocuments->UPLOADED_DOCUMENT_ID;
                    }				
					
					$files = File::allFiles($targetdirectory);
					$fileListArr = array();
					foreach ($files as $file)
					{
						$singleFileArr = array();
						$singleFileArr['filename'] = $file->getFilename();
						$singleFileArr['size'] = $file->getSize();
						$singleFileArr['type'] = $file->getType();
						$singleFileArr['cTime'] = $file->getCTime();
						$fileListArr[] = $singleFileArr;
					}
					
					$Response['Status'] = 0;//200
                    $Response['Msg'] = 'File uploaded successfully.';
                    //$Response['files'] = $fileListArr;
					$Response['FilePath'] = $target_path;
                    $Response['DocumentID'] = $DocumentID;
					
					$getResp = $this->uploadExcelRead($Response);
					if (isset($getResp['firstSheetData'])) {
						$getExcelSheetData = $getResp['firstSheetData'];
						
						//disable previous trim size
						FinanceModel\TrimSizeModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'IS_ACTIVE' => 1));
						
						$getNormalSizeValue = FinanceModel\TrimSizeModel::getTrimSizeValue($getExcelSheetData['normalSizeValue']);						
						$normalSizeArr = array();
						$normalSizeArr['UPLOADED_DOCUMENT_ID'] = $DocumentID;
						$normalSizeArr['CUSTOMER_ID'] = $customerId;
						$normalSizeArr['CUSTOMER_DIVISION_ID'] = $customerDivisionId;
						$getNormalTrimTypeId = FinanceModel\TrimTypeModel::getData(['TRIM_TYPE_ID'], array('TYPE' => 'Normal'));
						if (count($getNormalTrimTypeId) == 1) {
							$NORMAL_TRIM_TYPE_ID = $normalSizeArr['TRIM_TYPE_ID'] = $getNormalTrimTypeId[0]->TRIM_TYPE_ID;
						}
						$normalSizeArr['CREATED_DATE'] = $this->DateTime;
						$normalSizeArr['CREATED_BY'] = $this->loginUserId;
						$getNormalSizeInsertDataArr = FinanceModel\TrimSizeModel::generateInsertDataArray($normalSizeArr, $getNormalSizeValue);
						$normalTrimSizeInsertId = FinanceModel\TrimSizeModel::insertData($getNormalSizeInsertDataArr);
						
						$getLargeSizeValue = FinanceModel\TrimSizeModel::getTrimSizeValue($getExcelSheetData['largeSizeValue']);						
						$largeSizeArr = array();
						$largeSizeArr['UPLOADED_DOCUMENT_ID'] = $DocumentID;
						$largeSizeArr['CUSTOMER_ID'] = $customerId;
						$largeSizeArr['CUSTOMER_DIVISION_ID'] = $customerDivisionId;
						$getLargeTrimTypeId = FinanceModel\TrimTypeModel::getData(['TRIM_TYPE_ID'], array('TYPE' => 'Large'));
						if (count($getLargeTrimTypeId) == 1) {
							$LARGE_TRIM_TYPE_ID = $largeSizeArr['TRIM_TYPE_ID'] = $getLargeTrimTypeId[0]->TRIM_TYPE_ID;
						}
						$largeSizeArr['CREATED_DATE'] = $this->DateTime;
						$largeSizeArr['CREATED_BY'] = $this->loginUserId;
						$getLargeSizeInsertDataArr = FinanceModel\TrimSizeModel::generateInsertDataArray($largeSizeArr, $getLargeSizeValue);
						$largeTrimSizeInsertId = FinanceModel\TrimSizeModel::insertData($getLargeSizeInsertDataArr);
											

						$getFinCurrencyEnum = FinanceModel\CurrencyEnumModel::where('SYMBOL', '<>', '')->select(['SYMBOL'])->get()->toArray();
						if(count($getFinCurrencyEnum) > 0){
							//$currencySearch = $getFinCurrencyEnum;
							$currencySearch = array();
							$currencyReplace = array();
							foreach($getFinCurrencyEnum as $key=>$val){
								$currencySearch[] = $val['SYMBOL'];
								$currencyReplace[] = '';
							}
						}else{
							$currencySearch = array('$');
							$currencyReplace = array('');
						}
						
						$currencyName = trim(str_replace($currencySearch, $currencyReplace, $getExcelSheetData['currencyValue']));
						$currencySymbol = trim(str_replace($currencyName, '', $getExcelSheetData['currencyValue']));
						
						$getFinCurrencyEnumId = FinanceModel\CurrencyEnumModel::where('COUNTRY', $currencyName)->select(['ID'])->first()->toArray();
						$currencyEnumID = NULL;
						if(count($getFinCurrencyEnumId) > 0){
							$currencyEnumID = $getFinCurrencyEnumId['ID'];
						}	
						
						
						$updateFinUploadedDocuments = FinanceModel\UploadedDocumentsModel::find($DocumentID);
						$updateFinUploadedDocuments->CURRENCY_ENUM_ID = $currencyEnumID;
						$updateFinUploadedDocuments->CURRENCY_NAME = $currencyName;
						$updateFinUploadedDocuments->CURRENCY_SYMBOL = $currencySymbol;
						$updateFinUploadedDocuments->VENDOR_NAME = $getExcelSheetData['vendorValue'];
						$updateFinUploadedDocuments->DATE = date("Y-m-d H:i:s", $getExcelSheetData['dateValue']);
						$updateFinUploadedDocuments->REFERENCE_DATA = json_encode($getExcelSheetData);
						$updateFinUploadedDocuments->LAST_MOD_DATE = $this->DateTime;
                        $updateFinUploadedDocuments->LAST_MOD_BY = $this->loginUserId;
						$updateFinUploadedDocuments->save();
						
						if(isset($getExcelSheetData['serviceGroup']) && count($getExcelSheetData['serviceGroup']) > 0){
							foreach($getExcelSheetData['serviceGroup'] as $sGKey => $sGValue){
								$getServiceGroup = FinanceModel\ServiceGroupModel::where(array('SECTION_NAME' => $sGValue,'IS_ACTIVE' => 1))->first();
								if(count($getServiceGroup) > 0){
									$SERVICE_GROUP_ID = $getServiceGroup->SERVICE_GROUP_ID;									
								}else{
									$insertServiceGroup = new FinanceModel\ServiceGroupModel();
									$insertServiceGroup->SECTION_NAME = $sGValue;            
									$insertServiceGroup->CREATED_DATE = $this->DateTime;
									$insertServiceGroup->CREATED_BY = $this->loginUserId;
									$insertServiceGroup->save();
									$SERVICE_GROUP_ID = $insertServiceGroup->SERVICE_GROUP_ID;
								}
								$serviceGroupkey = str_replace(" ", "_-_", strtolower($sGValue));								
								
								if(isset($getExcelSheetData['serviceItem']) && count($getExcelSheetData['serviceItem']) > 0){
									if(count($getExcelSheetData['serviceItem'][$serviceGroupkey]) > 0){
										foreach($getExcelSheetData['serviceItem'][$serviceGroupkey] as $sIKey => $sIValue){
											$getServiceItemName = $sIValue['C'];
											
											$getServiceItem = FinanceModel\ServiceItemsModel::where(array('SERVICE_GROUP_ID' => $SERVICE_GROUP_ID,'ITEM_NAME' => $getServiceItemName,'IS_ACTIVE' => 1))->first();
											if(count($getServiceItem) > 0){
												$SERVICE_ITEM_ID = $getServiceItem->SERVICE_ITEM_ID;									
											}else{
												$Prefix = 'SI';
												$Last_ID = FinanceModel\ServiceItemsModel::max('SERVICE_ITEM_ID');
												
												$insertServiceItem = new FinanceModel\ServiceItemsModel();
												$insertServiceItem->ITEM_NAME = $getServiceItemName; 												
												$insertServiceItem->ITEM_CODE = $Prefix . str_pad($Last_ID + 1, 4, 0, STR_PAD_LEFT);
												$insertServiceItem->SERVICE_GROUP_ID = $SERVICE_GROUP_ID;            
												$insertServiceItem->CREATED_DATE = $this->DateTime;
												$insertServiceItem->CREATED_BY = $this->loginUserId;
												$insertServiceItem->save();
												$SERVICE_ITEM_ID = $insertServiceItem->SERVICE_ITEM_ID;
											}
												
											$currSearch  = array($currencyName, $currencySymbol, '(', ')', '/', '('.$currencyName.''.$currencySymbol.')');
											$currReplace = array('', '', '', '', '', '');
											
											$normalStandardUnit = trim(str_replace($currSearch, $currReplace, $sIValue['D']));
											$normalStandardPricing = trim(str_replace($currSearch, $currReplace, $sIValue['E']));
											$normalComplexUnit = trim(str_replace($currSearch, $currReplace, $sIValue['G']));
											$normalComplexPricing = trim(str_replace($currSearch, $currReplace, $sIValue['H']));
											if(!empty($normalStandardPricing) && empty($normalComplexPricing)){
												$normalComplexUnit = $normalStandardUnit;
												$normalComplexPricing = $normalStandardPricing;
											}
											
											$largeStandardUnit = trim(str_replace($currSearch, $currReplace, $sIValue['J']));
											$largeStandardPricing = trim(str_replace($currSearch, $currReplace, $sIValue['K']));
											$largeComplexUnit = trim(str_replace($currSearch, $currReplace, $sIValue['M']));
											$largeComplexPricing = trim(str_replace($currSearch, $currReplace, $sIValue['N']));
											if(!empty($largeStandardPricing) && empty($largeComplexPricing)){
												$largeComplexUnit = $largeStandardUnit;
												$largeComplexPricing = $largeStandardPricing;
											}
											
											
											$getStandardWorkTypeId = FinanceModel\WorkTypeModel::getData(['WORK_TYPE_ID'], array('TYPE' => 'Standard Work'));
											if (count($getStandardWorkTypeId) == 1) {
												$Standard_WORK_TYPE_ID = $getStandardWorkTypeId[0]->WORK_TYPE_ID;
											}
											
											$getComplexWorkTypeId = FinanceModel\WorkTypeModel::getData(['WORK_TYPE_ID'], array('TYPE' => 'Complex Work'));
											if (count($getComplexWorkTypeId) == 1) {
												$Complex_WORK_TYPE_ID = $getComplexWorkTypeId[0]->WORK_TYPE_ID;
											}
											
											$getUnitEnumId = FinanceModel\UnitEnumModel::getData(['UNIT_ENUM_ID', 'NAME'], array('NAME' => trim(strtolower($normalStandardUnit))));
											if (count($getUnitEnumId) == 1) {
												$UNIT_ENUM_ID = $getUnitEnumId[0]->UNIT_ENUM_ID;
												$UNIT_NAME = $getUnitEnumId[0]->NAME;
											}											
											
											$insertUploadedDocumentItemsData = array();
											$insertUploadedDocumentItemsData['UPLOADED_DOCUMENT_ID'] = $DocumentID;
											$insertUploadedDocumentItemsData['TRIM_TYPE_ID'] = $NORMAL_TRIM_TYPE_ID;
											$insertUploadedDocumentItemsData['WORK_TYPE_ID'] = $Standard_WORK_TYPE_ID;
											$insertUploadedDocumentItemsData['SERVICE_GROUP_ID'] = $SERVICE_GROUP_ID;
											$insertUploadedDocumentItemsData['SERVICE_ITEM_ID'] = $SERVICE_ITEM_ID;
											$insertUploadedDocumentItemsData['UNIT_ENUM_ID'] = $UNIT_ENUM_ID;
											$insertUploadedDocumentItemsData['CURRENCY_ID'] = $currencyEnumID;
											$insertUploadedDocumentItemsData['CUSTOMER_ID'] = $customerId;
											$insertUploadedDocumentItemsData['CUSTOMER_DIVISION_ID'] = $customerDivisionId;
											$insertUploadedDocumentItemsData['START_DATE'] = $startDate;      
											$insertUploadedDocumentItemsData['END_DATE'] = $endDate;
											$insertUploadedDocumentItemsData['CREATED_DATE'] = $this->DateTime;
											$insertUploadedDocumentItemsData['CREATED_BY'] = $this->loginUserId;
											$insertUploadedDocumentItemsData['CURRENT_STATUS'] = 0;
											$insertUploadedDocumentItemsData['IS_ACTIVE'] = 1;
											
											$prev_date = date('Y-m-d', strtotime($startDate .' -1 day'));
											
											if(!empty($normalStandardPricing)){
												/*$getServiceItemRateNorStd = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();//->toArray();
												if (count($getServiceItemRateNorStd) > 0) {	
													$getRespServiceItemRateNorStd = FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 1, 'END_DATE' => $prev_date, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateNorStd->SERVICE_ITEM_RATE_ID));
												}*/
												
												$getServiceItemRateNorStd = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'START_DATE' => $startDate, 'END_DATE' => $endDate, 'CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();//->toArray();
												if (count($getServiceItemRateNorStd) > 0) {	
													$getRespServiceItemRateNorStd = FinanceModel\ServiceItemRateModel::updateData(array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateNorStd->SERVICE_ITEM_RATE_ID, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
												}										
												
												$insertUDIDarr = FinanceModel\ServiceItemRateModel::generateInsertDataArray($insertUploadedDocumentItemsData, $normalStandardPricing, "Normal", "Standard", $currencySymbol, $normalComplexPricing);
												FinanceModel\ServiceItemRateModel::insertData($insertUDIDarr);
											}
											if(!empty($normalComplexPricing)){
												$insertUploadedDocumentItemsData['TRIM_TYPE_ID'] = $NORMAL_TRIM_TYPE_ID;
												$insertUploadedDocumentItemsData['WORK_TYPE_ID'] = $Complex_WORK_TYPE_ID;
												/*$getServiceItemRateNorCom = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateNorCom) > 0) {		
													FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 1, 'END_DATE' => $prev_date, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateNorCom->SERVICE_ITEM_RATE_ID));
												}*/
												$getServiceItemRateNorCom = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'START_DATE' => $startDate, 'END_DATE' => $endDate, 'CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateNorCom) > 0) {		
													FinanceModel\ServiceItemRateModel::updateData(array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $NORMAL_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateNorCom->SERVICE_ITEM_RATE_ID, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
												}
												
												$insertUDIDarr = FinanceModel\ServiceItemRateModel::generateInsertDataArray($insertUploadedDocumentItemsData, $normalComplexPricing, "Normal", "Complex", $currencySymbol, $normalStandardPricing);
												FinanceModel\ServiceItemRateModel::insertData($insertUDIDarr);
											}
											if(!empty($largeStandardPricing)){
												$insertUploadedDocumentItemsData['TRIM_TYPE_ID'] = $LARGE_TRIM_TYPE_ID;
												$insertUploadedDocumentItemsData['WORK_TYPE_ID'] = $Standard_WORK_TYPE_ID;
												/*$getServiceItemRateLarStd = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateLarStd) > 0) {	
													FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 1, 'END_DATE' => $prev_date, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateLarStd->SERVICE_ITEM_RATE_ID));
												}*/
												$getServiceItemRateLarStd = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'START_DATE' => $startDate, 'END_DATE' => $endDate, 'CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateLarStd) > 0) {	
													FinanceModel\ServiceItemRateModel::updateData(array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Standard_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateLarStd->SERVICE_ITEM_RATE_ID, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
												}
												
												$insertUDIDarr = FinanceModel\ServiceItemRateModel::generateInsertDataArray($insertUploadedDocumentItemsData, $largeStandardPricing, "Large", "Standard", $currencySymbol, $largeComplexPricing);
												FinanceModel\ServiceItemRateModel::insertData($insertUDIDarr);
											}
											if(!empty($largeComplexPricing)){
												$insertUploadedDocumentItemsData['TRIM_TYPE_ID'] = $LARGE_TRIM_TYPE_ID;
												$insertUploadedDocumentItemsData['WORK_TYPE_ID'] = $Complex_WORK_TYPE_ID;
												/*$getServiceItemRateLarCom = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateLarCom) > 0) {													
													FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 1, 'END_DATE' => $prev_date, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateLarCom->SERVICE_ITEM_RATE_ID));
												}*/
												$getServiceItemRateLarCom = FinanceModel\ServiceItemRateModel::where(array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'START_DATE' => $startDate, 'END_DATE' => $endDate, 'CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1))->orderBy('SERVICE_ITEM_RATE_ID', 'desc')->first();
												if (count($getServiceItemRateLarCom) > 0) {													
													FinanceModel\ServiceItemRateModel::updateData(array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId ), array('TRIM_TYPE_ID' => $LARGE_TRIM_TYPE_ID, 'WORK_TYPE_ID' => $Complex_WORK_TYPE_ID, 'SERVICE_GROUP_ID' => $SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $SERVICE_ITEM_ID, 'CUSTOMER_ID' => $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_ITEM_RATE_ID'=>$getServiceItemRateLarCom->SERVICE_ITEM_RATE_ID, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
												}
												
												$insertUDIDarr = FinanceModel\ServiceItemRateModel::generateInsertDataArray($insertUploadedDocumentItemsData, $largeComplexPricing, "Large", "Complex", $currencySymbol, $largeStandardPricing);
												FinanceModel\ServiceItemRateModel::insertData($insertUDIDarr);
											}
										}
									}else{
										$Response['Status'] = 1;
										$Response['Msg'] = 'Failure';
										$Response['ErrorMsg'] = "Service Item row data array is empty.";
									}
								}else{
									$Response['Status'] = 1;
									$Response['Msg'] = 'Failure';
									$Response['ErrorMsg'] = "Service Item data array is empty.";
								}								
							}						
						}else{
							$Response['Status'] = 1;
							$Response['Msg'] = 'Failure';
							$Response['ErrorMsg'] = "Service group data array is empty.";
						}						
					}else{
						$Response['Status'] = 1;
						$Response['Msg'] = 'Failure';
						$Response['ErrorMsg'] = "Excel Data not read.";
					}	
					}else{
						$Response['Status'] = 1;
						$Response['Msg'] = 'Failure';
						$Response['ErrorMsg'] = "Already exists this date range. Please change the start date and end date.";
					}
				} catch (\Exception $e) {
                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Failure';
                    $Response['ErrorMsg'] = $e->getMessage().". Line No:".$e->getLine();
                }
			}
		} else {
            $Response['Status'] = 1;
            $Response['Msg'] = 'Failure';
			$Response['ErrorMsg'] = 'File Not Found.';
        }
		
		if ($Response['Status'] == 1) {
			DB::rollback();            
        } else {
			DB::commit();
        }      
		return response()->json($Response);
    }
	
	public function uploadExcelRead($Response){
		$FilePath = $Response['FilePath'];

		PHPExcel_Calculation::getInstance()->clearCalculationCache();
		PHPExcel_Calculation::getInstance()->disableCalculationCache();

		$ResponseData = array();

		Excel::load($FilePath, function($doc) use ($Response, $FilePath, &$ResponseData) {

			$sheetNames = $doc->getSheetNames();
			$clientSheetNames = array();
			$clientSheetNames[] = $sheetNames[0];//'Books FS 2018';
			//$clientSheetNames[] = $sheetNames[1];//'Books FS 2017';

			$SheetDiff = array_diff($clientSheetNames, $sheetNames);
			if (count($SheetDiff) == 0) {
				$sheet0 = $doc->getSheetByName($clientSheetNames[0]);
				//$sheet1 = $doc->getSheetByName($clientSheetNames[1]);
				$ResponseData['sheet0'] = $sheet0;
				//$ResponseData['sheet1'] = $sheet1;
							
				$firstSheetData = array();
				
				$firstSheetData['B2'] =  trim($this->getExactExcelCellValue($sheet0, 'B', 2)); 
				$firstSheetData['D2'] =  trim($this->getExactExcelCellValue($sheet0, 'D', 2)); 
				
				$getTrimSizeGroupNormal = trim($this->getExactExcelCellValue($sheet0, 'D', 4));
				if(strtolower($getTrimSizeGroupNormal) === 'Trim Size Group "Normal"' || strpos(strtolower($getTrimSizeGroupNormal), "trim size group") !== false || strpos(strtolower($getTrimSizeGroupNormal), "normal") !== false){
					$firstSheetData['normalSize'] = $getTrimSizeGroupNormal;
				}
				
				$getTrimSizeGroupNormal = trim($this->getExactExcelCellValue($sheet0, 'J', 4));
				if(strtolower($getTrimSizeGroupNormal) === 'Trim Size Group "Large"' || strpos(strtolower($getTrimSizeGroupNormal), "trim size group") !== false || strpos(strtolower($getTrimSizeGroupNormal), "large") !== false){
					$firstSheetData['largeSize'] = $getTrimSizeGroupNormal;
				}
				
				$normalStandardWork = array();
				$normalComplexWork = array();
				$largeStandardWork = array();
				$largeComplexWork = array();

				if(strtolower(trim($this->getExactExcelCellValue($sheet0, 'B', 4))) === "currency"){
					$firstSheetData['currencyKey'] = trim($this->getExactExcelCellValue($sheet0, 'B', 4));
					$firstSheetData['currencyValue'] = trim($this->getExactExcelCellValue($sheet0, 'C', 4));
				}
				if(strtolower(trim($this->getExactExcelCellValue($sheet0, 'B', 5))) === "vendor"){
					$firstSheetData['vendorKey'] = trim($this->getExactExcelCellValue($sheet0, 'B', 5));
					$firstSheetData['vendorValue'] = trim($this->getExactExcelCellValue($sheet0, 'C', 5));
				}
				if(strtolower(trim($this->getExactExcelCellValue($sheet0, 'B', 6))) === "date"){
					$firstSheetData['dateKey'] = strtotime(trim($this->getExactExcelCellValue($sheet0, 'B', 6)));
					$firstSheetData['dateValue'] = strtotime(trim($this->getExactExcelCellValue($sheet0, 'C', 6)));
				}
				
				$firstSheetData['normalSizeValue'] = trim($this->getExactExcelCellValue($sheet0, 'D', 5));
				$firstSheetData['largeSizeValue'] = trim($this->getExactExcelCellValue($sheet0, 'J', 5));
				
				$firstSheetData['D8'] =  trim($this->getExactExcelCellValue($sheet0, 'D', 8)); 
				$firstSheetData['G8'] =  trim($this->getExactExcelCellValue($sheet0, 'G', 8)); 
				$firstSheetData['J8'] =  trim($this->getExactExcelCellValue($sheet0, 'J', 8)); 
				$firstSheetData['M8'] =  trim($this->getExactExcelCellValue($sheet0, 'M', 8)); 
				$firstSheetData['B9'] =  trim($this->getExactExcelCellValue($sheet0, 'B', 9)); 
				$firstSheetData['C9'] =  trim($this->getExactExcelCellValue($sheet0, 'C', 9)); 
				
				//standard Units
				$firstSheetData['D9'] =  trim($this->getExactExcelCellValue($sheet0, 'D', 9));													
				$firstSheetData['J9'] =  trim($this->getExactExcelCellValue($sheet0, 'J', 9));
				//standard Pricing
				$firstSheetData['E9'] =  trim($this->getExactExcelCellValue($sheet0, 'E', 9));
				$firstSheetData['K9'] =  trim($this->getExactExcelCellValue($sheet0, 'K', 9));
				 
				//complex Units
				$firstSheetData['G9'] =  trim($this->getExactExcelCellValue($sheet0, 'G', 9));				
				$firstSheetData['M9'] =  trim($this->getExactExcelCellValue($sheet0, 'M', 9));
				//complex Pricing
				$firstSheetData['H9'] =  trim($this->getExactExcelCellValue($sheet0, 'H', 9));
				$firstSheetData['N9'] =  trim($this->getExactExcelCellValue($sheet0, 'N', 9));
				
				
				$highestRow = $sheet0->getHighestRow();
                $highestColumn = $sheet0->getHighestColumn();
				
				$ratedata = array();
                $breakTotalRowNo = 0;
				$twoRowEmptyCnt = 0;
                $notFindItemArr = array();			

				$serviceGroupArr = array();
				$serviceGroupArrKey = 0;
				$serviceTempItemArr = array();
				$serviceItemArr = array();
				$remarksCol = 0;
				$remarksColRowNo = 0;
				$remarksTextRowNo = 0;
				$remarksText = '';

                for ($cellRow = 11; $cellRow <= $highestRow; $cellRow++) {
					
					$getBColValue =  trim($this->getExactExcelCellValue($sheet0, 'B', $cellRow));//echo $getBColValue;
					$getCColValue =  trim($this->getExactExcelCellValue($sheet0, 'C', $cellRow));//echo "-----".$getCColValue."-----";
					$getDColValue =  trim($this->getExactExcelCellValue($sheet0, 'D', $cellRow));
					$incCellRow = $cellRow+1;
					$getNextBColValue =  trim($this->getExactExcelCellValue($sheet0, 'B', $incCellRow));
					$getNextCColValue =  trim($this->getExactExcelCellValue($sheet0, 'C', $incCellRow));
					$getNextDColValue =  trim($this->getExactExcelCellValue($sheet0, 'D', $incCellRow));
					
					
					if (empty($getBColValue['B'.$cellRow]) && empty($getBColValue['C'.$cellRow]) && empty($getBColValue['D'.$cellRow]) && empty($getBColValue['B'.$incCellRow]) && empty($getBColValue['C'.$incCellRow]) && empty($getBColValue['D'.$incCellRow]) && $breakTotalRowNo > 3) {                       
                        $breakTotalRowNo = $cellRow + 1;
                        break;
                    }else if($remarksCol == 1 && !empty($getBColValue)){
						$remarksText = $getBColValue;
						$remarksTextRowNo = $cellRow;
						break;
					}else if (!empty($getBColValue) && empty($getCColValue) && strtolower($getBColValue) == 'remarks'){
						$remarksCol = 1;
						$remarksColRowNo = $cellRow;
					}else if (empty($getBColValue) && !empty($getCColValue) && empty($getDColValue)){
						$serviceGroupArr[] = $getCColValue;
						$serviceGroupArrKey = array_search($getCColValue,$serviceGroupArr);
					}else if (empty($getBColValue) && !empty($getCColValue) && !empty($getDColValue)){
						$serviceTempItemArr = array();
						$serviceTempItemArr['C'] = $getCColValue;
						$serviceTempItemArr['D'] = $getDColValue;
						$serviceTempItemArr['E'] = trim($this->getExactExcelCellValue($sheet0, 'E', $cellRow));
						$serviceTempItemArr['G'] = trim($this->getExactExcelCellValue($sheet0, 'G', $cellRow));
						$serviceTempItemArr['H'] = trim($this->getExactExcelCellValue($sheet0, 'H', $cellRow));
						$serviceTempItemArr['J'] = trim($this->getExactExcelCellValue($sheet0, 'J', $cellRow));
						$serviceTempItemArr['K'] = trim($this->getExactExcelCellValue($sheet0, 'K', $cellRow));
						$serviceTempItemArr['M'] = trim($this->getExactExcelCellValue($sheet0, 'M', $cellRow));
						$serviceTempItemArr['N'] = trim($this->getExactExcelCellValue($sheet0, 'N', $cellRow));
						
						$key = str_replace(" ", "_-_", strtolower($serviceGroupArr[$serviceGroupArrKey]));
						$serviceItemArr[$key][] = $serviceTempItemArr;
						
					}
				}
				
				$firstSheetData['serviceGroup'] = $serviceGroupArr;
				$firstSheetData['serviceItem'] = $serviceItemArr;
				$firstSheetData['remarksText'] = $remarksText;
				$firstSheetData['remarksColRowNo'] = $remarksColRowNo;
				$firstSheetData['remarksTextRowNo'] = $remarksTextRowNo;
				
				$ResponseData['firstSheetData'] = $firstSheetData;
				
			} else {
				$ResponseData['Status'] = 1;
				$ResponseData['Msg'] = 'Invalid Excel';
			}
		});					
		
		return $ResponseData;
        exit;
	}
	
	/**
     * List Uploaded files
     *
     * @return array
     */
    public function listUploadedFiles()
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.UPLOAD_PRICING'),$data);
        $data['pageTitle']  = 	'Pricing Grid Uploaded Files List';
        $data['pageName']   =   'Pricing Grid Uploaded Files List';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        return view('finance.pricinggrid.pricingGridUploadedFilesListView')->with($data);
    }
	
	public function getAllUploadFilesList(Request $request){
	
		if ($request->input() && $request->ajax()) {
            $Req = (object) $request->input();

            $columnArray = array();
            $columnArray[] = 'UPLOADED_DOCUMENT_ID';
            $columnArray[] = 'ORG_FILENAME';
            $columnArray[] = 'CURRENCY_NAME';
            $columnArray[] = 'CURRENCY_SYMBOL';
            $columnArray[] = 'VENDOR_NAME';
            //$columnArray[] = 'DATE';
            $columnArray[] = 'START_DATE';
            $columnArray[] = 'END_DATE';
            $columnArray[] = 'CREATED_DATE';
            $columnArray[] = 'CUSTOMER_ID';
            $columnArray[] = 'CUSTOMER_DIVISION_ID';
			
			/* Useful this($_POST) Variables coming from the plugin */
			$orderColumn = $orderByColumnIndex = $Req->order[0]['column'];// index of the sorting column (0 index based - i.e. 0 is the first record)
			//$orderBy = $Req->columns[$orderByColumnIndex]['data'];//Get name of the sorting column from its index
			//$orderType = $Req->order[0]['dir']; // ASC or DESC
            $sorting = $Req->order[0]['dir'];//echo $columnArray[$orderByColumnIndex];echo $sorting;die;
            $start = $Req->start;//Paging first record indicator.
            $length = $Req->length;//Number of records that the table can display in the current draw
			$draw = $Req->draw;//counter used by DataTables to ensure that the Ajax returns from server-side processing requests are drawn in sequence by DataTables
			/* END of POST variables */
			
            $searchStr = $Req->search['value'];
			
			$getAllPostData = $request->all();
			$otherSearchArray = array();
			if(isset($getAllPostData['customerId']) && !empty($getAllPostData['customerId'])){
				$otherSearchArray['CUSTOMER_ID'] = trim($getAllPostData['customerId']);	
			}
			if(isset($getAllPostData['customerDivisionId']) && !empty($getAllPostData['customerDivisionId'])){
				$otherSearchArray['CUSTOMER_DIVISION_ID'] = trim($getAllPostData['customerDivisionId']);	
			}
			
			$recordsTotal = FinanceModel\UploadedDocumentsModel::getDataWithSearch($searchStr, $otherSearchArray, $columnArray, $orderColumn, $sorting, $start, $length, true);
			$recordsFiltered = FinanceModel\UploadedDocumentsModel::getDataWithSearch($searchStr, $otherSearchArray, $columnArray, $orderColumn, $sorting, $start, $length, false, true);
			$data = FinanceModel\UploadedDocumentsModel::getDataWithSearch($searchStr, $otherSearchArray, $columnArray, $orderColumn, $sorting, $start, $length);
			
			$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frl.IS_FINAL', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();

			$currentStatusArray = array(10=>1, 1=>0);
			
			foreach($data as $key => $val){
				$view = $edit = $delete = '';
				$encryptUploadedFileId = FinanceModel\HelperModel::get_encrypt($val->UPLOADED_DOCUMENT_ID);
				
				$edit = '<button class="btn btn-xs btn-info pointer" ng-click="uploadedFileEdit('.$encryptUploadedFileId.')" ><i class="ace-icon fa-download bigger-120"></i></button>';//fa-file-excel-o	


				$startDate = date("Y-m-d H:i:s", strtotime($val->START_DATE));
				$endDate = date("Y-m-d H:i:s", strtotime($val->END_DATE));				
					
				$getPendingServiceItemRateDataCnt = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 0)->where('CUSTOMER_ID', $val->CUSTOMER_ID )->where('CUSTOMER_DIVISION_ID', $val->CUSTOMER_DIVISION_ID )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->count();	
				$val->downloadBtn = "";
				$pendingApprovedBtn = '';
				if($getPendingServiceItemRateDataCnt > 0){
					$val->approvedLink = $val->editLink = "fin/pricinggrid/updatePricing/".$val->CUSTOMER_ID."/".$val->CUSTOMER_DIVISION_ID."/1010/".strtotime($val->START_DATE)."-".strtotime($val->END_DATE);
					$pendingApprovedBtn .= '<button class="btn btn-xs btn-warning pointer editUploadFile" ng-click="editUploadFile(\''.$val->approvedLink.'\')" title="Edit Pending Pricing List" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i> Edit Pending Pricing List</button>&nbsp;&nbsp;';
					
				}//else 
				if($getApprovalListQueryCnt > 0){
					foreach ($getApprovalListQueryData as $key1 => $val1) {
						$getApprovedServiceItemRateDataCnt = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', (int)$val1->REQUEST_LEVEL_ID)->where('CUSTOMER_ID', $val->CUSTOMER_ID )->where('CUSTOMER_DIVISION_ID', $val->CUSTOMER_DIVISION_ID )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->count();
						if($getApprovedServiceItemRateDataCnt > 0){
							$val->pendingLink = $val->editLink = "fin/pricinggrid/updatePricing/".$val->CUSTOMER_ID."/".$val->CUSTOMER_DIVISION_ID."/".(int)$val1->REQUEST_LEVEL_ID."/".strtotime($val->START_DATE)."-".strtotime($val->END_DATE);
							$pendingApprovedBtn .= '<button class="btn btn-xs btn-success pointer editUploadFile" ng-click="editUploadFile(\''.$val->pendingLink.'\')" title="Edit Approved Pricinig List" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i> Edit Approved Pricinig List</button>';
							$downloadLink = "fin/pricinggrid/pricing/download/".$val->CUSTOMER_ID."/".$val->CUSTOMER_DIVISION_ID."/".(int)$val1->REQUEST_LEVEL_ID."/".strtotime($val->START_DATE)."/".strtotime($val->END_DATE);
					
							$val->downloadBtn = '<button class="btn btn-xs btn-info pointer downloadExcelFile" ng-click="downloadPricingList(\''.$downloadLink.'\')" title="Download" ><i class="ace-icon fa fa-download bigger-120"></i></button>';
						}
					}
				}
				/* if($this->chkPricingGridDataAvailable($val->CUSTOMER_ID, $val->CUSTOMER_DIVISION_ID, $currentStatusArray[10], strtotime($val->START_DATE), strtotime($val->END_DATE) )){
					$val->pendingLink = $val->editLink = "fin/pricinggrid/updatePricing/".$val->CUSTOMER_ID."/".$val->CUSTOMER_DIVISION_ID."/".$currentStatusArray[10]."/".strtotime($val->START_DATE)."-".strtotime($val->END_DATE);
					$pendingApprovedBtn .= '<button class="btn btn-xs btn-success pointer editUploadFile" ng-click="editUploadFile(\''.$val->pendingLink.'\')" title="Pending" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i> Pending</button>';
				}//else 
				if($getApprovalListQueryCnt > 0){
					foreach ($getApprovalListQueryData as $key1 => $val1) {
						if($this->chkPricingGridDataAvailable($val->CUSTOMER_ID, $val->CUSTOMER_DIVISION_ID, $currentStatusArray[(int)$val1->REQUEST_LEVEL_ID], strtotime($val->START_DATE), strtotime($val->END_DATE) )){
							$val->approvedLink = $val->editLink = "fin/pricinggrid/updatePricing/".$val->CUSTOMER_ID."/".$val->CUSTOMER_DIVISION_ID."/".$currentStatusArray[(int)$val1->REQUEST_LEVEL_ID]."/".strtotime($val->START_DATE)."-".strtotime($val->END_DATE);
							$pendingApprovedBtn .= '<button class="btn btn-xs btn-success pointer editUploadFile" ng-click="editUploadFile(\''.$val->approvedLink.'\')" title="Approved" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i> Approved</button>';
						}
					}
				} */
				$val->pendingApprovedBtn = $pendingApprovedBtn;
								
				$val->DATE = date("Y-m-d", strtotime($val->DATE));
				$val->START_DATE = date("Y-m-d", strtotime($val->START_DATE));
				$val->END_DATE = date("Y-m-d", strtotime($val->END_DATE));
				$val->CREATED_DATE = date("Y-m-d", strtotime($val->CREATED_DATE));
				$val->GROUP_KEY = $val->CUSTOMER_NAME."_".$val->START_DATE."_".$val->END_DATE;
				$val->ACTION = $edit . ' ' . $delete;
				$data[$key] = $val;
			}

            $Response = array();
            $Response["draw"] = $_POST['draw'];
            $Response["recordsTotal"] = $recordsTotal;
            $Response["recordsFiltered"] = count($recordsFiltered);
            $Response["data"] = $data;
            return response()->json($Response);
        }	
	}
	
	public function downloadFile(Request $request, $UploadedDocumentId){
		$resp = DB::table('fin_uploaded_documents as fud')
                ->where('fud.UPLOADED_DOCUMENT_ID', $UploadedDocumentId)
                ->first();

        $DOCUMENT_PATH = $resp->DOCUMENT_PATH."/".$resp->RENAME_FILENAME;
		$ResponseData = array();
		$ResponseData['Status'] = 0;
		$ResponseData['Msg'] = "Success";
		$ResponseData['DOCUMENT_PATH'] = $DOCUMENT_PATH;
		return response()->json($ResponseData);
	}
	
    /**
     * Delete existing file from the server
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function delete(Request $request, $UploadedDocumentId)
    {
        Storage::delete(__DIR__ . '/../../../image_uploads/' . $UploadedDocumentId);
        File::find($request->input('id'))->delete();
        return response()->json(['errors' => [], 'message' => 'File Successfully deleted!', 'status' => 200], 200);
    }
	
	public function editUploadedFile(Request $request, $UploadedDocumentId){
		
		$data               =   array();
                $this->displayMenuName(Config::get('menuconstants.MENU.REPORT_ARRIVAL'),$data);
        $data['pageTitle']  = 	'Pricing Grid Edit Uploaded File';
        $data['pageName']   =   'Pricing Grid Edit Uploaded File';
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data['UploadedDocumentId']  =   $UploadedDocumentId;
		
        return view('finance.pricinggrid.pricingGridEditView')->with($data);
	}
	
	public function editFileData(Request $request, $customerId = null, $customerDivisionId = null, $processTypeId = null, $startDate = null, $endDate = null){
		//$finalData = array();
		//$finalData['editData'] = $this->generatePricingGridData($customerId, $customerDivisionId, $startDate, $endDate);
		//$finalData['approveData'] = $this->generatePricingGridData($customerId, $customerDivisionId, $startDate, $endDate, 'approve');
		$finalData = $this->generatePricingGridData($customerId, $customerDivisionId, $processTypeId, $startDate, $endDate);
		
		/*$query = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('START_DATE', '>=', $this->DateTime)->orwhereRaw('"'.$this->DateTime.'" between `START_DATE` and `END_DATE`')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);//->where('IS_ACTIVE', 1 )
		$finalData['variousPricingList'] = array();
		$currentDate = date("Y-m-d", time());
		$currentDateRangeIndex = 0;
		if(count($query) > 0){
			$i = 0;
			foreach($query as $val){				
				if (($currentDate > date("Y-m-d", strtotime($val->START_DATE))) && ($currentDate < date("Y-m-d", strtotime($val->END_DATE))))
				{
					$currentDateRangeIndex = $i;				  
				}
				$finalData['variousPricingList'][] = array( 'START_DATE' => date("Y-m-d", strtotime($val->START_DATE)), 'END_DATE' => date("Y-m-d", strtotime($val->END_DATE)), 'UNIX_START_DATE'=>strtotime($val->START_DATE), 'UNIX_END_DATE'=>strtotime($val->END_DATE));
				$i++;
			}
		}*/
		
		$Response = array();
        $Response["data"] = $finalData;
        return response()->json($Response);
	}
	
	public function generatePricingGridData($customerId, $customerDivisionId, $processTypeId = null, $startDate = null, $endDate = null ){
		//$getServiceItemRateData = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->whereRaw('"'.$this->DateTime.'" between `START_DATE` and `END_DATE`')->get();
		$startDate = date("Y-m-d H:i:s", $startDate);
		$endDate = date("Y-m-d H:i:s", $endDate);
		
		$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frl.IS_FINAL', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();
					
		$currentStatusArr = array();
		$currentStatusFinal = 0;
		if($getApprovalListQueryCnt > 0){
			foreach ($getApprovalListQueryData as $key => $val) {
				$currentStatusArr[] = $val->REQUEST_LEVEL_ID;
				if(!empty($val->IS_FINAL) && (int)$val->IS_FINAL == 1){
					$currentStatusFinal = (int)$val->REQUEST_LEVEL_ID;
				}
			}
		}
		
		/*if($processTypeId == '10'){
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', $currentStatusFinal)->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)	(int)$currentStatusArr[0]		
		}else{
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', ((int)$processTypeId - 1))->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)
		}*/
		if($processTypeId == '1010'){
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 0)->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)
		}else{
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', (int)$processTypeId)->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)	(int)$currentStatusArr[0]
		}
		
		$getData = array();
		$serviceGroupArray = array();
		$serviceItemArray = array();
		$serviceItemCurrentStatusArray = array();
		$currentStatus = '';
		$currencyId = "";
		$uploadDocumentID = 0;
		if(count($getServiceItemRateData) > 0){
			foreach($getServiceItemRateData as $key=>$val){
				$currencyId = $val->CURRENCY_ID;
				if(!isset($serviceGroupArray[$val->SERVICE_GROUP_ID])){// && $val->IS_ACTIVE == 1 && $val->CURRENT_STATUS == 1
					$serviceGroupArray[$val->SERVICE_GROUP_ID] = $val->SERVICE_GROUP_ID;
				}
				if(!isset($serviceItemArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID])){
					$serviceItemArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID] = $val->SERVICE_ITEM_ID;
				}
				if(!isset($serviceItemCurrentStatusArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID])){
					$serviceItemCurrentStatusArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID] = $val->SERVICE_ITEM_ID;
					$currentStatus = 0;
				}				
				$uploadDocumentID = $val->UPLOADED_DOCUMENT_ID;				
			}
		}
		
		$finalData = array();
		if(count($serviceGroupArray) > 0 && count($serviceItemArray) > 0){
		
			$finalData['fullService'] = "FULL SERVICE";
			$finalData['trimSize'] = "Trimsizes";
			
			$finCurrencyEnumResp = FinanceModel\CurrencyEnumModel::getData(['currency_enum.*'], array('ID' => (int)$currencyId));
			if (count($finCurrencyEnumResp) == 1) {
				$finalData['currency'] = $finCurrencyEnumResp[0]->COUNTRY."".$finCurrencyEnumResp[0]->SYMBOL;
				$finalData['currencyName'] = $finCurrencyEnumResp[0]->COUNTRY;
				$finalData['currencySymbol'] = $finCurrencyEnumResp[0]->SYMBOL;
			}
			
			$finUploadedDocumentsResp = FinanceModel\UploadedDocumentsModel::getData(['fin_uploaded_documents.*'], array('UPLOADED_DOCUMENT_ID' => (int)$uploadDocumentID));
			if (count($finUploadedDocumentsResp) == 1) {
				$getReferenceData = json_decode($finUploadedDocumentsResp[0]->REFERENCE_DATA);
				$finalData['fullService'] = $getReferenceData->B2;
				$finalData['trimSize'] = $getReferenceData->D2;
				//$finalData['currency'] = $getReferenceData->currencyValue;
				$finalData['vendor'] = $getReferenceData->vendorValue;
				$finalData['date'] = date("M.d,Y", $getReferenceData->dateValue);
				$finalData['normalSize'] = $getReferenceData->normalSize;
				$finalData['normalSizeValue'] = $getReferenceData->normalSizeValue;
				$finalData['largeSize'] = $getReferenceData->largeSize;
				$finalData['largeSizeValue'] = $getReferenceData->largeSizeValue;
				$finalData['standardWork'] = $getReferenceData->D8;
				$finalData['complexWork'] = $getReferenceData->G8;
				$finalData['unit'] = $getReferenceData->D9;
				$finalData['pricingPerUnit'] = $getReferenceData->E9;
				$finalData['pricingHeader1'] = $getReferenceData->B9;
				$finalData['pricingHeader2'] = $getReferenceData->C9;
				$finalData['currentStatus'] = $currentStatus;
				
				$serviceItemData = array();
				$currentServiceGroupId = 0;
				$currentServiceItemId = 0;
				$currentRowId = 0;
				foreach($serviceItemArray as $key=>$val){			
						
					$finServiceGroupResp = FinanceModel\ServiceGroupModel::getData(['fin_service_group.*'], array('SERVICE_GROUP_ID' => (int)$key));
					if (count($finServiceGroupResp) == 1) {
						
						if($currentServiceGroupId != $finServiceGroupResp[0]->SERVICE_GROUP_ID ){
							$currentServiceGroupName = $finServiceGroupResp[0]->SECTION_NAME;
							$serviceItemData[] = array(
								'col1' => '',
								'col2' => $currentServiceGroupName,
								'col2_glAccountCode' => '',
								'col2_glAccountCodetype' => 'hidden',
								'col2_glAccountCodevalue' => 'empty',								
								'col3' => '',
								'col4' => '',
								'col4type' => 'hidden',
								'col4value' => 'empty',
								'col5' => '',
								'col6' => '',
								'col6type' => 'hidden',
								'col6value' => 'empty',
								'col7' => '',
								'col8' => '',
								'col8type' => 'hidden',
								'col9value' => 'empty',
								'col9' => '',
								'col10' => '',
								'col10type' => 'hidden',
								'col10value' => 'empty',
								'col1class' => '',
								'col2class' => 'meta-head5 textAlignLeft fontWeight',
								'col3class' => 'meta-head5 textAlignCenter fontWeight',
								'col4class' => 'meta-head5 textAlignCenter fontWeight',
								'col5class' => 'meta-head5 textAlignCenter fontWeight',
								'col6class' => 'meta-head5 textAlignCenter fontWeight',
								'col7class' => 'meta-head5 textAlignCenter fontWeight',
								'col8class' => 'meta-head5 textAlignCenter fontWeight',
								'col9class' => 'meta-head5 textAlignCenter fontWeight',
								'col10class' => 'meta-head5 textAlignCenter fontWeight',
								'validateCol' => 0
							);
							
							$currentServiceGroupId = (int) $finServiceGroupResp[0]->SERVICE_GROUP_ID;
						}					
					}
					
					foreach($val as $sK=>$sV){
						$finServiceItemsResp = FinanceModel\ServiceItemsModel::getData(['fin_service_items.*'], array('SERVICE_ITEM_ID' => (int)$sV));
						if (count($finServiceItemsResp) > 0 ) {
							foreach($finServiceItemsResp as $sikey=>$sival){
								//if($currentServiceItemId != $sival->SERVICE_ITEM_ID ){
									$currentServiceItemId = $sival->SERVICE_ITEM_ID;
									//$currentserviceItemRateId = $serviceItemRateIdArray[$currentServiceGroupId][$currentServiceItemId];
									
									$rowItemData = array();							
									$rowItemData['showCheckBox'] = true;
									$rowItemData['checkBoxChecked'] = false;
									$rowItemData['enableRow'] = false;
									$rowItemData['col1'] = '';
									$rowItemData['col2'] = $sival->ITEM_NAME;
									$rowItemData['col2_glAccountCode'] = $sival->ACCOUNT_CODE;//$getData[0]['currencySymbol']." ".
									$rowItemData['col2_glAccountCodeId'] = $currentServiceItemId;
									$rowItemData['col2_glAccountCodetype'] = 'text';
									$rowItemData['col2_glAccountCodevalue'] = $rowItemData['col2_glAccountCode'];
									
									//'SERVICE_ITEM_RATE_ID' => $currentserviceItemRateId, 
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1), $this->DateTime);
									if($processTypeId == '1010'){
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => 0, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									}else{
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => (int)$processTypeId, 'START_DATE' => $startDate, 'END_DATE' => $endDate));										
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									if (count($finUploadedDocumentItemsResp) == 1 ) {
										$finUnitEnumResp = FinanceModel\UnitEnumModel::getData(['fin_unit_enum.*'], array('UNIT_ENUM_ID' => (int)$finUploadedDocumentItemsResp[0]->UNIT_ENUM_ID));
										if (count($finUnitEnumResp) == 1) {
											$rowItemData['col3'] = "/".$finUnitEnumResp[0]->NAME." (".$finalData['currencyName']."".$finalData['currencySymbol'].")";
											$rowItemData['col4'] = $finUploadedDocumentItemsResp[0]->RATE;//$getData[0]['currencySymbol']." ".
											$rowItemData['col4Id'] = $finUploadedDocumentItemsResp[0]->SERVICE_ITEM_RATE_ID;
											$rowItemData['col4type'] = 'text';
											$rowItemData['col4value'] = $rowItemData['col4'];
										}								
									}else{
										$rowItemData['col3'] = '';
										$rowItemData['col4'] = '';
										$rowItemData['col4type'] = 'hidden';
										$rowItemData['col4value'] = 'empty';
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId,  'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>1 , 'WORK_TYPE_ID'=> 2, 'IS_ACTIVE' => 1), $this->DateTime);
									if($processTypeId == '1010'){
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 2, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => 0, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									}else{
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 1, 'WORK_TYPE_ID' => 2, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => (int)$processTypeId, 'START_DATE' => $startDate, 'END_DATE' => $endDate));										
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId,  'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>1 , 'WORK_TYPE_ID'=> 2, 'IS_ACTIVE' => 1, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									if (count($finUploadedDocumentItemsResp) == 1 ) {
										$finUnitEnumResp = FinanceModel\UnitEnumModel::getData(['fin_unit_enum.*'], array('UNIT_ENUM_ID' => (int)$finUploadedDocumentItemsResp[0]->UNIT_ENUM_ID));
										if (count($finUnitEnumResp) == 1) {
											$rowItemData['col5'] = "/".$finUnitEnumResp[0]->NAME." (".$finalData['currencyName']."".$finalData['currencySymbol'].")";
											$rowItemData['col6'] = $finUploadedDocumentItemsResp[0]->RATE;//$getData[0]['currencySymbol']." ".
											$rowItemData['col6Id'] = $finUploadedDocumentItemsResp[0]->SERVICE_ITEM_RATE_ID;
											$rowItemData['col6type'] = 'text';
											$rowItemData['col6value'] = $rowItemData['col6'];
										}								
									}else{
										$rowItemData['col5'] = '';
										$rowItemData['col6'] = '';
										$rowItemData['col6type'] = 'hidden';
										$rowItemData['col6value'] = 'empty';
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>2 , 'WORK_TYPE_ID'=> 1, 'IS_ACTIVE' => 1), $this->DateTime);
									if($processTypeId == '1010'){
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 2, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => 0, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									}else{
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 2, 'WORK_TYPE_ID' => 1, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => (int)$processTypeId, 'START_DATE' => $startDate, 'END_DATE' => $endDate));									
										
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>2 , 'WORK_TYPE_ID'=> 1, 'IS_ACTIVE' => 1, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									if (count($finUploadedDocumentItemsResp) == 1 ) {
										$finUnitEnumResp = FinanceModel\UnitEnumModel::getData(['fin_unit_enum.*'], array('UNIT_ENUM_ID' => (int)$finUploadedDocumentItemsResp[0]->UNIT_ENUM_ID));
										if (count($finUnitEnumResp) == 1) {
											$rowItemData['col7'] = "/".$finUnitEnumResp[0]->NAME." (".$finalData['currencyName']."".$finalData['currencySymbol'].")";
											$rowItemData['col8'] = $finUploadedDocumentItemsResp[0]->RATE;//$getData[0]['currencySymbol']." ".
											$rowItemData['col8Id'] = $finUploadedDocumentItemsResp[0]->SERVICE_ITEM_RATE_ID;
											$rowItemData['col8type'] = 'text';
											$rowItemData['col8value'] = $rowItemData['col8'];
										}								
									}else{
										$rowItemData['col7'] = '';
										$rowItemData['col8'] = '';
										$rowItemData['col8type'] = 'hidden';
										$rowItemData['col8value'] = 'empty';
									}							
									
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>2 , 'WORK_TYPE_ID'=> 2, 'IS_ACTIVE' => 1), $this->DateTime);
									if($processTypeId == '1010'){
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 2, 'WORK_TYPE_ID' => 2, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => 0, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									}else{
										$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID' => 2, 'WORK_TYPE_ID' => 2, 'IS_ACTIVE' => 1, 'CURRENT_STATUS' => (int)$processTypeId, 'START_DATE' => $startDate, 'END_DATE' => $endDate));										
									}
									//$finUploadedDocumentItemsResp = FinanceModel\ServiceItemRateModel::getData(['fin_service_item_rate.*'], array('CUSTOMER_ID'=> $customerId, 'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $currentServiceGroupId, 'SERVICE_ITEM_ID' => $currentServiceItemId, 'TRIM_TYPE_ID'=>2 , 'WORK_TYPE_ID'=> 2, 'IS_ACTIVE' => 1, 'START_DATE' => $startDate, 'END_DATE' => $endDate));
									if (count($finUploadedDocumentItemsResp) == 1 ) {
										$finUnitEnumResp = FinanceModel\UnitEnumModel::getData(['fin_unit_enum.*'], array('UNIT_ENUM_ID' => (int)$finUploadedDocumentItemsResp[0]->UNIT_ENUM_ID));
										if (count($finUnitEnumResp) == 1) {									
											$rowItemData['col9'] = "/".$finUnitEnumResp[0]->NAME." (".$finalData['currencyName']."".$finalData['currencySymbol'].")";
											$rowItemData['col10'] = $finUploadedDocumentItemsResp[0]->RATE;//$getData[0]['currencySymbol']." ".
											$rowItemData['col10Id'] = $finUploadedDocumentItemsResp[0]->SERVICE_ITEM_RATE_ID;
											$rowItemData['col10type'] = 'text';
											$rowItemData['col10value'] = $rowItemData['col8'];
										}								
									}else{
										$rowItemData['col9'] = '';
										$rowItemData['col10'] = '';
										$rowItemData['col10type'] = 'hidden';
										$rowItemData['col10value'] = 'empty';
									}
									
									if(!empty($rowItemData['col4']) && !empty($rowItemData['col6']) && !empty($rowItemData['col8']) && !empty($rowItemData['col10']) ){
										$rowItemData['validateCol'] = 4;
									}
									if(!empty($rowItemData['col4']) && empty($rowItemData['col6']) && !empty($rowItemData['col8']) && empty($rowItemData['col10']) ){
										$rowItemData['validateCol'] = 2;
									}
									
									$rowItemData['col1class'] = '';
									$rowItemData['col2class'] = '';
									$rowItemData['col3class'] = 'textAlignCenter';
									$rowItemData['col4class'] = '';
									$rowItemData['col5class'] = 'textAlignCenter';
									$rowItemData['col6class'] = '';
									$rowItemData['col7class'] = 'textAlignCenter';
									$rowItemData['col8class'] = '';
									$rowItemData['col9class'] = 'textAlignCenter';
									$rowItemData['col10class'] = '';
									$serviceItemData[] = $rowItemData;	
									$finalData['serviceItemRowData'] = $serviceItemData;
								//}
							}
						}
					}
				}
			}			
		}	
		
		return $finalData;
	}
	
	public function updatePricing(Request $request,$customerId = null,$customerDivisionId = null,$processTypeId = null,$dateRangeVal = null)
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.REPORT_ARRIVAL'),$data);
        $data['pageTitle']  = 	'Update Pricing';
        $data['pageName']   =   'Update Pricing';
		$data['customerId'] 	=   $customerId;
		$data['customerDivisionId'] 	=   $customerDivisionId;
		$data['processTypeId'] 	=   $processTypeId;
		$data['dateRangeVal'] 	=   $dateRangeVal;
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
		
		$data['processTypeName'] 	=   '';
		$data['isFinal'] 	=   0;
		if(!empty($processTypeId)){
			$currentProcessTypeId 	=   $processTypeId;
			if($processTypeId == "1010"){
				$currentProcessTypeId 	=   1;
			}
			$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', $currentProcessTypeId)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();
					
					$currentStatusArr = array();
					if($getApprovalListQueryCnt > 0){
						foreach ($getApprovalListQueryData as $key => $val) {
							$data['processTypeName'] 	=   $val->LEVEL_NAME;
							if(!empty($val->IS_FINAL)){
								$data['isFinal'] 	=   $val->IS_FINAL;
							}							
						}
					}
		}
		if($processTypeId == "1010"){
			$data['processTypeName'] 	=   'Approve';
		}
		//$data['customerDivisionId'] = Config::get('constants.FINANCE.SPRINGER_CUSTOMER_DIVISION_ID');		
		//$data['customerList'] = FinanceModel\CustomerModel::where('IS_ACTIVE', 1)->where('CUSTOMER_ID', $data['customerId'])->select('CUSTOMER_ID', 'CUSTOMER_NAME')->get();
		//$data['customerDivisionList'] = FinanceModel\CustomerDivisionModel::where('IS_ACTIVE', 1)->where('CUSTOMER_ID', $data['customerId'])->select('CUSTOMER_DIVISION_ID', 'DIVISION_NAME')->get();//->whereIn('CUSTOMER_DIVISION_ID', $data['customerDivisionId'])
		$data['backurl'] 	=   url('/').'/fin/pricinggrid/upload';//'javascript:history.back()';//history.go(-1)
        return view('finance.pricinggrid.updatePricingView')->with($data);
    }
	
	public function getCustomerList(Request $request)
    {
		$data 	=	FinanceModel\CustomerModel::getData(['customer.*'], array('CUSTOMER_ID'=>Config::get('constants.FINANCE.SPRINGER_CUSTOMER_ID_SEL') ));
        $userId =       Session::get('users')['user_id'];
		$response["customerList"] 	= 	$data;
        $response['userId']     =       $userId;
		return response()->json($response);
    }
	
	public function getCustomerDivisionList(Request $request,$customerId = null)
    {
		$data 	=	FinanceModel\CustomerDivisionModel::getData(['customer_division.*'], array('CUSTOMER_ID'=>(int) $customerId));
        $userId =       Session::get('users')['user_id'];
		$customerDivisionKey = array();
		foreach ($data as $key => $val) {
			$customerDivisionKey[$val->CUSTOMER_DIVISION_ID] = $key;
		}
		$response["customerDivisionKey"] 	= 	$customerDivisionKey;
		$response["customerId"] 	= 	$customerId;
		$response["customerDivisionList"] 	= 	$data;
        $response['userId']     =       $userId;
		return response()->json($response);
    }
	
	public function getCurrentStatusList(Request $request,$customerId = null)
    {
		//DB::enableQueryLog();
		$getQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
						
		$recordTotal = $getQuery->count();
		$getRecord = $getQuery->get();
		//$queryChk = DB::getQueryLog();echo $queryChk;
		$userId =       Session::get('users')['user_id'];
		$currentStatusDropDownData = array();
		$currentStatusDropDownData[] = array('name' => 'Pending', 'value' => 1010);
		if($recordTotal > 0){
			foreach ($getRecord as $key => $val) {
				$currentStatusDropDownData[] = array('name' => $val->LEVEL_NAME, 'value' => $val->REQUEST_LEVEL_ID);
			}
		}
		
		$response["customerId"] 	= 	$customerId;
		$response["currentStatusList"] 	= 	$currentStatusDropDownData;
        $response['userId']     =       $userId;
		return response()->json($response);
    }
	
	public function updateServiceItemPricing(Request $request,$customerId = null)
    {
		DB::beginTransaction();
        if($request->isMethod('post') == "post")
        {			
			$getAllPostData = $request->all();
			if(isset($getAllPostData['reasonForChange'])){
				$validator = Validator::make($request->all(), [
					"startDate" => "required|min:1",
					"endDate" => "required|min:1",
					"reasonForChange" => "required|min:1",
					"pricingData" => "required|min:1",
					"updateServiceItemRate" => "required|min:1",
					"customerDivisionId" => "required|min:1",
					"processTypeId" => "required|min:1",
					"Type" => "required|min:1"
				]);
			}else{
				$validator = Validator::make($request->all(), [
					"startDate" => "required|min:1",
					"endDate" => "required|min:1",
					"pricingData" => "required|min:1",
					"updateServiceItemRate" => "required|min:1",
					"customerDivisionId" => "required|min:1",
					"processTypeId" => "required|min:1",
					"Type" => "required|min:1"
				]);
			}
        
			if ($validator->fails()) {
				$Response['Status'] = 1;//400
                $Response['Msg'] = 'Validation Error';
                $Response['ErrorMsg'] = $validator->errors();
			} else {              
                try {
					$processTypeId = $request->input('processTypeId');
					$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();
					
					$currentStatusArr = array();
					$currentStatusIsFinal = 0;
					$currentStatusId = 0;
					if($getApprovalListQueryCnt > 0){
						foreach ($getApprovalListQueryData as $key => $val) {
							$currentStatusArr[] = $val->REQUEST_LEVEL_ID;
							if((int) $processTypeId == (int) $val->REQUEST_LEVEL_ID){
								if(!empty($val->IS_FINAL) && (int)$val->IS_FINAL == 1){
									$currentStatusIsFinal = 1;
									$currentStatusId = (int) $val->REQUEST_LEVEL_ID;
								}
							}
						}
					}
						
					if(isset($getAllPostData['reasonForChange'])){
						$getreasonForChange = $request->input('reasonForChange');
					}					
					$getServiceItemRowData = $request->input('pricingData');				
									
					$isFinal = $request->input('isFinal');				
					$customerDivisionId = $request->input('customerDivisionId');				
					$btnType = $request->input('Type');				
					if(count($getServiceItemRowData) > 0){
						foreach($getServiceItemRowData as $key => $val){
							if((empty($val['col4']) && empty($val['col6']) && empty($val['col8']) && empty($val['col10'])) || (is_null($val['col4']) && is_null($val['col6']) && is_null($val['col8']) && is_null($val['col10']))){
								
							}else if(!empty($val['col4']) && !empty($val['col6']) && !empty($val['col8']) && !empty($val['col10'])){
								//echo gettype($processTypeId)."-----".$processTypeId;
								if($processTypeId == "1010" || $processTypeId == 1010){
									$getRespNS = FinanceModel\ServiceItemRateModel::find($val['col4Id']);
									if($getRespNS->CURRENT_STATUS == 0 && $getRespNS->IS_ACTIVE == 1 && $btnType == 'update'){
										$newNSEntry = $getRespNS->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col4Id'] ));
									}else if($getRespNS->CURRENT_STATUS == 0 && $getRespNS->IS_ACTIVE == 1 && $btnType == 'approve'){
										if($getRespNS->RATE != $val['col4']){//echo 2;die;
											$newNSEntry = $getRespNS->replicate();
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col4Id'] ));
										}else{//echo 3;die;
											$newNSEntry = FinanceModel\ServiceItemRateModel::find($val['col4Id']);
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))) ));
										}
									}
									
								}else if(in_array($processTypeId, $currentStatusArr)){
									$getRespNS = FinanceModel\ServiceItemRateModel::find($val['col4Id']);//echo gettype($getRespNS->CURRENT_STATUS)."---2--".gettype($getRespNS->IS_ACTIVE)."-----".gettype($btnType)."-----".$getRespNS->CURRENT_STATUS."-----".$getRespNS->IS_ACTIVE."-----".$btnType;die;
									if($getRespNS->RATE != $val['col4']){
										$newNSEntry = $getRespNS->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => $processTypeId, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col4Id'] ));
									}else{
										$newNSEntry = FinanceModel\ServiceItemRateModel::find($val['col4Id']);
									}
								}
								
								$newNSEntry->RATE = $val['col4'];
								if(isset($getAllPostData['reasonForChange'])){
									$newNSEntry->REMARKS = $getreasonForChange;
								}
								if($processTypeId == "1010" || $processTypeId == 1010){
									if($getRespNS->CURRENT_STATUS == 0 && $getRespNS->IS_ACTIVE == 1 && $btnType == 'update'){
										$newNSEntry->CURRENT_STATUS = 0;
									}else if($getRespNS->CURRENT_STATUS == 0 && $getRespNS->IS_ACTIVE == 1 && $btnType == 'approve'){
										$newNSEntry->CURRENT_STATUS = 1;
									}
								}else if(in_array($processTypeId, $currentStatusArr)){
									$newNSEntry->CURRENT_STATUS = $processTypeId;
								} 
								
								if(!empty($val['col2_glAccountCode']) && $val['col2_glAccountCode'] == $val['col2_glAccountCodevalue']){
									$newNSEntry->ACCOUNT_CODE = $val['col2_glAccountCodevalue'];
								}else{
									$newNSEntry->ACCOUNT_CODE = $val['col2_glAccountCode'];									
								}	
								
								$currentRowServiceItemID = $newNSEntry->SERVICE_ITEM_ID;
								$currentRowAccountCode = $newNSEntry->ACCOUNT_CODE;
								
								$newNSEntry->IS_ACTIVE = 1;
								$newNSEntry->LAST_MOD_DATE = $this->DateTime;
								$newNSEntry->LAST_MOD_BY = $this->loginUserId;
								$newNSEntry->save();
								
								if($processTypeId == "1010" || $processTypeId == 1010){
									$getRespNC = FinanceModel\ServiceItemRateModel::find($val['col6Id']);									
									if($getRespNC->CURRENT_STATUS == 0 && $getRespNC->IS_ACTIVE == 1 && $btnType == 'update'){
										$newNCEntry = $getRespNC->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col6Id'] ));
									}else if($getRespNC->CURRENT_STATUS == 0 && $getRespNC->IS_ACTIVE == 1 && $btnType == 'approve'){
										if($getRespNC->RATE != $val['col6']){
											$newNCEntry = $getRespNC->replicate();
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col6Id'] ));
										}else{
											$newNCEntry = FinanceModel\ServiceItemRateModel::find($val['col6Id']);
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))) ));
										}
									}
									
								}else if(in_array($processTypeId, $currentStatusArr)){
									$getRespNC = FinanceModel\ServiceItemRateModel::find($val['col6Id']);
									if($getRespNC->RATE != $val['col6']){
										$newNCEntry = $getRespNC->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => $processTypeId, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newNCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newNCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newNCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newNCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newNCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col6Id'] ));
									}else{
										$newNCEntry = FinanceModel\ServiceItemRateModel::find($val['col6Id']);
									}
								}
								
								$newNCEntry->RATE = $val['col6'];
								if(isset($getAllPostData['reasonForChange'])){
									$newNCEntry->REMARKS = $getreasonForChange;
								}
								if($processTypeId == "1010" || $processTypeId == 1010){
									if($getRespNC->CURRENT_STATUS == 0 && $getRespNC->IS_ACTIVE == 1 && $btnType == 'update'){
										$newNCEntry->CURRENT_STATUS = 0;
									}else if($getRespNC->CURRENT_STATUS == 0 && $getRespNC->IS_ACTIVE == 1 && $btnType == 'approve'){
										$newNCEntry->CURRENT_STATUS = 1;
									}
								}else if(in_array($processTypeId, $currentStatusArr)){
									$newNCEntry->CURRENT_STATUS = $processTypeId;
								} 
								
								if(!empty($val['col2_glAccountCode']) && $val['col2_glAccountCode'] == $val['col2_glAccountCodevalue']){
									$newNCEntry->ACCOUNT_CODE = $val['col2_glAccountCodevalue'];
								}else{
									$newNCEntry->ACCOUNT_CODE = $val['col2_glAccountCode'];									
								}								
								 
								$newNCEntry->IS_ACTIVE = 1;
								$newNCEntry->LAST_MOD_DATE = $this->DateTime;
								$newNCEntry->LAST_MOD_BY = $this->loginUserId;
								$newNCEntry->save();
								
								if($processTypeId == "1010" || $processTypeId == 1010){
									$getRespLS = FinanceModel\ServiceItemRateModel::find($val['col8Id']);									
									if($getRespLS->CURRENT_STATUS == 0 && $getRespLS->IS_ACTIVE == 1 && $btnType == 'update'){
										$newLSEntry = $getRespLS->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col8Id'] ));
									}else if($getRespLS->CURRENT_STATUS == 0 && $getRespLS->IS_ACTIVE == 1 && $btnType == 'approve'){
										if($getRespLS->RATE != $val['col8']){
											$newLSEntry = $getRespLS->replicate();
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col8Id'] ));
										}else{
											$newLSEntry = FinanceModel\ServiceItemRateModel::find($val['col8Id']);
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))) ));
										}
									}
									
								}else if(in_array($processTypeId, $currentStatusArr)){
									$getRespLS = FinanceModel\ServiceItemRateModel::find($val['col8Id']);
									if($getRespLS->RATE != $val['col8']){
										$newLSEntry = $getRespLS->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => $processTypeId, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLSEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLSEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLSEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLSEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLSEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col8Id'] ));
									}else{
										$newLSEntry = FinanceModel\ServiceItemRateModel::find($val['col8Id']);
									}
								}
								
								$newLSEntry->RATE = $val['col8'];
								if(isset($getAllPostData['reasonForChange'])){
									$newLSEntry->REMARKS = $getreasonForChange;
								}
								if($processTypeId == "1010" || $processTypeId == 1010){
									if($getRespLS->CURRENT_STATUS == 0 && $getRespLS->IS_ACTIVE == 1 && $btnType == 'update'){
										$newLSEntry->CURRENT_STATUS = 0;
									}else if($getRespLS->CURRENT_STATUS == 0 && $getRespLS->IS_ACTIVE == 1 && $btnType == 'approve'){
										$newLSEntry->CURRENT_STATUS = 1;
									}
								}else if(in_array($processTypeId, $currentStatusArr)){
									$newLSEntry->CURRENT_STATUS = $processTypeId;
								} 
								
								if(!empty($val['col2_glAccountCode']) && $val['col2_glAccountCode'] == $val['col2_glAccountCodevalue']){
									$newLSEntry->ACCOUNT_CODE = $val['col2_glAccountCodevalue'];
								}else{
									$newLSEntry->ACCOUNT_CODE = $val['col2_glAccountCode'];									
								}
								
								$newLSEntry->IS_ACTIVE = 1;
								$newLSEntry->LAST_MOD_DATE = $this->DateTime;
								$newLSEntry->LAST_MOD_BY = $this->loginUserId;
								$newLSEntry->save();
								
								if($processTypeId == "1010" || $processTypeId == 1010){
									$getRespLC = FinanceModel\ServiceItemRateModel::find($val['col10Id']);									
									if($getRespLC->CURRENT_STATUS == 0 && $getRespLC->IS_ACTIVE == 1 && $btnType == 'update'){
										$newLCEntry = $getRespLC->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col10Id'] ));
									}else if($getRespLC->CURRENT_STATUS == 0 && $getRespLC->IS_ACTIVE == 1 && $btnType == 'approve'){
										if($getRespLC->RATE != $val['col10']){
											$newLCEntry = $getRespLC->replicate();
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col10Id'] ));
										}else{
											$newLCEntry = FinanceModel\ServiceItemRateModel::find($val['col10Id']);
											FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => 0, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))) ));
										}
									}
									
								}else if(in_array($processTypeId, $currentStatusArr)){
									$getRespLC = FinanceModel\ServiceItemRateModel::find($val['col10Id']);
									if($getRespLC->RATE != $val['col10']){
										$newLCEntry = $getRespLC->replicate();
										FinanceModel\ServiceItemRateModel::updateData(array('IS_ACTIVE' => 0, 'LAST_MOD_DATE' => $this->DateTime, 'LAST_MOD_BY' => $this->loginUserId), array('CURRENT_STATUS' => $processTypeId, 'IS_ACTIVE' => 1, 'CUSTOMER_ID' => $customerId,'CUSTOMER_DIVISION_ID' => $customerDivisionId, 'SERVICE_GROUP_ID' => $newLCEntry->SERVICE_GROUP_ID, 'SERVICE_ITEM_ID' => $newLCEntry->SERVICE_ITEM_ID, 'UNIT_ENUM_ID' => $newLCEntry->UNIT_ENUM_ID, 'WORK_TYPE_ID' => $newLCEntry->WORK_TYPE_ID, 'TRIM_TYPE_ID' => $newLCEntry->TRIM_TYPE_ID, 'START_DATE' => date("Y-m-d H:i:s", strtotime($request->input('startDate'))), 'END_DATE' => date("Y-m-d H:i:s", strtotime($request->input('endDate'))), 'SERVICE_ITEM_RATE_ID' => $val['col10Id'] ));
									}else{
										$newLCEntry = FinanceModel\ServiceItemRateModel::find($val['col10Id']);
									}
								}
								
								$newLCEntry->RATE = $val['col10'];
								if(isset($getAllPostData['reasonForChange'])){
									$newLCEntry->REMARKS = $getreasonForChange;
								}
								if($processTypeId == "1010" || $processTypeId == 1010){
									if($getRespLC->CURRENT_STATUS == 0 && $getRespLC->IS_ACTIVE == 1 && $btnType == 'update'){
										$newLCEntry->CURRENT_STATUS = 0;
									}else if($getRespLC->CURRENT_STATUS == 0 && $getRespLC->IS_ACTIVE == 1 && $btnType == 'approve'){
										$newLCEntry->CURRENT_STATUS = 1;
									}
								}else if(in_array($processTypeId, $currentStatusArr)){
									$newLCEntry->CURRENT_STATUS = $processTypeId;
								} 
								
								if(!empty($val['col2_glAccountCode']) && $val['col2_glAccountCode'] == $val['col2_glAccountCodevalue']){
									$newLCEntry->ACCOUNT_CODE = $val['col2_glAccountCodevalue'];
								}else{
									$newLCEntry->ACCOUNT_CODE = $val['col2_glAccountCode'];									
								}
								 
								$newLCEntry->IS_ACTIVE = 1;
								$newLCEntry->LAST_MOD_DATE = $this->DateTime;
								$newLCEntry->LAST_MOD_BY = $this->loginUserId;
								$newLCEntry->save();
								
								if($currentStatusIsFinal == 1){
									$getSItmsQuery = FinanceModel\ServiceItemsModel::find($currentRowServiceItemID);
									$getSItmsQuery->ACCOUNT_CODE = $currentRowAccountCode;
									$getSItmsQuery->LAST_MOD_DATE = $this->DateTime;
									$getSItmsQuery->LAST_MOD_BY = $this->loginUserId;
									$getSItmsQuery->save();
								}
							}
						}
						
						$Response['Status'] = 0;//200
						$Response['Msg'] = 'Success';
						$Response['SuccessMsg'] = 'Line item pricing is updated successfully.';
					}else{
						$Response['Status'] = 1;
						$Response['Msg'] = 'Failure';
						$Response['ErrorMsg'] = "Line Item is not found.";
					}
				} catch (\Exception $e) {
                    $Response['Status'] = 1;
                    $Response['Msg'] = 'Failure';
                    $Response['ErrorMsg'] = $e->getMessage();
                }
			}
		} else {
            $Response['Status'] = 1;
            $Response['Msg'] = 'Failure';
			$Response['ErrorMsg'] = 'Post Data is not found.';
        }
		
		if ($Response['Status'] == 1) {
			DB::rollback();            
        } else {
			DB::commit();
        }  
		
		return response()->json($Response);
	}
	
	public function downloadServiceItemPricing(Request $request,$customerId = null, $customerDivisionId = null, $processTypeId = null, $startDate = null, $endDate = null)
    {	
		$finalData = $this->generatePricingGridData($customerId, $customerDivisionId, $processTypeId, $startDate, $endDate);
		if(count($finalData) > 0){
			$sampleFileSourcePath = 'uploadFiles/pricingGrid/SampleTemplate/SamplePricingGrid.XLSX';	
		
			$folderName = "uploadFiles/pricingGrid/".date("Y", time());
			
			$fileName = 'UpdatedPricingGrid' . date("Y", time());		

			PHPExcel_Calculation::getInstance()->clearCalculationCache();
			PHPExcel_Calculation::getInstance()->disableCalculationCache();
			
			Excel::load($sampleFileSourcePath, function($file) use ($finalData, $folderName, $fileName) {
				$firstSheetNo = 0;
				$file->setActiveSheetIndex($firstSheetNo)->setCellValue('C4', $finalData['currency'], true);
				$file->setActiveSheetIndex($firstSheetNo)->setCellValue('C5', $finalData['vendor'], true);
				$file->setActiveSheetIndex($firstSheetNo)->setCellValue('C6', $finalData['date'], true);
				$file->setActiveSheetIndex($firstSheetNo)->setCellValue('D5', $finalData['normalSizeValue'], true);
				$file->setActiveSheetIndex($firstSheetNo)->setCellValue('J5', $finalData['largeSizeValue'], true);				
				
				$sheetRow = 11;
				foreach($finalData['serviceItemRowData'] as $key=>$val){
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('B'.$sheetRow, $val['col1'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('C'.$sheetRow, $val['col2'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('D'.$sheetRow, $val['col3'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('E'.$sheetRow, $val['col4'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('G'.$sheetRow, $val['col5'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('H'.$sheetRow, $val['col6'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('J'.$sheetRow, $val['col7'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('K'.$sheetRow, $val['col8'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('M'.$sheetRow, $val['col9'], true);
					$file->setActiveSheetIndex($firstSheetNo)->setCellValue('N'.$sheetRow, $val['col10'], true);
					$sheetRow++;
				}
				
				$file->sheet('Books FS '.date('Y', time()), function($sheet) use ($finalData) 
                {	
					$sheetRow = 11;
					foreach($finalData['serviceItemRowData'] as $key=>$val){
						if(empty($val['col3']) && empty($val['col4']) && empty($val['col5']) && empty($val['col6']) && empty($val['col7']) && empty($val['col8']) && empty($val['col9']) && empty($val['col10'])){
							$rowIndex = array('C', 'D', 'E', 'G', 'H', 'J', 'K', 'M', 'N');
							foreach($rowIndex as $k => $v){
								$sheet->cells($v."".$sheetRow, function($cells) {
									//$cells->setFontFamily('Arial');
									//$cells->setFontSize(10);	
									$cells->setFontWeight('bold');	
									//$cells->setBorder('thin', 'thin', 'thin', 'thin');
									// $cells->setAlignment('center');
									//$cells->setValignment('center');
									$cells->setBackground('#bada87');
								});
							}
						}
						$sheetRow++;
					}                    					
                });				
			})->setFilename($fileName)->export('xlsx');
        } else {
            return view('errors.401');
        }
	}
	
	public function getDateRangeData(Request $request, $customerId, $customerDivisionId, $processTypeId, $isFinal){
		$finalData = array();
		//DB::enableQueryLog();
		$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frl.IS_FINAL', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();
					
		$currentStatusArr = array();
		$currentStatusFinal = 0;
		if($getApprovalListQueryCnt > 0){
			foreach ($getApprovalListQueryData as $key => $val) {
				$currentStatusArr[] = $val->REQUEST_LEVEL_ID;
				if(!empty($val->IS_FINAL) && (int)$val->IS_FINAL == 1){
					$currentStatusFinal = (int)$val->REQUEST_LEVEL_ID;
				}
			}
		}
					
		if($processTypeId == "1010"){
			$query = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1 )->where('CURRENT_STATUS', 0 )->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->whereRaw('(("START_DATE" >= "'.$this->DateTime.'")')->orwhereRaw('("'.$this->DateTime.'" between `START_DATE` and `END_DATE`))')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);//->where('IS_ACTIVE', 1 )
		}else{			
			$query = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1 )->where('CURRENT_STATUS', (int)$processTypeId )->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->whereRaw('(("START_DATE" >= "'.$this->DateTime.'")')->orwhereRaw('("'.$this->DateTime.'" between `START_DATE` and `END_DATE`))')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);//->where('IS_ACTIVE', 1 )(int)$currentStatusArr[0]
		}
		//$query = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->whereRaw('(("START_DATE" >= "'.$this->DateTime.'")')->orwhereRaw('("'.$this->DateTime.'" between `START_DATE` and `END_DATE`))')->orderBy('START_DATE', 'asc')->distinct()->get(['START_DATE','END_DATE']);//->where('IS_ACTIVE', 1 )
		//$queryChk = DB::getQueryLog();echo $queryChk;die;
		$finalData['variousPricingList'] = array();
		$currentDate = date("Y-m-d", time());
		$currentDateRangeIndex = 0;
		if(count($query) > 0){
			$i = 0;
			foreach($query as $val){				
				if (($currentDate > date("Y-m-d", strtotime($val->START_DATE))) && ($currentDate < date("Y-m-d", strtotime($val->END_DATE))))
				{
					$currentDateRangeIndex = $i;				  
				}
				$finalData['variousPricingList'][] = array( 'START_DATE' => date("Y-m-d", strtotime($val->START_DATE)), 'END_DATE' => date("Y-m-d", strtotime($val->END_DATE)), 'UNIX_START_DATE'=>strtotime($val->START_DATE), 'UNIX_END_DATE'=>strtotime($val->END_DATE));
				$i++;
			}
		}
		
		$Response = array();
        $Response["data"] = $finalData;
        return response()->json($Response);
	}
	
	public function chkPricingGridDataAvailable($customerId, $customerDivisionId, $processTypeId = null, $startDate = null, $endDate = null ){
		//$getServiceItemRateData = DB::table('fin_service_item_rate')->where('CUSTOMER_ID', $customerId )->whereRaw('"'.$this->DateTime.'" between `START_DATE` and `END_DATE`')->get();
		$startDate = date("Y-m-d H:i:s", $startDate);
		$endDate = date("Y-m-d H:i:s", $endDate);
		
		$getApprovalListQuery = DB::table('fin_request_master AS frm')
                        ->join('fin_request_level AS frl', 'frm.REQUEST_MASTER_ID', '=', 'frl.REQUEST_MASTER_ID')
						->where('frm.REQUEST_TYPE', 'PRICING GRID')
                        ->where('frl.REQUEST_LEVEL_ID', '>', 0)
                        ->where('frl.IS_ACTIVE', 1)
                        ->where('frl.IS_FINAL', 1)
                        ->where('frm.IS_ACTIVE', 1)
						->select(array('frl.LEVEL_NAME', 'frl.REQUEST_LEVEL_ID', 'frl.IS_FINAL'));
					$getApprovalListQueryCnt = $getApprovalListQuery->count();
					$getApprovalListQueryData = $getApprovalListQuery->get();
					
		$currentStatusArr = array();
		$currentStatusFinal = 0;
		if($getApprovalListQueryCnt > 0){
			foreach ($getApprovalListQueryData as $key => $val) {
				$currentStatusArr[] = $val->REQUEST_LEVEL_ID;
				if(!empty($val->IS_FINAL) && (int)$val->IS_FINAL == 1){
					$currentStatusFinal = (int)$val->REQUEST_LEVEL_ID;
				}
			}
		}
		
		if($processTypeId == '10'){
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', $currentStatusFinal)->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)	(int)$currentStatusArr[0]		
		}else{
			$getServiceItemRateData = DB::table('fin_service_item_rate')->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', ((int)$processTypeId - 1))->where('CUSTOMER_ID', $customerId )->where('CUSTOMER_DIVISION_ID', $customerDivisionId )->where('START_DATE', $startDate)->where('END_DATE', $endDate)->orderBy('SERVICE_ITEM_ID', 'asc')->get();//->where('IS_ACTIVE', 1)->where('CURRENT_STATUS', 1)
		}
		
		$getData = array();
		$serviceGroupArray = array();
		$serviceItemArray = array();
		$serviceItemCurrentStatusArray = array();
		$currentStatus = '';
		$currencyId = "";
		$uploadDocumentID = 0;
		if(count($getServiceItemRateData) > 0){
			foreach($getServiceItemRateData as $key=>$val){
				$currencyId = $val->CURRENCY_ID;
				if(!isset($serviceGroupArray[$val->SERVICE_GROUP_ID])){// && $val->IS_ACTIVE == 1 && $val->CURRENT_STATUS == 1
					$serviceGroupArray[$val->SERVICE_GROUP_ID] = $val->SERVICE_GROUP_ID;
				}
				if(!isset($serviceItemArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID])){
					$serviceItemArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID] = $val->SERVICE_ITEM_ID;
				}
				if(!isset($serviceItemCurrentStatusArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID])){
					$serviceItemCurrentStatusArray[$val->SERVICE_GROUP_ID][$val->SERVICE_ITEM_ID] = $val->SERVICE_ITEM_ID;
					$currentStatus = 0;
				}				
				$uploadDocumentID = $val->UPLOADED_DOCUMENT_ID;				
			}
		}
		
		if(count($serviceGroupArray) > 0 && count($serviceItemArray) > 0){
			return true;
		}
		return false;
	}
}