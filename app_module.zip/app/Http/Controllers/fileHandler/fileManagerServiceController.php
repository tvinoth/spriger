<?php
/*
 *  Author : Ananth B [ananth.b@spi-global.com]
 *  Date : 21-04-2019
 *  Spi Global`s file manager service controller 
 *  
 */

namespace App\Http\Controllers\fileHandler;

use App\Http\Controllers\Controller;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Models\productionLocationModel;
use App\Models\fileManagerServiceModel;
use App\Http\Controllers\custom\errorController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\bgprocess\bgprocessController;
use App\Models\taskLevelMetadataModel;
use App\Models\jobModel;
use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;
//use GuzzleHttp\Client;


class fileManagerServiceController extends Controller{
    
    #required properties :
    
    public $locationBasedWebServiceUrl;
    public $postFileUrl;
	public $metaExtractor;
    public $commonformatXmlFlag    =   0;
    
    public function __construct( $metaid , $round  , $jbstgid = null ) {
        
        //default assignment
        if(empty(\Config::get('requiredconstants.FILE_MANAGER_SERVICE.pondy'))){
            $this->locationBasedWebServiceUrl   =   \Config::get('constants.FILE_MANAGER_SERVICE.pondy');
        }
        else{
			$this->locationBasedWebServiceUrl   =   \Config::get('requiredconstants.FILE_MANAGER_SERVICE.pondy'); 
        }
		
		//	$this->locationBasedWebServiceUrl	=	 'http://172.24.131.162:8101/PGDWCFSERVICE.svc?wsdl';
		//  $this->postFileUrl                  =   'http://172.24.131.162:8100/PGDWCFSERVICE.svc/';
		//	$this->metaExtractor				=	'http://172.24.131.162:8100/PGDWCFSERVICE.svc?wsdl';
	
		$this->locationBasedWebServiceUrl	=	 'http://172.24.175.46:8100/PGDWCFSERVICE.svc?wsdl';
		$this->postFileUrl                  =    'http://172.24.175.46:8090/PGDWCFSERVICE.svc/';
		$this->metaExtractor				=	 'http://172.24.175.46:8090/PGDWCFSERVICE.svc?wsdl';
		
		$metainfo							=		$this->getBasicMetainfo( $metaid , $round , $jbstgid );
		$this->metainfo						=		$metainfo;
		
		
    }

    public function getBasicMetainfo(  $metaid ,  $round , $jbstgid ){
		
		$tskObj		=	new taskLevelMetadataModel();
		$round_arr	=	\Config::get( 'constants.ROUND_NAME' );
		$roundname	=	$round_arr[$round];
		$metainfo	=	array();
		
		$metainformation		=	$tskObj->getMetadatadetailsChapterwithbook( $metaid );
		
		if( count( $metainformation ) && $metainformation ){
			
			if( isset( $metainformation[0] ) ){
				$metainformation   =  $metainformation[0];
			}
			
			$jobid		=			$metainformation->JOB_ID;
			
			$jb_obj     =           new jobModel();
			$bookInfo	=   		jobModel::getJobdetails( $jobid );
			
			$getlocationftp             =       productionLocationModel::doGetLocationname( $jobid );
			if( empty( $getlocationftp ) )            
			   $getlocationftp          =       productionLocationModel::getDefaultProductionLocationInfo();
			
			$getlocationftp->FTP_PASSWORD       =       \Crypt::decryptString( $getlocationftp->FTP_PASSWORD );
			
			$metainfo['getlocationftp']    =       $getlocationftp;   
			$metainfo['chapterid']	=			$metainformation->CHAPTER_NO;
			$metainfo['chaptername']=			$metainformation->CHAPTER_NO;
			$metainfo['chapterno']=			$metainformation->CHAPTER_NO;
			$metainfo['metaid']		=			$metainformation->METADATA_ID;
			$metainfo['chapternumber']	=			preg_replace( '/\D/', '', $metainformation->CHAPTER_NO );
			$metainfo['roundname']	=			$roundname;
			$metainfo['round']		=			$round;
			$metainfo['isbnnumber']	=			$bookInfo->ISSN_ONLINE;
			$metainfo['publisher']	=			$bookInfo->PUBLISHER_NAME;
			$metainfo['bookid']		=			$bookInfo->BOOK_ID;
			$metainfo['jobid']		=			$jobid;
			
			$apc_obj    			=   		new autoPageController();
			$paging_collect     	=       	$apc_obj->getPagingFileNameing( $metainfo['bookid'] , $metainfo['chapterid'] ,  $metaid );
			extract( $paging_collect );
			
			$metainfo['pagingfilnaming']		=		$pagingfilnaming;
			$metainfo['{PAGING_FILENAMING}']	=		$pagingfilnaming;
			
		}
		
		if( !is_null( $jbstgid ) ){
			
		}
		
		return $metainfo;
	}	
	
    public function storeResponse( Request $request ){
       
        $inputarr           =       json_decode( $request->getContent() );
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        $inputarr           =       (array)$inputarr;
       
        $response['status']         =       0;
        $response['msg']            =       'Failed';
        $response['errMsg']         =       'Try again after sometimes';
        
        $rules      =   $this->validationRuleForResponseSignal(); 
        $validator                  =       Validator::make( $inputarr , $rules );
      
            if ($validator->fails()) {
                
               $response['errMsg']      =       'Required field validation error occured.';
               
            }else{ 
                
                $token_key      =      $inputarr['tokenkey'];
               
                
                $sig_obj        =      new fileManagerServiceModel();
                $getRec         =      $sig_obj->getApiRequestByTokenKey( $token_key );
                 
                if(!empty( $getRec )){
                    
                    $this->prepareUpdationValues( $inputarr , $inpArr );
                    
                    $rowid              =           $getRec->ID;
                    $lstatus      =           $sig_obj->updateIfExist( $inpArr, $rowid );
                    
                    if( $lstatus ){
                        
                        $response['status']         =       1;
                        $response['msg']            =       'Success';
                        $response['errMsg']         =       'Signal Received Successfully';
                        
                    }else{
                        
                        $response['errMsg']         =       'Signal update Query got Failed';
                        
                    }

                }else{
                    $response['errMsg']         =       'Invalid try , Try again after sometimes. [ Requested process not available in the service list ]';
                }
                
            }
            
            echo json_encode( $response );
            exit;
    }
    
    public function generateFileCopyXml($data ){
		
		$metainfo		=		$this->metainfo;
		extract( $metainfo );
		
        $metaXml    =   '';
        $metaData = '<MetaData>
                                <Current_User>6000</Current_User>
                                <Actual_Name>Admin M</Actual_Name>
                                <Stage>'.$roundname.'</Stage>
                                <Chapter_ID>'.$chapterid.'</Chapter_ID>
                                <BookID>'.$bookid.'</BookID>
                                <Isbn_Number>'.$isbnnumber.'</Isbn_Number>
                                <Publisher>'.$publisher.'</Publisher>
                                <Acronym>'.$bookid.'</Acronym>
                                <aid></aid>
                                <ChapterNumber>'.$chapternumber.'</ChapterNumber>
                                <EProofing></EProofing>
                                <SourceWorkFlow>Magnus</SourceWorkFlow>
                                <ProjectName>SpringerBWF</ProjectName>
                                <WorkType>Normal Books</WorkType>
                                <BGProcess>NO</BGProcess>
                </MetaData>';
        
			$bodyContent     =    $this->generateFileCopyBody( $data );
			$appurl			=	  \Config::get( 'constants.BASE_URL' );
			
			$workflow 	=	'<Workflow>
                                <Process OrderNo="2" ProcessName="FileCopy" State="I" ServerName="ppdysvm-016" XPath="//FileCopy"/> 
                                <WorkflowAPI>
                                                <Url value="'.$appurl.'filemovement" />
                                                <parameter type="fixed" value="1522" key="RequestID" />
                                                <parameter type="fixed" value="FileCopy" key="RequestFor" />
                                                <parameter type="string" value="@Status" key="Status" />
                                                <parameter type="fixed" value="523" key="SwfId" />
                                                <parameter type="fixed" value="2" key="ActivityOrder" />
                                                <parameter type="string" value="@Remarks" key="remarks" />
                                                <parameter type="string" value="@Source" key="Source" />
                                </WorkflowAPI>
                </Workflow>';
         
         
         $metaXml  = '<WorkflowMetadata>';
         
         $metaXml  .= $metaData;
         $metaXml  .= '<FileCopy>';
         
         $metaXml  .= $bodyContent;
         
         $metaXml  .= '</FileCopy>';
         
		$metaXml  .= $workflow;
         
         $metaXml  .= '</WorkflowMetadata>';
         
         return $metaXml;
        
    }
    
    public function generateFileCopyBody($data){
		
        $content        =   '';
        $metainfo		=	$this->metainfo;
		extract( $metainfo );

        if(!empty($data)){
            $content  = '';
            $src      = '';
            $des      = '';
			
            foreach( $data['src'] as $key => $srcData ){ 
               
              $del     =  ((isset($srcData['delete'])&& !empty($srcData['delete']))?'Y':'N'); 
              $mandatory     =  ((isset($data['src'][$key]['mandatory'])&& !empty($data['src'][$key]['mandatory']))?$data['src'][$key]['mandatory']:'N');  
              
			  if(!empty($srcData['path'])){
                $src     =  str_ireplace('/', '\\', $srcData['path']);
				$src	 =	$this->pathpreparationAdjustment( $src , $getlocationftp );
              }
			  
              if(!empty($data['dest'][$key]['path'])){
                $des     =  str_ireplace('/', '\\', $data['dest'][$key]['path']);
				$des	 =	$this->pathpreparationAdjustment( $des , $getlocationftp );
              }
              
              $ext     =  ((isset($srcData['extension'])&& !empty($srcData['extension']))?$srcData['extension']:'');
              $content .=	'<Application mandatory="'.$mandatory.'" delete="'.$del.'" SourcePath="'.$src.'" extension="'.$ext.'">'.$des.'</Application>';
			  
            }
			
        }
        
        return $content;
    }
    
    #folder related collections
	
    public function makeDirectory( $path ){
            
        $response['status']     =   0;
        $response['msg']        =   'failed';
        $response['errMsg']     =   'Oops , something went wrong.';
        
        try{
            
            $cmnobj         =       new CommonMethodsController();

            $serviceurl     =       $this->metaExtractor;
       
            $inputData      =       array( 'data'=> $path );
			
 
            $methodname         =   'CreateDirectory';
           
            $outputparameter    =   $methodname.'Result';
           
            $output     =       $cmnobj->soapServiceCall( $serviceurl ,  $methodname , $inputData , $outputparameter );
		
         
            if( $output == 'Success' ){
                $response['status']     =   1;
                $response['msg']        =   'success';
                $response['errMsg']     =   $output;
            }else{
                $response['status']     =   0;
                $response['msg']        =   'failed';
                $response['errMsg']     =   $output;
            }
            return  response()->json( $response , 200 );
        
        }catch( Exception $e ){
            
            $response['reason']     =   $e->getMessage() ;
          
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );
     
            return  response()->json( $response , 200 );
            
        }
        
    }
	
    public function dirCopy( $src , $dest ){

    }

    public function isDirectory( $path ){
        
    }
        
    public function directoryFileList( $path ){
        
        $fileData       =   [];
        $url            =   $this->postFileUrl.'FileListWithSize';

        $commonObj      =   new CommonMethodsController();
        $fileList       =   $commonObj->callService($path,$url );
        $fileList       =   json_decode($fileList, TRUE);
        
        if(!empty($fileList)){
            
            foreach($fileList as $key => $data){
               
                if(!empty($data['filesLists'])){
                    foreach($data['filesLists'] as $key2 => $val ){
                        $fileData[] = $val['path'].$val['FileName'];
                    }
                }

            }
        }
        
        Log::useDailyFiles(storage_path().'/Api/fileMovement.log');
        Log::info($fileList);
       // echo "<pre>";print_r($postResponse);exit;

        return $fileData;

    }
    
    public function directoryFileListwithSize( $path ){
        $fileData       =   [];
        $url            =   $this->postFileUrl.'FileListWithSize';
        $commonObj      =   new CommonMethodsController();
        $fileList       =   $commonObj->callService($path,$url );      
        $fileList       =   json_decode($fileList, TRUE);
        
        if(!empty($fileList)){
            
            foreach($fileList as $key => $data){
               
                if(isset($data['filesLists']) && !empty($data['filesLists'])){
                    foreach($data['filesLists'] as $key2 => $val ){
                        $fileData[$key2]['path']   =   $val['path'].'/'.$val['FileName'];
                        $fileData[$key2]['folderpath']   =   $val['path'].'/';
                        $fileData[$key2]['FileName']   =   $val['FileName'];
                        $fileData[$key2]['FileSize']   =   $val['FileSize'];
                    }
                }

            }
        }
        return $fileData;
    }
    
    public function listDirectory( $path ){
        $fileData       =   [];
        $url            =   $this->postFileUrl.'FileListWithSize';
        $commonObj      =   new CommonMethodsController();
        $fileList       =   $commonObj->callService($path,$url );      
        $fileList       =   json_decode($fileList, TRUE);
        
        if(!empty($fileList)){
            foreach($fileList as $key => $data){
                if(isset($data['subDirectories']) && !empty($data['subDirectories'])){
                    foreach($data['subDirectories'] as $key2 => $val ){
                        $fileData[]   =   $val['path'];
                    }
                }
            }
        }
        return $fileData;
    }
    
    public function deleteDirecotory( $path ){

    }

    #file related collections

    public function fileCopy( $data ){
        
	$url            =   $this->postFileUrl.'FileManager';
	$xmldata        =   $this->generateFileCopyXml( $data );
		
	$commonObj      =   new CommonMethodsController();
	$bg_Obj       	=	new bgprocessController();   
	$xmldata    	=	$bg_Obj->replaceRequireKeysToValues( $xmldata , $this->metainfo ); 
		
	$formatString   =   $commonObj->formatXmlString($xmldata);
		
	//Log::useDailyFiles(storage_path().'/Api/fileMovement.log');
	//Log::info($xmldata);
	//echo '<pre>';
	//echo htmlspecialchars( $formatString );
		
		try{
			
			$postResponse   =   $commonObj->callService($xmldata,$url);
			$status         =   $this->getfileCopyStatus($postResponse);
		
		}catch(\Exception $e){			
            $err_handle     =       new errorController();
            $err_handle->handleApplicationErrors( $e );			
			return false;			
		}
		
        //Log::useDailyFiles(storage_path().'/Api/fileMovement.log');
        //Log::info($postResponse);
		
        return $status;

    }
    
    public function getfileCopyStatus($response){
        $status         =   array();
        $json_obj       = json_decode($response , TRUE);
        
        if(!empty($json_obj)){
           
            foreach($json_obj['FileCopyInfo'] as $key => $data){
               
                if($data['Status']  == 'S' ){
                    $status[$data['SourceFilename']] = 'success';
                }else{
                    $status[$data['SourceFilename']] = 'failed';
                }
            }
        }
        
        return $status;
        
    }

    public function fileCreate( $pathWithFilename , $content , $getlocationftp = null ){
        
          
        $response['status']     =   0;
        $response['msg']        =   'failed';
        $response['errMsg']     =   'Oops , something went wrong.';
        
        if( !is_null( $getlocationftp  ) ){
            $pathWithFilename       =       $this->pathpreparationAdjustment( $pathWithFilename , $getlocationftp );
        }
        
        $cmnobj         =       new CommonMethodsController();
        
        try{
            
            $serviceurl     =       $this->metaExtractor;
            
              //  $methodname         =       'FileWriteByte';
          //  $outputparameter    =       'FileWriteByteResult';
		  
			$methodname         =       'FileWrite';
			$outputparameter    =       'FileWriteResult';
           
            $inputData          =       array( 'data' => $content , 'outputPath' =>  $pathWithFilename );
			
		
            $output             =       $cmnobj->soapServiceCall( $serviceurl ,  $methodname , $inputData , $outputparameter );
			
         
            if( $output ){
                $response['status']     =   1;
                $response['msg']        =   'success';
                $response['errMsg']     =   $output;
            }
            
            return  $response;
        
        }catch( \Exception $e ){
            
            $response['reason'] =   $e->getMessage();
			
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $e );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['reason']     =   $e->getTraceAsString();
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
             
            return  $response;
            
        }
        
        
        
    }
	
	public function fileCreateWithByte( $pathWithFilename , $content , $getlocationftp = null ){
        
          
        $response['status']     =   0;
        $response['msg']        =   'failed';
        $response['errMsg']     =   'Oops , something went wrong.';
        
        if( !is_null( $getlocationftp  ) ){
            $pathWithFilename       =       $this->pathpreparationAdjustment( $pathWithFilename , $getlocationftp );
        }
        
        $cmnobj         =       new CommonMethodsController();
        
        try{
            
            $serviceurl     =       $this->metaExtractor;
            
            $methodname         =       'FileWriteByte';
			$outputparameter    =       'FileWriteByteResult';
		  
			//$methodname         =       'FileWrite';
			//$outputparameter    =       'FileWriteResult';
           
            $inputData          =       array( 'data' => $content , 'outputPath' =>  $pathWithFilename );
				
            $output             =       $cmnobj->soapServiceCall( $serviceurl ,  $methodname , $inputData , $outputparameter );
		
         
            if( $output ){
                $response['status']     =   1;
                $response['msg']        =   'success';
                $response['errMsg']     =   $output;
            }
            
            return  $response;
        
        }catch( \Exception $e ){
            
            $response['reason'] =   $e->getMessage();
			
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $e );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['reason']     =   $e->getTraceAsString();
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
             
            return  $response;
            
        }
        
        
        
    }
    
    public function fileGetContent( $path , $getlocationftp = null ){
            
        $response['status']     =       0;
        $response['msg']        =       'failed';
        $response['errMsg']     =       'Oops , something went wrong.';
        $cmnobj                 =       new CommonMethodsController();
        
        if( !is_null( $getlocationftp  ) ){
            $path       =       $this->pathpreparationAdjustment( $path , $getlocationftp );
        }
        
        try{
          //  $serviceurl     =       'http://172.24.131.162:8101/PGDWCFSERVICE.svc?wsdl';
           $serviceurl     =      $this->metaExtractor;
		  
            $methodname         =   'FileRead';
            $inputparameter     =   'data';
            $outputparameter    =   'FileReadResult';
            
            $inputData          =    array( 'data' => $path );
			
            $output     		=    $cmnobj->soapServiceCall( $serviceurl , $methodname , $inputData   , $outputparameter );
         
            if( $output ){
                
                $response['status']     =   1;
                $response['msg']        =   'success';
                $response['errMsg']     =   $output;
               
            }
            
            return $response;
            
        }catch( \Exception $e ){
            
            $response['reason'] =   $e->getTraceAsString();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $e );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
            return $response;
            //return  response()->json( $response , 200 );
            
        }
        
    }
    
    public function fileListWithSize( $path , $getlocationftp = null , $extractParam = 'All' ){
          
        $response['status']     =   0;
        $response['msg']        =   'failed';
        $response['errMsg']     =   'Oops , something went wrong.';
        
        if( !is_null( $getlocationftp  ) ){
            $pathWithFilename       =       $this->pathpreparationAdjustment( $path , $getlocationftp );
        }
        $cmnobj         =       new CommonMethodsController();
        
        try{
            $serviceurl         =       $this->metaExtractor;
            $methodname         =       'FileListWithSize';
            $outputparameter    =       'FileListWithSizeResult';
           
            $inputData          =       array( 'data' => $path );
	
            $output             =       $cmnobj->soapServiceCall( $serviceurl ,  $methodname , $inputData , $outputparameter );
           
            if( $output ){
                
                $arrinp     =       json_decode( $output , true );
                
                if( !empty( $arrinp ) ){            
                    $folderArr      =       $arrinp[0];
                    $arrinp         =       $folderArr;
                    if( count( $arrinp ) ){
                        $fileArr    =   $arrinp['filesLists'];
                        if( $extractParam   == 'All' ){    
                            $arrinp     =   $fileArr;
                        }else if( $extractParam == 'FileName' ){
                            $arrinp     =   $this->array_filterByKey( $fileArr , $extractParam );
                        }else if( $extractParam == 'FileSize' ){
                            $arrinp     =   $this->array_filterByKey( $fileArr , $extractParam );
                        }else{
                            $arrinp     =   $fileArr;
                        }
                    }else{
                        $arrinp     =   array();
                    }

                }else{
                    $arrinp =   array();
                }

                $response['status']     =   1;
                $response['msg']        =   'success';
                $response['errMsg']     =   'success';
                $response['data']       =   $arrinp;
            }
            
            return  $response;
        
        }catch( \Exception $e ){
            
            $response['reason'] =   $e->getMessage();
            $err_handle     =       new errorController();
            $errorid        =       $err_handle->handleApplicationErrors( $e );
            $errMsgPrev     =       $response['errMsg'];            
            $response['errorid']    =   $errorid;
            $response['reason']     =   $e->getTraceAsString();
            $response['errMsg']     =   $errMsgPrev.' [ error id : '.$errorid.' ]';
             
            return  $response;
            
        }
        
    }
    
    public function fileExists( $path , $getlocationftp = null ){
       $cmnobj         =       new CommonMethodsController();
        $status     =       false;
       
        if( !is_null( $getlocationftp  ) ){
            $path       =       $this->pathpreparationAdjustment( $path , $getlocationftp );
        }
    
        if( !empty( $path ) ){
            
            $path               =       $cmnobj->forwardslashPathPrepare( $path , true );
          
            $returnpop   =   $arrayin             =       explode( '/' , $path );
            array_pop( $returnpop );
       
            $path                =       implode( '/' , $returnpop );
            $indexkey            =       count( $arrayin )-1;
            $filenameTofind      =       $arrayin[$indexkey];
   
            $returnArr           =       $this->fileListWithSize( $path , $getlocationftp , 'FileName' );
			
            
            if( $returnArr['status'] && !empty($returnArr['data'])){               
               $status              =       in_array( $filenameTofind ,  $returnArr['data'] );
            }else{
				$status              =   false;
			}
            
        }
	
   
        return $status;
    }
    
    public function array_filterByKey( $arrinp  , $extract ){
        
        $arrRes =   array();
        foreach( $arrinp as $key => $value ){
          
           $arrRes[]    =   $value[$extract]; 
        }
        
        return $arrRes;
    }
    
    public function deleteFile( $path ){

    }

    #both file and folder related collection

    public function fileOrFolderRenaming( $pathWithFilename , $newname ){

    }

    public function serviceStatusCheck( ){
        
        #status checkup
        $apiurl     =   $this->locationBasedWebServiceUrl;
        
    }
   
    public function logingServiceRequest( $input_arr = array() , $rowid = null ){
        
        $status   = false;
        
        if( is_null( $rowid  ) ){
            $status  = fileManagerServiceModel::insertGetId( $input_arr );
        }
        
        if( !is_null($rowid) ){
            $condi      =   [ 'ID' => $rowid ];
            $status     =    fileManagerServiceModel::where( $condi )->update( $input_arr );   
        }
        
        return $status;
        
    }
    
    public function prepareCommonInputFomatXml( $method  , $input , $impact_options=array() ){
        
        $xmlStr =   '';
        $preparedXml    =   '';
        
        $metadataSec        =   \Config::get('requiredconstants.FILESERVICE_COMMON_METADATA_SEC');
        $workflowSec        =   \Config::get('requiredconstants.FILESERVICE_COMMON_WORKFLOW_SEC');
        
        $processSec         =   $this->inputConversionForService( $method  , $input , $impact_options );
        
        $preparedXml        .=  "$metadataSec"
                . "$processSec"
                . "$workflowSec";
       
        $xmlStr              =  '<WorkflowMetadata>'
                                    .$preparedXml
                                .'</WorkflowMetadata>';
        
        $cmn_obj        =       new CommonMethodsController();
        $xmlStr  =       $cmn_obj->formatXmlString( $xmlStr );
     
        if(  true ){
            echo '<pre>';
            echo htmlspecialchars($preparedXml);
            echo '<br/>';echo '<br/>';
            echo 'Output :';
            echo '<br/>';
           
        }
        
        return $xmlStr;
        
    }
    
    public function inputConversionForService( $method , $input , $impact_arr ){
        
        //loosely coupled type string  : $input
        
        $processed_xml_str         =       '';
        
        switch( $method ){
            
            case 'fileGetContent':
                $processed_xml_str  .=    "<$method>"
                    ."<File>$input</File>"
                    . "</$method>";
                break;
            
            case 'fileCreate'   :
                $processed_xml_str  .=    "<$method>"
                    ."<path>".$input['pathWithFilename']."</path>"
                    ."<content>".$input['content']."</content>"
                    . "</$method>";
                break;
        }
        
        
        return  $processed_xml_str;
        
    }
    
    public function prepareUpdationValues( $inputarr , &$output){
       
        $output['REMARKS']          =        $inputarr['remarks'];
        #$output['RESPONSE_LOG']     =        json_encode( $inputarr['Artwork'] );
        $output['END_TIME']         =        $inputarr['endtime'][1];
        $output['updated_at']       =        date( 'Y-m-d H:i:s' );
        $output['STATUS']           =        $inputarr['status'];
        
        return $output;
    }
   
    public function validationRuleForResponseSignal(){
        
        $rules['process']           =       'required';
        //$rules['metaid']            =       'required';
        $rules['tokenkey']          =       'required';
        $rules['endtime']           =       'required';
       // $rules['round']             =       'required';
        $rules['remarks']           =       'required';
        $rules['status']            =       'required';
        
        return $rules;
    }
    
    public function testSoapServiceCall( ){
            
        $cmnobj         =       new CommonMethodsController();
        $serviceurl     =    'http://172.24.175.46:8090/PGDWCFSERVICE.svc?wsdl';
//        $path           =     '//172.24.191.59/e/ftp/SP_BOOKS/PRODUCTION/472917_1_En/S300/JOBSHEET/Chapter_3/472917_1_En_3_JobSheet_100.xml';
        $path           =     '//172.24.136.41/Magnus_SP_Books/PRODUCTION/472917_1_En/S300/JOBSHEET/Chapter_3/472917_1_En_3_JobSheet_100.xml';
        
        $methodname         =   'FileListWithSize';
        $inputData          =   array( 'data' => $path );
        $outputparameter    =   'FileListWithSizeResult';
        $resturResp         =   $this->fileExists( $path );
        var_dump( $resturResp );
        exit;
        $output     =       $cmnobj->soapServiceCall( $serviceurl,  $methodname , $inputData , $outputparameter );
        $extractParam   =   'FileSize';
                $arrinp     =       json_decode( $output , true );
                
                if( !empty( $arrinp ) ){            
                    $folderArr      =       $arrinp[0];
                    $arrinp         =       $folderArr;
                    if( count( $arrinp ) ){
                        $fileArr    =   $arrinp['filesLists'];
                        if( $extractParam   == 'All' ){    
                            $arrinp     =   $fileArr;
                        }else if( $extractParam == 'FileName' ){
                            $arrinp     =   $this->array_filterByKey( $fileArr , $extractParam );
                        }else if( $extractParam == 'FileSize' ){
                            $arrinp     =   $this->array_filterByKey( $fileArr , $extractParam );
                        }else{
                            $arrinp     =   $fileArr;
                        }
                    }else{
                        $arrinp     =   array();
                    }

                }else{
                    $arrinp =   array();
                }

        dd( $arrinp );
    }
    
    public function pathpreparationAdjustment( $path , $getlocationftp ){
        
        $path_prework       =       $path;
        $defaultFileSvrPath =       \Config::get( 'serverconstants.FILE_SERVER_ROOT_DIR' ).\Config::get( 'serverconstants.FILE_SERVER_FTP_PATH' );
        $defaultFTPPath     =       '/'.\Config::get( 'serverconstants.FILE_SERVER_FTP_PATH' );
        
        $hostip             =       !empty( $getlocationftp->FTP_HOST ) ? $getlocationftp->FTP_HOST : (!empty( $getlocationftp->HOST ) ? $getlocationftp->HOST : null);
        $ftpPath_root       =       !empty( $getlocationftp->FTP_PATH ) ?  $getlocationftp->FTP_PATH : $defaultFTPPath;
        $fileserverpath     =       !empty( $getlocationftp->FILE_SERVER_PATH ) ?  $getlocationftp->FILE_SERVER_PATH : $defaultFileSvrPath;  
        $cmnobj             =       new CommonMethodsController();
        
        if( substr( $path_prework , 0 , 1 ) !== '/' ){
            $path_prework   =  "/$path_prework";
        } 
        //if root path is not start with / add slash
        if( substr( $ftpPath_root , 0 , 1 ) !== '/' ){
            $ftpPath_root   =  "/$ftpPath_root";
        }
        
        if( substr( $fileserverpath , 0 , 1 ) !== '/' ){
            $fileserverpath   =  "/$fileserverpath";
        }
        
        if( !is_null( $hostip ) && !is_null( $ftpPath_root )  ){            
            $path_prework       =       str_replace( $ftpPath_root , '' , $path_prework );
            $path_prework       =       $hostip.$fileserverpath.$path_prework;
        }
        
		$path_prework			=		str_replace(  '//' , '\\' , $path_prework );
		$path_prework			=		str_replace(  '/' , '\\' , $path_prework );
		
		$explodearr				=		explode( '\\' , $path_prework );		
		$explodearr				=		array_unique( $explodearr );
		$path_prework			=		implode( '\\' , $explodearr );
		
		if( !strpos(  $explodearr[count( $explodearr ) ]  , '.' ) ){
			$path_prework .= '\\';
		}
		
        $path               =       $cmnobj->backslashPathPrepare( $path_prework , TRUE );
        
        return $path;
        
    }
    
}