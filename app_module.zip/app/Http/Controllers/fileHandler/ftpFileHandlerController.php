<?php
namespace App\Http\Controllers\fileHandler;

use App\Http\Controllers\Controller;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;

use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;

class ftpFileHandlerController extends Controller
{   
    public $connection = false;
    public $copyStatus  =   array();
    public $ftpHost     =   '';
    
    public function __construct( $host , $usr , $psw )
    {  
       
        ini_set('max_execution_time', 0);
       
         $this->copyStatus      =       array();
         $this->ftpHost         =       $host;
         $conn_id 		=       ftp_connect( $host );
	 $login_result          =       ftp_login(  $conn_id, $usr, $psw )or die('ftp Connection not authorized');
       
         $this->connection   =   $conn_id;
         
    }
    
    public function __destruct(){
        
        if ($this->connection) {
            ftp_close( $this->connection );
            $this->connection = null;
        }
        
    }
    
    public function close()
    {
        if ($this->connection) {
            ftp_close( $this->connection );
            $this->connection = null;
        }
    }
    
    public function getDirectoryFiles( $src_path ){
        
        $conn_id        =       $this->connection;
        $dirList        =       array();
         
        $host           =       $this->ftpHost;
        $crd                =       Config::get('constants.FILE_SERVER_CREDENTIALS'); 
         
        $src_path1	=	str_replace( $host , '', $src_path);
        $src_path1	=	str_replace( $crd , '', $src_path1);
        $dirList        =       ftp_nlist( $conn_id , $src_path1 );  
        if( is_dir( $src_path ) ){
           
           $dirList     =     ftp_nlist( $conn_id , $src_path1 );  
           
        }
       
        return $dirList;
        
    }
    
    public function make_directory($dir){
	
        $ftp_stream     =   $this->connection;
        // if directory already exists or can be immediately created return true
	if ( self::ftp_is_dir($dir) || @ftp_mkdir($ftp_stream, $dir)) return true;
	// otherwise recursively try to make the directory
	if (!self::make_directory(dirname($dir))) return false;
	// final step to create the directory
	return ftp_mkdir($ftp_stream, $dir);
        
    }
    
    public function ftp_dir_copy( $srcdirPath, $desdirPath ) {
        $res	=	self::ftp_dir_copy_rec( $srcdirPath , $desdirPath );
	return $res;
    }
    
    public function ftp_dir_copy_word_file_only( $srcdirPath, $desdirPath,$getinputchapters,$readfileoptions ) {
        $res	=	self::ftp_dir_copy_rec_word_file_only( $srcdirPath , $desdirPath,$getinputchapters,$readfileoptions );
	return $res;
    }
    
    public function ftp_putAll( $src_dir , $dst_dir ) {

        $conn_id    =   $this->connection;
        
        $fileCopyStatus     =   array();
        
        if( !$conn_id )
            return false;
        
        if( @is_dir( $src_dir ) ){
            $d = dir($src_dir); 
           
            while($file = $d->read()) {
                // do this for each file in the directory
		if ($file != "." && $file != "..") {
                    // to prevent an infinite loop
                    if (is_dir($src_dir."/".$file)) { 
                    // do the following if it is a directory
                       
			if (!@ftp_nlist($conn_id, $dst_dir."/".$file)) {
                            $this->ftp_make_dir($dst_dir."/".$file, $conn_id); // create directories that do not yet exist
			}
                        
                        $this->ftp_putAll( $src_dir."/".$file, $dst_dir."/".$file ); // recursive part
                        
			} else {
                            $this->ftp_make_dir($dst_dir,$conn_id);
                            
                            if($file != 'Thumbs.db'){
                                try {
                                  
                                    $upload = ftp_put( $conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files
                                    
                                    if( !$upload ){
                                        $fileCopyStatus =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'file Copy failed. Try after sometimes' );
                                        break;
                                    }
                                    
                                } catch (Exception $ex) {
                                    throw new Exception( 'File Copying error . check network connection ,  try after sometimes' );
                                }
                                   
                                if( $upload == false ){
                                    $fileCopyStatus[$file]   =   'failed';
                                }else{
                                    $fileCopyStatus[$file]   =   'success';
                                }
                            }
			}
                    }
            }
            
            $d->close();
            
        }else{
           
           $crd                =       Config::get('constants.FILE_SERVER_CREDENTIALS'); 
           $fs                  =      $this->ftpHost;
           
           $src_dir = str_replace( $crd ,  '' , $src_dir );
           //$src_dir = str_replace( $fs  ,  'File_Server_Host' , $src_dir );
           
           $fileCopyStatus  =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'Source directory not available to copy. [ '.$src_dir.' ] ' );
                   
        }    
        
        $this->copyStatus       =       $fileCopyStatus;
        
	return $fileCopyStatus;
    
    }
    
    
    public function ftp_putAll_word_file_only( $src_dir , $dst_dir ,$getinputchapters   =   [],$readwordfile_exntenstion    =   null) {

        $conn_id    =   $this->connection;
        $fileCopyStatus     =   array();
        if( !$conn_id )
            return false;
        $originalfilenme    =   "";
        if( @is_dir( $src_dir ) ){
            $d = dir($src_dir);
            while($file = $d->read()) {
                $originalfilenme            =   substr(strrchr($file, "."), 0);
                $getvalidchapterfilenme[0]  =   '';
                if(strpos($file,'.') !== false)
                {
                    $getvalidchapterfilenme =   explode('.',$file);
                }
                
                //copy with given input files only
                if(count($getinputchapters)>=1)
                {
                    $convertlowercasename 	=   strtolower($originalfilenme);
                    $convertlowercaseextn 	=   array_map("strtolower",$readwordfile_exntenstion);
                    $convertlowercasechpname	=   strtolower($getvalidchapterfilenme[0]);
                    $convertlowercasechapter    =   array_map("strtolower",$getinputchapters);
                    if ($file != "." && $file != ".." && in_array($convertlowercasename,$convertlowercaseextn) && in_array($convertlowercasechpname,$convertlowercasechapter)) {
                    // to prevent an infinite loop
                    if (is_dir($src_dir."/".$file)) { 
                    // do the following if it is a directory

                        if (!@ftp_nlist($conn_id, $dst_dir."/".$file)) {
                            $this->ftp_make_dir($dst_dir."/".$file, $conn_id); // create directories that do not yet exist
                        }

                        $this->ftp_putAll_word_file_only( $src_dir."/".$file, $dst_dir."/".$file ); // recursive part

                        } else {
                            $this->ftp_make_dir($dst_dir,$conn_id);

                            if($file != 'Thumbs.db'){
                                try {

                                    $upload = ftp_put( $conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files

                                    if( !$upload ){
                                        $fileCopyStatus =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'file Copy failed. Try after sometimes' );
                                        break;
                                    }

                                } catch (Exception $ex) {
                                    throw new Exception( 'File Copying error . check network connection ,  try after sometimes' );
                                }

                                if( $upload == false ){
                                    $fileCopyStatus[$file]   =   'failed';
                                }else{
                                    $fileCopyStatus[$file]   =   'success';
                                }
                            }
                        }
                    }
                    $originalfilenme            =   "";
                    $getvalidchapterfilenme[0]  =   "";
                }
                //copy without given input files only
                else{
                    if ($file != "." && $file != ".." && in_array($originalfilenme,$readwordfile_exntenstion)) {

                    // to prevent an infinite loop
                    if (is_dir($src_dir."/".$file)) { 
                    // do the following if it is a directory

                        if (!@ftp_nlist($conn_id, $dst_dir."/".$file)) {
                            $this->ftp_make_dir($dst_dir."/".$file, $conn_id); // create directories that do not yet exist
                        }

                        $this->ftp_putAll_word_file_only( $src_dir."/".$file, $dst_dir."/".$file ); // recursive part

                        } else {
                            $this->ftp_make_dir($dst_dir,$conn_id);

                            if($file != 'Thumbs.db'){
                                try {

                                    $upload = ftp_put( $conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files

                                    if( !$upload ){
                                        $fileCopyStatus =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'file Copy failed. Try after sometimes' );
                                        break;
                                    }

                                } catch (Exception $ex) {
                                    throw new Exception( 'File Copying error . check network connection ,  try after sometimes' );
                                }

                                if( $upload == false ){
                                    $fileCopyStatus[$file]   =   'failed';
                                }else{
                                    $fileCopyStatus[$file]   =   'success';
                                }
                            }
                        }
                    }
                    $originalfilenme            =   "";
                }
                
            }
            
            $d->close();
            
        }else{
           
           $crd                =       Config::get('constants.FILE_SERVER_CREDENTIALS'); 
           $fs                  =      $this->ftpHost;
           
           $src_dir = str_replace( $crd ,  '' , $src_dir );
           //$src_dir = str_replace( $fs  ,  'File_Server_Host' , $src_dir );
           
           $fileCopyStatus  =   array( 'status' => 0  , 'msg' =>  'failed' , 'errMsg' => 'Source directory not available to copy. [ '.$src_dir.' ] ' );
                   
        }    
        
        $this->copyStatus       =       $fileCopyStatus;
        
	return $fileCopyStatus;
    
    }
    
    public function ftp_putAll_nb( $src_dir , $dst_dir ) {

        $conn_id    =   $this->connection;
        
        $fileCopyStatus     =   array();
        
        if( !$conn_id )
            return false;
        
        $d = dir($src_dir);
                
            while($file = $d->read()) {
               
                // do this for each file in the directory
		if ($file != "." && $file != "..") {
                    // to prevent an infinite loop
                    if (is_dir($src_dir."/".$file)) { 
                    // do the following if it is a directory
			if (!@ftp_nlist($conn_id, $dst_dir."/".$file)) {
                            $this->ftp_make_dir($dst_dir."/".$file, $conn_id); // create directories that do not yet exist
			}
                        $this->ftp_putAll_nb($conn_id, $src_dir."/".$file, $dst_dir."/".$file); // recursive part
                        
			} else {
                            
                            $this->ftp_make_dir($dst_dir,$conn_id);
                            
                            if($file != 'Thumbs.db'){
				
                                //$upload = ftp_put($conn_id, $dst_dir."/".$file, $src_dir."/".$file, FTP_BINARY); // put the files
                                
                                $ret  =  ftp_nb_fput( $conn_id , $dst_dir."/".$file , $src_dir."/".$file , FTP_BINARY, FTP_AUTORESUME );
                                
                                while ($ret == FTP_MOREDATA) {
                                    
                                   // Do whatever you want
                                   echo ".";
                                   // Continue uploading...
                                   $ret = ftp_nb_continue( $conn_id );                                
                                   
                                }
                                
                                if ($ret != FTP_FINISHED) {
                                    $fileCopyStatus[$file]   =   array( 'failed' , FTP_MOREDATA , );
                                }else{
                                    //$fileCopyStatus[$file]   =   true;
                                }
                                
                            }
			}
                    }
                    
            }
            
        $d->close();
	
        $this->copyStatus       =       $fileCopyStatus;
        
        if( in_array("failed", $fileCopyStatus )) {
            return $fileCopyStatus;
        }
	return true;
    }
    
    public function ftp_is_dir( $dir ){
        
	$ftp_stream = $this->connection;
        // get current directory
    	$original_directory = ftp_pwd($ftp_stream);
    	// test if you can change directory to $dir
	// suppress errors in case $dir is not a file or not a directory
	if ( @ftp_chdir( $ftp_stream, $dir ) ) {
	// If it is a directory, then change the directory back to the original directory
	ftp_chdir( $ftp_stream, $original_directory );
	return true;
	} else {
            return false;
	}
        
    }
    
    public function ftp_dir_copy_rec( $src_dir, $dst_dir) {

        $conn_id    =   $this->connection;
        //$src_dir	=	FILE_SERVER_FTTP_CREDENTIAL.$src_dir;
        $host       =       $this->ftpHost;
        $dst_dir	=	str_replace( $host , '', $dst_dir);
        //return 	self::ftp_putAll( $src_dir, $dst_dir);
        
        return 	self::ftp_putAll( $src_dir, $dst_dir);

    }	
    public function ftp_dir_copy_rec_word_file_only( $src_dir, $dst_dir,$getinputchapters,$readfileoptions) {

        $conn_id    =   $this->connection;
        //$src_dir	=	FILE_SERVER_FTTP_CREDENTIAL.$src_dir;
        $host       =       $this->ftpHost;
        $dst_dir	=	str_replace( $host , '', $dst_dir);
        //return 	self::ftp_putAll( $src_dir, $dst_dir);
        
        return 	self::ftp_putAll_word_file_only( $src_dir, $dst_dir,$getinputchapters,$readfileoptions);
    }	
    
    
    public function ftp_delet_dir($dir){
        
       // set up basic connection
	$conn_id = $this->connection;
	// login with username and password
	$login_result = ftp_login($conn_id, $ftp_user, $ftp_password);
	// try to delete the directory $dir
        if (ftp_rmdir($conn_id, $dir)) {
            echo "Successfully deleted $dir\n";
        } else {
            echo "There was a problem while deleting $dir\n";
        }
        
        ftp_close($conn_id);
        
    }
	
    public function ftp_file_exist($filePath) {
        
	$conn_id = $this->connection;
	
        if(ftp_size($conn_id,$filePath)!='-1')
            return true;
        else 
            return false;
	
    }
    
    public function ftp_copy($src_dir, $dst_dir){

        $conn_id    = $this->connection;
        $stream_options = array('ftp' => array('overwrite' => true));
	// Creates a stream context resource with the defined options
	$stream_context = stream_context_create($stream_options);
        
        if(copy($src_dir, $dst_dir,$stream_context)) {
            return true;
            ftp_close($conn_id);
	}else {
            return false;
            ftp_close($conn_id);
	}
		
    }
    
    public function ftp_file_put($fileName, $fileData){
	
	// Allows overwriting of existing files on the remote FTP server
	$stream_options = array('ftp' => array('overwrite' => true));
	
	// Creates a stream context resource with the defined options
	$stream_context = stream_context_create($stream_options);
	
	// Opens the file for writing and truncates it to zero length
	if ($fh = fopen($fileName, 'w', 0, $stream_context))
	{
	    // Writes contents to the file
	    fputs($fh, $fileData);
	   
	    // Closes the file handle
	    fclose($fh);
	}
	return $fh;
        
    }
    
    public function ftp_file_copy( $src_path , $desti_path ){
        $conn_id    =   $this->connection;
        //ftp_get($conn_id, $local_file, $server_file, FTP_BINARY)
    }
    
    public function get_ftp_file_list($folderPath) {
	
        $conn_id        =       $this->connection;
	$mode = ftp_pasv($conn_id, TRUE);
	// get contents of the current directory
	$contents = ftp_nlist($conn_id,$folderPath);
	ftp_close($conn_id);
        
	return $contents;
    }
    
    public function ftp_file_size($filePath) {
        
    	$conn_id 	=       $this->connection;
	$fileSize	=	ftp_size($conn_id,$filePath);
    	
        if($fileSize == '-1')
            return '0';
	else 
	return $fileSize;
	 
    }

    public function recursiveDelete($handle,$directory) {
	
	# here we attempt to delete the file/directory
	if( !(@ftp_rmdir($handle, $directory) || @ftp_delete($handle, $directory)) ){
	    # if the attempt to delete fails, get the file listing
	    $filelist = @ftp_nlist($handle, $directory);
	    # loop through the file list and recursively delete the FILE in the list
	    if(!empty($filelist)) {
		foreach($filelist as $file){
		    $this->recursiveDelete($handle,$file);
		}
	    }
            #if the file list is empty, delete the DIRECTORY we passed
	        $this->recursiveDelete($handle,$directory);
	    return true;
            
        }
        return true;
        
    }
    
    public function ftpRecursiveFileListing( $path ) {
        
        $ftpConnection      =       $this->connection;
        static $allFiles = array(); 
        $contents = ftp_nlist($ftpConnection, $path); 
        if(!empty($contents)){
            foreach($contents as $currentFile) { 
                // assuming its a folder if there's no dot in the name 
                if (strpos($currentFile, '.') === false) { 
                    $this->ftpRecursiveFileListing($ftpConnection, $currentFile); 
                }
                if(strpos($currentFile, '.') != false) {
                    $setpath	=	str_replace('//','/',$path.'/'. substr($currentFile, strlen($path) + 1));
		    $allFiles[] = $setpath;
                }
            } 
	}
        
    	return $allFiles; 
        
    } 
    
    public function ftp_make_dir ($folderPath){

        $conn_id 	=       $this->connection;
	$mode           =       ftp_pasv( $conn_id, TRUE );
	// get contents of the current directory
	$contents = $this->make_directory($folderPath);
	
        return $contents;
         
    }
	
    public function ftpFileExist( $file_path ){
        
        $conn_id 	=       $this->connection;
        $fileSize       =       ftp_size( $conn_id, $file_path );

        if ($fileSize != -1) {
            return true;
        } else {
            return false;
        }
        
    } 
    
    
   function ftpSingleFileCopyOrMove( $src ,  $descPath , $delete = false ){ 
        $options = array('ftp' => array('overwrite' => true));
        $stream = stream_context_create($options); 
        $fileExistPath               =       str_replace( '\\' , '/'  , $src );
        $src_arr                     =       ( explode('@' , $src ));
        $src_str                     =       str_replace( $this->ftpHost , '' , $src_arr[count($src_arr)-1] );
       
        $descPath                    =       str_replace( '\\' , '/'  , $descPath );
        $src                         =       str_replace( '\\' , '/'  , $src );
       
        $fileExist                   =       $this->ftpFileExist( $src_str );
       
        
        if( $fileExist  ){
            
            $dest_arr                =       explode( '/' , $descPath );
            $index                   =       count($dest_arr) - 1;
            unset( $dest_arr[$index] ); // extracting filename to build a folder first.
            
            $destFolder              =       implode(  '\\' ,  $dest_arr );
            $dest_arr                =       explode( '@' ,  $destFolder ); //extracting a credential , unneccessary
            $folder_create           =       str_replace( $this->ftpHost.'\\' , '' , ( $dest_arr[count($dest_arr) -1 ] ) );
            $folder_create           =       str_replace( $this->ftpHost , '' , $folder_create );
			
            $folder_create			 = 	     str_replace( '\\' , '/' , $folder_create );
            $make_folder             =       $this->ftp_make_dir( $folder_create );
            $content                 =       file_get_contents($src);
         
            if(!empty($content)) {
                $response_file           =       file_put_contents($descPath , $content,'0',$stream );
                
                if( $delete ){
                    ftp_delete($this->connection ,  $src_str );
                }
                return true;
            }
            
        }
        
       return false; 
    } 
    
    public function ftpDeleteFile( $file_path ){
        
        $conn_id 	=       $this->connection;
        $fileSize       =       ftp_delete( $conn_id, $file_path );
        return true;
                
    } 
    
    public function ftpRename($oldDir, $newDir){
        $conn_id          =       $this->connection;
        $fileStatus       =       ftp_rename( $conn_id, $oldDir, $newDir );
        return $fileStatus;
    }
	
}