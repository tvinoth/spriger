<?php
namespace App\Http\Controllers\fileHandler;

use App\Http\Controllers\Controller;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\fileHandler\fileHandlerController;

use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;

class fileHandlerController extends Controller
{
    
    public function insert(){
        
    }
    
    public function update(){
        
    }
    
    public function getDbInfoForFh( $mode ){
        
        $dbParam="";
        
        if( $mode == 'selectDb' ){
            
            $host           =       getenv( 'DB_HOST' );        //Host name of the Server
            $username       =       getenv( 'DB_USERNAME' );        //User Name of the Server
            $password       =       getenv( 'DB_PASSWORD' );    //Password of the Server
            $dbname         =       getenv( 'DB_DATABASE' ); 
            $tablename      =       'file_handler';
            
            $dbParam        =       $host."[]".$username."[]".$password."[]".$dbname."[]".$tablename;
            //echo $dbParam;
        }
        
        return $dbParam;
        
    }
    
    public static function saveFhInfo(Request $request) {

        $inpArray       =       array(); 
        
        if( !empty( $request->input('filePath') ) )
            $inpArray['file_path']       =       $request->input('filePath');	
	//$inpArray['scptPath']     =       getenv('APPLESCRIPT_FILE_PATH');	
        if( !empty( $request->input('bookid') ) )
            $inpArray['project_id']      =       $request->input('bookid');
	if( !empty( $request->input('processname') ) )
            $inpArray['processname']    =       $request->input('processname');
	if( !empty( $request->input('src_path') ) )
            $inpArray['src_path']       =       $request->input('src_path');
        if( !empty( $request->input('dest_path') ) )
            $inpArray['dest_path']      =       $request->input('dest_path');
	if( !empty( $request->input('openpath') ) )
            $inpArray['openpath']       =       $request->input('openpath');
	if( !empty( $request->input('ext') ) )
            $inpArray['ext']            =       $request->input('ext');
        if( !empty( $request->input('isdelete') ) )
            $inpArray['isdelete']       =       $request->input('isdelete');
        if( !empty( $request->input('methodName') ) )
            $inpArray['method_name']     =       $request->input('methodName');
        
        $inpArray['system_ip']   =   self::get_ip_address();
	
	$response[0]['rmiId']   =       fileHandler::insertNew($inpArray);   
        
	return response()->json($response); 
    }
	
    public static function checkFhStatus(Request $request) {
	
        $inpArray = array(); 
	$inpArray['FhID']      =       $request->input('rmiID');	
	$inpArray['systemIP']   =       self::get_ip_address();
        
	$response   =   fileHandler::checkFhStatus(  $inpArray  );     
	
        return response()->json($response); 
        
    }
    public static function checkFileStatus(Request $request) {
        $inpArray               =   array(); 
	$inpArray['FhID']       =   $request->input('rmiID');
        $typeofstatus           =   $request->input('typeofstatus');
	$inpArray['systemIP']   =   self::get_ip_address();
	$result                 =   fileHandler::checkFileStatus(  $inpArray  ); 
        if($result !=   null)
        {
            if($result->status  ==  0)
            {
                $response       =   array('result'=>500,'errMsg'=>'File Handler is not running try again'); 
                return response()->json($response);	
            }
            if($result->status  ==  1)
            {
                $typeofstatus   =   ($typeofstatus  ==  "Opendrive"?'Folder Opened Successfully':'Successfully checked out');
                $checkremarks   =   ($result->remarks    ==  'completed'?$typeofstatus:$result->remarks);
                $response       =   array('result'=>200,'errMsg'=>$checkremarks); 
                return response()->json($response);	
            }
        }
        $response       =   array('result'=>404,'errMsg'=>'File Handler is not running try again'); 
        return response()->json($response);
    }
    
    
    public static function get_ip_address() {
        // check for shared internet/ISP IP
	if (!empty($_SERVER['HTTP_CLIENT_IP']) && validate_ip($_SERVER['HTTP_CLIENT_IP'])) {
            return $_SERVER['HTTP_CLIENT_IP'];
	}
	// check for IPs passing through proxies
	
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // check if multiple ips exist in var
	if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
            $iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            foreach ($iplist as $ip) {
		if (validate_ip($ip))
			return $ip;
		}
            } else {
		if (validate_ip($_SERVER['HTTP_X_FORWARDED_FOR']))
                    return $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
	}
	
        if (!empty($_SERVER['HTTP_X_FORWARDED']) && validate_ip($_SERVER['HTTP_X_FORWARDED']))
            return $_SERVER['HTTP_X_FORWARDED'];
	if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validate_ip($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
            return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
	if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validate_ip($_SERVER['HTTP_FORWARDED_FOR']))
            return $_SERVER['HTTP_FORWARDED_FOR'];
        if (!empty($_SERVER['HTTP_FORWARDED']) && validate_ip($_SERVER['HTTP_FORWARDED']))
            return $_SERVER['HTTP_FORWARDED'];
	// return unreliable ip since all else failed
            return $_SERVER['REMOTE_ADDR'];
	}
        
}