<?php
namespace App\Http\Controllers\fileHandler;

use App\Http\Controllers\Controller;
use App\Models\apiClientAcknowledgement;
use App\Models\projectModel;
use App\Models\fileHandler;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Artisaninweb\SoapWrapper\SoapWrapper;
use App\Http\Controllers\CommonMethodsController;
use App\Models\productionLocationModel;
use App\Http\Controllers\fileHandler\fileHandlerController;

use Session;
use Mail;
use Validator;
use DB; 
use Log;
use Config;

class filemovementController extends Controller
{
    
    public function fileMovement(Request $request){
        
        $input_params       =       $request->all();
        $src_path           =       ( $input_params['src_path'] ) ;
        $dest_path          =       ( $input_params['dest_path'] ) ;
        $is_delete          =       ( !empty($input_params['isdelete'])?$input_params['isdelete']:'0' ) ;
        $jobId              =       ( $input_params['job_id'] ) ;
        $openpath            =       ( $input_params['openpath'] ) ;
        $methodName         =       ( $input_params['method_name'] ) ;
        
        if($src_path !='' && $dest_path!='') {
            
            $locationDetails       =   productionLocationModel::getJobLocationServerPath( $jobId );
           
            $host                  =   $locationDetails['HOST'];
            $usr                   =   $locationDetails['FTP_USERNAME'];
            $psw                   =   $locationDetails['FTP_PASSWORD'];
            $ftpObj                =   new ftpFileHandlerController($host, $usr, $psw);
            $crd                   =   $locationDetails['FTP_PATH_CREDENTIAL'];
            
            if($methodName == 'checkout'){
               $res     =    $this->checkout($ftpObj,$crd.$host.$src_path, $dest_path, $is_delete);
            }
         
        }
        
       return  $res;
      
    }
    
    
    public function checkout($ftpObj, $src_path, $dest_path, $is_delete ){
        
	try{
            $response       =       $ftpObj->ftp_dir_copy( $src_path , $dest_path );
            
        } catch (Exception $ex) {
            
            $response   =   array(
                                'status' => 0, 
                                'msg'   => 'Failed' ,  
                                'errMsg'    => $ex->getMessage()
                                );
                
            return response()->json( $response );
            
        }
        
        if( in_array( 'failed' , $response ) ){
            
            foreach ($response as $key => $value ){
                if( $value == 'success' ){
                    unset( $response[$key] );
                }
            }
            
            $response   =       array( 'status' => 'failed'  , $response );
            
        }else{
            $response    =       array( 'status' => 'success' , $response );
        }
        
        return response()->json($response);
        
    }
    
    function jobsheetData(Request $request){
        $input_params       =       $request->all();
        echo "<pre>";print_r($input_params);exit;
        $jobId           =       ( $input_params['jobId'] ) ;
        $stageId           =       ( $input_params['stageId'] ) ;
    }
    
    //insert record in filehandler table for delete ftp drive
    public function doDeletefileinfileproduction(Request $request,$filepath)
    {
        $returndata     =   [];
        if(!empty($filepath))
        {
            $postdata               =   [];
            $postdata['file_path']  =   $filepath;
            $postdata['method_name']=   "deleteFileServer";
            $postdata['system_ip']  =   $request->ip();
            $postdata['processname']=   "deleteFileServer";
            $insertfilehandler      =   fileHandler::insertNew($postdata);
            if($insertfilehandler)
            {
                $result             =   array('status'=>2,'errMsg'=>'File Production delete operation submitted Successfully...');   
                return $result;
            }
            $result                 =   array('status'=>0,'errMsg'=>'File Production delete operation not submitted Successfully...');   
            return $result;
        }
        $result                     =   array('status'=>0,'errMsg'=>'File Production path is empty kindly check it');   
        return $result;
    }
    
     //insert record in filehandler table for delete ftp drive
    public function deletefileinproduction($filepath)
    {
        $returndata     =   [];
        if(!empty($filepath))
        {
            $postdata               =   [];
            $postdata['file_path']  =   $filepath;
            $postdata['method_name']=   "deleteFileServer";
            $postdata['system_ip']  =   Request::ip();
            $postdata['processname']=   "deleteFileServer";
            $insertfilehandler      =   fileHandler::insertNew($postdata);
            if($insertfilehandler)
            {
                $result             =   array('status'=>2,'errMsg'=>'File Production delete operation submitted Successfully...');   
                return $result;
            }
            $result                 =   array('status'=>0,'errMsg'=>'File Production delete operation not submitted Successfully...');   
            return $result;
        }
        $result                     =   array('status'=>0,'errMsg'=>'File Production path is empty kindly check it');   
        return $result;
    }
    
}