<?php
namespace App\Http\Controllers\workflow;

use App\Http\Controllers\Controller;
use App\Models\customizationModel;
use App\Models\workflowServerMapPathModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\productionLocationModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\workflowModel;
use App\Models\roundModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Models\checkoutModel;
use App\Http\Controllers\checkout\stageMangerController;
use Session;
use Validator;
use PDF;
use Config;
use DB; 
use Crypt;
class workflowRuleController extends Controller
{
    public function getRuleForGivenStage($stageId,$roundId,$jobId,$wfId,$wfMid=''){
         $rule = array();
        if(empty($stageId) || empty($roundId) || empty($jobId) || empty($wfId) )
            return $rule;
        
        $sql = "select wr.* from task_level_userdefined_workflow as uw 
                join user_defined_workflow_rule as wr ON wr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = uw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID
                where uw.JOB_ID = '$jobId' and uw.ROUND = '$roundId' and uw.WORKFLOW = '$wfId' and uw.STAGE = '$stageId'";
       
        $getRec        =   DB::select( $sql );
        if (!empty($getRec)) {
            foreach ($getRec as $key => $value) {

                $goToStage = $value->GOTO_STAGE_ID;

                if ($value->RULE_TYPE == '1') { // if error                    
                    $rule['1'] = $this->getStageSequence($goToStage, $roundId, $jobId, $wfId);
                } elseif ($value->RULE_TYPE == '2') { // if no error                    
                    $rule['2'] = $goToStage;
                } elseif ($value->RULE_TYPE == '3') {  // Reject
                    $rule['3'] = $goToStage;
                } elseif ($value->RULE_TYPE == '4') {  // ifno error complete All pages
                    $rule['4'] = $goToStage;
                }
            }
        }
        return $rule;
       
    }
    
    public function getStageSequence($stageId,$roundId,$jobId,$wfId){
        
        $sql  = " SELECT uw.STAGE,uw.STAGE_SEQ
                    FROM task_level_userdefined_workflow AS uw
                    WHERE uw.JOB_ID = '$jobId' AND uw.WORKFLOW = '$wfId' AND uw.ROUND = '$roundId' AND stage = '$stageId'";
        
         $getRec        =   DB::select( $sql );
         
         if(!empty($getRec)){
             return $getRec['0']->STAGE_SEQ;
         }
         else {
             return 1;
         }
    }
    
    public function getWorkflowRuleBasedJobStageAvail(  $jobStageId , $ruletype  = 1 ){ 
   
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);            
        
        if(count($stageDetails)){
           $stageDetails   =   $stageDetails[0];
           $stageId     =       $stageDetails->STAGE_ID;
           $jobId       =       $stageDetails->JOB_ID;
           $roundId     =       $stageDetails->ROUND_ID;
           $wfId        =       $stageDetails->WORKFLOW_ID;
           $wfMid       =       $stageDetails->WORKFLOW_MASTER_ID;
          
            $sql        =       "select wr.* from task_level_userdefined_workflow as uw 
                                join user_defined_workflow_rule as wr ON wr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = uw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID
                                where uw.JOB_ID = '$jobId' and uw.ROUND = '$roundId' and uw.WORKFLOW = '$wfId' and uw.STAGE = '$stageId' and wr.rule_type = '".$ruletype."' limit 1";
    
            $ruleDetail        =   DB::select( $sql );
           
            if( count( $ruleDetail ) ){
                $ruleDetail =   $ruleDetail[0];
                return $ruleDetail->GOTO_STAGE_ID;                 
            }
			if( !count( $ruleDetail ) ){
				//return $this->PaginationFailureStageRule( $stageId  );
			}
        }
      
        return false;
    }
    
	public function PaginationFailureStageRule( $stageid ){
		
		$gotostg	=	false;
		$mnPgn		=	\Config::get( 'constants.STAGE_COLLEECTION.MANUAL_PAGINATION' );
		$mnPgn1		=	\Config::get( 'constants.STAGE_COLLEECTION.AUTO_PAGE' );
		
		switch( $stageid ){
			
			case \Config::get( 'constants.STAGE_COLLEECTION.AUTO_CAP' ):
				$gotostg = $mnPgn;
				break;
				
			case \Config::get( 'constants.STAGE_COLLEECTION.AUTO_DP' ):
				$gotostg = $mnPgn;
				break;
				
			case \Config::get( 'constants.STAGE_COLLEECTION.AUTO_PAGE_BG' ):
				$gotostg = $mnPgn1;
				break;
				
			case \Config::get( 'constants.STAGE_COLLEECTION.COVER_DP' ):
				$gotostg = $mnPgn;
				break;
				
			default :
				$gotostg = false;
				
		}
		
		return $gotostg;
		
	}
	
    public function checkIsSkipWorkflowRule(  $jobStageId , $ruletype  = 1 ){ 
   
        $checkoutObj        =   new checkoutModel();
        $stageDetails       =   $checkoutObj->getStageInfo($jobStageId);            
        
        if(count($stageDetails)){
           $stageDetails   =   $stageDetails[0];
           $stageId     =       $stageDetails->STAGE_ID;
           $jobId       =       $stageDetails->JOB_ID;
           $roundId     =       $stageDetails->ROUND_ID;
           $wfId        =       $stageDetails->WORKFLOW_ID;
           $wfMid       =       $stageDetails->WORKFLOW_MASTER_ID;
          
            $sql        =       "select wr.* from task_level_userdefined_workflow as uw 
                                join user_defined_workflow_rule as wr ON wr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = uw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID
                                where uw.JOB_ID = '$jobId' and uw.ROUND = '$roundId' and uw.WORKFLOW = '$wfId' and uw.STAGE = '$stageId' and rule_type = ".$ruletype." limit 1";
       
            $ruleDetail        =   DB::select( $sql );
            return $ruleDetail;                 
        }
      
        return false;
    }
     
}