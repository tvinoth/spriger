<?php
namespace App\Http\Controllers\workflow;

use App\Http\Controllers\Controller;
use App\Models\customizationModel;
use App\Models\workflowServerMapPathModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\productionLocationModel;
use App\Models\jobModel;
use App\Models\bookinfoModel;
use App\Models\workflowModel;
use App\Models\roundModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Validator;
use PDF;
use Config;
use DB; 
use Crypt;
class serverMapPathController extends Controller
{
    public function index( $jobid , $rid ,  $wmid , $wfid , $wtype = 0 ){
        
        $data   =       array();
        $serverMapPathCollection    =       array();
        $wsmp_obj       =       new workflowServerMapPathModel();
        $tuwf_obj       =       new taskLevelUserdefinedWorkflow();
        $prdl_obj       =       new productionLocationModel();
        $jobM_obj       =       new jobModel();
        
        //try{
        $wfw_obj        =       new workflowModel();
        $wfw_data       =       $wfw_obj->getWorkflosByMasterId( $wmid );
       
        $wfdata         =       $wfw_obj->getWorkflosByMasterIdAndType( $wmid , $wtype);
        $wtype          =        $wfdata->WORKFLOW_TYPE;
        $getStgCl       =       $tuwf_obj->getUserdefinedWorkflowInformation( $jobid , $rid , $wmid , $wfid , $wtype );
        
        $jobDetai       =       $jobM_obj->getJobdetails( $jobid );
        
        $srcType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.SRC_TYPE' );
        $wrkType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.WRK_TYPE' );
        $destType       =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.DEST_TYPE' );
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_WORKFLOW'),$data);
        $data['pageTitle']  =   'WorkflowServerPath';
        $data['pageName']   =   'Workflow Server Path Map';
        $data['jobid']      =   $jobid;
        $data['jobref']     =   $jobDetai->JOB_REF;
        $data['bookid']     =   $jobDetai->BOOK_ID;
        $data['round']      =   $rid;
        $data['wtype']      =   $wtype;
        $data['wmid']       =   $wmid;
        $data['wfid']       =   $wfid;
        $data['wfw_data']   =   $wfw_data;
        
        $prdlInfo           =   $prdl_obj->getAllPrductionDetails();
        $prdSrc             =   array();
        foreach( $prdlInfo as $index => $valuePrd ){
        
             $prdSrc2['label']    =  $valuePrd->FTP_HOST;
             $prdSrc2['indx']     =  $index;
             $prdSrc[]          =  $prdSrc2;
             $prdUser[]         =  ''.$valuePrd->FTP_USER_NAME.'';
             
             $prdPass[]         =  \Crypt::decryptString( $valuePrd->FTP_PASSWORD );
                
        }
        
        $data['prdSrc']       =    json_encode( $prdSrc );
        $data['prdUser']      =    $prdUser;
        $data['prdPass']      =    $prdPass;
        
        $wname   =   $getStgCl->pluck( 'WORKFLOW_NAME');
        $is_auto_arr    =       array();
        
        if( isset( $wname[0] ) ){

            $data['wflwname']  =   $wname[0];
            $wmname =   $getStgCl->pluck('WORKFLOW_MASTER_NAME');

            $data['wflwMastername']  =   $wmname[0];

           if( $getStgCl->count() ){

                foreach( $getStgCl as $indx => $value ){

                    $stageid    =       $value->STAGE;
                    $wflw       =       $value->WORKFLOW_ID;
                    $keyPre     =       $stageid.'@@@'.$value->STAGE_NAME;
                    
                    if( $value->IS_AUTO == 1 )
                        $is_auto_arr[]    =   $stageid;
                    
                    //if( $value->IS_AUTO == 1 )
                    //$is_semiauto_arr[]    =   $stageid;
                    
                    $serverMapPathCollection[$keyPre]['srcPath']     =     $wsmp_obj->getServerPathBasedOnWorkflowStages( $jobid , $wflw , $stageid , array(  $srcType ) );
                    $serverMapPathCollection[$keyPre]['wrkPath']     =     $wsmp_obj->getServerPathBasedOnWorkflowStages( $jobid , $wflw , $stageid , array(  $wrkType ) );
                    $serverMapPathCollection[$keyPre]['destPath']     =    $wsmp_obj->getServerPathBasedOnWorkflowStages( $jobid , $wflw , $stageid , array(  $destType ) );

                }

            }else{

            }
            
        }else{
            
            $statusCode         =       '4004';
            return redirect( 'book_infodetails/'.$jobid.'?cntlr=serverMapPathController&statusCode='.$statusCode  ); 
            
        }
        
        $semiautocollect        =           \Config::get( 'dynamicConstant.SEMI_AUTO_STAGES' );
        
        $data['autostages']         =   $is_auto_arr;
        $data['semistages']         =   array_values($semiautocollect);
        $data['backurl']   =   url('/').'/book_infodetails/'.$jobid;
        $data['serverMapPathCollection']    =       $serverMapPathCollection;
        
       return view( 'workflow/serverpath' , $data );
       
       //}catch(\Exception $e){
          $statusCode   =   4003;
          //return redirect( 'book_infodetails/'.$jobid.'?cntlr=serverMapPathController&statusCode='.$statusCode  ); 
       //}
       
    }
    
    public function addNewWorkflowServerMapPath( Request $request ){
        
        $wsmp_obj       =       new workflowServerMapPathModel();
        $tuwf_obj       =       new taskLevelUserdefinedWorkflow();
        $jobM_obj       =       new jobModel();
        
        $response       =       array();
        
        $jobid  =    $request->input( 'jobid' );
        $rid    =    $request->input( 'round' );
        $wmid   =    $request->input( 'wmid' );
        $wfid   =    $request->input( 'wfid' );
        $wtype  =    $request->input( 'wtype' );
        
        $params =    array( 'jobid' =>$jobid, 'rid' => $rid , 'wmid' => $wmid );
        $getStgCl       =       $tuwf_obj->getUserdefinedWorkflowInformation( $jobid , $rid , $wmid , $wfid , $wtype );
        
        $wrkflw         =   ( $getStgCl->pluck('WORKFLOW') );
        
        if( $getStgCl->count() ){
             
            $getRequiredStage   =       $tuwf_obj->getWorkflowStages(  $jobid , $rid , $wrkflw[0] , $response );

            foreach( $getRequiredStage as $index => $stgrcd ){

                $params['stage_id'] =        $stgrcd->STAGE;
                $this->updateWorkflowServerPath( $request , $params , $wrkflw , $response );
                
            }
	
        }else{
            
            $response   =   array( 'status' => 0 , 'msg' => 'faild' , 'errMsg' => 'workflow entry does not exist' );
        }
         
        return response()->json( $response );
        
    }
    
   public function updateWorkflowServerPath( $request , $params  , $wrkflw , &$response ){
        
        extract( $params );
        $time   =    date( 'Y-m-d H:i:s' );
        $userid =    '29218';
        
        $srcType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.SRC_TYPE' );
        $wrkType        =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.WRK_TYPE' );
        $destType       =       \Config::get( 'constants.WORKFLOW_SERVER_PATH.FOLDER_TYPE.DEST_TYPE' );
        $statusCode     =       '4001';
        
        //try{
           
        //DB::beginTransaction();
        
        //For Source Path Insert
        $sql_delete = "DELETE FROM `workflow_server_map` WHERE WORKFLOW_ID='" .$wrkflw[0]. "' AND ROUND_ID='" .$rid. "' AND JOB_ID='".$jobid. "' AND STAGE_ID ='".$stage_id."' and FOLDER_TYPE = ".$srcType;
	
        DB::delete( $sql_delete );
        
        $source_row_count       =        count( $request->input( 'usernamesrc_'.$stage_id ) );
        
        for ($j = 0; $j < $source_row_count; $j++){
            //dd( $request->input( 'filemovementsrc_' . $stage_id )[$j]);
            $serverpath_src         =       addslashes(@$request->input( 'serveripsrc_' . $stage_id)[$j]);
            $folderpath_src         =       addslashes(@$request->input( 'folderpathsrc_' . $stage_id)[$j]);
            $username_src           =       (@$request->input( 'usernamesrc_' . $stage_id)[$j]);
            $password_src           =       (@$request->input( 'passwordsrc_' . $stage_id)[$j]);
			
			
			
            $fileplacement_src      =       addslashes(@$request->input( 'filemovementsrc_' . $stage_id)[$j]);
            $fileext_src            =       addslashes(@$request->input( 'fileextsrc_' . $stage_id )[$j]);
            $filestring_src         =       addslashes(@$request->input( 'filestringsrc_' . $stage_id )[$j]);
            $serverpath_src         =       str_replace( '\\' , '/' , $serverpath_src );
            $folderpath_src         =       str_replace( '\\' , '/' , $folderpath_src );

            if ($fileplacement_src != "" && $serverpath_src != "" && $folderpath_src != "" && $username_src != "" && $password_src != ""){  

			$password_src   			=  		\Crypt::encryptString($password_src);
                $src_row = "INSERT INTO `workflow_server_map` SET WORKFLOW_ID='" .$wrkflw[0]. "',ROUND_ID='" .$rid. "',JOB_ID='" .$jobid. "',STAGE_ID='" . $stage_id . "',SERVER_PATH='" . $serverpath_src . "',FOLDER_PATH='" . $folderpath_src . "',USER_NAME='" . $username_src . "',PASSWORD='" . $password_src . "',FOLDER_TYPE=6,FILE_MOVEMENT='" . $fileplacement_src . "',FILE_STRING='" . $filestring_src . "',FILE_EXTENSION='" . $fileext_src . "',LAST_MOD_DATE='" . $time . "',LAST_MOD_BY='" .$userid. "',WORKFLOW_MASTER_ID = '" .$wmid. "',ORDER_SEQ = '" . ($j+1) . "'";
                
               DB::insert( $src_row );
            }
            
        }

        //For Working Path Insert
        $sql_delete = "DELETE FROM `workflow_server_map` WHERE WORKFLOW_ID='" .$wrkflw[0]. "' AND ROUND_ID='" .$rid. "' AND JOB_ID='".$jobid. "' AND STAGE_ID ='".$stage_id."' and FOLDER_TYPE = ".$wrkType;
	DB::delete( $sql_delete );
        
        $work_row_count     =       count($request->input( 'usernamewp_' . $stage_id ) );

        for ($l = 0; $l < $work_row_count; $l++){
            
            $serverpath_workingpath     =       addslashes($request->input( 'serveripwp_' . $stage_id)[$l]);
            $folderpath_workingpath     =       addslashes($request->input( 'folderpathwp_' . $stage_id)[$l]);
            $username_workingpath       =       ($request->input( 'usernamewp_' . $stage_id )[$l]);
            $password_workingpath       =       ($request->input( 'passwordwp_' . $stage_id )[$l]);
            $fileplacement_workingpath  =       addslashes($request->input( 'filemovementwp_' . $stage_id )[$l]);
            $fileext_workingpath        =       addslashes($request->input( 'fileextwp_' . $stage_id )[$l]);
            $filestring_workingpath     =       addslashes($request->input( 'filestringwp_' . $stage_id ) [$l]);
            $serverpath_workingpath     =       str_replace('\\', '/', $serverpath_workingpath);
            $folderpath_workingpath     =       str_replace('\\', '/', $folderpath_workingpath);
            
            if ($fileplacement_workingpath != "" && $serverpath_workingpath != "" && $folderpath_workingpath != "" && $username_workingpath != "" && $password_workingpath != ""){
				$password_workingpath   			=  		\Crypt::encryptString($password_workingpath);
               $wrk_row = "INSERT INTO `workflow_server_map` SET WORKFLOW_ID='" .$wrkflw[0]. "',ROUND_ID='" .$rid. "',JOB_ID='" .$jobid. "',STAGE_ID='" . $stage_id . "',SERVER_PATH='" . $serverpath_workingpath . "',FOLDER_PATH='" . $folderpath_workingpath . "',USER_NAME='" . $username_workingpath . "',PASSWORD='" . $password_workingpath . "',FOLDER_TYPE=7,FILE_MOVEMENT='" . $fileplacement_workingpath . "',FILE_STRING='" . $filestring_workingpath . "',FILE_EXTENSION='" . $fileext_workingpath . "',LAST_MOD_DATE='" . $time . "',LAST_MOD_BY='" .$userid. "',WORKFLOW_MASTER_ID = '" .$wmid. "',ORDER_SEQ = '" . ($l+1) . "'";
               DB::insert( $wrk_row );
            }
            
        }

        //For Destination Path
        $sql_delete = "DELETE FROM `workflow_server_map` WHERE WORKFLOW_ID='" .$wrkflw[0]. "' AND ROUND_ID='" .$rid. "' AND JOB_ID='".$jobid. "' AND STAGE_ID ='".$stage_id."' and FOLDER_TYPE = ".$destType;
        DB::delete( $sql_delete );
        
        $dest_row_count     =       count( $request->input( 'usernamedes_' . $stage_id ) );

        for ($k = 0; $k < $dest_row_count ; $k++){
            
            $serverpath_dest    =       addslashes($request->input( 'serveripdes_' . $stage_id )[$k]);
            $folderpath_dest    =       addslashes($request->input( 'folderpathdes_' . $stage_id )[$k]);
            $username_dest      =       ($request->input( 'usernamedes_' . $stage_id )[$k]);
            $password_dest      =       ($request->input( 'passworddes_' . $stage_id )[$k]);
            $fileplacement_dest =       addslashes($request->input( 'filemovementdes_' . $stage_id )[$k]);
            $fileext_dest       =       addslashes($request->input( 'fileextdes_' . $stage_id )[$k]);
            $filestring_dest    =       addslashes($request->input( 'filestringdes_' . $stage_id )[$k]);
            $serverpath_dest    =       str_replace('\\', '/', $serverpath_dest);
            $folderpath_dest    =       str_replace('\\', '/', $folderpath_dest);
            
            if ($fileplacement_dest != "" && $serverpath_dest != "" && $folderpath_dest != "" && $username_dest != "" && $password_dest != ""){
				
				$password_dest   			=  		\Crypt::encryptString($password_dest);
				
                $dest_row = "INSERT INTO `workflow_server_map` SET WORKFLOW_ID='" .$wrkflw[0]. "',ROUND_ID='" .$rid. "',JOB_ID='" .$jobid. "',STAGE_ID='" . $stage_id . "',SERVER_PATH='" . $serverpath_dest . "',FOLDER_PATH='" . $folderpath_dest . "',USER_NAME='" . $username_dest . "',PASSWORD='" . $password_dest . "',FOLDER_TYPE=9,FILE_MOVEMENT='" . $fileplacement_dest . "',FILE_STRING='" . $filestring_dest . "',FILE_EXTENSION='" . $fileext_dest . "',LAST_MOD_DATE='" . $time . "',LAST_MOD_BY='" .$userid. "',WORKFLOW_MASTER_ID = '" .$wmid. "',ORDER_SEQ = '" . ($k+1) . "'";
                DB::insert( $dest_row );
            }
            
        }
        
        //DB::commit();
        
        $statusCode     =       '4002';
        $response       =       array( 'status' => 1 , 'msg' => 'success' , 'errMsg' => 'Successfully Inserted!' , 
            'params' =>  array( 'redirectUrl' =>   '/book_infodetails/'.$jobid.'?cntlr=serverMapPathController&statusCode='.$statusCode ) );
        
        //}catch( \Exception $e ){
            //DB::rollback();
            
            //$response['status']     =   0;
            //$response['msg']        =   'failed';
            //$response['errMsg']     =   $e->getMessage();
            //$response['params']     =   array( 'redirectUrl' =>   '/book_infodetails/'.$jobid.'?cntlr=serverMapPathController&statusCode='.$statusCode ); 
        //}
                        
    }
    
    public  function duplicateWorkflowMapPathToAnotherJob( $jobId , $roundId , $wmasterid , $copyfromjobid , $booklevelUpdate_flag = false ) { 
        
        $workflowMasterId       =       $wmasterid;
        $userId                 =       \Config::get('constants.ADMIN_USER_ID'); 
        $serverpathCopyJOBId    =       $copyfromjobid; 
        
        $customizationModelObj  =       new customizationModel();
        $workflowList           =       $customizationModelObj->getUserdefinedInformation( $jobId , $roundId , $workflowMasterId );
        $status['status']   	=   0;
        
        try{
        
        if($workflowList['0']->total == '0'){
            
            $workflowCount      =       $customizationModelObj->getWorkflowCount($jobId);
            $roundSequence      =       $workflowCount +1;
            $userDefineData     =       $customizationModelObj->insertUserdefineData( $jobId , $roundId , $workflowMasterId , $userId , $roundSequence );
            
        }
        
        $sql_smt    =   "INSERT INTO `workflow_server_map` ( `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`, `JOB_ID`, `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ`)
                    select `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`,'".$jobId."', `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ` from workflow_server_map where job_id =  '$serverpathCopyJOBId'";
          
        $executed_val       =       DB::query($sql_smt);
            
        if( $booklevelUpdate_flag ){
            
            $updateData['WORKFLOW_TYPE']       =    $workflowMasterId;
			
            $updateQry  =   DB::table('job_info')
			->where('JOB_ID', $jobId )
			->update( $updateData );
            
        
        }
        }catch(\Exception $e){
            
            
        }
        
        return true;
    }
    
    public function assignDefaultWorkFlowCommon( $jobId , $roundId , $getdefaultworkflowid  =   [] , $defaultCopyJobid = null ){
		
        if(empty($jobId) || empty($roundId))
            return false;
        
        if( empty( $getdefaultworkflowid ) && $roundId == 118 ){
            $getdefaultworkflowid   =    \Config::get('constants.S300_DEFAULT_WORKFLOW_LIST');
        }
					
        if( is_null( $defaultCopyJobid ) || empty( $defaultCopyJobid ) ){
            switch($roundId){
                case '118':
                    $defaultCopyJobid    =   \Config::get('constants.DEFAULT_S300_WORKFLOW_COPYJOB_ID');
                break; 
                case '119':
                    $defaultCopyJobid    =   \Config::get('constants.DEFAULT_S600_WORKFLOW_COPYJOB_ID');
                break; 
                case '120':
                    $defaultCopyJobid    =   \Config::get('constants.DEFAULT_S650_WORKFLOW_COPYJOB_ID');
                break;
                
            }
                
        }
        
        if( !is_array( $getdefaultworkflowid ) ){
            $getdefaultworkflowid       =       explode( ',' , $getdefaultworkflowid );
        }
            
        
        $workflowmsid_str		=	implode( ',' , $getdefaultworkflowid );
        $customizationModelObj  =   new customizationModel();
        $userId                 =   \Config::get('constants.ADMIN_USER_ID');
        $wheredata              =   [ 'JOB_ID'=> $jobId , 'ROUND' => $roundId ];
        $checkexitdata          =   taskLevelUserdefinedWorkflow::where($wheredata)->wherein('WORKFLOW_MASTER_ID',$getdefaultworkflowid)->groupby('WORKFLOW_MASTER_ID')->get();
		
        $checkexitdata          =   $checkexitdata->pluck('WORKFLOW_MASTER_ID')->toArray();
        $getmissiedworkflow     =   array_diff( $getdefaultworkflowid , $checkexitdata );
        
        $status['status']       =   1;
		
        $step1  = false;
        $step2  = false;
        $step3  = false;
           
        if(count($getmissiedworkflow)>=1){
			
            foreach($getmissiedworkflow as $wfMid){
				
                $roundSequence      =   '0';
                $workflowCount      =   $customizationModelObj->getWorkflowCount($jobId);
                $roundSequence      =   $workflowCount +1;
                $userDefineData     =   $customizationModelObj->insertUserdefineData( $jobId, $roundId, $wfMid, $userId, $roundSequence );
                $step1              =	$status['status']   =   2;
				
            }
            
        }else{
			
            //if already present logic should come here			
             $present_qurey1  	= 	"select * from task_level_userdefined_workflow where job_id = $jobId and round = $roundId and workflow_master_id in ( $workflowmsid_str ) and workflow_type = 0 group by ( workflow_master_id )";

            $count_rec 	=	count( DB::select( $present_qurey1 ) );
            if( $count_rec && ( $count_rec == count( $getdefaultworkflowid ) ) )
                $step1		=		true;
			
        }
	
        // check workflow server map path
        $whereserdata               =   [ 'JOB_ID'=>$jobId , 'ROUND_ID'=>$roundId ];
        $checkexitserdata           =   workflowServerMapPathModel::where($whereserdata)->wherein('WORKFLOW_MASTER_ID',$getdefaultworkflowid)->groupby('WORKFLOW_MASTER_ID')->get();
        $checkexitserdata           =   $checkexitserdata->pluck('WORKFLOW_MASTER_ID')->toArray();	
        $getmissiedworkflow         =   array_diff( $getdefaultworkflowid , $checkexitserdata );
        
        $is_wsartmaster				=	true;
        
        //this condition will skip the art workflow map path entry [ while resume only ]
        //if( count( $getmissiedworkflow ) == 1 ){

        //       $wsmp_validtry			=		"select * from task_level_userdefined_workflow where job_id = $jobId and round = $roundId and workflow_master_id in ( $workflowmsid_str ) and workflow_type = 2 group by ( workflow_master_id )";

        //        if( count( $wsmp_validtry ) ){
        //                $is_wsartmaster		=	false;
        //        }

        //}
        
        if( count( $getmissiedworkflow ) >= 1 && $step1 && $is_wsartmaster ){
            $commasepratedworkflow  =   implode(',',$getmissiedworkflow);
		
            $sql_qr =  "INSERT INTO `workflow_server_map` ( `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`, `JOB_ID`, `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ`)
            select `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`,'".$jobId."', `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ` from workflow_server_map where job_id =  '$defaultCopyJobid' and WORKFLOW_MASTER_ID in ($commasepratedworkflow)";
            
            $dtlList = DB::insert( $sql_qr );
            $step2	=	true; 
			
        }else{
			
            $wmsp_check		=	"select * from workflow_server_map where job_id = $jobId and round_id = $roundId  and workflow_master_id in ( $workflowmsid_str ) group by ( workflow_master_id )";
            $wsmp_if_exist	=	DB::select( $wmsp_check );

            //if already presesnt logic should come here.
            $count_wsmp	=		count( $wsmp_if_exist );

            if( $count_wsmp == count( $getdefaultworkflowid ) ||  ( $count_wsmp == 1 && $is_wsartmaster ) ) {
                $step2	=	true;
            }

        }
              
        //default copy of workflow rule table , currently working as optional		
        if( $step1 && $step2 || true ){
            
            $step3 	=	$this->getAndSetWorkflowRule( $jobId , $roundId , $getdefaultworkflowid , $defaultCopyJobid );

        }
       
        if( $step2 && $step1 )
                return 1;
       
                
        return 0;
    }
     
    public function getAndSetWorkflowRule( $jobId , $roundId , $wmid_arr = array() , $defaultCopyJobid ){  

            $selectrule_qry		=	"SELECT * FROM user_defined_workflow_rule udwr LEFT JOIN task_level_userdefined_workflow tluw ON udwr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = 
            tluw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID WHERE tluw.JOB_ID = $defaultCopyJobid and tluw.ROUND = $roundId ";//and udwr.is_active =1";
           
            $selectruleforDeflt		=	DB::select( $selectrule_qry );
            $defaultrulepresent		=	count( $selectruleforDeflt );
            $selectruleforJob_qr	=	"SELECT udwr.* FROM user_defined_workflow_rule udwr LEFT JOIN task_level_userdefined_workflow tluw ON udwr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = tluw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID WHERE tluw.JOB_ID = $jobId and tluw.ROUND = $roundId and udwr.is_active = 1";

            $selectruleforJob		=	DB::select( $selectruleforJob_qr );
            $curjobrulepresent		=	count( $selectruleforJob );
            
            if( $defaultrulepresent && ( $curjobrulepresent == $defaultrulepresent || true ) && !$curjobrulepresent ){

                    $insertAr		=	array();
                    $getUdWr_recDB	=	DB::select( "SELECT tluw.* FROM task_level_userdefined_workflow tluw WHERE tluw.JOB_ID = $jobId AND tluw.ROUND = $roundId" );
                    $instr_val		=	array();
                    $stgTlmdMp		=	array();

                    foreach( $getUdWr_recDB as $keytlmd => $valueoftlmd ){				
                        //$stgTlmdMp[$valueoftlmd->STAGE] = $valueoftlmd->TASK_LEVEL_USERDEFINED_WORKFLOW_ID;				
                        $keyfixed  = $valueoftlmd->ROUND.'_'.$valueoftlmd->WORKFLOW_MASTER_ID.'_'.$valueoftlmd->WORKFLOW.'_'.$valueoftlmd->STAGE;
                        $stgTlmdMp[$keyfixed] = $valueoftlmd->TASK_LEVEL_USERDEFINED_WORKFLOW_ID;				
                    }

                    //if exist deactivate the existing one
                    foreach( $selectruleforDeflt as $key_ => $value_ ){

                        $row_arr  =  array();

                        $row_arr['IS_AUTO']	=	isset( $value_->IS_AUTO ) 	? 	$value_->IS_AUTO : 0;
                        $row_arr['IS_SKIP']	=	isset( $value_->IS_SKIP ) 	? 	$value_->IS_SKIP : 0;
                        $row_arr['STAGE_ID']	=	isset( $value_->STAGE_ID )	?	$value_->STAGE_ID : '';
                        $row_arr['RULE_TYPE']	=	isset( $value_->RULE_TYPE )	?	$value_->RULE_TYPE : '';
                        $row_arr['GOTO_STAGE_ID']=	isset( $value_->GOTO_STAGE_ID )	?	$value_->GOTO_STAGE_ID : '';
                        $row_arr['IS_PARENT']	=	isset( $value_->IS_PARENT )	?	$value_->IS_PARENT : 1;
                        $row_arr['IS_CHILD']	=	isset( $value_->IS_CHILD )	?	$value_->IS_CHILD : 2;
                        $row_arr['CREATED_BY']	=	isset( $value_->CREATED_BY )	?	$value_->CREATED_BY : '';
                        $row_arr['CREATED_DATE']=	date( 'Y-m-d H:i:s' );
                        $row_arr['LAST_MOD_DATE']	=	date( 'Y-m-d H:i:s' );
                        $row_arr['IS_ACTIVE']		=	1;
                        
                        $keyfixedfind           =       $value_->ROUND.'_'.$value_->WORKFLOW_MASTER_ID.'_'.$value_->WORKFLOW.'_'.$value_->STAGE_ID;
                        $row_arr['TASK_LEVEL_USERDEFINED_WORKFLOW_ID']	=	@$stgTlmdMp[$keyfixedfind];

                        $instr_val[]		.=  	" ( '".implode( "' , '" , array_values( $row_arr ) )."') ";
                        $insertAr[]             =	$row_arr;

                    } 

                    if( empty( $insertAr ) ){ 

                    }else if( !empty( $insertAr ) ){

                        $var_field  		= 		implode( "," , array_keys( $row_arr ) );
                        $var_values		=		implode( " , " , $instr_val );
                        $insert_qry_rule	=	 	" INSERT INTO `user_defined_workflow_rule` ( $var_field ) VALUES $var_values "; 

                        try{
                            
                            DB::beginTransaction();

                            $insertstatusDB	=	DB::insert( $insert_qry_rule );
                            
                            if( $insertstatusDB ){ 
                                DB::commit();
                                return true;
                            }else{
                                DB::roleback();

                            }


                        }catch( Exception $e ){
                                DB::roleback();
                                return false;
                        }

                        return false;

                    }


            }else if( $curjobrulepresent ){
                return true;
            }
            
            return false;

    }
	
    
    
}