<?php

namespace App\Http\Controllers\esm;

use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\projectModel;
use App\Models\fileHandler;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\bookinfoModel;
use App\Models\ApiDownloadModel;
use App\Models\metadataEsmModel;
use App\Models\jobStage;
use App\Models\apiCucbackgroundprocessModel;
use App\Models\jobTimeSheet;
use App\Models\productionLocationModel;
use App\Models\apiEsm;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use App\Http\Controllers\finance\readJobSheetDataController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB;
use Log;
use Config;

class esmController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {

        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index() {
        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.ESM'),$data);
        $data['user_name'] = $this->userName;
        $data['role_name'] = $this->roleName;
        $data["userId"] = $this->loginUserId;
        return view('esm.esm-index')->with($data);
    }

    public function getEsmlist(Request $request, $jobID) {

        $data = array();
        $this->displayMenuName(Config::get('menuconstants.MENU.ESM'),$data);
        $data['user_name'] = $this->userName;
        $data['role_name'] = $this->roleName;
        $bookdata = jobModel::where('JOB_ID', $jobID)->first();
        $bookid = (count($bookdata) >= 1 ? $bookdata->BOOK_ID : '');
        $data['pageName'] = 'ESM - ' . $bookid;
        $data['jobid'] = $jobID;
        $data['backurl']        =   url('/').'/Esmlist-list';
        return view('esm.esm-checkout')->with($data);
    }

    public function getjobChapterlist(Request $request) {
        $jobID = $request->input('jodId');
        $response = [];
        
        $jobdetails =   jobModel::getJobdetails($jobID);
        
        $data = taskLevelMetadataModel::getallesmJoblist($jobID);

        $esmObj = new apiEsm();

        $jobValidation = $esmObj->getEsmValidationByJob($jobID);
        if (!empty($jobValidation))
            $jobEsmStatus = (isset($jobValidation->STATUS) ? $jobValidation->STATUS : '');
        else
            $jobEsmStatus = '';

        foreach ($data as $key => $metadata) {

            $medatValidation = $esmObj->getEsmValidationByMetaId($metadata->taskmetaid, $jobID);
            $medatVid = $esmObj->getEsmVidByMetaId($metadata->taskmetaid, $jobID);

            if ($metadata->esmcount >= 1) {
                if (!empty($medatValidation)) {
                    $data[$key]->validationStatus = $medatValidation->STATUS;
                } else {
                    $data[$key]->validationStatus = $jobEsmStatus;
                }

                if (!empty($medatVid)) {
                    $data[$key]->vidStatus = $medatVid->STATUS;
                } else {
                    $data[$key]->vidStatus = '';
                }
            } else {
                $data[$key]->validationStatus = '';
                $data[$key]->vidStatus = '';
            }
        }
        $response["cuclist"] = $data;
        $response["user_id"] = $this->loginUserId;
        $response["jobESm"] = $jobdetails->CONTAINS_ESM;
        return response($response);
    }

    public function getEsmjoblist(Request $request) {

        $Req = (object) $request->input();
        $orderColumn = 3; //created date column
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn = $Req->order[0]['column'];
        }

        $sorting = 'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting = $Req->order[0]['dir'];
        }

        $start = '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start = $Req->start;
        }

        $length = false;
        if (isset($Req->length) && $Req->length != -1) {
            $length = $Req->length;
        }

        $searchStr = '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr = trim($Req->search['value']);
        }

        $data = bookinfoModel::commonbookinfodetails($start, $length, $searchStr, $orderColumn, $sorting);

        $bookdata = array();
        if (isset($data) && count($data['bookdetails']) >= 1) {
            foreach ($data as $row) {

                $tempArray = array();
                $tempArray['BOOK_ID'] = $row->BOOK_ID;
                $showauthorname = ($row->AUTHOR_NAME == "" ? $row->EDITOR_NAME : $row->AUTHOR_NAME);
                $tempArray['JOB_TITLE'] = '<span  class="pointer" ng-click="openchapterlistdetails(' . "'" . $row->JOB_ID . "'" . ')">' . $row->JOB_TITLE . ' - <span class="authornamestyle">' . $showauthorname . '</span></span>';
                $tempArray['PM_NAME'] = $row->PM_NAME;
                $tempArray['CREATED_DATE'] = $row->CREATED_DATE;
                $tempArray['QUERY'] = '<a ng-click=' . 'qmsspike("' . $row->JOB_ID . '","' . $this->loginUserId . '","' . $row->BOOK_ID . '","qms")' . ' data-toggle="modal" data-target="#qmsModal" class="fa fa-comments-o fa-2x pointer" /></a>';
                $tempArray['SPIKE'] = '<a ng-click=' . 'qmsspike("' . $row->JOB_ID . '","' . $this->loginUserId . '","' . $row->BOOK_ID . '","spike")' . ' data-toggle="modal" data-target="#spikeModal" class="fa fa-list-ul fa-2x pointer"/></a>';
                array_push($bookdata, $tempArray);
            }
        }

        $Response = array();
        $Response["draw"] = $Req->draw;
        $Response["recordsTotal"] = (isset($data['countbookinfo']) ? $data['countbookinfo'] : 0);
        $Response["recordsFiltered"] = (isset($data['countbookinfo']) ? $data['countbookinfo'] : 0);
        $Response["data"] = $bookdata;

        return response()->json($Response);

//        $userId = $this->loginUserId;
//        $response["book"] = $data;
//        $response['userId'] = $userId;
//        return response()->json($response);
    }
    
    //check out process
    public function checkEsmDataispresentornot(Request $request) {
        try {
            $response   =   $this->locationNotFoundResponse;
            $validation = Validator::make($request->all(), [
                        'metadataid' => 'required|numeric',
                        'jobId' => 'required|numeric'
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response, 404);
            }
            
            $metaid = $request->input('metadataid');
            $jobId = $request->input('jobId');
            
            $readJobsheetObj2 = new readJobSheetDataController();
            $readAuthorInfoStyle = $readJobsheetObj2->getJobSheetData($jobId, '',$metaid,'ChapterInfo', 0, '');
            if(count($readAuthorInfoStyle)>=1){
                if(isset($readAuthorInfoStyle['@ContainsESM']) && ($readAuthorInfoStyle['@ContainsESM']  ==  "No" || $readAuthorInfoStyle['@ContainsESM']  ==  "no")){
                    $response           =   $this->successResponse;
                    $response['errMsg'] =   'ESM record is not exist';
                    return response()->json($response);
                }
            }
            return response()->json($this->notfoundResponse);
        }catch (\Exception $e) {
            return response()->json($response);
        }
    }
    //check out process
    public function doEsmCheckoutprocess(Request $request) {
        try {
            $response   =   $this->locationNotFoundResponse;
            $checkouttype = $request->input('checkouttype');
            $checkouttype = 'new';
            $validation = Validator::make($request->all(), [
                        'metadataid' => 'required|numeric',
                        'jobId' => 'required|numeric',
                        'Chapter' => 'required',
                        'bookid' => 'required',
                        'checkouttype' => 'required'
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response, 404);
            }
        
            $stagename = $this->stagetypeEsm;
            $stageid = Config::get('constants.STAGE_COLLEECTION.ESM');
            $metaid = $request->input('metadataid');
            $jobId = $request->input('jobId');
            $Chapter = $request->input('Chapter');
            $bookid = $request->input('bookid');
            //check already exist have chapter or not
            $inp_array = array();
            $inp_arr['METADATA_ID'] = $metaid;
            $inp_arr['ROUND_ID'] = Config::get('constants.ROUND_ID.ESM');
            $inp_arr['STAGE'] = Config::get('constants.STAGE_COLLEECTION.ESM');
            $getcurrentuserid = $this->loginUserId;
            $jts_obj = new jobTimeSheet();
            $hasMetaid = jobTimeSheet::where($inp_arr)->first();

            $inparray = array();
            $inparray['METADATA_ID'] = $metaid;
            $inparray['ROUND_ID'] = Config::get('constants.ROUND_ID.ESM');
            $inparray['STAGE'] = Config::get('constants.STAGE_COLLEECTION.ESM');
            $inparray['CREATED_BY'] = $this->loginUserId;
            $hasMyCheckoutentry = $jts_obj->hasChapterCheckedOutEntry($inparray);
            $hasMyCheckoutentryOfMe = $jts_obj->hasChapterCheckedOutOtherByMe($inparray);
            $hasOtherCheckoutentry = $jts_obj->hasOthersChapterCheckedOutEntry($inparray);

            if (count($hasOtherCheckoutentry) >= 1 && !empty($hasOtherCheckoutentry)) {
                $response = array('result' => 401, 'errMsg' => 'Other User checkout this chapter. kindly refresh the page and proceed.');
                return response()->json($response);
            }

            if (!empty($hasMyCheckoutentryOfMe)) {
                $arrayinp = [];
                $arrayinp['METADATA_ID'] = (count($hasMyCheckoutentryOfMe) >= 1 ? $hasMyCheckoutentryOfMe->METADATA_ID : '');
                $arrayinp['ROUND_ID'] = Config::get('constants.ROUND_ID.ESM');
                $arrayinp['STAGE'] = Config::get('constants.STAGE_COLLEECTION.ESM');
                $arrayinp['STATUS'] = 2;
                $arrayinp['CREATED_BY'] = $this->loginUserId;
                $checkexistcomplete = jobTimeSheet::where($arrayinp)->first();
                if (empty($checkexistcomplete)) {
                    $getbookidexit = (count($hasMyCheckoutentryOfMe) >= 1 ? $hasMyCheckoutentryOfMe->JOB_ID : '');

                    $bookdetails = bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                    ->join('job_info', 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                    ->where('job.JOB_ID', $getbookidexit)
                                    ->get()->first();
                    //get chpter name       
                    $getchaptername = taskLevelMetadataModel::where('METADATA_ID', $arrayinp['METADATA_ID'])->first();
                    $getcurrentchaptername = '';
                    if (count($getchaptername) >= 1) {
                        $getcurrentchaptername = $getchaptername->CHAPTER_NO;
                    }
                    $response = array('result' => 401, 'errMsg' => 'Kindly check-in the previous Chapter : ' . $bookdetails["BOOK_ID"] . ' - ' . $getcurrentchaptername);
                    return response()->json($response);
                }
            }

            if (!empty($hasMyCheckoutentry)) {
                
            }

            //get location for exist job id
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);

            if (count($getlocationftp) >= 1) {
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj = Storage::createFtpDriver([
                            'host' => $hostserver,
                            'username' => $hostusername,
                            'password' => $hostpassword, // 
                            'port' => '21',
                            'timeout' => '30',
                ]);
                $ftpObj2 = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);

                $getuserid = Session::get('users')['user_id'];
                $userWork_for_const = Config::get('serverconstants.USER_WORK_PATH');
                $serDir = Config::get('serverconstants.PRE_PROCESSING_PATH');
                $sucfile = [];
                if ($checkouttype == "new") {
                    //CUC_CHECKOUT_FOLDER
                    $splitround = $this->stagetypeEsm;

                    $cucSourceCheckout = $hostpath . $serDir . $bookid . '/' . $splitround . '/' . $Chapter;

                    $cucuserworkfolder = Config::get('serverconstants.USER_WORK_PATH');

                    //get all files from ftp based on given folder name

                    $cucDirFiles = $ftpObj->allFiles($cucSourceCheckout);

                    $successfile = $this->dogetdocumentfile($cucDirFiles, $Chapter);

                    if (count($cucDirFiles) >= 1 && false) {
                        $putfile = "";
                        $putfile_location = $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;

                        //check directory exist or not
                        $checkdirexistchapter = $ftpObj->has($putfile_location);
                        if (empty($checkdirexistchapter) && $checkdirexistchapter != 1) {
                            $cucDirFiles = $ftpObj->makeDirectory($putfile_location, 0777);
                        }
                        $stream_options = array('ftp' => array('overwrite' => true));
                        // Creates a stream context resource with the defined options
                        $stream_context = stream_context_create($stream_options);

                        foreach ($successfile as $filename) {

                            if ($ftpObj->has($putfile_location . '/' . $filename)) {
                                $ftpObj->delete($putfile_location . '/' . $filename);
                                $putfile = $ftpObj->copy($cucSourceCheckout . '/' . $filename, $putfile_location . '/' . $filename);
                            } else {
                                $putfile = $ftpObj->copy($cucSourceCheckout . '/' . $filename, $putfile_location . '/' . $filename);
                            }

                            if ($putfile == true) {
                                $sucfile[$filename] = 'Success';
                            } else {
                                $sucfile[$filename] = 'failed';
                            }
                        }
                        if (in_array('failed', $sucfile)) {
                            $response['errMsg']     =   'File is not able to detect location try again';
                            return response()->json($response);
                        }

                        $sourcepath = Config::get('constants.FILE_SERVER_CREDENTIALS') . $hostserver . $cucSourceCheckout;
                        $ftp_root_dir = Config::get('constants.FILE_SERVER_ROOT_DIR');
                        $open_path = $hostserver . $ftp_root_dir . $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;

                        $open_path = str_replace('//', '/', $open_path . '/');
                    } else {
                        $ftp_root_dir = Config::get('constants.FILE_SERVER_ROOT_DIR');
                        $putfile_location = $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $cucDirFiles = $ftpObj->makeDirectory($putfile_location, 0777);
                        $open_path = $hostserver . $ftp_root_dir . $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $open_path = str_replace('//', '/', $open_path . '/');

                        /*
                          $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...');
                          return response()->json($result); */
                    }
                } else {
                    //move from temp to user user again checkout
                    $tempfolder = Config::get('serverconstants.TEMP_PATH');
                    $ftp_root_dir = Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                    $sourcepath = Config::get('constants.FILE_SERVER_CREDENTIALS') . $hostserver . $hostpath . $tempfolder . $stagename . '/' . $bookid . '/' . $Chapter;
                    $checkexistdirfile = $hostpath . $tempfolder . $stageid . '_' . $bookid . '_' . $Chapter;
                    $cucDirFiles = $ftpObj->allFiles($checkexistdirfile);
                   
                    $successfile = $this->dogetdocumentfile($cucDirFiles, $Chapter);
                    if (count($successfile) >= 1) {
                        $destinationpath = $hostserver . $hostpath . Config::get('serverconstants.USER_WORK_PATH') . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $open_path = $hostserver . $ftp_root_dir . $hostpath . $userWork_for_const . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $open_path = str_replace('//', '/', $open_path . '/' . $successfile[0]);
                    }
                    if (count($cucDirFiles) == 0) { //copy file from user dir to temp
                        $cucSourceCheckout = $hostpath . Config::get('serverconstants.USER_WORK_PATH') . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $ftpestablishconnection = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                        $destinationpath = $hostserver . $hostpath . $tempfolder . $stageid . '_' . $bookid . '_' . $Chapter;
                        $sourcepath = Config::get('constants.FILE_SERVER_CREDENTIALS') . $hostserver . $hostpath . Config::get('serverconstants.USER_WORK_PATH') . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        $response = $ftpestablishconnection->ftp_dir_copy($sourcepath, $destinationpath);
                        $cucDirFiles = $ftpObj->allFiles($cucSourceCheckout);

                        $successfile = $this->dogetdocumentfile($cucDirFiles, $Chapter);
                        $open_path = $hostserver . $ftp_root_dir . $hostpath . $userWork_for_const . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                        if (count($successfile) >= 1) {
                            $open_path = str_replace('//', '/', $open_path . '/' . $successfile[0]);
                        } else {
                            $response['errMsg']     =   $Chapter . ' directory is not found...';
                            return response()->json($response);
                        }
                    }
                    if (count($cucDirFiles) == 0) {
                        $response['errMsg']     =   $Chapter . ' directory is not found...';
                        return response()->json($response);
                    }
                    $ftpestablishconnection = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response = $ftpestablishconnection->ftp_dir_copy($sourcepath, $destinationpath);

                    $response_copy = array('success');
                    if (in_array('failed', $response_copy)) {
                        foreach ($response_copy as $key => $value) {
                            if ($value == 'success') {
                                unset($response[$key]);
                            }
                        }
                        $response_copy = array('status' => 'failed', $response_copy);
                    } else {
                        $response_copy = array('status' => 'success', $response_copy);
                    }
                    $response = $response_copy;
                    if ($response_copy['status'] != 'success') {
                        $response['errMsg']     =   'File is not able to detect location try again';
                        return response()->json($response);
                    }
                }

                $postdata = [];
                $postdata['file_path'] = $open_path . '/<>' . $hostuserfieserver . '<>' . $hostpasswordfieserver;
                $postdata['system_ip'] = $request->ip();
                $postdata['method_name'] = "doOpenDriveServer";
                $postdata['processname'] = "checkout";
                $insertfilehandler = fileHandler::insertNew($postdata);

                if ($insertfilehandler >= 1) {
                    $jobtimedata = [];
                    $jobtimedata['JOB_ID'] = $jobId;
                    $jobtimedata['METADATA_ID'] = $metaid;
                    $jobtimedata['ROUND_ID'] = Config::get('constants.ROUND_ID.ESM');
                    $jobtimedata['STAGE'] = Config::get('constants.STAGE_COLLEECTION.ESM');
                    $jobtimedata['TYPE'] = 1;
                    $jobtimedata['STATUS'] = 1;
                    $jobtimedata['CHECK_OUT'] = Carbon::now();
                    $jobtimedata['CREATED_DATE'] = Carbon::now();
                    $jobtimedata['created_at'] = Carbon::now();
                    $jobtimedata['updated_at'] = Carbon::now();
                    $jobtimedata['CREATED_BY'] = Session::get('users')['user_id'];
                    $timesheeid = jobTimeSheet::doAddNewTime($jobtimedata);
                    $getrecords = [];
                    if ($timesheeid) {
                        $getrecords = jobTimeSheet::getJimetimelastcuc($timesheeid);
                    }
                    $response   =   $this->insertedResponse;
                    $response['errMsg']     =   'Successfully checkout';
                    $response['records']    =   $getrecords;
                    $response['rmID']       =   $insertfilehandler;
                    return response()->json($response);
                }
                return response()->json($this->insertedFailedResponse);
            }
            return response()->json($response);
        } catch (\Exception $e) {
            $response['result']     =   500;
            return response()->json($response);
        }
    }

    //Final submit process
    public function doemsCompleteprocess(Request $request) {
        try {
            $response   =   $this->locationNotFoundResponse;
            $validation = Validator::make($request->all(), [
                        'metadataid' => 'required|numeric',
                        'jobId' => 'required|numeric',
                        'Chapter' => 'required',
                        'bookid' => 'required'
                            //'jobtimesheetid' => 'required|numeric'
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response,404);
            }
            $stagename = $this->stagetypeEsm;
            $esmfiletype = Config::get('constants.ESM_FILE_TYPE');

            $stageid = Config::get('constants.STAGE_COLLEECTION.ESM');
            $metaid = $request->input('metadataid');
            $jobId = $request->input('jobId');
            $Chapter = $request->input('Chapter');
            $bookid = $request->input('bookid');
            //$jobtimesheetid     =   $request->input('jobtimesheetid');
            $wheredata = [];
            $wheredata['METADATA_ID'] = $metaid;
            $wheredata['JOB_ID'] = $jobId;
            $wheredata['STAGE'] = $stageid;
            $wheredata['METADATA_ID'] = $metaid;

            //check user access 
            $getmamtimesheetid = jobTimeSheet::getMaxoftimesheetrecords($wheredata);

            $jobtimesheetid = (count($getmamtimesheetid) >= 1 ? $getmamtimesheetid->timesheetid : $jobtimesheetid);

            //get location for exist job id
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            if (count($getlocationftp) >= 1) {
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj = Storage::createFtpDriver([
                            'host' => $hostserver,
                            'username' => $hostusername,
                            'password' => $hostpassword, // 
                            'port' => '21',
                            'timeout' => '30',
                ]);
                $getuserid = Session::get('users')['user_id'];

                $cucSourceCheckout = $hostpath . Config::get('serverconstants.PRE_PROCESSING_PATH') . $bookid . '/' . $stagename . '/' . $Chapter;
                $cucuserworkfolder = Config::get('serverconstants.USER_WORK_PATH');
                //check directory is exist or not
                $cucSourceexist = $hostpath . Config::get('serverconstants.USER_WORK_PATH') . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                $sourcepath = Config::get('constants.FILE_SERVER_CREDENTIALS') . $hostserver . $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                //get all files from ftp based on given folder name
                $cucDirFiles = $ftpObj->allFiles($cucSourceexist);
                $destinationpath = $hostserver . $cucSourceCheckout;

                if (!empty($cucDirFiles)) {
                    $ftpestablishconnection = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response = $ftpestablishconnection->ftp_dir_copy($sourcepath, $destinationpath);
                    $response_copy = array('success');
                    if (in_array('failed', $response_copy)) {
                        foreach ($response_copy as $key => $value) {
                            if ($value == 'success') {
                                unset($response[$key]);
                            }
                        }
                        $response_copy = array('status' => 'failed', $response_copy);
                    } else {
                        $response_copy = array('status' => 'success', $response_copy);
                    }
                    $response = $response_copy;
                    if ($response_copy['status'] != 'success') {
                        return response()->json($this->fileNotCopiedResponse);
                    }

                    $setArrinfo = array('TYPE_OF_CONTAINESM' => 'YES');
                    $updateQry = DB::table('metadata_info')
                            ->where('METADATA_ID', $metaid)
                            ->update($setArrinfo);

                    $createdDate = date('Y-m-d H:i:s');
                    $setArr['IS_DELETED'] = 1;
                    $setArr['UPDATED_DATE'] = $createdDate;

                    /* $updateQry  =   DB::table('metadata_esm')
                      ->where('METADATA_ID', $metaid )
                      ->where('JOB_ID', $jobId )
                      ->update( $setArr );
                     */

                    foreach ($cucDirFiles as $mvfile) {

                        $filepath = explode('/', $mvfile);
                        $filename = end($filepath);
                        $filetypes = explode('.', $filename);

                        $mvdata['FILE_TYPE'] = 'others';
                        if (!empty($filetypes['1'])) {
                            $mvdata['FILE_FORMAT'] = $filetypes['1'];
                            if (in_array($filetypes['1'], $esmfiletype)) {
                                $mvdata['FILE_TYPE'] = 'video';
                            }else{
                                $mvdata['FILE_TYPE'] = 'others';
                                $mvdata['IS_VALID'] = '3';
                            }
                        }
                        $mvdata['JOB_ID'] = $jobId;
                        $mvdata['METADATA_ID'] = $metaid;
                        $mvdata['ROUND'] = '104';
                        $mvdata['ORGINAL_FILE_NAME'] = $filename;
                        $mvdata['CREATED_DATE'] = $createdDate;
                        $mvdata['CREATED_BY'] = $this->loginUserId;
                        $inserid = DB::table('metadata_esm')->insertGetId($mvdata);
                    }

                    $ref_pdf_data = ['jobid' => $jobId, 'metaId' => $metaid];
                    $ref_url = url('/') . '/api/esmvalidation';
                    $cmn_obj = new CommonMethodsController();
                    $postreferencepdf = $cmn_obj->PostcUrlExecution($ref_pdf_data, $ref_url);

                    //check exist meta id in job time sheet table
                    $jobtimedata = [];
                    $jobtimedata['STATUS'] = 2;
                    $jobtimedata['CHECK_IN'] = Carbon::now();
                    $updatemetasuccess = jobTimeSheet::updateIfExist($jobtimedata, $jobtimesheetid);
                    //insert record in filehandler table for delete ftp drive
                    $sourcepath = Config::get('constants.FILE_SERVER_CREDENTIALS') . $hostserver . $cucSourceCheckout;
                    $ftp_root_dir = Config::get('constants.FILE_SERVER_ROOT_DIR');
                    $open_path = $hostserver . $ftp_root_dir . $hostpath . $cucuserworkfolder . $getuserid . '/' . $stagename . '/' . $bookid . '/' . $Chapter;
                    $open_path = str_replace('//', '/', $open_path);
                    $postdata = [];

                    $postdata['file_path'] = $open_path . '/<>' . $hostuserfieserver . '<>' . $hostpasswordfieserver;
                    $postdata['method_name'] = "deleteFileServer";
                    $postdata['system_ip'] = $request->ip();
                    $postdata['processname'] = "deleteFileServer";
                    $insertfilehandler = fileHandler::insertNew($postdata);

                    $response   =   $this->insertedResponse;
                    $response['errMsg']     =   'File submitted Successfully...';
                    return response()->json($response);
                }

                $setArrinfo = array('TYPE_OF_CONTAINESM' => 'NO');
                $updateQry = DB::table('metadata_info')
                        ->where('METADATA_ID', $metaid)
                        ->update($setArrinfo);
                $jobtimedata = [];
                $jobtimedata['STATUS'] = 2;
                $jobtimedata['CHECK_IN'] = Carbon::now();
                $updatemetasuccess = jobTimeSheet::updateIfExist($jobtimedata, $jobtimesheetid);
                $response   =   $this->insertedResponse;
                $response['errMsg']     =   'Successfully submit with out ESM files.';
                return response()->json($response);
            }
            return response()->json($response);
        } catch (\Exception $e) {
            $response['result']     =   500;
            return response()->json($response);
        }
    }

    public function dogetdocumentfile($cucDirFiles, $Chapter) {

        $successfile = [];
        if (count($cucDirFiles) >= 1) {
            $readfileextenstion = Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
            foreach ($cucDirFiles as $key => $jsonvalue) {
                if (strpos($jsonvalue, '/') !== false) {
                    $spiltchapter = substr(strrchr($jsonvalue, "/"), 1);

                    if (strpos($spiltchapter, '.') !== false) {
                        $splitname = explode('.', $spiltchapter);

                        if (in_array(trim($splitname[1]), $readfileextenstion)) {
                            $successfile[] = $spiltchapter;
                        }
                    }
                }
            }
        }

        return $successfile;
    }

    public function generateEsm($jobid, $esmdata = array()) {

        $ref_pdf_data = ['jobid' => $jobId, 'metaId' => $metaid];
        $ref_url = url('/') . '/api/esmvalidation';
        $cmn_obj = new CommonMethodsController();
        $postreferencepdf = $cmn_obj->PostcUrlExecution($ref_pdf_data, $ref_url);
    }

    //manage video submit process
    public function addEsmFiles(Request $request) {
        try {
            $response   =   $this->locationNotFoundResponse;
            $validation =   Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'metadataId' => 'required|numeric',
                        'esmId' => "required|numeric"
//                    'esmId' => "required|array|min:1",
//                    'esmId.*' => "required|distinct|min:1|numeric"
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId = $request->input('jobId');
            $metadataId = $request->input('metadataId');
            $esmId = $request->input('esmId');
            $whereesm = ['IS_DELETED' => 0, 'METADATA_ID' => $metadataId];
            $getesmfilename = metadataEsmModel::select(DB::raw('ID,ORGINAL_FILE_NAME'))->where($whereesm)->where('ID', $esmId)->get();
            //filename
            $copyesmvideofiles = [];
            if ($getesmfilename != null) {
                $newgetesmfilename = $getesmfilename->pluck('ORGINAL_FILE_NAME');
                if ($newgetesmfilename != null && count($newgetesmfilename) >= 1) {
                    foreach ($newgetesmfilename as $key => $value) {
                        $splitesmvideofiles = explode('.', $value);
                        $copyesmvideofiles[] = $splitesmvideofiles[0];
                    }
                }
            }

            $getchapter = taskLevelMetadataModel::find($metadataId);
            if (empty($getchapter)) {
                return response()->json($this->nofileResponse);
            }
            $bookdata = jobModel::getJobdetails($jobId);
            if (empty($bookdata)) {
                return response()->json($this->notfoundResponse);
            }

            $chapter = $getchapter->CHAPTER_NO;
            $bookid = (count($bookdata) >= 1 ? $bookdata->BOOK_ID : '');
            $preprocesspath = $this->preProcessPath;
            $userpath = $this->userWorkPath;
            //get location for exist job id
            $default_location = 0;
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);

            if (empty($getlocationftp) || $getlocationftp == null) {
                $default_location = 1;
                $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
            }

            $hostserver = $getlocationftp->FTP_HOST;
            $hostusername = $getlocationftp->FTP_USER_NAME;
            if ($default_location == 1) {
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            } else {
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $getlocationftp->FTP_PATH_CREDENTIAL = 'ftp://' . $getlocationftp->FTP_USER_NAME . ':' . $hostpassword . '@';
                $getlocationftp->SERVER_PATH = $hostserver . $getlocationftp->FTP_PATH;
            }
            $hostpath = $getlocationftp->FTP_PATH;
            $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
            $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;

            // Do the FTP connection
            $ftpObj = Storage::createFtpDriver([
                        'host' => $hostserver,
                        'username' => $hostusername,
                        'password' => $hostpassword, // 
                        'port' => '21',
                        'timeout' => '30',
            ]);

            $fileHandlerObj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
            $cucSourceexist = "";
            // RAW FILE PATH MAPPING
            $getuserid = $this->empId;
            $ftp_root_dir = $this->ftp_root_dir;
            $stagetype = $this->stagetypeEsm;
            $open_path = $hostserver . $ftp_root_dir . $hostpath . $userpath . $getuserid . '/' . $bookid . '/' . $stagetype . '/' . $chapter;
            $open_path = str_replace('//', '/', $open_path);
            $checkSourceexist = $hostpath . $preprocesspath . $bookid . '/' . $stagetype . '/' . $chapter;
            $checkDirFiles = $ftpObj->allFiles($checkSourceexist);
            if (count($checkDirFiles) >= 1 && $checkDirFiles != null) {

                $crd = "ftp://$hostusername:$hostpassword@";
                $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $desDir = $hostserver . $hostpath . $userpath . $getuserid . '/' . $bookid . '/' . $stagetype . '/' . $chapter;
                $sourcepath = $crd . $hostserver . $checkSourceexist;
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                $response_copy = $ftp_obj->ftp_dir_copy_word_file_only($sourcepath, $desDir, $copyesmvideofiles, $this->esm_FILE_FORMAT);

                $response = array('result' => 404, 'msg' => 'Failed', 'errMsg' => "");
                if (in_array('failed', $response_copy)) {
                    foreach ($response_copy as $key => $value) {
                        if ($value == 'success') {
                            unset($response[$key]);
                        }
                    }
                    $response_copy = array('status' => 'failed', $response_copy);
                } else {
                    $response_copy = array('status' => 'success', $response_copy);
                }

                if ($response_copy['status'] == 'success') {

                    $postdata = [];
                    $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                    $postdata['system_ip'] = $request->ip();
                    $postdata['method_name'] = "doOpenDriveServer";
                    $postdata['processname'] = "checkout";
                    $insertfilehandler = fileHandler::insertNew($postdata);

                    if ($insertfilehandler) {
                        $response           =   $this->successResponse;
                        $response['errMsg'] = 'File open initialized..';
                        $response['rmID'] = $insertfilehandler;
                        return response()->json($response);
                    }
                }
                return response()->json($this->fileNotCopiedResponse);
            }
            return response()->json($this->nofileResponse);
        } catch (\Exception $e) {
            return response()->json($response);
        }
    }

    //Final submit process
    public function updateEsmFiles(Request $request) {
        try{
            $response   =   $this->locationNotFoundResponse; 
        $validation = Validator::make($request->all(), [
                    'jobId' => 'required|numeric',
                    'metadataId' => 'required|numeric',
                    'esmId' => "required|numeric"
        ]);
        if ($validation->fails()) {
            $response   =   $this->validationResponse;
            $response['validation']     =   $validation->errors();
            return response()->json($response);
        }
        $jobId = $request->input('jobId');
        $metadataId = $request->input('metadataId');
        $esmId = $request->input('esmId');
        $whereesm = ['IS_DELETED' => 0, 'METADATA_ID' => $metadataId, 'ID' => $esmId];
        $getesmfilename = metadataEsmModel::select(DB::raw('ID,ORGINAL_FILE_NAME'))->where($whereesm)->first();
        //filename
        $copyesmvideofiles = [];
        if (empty($getesmfilename)) {
            return response()->json($this->notfoundResponse);
        }
        $esmfilename = $getesmfilename->ORGINAL_FILE_NAME;
        $getchapter = taskLevelMetadataModel::find($metadataId);
        if (empty($getchapter)) {
            $response['errMsg']     =   "Chapter is not found";
            return response()->json($response);
        }
        $bookdata = jobModel::getJobdetails($jobId);
        if (empty($bookdata)) {
            return response()->json($this->notfoundResponse);
        }

        $chapter = $getchapter->CHAPTER_NO;
        $bookid = (count($bookdata) >= 1 ? $bookdata->BOOK_ID : '');
        $preprocesspath = $this->preProcessPath;
        $userpath = $this->userWorkPath;
        //get location for exist job id
        $default_location = 0;
        $getlocationftp = productionLocationModel::doGetLocationname($jobId);

        if (empty($getlocationftp) || $getlocationftp == null) {
            $default_location = 1;
            $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
        }
        $hostserver = $getlocationftp->FTP_HOST;
        $hostusername = $getlocationftp->FTP_USER_NAME;
        if ($default_location == 1) {
            $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        } else {
            $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $getlocationftp->FTP_PATH_CREDENTIAL = 'ftp://' . $getlocationftp->FTP_USER_NAME . ':' . $hostpassword . '@';
            $getlocationftp->SERVER_PATH = $hostserver . $getlocationftp->FTP_PATH;
        }
        $hostpath = $getlocationftp->FTP_PATH;
        $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
        $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;

        // Do the FTP connection
        $ftpObj = Storage::createFtpDriver([
                    'host' => $hostserver,
                    'username' => $hostusername,
                    'password' => $hostpassword, // 
                    'port' => '21',
                    'timeout' => '30',
        ]);

        $fileHandlerObj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
        $cucSourceexist = "";
        // RAW FILE PATH MAPPING
        $crd = "ftp://$hostusername:$hostpassword@";
        $getuserid = $this->empId;
        $ftp_root_dir = rtrim($this->ftp_root_dir, '/');
        $stagetype = $this->stagetypeEsm;
        $open_path = $hostserver . $ftp_root_dir . $hostpath . $userpath . $getuserid . '/' . $bookid . '/' . $stagetype . '/' . $chapter;
        $open_path = str_replace('//', '/', $open_path);
        $checkSourceexist = $hostpath . $userpath . $getuserid . '/' . $bookid . '/' . $stagetype . '/' . $chapter;
        $deleteSourceexist = $hostserver . $ftp_root_dir . $hostpath . $preprocesspath . $bookid . '/' . $stagetype . '/' . $chapter . '/' . $esmfilename;
        $checkDirFiles = $ftpObj->allFiles($checkSourceexist);
        if (count($checkDirFiles) >= 1 && $checkDirFiles != null) {
            $newcheckDirFiles = [];
            foreach ($checkDirFiles as $value) {
                if (strpos($value, '.') !== false) {
                    if (in_array(strrchr($value, "."), $this->esm_FILE_FORMAT)) {
                        $newcheckDirFiles[] = $value;
                    }
                }
            }

            if ($newcheckDirFiles != null && count($newcheckDirFiles) >= 2) {
                $response['errMsg']     =   "More than one ESM Files is submitting remove unwanted file";
                return response()->json($response);
            }

            $moveesmfile = "";
            if (strpos($newcheckDirFiles[0], '/') !== false) {
                $moveesmfile = substr(strrchr($newcheckDirFiles[0], "/"), 1);
            }

            $splitesmvideofiles = explode('.', $moveesmfile);
            $copyesmvideofiles[] = $splitesmvideofiles[0];

            $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
            $desDir = $hostserver . $hostpath . $preprocesspath . $bookid . '/' . $stagetype . '/' . $chapter;
            $sourcepath = $crd . $hostserver . $checkSourceexist;
            $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
            $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
            $response_copy = $ftp_obj->ftp_dir_copy_word_file_only($sourcepath, $desDir, $copyesmvideofiles, $this->esm_FILE_FORMAT);
            $response = array('result' => 404, 'Msg' => 'Failed', 'errMsg' => "");
            if (in_array('failed', $response_copy)) {
                foreach ($response_copy as $key => $value) {
                    if ($value == 'success') {
                        unset($response[$key]);
                    }
                }
                $response_copy = array('status' => 'failed', $response_copy);
            } else {
                $response_copy = array('status' => 'success', $response_copy);
            }

            if ($response_copy['status'] == 'success') {

                $filepath = explode('/', $moveesmfile);
                $filetypes = strrchr($moveesmfile, ".");
                $getesmfilename->FILE_TYPE = 'others';
                if (!empty($filetypes)) {
                    $getesmfilename->FILE_FORMAT = $filetypes;
                    if (in_array($filetypes, $this->esm_FILE_FORMAT)) {
                        $getesmfilename->FILE_TYPE = 'video';
                    }else{
                        $getesmfilename->FILE_TYPE = 'others';
                        $getesmfilename->IS_VALID = '3';
                    }
                }

                $getesmfilename->ORGINAL_FILE_NAME = $moveesmfile;
                $getesmfilename->UPDATED_DATE = Carbon::now();
                $getesmfilename->UPDATED_BY = $this->loginUserId;
                $getesmfilename->VID_GENERATION_STATUS = 0;
                $getesmfilename->save();
                $ref_pdf_data = ['jobid' => $jobId, 'metaId' => $metadataId];
                $ref_url = url('/') . '/api/esmvalidation';
                $cmn_obj = new CommonMethodsController();
                $postreferencepdf = $cmn_obj->PostcUrlExecution($ref_pdf_data, $ref_url);
               
                //delete if file name is not match
                if ($esmfilename != $moveesmfile) {
                    $postdata = [];
                    $postdata['file_path'] = $deleteSourceexist . '/<>' . $domuser . '<>' . $domPass;
                    $postdata['system_ip'] = $request->ip();
                    $postdata['processname'] = "deleteFileServer";
                    $postdata['method_name'] = "deleteFileServer";
                    $insertfilehandler = fileHandler::insertNew($postdata);
                }
                $response   =   $this->updatedResponse;
                return response()->json($response);
            }
            return response()->json($this->fileNotCopiedResponse);
        }
        return response()->json($this->nofileResponse);
        }
        catch( \Exception $e )
        {           
            return response()->json($response);
        }
    }

    public function deleteEsmFiles(Request $request) {
        try {
            $response   =   $this->locationNotFoundResponse;
            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'metadataId' => 'required|numeric',
                        'esmId' => "required|numeric"
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId = $request->input('jobId');
            $metadataId = $request->input('metadataId');
            $esmId = $request->input('esmId');
            $whereesm = ['IS_DELETED' => 0, 'METADATA_ID' => $metadataId, 'ID' => $esmId];
            $getesmfilename = metadataEsmModel::select(DB::raw('ID,ORGINAL_FILE_NAME'))->where($whereesm)->first();
            //filename
            $copyesmvideofiles = [];
            if (empty($getesmfilename)) {
                return response()->json($this->nofileResponse);
            }
            $esmfilename = $getesmfilename->ORGINAL_FILE_NAME;
            $getchapter = taskLevelMetadataModel::find($metadataId);
            if (empty($getchapter)) {
                $response['errMsg']     =   "Chapter is not found";
                return response()->json($response);
            }
            $bookdata = jobModel::getJobdetails($jobId);
            if (empty($bookdata)) {
                return response()->json($this->notfoundResponse);
            }

            $chapter = $getchapter->CHAPTER_NO;
            $bookid = (count($bookdata) >= 1 ? $bookdata->BOOK_ID : '');
            $preprocesspath = $this->preProcessPath;
            $userpath = $this->userWorkPath;
            //get location for exist job id
            $default_location = 0;
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);

            if (empty($getlocationftp) || $getlocationftp == null) {
                $default_location = 1;
                $getlocationftp = productionLocationModel::getDefaultProductionLocationInfo();
            }
            $hostserver = $getlocationftp->FTP_HOST;
            $hostusername = $getlocationftp->FTP_USER_NAME;
            if ($default_location == 1) {
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            } else {
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $getlocationftp->FTP_PATH_CREDENTIAL = 'ftp://' . $getlocationftp->FTP_USER_NAME . ':' . $hostpassword . '@';
                $getlocationftp->SERVER_PATH = $hostserver . $getlocationftp->FTP_PATH;
            }
            $hostpath = $getlocationftp->FTP_PATH;
            $hostuserfieserver = $getlocationftp->FILE_SERVER_USER_NAME;
            $hostpasswordfieserver = $getlocationftp->FILE_SERVER_PASSWORD;

            // Do the FTP connection
            $ftpObj = Storage::createFtpDriver([
                        'host' => $hostserver,
                        'username' => $hostusername,
                        'password' => $hostpassword, // 
                        'port' => '21',
                        'timeout' => '30',
            ]);

            $fileHandlerObj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
            $cucSourceexist = "";
            // RAW FILE PATH MAPPING
            $crd = "ftp://$hostusername:$hostpassword@";
            $getuserid = $this->empId;
            $ftp_root_dir = rtrim($this->ftp_root_dir, '/');
            $stagetype = $this->stagetypeEsm;
            $open_path = $hostserver . $ftp_root_dir . $hostpath . $userpath . $getuserid . '/' . $bookid . '/' . $stagetype . '/' . $chapter;
            $open_path = str_replace('//', '/', $open_path);
            $checkSourceexist = $hostpath . $preprocesspath . $bookid . '/' . $stagetype . '/' . $chapter . '/' . $esmfilename;
            $deleteSourceexist = $hostserver . $ftp_root_dir . $hostpath . $preprocesspath . $bookid . '/' . $stagetype . '/' . $chapter . '/' . $esmfilename;

            if ($ftpObj->has($checkSourceexist)) {
                $ftpObj->delete($checkSourceexist);
            }
            $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
            $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
            $getesmfilename->IS_DELETED = 1;
            $getesmfilename->save();
            $response   =   $this->deletedResponse;
            return response()->json($response);
        } catch (\Exception $e) {
            return response()->json($response);
        }
    }

}
