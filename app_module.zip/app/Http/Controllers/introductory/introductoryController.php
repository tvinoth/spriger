<?php
namespace App\Http\Controllers\introductory;
use App\Http\Controllers\Controller;
use App\Models\bookinfoModel;
use App\Models\jobInfoModel;
use App\Models\jobModel;
use App\Models\stageModel;
use App\Models\productionLocationModel;  
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
use File;
use Mail;
use Config;

/*
 * Author   :    Ananth Bhagavan -> March 09 2018
 * Introductory Controller
 * 
 */

class introductoryController extends Controller
{   
   
    public $validationErr        =      array();
    public $errFlag              =      false;
    public $attachPath           =      'introductory_attachment/';

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(){
        
	$data 			=	array();
        $this->displayMenuName(Config::get('menuconstants.MENU.INTRO_LETTERY'),$data);
        $letterFormat_arr       =       \Config::get('constants.INTRODUCTORY.LETTER_FORMAT');
        $letterOpt              =       '';
        
        foreach ( $letterFormat_arr as $key => $value ){
            $letterOpt      .=  '<option value="'.($key+1).'">';
            $letterOpt      .=  $value;
            $letterOpt      .=  '</option>';
        }
        $data['letterFormat']   =   $letterOpt;
        
        $booksinfo       =       bookinfoModel::getBookinfo();
        $booksOpt              =       '';
        
        foreach ( $booksinfo as $key => $value ){
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
        }
        $data['bookidCollect']   =   $booksOpt;
        
        return view('introductory.introletter')->with($data);
		
    }
    
    public function getAllBooklist(){
	
        $data       =       bookinfoModel::getBookinfo();
        $userId     =       Session::get('users')['user_id'];
	$response["book"] 	= 	$data;
        
        return response()->json($response);
        
    }
 
    public  function getBookinfoByJobid( $jobid = null , $returns = 'json'){
        
        $response       =       array( );
        
        $query_cstm     =       'SELECT j.BOOK_ID  as bookId , j.JOB_TITLE as bookTitle , ji.ISSN_PRINT as printIssn ,  ji.PE_MAIL as productionEditor , 
                                        ji.PROOF_RECIPIENT as proofRecipient , pal.ADDRESS as pmAddress , upm.EMPLOYEE_ID as empId ,
                                        concat( upm.FIRST_NAME , " " , upm.LAST_NAME  ) as pmName , upm.EMAIL as pmEmail , ji.AUTHOR_NAME as authorName , ji.AUTHOR_EMAIL as authorEmail , 
                                        ji.EDITOR_NAME as editorName , ji.EDITOR_EMAIL as editorEmail , pal.ADDRESS as address FROM job j 
                                        LEFT JOIN job_info ji on ji.JOB_ID = j.JOB_ID LEFT JOIN user upm on upm.USER_ID = j.PM 
                                        LEFT JOIN user_credential uc_pm ON upm.USER_ID = uc_pm.INTERNAL_USER_ID
                                        left join pm_location_mapping plm on plm.PROJECT_MANAGER_ID = upm.USER_ID and plm.`STATUS` = "ACTIVE" 
                                        left join production_area_location pal on pal.ID = plm.PRODUCTION_AREA WHERE j.JOB_ID = '.$jobid;
        
        $data       =          DB::select( $query_cstm );
        $userId     =       Session::get('users')['user_id'];
	$response["bookinfo"] 	= 	$data;
        
        if( $returns == 'json' )
            return response()->json($response);
        
        
        return $response;
    }
    
    public  function getBookinfoByJobidwithProjectbinStage( Request $request){
        
        $response       =       array( );
        $jobid          =   $request->input('jobId');
        $round          =   $request->input('round');
        $typeofsearch   =   $request->input('typeofsearch');
        
        $query_cstm     =       'SELECT j.BOOK_ID  as bookId , j.JOB_TITLE as bookTitle , ji.ISSN_PRINT as printIssn ,  ji.PE_MAIL as productionEditor , 
                                        ji.PROOF_RECIPIENT as proofRecipient , pal.ADDRESS as pmAddress , upm.EMPLOYEE_ID as empId ,
                                        concat( upm.FIRST_NAME , " " , upm.LAST_NAME  ) as pmName , upm.EMAIL as pmEmail , ji.AUTHOR_NAME as authorName , ji.AUTHOR_EMAIL as authorEmail , 
                                        ji.EDITOR_NAME as editorName , ji.EDITOR_EMAIL as editorEmail , pal.ADDRESS as address FROM job j 
                                        LEFT JOIN job_info ji on ji.JOB_ID = j.JOB_ID LEFT JOIN user upm on upm.USER_ID = j.PM 
                                        LEFT JOIN user_credential uc_pm ON upm.USER_ID = uc_pm.INTERNAL_USER_ID
                                        left join pm_location_mapping plm on plm.PROJECT_MANAGER_ID = upm.USER_ID and plm.`STATUS` = "ACTIVE" 
                                        left join production_area_location pal on pal.ID = plm.PRODUCTION_AREA WHERE j.JOB_ID = '.$jobid;
        
        $data           =   DB::select( $query_cstm );
	$response["bookinfo"]   =   $data;
        
        $stagequery     =   "";
        $stageData      =   [];
        
        $stagequery     .=   " select s.STAGE_ID,re.NAME as ROLENAME,s.STAGE_NAME from role_enum re join stage_role sr on sr.ROLE = re.ID join stage s on s.STAGE_ID = sr.STAGE where sr.ROLE = $this->roleId group by s.STAGE_ID ";
        if(empty($this->roleId)){
            $stageData  =   stageModel::getAllStageInfo();
        } 
//        if($round != null){
//            $stagequery .=  " and jr.ROUND_ID = $round ";
//        }
        
//        $stagequery .=  " group by jr.ROUND_ID,jr.CURRENT_STAGE ";
        
        $stageData   =   DB::select( $stagequery );
        $response["stageinfo"]   =   $stageData;
        
        return response()->json($response);
    }
    
    public function doAttachment( $getftpfile  , &$mailArray ){
        
        $app_temp_path                  =       $this->attachPath;
        $putfile                        =       false;
        if( isset( $getftpfile ) && is_object( $getftpfile ) ){

            if(!file_exists( storage_path( $app_temp_path ) ) ){            
                File::makeDirectory(storage_path($app_temp_path), $mode = 0777, true, true);
            }

            $putfile                    =       file_put_contents( storage_path( $app_temp_path.$getftpfile->getClientOriginalName() ) , $getftpfile->getClientOriginalName());
            
            
            $mailArray['file']          =       $getftpfile->getRealPath();
            $mailArray['attachfile']    =       array( 'as' => 'Introductory_Letter.' . $getftpfile->getClientOriginalExtension(), 'mime' => $getftpfile->getMimeType());

        }       
         
        return $putfile;
    }
    
    public function validation( $input_arr = array() ){
       
        //validation  Rule  -   
        
        $validator  = Validator::make( $input_arr , [
                        'jobId'             =>      'required',
                        'letterFormat'      =>      'required|numeric',
                        'ediAuthName'       =>      'required',
                        'spiContactname'    =>      'required',
                        'titleName'         =>      'required',
                        'mailFrom'          =>      'required|email',
                        //'mailCc'            =>      'required|email',
                        'ediAuthEmail'      =>      'required|email',
                        'ediAuthSubject'    =>      'required',
                        'spiEmail'          =>      'required|email',
                        'spiContactname'    =>      'required',
                        'spiContactEmpId'   =>      'required',
                        'timePrfStrt'       =>      'required',
                        'timePrfEnd'        =>      'required',
                        'timeEstimated'     =>      'required',
                        'corrections'       =>      'required' , 
                        'reviewNoofDays'    =>      'numeric' , 
                        'complementry'    =>      'numeric' , 
            
                    ]);
        
       if($validator->fails()){
            $this->validationErr    =       array(
                                            'status'            =>      0,
                                            'validationerror'   =>      $validator->errors()
                                                ); 
            $this->errFlag          =       true;
           
        }
            
       return $validator; 
       
    }
    
    public function sendMailForIntroductory( Request $request ){
            $response   =   $this->notfoundResponse;
            $inp_data               =       $request->input( 'data' );
            $inp_data               =       json_decode( $inp_data );
            $inp_data2              =       (array)$inp_data;
            $inp_data2['file']      =       $request->file('file');
            
            $validator              =       $this->validation( $inp_data2 );
            $log_insert             =       array();
            
            if( $validator->fails() ){
                return response()->json( $this->validationErr , 401 );
            }
            
            $jobId              =       $inp_data->jobId;
            $mailArray          =       array();
            $mailData           =       array();
            $bookexist          =       jobInfoModel::checkExistbookjob($jobId);
            $job_info           =       jobModel::getJobdetails( $jobId );
            $pmLocation         =       $this->getBookinfoByJobid( $jobId  , 'array' );           
            $mailData           =       $this->prepareData( $inp_data );
            $leterformat_id     =       $inp_data->letterFormat;
            
            $mailData['book_title']             =       $job_info->JOB_TITLE;
            $log_insert['JOB_ID']               =       $jobId;
            $log_insert['CREATED_BY']           =       Session::get('users')['user_id'];
            $log_insert['CREATED_DATE']         =       date( 'Y-m-d H:i:s' );
            
            $pub_imprint_logic                  =       '';
            
            if( isset( $job_info->PUBLISHER_IMPRINT_NAME ) ){
                
                $pub_imprint_logic          =       $job_info->PUBLISHER_IMPRINT_NAME;
                $pub_imprint_logic          =       str_replace(  'pivot' , '' , strtolower( $pub_imprint_logic ) );
                
                if( $pub_imprint_logic == 'palgrave' ){
                    $pub_imprint_logic      =       ( $pub_imprint_logic ).' Macmillan';
                }
                
            }
            
            $pub_imprint_logic              =       ucfirst( $pub_imprint_logic );
            
            $mailData['publisherImprint']   =       $pub_imprint_logic;    
            $pmLocation                     =       $pmLocation['bookinfo'][0];
            $mailData['pm_contact']         =       $pmLocation->pmAddress;
           
            if( count($bookexist) >= 1 ){
                
                $getftpfile             =       $request->file('file');
                //this method will validate and do the application file upload , then return attachment related infomation for mail
                $this->doAttachment( $getftpfile , $mailArray );
                
                //addition MailData push
                
                $mailData['Title']          =       'Introductory Letter';
                $mailData['HeadLine']       =       'Introductory Letter';
                $mailData['ToName']         =       (count( $bookexist )>=1 ? $bookexist->PE_NAME:'');
                $mailData['username']       =       Session::get('users')['user_name'];
                $mailArray['Data']          =       $mailData;
                
                $mailArray['TemplateName']  =       'emailtemplate.introductory.template_'.$leterformat_id;
                $mailArray['Subject']       =       $inp_data->ediAuthSubject;
                $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
                $mailArray['ToMail']        =       'ananth.b@spi-global.com';//$inp_data->ediAuthEmail;
                  
                if( !empty( $inp_data->mailCc ) ){
                    $mailArray['CcMail']    =   explode( ';' , $inp_data->mailCc );
                    
                    //Server side mailid validation need to done here for cc
                }
                
                $log_insert['data']         =      json_encode( $mailArray );
                 
                if (is_array($mailArray)){
                    
                    Mail::send( $mailArray['TemplateName'] , $mailArray['Data'] , function ($message) use ($mailArray){
                        
                        $message->subject($mailArray['Subject']);
                        $message->from($mailArray['FromMail'], $mailArray['FromName']);
                        $message->to($mailArray['ToMail']);
                        if( isset( $mailArray['attachfile'] ) )
                            $message->attach($mailArray['file'],$mailArray['attachfile']);
                        
                        if (array_key_exists('CcMail', $mailArray)){
                            $message->cc($mailArray['CcMail']);
                        }
                        
                       $message->getSwiftMessage();
                        
                        $log_insert['status']           =       1;
                        
                        
                    });

                    if (Mail::failures()){              
                        $response   =   $this->failedResponse;
                        $response['MsgText']    =   Mail::failures();
                        $log_insert['status']           =       0;
                        
                        DB::table('introductory_mail_log')->insert( $log_insert );
                        
                        return response()->json($result,401);
                        
                    } else {
                        
                        //unlink the attachment from application                   
                        
                        DB::table('introductory_mail_log')->insert( $log_insert );    
                        return response()->json($this->mailSentResponse);
                    }   
                }
                $response['errMsg']     =   'Mail sending Failed!';
                return response()->json($response,401 );
            }
            return response()->json( $response,401 );
        
    }   
    
    public function getPreviewDesign( Request $request ){
       
            $inp_data           =      $request->all();
            $validator              =       $this->validation( $inp_data );
            if( $validator->fails() ){
                return response()->json( $this->validationErr , 401 );
            }
            
            $inp_data           =       (object)$inp_data;
            $jobId              =       $inp_data->jobId;
            $mailData                       =       array();
            $bookexist          =       jobInfoModel::checkExistbookjob($jobId);
            $job_info           =       jobModel::getJobdetails( $jobId );
            $pmLocation         =       $this->getBookinfoByJobid( $jobId  , 'array' );
            $mailData           =       $this->prepareData( $inp_data );
            $leterformat_id     =       $inp_data->letterFormat;
            $mailData['book_title']          =       $job_info->JOB_TITLE;
            $pub_imprint_logic               =       '';
            
            if( isset( $job_info->PUBLISHER_IMPRINT_NAME ) ){
                
                $pub_imprint_logic          =       $job_info->PUBLISHER_IMPRINT_NAME;
                $pub_imprint_logic          =       str_replace(  'pivot' , '' , strtolower( $pub_imprint_logic ) );
                
                if( trim( $pub_imprint_logic ) == 'palgrave' ){
                    $pub_imprint_logic      =       ( $pub_imprint_logic ).' Macmillan';
                }
                
            }
            $pub_imprint_logic               =       ucfirst( $pub_imprint_logic );
            $mailData['publisherImprint']    =       $pub_imprint_logic;                
            $mailData['book_title']          =       $job_info->JOB_TITLE;
            $pmLocation                      =       $pmLocation['bookinfo'][0];
            $mailData['pm_name']             =       $pmLocation->pmName;
            $mailData['pm_contact']          =       $pmLocation->pmAddress;            
            $mailData['Title']               =       'Introductory Letter';
            $mailData['HeadLine']            =       'Introductory Letter Preview';
            $mailData['username']            =       Session::get('users')['user_name'];
            $mailData['ToName']              =       (count( $bookexist )>=1 ? $bookexist->PE_NAME:'');
            $mailData['username']            =       Session::get('users')['user_name'];
               
           return view( 'emailtemplate.introductory.template_'.$leterformat_id )->with( $mailData ); 
           
    }
        
    public function prepareData( $inp_data ){
        
        $ediauth                        =       isset( $inp_data->ediAuthName ) ? $inp_data->ediAuthName : '';
        $mailData['book_author']        =       $ediauth;
        $mailData['pm_name']            =       $inp_data->spiContactname;
        
        $timePrfStrt                    =       $inp_data->timePrfStrt;
        $timePrfEnd                     =       $inp_data->timePrfEnd;
        
        $finding_proof_date_start               =       date( 'd M' , strtotime( $timePrfStrt ) );
        $finding_proof_date_end                 =       date( 'd M' , strtotime( $timePrfEnd  ) );
       
        $mailData['chp_proof']                  =       $finding_proof_date_start.' - '.$finding_proof_date_end;
        $mailData['estimatedPrintPubDate']      =       date( 'M-Y' , strtotime( $inp_data->timeEstimated ) );        
        
        if( isset( $inp_data->timeFmStart ) &&  isset( $inp_data->timeFmEnd )  ){
        
            $fm_start       =           date( 'd M' , strtotime( $inp_data->timeFmStart ) );
            $fm_end         =           date( 'd M' , strtotime( $inp_data->timeFmEnd  ) ); 
            $mailData['book_proof_with_fm']     =       $fm_start.' - '.$fm_end;
        
        }
        
        $mailData['correction_days']            =       @$inp_data->corrections.' days after receipt of proofs';
        $mailData['review_days']                =       @$inp_data->reviewNoofDays;
        $mailData['complementry_copy']          =       @$inp_data->complementry;
        
        $mailData['fsv_company_name']           =       'SPI-GLOBAL';
        $mailData['nature_reference_style']     =       'Lorum ipsum';
        
        return $mailData;
        
    }
    
	
	
    public function mailLogByPM(){
        
        //yet to do
        
    }
        
    }
    
