<?php

namespace App\Http\Controllers\RetrieveVersion;

use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\bookinfoModel;
use App\Models\jobModel;
use App\Models\productionLocationModel;
use App\Models\stageModel;
use App\Models\requiredConstants;
use App\Models\roundModel;
use App\Models\fileHandler;
use App\Models\downloadModel;
use App\Models\alfrescoLogModel;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB;

class RetrieveVersionController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request) {
        $data = array();
        $wheredata = ['stage.STAGE_TYPE' => 1, 'stage.IS_AUTO' => 0, 'stage.IS_ACTIVE' => 1, 'al.IS_ACTIVE' => 1, 'al.MODE' => 1];
        $processtypes = alfrescoLogModel::retrievestageData($wheredata);
        $this->displayMenuName(Config::get('menuconstants.MENU.CUSTOMIZATION_RETRIEVE'), $data);
        $wherejobdata = ['job.IS_ACTIVE' => 1, 'al.IS_ACTIVE' => 1];
        $booksinfo = alfrescoLogModel::retrieveJobData($wherejobdata);
        $booksOpt = '<option value="">--Select--</option>';
        if (count($booksinfo) >= 1) {
            foreach ($booksinfo as $key => $value) {
                $booksOpt .= '<option data-bookid="' . $value['BOOK_ID'] . '" value="' . $value['JOB_ID'] . '">';
                $booksOpt .= $value['BOOK_ID'];
                $booksOpt .= '</option>';
            }
        }

        $processOpt = '<option value="">--Select--</option>';
        if (count($processtypes) >= 1) {
            foreach ($processtypes as $key => $value) {
                $processOpt .= '<option value="' . $value->STAGE_ID . '">';
                $processOpt .= $value->STAGE_NAME;
                $processOpt .= '</option>';
            }
        }

        $rounddata = roundModel::Active()->get();
        $roundOpt = '<option value="">--Select--</option>';
        if (count($rounddata) >= 1) {
            foreach ($rounddata as $key => $value) {
                $roundOpt .= '<option value="' . ($value->ID) . '">';
                $roundOpt .= $value->NAME;
                $roundOpt .= '</option>';
            }
        }
        $data['bookidCollect'] = $booksOpt;
        $data['processview'] = $processOpt;
        $data['round'] = $roundOpt;
        return view('RetrieveVersion.index')->with($data);
    }

    public function viewretrieveChapterList(Request $request) {
        $validation = Validator::make($request->all(), [
                    'jodId' => 'required|numeric',
                    'bookId' => 'required',
                    'roundId' => 'required',
                    'processId' => 'required|numeric'
        ]);

        if ($validation->fails()) {
            $response = $this->validationResponse;
            $response['validation'] = $validation->errors();
            return response()->json($response);
        }

        $jobID = $request->input('jodId');
        $bookID = $request->input('bookId');
        $roundID = $request->input('roundId');
        $processID = $request->input('processId');
        $data = alfrescoLogModel::retrieveChapterData($jobID, $roundID, $processID);
        $response["chapterdata"] = $data;
        return response()->json($response);
    }

    public function openChapterFiles(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'roundId' => 'required|numeric',
                        'resourcetype' => 'required|numeric',
                        'chapterId' => "required|array|min:1",
                        'chapterId.*' => "required|distinct|min:1|numeric"
            ]);

            if ($validation->fails()) {
                $response = $this->validationResponse;
                $response['validation'] = $validation->errors();
                return response()->json($response);
            }

            $jobId = $request->input('jobId');
            $resourcetype = $request->input('resourcetype');
            $metaid = $request->input('chapterId');
            $roundId = $request->input('roundId');
            $roundname = roundModel::find($roundId);
            $roundname = ($roundname != '' ? $roundname->NAME : '');
            $resourceview = downloadViewSourceModel::find($resourcetype);
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills = jobModel::where('JOB_ID', $jobId)->first();
            $filepathid = ($resourceview != '' ? $resourceview->REQUIRED_CONSTANT_NAME : '');
            $getchapterinfo = taskLevelMetadataModel::wherein('METADATA_ID', $metaid)->Active()->get();
            $getchapterinfo = $getchapterinfo->pluck('CHAPTER_NO', 'METADATA_ID');
            $getfileconstant = requiredConstants::where('CONSTANT_NAME', $filepathid)->first();
            if (count($getlocationftp) >= 1 && $bookdetaills != null && $resourceview != null && count($bookdetaills) >= 1 && $getfileconstant != '' && count($getchapterinfo) >= 1 && $getchapterinfo != null) {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;

                $ftpObj = \Storage::createFtpDriver([
                            'host' => $hostserver,
                            'username' => $hostusername,
                            'password' => $hostpassword,
                            'port' => '21',
                            'timeout' => '30',
                ]);

                $cmn_obj = new CommonMethodsController();
                $filepath = [];
                $getzipname = [];
                //PATH CONCATENATION
                switch ($resourcetype) {
                    case ($resourcetype == '7' || $resourcetype == '8' || $resourcetype == '10' || $resourcetype == '11'):
                        foreach ($getchapterinfo as $key => $value) {
                            $array = array(
                                '{BID}' => $bookid,
                                '{RID}' => $roundname,
                                '{CID}' => $value
                            );
                            $filepath[$value] = $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                        }

                        break;
                    case '9':
                        //zip file name
                        $getzipproofing = apiEproofPackagingModel::join(DB::raw('(select max(ID) as aepid from api_eproof_packaging group by METADATA_ID order by aepid desc) apieproof'), function($join) {
                                            $join->on('api_eproof_packaging.ID', '=', 'apieproof.aepid');
                                        })
                                        ->wherein('METADATA_ID', $metaid)
                                        ->where('ROUND', $roundId)->get();

                        if ($getzipproofing == null || count($getzipproofing) == 0) {
                            $response = $this->notfoundResponse;
                            $response['errMsg'] = 'Author Zip File is not found !';
                            return response()->json($response);
                        }
                        $getzipproofing = $getzipproofing->pluck('PACKAGE_ID', 'METADATA_ID')->toArray();
                        foreach ($getchapterinfo as $key => $value) {
                            $array = array(
                                '{BID}' => $bookid,
                                '{RID}' => $roundname,
                                '{CID}' => $value);
                            $filepath[$value] = $cmn_obj->arr_key_value_replace($array, rtrim($getfileconstant->CONSTANT_VALUE, '/'));
                        }
//                                            foreach($getzipproofing as $key=>$value){
//                                                if(array_key_exists($key, $filepath)){
//                                                    $newarray   =   explode('/',$filepath[$key]);
//                                                    //get chapter name
//                                                    $splitchp   =   last($newarray);
//                                                    $getzipname[$splitchp]  =   str_replace('.zip','',$filepath[$key].'/'.$value);
//                                                }
//                                            }                    
                        break;
                    default:
                        foreach ($getchapterinfo as $key => $value) {
                            $array = array(
                                '{BID}' => $bookid,
                                '{RID}' => $roundname,
                                '{CID}' => $value
                            );
                            $filepath[$value] = $cmn_obj->arr_key_value_replace($array, $getfileconstant->CONSTANT_VALUE);
                        }
                        break;
                }

                $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                $userworkfolder = Config::get('serverconstants.RESOURCE_VIEW');
                $ftp_root_dir = rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'), '/');
                $getuserid = $this->empId;
                $crd = "ftp://$hostusername:$hostpassword@";
                $nameofresourceview = preg_replace('/\s+/', '_', $resourceview->NAME);
                $open_path = $hostserver . $ftp_root_dir . $hostpath . $userworkfolder . $getuserid . '/' . $bookid . '/' . $nameofresourceview;
                $checkfilesexist = [];
                $filecopymessage = [];
                $getFileExtnType = [];

                if (count($filepath) >= 1) {
                    foreach ($filepath as $Chapter => $value) {
                        $checkDirFiles = $ftpObj->allFiles($value);
                        if (count($checkDirFiles) >= 1) {
                            $desDir = $hostserver . $hostpath . $userworkfolder . $getuserid . '/' . $bookid . '/' . $nameofresourceview . '/' . $Chapter;
                            $sourcepath = $crd . $hostserver . '/' . $value;
                            //if format is not null copy only format file
                            if ($resourceview->FILE_FORMAT == null) {
                                $response_copy = $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                            } else {
                                //if format is null copy all file
                                if (strpos($resourceview->FILE_FORMAT, ',') != false) {
                                    $getFileExtnType = explode(",", $resourceview->FILE_FORMAT);
                                } else {
                                    $getFileExtnType[] = $resourceview->FILE_FORMAT;
                                }
                                $response_copy = $ftp_obj->ftp_dir_copy_word_file_only($sourcepath, $desDir, [], $getFileExtnType);
                            }

                            $filecopymessage[] = $response_copy;
                            $checkfilesexist[] = $value;
                        } else {
                            $checkfilesexist[] = "";
                        }
                    }
                }

                if (count($filepath) >= 1 && $resourcetype == 9) {
                    $newFilepath = [];
                    foreach ($filepath as $Chapter => $value) {
                        $newFilepath[$Chapter] = str_replace($roundname, Config::get('constants.ROUND_ID')[$this->round_ID_650], $value);
                    }
                    foreach ($newFilepath as $Chapter => $value) {
                        $checkDirFiles = $ftpObj->allFiles($value);
                        if (count($checkDirFiles) >= 1) {
                            $desDir = $hostserver . $hostpath . $userworkfolder . $getuserid . '/' . $bookid . '/' . $nameofresourceview . '/' . $Chapter;
                            $sourcepath = $crd . $hostserver . '/' . $value;
                            //if format is not null copy only format file
                            if ($resourceview->FILE_FORMAT == null) {
                                $response_copy = $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                            } else {
                                //if format is null copy all file
                                if (strpos($resourceview->FILE_FORMAT, ',') != false) {
                                    $getFileExtnType = explode(",", $resourceview->FILE_FORMAT);
                                } else {
                                    $getFileExtnType[] = $resourceview->FILE_FORMAT;
                                }
                                $response_copy = $ftp_obj->ftp_dir_copy_word_file_only($sourcepath, $desDir, [], $getFileExtnType);
                            }

                            $filecopymessage[] = $response_copy;
                            $checkfilesexist[] = $value;
                        } else {
                            $checkfilesexist[] = "";
                        }
                    }
                }

//                if(count($filepath) >= 1 && $resourcetype   !=  9){
//                    foreach($filepath as $Chapter=>$value){
//                        $checkDirFiles = $ftpObj->allFiles($value);
//                        if(count($checkDirFiles) >= 1) {
//                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
//                            $sourcepath     =   $crd . $hostserver . '/' . $value;
//                            $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
//                            $filecopymessage[]  =   $response_copy;
//                            $checkfilesexist[]  =   $value;
//                        }else{
//                            $checkfilesexist[]  =   "";
//                        }
//                    }
//                }
//                if(count($getzipname) >= 1 && $resourcetype   ==  9){
//                    foreach($getzipname as $Chapter=>$value){
//                        // get full path  except zip file name
//                        $getfilecopyname    =   substr(strrchr($value, "/"), 1);
//                        $totalleng  =   strlen($value) - strlen($getfilecopyname);
//                        $splitchp   =   substr($value,0,$totalleng);
//                        $checkDirFiles = $ftpObj->allFiles($splitchp);
//                        if(count($checkDirFiles) >= 1) {
//                            $desDir     =   $hostserver.$hostpath.$userworkfolder.$getuserid.'/'.$bookid.'/'.$nameofresourceview.'/'.$Chapter;
//                            $sourcepath     =   $crd . $hostserver . '/' . $splitchp;
//                            $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only(  $sourcepath , $desDir,[$getfilecopyname],['.zip'] );
//                            $filecopymessage[]  =   $response_copy;
//                            $checkfilesexist[]  =   $value;
//                        }else{
//                            $checkfilesexist[]  =   "";
//                        }
//                    }
//                }

                if (count($checkfilesexist) >= 1) {
                    if (in_array('', $checkfilesexist) && $resourcetype != 9) {
                        $response = $this->notfoundResponse;
                        $response['errMsg'] = $resourceview->NAME . ' file is not found !';
                        return response()->json($response);
                    }
                }

                if (count($filecopymessage) >= 1) {
                    foreach ($filecopymessage as $key => $value) {
                        if (in_array('failed', $filecopymessage[$key])) {
                            return response()->json($this->fileNotCopiedResponse);
                        }
                    }
                }

                if (count($filecopymessage) >= 1) {
                    $postdata = [];
                    $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                    $postdata['system_ip'] = $request->ip();
                    $postdata['method_name'] = "doOpenDriveServer";
                    $postdata['processname'] = "checkout";
                    $insertfilehandler = fileHandler::insertNew($postdata);

                    if ($insertfilehandler) {
                        $response = $this->successResponse;
                        $response['rmID'] = $insertfilehandler;
                        return response()->json($response);
                    }
                }
                return response()->json($this->fileNotCopiedResponse);
            }
            return response()->json($this->locationNotFoundResponse);
        } catch (\Exception $e) {
            return response()->json($this->locationNotFoundResponse);
        }
    }

}
