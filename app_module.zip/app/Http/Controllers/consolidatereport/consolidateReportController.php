<?php
namespace App\Http\Controllers\consolidatereport;
use App\Http\Controllers\Controller;
use App\Models\parreportModel;
use App\Models\jobModel;
use App\Models\productionLocationModel;
use App\Models\jobInfoModel;
use App\Models\partMappingModel;
use App\Models\downloadModel;
use App\Models\apiMetaExtractor;
use App\Models\apiFileUpload;
use App\Models\metadataEsmModel;
use App\Models\apiClientAcknowledgement;
use App\Models\jobsheetViewpathModel;
use App\Models\taskLevelMetadataModel;
use App\Models\taskLevelArtMetadataModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use PHPExcel_Cell_DataValidation; 
use PHPExcel_NamedRange; 
use App\Http\Controllers\CommonMethodsController;
use Session;
use Config;
use Excel;
use Storage;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
class consolidateReportController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request,$jobID = null)
    {
	$data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CONSOLIDATE'),$data);
	$data['projectId'] 	=   $jobID;
        $data['user_name']      =   $this->userName;
        $data['role_name']      =   $this->roleName;
        return view('consolidatereport.consolidate-index')->with($data);
    }
   
    public function getConsolidateList()
    {
        $wheredata      =   [];
//        $wheredata['PRR_REPORT_STATUS']     =   1;        
//        $wheredata['SPICAST_STATUS']        =   1;        
        $wheredata['job.IS_ACTIVE']           =   1;        
        $data           =   jobModel::getConsolitedetails($wheredata);
        $response["consolidate"]    =   $data;
        $response['role_id']        =   $this->loginUserId;
        return response()->json($response);
    }
    
    public function getConsolidateJob(Request $request,$jobId)
    {
        if($jobId 	==  null){
            return redirect('/consolidate-report');
        }
        $data 			=   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CONSOLIDATE'),$data);
        $data['backurl']        =   url('/').'/consolidate-report';
        $bookdata               =   jobModel::Find($jobId);
        if($bookdata){
            $bookid                 =   $bookdata->BOOK_ID;
            $data['pageName']       =   'Consolidated Report - '.$bookid;
            $data['user_name'] 	=   $this->userName;
            $data['role_name'] 	=   $this->roleName;
            $data['downloadURL']    =   url('downloadConsolidateReport/'.$jobId);
            $data['artfigureURL']   =   url('downloadArtfigureReport/'.$jobId);
            $data['projectId']      =   $jobId;
            $wheredata              =   ['ROUND'=>Config::get('constants.ROUND_ID.S50'),'META_EXTRACTION_STATUS'=>'1','BOOK_ID'=>$bookid];
            $sfiftyjobsheetview     =   downloadModel::where($wheredata)->orderBy('ID','desc')->first();

            $wheremeta              =   ['ROUND'=>Config::get('constants.ROUND_ID.S50'),'JOB_ID'=>$jobId  , 'PROCESS_TYPE' => 'UPDATE' ];
            $sfiftymeta             =   apiMetaExtractor::where($wheremeta)->orderBy('ID','desc')->first();

            $data['sfiftymetaview'] =   (count($sfiftymeta)>=1?1:0);

            if( count($sfiftymeta) == 0 ){
                $data['sfiftymetaview'] =  1;
            }

            $data['sfiftyjobsheet'] =   (count($sfiftyjobsheetview)>=1?1:0);

            $rolerestrict           =   Config::get('constants.CONSOLIDATE_MANAGER_ROLE_ID');
            $data['disablevalues']  =   ((in_array($this->roleId,$rolerestrict)  ==  true)?0:1);
            return view('consolidatereport.consolidate-report')->with($data);
        }
        return redirect('/consolidate-report');
    }
    
    public function getConsolidateofjobinfo(Request $request)
    {
        try
        {
            if ($request->input('jodId') == null) 
            {
                return response()->json($this->notfoundResponse, 400);
            }
            $resultofpart       =   [];
            $jobID              =   $request->input('jodId');
            $getparrtmapping    =   partMappingModel::where('JOB_ID',$jobID)->where('STATUS',true)->get();
            
            $jobModelObj        =   new jobModel();
            $jobDetails         =   $jobModelObj->getJobdetails($jobID);
            $bookId             =   $jobDetails['BOOK_ID'];
            
            if(count($getparrtmapping)>=1)
            {
                $getparts       =   $getparrtmapping->pluck('PART_METADATA_ID')->toArray();
                $getchapters    =   $getparrtmapping->pluck('CHAPTER_METADATA_ID')->toArray();
                $allprtchapter  =   array_merge($getparts,$getchapters);
                //get chapters from part mapping
                $getchapterparrtmapping  =   partMappingModel::wherein('PART_METADATA_ID',$getparts)->get();
                $resultofpart   =   taskLevelMetadataModel::select(DB::raw('METADATA_ID,CHAPTER_NO '))->wherein('METADATA_ID',$getparts)->get()->toArray();
            }
            $newparts           =   [];
            $allresultofpart    =   taskLevelMetadataModel::getpartnameBook($jobID);
            if(count($resultofpart)>=1)
            {
                foreach($resultofpart as $key=>$value)
                {
                    $newparts[$key]  =   (object)$value;
                }
            }
            $resultofpart       =   array_unique(array_merge($allresultofpart,$newparts),SORT_REGULAR);
            
            //get consolidate list from tasklevelmeata ,metadata - info table
            //CHECK PART IS AVAILABLE OR NOT
            $checkpartavailable =   taskLevelMetadataModel::getreportofconsolidate("4",$jobID);
            $bookQuery          =   $this->getQueryCountByJob($bookId );
            if(count($checkpartavailable)>=1)
            {
                $partresult     =   [];
                $partincrement  =   0;
                //get fm record 
                $getfrontmatter =   taskLevelMetadataModel::getreportofconsolidate("1",$jobID);
              
                if(count($getfrontmatter)>=1)
                {
                    foreach($getfrontmatter     as     $frontdata)
                    {
                        if($frontdata['CHAPTER_NO'] !=   null){
                            $frontdata['query']         =   $this->getQueryCountByChapter($frontdata['CHAPTER_NO'],$bookQuery );
                            $partresult[$partincrement]  =   $frontdata;
                            $partincrement++;
                        }
                    }
                }
                $partincrement  =   $partincrement;
                
                
                $onlyChapter    =   taskLevelMetadataModel::getChapterWithoutPart($jobID);
                
                if(count($onlyChapter)>=1){
                    foreach($onlyChapter     as     $onlyChapters)
                    {
                        if($onlyChapters['CHAPTER_NO'] !=   null){
                            $onlyChapters['query']         =   $this->getQueryCountByChapter($onlyChapters['CHAPTER_NO'],$bookQuery);
                            $partresult[$partincrement]  =   $onlyChapters;
                            $partincrement++;
                        }
                    }
                    $partincrement  =   $partincrement;
                }
                
                //get part then chapter record 
                foreach($checkpartavailable     as $partidvalue)
                {
                    ++$partincrement;
                    $partresult[$partincrement]     =   $partidvalue;
                    $chapterdataresult  =   taskLevelMetadataModel::getchapterlistagainpart($partidvalue->METADATA_ID,$jobID);
                    if(count($chapterdataresult)>=1)
                    {
                        foreach($chapterdataresult  as  $chapterdatavalue)
                        {
                            if($chapterdatavalue['CHAPTER_NO'] !=   null){
                                $chapterdatavalue['query']         =   $this->getQueryCountByChapter($chapterdatavalue['CHAPTER_NO'],$bookQuery);
                                ++$partincrement;
                                $partresult[$partincrement]     =   $chapterdatavalue;
                            }
                        }
                    }
                }
                //get bm then chapter record 
                $getbackmatter      =   taskLevelMetadataModel::getreportofconsolidate("3",$jobID);
                if(count($getbackmatter)>=1)
                {
                    ++$partincrement;
                    foreach($getbackmatter  as     $backdata)
                    {
                        $backdata['query']         =   $this->getQueryCountByChapter($backdata['CHAPTER_NO'],$bookQuery);
                        $partresult[$partincrement]  =   $backdata;
                    }
                }
                $data           =   collect($partresult);
            }
            else
            {
                $data           =   parreportModel::getConsolidatereport($jobID);
                foreach($data as $key=>$dta){
                    
                    $data[$key]['query'] = $this->getQueryCountByChapter($dta['CHAPTER_NO'],$bookQuery);
                  
                }
            }
            
            $job                =   jobInfoModel::where('JOB_ID',$jobID)->first();
            $resultofmetadata   =   taskLevelMetadataModel::where('JOB_ID',$jobID)->get();
            $gettotalcolor      =   taskLevelArtMetadataModel::where('JOB_ID',$jobID)->get();
            $getbwcolor         =   $gettotalcolor->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
            $getcolorsillu      =   $gettotalcolor->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
            $chapters           =   $resultofmetadata->pluck('CHAPTER_NO');
            $readapgae          =   Config::get('constants.READ_TYPEOF_PM_FM_EXTENSTION');
            $readfilepart       =   Config::get('constants.READ_TYPEOF_PART');
            $readchapter        =   Config::get('constants.READ_CHAPTER_EXTENSTION');
            $apagecount         =   [];
            $partcount          =   [];
            $chaptercount       =   [];
            $romanpagecount     =   0;
            $arbicpagecount     =   0;
            foreach($chapters as $key=>$jsonvalue)
            {
                if(in_array(substr(strtolower($jsonvalue),0,2),$readapgae))
                {
                    $apagecount[]       =   $jsonvalue;
                }
                if(in_array(substr(strtolower($jsonvalue),0,2),$readfilepart))
                {
                    $partcount[]        =   $jsonvalue;
                }
                if(in_array(substr(strtolower($jsonvalue),0,2),$readchapter))
                {
                    $chaptercount[]     =   $jsonvalue;
                }			
            }
            
//            foreach($data as $key=>$jsonvalue)
//            {
//                if(in_array(substr(strtolower($jsonvalue->CHAPTER_NO),0,2),Config::get('constants.FRONT_MATTER')))
//                {
//                    $romanpagecount     =   ($jsonvalue->SPICAST_TOTALPAGES     ==  null?0:$jsonvalue->SPICAST_TOTALPAGES);
//                }
//                else
//                {
//                    $arbicpagecount     +=   $jsonvalue->SPICAST_TOTALPAGES;
//                }
//            }
//            $data->sum('SPICAST_TOTALPAGES')
            
            
            //check api file upload or not
            $wheredata              =   array('JOB_ID'=>$jobID,'ROUND'=>Config::get('constants.ROUND_ID.S50'),'PROCESS_TYPE'=>Config::get('constants.PROCESS_TYPE'));
            $checkfileupload        =   apiFileUpload::where($wheredata)->latest()->first();
            $fileuploadcount        =   apiFileUpload::where($wheredata)->get()->count();
            /*if(count($checkfileupload)>=1){
                if($checkfileupload->STATUS     ==  3){
                    $response["jobsheetdisptchfile"]    =   0;
                }else{
                    $response["jobsheetdisptchfile"]    =   1;
                }
            }else{
                $response["jobsheetdisptchfile"]    =   0;
            }*/
            //client ack
            $whereclidata           =   array('JOB_ID'=>$jobID,'ROUND'=>Config::get('constants.ROUND_ID.S50'),'PROCESS_TYPE_DIFF'=>Config::get('constants.REVISED_PROCESS_TYPE.RECEIPT'));
            $clientaackstatus       =   apiClientAcknowledgement::where($whereclidata)->latest()->first();

            $wheremeta              =   ['ROUND'=>Config::get('constants.ROUND_ID.S50'),'JOB_ID'=>$jobID , 'PROCESS_TYPE' => 'UPDATE'];
            $updatebuttondtls       =   apiMetaExtractor::where($wheremeta)->orderBy('ID','desc')->first();
            
            $metacount              =   apiMetaExtractor::where($wheremeta)->get()->count();
            /*if(count($updatebuttondtls)>=1)
            {
                if($updatebuttondtls->PROCESS_TYPE  ==  'UPDATE' && $updatebuttondtls->STATUS  ==  2){
                    $response['jobupdatebutton']    =   0;
                    $response['savebutton']         =   0;
                }
                if($updatebuttondtls->PROCESS_TYPE  ==  'UPDATE' && $updatebuttondtls->STATUS  ==  3){
                    $response['jobupdatebutton']    =   1;
                    $response['savebutton']         =   1;
                }
            }else{
                $response['jobupdatebutton']        =   1;
                $response['savebutton']             =   1;
                $response["jobsheetdisptchfile"]    =   1;
            }
            
            if(count($checkfileupload)>=1){
                if($checkfileupload->STATUS     ==  2){
                    $response["jobsheetdisptchfile"]    =   1;
                    $response["jobupdatebutton"]        =   0;
                    $response['savebutton']             =   0;
                }
            }*/
            
            $whereclidata               =   array('JOB_ID'=>$jobID,'ROUND'=>Config::get('constants.ROUND_ID.S50'),'PROCESS_TYPE_DIFF'=>Config::get('constants.PROCESS_TYPE'));
            $clientaackstatusdetails    =   apiClientAcknowledgement::where($whereclidata)->latest()->first();
            $clientaackcount            =   apiClientAcknowledgement::where($whereclidata)->get()->count();
//            
            /*if(count($clientaackstatus)>=1)
            {
                if($clientaackstatus->STATUS     ==  2){
                    $response["jobsheetdisptchfile"]    =   1;
                    $response["jobupdatebutton"]        =   1;
                    $response['savebutton']             =   1;
                }
                if($clientaackstatus->STATUS     ==  3){
                    $response['jobupdatebutton']        =   0;
                    $response["jobsheetdisptchfile"]    =   1;
                    $response['savebutton']             =   0;
                }
            }else{
                $response['jobupdatebutton']        =   0;
                $response['savebutton']             =   0;
                $response["jobsheetdisptchfile"]    =   1;
            }
            
            if(count($clientaackstatusdetails)>=1)
            {
                $response['jobupdatebutton']        =   ($clientaackstatusdetails->STATUS  ==  2?0:1);
                $response['savebutton']             =   ($clientaackstatusdetails->STATUS  ==  2?0:1);
                $response["jobsheetdisptchfile"]    =   ($clientaackstatusdetails->STATUS  ==  2?1:0);
            }*/
          
            // new code for disable and enable button
            if(count($clientaackstatus)>=1)
            {//check dispatched or not 
                if(count($checkfileupload) >=1 && count($clientaackstatusdetails)>=1 && count($updatebuttondtls) >= 1){
                    if(($checkfileupload->STATUS     ==  $this->statusSuccess || $checkfileupload->STATUS     ==  $this->statusInprogress) && ($clientaackstatusdetails->STATUS     ==  $this->statusSuccess || $clientaackstatusdetails->STATUS     ==  $this->statusInprogress) && ($updatebuttondtls->STATUS     ==  $this->statusSuccess || $updatebuttondtls->STATUS     ==  $this->statusInprogress)){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   0;
                        $response['savebutton']             =   0;
                    }else if(($checkfileupload->STATUS     ==  $this->statusFailure || $clientaackstatusdetails->STATUS     ==  $this->statusFailure) && ($updatebuttondtls->STATUS     ==  $this->statusSuccess  || $updatebuttondtls->STATUS     ==  $this->statusInprogress) && $metacount == $clientaackcount) {
                        $response["jobsheetdisptchfile"]    =   0;
                        $response["jobupdatebutton"]        =   0;
                        $response['savebutton']             =   0;
                    }
                    else if(($checkfileupload->STATUS     ==  $this->statusFailure || $clientaackstatusdetails->STATUS     ==  $this->statusFailure) && ($updatebuttondtls->STATUS     ==  $this->statusSuccess  || $updatebuttondtls->STATUS     ==  $this->statusInprogress) && $metacount >= $clientaackcount) {
                        $response["jobsheetdisptchfile"]    =   0;
                        $response["jobupdatebutton"]        =   0;
                        $response['savebutton']             =   0;
                    }else if(($checkfileupload->STATUS     ==  $this->statusFailure || $clientaackstatusdetails->STATUS     ==  $this->statusFailure) && ($updatebuttondtls->STATUS     ==  $this->statusSuccess  || $updatebuttondtls->STATUS     ==  $this->statusInprogress) && $metacount <= $clientaackcount) {
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }
                    else if(($checkfileupload->STATUS     ==  $this->statusSuccess || $checkfileupload->STATUS     ==  $this->statusInprogress) && ($clientaackstatusdetails->STATUS     ==  $this->statusSuccess || $clientaackstatusdetails->STATUS     ==  $this->statusInprogress) && $updatebuttondtls->STATUS     ==  $this->statusFailure){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }else if(($checkfileupload->STATUS     ==  $this->statusFailure || $clientaackstatusdetails->STATUS     ==  $this->statusFailure) && $updatebuttondtls->STATUS     ==  $this->statusFailure){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }else if(($checkfileupload->STATUS     ==  $this->statusSuccess || $checkfileupload->STATUS     ==  $this->statusInprogress) && $clientaackstatusdetails->STATUS     ==  $this->statusFailure && ($updatebuttondtls->STATUS     !=  $this->statusSuccess || $updatebuttondtls->STATUS     !=  $this->statusInprogress)){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }else if($updatebuttondtls->STATUS     ==  $this->statusFailure){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }
                }else if(count($checkfileupload) >= 1 && count($clientaackstatusdetails) == 0 && count($updatebuttondtls) == 0){
                    if($checkfileupload->STATUS     ==  $this->statusFailure){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }
                }else if(count($checkfileupload) == 0 && count($clientaackstatusdetails) == 0 && count($updatebuttondtls) == 0){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                }else if(count($checkfileupload) == 0 && count($clientaackstatusdetails) == 0 && count($updatebuttondtls) >= 1){
                    if($updatebuttondtls->STATUS     ==  $this->statusFailure){
                        $response["jobsheetdisptchfile"]    =   1;
                        $response["jobupdatebutton"]        =   1;
                        $response['savebutton']             =   1;
                    }else{
                        $response['jobupdatebutton']        =   0;
                        $response['savebutton']             =   0;
                        $response["jobsheetdisptchfile"]    =   0;
                    }
                }else{
                    $response['jobupdatebutton']        =   0;
                    $response['savebutton']             =   0;
                    $response["jobsheetdisptchfile"]    =   0;
                }
            }else{
                $response['jobupdatebutton']        =   0;
                $response['savebutton']             =   0;
                $response["jobsheetdisptchfile"]    =   1;
            }
            
            
    //        $resultofpart   =   array(array('CHAPTER_NO'=>'PART1','METADATA_ID'=>2562),array('CHAPTER_NO'=>'PART2','METADATA_ID'=>2563),array('CHAPTER_NO'=>'Chapter_01','METADATA_ID'=>2556));
            $response["parreport"]              =   $data;
            $response["romanpagecount"]         =   (count($job)>=1?$job->NO_ROMAN_PAGES:0);
            $response["arbicpagecount"]         =   (count($job)>=1?$job->NO_ARABIC_PAGES:0);
            $response["totalpagecount"]         =   $response["romanpagecount"]+$response["arbicpagecount"];
            $response["jsmspage"]               =   (count($job)>=1?$job->NO_PAGES:0);
//            $response["jobsheetdisptchfile"]    =   $checkfileexist;
            $response["partlistofchpter"]       =   $resultofpart;
//            $response["apagecount"]             =   count($apagecount);
//            $response["partcount"]              =   count($partcount);
//            $response["chaptercount"]           =   count($chaptercount);
            $response["apagecount"]             =   (count($job)>=1?$job->NO_APAGE_COUNT:0);
            $response["partcount"]              =   (count($job)>=1?$job->NO_PART_COUNT:0);
            $response["chaptercount"]           =   (count($job)>=1?$job->NO_CHAPTER_COUNT:0);
            $response["totalillustration"]      =   count($gettotalcolor);
            $response["bwcolor"]                =   count($getbwcolor);
            $response["colorillustration"]      =   count($getcolorsillu);
            $response["jsmspcount"]             =   round($data->sum('NO_JSMS_PAGES'));
            $response["mspcount"]               =   round($data->sum('NO_MSP'));
            $response["notablecount"]           =   round($data->sum('NO_TABLES'));
            $response["nounnumtablecount"]      =   round($data->sum('NO_TABLES_UNNUMBERED'));
            $response["noequatincount"]         =   round($data->sum('NO_EQUATION'));
            $response["nounnumequatincount"]    =   round($data->sum('NO_EQUATION_UNNUMBERED'));
            $response["nofigurcount"]           =   round($data->sum('FIGURE_COUNT'));
            $response["nonumfigurcount"]        =   round($data->sum('FIGURE_COUNT_NUMBERED'));
            $response["nounnumfigurcount"]      =   round($data->sum('FIGURE_COUNT_UNNUMBERED'));
    //        $response["noarttablecount"]        =   $data->sum('NO_ART_TABLES');
    //        $response["noarttableunnumcount"]   =   $data->sum('NO_ART_TABLES_UNNUMBERED');
            $response["noartfigurecount"]       =   round($data->sum('NO_ART_FIGURES'));
            $response["noartunnumfigurecount"]  =   round($data->sum('NO_ART_FIGURE_UNNUMBERED'));
            $response["noschemescount"]         =   round($data->sum('NO_SCHEMES'));
            $response["nounnumschemescount"]    =   round($data->sum('NO_SCHEME_UNNUMBERED'));
            $response["noartstructurecount"]    =   round($data->sum('NO_ART_STRUCTURE'));
            $response["noartunstructurecount"]  =   round($data->sum('NO_ART_STRUCTURE_UNNUMBERED'));
            $response["noartequtioncount"]      =   round($data->sum('NO_ART_EQUATION'));
            $response["nounnumartequtioncount"] =   round($data->sum('NO_ART_UNNUMBERED_EQUATION'));
            $response["pagebycharcount"]        =   round($data->sum('PAGE_COUNT_BY_CHARACTERS'));
            $response["pagebywordcount"]        =   round($data->sum('PAGE_COUNT_BY_WORDS'));
            $response["spicastpagecount"]       =   round($data->sum('SPICAST_PAGES'));
            $response["spicastartpagecount"]    =   round($data->sum('SPICAST_ARTPAGES'));
            $response["spicastblankpagecount"]  =   round($data->sum('SPICAST_BLANKS'));
            $response["spicasttotalpagecount"]  =   round($data->sum('SPICAST_TOTALPAGES'));
            $response["spicastcucrportcount"]   =   round($data->sum('CUC_REPORT'));
          
            return response()->json($response);
        }
        catch(\Exception $e)
        {
            return response()->json(false);
        }
    }
    
    public function getQueryCountByJob($bookId){
        $curl                    =       Config::get('constants.QMS_JOB_QUERIES_URL').'?TitleAcronym='.$bookId.'&Type=Magnus';
        $data                    =       array( 'BOOK_ID' => $bookId );
        
       
        $cmn_obj                 =       new CommonMethodsController();
        $returns_response        =       json_decode($cmn_obj->getcUrlExecution(  $curl,0 ));
        
        $querychap               =       array();
       
        foreach($returns_response as $key => $data){
          
            if($data->Status == 'Open'){
               $chapters    =    explode(',',$data->Chapters);
             
               foreach($chapters as $chap){
                   if(array_key_exists($chap,$querychap) ){
                       $querychap[$chap] = $querychap[$chap]+1;
                   }else{
                       $querychap[$chap] =  1;
                       
                   }
               }
            }
        }
      return $querychap;
      
    }
    
    public function getQueryCountByChapter($chapter,$bookQuery){
        
        if(array_key_exists($chapter,$bookQuery)){
            return $bookQuery[$chapter];
        }else{
            return 0;
        }
    }
	
    public function updateConsolidatereport(Request $request)
    {
        if($request->isMethod('post') == "POST")
        {
            $jobId          =   $request->input('job_id');
            $chaptercount   =   $request->input('chaptercount');
            $partcount      =   $request->input('partcount');
            $apageobjectcount   =   $request->input('apageobjectcount');
            $romancount     =   $request->input('romancount');
            $arabiccount    =   $request->input('arabiccount');
            if(count($request->input('metaids')))
            {
                $metadata               =   $request->input('metaids');
                $chapters               =   $request->input('chapters');
                $chaptertypesselect     =   $request->input('chaptertypesselect');
                $titleofchpter          =   $request->input('titleofchpter');
                $chaptersequence        =   $request->input('chaptersequence');
                $containesm             =   $request->input('containesm');
                /*if(in_array('',$containesm) || in_array('',$titleofchpter) || in_array('',$chaptersequence) || in_array('0',$chaptersequence)) {
                    $response 	=	array('result'=>400,'msg'=>'ContainsESM or Chapter Title or Chapter Sequence field is required');
                    return response()->json($response,400);
                }*/
                
                /*if($partcount   !=  0){
                    $partcount  =   $partcount+1;
                    if(in_array($partcount,$chaptersequence) || in_array(3,$chaptersequence)){
                        $response 	=	array('result'=>400,'msg'=>'Duplicate seuqnce number is found kindly check it!');
                        return response()->json($response,400);
                    }
                }else{
                    if(in_array(2,$chaptersequence)){
                        $response 	=	array('result'=>400,'msg'=>'Duplicate seuqnce number is found kindly check it!');
                        return response()->json($response,400);
                    }
                }*/
                
                $noofmsp                =   $request->input('noofmsp');
//                $noofjsmsp              =   $request->input('noofjsmsp');
                $nooftables             =   $request->input('nooftables');
                $noofunnumberedtables   =   $request->input('noofunnumberedtables');
                $noofequations          =   $request->input('noofequations');
                $noofunnumberedequations    =   $request->input('noofunnumberedequations');
                $nooffigure             =   $request->input('nooffigure');
                $noofnumberedfigure     =   $request->input('noofnumberedfigure');
                $noofunnumberedfigure   =   $request->input('noofunnumberedfigure');
                $noofartables           =   $request->input('noofartables');
                $noofartunnumberedtables    =   $request->input('noofartunnumberedtables');
                $noofartfigure          =   $request->input('noofartfigure');
                $noofartunnumberedfigure    =   $request->input('noofartunnumberedfigure');
                $noofschemes            =   $request->input('noofschemes');
                $noofnumberedschemes    =   $request->input('noofnumberedschemes');
                $noofartstructure       =   $request->input('noofartstructure');
                $noofartstructureunnumbered     =   $request->input('noofartstructureunnumbered');
                $noofartequations       =   $request->input('noofartequations');
                $noofartunnumberedequations     =   $request->input('noofartunnumberedequations');
                $pagecountbychar        =   $request->input('pagecountbychar');
                $pagecountbyword        =   $request->input('pagecountbyword');
                $noofspicastpages       =   $request->input('noofspicastpages');
                $noofspicastartpages    =   $request->input('noofspicastartpages');
                $noofspicastblankpages  =   $request->input('noofspicastblankpages');
                $noofspicasttotalpages  =   $request->input('noofspicasttotalpages');
                $updateData 		=	taskLevelMetadataModel::updateallConsolidatedetails($jobId,
                                                                                                    $metadata,
                                                                                                    $chapters,
                                                                                                    $chaptertypesselect,
                                                                                                    $titleofchpter,
                                                                                                    $chaptersequence,
                                                                                                    $containesm,
                                                                                                    $noofmsp,
//                                                                                                    $noofjsmsp,
                                                                                                    $nooftables,
                                                                                                    $noofunnumberedtables,
                                                                                                    $noofequations,
                                                                                                    $noofunnumberedequations,
                                                                                                    $nooffigure,
                                                                                                    $noofnumberedfigure,
                                                                                                    $noofunnumberedfigure,
//                                                                                                    $noofartables,
//                                                                                                    $noofartunnumberedtables,
                                                                                                    $noofartfigure,
                                                                                                    $noofartunnumberedfigure,
                                                                                                    $noofschemes,
                                                                                                    $noofnumberedschemes,
                                                                                                    $noofartstructure,
                                                                                                    $noofartstructureunnumbered,
                                                                                                    $noofartequations,
                                                                                                    $noofartunnumberedequations,
                                                                                                    $pagecountbychar,
                                                                                                    $pagecountbyword,
                                                                                                    $noofspicastpages,
                                                                                                    $noofspicastartpages,
                                                                                                    $noofspicastblankpages,
                                                                                                    $noofspicasttotalpages);
                if($updateData)
                {
                    $jobinfo            =   [];
                    $jobinfo['NO_ARABIC_PAGES']     =   $arabiccount;
                    $jobinfo['NO_ROMAN_PAGES']      =   $romancount;
                    $jobinfo['NO_PART_COUNT']       =   $partcount;
                    $jobinfo['NO_APAGE_COUNT']      =   $apageobjectcount;
                    $jobinfo['NO_CHAPTER_COUNT']    =   $chaptercount;
                    $updatejobinfo      =   jobInfoModel::updateJobdata($jobId,$jobinfo);
                    $successfileresponse            =   app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobId,'116','update','chapter','');
                    return response()->json($this->updatedResponse);
                }
                return response()->json($this->updatedFailedResponse,400);
            }
            return response()->json($this->oopsErrorResponse,400);
        }
    }
    
    /* consolidate REPORTS download*/
    public function consolidatereportDownload(Request $request, $projectID = null) 
    {
        $getjobinfo             =   jobModel::where('JOB_ID',$projectID)->first();
        if(count($getjobinfo)>=1){
            $bookid             =   $getjobinfo->BOOK_ID;
            Excel::create('Consolidated Report_'.$bookid, function($excel) use ($projectID,$bookid) 
            {
                    $parreportsitems 	=   array(); 
                    //get consolidate list from tasklevelmeata ,metadata - info table
                    //CHECK PART IS AVAILABLE OR NOT
                    $checkpartavailable     =   taskLevelMetadataModel::getreportofconsolidate("4",$projectID);
                    if(count($checkpartavailable)>=1)
                    {
                        $partresult     =   [];
                        $partincrement  =   0;
                        //get fm record 
                        $getfrontmatter =   taskLevelMetadataModel::getreportofconsolidate("1",$projectID);
                        if(count($getfrontmatter)>=1)
                        {
                            foreach($getfrontmatter     as     $frontdata)
                            {
                                if($frontdata['CHAPTER_NO'] !=  null){
                                    $partresult[$partincrement]  =   $frontdata;
                                    $partincrement++;
                                }
                            }
                        }
                        $partincrement  =   $partincrement;
                        
                        $onlyChapter    =   taskLevelMetadataModel::getChapterWithoutPart($projectID);
                        if(count($onlyChapter)>=1)
                        {
                            foreach($onlyChapter     as     $onlyChapters)
                            {
                                if($onlyChapters['CHAPTER_NO'] !=  null){
                                    $partresult[$partincrement]  =   $onlyChapters;
                                    $partincrement++;
                                }
                            }
                            $partincrement  =   $partincrement;
                        }
            
                        //get part then chapter record 
                        foreach($checkpartavailable     as $partidvalue)
                        {
                            ++$partincrement;
                            $partresult[$partincrement]     =   $partidvalue;
                            $chapterdataresult  =   taskLevelMetadataModel::getchapterlistagainpart($partidvalue->METADATA_ID,$projectID);
                            if(count($chapterdataresult)>=1)
                            {
                                foreach($chapterdataresult  as  $chapterdatavalue)
                                {
                                    if($chapterdatavalue['CHAPTER_NO'] !=  null){
                                        ++$partincrement;
                                        $partresult[$partincrement]     =   $chapterdatavalue;
                                    }
                                }
                            }
                        }
                        //get bm then chapter record 
                        $getbackmatter      =   taskLevelMetadataModel::getreportofconsolidate("3",$projectID);
                        if(count($getbackmatter)>=1)
                        {
                            ++$partincrement;
                            foreach($getbackmatter  as     $backdata)
                            {
                                if($backdata['CHAPTER_NO'] !=  null){
                                    $partresult[$partincrement]  =   $backdata;
                                }
                            }
                        }
                        $parreports         =   collect($partresult);
                        
                    }
                    else
                    {
                        $parreports         =   taskLevelMetadataModel::getMetadatadetailsJob($projectID);
                    }
                    
                    $jobdata                =   jobInfoModel::where('JOB_ID',$projectID)->first();
                    $romanpagecount         =   (count($jobdata)>=1?$jobdata->NO_ROMAN_PAGES:'');
                    $arabicpagecount        =   (count($jobdata)>=1?$jobdata->NO_ARABIC_PAGES:'');
                    $chaptercount           =   '';
                    $partcount              =   '';
                    $apagecount             =   '';
                    $chaptercount           =   (count($jobdata)>=1?$jobdata->NO_CHAPTER_COUNT:'');
                    $partcount              =   (count($jobdata)>=1?$jobdata->NO_PART_COUNT:'');
                    $apagecount             =   (count($jobdata)>=1?$jobdata->NO_APAGE_COUNT:'');
                    $jsmspage               =   (count($jobdata)>=1?$jobdata->NO_PAGES:0);
                    $totalpagecount         =   $romanpagecount+$arabicpagecount;
                    $excel->setTitle('Consolidate Reports_'.$bookid);
                    $excel->setCreator('vinoth')->setCompany('SPi Global');
                    $excel->setDescription('Magnus Springer - Consolidated reports');

                    $excel->sheet($bookid, function($sheet) use ($parreports,$projectID,$bookid,
                            $romanpagecount,
                            $arabicpagecount,
                            $chaptercount,
                            $partcount,
                            $apagecount,
                            $totalpagecount,$jsmspage) 
                    {	
                            $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('H')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('I')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('J')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('K')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('L')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('M')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('N')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('O')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('P')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('Q')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('R')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('S')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('T')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('U')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('V')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('W')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('X')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('Y')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('Z')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('AA')->getAlignment()->setWrapText(true);	
                            $sheet->getStyle('AB')->getAlignment()->setWrapText(true);	
                            $sheet->setWidth(array(
                                                    'A'     =>  5,
                                                    'B'     =>  20,
                                                    'C'     =>  20,
                                                    'D'     =>  20,
                                                    'E'     =>  20,
                                                    'F' 	=>  15,
                                                    'G' 	=>  15,
                                                    'H' 	=>  10,
                                                    'I' 	=>  15,
                                                    'J' 	=>  15,
                                                    'K' 	=>  10,
                                                    'L' 	=>  10,
                                                    'M' 	=>  15,
                                                    'N' 	=>  20,
                                                    'O' 	=>  15,
                                                    'P' 	=>  15,
                                                    'Q' 	=>  15,
                                                    'R' 	=>  15,
                                                    'S' 	=>  15,
                                                    'T' 	=>  15,
                                                    'U' 	=>  15,
                                                    'V' 	=>  15,
                                                    'W' 	=>  15,
                                                    'X' 	=>  15,
                                                    'Y' 	=>  15,
                                                    'Z' 	=>  15,
                                                    'AA' 	=>  15,
                                                    'AB' 	=>  15
                                            ));

                            $sheet->cells('A1:AB1', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);	
                                    $cells->setFontWeight('bold');	
                                    //$cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#fffffc');
                            });

                            //second row start 
                            $sheet->cells('D2:F2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontWeight('bold');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#4784b9');
                            });
                            $sheet->cells('G2:N2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });
                            $sheet->cells('N2:O2', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });
                            $sheet->mergeCells('A2:C2');
                            $sheet->mergeCells('D2:F2');
                            $sheet->mergeCells('L2:M2');
                            $sheet->cell('D2', function($cell) {
                                $cell->setValue('Components Details');
                            });
                            $sheet->cell('G2', function($cell) {
                                $cell->setValue('Chapter Count');
                            });
                            $sheet->setCellValue('I2', $chaptercount);
                            $sheet->cell('J2', function($cell) {
                                $cell->setValue('Part Count');
                            });
                            $sheet->setCellValue('K2', $partcount);
                            $sheet->cell('L2', function($cell) {
                                $cell->setValue('Apage Object Count');
                            });
                            $sheet->setCellValue('N2', $apagecount);
                            $sheet->cell('O2', function($cell) {
                                $cell->setValue('JS MS Pages');
                            });
                            //second row end 
                            //third row start 
                            $sheet->cells('D3:F3', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontWeight('bold');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#4784b9');
                            });
                            $sheet->cells('G3:N3', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });
                            $sheet->cells('N3:O3', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                            });
                            $sheet->mergeCells('A3:C3');
                            $sheet->mergeCells('D3:F3');
                            $sheet->mergeCells('L3:M3');
                            $sheet->cell('D3', function($cell) {
                                $cell->setValue('Page Details');
                            });
                            $sheet->cell('G3', function($cell) {
                                $cell->setValue('Roman Pages');
                            });
                            $sheet->setCellValue('I3', $romanpagecount);
                            $sheet->cell('J3', function($cell) {
                                $cell->setValue('Arabic Pages');
                            });
                            $sheet->setCellValue('K3', $arabicpagecount);
                            $sheet->cell('L3', function($cell) {
                                $cell->setValue('Total Pages');
                            });
                            $sheet->setCellValue('N3', $totalpagecount);
                            $sheet->setCellValue('O3', $jsmspage);
                            //second row end 
                            $sheet->mergeCells('A4:AB4');
                            $sheet->mergeCells('A5:AB5');
                            $sheet->mergeCells('A6:A6');
                            $sheet->mergeCells('B6:AB6');
                            //six row start 
                            $sheet->cells('B6:AB6', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontWeight('bold');	
                                    $cells->setFontSize(14);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#ef970f');
                            });
                            $sheet->row(6, array('',$bookid));
                            $sheet->mergeCells('A4:AB4');
                            $sheet->mergeCells('A5:AB5');
                            $sheet->mergeCells('A6:A6');
                            $sheet->mergeCells('B6:AB6');
                            //SEVENTH row start 
                            $sheet->mergeCells('A7:A7');
                            $sheet->mergeCells('B7:E7');
                            $sheet->mergeCells('F7:F7');
                            $sheet->mergeCells('G7:K7');
                            $sheet->mergeCells('L7:V7');
                            $sheet->mergeCells('W7:X7');
                            $sheet->mergeCells('Y7:AB7');
                            $sheet->cells('A7:A7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#fffffc');
                            });
                            $sheet->cells('B7:E7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#f5f53e');
                            });
                            $sheet->cells('F7:F7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#fffffc');
                            });
                            $sheet->cells('G7:K7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#91a791');
                            });
                            $sheet->cells('L7:V7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#e0bf93');
                            });
                            $sheet->cells('W7:X7', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#4fec55');
                            });
                            $sheet->cells('Y7:AB7', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#fd4532');
                            });
                            $sheet->cell('B7', function($cell) {
                                $cell->setValue('');
                            });
                            $sheet->cell('F7', function($cell) {
                                $cell->setValue('');
                            });
                            $sheet->cell('G7', function($cell) {
                                $cell->setValue('PAR Report');
                            });
                            $sheet->cell('L7', function($cell) {
                                $cell->setValue('ART Work');
                            });
                            $sheet->cell('W7', function($cell) {
                                $cell->setValue('CE Estimate Details');
                            });
                            $sheet->cell('Y7', function($cell) {
                                $cell->setValue('SPICAST');
                            });
                            //SEVENTH row end
                            //eight row start 
                            $sheet->mergeCells('A8:A8');
                            $sheet->mergeCells('H8:I8');
                            $sheet->mergeCells('J8:K8');
                            $sheet->mergeCells('L8:N8');
                            $sheet->mergeCells('O8:P8');
                            $sheet->mergeCells('Q8:R8');
                            $sheet->mergeCells('S8:T8');
                            $sheet->mergeCells('U8:V8');
                            $sheet->mergeCells('W8:X8');
                            $sheet->mergeCells('Y8:AB8');
                            $sheet->cells('B8:F8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#fffffc');
                            });
                            $sheet->cells('G8:K8', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c1f1dd');
                            });
                            $sheet->cells('L8:N8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->cells('O8:P8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->cells('Q8:R8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->cells('S8:T8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->cells('U8:V8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->cells('W8:X8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#f5f53e');
                            });
                            $sheet->cells('Y8:AB8', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#f5f53e');
                            });
                            $sheet->cell('H8', function($cell) {
                                $cell->setValue('Table');
                            });
                            $sheet->cell('J8', function($cell) {
                                $cell->setValue('Equations');
                            });
                            $sheet->cell('L8', function($cell) {
                                $cell->setValue('Figures');
                            });
                            $sheet->cell('O8', function($cell) {
                                $cell->setValue('Tables');
                            });
                            $sheet->cell('Q8', function($cell) {
                                $cell->setValue('Schemes');
                            });
                            $sheet->cell('S8', function($cell) {
                                $cell->setValue('Structure');
                            });
                            $sheet->cell('U8', function($cell) {
                                $cell->setValue('Equations');
                            });
                            //ninth row start 
                            $sheet->cells('B9:D9', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#0b9c39');
                            });
                            $sheet->cells('E9:E9', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#ef970f');
                            });
                            $sheet->cells('F9:F9', function($cells) {
                                    $cells->setFontFamily('Arial');	
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#d0a3f9');
                            });
                            $sheet->cells('G9:K9', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#b2cfd4');
                            });
                            $sheet->cells('L9:V9', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#e685f7');
                            });
                            $sheet->cells('W9:X9', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#4fec55');
                            });
                            $sheet->cells('Y9:AB9', function($cells) {
                                    $cells->setFontFamily('Arial');
                                    $cells->setFontSize(10);
                                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                    $cells->setAlignment('center');
                                    $cells->setValignment('center');
                                    $cells->setBackground('#c5c7c6');
                            });
                            $sheet->row(9, array('','Parts','Chapter Sequence','Chapter Title','ContainsESM','JS MS Pages','Total (MS) Pages',
                                'Tables','Unnumbered Tables','Equations','Unnumbered Equations','No. of Figures','No. of Numbered Figures','No. of Unnumbered Figures',
                                'Table Figures','Unnumbered Table Figures','Schemes','Unnumbered Schemes','Structure','Unnumbered Structure',
                                'Equations','Unnumbered Equations','PageCount By Characters','PageCount By Words','SPICAST Text Pages','SPICAST Art Pages',
                                'SPICAST Blank Pages','SPICAST Total Pages'));

                            $t 		= 	10;
                            if(count($parreports)>=1)
                            {
                                    foreach($parreports as $key=>$parvalue)
                                    {
                                        $readchapter        =   Config::get('constants.READ_CHAPTER_EXTENSTION');
                                        $readfilepart       =   Config::get('constants.READ_TYPEOF_PART');
                                        $readallfile        =   Config::get('constants.READ_TYPEOF_PM_FM_EXTENSTION');
                                        if(in_array(substr(strtolower($parvalue->CHAPTER_NO),0,2),$readchapter))
                                        {
                                            $sheet->cells("B".$t.":AB".$t,function($row)
                                            {
                                                $row->setFontFamily('Arial');
                                                $row->setFontSize(10);	
                                                $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                $row->setBackground('#fffffc');
                                            });	
                                        }
                                        if(in_array(substr(strtolower($parvalue->CHAPTER_NO),0,2),$readfilepart))
                                        {
                                            $sheet->cells("B".$t.":AB".$t,function($row)
                                            {
                                                $row->setFontFamily('Arial');
                                                $row->setFontSize(10);	
                                                $row->setBorder('thin', 'thin', 'thin', 'thin');
                                                $row->setBackground('#c5d1dc');
                                            });	
                                        }
                                        $sheet->row($t, array('',
                                                                                $parvalue->CHAPTER_NO,
                                                                                $parvalue->CHAPTER_SEQ, 
                                                                                $parvalue->CHAPTER_NAME,
                                                                                $parvalue->TYPE_OF_CONTAINESM,
                                                                                $parvalue->NO_JSMS_PAGES,
                                                                                $parvalue->NO_MSP,
                                                                                $parvalue->NO_TABLES,
                                                                                $parvalue->NO_TABLES_UNNUMBERED,
                                                                                $parvalue->NO_EQUATION,
                                                                                $parvalue->NO_EQUATION_UNNUMBERED,
                                                                                $parvalue->FIGURE_COUNT,
                                                                                $parvalue->FIGURE_COUNT_NUMBERED,
                                                                                $parvalue->FIGURE_COUNT_UNNUMBERED,
                                                                                $parvalue->NO_ART_FIGURES,
                                                                                $parvalue->NO_ART_FIGURE_UNNUMBERED,
                                                                                $parvalue->NO_SCHEMES,
                                                                                $parvalue->NO_SCHEME_UNNUMBERED,
                                                                                $parvalue->NO_ART_STRUCTURE,
                                                                                $parvalue->NO_ART_STRUCTURE_UNNUMBERED,
                                                                                $parvalue->NO_ART_EQUATION,
                                                                                $parvalue->NO_ART_UNNUMBERED_EQUATION,
                                                                                $parvalue->PAGE_COUNT_BY_CHARACTERS,
                                                                                $parvalue->PAGE_COUNT_BY_WORDS,
                                                                                $parvalue->SPICAST_PAGES,
                                                                                $parvalue->SPICAST_ARTPAGES,
                                                                                $parvalue->SPICAST_BLANKS,
                                                                                $parvalue->SPICAST_TOTALPAGES
                                                        ));

                                        $t++;
                                    }
                                    $sheet->mergeCells('A'.$t.':A'.$t);
                                    $sheet->mergeCells('B'.$t.':AB'.$t);
                                    $sheet->cells("B".$t.":AB".$t,function($row)
                                    {
                                        $row->setFontFamily('Arial');
                                        $row->setFontSize(10);	
                                        $row->setBorder('thin', 'thin', 'thin', 'thin');
                                        $row->setBackground('#bcf0f3');
                                    });	
                                    $t      =   $t+1;
                                    $sheet->mergeCells('A'.$t.':A'.$t);
                                    $sheet->mergeCells('B'.$t.':AB'.$t);
                                    $sheet->cells("B".$t.":AB".$t,function($row)
                                    {
                                        $row->setFontFamily('Arial');
                                        $row->setFontSize(10);	
                                        $row->setBorder('thin', 'thin', 'thin', 'thin');
                                        $row->setBackground('#bcf0f3');
                                    });
                                    $t      =   $t+1;
                                    $sheet->cells("B".$t.":AB".$t,function($row)
                                    {
                                        $row->setFontFamily('Arial');
                                        $row->setFontSize(10);	
                                        $row->setBorder('thin', 'thin', 'thin', 'thin');
                                        $row->setBackground('#98c4cc');
                                    });	

                                    $sheet->cells('B'.$t.':E'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                            $cells->setAlignment('center');
                                            $cells->setValignment('center');
                                            $cells->setBackground('#c37777');
                                    });

                                    $sheet->cells('F'.$t.':F'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');	
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
    //                                        $cells->setAlignment('center');
    //                                        $cells->setValignment('center');
                                            $cells->setBackground('#d0a3f9');
                                    });
                                    $sheet->cells('G'.$t.':K'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
    //                                        $cells->setAlignment('center');
    //                                        $cells->setValignment('center');
                                            $cells->setBackground('#b2cfd4');
                                    });
                                    $sheet->cells('L'.$t.':V'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
    //                                        $cells->setAlignment('center');
    //                                        $cells->setValignment('center');
                                            $cells->setBackground('#e685f7');
                                    });
                                    $sheet->cells('W'.$t.':X'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
    //                                        $cells->setAlignment('center');
    //                                        $cells->setValignment('center');
                                            $cells->setBackground('#4fec55');
                                    });
                                    $sheet->cells('Y'.$t.':AB'.$t, function($cells) {
                                            $cells->setFontFamily('Arial');
                                            $cells->setFontSize(10);
                                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
    //                                        $cells->setAlignment('center');
    //                                        $cells->setValignment('center');
                                            $cells->setBackground('#c5c7c6');
                                    });
                                    $sheet->row($t, array('','Total','','','',round($parreports->sum('NO_JSMS_PAGES')),round($parreports->sum('NO_MSP')),
                                                                                round($parreports->sum('NO_TABLES')),round($parreports->sum('NO_TABLES_UNNUMBERED')),
                                                                                round($parreports->sum('NO_EQUATION')),round($parreports->sum('NO_EQUATION_UNNUMBERED')),
                                                                                round($parreports->sum('FIGURE_COUNT')),round($parreports->sum('FIGURE_COUNT_NUMBERED')),round($parreports->sum('FIGURE_COUNT_UNNUMBERED')),
                                                                                round($parreports->sum('NO_ART_FIGURES')),round($parreports->sum('NO_ART_FIGURE_UNNUMBERED')),
                                                                                round($parreports->sum('NO_SCHEMES')),round($parreports->sum('NO_SCHEME_UNNUMBERED')),
                                                                                round($parreports->sum('NO_ART_STRUCTURE')),round($parreports->sum('NO_ART_STRUCTURE_UNNUMBERED')),
                                                                                round($parreports->sum('NO_ART_EQUATION')),round($parreports->sum('NO_ART_UNNUMBERED_EQUATION')),
                                                                                round($parreports->sum('PAGE_COUNT_BY_CHARACTERS')),round($parreports->sum('PAGE_COUNT_BY_WORDS')),
                                                                                round($parreports->sum('SPICAST_PAGES')),round($parreports->sum('SPICAST_ARTPAGES')),
                                                                                round($parreports->sum('SPICAST_BLANKS')),round($parreports->sum('SPICAST_TOTALPAGES'))
                                                                            ));
                            }					
                    });			

            })->download('xlsx');
        }
        return response()->json($this->notfoundResponse);
    }
    
    //s5 job sheet view
    public function getJosheetViewInfo(Request $request) 
    {
        try
        {
            $response           =   $this->locationNotFoundResponse;
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $jobId          =   $request->input('jobId');
                $stagename      =   $request->input('stagename');
                $cid            =   $request->input('chapterId');
                //get book id 
                $bookdetaills   =   jobModel::where('JOB_ID',$jobId)->first();
                $bookid         =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $round              =   Config::get('constants.ROUND_NAME')[$stagename];
                $wheredata          =   ['ROUND_ID'=>$round];
                $getjobsheetpath    =   jobsheetViewpathModel::active()->where($wheredata)->first();
                $xmlFilePath        =   "";
                if(count($getjobsheetpath)>=1)
                {
                    $serverDir      =   $getjobsheetpath->JOBSHEET_PATH; 
                    $inp_rep_arr    =   array( 
                                            'BOOK_ID'    =>  $bookid , 
                                            'ROUND_NAME' =>  $stagename,
                                            'CID'        =>  $cid
                                         );
                    $cmn_obj        =   new CommonMethodsController();
                    $serverDir      =   $prepared_path      =       $cmn_obj->arr_key_value_replace( $inp_rep_arr , $serverDir );
                  
                    $serverDirFiles =   $ftpObj->allFiles($serverDir);
                   
                    if(!empty($serverDirFiles)) {
                        foreach($serverDirFiles as $serverDirFile) {
                            $jobsheetpath   =   substr(strrchr($serverDirFile, "/"), 1);
                            if(pathinfo($serverDirFile)['extension'] == 'xml' && strpos($jobsheetpath,$bookid) !==   false) {
                                $xmlFilePath = $serverDirFile;
                            }
                        }
                    }
                }
                
                if($xmlFilePath == '') 
                {
                    $response['errMsg']     =   '<p class="text-center">No XML found.</p>';
                    return response()->json($response);
                }

                $filePath       =   '/' . $xmlFilePath;
                // $filecontent = self::xmlSampleContent();
                $filecontent    =   $ftpObj->get($filePath); // read file content
                $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';
                // LOAD XML FILE CONTENT
                $XML            =   new \DOMDocument(); 
                $XML->loadXML($filecontent);
                // START XSLT 
                $xslt           =   new \XSLTProcessor(); 

                // IMPORT STYLESHEET
                $XSL            =   new \DOMDocument(); 
                $XSL->load( $xslFilePath ); 
                $xslt->importStylesheet( $XSL );
                $response       =   $this->successResponse;
                $response['errMsg']     =   $xslt->transformToXML( $XML );
                $response['xmlcount']   =   strlen($xslt->transformToXML( $XML ));
                return response()->json($response);
            }
            return response()->json($response);
        }
        catch( \Exception $e )
        {           
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response);
        }
    }
    
    public function getfigurecountViewInfo(Request $request)
    {
        $MetadataID         =   $request->input('MetadataID');
        if($request->input('typeoffigure') == "chapter") 
        {
            $response       =   taskLevelArtMetadataModel::getArtChapterwisefigureInfo($MetadataID);
//            $response       =   taskLevelArtMetadataModel::where('METADATA_ID',$MetadataID)->get();
            $result         =   array('result'=>200,'figuredata'=>$response,'chapterfigure'=>1);   
            return response()->json($result);
        }
        $getartinfo         =   taskLevelMetadataModel::getArtfigureInfo($MetadataID);
       
        $onlinetotalcolor   =   $getartinfo->pluck('INPUTCOLOR')->all();
        $printtotalcolor    =   $getartinfo->pluck('OUTPUTCOLOR')->all();
        $onlinebwcolor      =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
        $onlineillu         =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
        $printbwcolor       =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
        $printillu          =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
        $result             =   array('result'=>200,'figuredata'=>$getartinfo,'bookfigure'=>2,
                                        'totalonline'=>count($onlinetotalcolor),'coloronline'=>count($onlineillu),'bwonline'=>count($onlinebwcolor),
                                        'totalprint'=>count($printtotalcolor),'colorprint'=>count($printillu),'bwprint'=>count($printbwcolor),
                                    );   
        return response()->json($result);
        
    }
    
    public function getesmViewInfo(Request $request)
    {
        try {
            $response   =   $this->locationNotFoundResponse;
            $validation = Validator::make($request->all(), [
                        'jodId' => 'required|numeric',
                        'metadataId' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $MetadataID         =   $request->input('metadataId');
            $JobID              =   $request->input('jodId');
            $wheredata          =   ['JOB_ID'=>$JobID,'METADATA_ID'=>$MetadataID];
            $checkexist         =   jobModel::find($JobID);
            if($checkexist){
                $getartinfo         =   metadataEsmModel::Active()->where($wheredata)->get();
                $response       =   $this->successResponse;
                $response['esmchapterlist']     =   $getartinfo;
                return response()->json($response);
            }
            return response()->json($this->notfoundResponse);
        } catch (\Exception $e) {
            return response()->json($response);
        }
        
    }
    
    /* ART FIGURE REPORTS download*/
    public function artFiguredetaisDownloadType(Request $request, $projectID = null,$typeID = null) 
    {
        switch($typeID)
        {
            case 1:
            $this->artFiguredetaisDownload($projectID,$typeID);
            break;
            case 2:
            $this->artFigureQualityanalysisDownload($projectID,$typeID);
            break;
            case 3:
            $this->artFigurecataogueDownload($projectID,$typeID);
            break;
            default:
                echo "Invalid data sending kindly try again";
            break;
        }
    }
    //art Figure details Download
    public function artFiguredetaisDownload($projectID = null,$typeID = null) 
    {
        $getjobtitle                =   jobModel::getJobdetails($projectID);
        $jobbookid                  =   (count($getjobtitle)>=1?$getjobtitle->BOOK_ID:'');
        $jobtitle                   =   (count($getjobtitle)>=1?$getjobtitle->JOB_TITLE:'');
        $jobauthor                  =   (count($getjobtitle)>=1?($getjobtitle->AUTHOR_NAME  ==  ''?$getjobtitle->EDITOR_NAME:$getjobtitle->AUTHOR_NAME):'');
        if(count($getjobtitle)>=1)
        {
            $bookid                 =   $getjobtitle->BOOK_ID;
            Excel::create('Art Figure Reports_'.$jobbookid.'_'.$jobauthor, function($excel) use ($projectID,$getjobtitle,$bookid) 
            {
                $parreportsitems        =   array(); 
                $getartdatainfo         =   taskLevelMetadataModel::getArtfigureillustrationInfo($projectID);
                $getartinfo             =   taskLevelMetadataModel::getArtfigureInfo($projectID);
                $onlinetotalcolor       =   $getartinfo->pluck('INPUTCOLOR')->all();
                $printtotalcolor        =   $getartinfo->pluck('OUTPUTCOLOR')->all();
                $onlinebwcolor          =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
                $onlineillu             =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
                $printbwcolor           =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
                $printillu              =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
                $onlinetotal            =   count($onlinetotalcolor);
                $onlineill              =   count($onlineillu);
                $onlinebw               =   count($onlinebwcolor);
                $printtotal             =   count($printtotalcolor);
                $printill               =   count($printillu);
                $printbw                =   count($printbwcolor);
                $jobauthor              =   (count($getjobtitle)>=1?($getjobtitle->AUTHOR_NAME  ==  ''?$getjobtitle->EDITOR_NAME:$getjobtitle->AUTHOR_NAME):'');
                $jobbookid              =   (count($getjobtitle)>=1?$getjobtitle->BOOK_ID:'');
                $jobbookid              =   strchr($jobbookid,'_',true);
                $constantname           =   '_'.Config::get('constants.ART_CATALOGUE_NAME').'_';
                $authorname             =   $jobauthor.$constantname.$jobbookid;
                $excel->setTitle('Art Figure Reports_'.$jobbookid);
                $excel->setCreator('vinoth')->setCompany('SPi Global');
                $excel->setDescription('Magnus Springer - Art Figure Reports');

                $excel->sheet('Art Figure Reports_'.$jobbookid, function($sheet) use ($getartinfo,$getartdatainfo,$projectID,
                                                                                            $onlinetotal,
                                                                                            $onlineill,
                                                                                            $onlinebw,
                                                                                            $printtotal,
                                                                                            $printill,
                                                                                            $printbw,
                                                                                            $authorname
                                                                                    ) 
                {	
                    $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                    $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
                    $sheet->setWidth(array(
                                            'A'     =>  25,
                                            'B'     =>  20,
                                            'C'     =>  25,
                                            'D'     =>  23,
                                            'E'     =>  23,
                                            'F' 	=>  23,
                                            'G' 	=>  25
                                    ));

                    $sheet->cells('A1:G1', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);	
                            $cells->setFontWeight('bold');	
    //                        $cells->setBorder('thin', 'thin', '', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setBackground('#fffffc');
                    });
                    $sheet->mergeCells('A1:G1');
                    $sheet->setCellValue('A1', 'Total number of Illustrations in online : '.$authorname);
                    //second row start 

                    $sheet->cells('B3:C3', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->cells('D3:E3', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->cells('B4:C4', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->cells('D4:E4', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->cells('B5:C5', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->cells('D5:E5', function($cells) {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setBorder('thin', 'thin', 'thin', 'thin');
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setFontWeight('bold');
                    });
                    $sheet->mergeCells('A2:A2');
                    $sheet->mergeCells('B2:C2');
                    $sheet->mergeCells('D2:E2');
                    //second row end 
                    //third row start 
                    $sheet->mergeCells('A3:A3');
                    $sheet->mergeCells('B3:C3');
                    $sheet->mergeCells('D3:E3');
                    $sheet->setCellValue('B3', 'Total number of Illustrations in online : '.$onlinetotal);
                    $sheet->setCellValue('D3', 'Total number of Illustrations in print : '.$printtotal);
                    //third row END
                    //fourth row start 
                    $sheet->mergeCells('A4:A4');
                    $sheet->mergeCells('B4:C4');
                    $sheet->mergeCells('D4:E4');

                    $sheet->setCellValue('B4', 'Total number of color Illustrations : '.$onlineill);
                    $sheet->setCellValue('D4', 'Total number of color Illustrations : '.$printill);

                    //fourth row END
                    //fifth row start 
                    $sheet->mergeCells('A5:A5');
                    $sheet->mergeCells('B5:C5');
                    $sheet->mergeCells('D5:E5');
                    $sheet->setCellValue('B5', 'Total number of Black/White Illustrations : '.$onlinebw);
                    $sheet->setCellValue('D5', 'Total number of Black/White Illustrations : '.$printbw);
                    //fifth row END
                    $sheet->mergeCells('A6:G6');
                    $sheet->cells('A7:G7', function($cells) 
                    {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#fffffc');
                        $cells->setFontWeight('bold');
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    });
                    $sheet->mergeCells('A7:A7');
                    $sheet->mergeCells('B7:D7');
                    $sheet->mergeCells('E7:G7');
                    $sheet->cell('A7', function($cell) {
                        $cell->setValue('Chapter Number');
                    });
                    $sheet->cell('B7', function($cell) {
                        $cell->setValue('B/W figures');
                    });
                    $sheet->cell('E7', function($cell) {
                        $cell->setValue('Color figures');
                    });

                    //eigth row start 
                    $sheet->cells('A8:G8', function($cells) 
                    {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#dff0d8');
                    });
    //                $columncell     =   ['A','B','C','D','E','F','G'];
    //                $getcolumns     =   $this->setbordercolumn($sheet,$columncell,8);
                    $sheet->row(8, array('','Half tones','Line tone','Line art','Half tones','Line tone','Line art'));

                    $t  = 	9;
                    $gethalftoneonlinesum   =   0;
                    $getlinetoneonlinesum   =   0;
                    $getlineartonlinesum    =   0;
                    $gethalftoneprintsum    =   0;
                    $getlinetoneprintsum    =   0;
                    $getlineartprintsum     =   0;
                    if(count($getartdatainfo)>=1)
                    {
                        foreach($getartdatainfo as $artvalueid)
                        {
                            $getarteachchapterinfo  =   taskLevelArtMetadataModel::where(['METADATA_ID'=>$artvalueid->METADATA_ID])->get();
                            //bw halftone 
                            $gethalftoneonline      =   $getarteachchapterinfo->where('INPUT_MODE','BW-HT')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO')->toArray();
                            $gethalftoneonlinesum   +=   count($getarteachchapterinfo->where('INPUT_MODE','BW-HT')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO'));
                            $halftoneonline         =   "";
                            if(count($gethalftoneonline)>=1)
                            {
                                $halftoneonline     =   implode(',',$gethalftoneonline); 
                            }
                            //bw linetone 
                            $getlinetoneonline      =   $getarteachchapterinfo->where('INPUT_MODE','BW-LT')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO')->toArray();
                            $getlinetoneonlinesum   +=   count($getarteachchapterinfo->where('INPUT_MODE','BW-LT')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO'));
                            $linetoneonline         =   "";
                            if(count($getlinetoneonline)>=1)
                            {
                                $linetoneonline     =   implode(',',$getlinetoneonline); 
                            }
                            //bw lineart 
                            $getlineartonline       =   $getarteachchapterinfo->where('INPUT_MODE','BW-LA')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO')->toArray();
                            $getlineartonlinesum    +=   count($getarteachchapterinfo->where('INPUT_MODE','BW-LA')->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'))->pluck('FIGURE_NO'));
                            $lineartonline          =   "";
                            if(count($getlineartonline)>=1)
                            {
                                $lineartonline      =   implode(',',$getlineartonline); 
                            }

                            //color halftone 
                            $gethalftoneprint       =   $getarteachchapterinfo->where('INPUT_MODE','CL-HT')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO')->toArray();
                            $gethalftoneprintsum    +=   count($getarteachchapterinfo->where('INPUT_MODE','CL-HT')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO'));
                            $halftoneprint          =   "";
                            if(count($gethalftoneprint)>=1)
                            {
                                $halftoneprint      =   implode(',',$gethalftoneprint); 
                            }
                            //color linetone 
                            $getlinetoneprint       =   $getarteachchapterinfo->where('INPUT_MODE','CL-LT')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO')->toArray();
                            $getlinetoneprintsum    +=   count($getarteachchapterinfo->where('INPUT_MODE','CL-LT')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO'));
                            $linetoneprint          =   "";
                            if(count($getlinetoneprint)>=1)
                            {
                                $linetoneprint       =   implode(',',$getlinetoneprint); 
                            }
                            //color lineart 
                            $getlineartprint        =   $getarteachchapterinfo->where('INPUT_MODE','CL-LA')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO')->toArray();
                            $getlineartprintsum     +=   count($getarteachchapterinfo->where('INPUT_MODE','CL-LA')->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'))->pluck('FIGURE_NO'));
                            $lineartprint           =   "";
                            if(count($getlineartprint)>=1)
                            {
                                $lineartprint       =   implode(',',$getlineartprint); 
                            }

                            $sheet->cells("A".$t.":G".$t,function($row)
                            {
                                $row->setFontFamily('Arial');
                                $row->setFontSize(10);	
                                $row->setBorder('thin', 'thin', 'thin', 'thin');
                                $row->setAlignment('center');
                                $row->setValignment('center');
                                $row->setBackground('#fffffc');
                            });	

                            $sheet->row($t, array($artvalueid->CHAPTER_NO,
                                            $halftoneonline,
                                            $linetoneonline,
                                            $lineartonline,
                                            $halftoneprint,
                                            $linetoneprint,
                                            $lineartprint
                                        ));
                            $t++;
                        }
                    }	

                    //last row start 
                    $t  =   $t+1;
                    $sheet->mergeCells('A'.$t.':G'.$t);
                    $t  =   $t+1;
                    $sheet->cells('A'.$t.':G'.$t, function($cells) 
                    {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#dff0d8');
                    });
                    $sheet->row($t, array('Half tone bw','Line tone bw','Line art bw','Half tone color','Line tone color','Line art color','Total'));
                    $t  =   $t+1;
                    $totalsum   =   $gethalftoneonlinesum+$getlinetoneonlinesum+$getlineartonlinesum+$gethalftoneprintsum+$getlinetoneprintsum+$getlineartprintsum;
                    $sheet->cells("A".$t.":G".$t,function($row)
                    {
                        $row->setFontFamily('Arial');
                        $row->setFontSize(10);	
                        $row->setBorder('thin', 'thin', 'thin', 'thin');
                        $row->setAlignment('center');
                        $row->setValignment('center');
                        $row->setBackground('#fffffc');
                    });
                    $sheet->row($t, array($gethalftoneonlinesum,$getlinetoneonlinesum,$getlineartonlinesum,$gethalftoneprintsum,$getlinetoneprintsum,$getlineartprintsum,$totalsum));
                });			
            })->download('xlsx');
        }
        return response()->json($this->notfoundResponse);
    }
    
    /*public function setbordercolumn($sheet,$noofcell,$cellno)
    {
        $returnrow  =   [];
        foreach($noofcell as $value)
        {
            $returnrow[]    =   $$sheet->cells($value.$cellno.":".$value.$cellno,function($row)
                            {
                                $row->setFontFamily('Arial');
                                $row->setFontSize(10);	
                                $row->setBorder('thin', 'thin', 'thin', 'thin');
                                $row->setAlignment('center');
                                $row->setValignment('center');
                                $row->setBackground('#fffffc');
                            });
        }
        return $returnrow;
    }*/
    //art figure Quality analysis download
    public function artFigureQualityanalysisDownload($projectID = null,$typeID = null) 
    {
        $getjobtitle                =   jobModel::getJobdetails($projectID);
        $jobbookid                  =   (count($getjobtitle)>=1?$getjobtitle->BOOK_ID:'');
        $jobtitle                   =   (count($getjobtitle)>=1?$getjobtitle->JOB_TITLE:'');
        $jobauthor                  =   (count($getjobtitle)>=1?($getjobtitle->AUTHOR_NAME  ==  ''?$getjobtitle->EDITOR_NAME:$getjobtitle->AUTHOR_NAME):'');
        Excel::create('Figure Quality Analysis Reports_'.$jobbookid.'_'.$jobauthor, function($excel) use ($projectID,$getjobtitle,$jobbookid,$jobtitle,$jobauthor) 
        {
            $parreportsitems        =   array(); 
            $getartinfo             =   taskLevelMetadataModel::getArtfigurequalityInfo($projectID);
            $dummychapter           =   [];
            foreach($getartinfo as $key=>$parvalue)
            {
                $dummychapter[]     =   (in_array($parvalue->CHAPTER_NO,$dummychapter)?'':$parvalue->CHAPTER_NO);
            }
            
            $getjobtitle            =   jobModel::getJobdetails($projectID);
            $jobbookid              =   (count($getjobtitle)>=1?$getjobtitle->BOOK_ID:'');
            $jobbookid              =   strchr($jobbookid,'_',true);
            $jobtitle               =   (count($getjobtitle)>=1?$getjobtitle->JOB_TITLE:'');
            
            $constantname           =   '_'.Config::get('constants.ART_CATALOGUE_NAME').'_';
            $nameofbookauthor       =   'Author\Title : '.$jobauthor.$constantname.$jobbookid.' \\ '.$jobtitle;
            $authorname             =   $jobauthor.$constantname.$jobbookid;
            $excel->setTitle('Figure Quality Analysis  Reports_'.$jobbookid.'_'.$jobauthor);
            $excel->setCreator('vinoth')->setCompany('SPi Global');
            $excel->setDescription('Magnus Springer - Figure Quality Analysis Reports');
            $excel->sheet(date('Y-m-d').$jobbookid, function($sheet) use ($getartinfo,$excel,$jobtitle,$nameofbookauthor,$projectID,$dummychapter) 
            {	
                $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('H')->getAlignment()->setWrapText(true);	
                $sheet->setWidth(array(
                                        'A'     =>  15,
                                        'B'     =>  20,
                                        'C'     =>  20,
                                        'D'     =>  20,
                                        'E'     =>  20,
                                        'F' 	=>  20,
                                        'G' 	=>  40,
                                        'H' 	=>  20
                                ));
                $sheet->mergeCells('A1:H1');
                $sheet->cells('A1:H1', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#CACFD2');
                });
                $sheet->row(1, array($nameofbookauthor));
                //second row start 
                $sheet->mergeCells('A2:H2');
                $sheet->cells('A2:H2', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontWeight('bold');	
                        $cells->setFontSize(10);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#CACFD2');
                });
                $sheet->row(2, array('Figure Quality Analysis Report'));
                //third row start 
                $sheet->cells('A3:H3', function($cells) 
                {
                    $cells->setFontFamily('Arial');
                    $cells->setFontSize(10);
                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
                    $cells->setAlignment('center');
                    $cells->setValignment('center');
                });
                
                
                $sheet->row(3, array('Chapter No','Figure No','From Previous Edn','Task','Complexity level','Figure mode','Remarks',
                    'Feedback from Springer'));
                $t  = 	4;
                if(count($getartinfo)>=1)
                {
                    foreach($getartinfo as $key=>$parvalue)
                    {
                        $sheet->cells("A".$t.":A".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("B".$t.":B".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("C".$t.":C".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("D".$t.":D".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("E".$t.":E".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("F".$t.":F".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("G".$t.":G".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });	
                        $sheet->cells("H".$t.":H".$t,function($row)
                        {
                            $row->setFontFamily('Arial');
                            $row->setFontSize(10);	
                            $row->setBorder('thin', 'thin', 'thin', 'thin');
                            $row->setBackground('#fffffc');
                        });
                        
                        $sheet->row($t, array(
                                        $dummychapter[$key],
                                        $parvalue->FIGURE_ID, 
                                        '',
                                        $parvalue->WORK_INVOLVED,
                                        $parvalue->COMPLEXITY,
                                        $parvalue->FIGURE_FULL_MODE,
                                        $parvalue->REMARKS,
                                        ''
                                    ));
                        $t++;
                        $avoidduplicatechapter  =   "";
                    }
                }					
            });			
        })->download('xlsx');
    }
    
    //art figure catlogue download
    public function artFigurecataogueDownload($projectID = null,$typeID = null) 
    {
        $getjobtitle                =   jobModel::getJobdetails($projectID);
        $jobbookid                  =   (count($getjobtitle)>=1?$getjobtitle->BOOK_ID:'');
        $jobtitle                   =   (count($getjobtitle)>=1?$getjobtitle->JOB_TITLE:'');
        Excel::create('Art Catalogue Reports_'.$jobbookid.'_'.$jobtitle, function($excel) use ($projectID,$getjobtitle,$jobbookid,$jobtitle) 
        {
            $parreportsitems        =   array(); 
            $getartinfo             =   taskLevelMetadataModel::getArtfigurecatlogueInfo($projectID);
            $getfiguredetails       =   taskLevelMetadataModel::getSpicastInfo($projectID);
            $getfigurecountdata     =   taskLevelArtMetadataModel::select(DB::raw('count(*) as totalfigures'))->where('JOB_ID',$projectID)->get();
            $noofartfigures         =   (count($getfigurecountdata)>=1?$getfigurecountdata[0]->totalfigures:0);
            $noofcastoff            =   $getfiguredetails->sum('SPICAST_TOTALPAGES');
            $imagename              =   base_path('/assets/dist/img/spi-global.png');
            $jobauthor              =   (count($getjobtitle)>=1?($getjobtitle->AUTHOR_NAME  ==  ''?$getjobtitle->EDITOR_NAME:$getjobtitle->AUTHOR_NAME):'');
            $jobbookid              =   strchr($jobbookid,'_',true);
            $jobisbn                =   (count($getjobtitle)>=1?$getjobtitle->ISSN_ONLINE:'');
            $jobreceiveddate        =   (count($getjobtitle)>=1?$getjobtitle->CREATED_DATE:'');
            $layoutname             =   (count($getjobtitle)>=1?$getjobtitle->FORMAT_TRIM_SIZE:'');
            $constantname           =   '_'.Config::get('constants.ART_CATALOGUE_NAME').'_';
            $nameofbookauthor       =   'Author\Title : '.$jobauthor.$constantname.$jobbookid.' \\ '.$jobtitle;
            $authorname             =   $jobauthor.$constantname.$jobbookid;
            $jobreceiveddate        =   Carbon::parse($jobreceiveddate)->toFormattedDateString();
            $excel->setTitle($jobbookid.'-Art Catalogue Reports_'.$jobbookid.'_'.$jobtitle);
            $excel->setCreator('vinoth')->setCompany('SPi Global');
            $excel->setDescription('Magnus Springer - Art Catalogue Reports');
            $excel->sheet('Title-Info ', function($sheet) use ($getartinfo,$projectID,$nameofbookauthor,$authorname,$layoutname,$imagename,$jobtitle,$jobisbn,$jobreceiveddate,$noofartfigures,$noofcastoff) 
            {	
                $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('H')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('I')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('J')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('K')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('L')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('M')->getAlignment()->setWrapText(true);	
                $sheet->getStyle('N')->getAlignment()->setWrapText(true);	
                $sheet->setWidth(array(
                                        'A'     =>  25,
                                        'B'     =>  20,
                                        'C'     =>  15,
                                        'D'     =>  15,
                                        'E'     =>  5,
                                        'F' 	=>  5,
                                        'G' 	=>  5,
                                        'H' 	=>  5,
                                        'I' 	=>  5,
                                        'J' 	=>  5,
                                        'K' 	=>  5,
                                        'L' 	=>  5,
                                        'M' 	=>  5,
                                        'N' 	=>  20
                                ));
                $sheet->mergeCells('A1:N1');
                $sheet->cells('A1:N1', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#fffffc');
                });

                //second row start 
                $sheet->mergeCells('A2:M2');
                $sheet->mergeCells('N2:N2');
                $sheet->cells('A2:M2', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontWeight('bold');	
                        $cells->setFontSize(12);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#c1dbf7');
                });
                $objDrawing = new \PHPExcel_Worksheet_Drawing;
                $objDrawing->setPath($imagename); //your image path
                $objDrawing->setCoordinates('N2');
                $objDrawing->setWorksheet($sheet);
                $sheet->row(2, array('ART CATALOGUE'));
                //second row end 
                //third row start 
                $sheet->mergeCells('A3:M3');
                $sheet->cells('A3:M3', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontWeight('bold');	
                        $cells->setFontSize(12);
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#c1dbf7');
                });
                $sheet->row(3, array($nameofbookauthor));
                //third row END
                //fourth row start 
                $sheet->mergeCells('A4:M4');
                $sheet->cells('A4:M4', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(4, array('Title Information'));
                //fourth row END
                //fifth row start 
                $sheet->mergeCells('A5:A5');
                $sheet->mergeCells('B5:N5');
                $sheet->cells('A5:A5', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A5:N5', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(5, array('Author',$authorname));
                //fifth row END
                //six row start 
                $sheet->mergeCells('A6:N6');
                $sheet->cells('A6:N6', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //seventh row start 
                $sheet->mergeCells('A7:A7');
                $sheet->mergeCells('B7:N7');
                $sheet->cells('A7:A7', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A7:N7', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(7, array('Title',$jobtitle));
                //eigth row start 
                $sheet->mergeCells('A8:N8');
                $sheet->cells('A8:N8', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //nineth row start 
                $sheet->mergeCells('A9:A9');
                $sheet->mergeCells('B9:N9');
                $sheet->cells('A9:A9', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A9:N9', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(9, array('Received On',$jobreceiveddate));
                //tenth row start 
                $sheet->mergeCells('A10:N10');
                $sheet->cells('A10:N10', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //leventh row start 
                $sheet->mergeCells('A11:A11');
                $sheet->mergeCells('B11:N11');
                $sheet->cells('A11:A11', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A11:N11', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(11, array('ISBN',$jobisbn));
                //twelth row start 
                $sheet->mergeCells('A12:N12');
                $sheet->cells('A12:N12', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //thirenth row start 
                $sheet->mergeCells('A13:A13');
                $sheet->mergeCells('B13:N13');
                $sheet->cells('A13:A13', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A13:N13', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(13, array('Layout',$layoutname));
                //fourytenth row start 
                $sheet->mergeCells('A14:N14');
                $sheet->cells('A14:N14', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //fiftytenth row start 
                $sheet->mergeCells('A15:A15');
                $sheet->mergeCells('B15:N15');
                $sheet->cells('A15:A15', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A15:N15', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(15, array('Total Figures',$noofartfigures));
                //sixtyth row start 
                $sheet->mergeCells('A16:N16');
                $sheet->cells('A16:N16', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
                //seventyth row start 
                $sheet->mergeCells('A17:A17');
                $sheet->mergeCells('B17:N17');
                $sheet->cells('A17:A17', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->cells('A17:N17', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('left');
                        $cells->setValignment('left');
                        $cells->setBackground('#fffffc');
                });
                $sheet->row(17, array('Castoff Pages',$noofcastoff));
                //eightyth row start 
                $sheet->mergeCells('A18:N18');
                $sheet->cells('A18:N18', function($cells) {
                        $cells->setFontFamily('Arial');
                        $cells->setFontSize(10);	
                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
                        $cells->setFontWeight('bold');	
                        $cells->setAlignment('center');
                        $cells->setValignment('center');
                        $cells->setBackground('#cac8c8');
                });
            });	
            //iteration sheet
            //chapterwise export seprate sheet
            if(count($getartinfo)>=1)
            {
                $chapternaame   =   '';
                foreach($getartinfo as $key=>$chaptervalues)
                {   
                    $getartchapterinfo      =   taskLevelMetadataModel::getArtfigurecatloguechapterInfo($projectID,$chaptervalues->METADATA_ID);
                    $chapternaame           =   $chaptervalues->CHAPTER_NO;
                    $excel->sheet($chaptervalues->CHAPTER_NO, function($sheet) use ($getartchapterinfo,$projectID,$nameofbookauthor,$chapternaame) 
                    {	
                        $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('H')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('I')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('J')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('K')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('L')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('M')->getAlignment()->setWrapText(true);	
                        $sheet->getStyle('N')->getAlignment()->setWrapText(true);	
                        $sheet->setWidth(array(
                                                'A'     =>  15,
                                                'B'     =>  15,
                                                'C'     =>  15,
                                                'D'     =>  15,
                                                'E'     =>  15,
                                                'F' 	=>  10,
                                                'G' 	=>  10,
                                                'H' 	=>  10,
                                                'I' 	=>  10,
                                                'J' 	=>  10,
                                                'K' 	=>  10,
                                                'L' 	=>  10,
                                                'M' 	=>  10,
                                                'N' 	=>  50
                                        ));
                        $sheet->mergeCells('A1:N1');
                        $sheet->cells('A1:N1', function($cells) {
                                $cells->setFontFamily('Arial');
                                $cells->setFontSize(10);	
                                $cells->setFontWeight('bold');	
                                $cells->setAlignment('center');
                                $cells->setValignment('center');
                                $cells->setBackground('#c1dbf7');
                        });
                        $sheet->row(1, array('ART CATALOGUE'));
                        //second row start 
                        $sheet->mergeCells('A2:N2');
                        $sheet->cells('A2:N2', function($cells) {
                                $cells->setFontFamily('Arial');
                                $cells->setFontWeight('bold');	
                                $cells->setFontSize(10);
                                $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                $cells->setAlignment('center');
                                $cells->setValignment('center');
                                $cells->setBackground('#c1dbf7');
                        });
                        $sheet->row(2, array($nameofbookauthor));

                        $sheet->mergeCells('A3:N3');
                        $sheet->cells('A3:N3', function($cells) {
                                $cells->setFontFamily('Arial');
                                $cells->setFontWeight('bold');	
                                $cells->setFontSize(10);
                                $cells->setBorder('thin', 'thin', 'thin', 'thin');
                                $cells->setAlignment('left');
                                $cells->setValignment('left');
                                $cells->setBackground('#fffffc');
                        });
                        $sheet->row(3, array('Chapter Number : '.$chapternaame));
                        $sheet->cells('A4:N4', function($cells) 
                        {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setBackground('#c1dbf7');
                        });
                        $sheet->cell("K4:L4", function($cells) {
                            $cells->setBorder('none', 'thin', 'thin', 'thin');
                        });
                        $sheet->cell("A4:A4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("B4:B4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("C4:C4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("D4:D4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("E4:E4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("F4:F4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("G4:G4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("H4:H4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("I4:I4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("J4:J4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("M4:M4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("N4:N4", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->row(4, array('','','','','','','','','','','File Formats','','',''));

                        $sheet->cell("A5:A5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("B5:B5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("C5:C5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("D5:D5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("E5:E5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("F5:F5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("G5:G5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("H5:H5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("I5:I5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("J5:J5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("K5:K5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("L5:L5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("M5:M5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cell("N5:N5", function($cells) {
                            $cells->setBorder('none', 'thin', 'none', 'none');
                        });
                        $sheet->cells('A5:N5', function($cells) 
                        {
                            $cells->setFontFamily('Arial');
                            $cells->setFontSize(10);
                            $cells->setAlignment('center');
                            $cells->setValignment('center');
                            $cells->setBackground('#c1dbf7');
                        });
                        $sheet->row(5, array('Figure ID','From Previous Edition','Task','Complexity level','Figure mode','Input Color','Output Color','Hardcopy','E-file','Replacement files',
                            'Input','Output','Resolution','Remarks/Issues'));

                        $t  = 	6;
                        if(count($getartchapterinfo)>=1)
                        {
                            foreach($getartchapterinfo as $key=>$parvalue)
                            {
                                $sheet->cells("A".$t.":A".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("B".$t.":B".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("C".$t.":C".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("D".$t.":D".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("E".$t.":E".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("F".$t.":F".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("G".$t.":G".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("H".$t.":H".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("I".$t.":I".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("J".$t.":J".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("K".$t.":K".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("L".$t.":L".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("M".$t.":M".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });	
                                $sheet->cells("N".$t.":N".$t,function($row)
                                {
                                    $row->setFontFamily('Arial');
                                    $row->setFontSize(10);	
                                    $row->setBorder('thin', 'thin', 'thin', 'thin');
                                    $row->setBackground('#fffffc');
                                });
                                $splitname[0]   =   '';
                                $splitname[1]   =   '';
                                if(strpos($parvalue->FILE_NAME,'.') !== false)
                                {
                                    $splitname  =   explode('.',$parvalue->FILE_NAME);
                                }
                                $sheet->row($t, array($parvalue->FIGURE_ID,
                                                '',
                                                $parvalue->WORK_INVOLVED,
                                                $parvalue->COMPLEXITY,
                                                $parvalue->FIGURE_FULL_MODE,
                                                $parvalue->INPUTCOLOR,
                                                $parvalue->OUTPUTCOLOR,
                                                '',
                                                '',
                                                '',
                                                $parvalue->INPUT_FILE,
                                                $parvalue->INPUT_FILE, //$splitname[1]
                                                '',
                                                $parvalue->REMARKS
                                            ));
                                $t++;
                            }
                        }					
                    });	
                }
            }
        })->download('xlsx');
    }
    
    
//    public function artFiguredetaisDownload($projectID = null,$typeID = null) 
//    {
//        Excel::create('Art Figure Reports_'.date('Ymd'), function($excel) use ($projectID) 
//        {
//            $parreportsitems        =   array(); 
//            $getartinfo             =   taskLevelMetadataModel::getArtfigureInfo($projectID);
//            $onlinetotalcolor       =   $getartinfo->pluck('INPUTCOLOR')->all();
//            $printtotalcolor        =   $getartinfo->pluck('OUTPUTCOLOR')->all();
//            $onlinebwcolor          =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
//            $onlineillu             =   $getartinfo->where('INPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
//            $printbwcolor           =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.BW'));
//            $printillu              =   $getartinfo->where('OUTPUTCOLOR',Config::get('constants.COLOR_MODE.Color'));
//            $onlinetotal            =   count($onlinetotalcolor);
//            $onlineill              =   count($onlineillu);
//            $onlinebw               =   count($onlinebwcolor);
//            $printtotal             =   count($printtotalcolor);
//            $printill               =   count($printillu);
//            $printbw                =   count($printbwcolor);
//            $excel->setTitle('Art Figure Reports_'.date('Y-m-d'));
//            $excel->setCreator('vinoth')->setCompany('SPi Global');
//            $excel->setDescription('Magnus Springer - Art Figure Reports');
//
//            $excel->sheet('Art Figure Reports_'.date('Y-m-d'), function($sheet) use ($getartinfo,$projectID,
//                                                                                        $onlinetotal,
//                                                                                        $onlineill,
//                                                                                        $onlinebw,
//                                                                                        $printtotal,
//                                                                                        $printill,
//                                                                                        $printbw
//                                                                                ) 
//            {	
//                $sheet->getStyle('A')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('B')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('C')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('D')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('E')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('F')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('G')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('H')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('I')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('J')->getAlignment()->setWrapText(true);	
//                $sheet->getStyle('K')->getAlignment()->setWrapText(true);	
//                $sheet->setWidth(array(
//                                        'A'     =>  5,
//                                        'B'     =>  20,
//                                        'C'     =>  15,
//                                        'D'     =>  20,
//                                        'E'     =>  15,
//                                        'F' 	=>  15,
//                                        'G' 	=>  15,
//                                        'H' 	=>  15,
//                                        'I' 	=>  15,
//                                        'J' 	=>  15,
//                                        'K' 	=>  20
//                                ));
//
//                $sheet->cells('A1:K1', function($cells) {
//                        $cells->setFontFamily('Arial');
//                        $cells->setFontSize(10);	
//                        $cells->setFontWeight('bold');	
//                        $cells->setAlignment('center');
//                        $cells->setValignment('center');
//                        $cells->setBackground('#fffffc');
//                });
//                $sheet->cell('D1', function($cell) {
//                    $cell->setValue('BOOK LEVEL');
//                });
//
//                //second row start 
//                $sheet->cells('B2:E2', function($cells) {
//                        $cells->setFontFamily('Arial');
//                        $cells->setFontWeight('bold');	
//                        $cells->setFontSize(10);
//                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
//                        $cells->setAlignment('center');
//                        $cells->setValignment('center');
//                        $cells->setBackground('#e6a7e4');
//                });
//                $sheet->cells('G2:J2', function($cells) {
//                        $cells->setFontFamily('Arial');
//                        $cells->setFontSize(10);
//                        $cells->setBorder('thin', 'thin', 'thin', 'thin');
//                        $cells->setAlignment('center');
//                        $cells->setValignment('center');
//                        $cells->setBackground('#e6a7e4');
//                });
//                $sheet->mergeCells('A2:A2');
//                $sheet->mergeCells('B2:C2');
//                $sheet->mergeCells('D2:E2');
//                $sheet->mergeCells('G2:H2');
//                $sheet->mergeCells('I2:J2');
//                $sheet->cell('B2', function($cell) {
//                    $cell->setValue('Illustrations Details - Online');
//                });
//                $sheet->cell('G2', function($cell) {
//                    $cell->setValue('Illustrations Details - Print');
//                });
//                //second row end 
//                //third row start 
//                $sheet->mergeCells('A3:A3');
//                $sheet->mergeCells('B3:C3');
//                $sheet->mergeCells('D3:E3');
//                $sheet->mergeCells('G3:H3');
//                $sheet->mergeCells('I3:J3');
//                $sheet->cell('B3', function($cell) {
//                    $cell->setValue('Total number of Illustrations in online');
//                });
//                $sheet->setCellValue('D3', $onlinetotal);
//                $sheet->cell('G3', function($cell) {
//                    $cell->setValue('Total number of Illustrations in print');
//                });
//                $sheet->setCellValue('I3', $printtotal);
//                //third row END
//                //fourth row start 
//                $sheet->mergeCells('A4:A4');
//                $sheet->mergeCells('B4:C4');
//                $sheet->mergeCells('D4:E4');
//                $sheet->mergeCells('G4:H4');
//                $sheet->mergeCells('I4:J4');
//                $sheet->cell('B4', function($cell) {
//                    $cell->setValue('Total number of color Illustrations');
//                });
//                $sheet->setCellValue('D4', $onlineill);
//                $sheet->cell('G4', function($cell) {
//                    $cell->setValue('Total number of Black/White Illustrations');
//                });
//                $sheet->setCellValue('I4', $printill);
//                //fourth row END
//                //fifth row start 
//                $sheet->mergeCells('A5:A5');
//                $sheet->mergeCells('B5:C5');
//                $sheet->mergeCells('D5:E5');
//                $sheet->mergeCells('G5:H5');
//                $sheet->mergeCells('I5:J5');
//                $sheet->cell('B5', function($cell) {
//                    $cell->setValue('Total number of color Illustrations');
//                });
//                $sheet->setCellValue('D5', $onlinebw);
//                $sheet->cell('G5', function($cell) {
//                    $cell->setValue('Total number of Black/White Illustrations');
//                });
//                $sheet->setCellValue('I5', $printbw);
//                //fifth row END
//                $sheet->mergeCells('A6:K6');
//                $sheet->mergeCells('A7:A7');
//                $sheet->cells('B7:K7', function($cells) 
//                {
//                    $cells->setFontFamily('Arial');
//                    $cells->setFontSize(10);	
//                    $cells->setFontWeight('bold');	
//                    $cells->setAlignment('center');
//                    $cells->setValignment('center');
//                    $cells->setBackground('#fffffc');
//                });
//                $sheet->cell('D7', function($cell) {
//                    $cell->setValue('CHAPTER LEVEL');
//                });
//                //ninth row start 
//                $sheet->mergeCells('A8:A8');
//                $sheet->cells('B8:K8', function($cells) 
//                {
//                    $cells->setFontFamily('Arial');
//                    $cells->setFontSize(10);
//                    $cells->setBorder('thin', 'thin', 'thin', 'thin');
//                    $cells->setAlignment('center');
//                    $cells->setValignment('center');
//                    $cells->setBackground('#dff0d8');
//                });
//                $sheet->row(8, array('','Chapter Name','Art Name','File','Type','Complexity','Mode',
//                    'Work Involved','Input Color Mode','Output Color Mode','Remarks'));
//
//                $t  = 	9;
//                if(count($getartinfo)>=1)
//                {
//                    foreach($getartinfo as $key=>$parvalue)
//                    {
//                        $sheet->cells("B".$t.":K".$t,function($row)
//                        {
//                            $row->setFontFamily('Arial');
//                            $row->setFontSize(10);	
//                            $row->setBorder('thin', 'thin', 'thin', 'thin');
//                            $row->setBackground('#fffffc');
//                        });	
//                        $sheet->row($t, array('',
//                                        $parvalue->CHAPTER_NO,
//                                        $parvalue->FILE_NAME, 
//                                        $parvalue->INPUT_FILE,
//                                        $parvalue->FIGURE_TYPE,
//                                        $parvalue->COMPLEXITY,
//                                        $parvalue->INPUT_MODE,
//                                        $parvalue->WORK_INVOLVED,
//                                        $parvalue->INPUTCOLOR,
//                                        $parvalue->OUTPUTCOLOR,
//                                        $parvalue->REMARKS
//                                    ));
//                        $t++;
//                    }
//                }					
//            });			
//        })->download('xlsx');
//    }
}