<?php

    namespace App\Http\Controllers\location;

    use App\Http\Controllers\Controller;
    use App\Models\projectModel;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Redirect;
    use Session;
    use Validator;
    use PDF;
    use DB; 
    use Illuminate\Http\Response;
    use Excel;
    
    class locationController extends Controller
    {
        public function __construct() {
            parent::__construct();
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
        
        public function index(){
             
            $data= array();
            $data['pageTitle'] = 'Location';
            $data['pageName']  = 'Location Information';
            $data['user_name'] =  Session::get('users')['user_name'];
            $data['role_name'] =  Session::get('users')['role_name'];
            return view('location.location-list')->with($data);
            
        }
        
        public function insert( Request $request ){
             
            $rules['manager_id']        =       'required';
            $rules['location']          =       'required';
//            $rules['production_area']   =       'required';
            $response                   =   $this->oopsErrorResponse;
            $response['errormsg']       =       'danger';
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['errMsg']      =       'Required field validation error occured.';
                
            }else{
                
                $in_data                             =       array();
                $in_data['LOCATION_NAME']            =       $request->input( 'location' );
//                $in_data['PRODUCTION_AREA']          =       $request->input( 'production_area' );
                $in_data['ACCOUNT_MANAGER_ID']       =       $request->input( 'manager_id' );
                $in_data['STATUS']                   =       1;
                $in_data['CREATED_DATE']             =       date('Y-m-d H:i:s');
                $user_info                           =       ( $request->session()->get('users') );
                $in_data['CREATED_BY']               =       $user_info['user_id'];
               
                try{
                    
                    $insertId   =    DB::table('am_location_mapping')->insertGetId( $in_data );
                    $response   =   $this->insertedResponse;
                    $response['errormsg']       =       'success';
                }catch( \Exception $e ){                  
                    
                }
            }
            
            echo json_encode( $response );
        }  

        public function getList( Request $request ){
                      
            $response       =       array();
            
            $response['location']       =   \App\Models\locationModel::getLocationList();
            
            echo json_encode( $response , true);
            
        }          

        public function getListWithAmDetails( Request $request ){
            
            $response       =       array();
            $response['locationAm']     = \App\Models\locationModel::getListWithAmDetails();
            echo json_encode( $response , true );
            
        }
        
        public function getListWithpmDetails( Request $request ){
            
            $response       =       array();
            $response['locationAm']     = \App\Models\locationModel::getListWithPmDetails();
            echo json_encode( $response , true );
            
        }
        
        public function getProductionArea(){
            
            $response       =       array();
            $getData        =       \App\Models\locationModel::getProductionAreaList();
            
            $i  =   1;
            
            foreach( $getData as $key => $value ){
                
                $response[$key]['LOCATION_NAME']       =   $value;
                $response[$key]['ID']       =       $i;
                $i++;
                
            }
            
            echo json_encode( $response );
            
        }
        
        public function delete( Request $request ){
            
            $rowid          =       $request->input( 'ID' );
            $statusid       =       $request->input( 'STATUSID' );
            $rules['ID']                =       'required';
            $rules['STATUSID']          =       'required';
            $response                   =   $this->failedResponse;
            $response['errormsg']       =       'danger';
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['msg']      =       'Required field validation error occured.';
                
            }else{
                $response               =   $this->updatedResponse;
                $response['errormsg']   =   'success';
                $deletedmsg     = \App\Models\locationModel::deleteAmLocation( $rowid ,$statusid);
            }
            return response()->json($response); 		
        }
        
        public function update( Request $request ){
            
            $inpArray = array();
            $rules['ID']                =       'required';
            $rules['location']          =       'required';
//            $rules['productionArea']    =       'required';
            $rules['userroleid']        =       'required';
            $response                   =   $this->failedResponse;
            $response['errormsg']       =       'danger';
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['msg']      =       'Required field validation error occured.';
                
            }else{                

                $inpArray['ID']              =   $request->input('ID');	
                $inpArray['LOCATION_NAME']    =   $request->input('location');	
//                $inpArray['PRODUCTION_AREA']   =   $request->input('productionArea');	
                $inpArray['ACCOUNT_MANAGER_ID']     =   $request->input('userroleid');	
                $user_info                           =       ( $request->session()->get('users') );
                $inpArray['user_id']        =   $user_info['user_id'];
                $response                   =   $this->updatedResponse;
                $response['errormsg']       =   'success';
                $updated            = \App\Models\locationModel::updateLocation( $inpArray );     
            }
            return response()->json($response); 		   
        }
    }