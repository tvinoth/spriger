<?php
namespace App\Http\Controllers\cucprocess;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\projectModel;
use App\Models\fileHandler;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\bookinfoModel;
use App\Models\ApiDownloadModel;
use App\Models\jobStage;
use App\Models\spicastProfileModel;
use App\Models\apiCucbackgroundprocessModel;
use App\Models\jobTimeSheet;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\Api\productionFileTransferController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Log;
use Config;

class cucProcessController extends Controller
{
    
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function index()
    {
	$data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUC'),$data);
        $data['pageTitle']  = 	'CUC';
        $data['pageName']   =   'CUC';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data["userId"]     =   $this->loginUserId;
        return view('cucprocess.cuc-index')->with($data);
    }
    
    public function getCuclist(Request $request,$jobID)
    {
        $data               =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.CUC'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $bookdata           =   jobModel::find($jobID);
        if(empty($bookdata)){
            return redirect('cucprocess-list');
        }
        $data['pageName']   =   'CUC - '.$bookdata->BOOK_ID;
        $data['jobid']      =   $jobID;
        $data['backurl']        =   url('/').'/cucprocess-list';
        // check already requested for raw download
        $this->displayRawfileButton($jobID,$data);
        return view('cucprocess.cuc-checkout')->with($data);
    }
    
    public function getCucjoblist(Request $request)
    {
        $Req            =   (object) $request->input();
       
        $orderColumn    =   3; //created date column
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn    =   $Req->order[0]['column'];
        }

        $sorting        =   'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting    =   $Req->order[0]['dir'];
        }
            
        $start  =   '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start      =   $Req->start;
        }

        $length     =   false;
        if (isset($Req->length) && $Req->length != -1) {
            $length =   $Req->length;
        }

        $searchStr  =   '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr  =   trim($Req->search['value']);
        }
        
        $response               =   [];
        $data                   =   bookinfoModel::getCucBookinfo($start,$length,$searchStr,$orderColumn,$sorting);
        $bookdata               =   array();
        if(isset($data['cucdetails']) && count($data['cucdetails'])>=1){
            foreach ($data['cucdetails'] as $row) {
                $tempArray                  =   array();
                $labelstatus                =   "";
                $tempArray['BOOK_ID']       =   $row->BOOK_ID;
                $showauthorname             =   ($row->AUTHOR_NAME   ==  ""?$row->EDITOR_NAME:$row->AUTHOR_NAME);
                if($row->CUCSTATUS   ==  2){
                    $tempArray['JOB_TITLE_LINK']    =   '<span  class="pointer" ng-click="openchapterlistdetails('."'".$row->JOB_ID."'".')">'.$row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span></span>';
                }else{
                    $tempArray['JOB_TITLE_LINK']    =   '<span>'.$row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span></span>';
                }
                $tempArray['PM_NAME']       =   $row->PM_NAME;
                $tempArray['CREATED_DATE']  =   $row->CREATED_DATE;
                if($row->CUCSTATUS   ==  2){
                    $labelstatus                =   Config::get('constants.MAGNUS_STATUS_LABEL.success');
                    $labelmessage               =   Config::get('constants.MAGNUS_STATUS_MESSAGE.success');
                }else if($row->CUCSTATUS   ==  3){
                    $labelstatus                =   Config::get('constants.MAGNUS_STATUS_LABEL.danger');
                    $labelmessage               =   Config::get('constants.MAGNUS_STATUS_MESSAGE.failed');
                }else if($row->CUCSTATUS   ==  "1.5"){
                    $labelstatus                =   Config::get('constants.MAGNUS_STATUS_LABEL.warning');
                    $labelmessage               =   Config::get('constants.MAGNUS_STATUS_MESSAGE.inprogress');
                }
                if($labelstatus     ==  "")
                    $tempArray['BG_PROCESS']    =   '--';
                else
                $tempArray['BG_PROCESS']        =   '<span class="label '.$labelstatus.' arrowed-in arrowed-in-right">'.$labelmessage.'</span>';
                array_push($bookdata, $tempArray);
            }
        }
            
        $Response                       =   array();
        $Response["draw"]               =   $Req->draw;
        $Response["recordsTotal"]       =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["recordsFiltered"]    =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["data"]               =   $bookdata;
        return response()->json($Response);
    }
    
    public function getjobChapterlist(Request $request)
    {
        $jobID                  =   $request->input('jodId');
        $response               =   [];
        $data                   =   taskLevelMetadataModel::getallcuclist($jobID);
        $response["cuclist"] 	=   $data;
        $response["user_id"] 	=   $this->loginUserId;
        return response($response);
    }
    //check out process
    public function doCucCheckoutprocess(Request $request)
    {
        try
        {
            $checkouttype       =   $request->input('checkouttype');
            $validation         =   Validator::make($request->all(), [
                                            'metadataid'=> 'required|numeric',
                                            'jobId' 	=> 'required|numeric',
                                            'Chapter' 	=> 'required',
                                            'bookid' 	=> 'required',
                                            'checkouttype'  =>  'required'
                                    ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>1,'errMsg'=>$validation->errors());   
                return response()->json($result,404);
            }
            $stagename          =   Config::get('constants.STAGE_NAME.CUC');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.CUC');      
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            //check already exist have chapter or not
            $inp_array          =   array();
            $inp_arr['METADATA_ID']     =   $metaid;
            $inp_arr['ROUND_ID']        =   Config::get('constants.ROUND_ID.CUC');  
            $inp_arr['STAGE']           =   Config::get('constants.STAGE_COLLEECTION.CUC');
            $getcurrentuserid 		=   $this->loginUserId;
            $jts_obj                    =   new jobTimeSheet();		
            $hasMetaid                  =   jobTimeSheet::where($inp_arr)->first();
			
            $inparray                   =   array();
            $inparray['METADATA_ID']    =   $metaid;
            $inparray['ROUND_ID']       =   Config::get('constants.ROUND_ID.CUC');  
            $inparray['STAGE']          =   Config::get('constants.STAGE_COLLEECTION.CUC');
            $inparray['CREATED_BY']     =   $this->loginUserId;
            $hasMyCheckoutentry         =   $jts_obj->hasChapterCheckedOutEntry($inparray);
            $hasMyCheckoutentryOfMe     =   $jts_obj->hasChapterCheckedOutOtherByMe($inparray);
            $hasOtherCheckoutentry      =   $jts_obj->hasOthersChapterCheckedOutEntry($inparray);

            if( count($hasOtherCheckoutentry) >= 1 && !empty( $hasOtherCheckoutentry ))
            {
                $result         =   array('result'=>401,'errMsg' => 'Other User checkout this chapter. kindly refresh the page and proceed.' );   
                return response()->json( $result );				
            }
				
            if( !empty( $hasMyCheckoutentryOfMe ))
            {
                $arrayinp                   =	[];
                $arrayinp['METADATA_ID']    =   (count($hasMyCheckoutentryOfMe)>=1?$hasMyCheckoutentryOfMe->METADATA_ID:'');
                $arrayinp['ROUND_ID']       =   Config::get('constants.ROUND_ID.CUC');  
                $arrayinp['STAGE']          =   Config::get('constants.STAGE_COLLEECTION.CUC');
                $arrayinp['STATUS']         =   2;
                $arrayinp['CREATED_BY']     =   $this->loginUserId;
                $checkexistcomplete         =	jobTimeSheet::where($arrayinp)->first();
                if(empty($checkexistcomplete))
                {
                    $getbookidexit          =   (count($hasMyCheckoutentryOfMe)>=1?$hasMyCheckoutentryOfMe->JOB_ID:'');

                    $bookdetails            =   bookinfoModel::select(DB::raw('job.*,job_info.*'))
                                                                            ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                                                            ->where('job.JOB_ID',$getbookidexit)
                                                                            ->get()->first(); 	
                    //get chpter name       
                    $getchaptername         =   taskLevelMetadataModel::where('METADATA_ID',$arrayinp['METADATA_ID'])->first();   
                    $getcurrentchaptername  =   '';
                    if(count($getchaptername)>=1)
                    {
                        $getcurrentchaptername  =   $getchaptername->CHAPTER_NO;
                    }
                    $result                 =   array('result'=>401,'errMsg'=>'Kindly check-in the previous Chapter : '.$bookdetails["BOOK_ID"].' - '.$getcurrentchaptername); 
                    return response()->json( $result );	
                }
            }
				
            if( !empty( $hasMyCheckoutentry )){

            }
				
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj         =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['user_id'];
                $userWork_for_const =   Config::get('serverconstants.USER_WORK_PATH');
                $serDir             =   Config::get('serverconstants.PRE_PROCESSING_PATH');
                
                if($checkouttype    ==  "new")
                {
                    //CUC_CHECKOUT_FOLDER
                    $splitround         =   Config::get('constants.STAGE_NAME.SPLIT'); 
                    $cucSourceCheckout  =   $hostpath.$serDir.$bookid.'/'.$splitround;
                    $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                    //get all files from ftp based on given folder name
                    $cucDirFiles        =   $ftpObj->allFiles($cucSourceCheckout);
                    $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter);   
                    if(count($successfile) >= 1 && count($cucDirFiles) >= 1){
                        $putfile    =   "";
                        $putfile_location   =   $hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        //check directory exist or not
                        $checkdirexistchapter   =   $ftpObj->has($putfile_location);
                        if(empty($checkdirexistchapter) && $checkdirexistchapter != 1){
                            $cucDirFiles    =   $ftpObj->makeDirectory($putfile_location,0777);
                        }
                        
                        if($ftpObj->has($putfile_location.'/'.$successfile[0])){
                            $ftpObj->delete($putfile_location.'/'.$successfile[0]);
                            $putfile    =	$ftpObj->copy($cucSourceCheckout.'/'.$successfile[0],$putfile_location.'/'.$successfile[0],0777);
                        }
                        else{
                            $putfile    =	$ftpObj->copy($cucSourceCheckout.'/'.$successfile[0],$putfile_location.'/'.$successfile[0],0777);
                        }
                        if($putfile !==     true){
                            $result         =   array('result'=>404,'errMsg'=>'File is not able to detect location try again'); 
                            return response()->json($result);
                        }
                        
                        $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucSourceCheckout;
                        $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        $open_path          =   str_replace( '//' , '/' , $open_path.'/'.$successfile[0] );
                    }
                    else{
                        $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...');   
                        return response()->json($result);
                    }
                }
                else {
                    //move from temp to user user again checkout
                    $tempfolder         =   Config::get('serverconstants.TEMP_PATH');
                    $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                    $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$tempfolder.$stagename.'/'.$bookid.'/'.$Chapter;
                    $checkexistdirfile  =   $hostpath.$tempfolder.$stageid.'_'.$bookid.'_'.$Chapter;
                    $cucDirFiles        =   $ftpObj->allFiles($checkexistdirfile);
                    $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                    if(count($successfile) >= 1){
                        $destinationpath    =   $hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$userWork_for_const.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        $open_path          =   str_replace( '//' , '/' , $open_path.'/'.$successfile[0]  );
                    }
                    if(count($cucDirFiles) == 0){ //copy file from user dir to temp
                        $cucSourceCheckout  =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;  
                        $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                        $destinationpath    =   $hostserver.$hostpath.$tempfolder.$stageid.'_'.$bookid.'_'.$Chapter;
                        $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                        $response           =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                        $cucDirFiles        =   $ftpObj->allFiles($cucSourceCheckout);
                        $successfile        =   $this->dogetdocumentfile($cucDirFiles,$Chapter); 
                        $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$userWork_for_const.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                        if(count($successfile) >= 1) 
                        {
                            $open_path          =   str_replace( '//' , '/' , $open_path.'/'.$successfile[0]  );
                        }else{
                            $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...');   
                            return response()->json($result);
                        }
                    }
                    if(count($cucDirFiles) == 0)
                    {
                        $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...');   
                        return response()->json($result);
                    }
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                    
                    $response_copy          =   array('success');
                    if( in_array( 'failed' , $response_copy ) )
                    {
                        foreach ($response_copy as $key => $value )
                        {
                            if( $value == 'success' ){
                                    unset( $response[$key] );
                            }
                        }
                        $response_copy      =   array( 'status' => 'failed'  , $response_copy );
                    }
                    else
                    {
                        $response_copy      =   array( 'status' => 'success' , $response_copy );
                    }
                    $response               =       $response_copy;
                    if( $response_copy['status'] != 'success' )
                    {
                        $result         =   array('result'=>404,'errMsg'=>'File is not able to detect location try again'); 
                        return response()->json($result);			
                    }
                }
                
                $postdata               =   [];
                $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                $postdata['system_ip']  =   $request->ip();
                $postdata['method_name']=   "doOpenDriveServer";
                $postdata['processname']=   "checkout";
                $insertfilehandler      =   fileHandler::insertNew($postdata);                   
                if($insertfilehandler>=1)
                {
                    $jobtimedata                =   [];
                    $jobtimedata['JOB_ID']      =   $jobId; 
                    $jobtimedata['METADATA_ID'] =   $metaid;
                    $jobtimedata['ROUND_ID']    =   Config::get('constants.ROUND_ID.CUC');
                    $jobtimedata['STAGE']       =   Config::get('constants.STAGE_COLLEECTION.CUC');
                    $jobtimedata['TYPE']        =   1;
                    $jobtimedata['STATUS']      =   1;
                    $jobtimedata['CHECK_OUT']   =   Carbon::now();
                    $jobtimedata['CREATED_DATE']=   Carbon::now();
                    $jobtimedata['created_at']  =   Carbon::now();
                    $jobtimedata['updated_at']  =   Carbon::now();
                    $jobtimedata['CREATED_BY']  =   Session::get('users')['user_id'];
                    $timesheeid                 =   jobTimeSheet::doAddNewTime($jobtimedata);
                    $getrecords                 =   [];
                    if($timesheeid)
                    {
                        $getrecords             =   jobTimeSheet::getJimetimelastcuc($timesheeid);
                    }
                    $result         =   array('result'=>200,'errMsg'=>'Successfully checkout','records'=>$getrecords,'rmID'=>$insertfilehandler);   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=>'While adding records in filehadler is error occurred try again'); 
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
	}
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Ftp connection Failed');   
            return response()->json($result);
        }
    }
    
    public function dogetdocumentfile($cucDirFiles,$Chapter)
    {
        $successfile        =   [];
        if(count($cucDirFiles)>=1) 
        {
            $readfileextenstion     =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
            foreach($cucDirFiles as $key=>$jsonvalue)
            {
                if(strpos($jsonvalue,'/') !== 	false)
                {
                    $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                    if(strpos($spiltchapter,'.') !== false)
                    {
                        $splitname          =   explode('.',$spiltchapter);
                        if(in_array(trim($splitname[1]),$readfileextenstion) && trim($splitname[0]) == $Chapter)
                        {
                            $successfile[]  =   $spiltchapter;
                        }
                    }
                }
            }
        }
        return $successfile;
    }
    
    public function doCheckfilehasbeenopenornot($insertfilehandler,$checkcount  =   0)
    {
        ini_set('max_execution_time',0);
        $completed 			=   Config::get('constants.FILE_HANDLER_ACTION.success');					
        $checkcomplete 			=   fileHandler::where('ID',$insertfilehandler)->where('status',1)->where('remarks',$completed)->first();
        if($checkcount>5 || count($checkcomplete)>=1)
        {
            return 1;
        }
        $this->doCheckfilehasbeenopenornot($insertfilehandler,++$checkcount);
    }
    //check in process
    public function doCucCheckinprocess(Request $request)
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                            'metadataid'=> 'required|numeric',
                                            'jobId' 	=> 'required|numeric',
                                            'Chapter' 	=> 'required',
                                            'bookid' 	=> 'required',
                                            'jobtimesheetid' => 'required|numeric'
                                    ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>1,'errMsg'=>$validation->errors());   
                return response()->json($result,404);
            }
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            $jobtimesheetid     =   $request->input('jobtimesheetid');
            
            //get location 
            $stagename          =   Config::get('constants.STAGE_NAME.CUC');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.CUC');  
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
                $getuserid          =   Session::get('users')['user_id'];
                $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                $sourcepathuserwork =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $checkexistdirfile  =   $hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $cucDirFiles        =   $ftpObj->allFiles($checkexistdirfile);
                if(!empty($cucDirFiles)) 
                {
                    //$sourcepath           =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucSourceCheckout;
                    $destinationpath        =   $hostserver.$hostpath.Config::get('serverconstants.TEMP_PATH').$stageid.'_'.$bookid.'_'.$Chapter;
                    $sourcepath             =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.Config::get('serverconstants.TEMP_PATH');
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepathuserwork , $destinationpath);
                    $response_copy      =   array('success');
                    if( in_array( 'failed' , $response_copy ) )
                    {
                        foreach ($response_copy as $key => $value )
                        {
                                if( $value == 'success' ){
                                        unset( $response[$key] );
                                }
                        }
                        $response_copy   =       array( 'status' => 'failed'  , $response_copy );
                    }
                    else
                    {
                        $response_copy    =       array( 'status' => 'success' , $response_copy );
                    }
                    $response   =       $response_copy;
                    if( $response_copy['status'] != 'success' )
                    {
                        $result         =   array('result'=>404,'errMsg'=>'Unable to copy files, please try again'); 
                        return response()->json($result);			
                    }
                    $datajob                =   [];
                    $datajob['CHECK_IN']    =   Carbon::now();
                    $doUpdatecheckin        =   jobTimeSheet::updateIfExist($datajob,$jobtimesheetid);
                    $result                 =   array('result'=>200, 'errMsg' => 'File Check-in Successful ' ,'desitinationpath'=>$destinationpath);
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...');   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
    //Final submit process
    public function doCucCompleteprocess(Request $request)
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                             'metadataid'=> 'required|numeric',
                                             'jobId' 	=> 'required|numeric',
                                             'Chapter' 	=> 'required',
                                             'bookid' 	=> 'required',
                                             'jobtimesheetid' => 'required|numeric'
                                     ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>1,'errMsg'=>$validation->errors());   
                return response()->json($result,404);
            } 
            $stagename          =   Config::get('constants.STAGE_NAME.CUC');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.CUC');   
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $bookid             =   $request->input('bookid');
            $jobtimesheetid     =   $request->input('jobtimesheetid');
            $wheredata          =   [];
            $wheredata['METADATA_ID']   =   $metaid;
            $wheredata['JOB_ID']        =   $jobId;
            $wheredata['STAGE']         =   $stageid;
            $wheredata['METADATA_ID']   =   $metaid;
            
            //check user access 
            $getmamtimesheetid  =   jobTimeSheet::getMaxoftimesheetrecords($wheredata);
            $jobtimesheetid     =   (count($getmamtimesheetid)>=1?$getmamtimesheetid->timesheetid:$jobtimesheetid);
            
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['user_id'];
                
                $cucSourceCheckout  =   $hostpath.Config::get('serverconstants.PRE_PROCESSING_PATH').$bookid.'/'.$stagename.'/'.$Chapter;                    
                $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                //check directory is exist or not
                $cucSourceexist     =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;
                //get all files from ftp based on given folder name
                $cucDirFiles        =   $ftpObj->allFiles($cucSourceexist);
                $destinationpath    =   $hostserver.$cucSourceCheckout;
                if(!empty($cucDirFiles)) 
                {
                    $xmlFilePath    =   "";
                    foreach($cucDirFiles as $checkxmlFile) 
                    {
                        if(pathinfo($checkxmlFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $checkxmlFile;
                        }
                    }
                    if($xmlFilePath == '') 
                    {
                        $result         =   array('result'=>404,'errMsg'=>'Cuc log file is not found');   
                        return response()->json($result);
                    }
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                    $response_copy          =   array('success');
                    if( in_array( 'failed' , $response_copy ) )
                    {
                        foreach ($response_copy as $key => $value )
                        {
                            if( $value == 'success' ){
                                unset( $response[$key] );
                            }
                        }
                        $response_copy      =   array( 'status' => 'failed'  , $response_copy );
                    }
                    else
                    {
                        $response_copy      =   array( 'status' => 'success' , $response_copy );
                    }
                    $response               =   $response_copy;
                    if( $response_copy['status'] != 'success' )
                    {
                        $result             =   array('result'=>404,'errMsg'=>'File copy is failed try again'); 
                        return response()->json($result);			
                    }
                    //check exist meta id in job time sheet table
                    $jobtimedata            =   [];
                    $jobtimedata['STATUS']  =   2;
                    $jobtimedata['CHECK_IN']=   Carbon::now();
                    $updatemetasuccess      =   jobTimeSheet::updateIfExist($jobtimedata,$jobtimesheetid);
                    //insert record in filehandler table for delete ftp drive
                    $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucSourceCheckout;
                    $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$cucuserworkfolder.$getuserid.'/'.$stagename.'/'.$bookid.'/'.$Chapter;                    
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    $postdata               =   [];
                
                    $postdata['file_path']  =   $open_path.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "deleteFileServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "deleteFileServer";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    
                    $result                 =   array('result'=>200,'errMsg'=>'File submitted Successfully...');   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...' );   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');      
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
        //OPEN CU LOG FILE folder process
    public function doCucOpenDrive(Request $request)
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                                'metadataid'=> 'required|numeric',
                                                'jobId' 	=> 'required|numeric',
                                                'Chapter' 	=> 'required'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>1,'errMsg'=>$validation->errors());   
                return response()->json($result,404);
            }
            $metaid             =   $request->input('metadataid');
            $jobId              =   $request->input('jobId');
            $Chapter            =   $request->input('Chapter');
            $getbookid          =   jobModel::getJobdetailsRawQuery($jobId,'job.BOOK_ID');
            $roundname          =   Config::get('constants.ROUND_OF_NAME.S5');
            $stagename          =   Config::get('constants.STAGE_NAME.CUC');
            $stageid            =   Config::get('constants.STAGE_COLLEECTION.CUC');   
            //get location for exist job id
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            if(count($getlocationftp)>=1 || empty($getbookid))
            {
                $bookid         =   $getbookid->BOOK_ID;
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['user_id'];
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $userWork_for_const =   Config::get('serverconstants.PRE_PROCESSING_PATH');
                $clientname         =   Config::get('constants.CLIENTNAME');
                $open_path          =   $hostserver.$hostpath.$userWork_for_const.'/'.$bookid.'/'.$stagename.'/'.$Chapter.'/';                    
                $source_path        =   $hostpath.$userWork_for_const.'/'.$bookid.'/'.$stagename.'/'.$Chapter.'/';                    
                $open_path          =   str_replace( '//' , '/' , $open_path );
                $cucdir_path        =   str_replace( '//' , '/' , $source_path );
                
                $sourcepath         =   Config::get('constants.FILE_SERVER_CREDENTIALS').$hostserver.$cucdir_path;
                $destinationpath    =   $hostserver.$hostpath.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid.'/CUCLOG/'.$Chapter;
                $userworkpath       =   $hostpath.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid.'/CUCLOG/'.$Chapter;
                //get all files from ftp based on given folder name
                $cucDirFiles        =   $ftpObj->allFiles($cucdir_path);
                if(!empty($cucDirFiles)) 
                {
                    $ftpestablishconnection =   new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                    $response               =   $ftpestablishconnection->ftp_dir_copy( $sourcepath , $destinationpath);
                    $response_copy          =   [];
                    if( in_array( 'failed' , $response ) )
                    {
                        foreach ($response as $key => $value )
                        {
                            if( $value == 'success' ){
                                unset( $response[$key] );
                            }
                        }
                        $response_copy      =   array( 'status' => 'failed'  , $response );
                    }else{
                        $response_copy      =   array( 'status' => 'success' , $response );
                    }
                    
                    if( $response_copy['status'] != 'success' ){
                        $result             =   array('result'=>404,'errMsg'=>'File copy is failed try again'); 
                        return response()->json($result);			
                    }
                    
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $open_path      =   $hostserver.$ftp_root_dir.$userworkpath.'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['file_path']  =   str_replace( '//' , '/' , $open_path );
//                    $postdata['file_path']  =   $open_path.'/'.$successfile[0].'/<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    if($insertfilehandler>=1)
                    {
                        $result         =   array('result'=>200,'errMsg'=>'Folder Opened Successfully','rmID'=>$insertfilehandler);   
                        return response()->json($result);
                    }
                    $result         =   array('result'=>404,'errMsg'=> 'While adding records in filehadler is error occurred try again');   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=> $Chapter.' directory is not found...' );   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>'Unable to connect to production Server...');   
            return response()->json($result);
        }
    }
    
    
    public function getCucJobXMLInfo(Request $request) 
    {
	try
        {
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
                $bookid         =   $request->input('bookid');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                $ftpObj         =   \Storage::createFtpDriver([
                                                                                        'host'     => $hostserver, 
                                                                                        'username' => $hostusername,
                                                                                        'password' => $hostpassword, // 
                                                                                        'port'     => '21',
                                                                                        'timeout'  => '30',
                                                                        ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $roundname          =   Config::get('constants.ROUND_OF_NAME.S5');
                $cucuserworkfolder  =   Config::get('serverconstants.JOBSHEET_FULL_PATH');
                $inp_rep_arr        =   array( 
                                            'BOOK_ID'       =>      $bookid , 
                                            'ROUND_NAME'    =>      $roundname                        
                                         );
                 
                $cmn_obj            =   new CommonMethodsController();
                $serverDir          =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , Config::get('serverconstants.JOBSHEET_FULL_PATH') );
                $cucuserworkfolder  =   $hostpath.$serverDir;
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(pathinfo($serverDirFile)['extension'] == 'xml') 
                        {
                            $xmlFilePath    =   $serverDirFile;
                        }
                    }
                    if($xmlFilePath == '') 
                    {
                            $result         =   array('result'=>404,'errMsg'=>'<p class="text-center">No XML found.</p>','xmlcount'=>'0');   
                            return response()->json($result);
                    }

                    $filePath       =   '/' . $xmlFilePath;
                    // $filecontent = self::xmlSampleContent();
                    $filecontent    =   $ftpObj->get($filePath); // read file content
                    $xmlPath        =   base_path() . DIRECTORY_SEPARATOR . 'sample.xml';
                    $xslFilePath    =   base_path() . DIRECTORY_SEPARATOR . 'assets'. DIRECTORY_SEPARATOR .'dist'. DIRECTORY_SEPARATOR .'css'. DIRECTORY_SEPARATOR .'jobsheet.xsl';

                    // LOAD XML FILE CONTENT
                    $XML = new \DOMDocument(); 
                    $XML->loadXML($filecontent);
                    // START XSLT 
                    $xslt = new \XSLTProcessor(); 
                    // IMPORT STYLESHEET
                    $XSL = new \DOMDocument(); 
                    $XSL->load( $xslFilePath ); 
                    $xslt->importStylesheet( $XSL ); 
                    $result         =   array('result'=>200,'errMsg'=>$xslt->transformToXML( $XML ),'xmlcount'=>strlen($xslt->transformToXML( $XML )));   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=>'XML file is not found','xmlcount'=>0);   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>  'No files found in the Production Location...' ,'xmlcount'=>0);   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>404,'errMsg'=>$e->getMessage());   
            return response()->json($result);
        }
    }
    
    public function getCucXMLInfo(Request $request) 
    {
        try
        {
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            if(count($getlocationftp)>=1)
            {
                $metaid         =   $request->input('metadataid');
                $jobId          =   $request->input('jobId');
                $Chapter        =   $request->input('Chapter');
//                $bookid         =   $request->input('bookid');
                //get book id 
                $bookdetaills   =   jobModel::where('JOB_ID',$jobId)->first();
                $bookid         =   (count($bookdetaills)>=1?$bookdetaills->BOOK_ID:'');
                $stagename      =   Config::get('constants.STAGE_NAME.CUC');
                $clientname     =   Config::get('constants.CLIENTNAME');
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                // Do the FTP connection
                
                $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['emp_id'];
                $cucuserworkfolder  =   $hostpath.Config::get('serverconstants.PRE_PROCESSING_PATH').$bookid.'/'.$stagename.'/'.$Chapter.'/'.$clientname;  
//                $cucuserworkfolder  =   $hostpath.Config::get('serverconstants.PRE_PROCESSING_PATH').$bookid.'/'.$stagename.'/'.$Chapter.'/';  
                $cucDirFiles        =   $ftpObj->allFiles($cucuserworkfolder);
                if(!empty($cucDirFiles)) 
                {
                    $htmlFilePath   =   "";
                    foreach($cucDirFiles as $serverDirFile) 
                    {
                        if(strtolower(pathinfo($serverDirFile)['extension']) == 'html') 
                        {
                            $htmlFilePath   =   $serverDirFile;
                        }
                    }
                    if($htmlFilePath == '') 
                    {
                        $result         =   array('result'=>404,'errMsg'=>'<p class="text-center">Log File is not found.</p>','xmlcount'=>'0');   
                        return response()->json($result);
                    }
//                    $htmlFilePath   =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver.'/'.$htmlFilePath;  
                    $htmlFilePath   =   'file://'.$hostserver.$this->ftp_root_dir.$htmlFilePath;  
//                    $filecontent    =   $ftpObj->get($htmlFilePath); 
                    $result         =   array('result'=>200,'errMsg'=>$htmlFilePath,'xmlcount'=>strlen($htmlFilePath));   
                    return response()->json($result);
                }
                $result         =   array('result'=>404,'errMsg'=>'Log File is not found','xmlcount'=>0);   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=> 'No files found in the Production Location...' ,'xmlcount'=>0);   
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>404,'errMsg'=>"Could not connect with production location, Kindly check credential");   
            return response()->json($result);
        }
    }
    
    //Final submit process
    public function docucopenrawfile(Request $request){
        
//        try{
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>404,'errMsg'=>"Mandatory fields are required",'validation'=>$validation->errors());   
                return response()->json($result);
            }
            
            $jobId              =   $request->input('jobId');
            $bookdata           =   jobModel::getJobdetails($jobId);
            if(empty($bookdata))
            {
                $result         =   array('result'=>404,'errMsg'=>"BookId is required");   
                return response()->json($result);
            }
            
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $rawpath            =   Config::get('serverconstants.RAW_PATH');
            //get location for exist job id
            $default_location	=	0;
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
             if(empty($getlocationftp) || $getlocationftp == null){
                $default_location	=	1;
                $getlocationftp     =   productionLocationModel::getDefaultProductionLocationInfo();
            }
               
            if($getlocationftp !=   ''){
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
               if($default_location == 1){
                    $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                }else{	
                        $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                        $getlocationftp->FTP_PATH_CREDENTIAL = 'ftp://'.$getlocationftp->FTP_USER_NAME.':'.$hostpassword.'@'; 
                        $getlocationftp->SERVER_PATH         =  $hostserver.$getlocationftp->FTP_PATH;
                }
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
               
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                
                $fileHandlerObj     =   new ftpFileHandlerController($hostserver,$hostusername,$hostpassword);
               
                $workPathdir        =   $getlocationftp->FTP_PATH.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid;
                
                $workPath           =   $getlocationftp->FTP_PATH_CREDENTIAL.$getlocationftp->SERVER_PATH.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid;
                $workPathLoca       =   $getlocationftp->SERVER_PATH.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid;
                $openPath           =   $hostserver.$getlocationftp->FILE_SERVER_PATH.Config::get('serverconstants.USER_WORK_PATH').$this->empId.'/'.$bookid;
                $cucSourceexist     =   "";
                
                //check location is mapped or not 
                if(empty($bookdata->LOCATION)){
                    //send tool rquest
                    $initprdObj     =   new productionFileTransferController();
                    $returnresponse     =   $initprdObj->rawFileDownloadRequest($jobId , $this->round_ID_5 );
                    
                    return response()->json($returnresponse);
                }else{
                // RAW FILE PATH MAPPING
                    $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                    $sfifty             =   Config::get('constants.ROUND_OF_NAME.S5');
                   
                    $destinationpath    =   $hostserver.$hostpath.$rawpath.$bookid.'/'.$sfifty;     
                    
                    $open_path          =   $hostserver.$ftp_root_dir.$hostpath.$rawpath.$bookid.'/'.$sfifty;  
                    $open_path          =   str_replace( '//' , '/' , $open_path );
                    $cucSourceexist     =   $hostpath.$rawpath.$bookid.'/'.$sfifty;
                }
                
                $fileHandlerObj->make_directory($workPathdir);
                
                if($default_location == 0){
                    $res =    $fileHandlerObj->ftp_dir_copy($getlocationftp->FTP_PATH_CREDENTIAL.$destinationpath,$workPathLoca);
                }else{
                    $res            =   $fileHandlerObj->ftpSingleFileCopyOrMove($srcPath,$workPath.'/'.$filename);
                }
              
                //check directory is exist or not
//                $cucDirFiles        =   $ftpObj->allFiles($cucSourceexist);
//                if(!empty($cucDirFiles)) 
//                {
                    //insert record in filehandler table for open ftp drive in window explore
                    $postdata               =   [];
                    $postdata['file_path']  =   $openPath.'<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                    $postdata['method_name']=   "doOpenDriveServer";
                    $postdata['system_ip']  =   $request->ip();
                    $postdata['processname']=   "checkout";
                    $insertfilehandler      =   fileHandler::insertNew($postdata);
                    if ($insertfilehandler) {
                        $response['result'] = 200;
                        $response['Msg'] = 'Success';
                        $response['errMsg'] = 'File open initialized..';
                        $response['rmID'] = $insertfilehandler;
                        return response()->json($response);
                    }
                    $result         =   array('result'=>404,'errMsg'=>'Data is not posted properly try again.');   
                    return response()->json($result);
//                }
//                $result         =   array('result'=>404,'errMsg'=> 'Directory is empty...' );   
//                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
//        }
//        catch( \Exception $e )
//        {           
//            $result         =   array('result'=>404,'errMsg'=>'Unable to connect to production Server...');   
//            return response()->json($result);
//        }
    }
    
    
    public function rawfileOpenrequestInsert(Request $request)
    {
//        try{
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $result         =   array('result'=>404,'errMsg'=>"Mandatory fields are required",'validation'=>$validation->errors());   
                return response()->json($result);
            }
            $jobId              =   $request->input('jobId');
            $bookdata           =   jobModel::getJobdetails($jobId);
            if(empty($bookdata))
            {
                $result         =   array('result'=>404,'errMsg'=>"BookId is required");   
                return response()->json($result);
            }
            $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
            $rawpath            =   Config::get('serverconstants.RAW_PATH');
            //get location for exist job id
            $default_location	=	0;
            $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
            
             if(empty($getlocationftp) || $getlocationftp == null){
                $default_location	=	1;
                $getlocationftp     =   productionLocationModel::getDefaultProductionLocationInfo();
            }
               
            if($getlocationftp !=   ''){
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
               if($default_location == 1){
                    $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                }else{	
                        $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                        $getlocationftp->FTP_PATH_CREDENTIAL = 'ftp://'.$getlocationftp->FTP_USER_NAME.':'.$hostpassword.'@'; 
                        $getlocationftp->SERVER_PATH         =  $hostserver.$getlocationftp->FTP_PATH;
                }
                $hostpath       =   $getlocationftp->FTP_PATH;
                $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
                $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
                
                $root           =       Config::get('constants.FILE_SERVER_ROOT_DIR');
                
                $getuserid  =   (empty($this->empId)?'':$this->empId.'/');
                $userdir        =       Config::get('serverconstants.USER_WORK_PATH');
                $userdirpath    =   $userdir.$getuserid.$bookid;
                $openPath       =   $hostserver.$root.$hostpath.$userdirpath;
        
                $ftp_root_dir       =   Config::get('serverconstants.FILE_SERVER_ROOT_DIR');
                $sfifty             =   Config::get('constants.ROUND_OF_NAME.S5');

                //insert record in filehandler table for open ftp drive in window explore
                $postdata               =   [];
                $postdata['file_path']  =   $openPath.'<>'.$hostuserfieserver.'<>'.$hostpasswordfieserver;
                $postdata['method_name']=   "doOpenDriveServer";
                $postdata['system_ip']  =   $request->ip();
                $postdata['processname']=   "checkout";
                $insertfilehandler      =   fileHandler::insertNew($postdata);
                if ($insertfilehandler) {
                    $response['result'] = 200;
                    $response['Msg'] = 'Success';
                    $response['errMsg'] = 'File open initialized..';
                    $response['rmID'] = $insertfilehandler;
                    return response()->json($response);
                }
                
                $result         =   array('result'=>404,'errMsg'=>'Data is not posted properly try again.');   
                return response()->json($result);
            }
            $result         =   array('result'=>404,'errMsg'=>'No files found in the Production Location...');   
            return response()->json($result);
//        }
//        catch( \Exception $e )
//        {           
//            $result         =   array('result'=>404,'errMsg'=>'Unable to connect to production Server...');   
//            return response()->json($result);
//        }
    }
    
    public function cucmanual(){
        $this->cucBackgroundprocess('6520');
        
    }
    
public function cucBackgroundprocess($job_id     =   null)
    {  
        try
        {
            $getlocationftp     =   productionLocationModel::doGetLocationname( $job_id ); 
            if(count($getlocationftp)>=1)
            {
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                
                 $ftpfileObj         =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
                // Do the FTP connection
                $ftpObj         =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                $getuserid          =   Session::get('users')['user_id'];
                $userWork_for_const =   Config::get('serverconstants.USER_WORK_PATH');
                $serDir             =   Config::get('serverconstants.PRE_PROCESSING_PATH');
                 $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                $bookdata           =   jobModel::getJobdetails($job_id);
                $bookid             =   (count($bookdata)>=1?$bookdata->BOOK_ID:'');
                $joblayout          =   (count($bookdata)>=1?$bookdata->LAYOUT_PROFILE:'');
                $getlayout          =   spicastProfileModel::where('SPICAST_ID',$joblayout)->first();
                $profilename        =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
                $clientname         =   (count($getlayout)>=1?$getlayout->CLIENT_NAME:'');
                $clientId           =   Config::get('constants.CLIENTNAME');
                //CUC_CHECKOUT_FOLDER
                $splitround         =   Config::get('constants.STAGE_NAME.SPLIT'); 
                $cucSourceCheckout  =   $hostpath.$serDir.$bookid.'/'.$splitround;
                
               // echo "<pre>";print_r($cucSourceCheckout);exit;
                $cucuserworkfolder  =   Config::get('serverconstants.USER_WORK_PATH');
                // GET CHAPTER FROM METADATA
                $getallchapters     =   taskLevelMetadataModel::getMetadatadetailsJob($job_id);
                
                foreach($getallchapters as $key => $data){
                   $filepath                                        =   $cucSourceCheckout.'/'.$data->CHAPTER_NO;
                   $recordDetails[$data->METADATA_ID]['filePath']   =   $filepath;
                   $recordDetails[$data->METADATA_ID]['chapNo']     =   $data->CHAPTER_NO;
                   $serverDirFiles                                  =   $ftpObj->allFiles($filepath);
                   if(!empty($serverDirFiles)){
                        $recordDetails[$data->METADATA_ID]['filename'] = '//'.$hostserver.$ftp_root_dir.$serverDirFiles['0'];   
                       $fsize                                          =    $ftpfileObj->ftp_file_size($serverDirFiles['0']);
                   }else{
                       $fsize              =    0;
                   }
                   $recordDetails[$data->METADATA_ID]['filesize'] = $fsize;
                }
                
                $result             =   array('result'=>400,'status'=>0,'errMsg'=>'Split Directories is empty');   
           
                if(count($recordDetails)>=1)
                {
                     $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                    $readfmfile         =   Config::get('constants.FRONT_MATTER');
                    $readbmfile         =   Config::get('constants.BACK_MATTER');
                    $readchapterfile    =   Config::get('constants.READ_CHAPTER_EXTENSTION');
                    $readparts          =   Config::get('constants.READ_TYPEOF_PART');
                    $readallfiles       =   Config::get('constants.READ_TYPEOF_PM_FM');
                    $ftp_root_dir       =   Config::get('constants.FILE_SERVER_ROOT_DIR');
                    $fileprocess_dir    =   Config::get('constants.SPLIT_DESTINATION_PATH');
                    $cucfileprocess_dir    =   Config::get('constants.SPLIT_DESTINATION_PATH');
                    $stagename          =   Config::get('constants.STAGE_NAME.SPLIT');
                    $chapterlist        =   $getallchapters->pluck('CHAPTER_NO')->toArray(); 
                    $readfileextenstion =   Config::get('constants.CUC_CHAPTER_READ_EXTENSTION_WITHOUTDOT');
                   
                    $bookidreplace      =   array(
                                                    'BOOK_ID'       =>  $bookid,
                                                    'STAGE_NAME'       =>  Config::get('constants.STAGE_NAME.SPLIT')
                                                 );
                    
                     $bookidreplace2      =   array(
                                                    'BOOK_ID'       =>  $bookid,
                                                    'STAGE_NAME'       =>  Config::get('constants.STAGE_NAME.CUC')
                                                 );
                    $cmn_obj            =   new CommonMethodsController();
                    $fileprocess_dir    =   $cmn_obj->arr_key_value_replace( $bookidreplace , $fileprocess_dir , true );
                    $fileprocess_dir2    =   $cmn_obj->arr_key_value_replace( $bookidreplace2 , $cucfileprocess_dir , true );
                    
                    $token_key                      =   $cmn_obj->generateRandomString( 16 , 'api_cuc','TOKEN' );
                    $getlayoutprofile               =   jobInfoModel::where('JOB_ID',$job_id)->first();
                    $layoutprofile                  =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
                    $url                            =   url('/').'/api/cucCallback';
                   
                    $hostpath   =   ltrim($hostpath,'/');
                    $cucstage   =   Config::get('constants.STAGE_NAME.CUC');
                    $destinationurl     =   "//".$hostserver.$ftp_root_dir.$hostpath.$fileprocess_dir2;
                                     
                    $xml            = 	new \XMLWriter();
                    $xml->openMemory();
                    $xml->startDocument();
                    $xml->startElement('Metadata');
                    $xml->setIndent(true);
                    $xml->startElement('Publisher');
                    $xml->text($clientname);
                    $xml->endElement();
                    $xml->startElement('Location');
                    $xml->text($getlocationftp->LOCATION_NAME);
                    $xml->endElement();
                    $xml->startElement('ClientID');
                    $xml->text($clientId);
                    $xml->endElement();
                    $xml->startElement('Cycle');
                    $xml->text(true);
                    $xml->endElement();
                    $xml->startElement('Process');
                    $xml->text(Config::get('constants.STAGE_NAME.CUC'));
                    $xml->endElement();
                    $xml->startElement('BookID');
                    $xml->text($bookid);
                    $xml->endElement();
                    //SOURCE PATH
                    $xml->startElement('Source');
                   
                    foreach($recordDetails as $key=>$data)
                    {
                        $xml->startElement("File"); 
                        $xml->writeAttribute("type", 'Document'); 
                        $xml->writeAttribute("size", $data['filesize']); 
                        $xml->writeAttribute("src", $data['filename']); 
                        $xml->endElement(); 
                        $chapaterDetails[$key] = $data['filename'];
                    }
                  
                    $xml->endElement();
                    //DESTINATION PATH
                    $xml->startElement('Destination');
                    foreach($recordDetails as $key=>$data2)
                    {
                      
                        $xml->startElement("File"); 
                        $xml->writeAttribute("src", $destinationurl.$data2['chapNo']); 
                        $xml->writeAttribute("metaid", $key); 
                        $xml->endElement();  
                    }
                   
                    $xml->endElement();
                    //work flow tag
                    $xml->startElement("Workflow"); 
                        $xml->startElement('Url');
                        $xml->writeAttribute('value', $url);
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "cuc");
                        $xml->writeAttribute('key', "process");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value',$job_id);
                        $xml->writeAttribute('key', "jobid");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', Config::get('constants.ROUND_ID.S5'));
                        $xml->writeAttribute('key', "round");
                        $xml->endElement();

                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', $token_key);
                        $xml->writeAttribute('key', "tokenkey");
                        $xml->endElement();

                        //status parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "boolean");
                        $xml->writeAttribute('key', "status");
                        $xml->endElement();

                        //end time parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "fixed");
                        $xml->writeAttribute('value', "Y-m-d H:m:i");
                        $xml->writeAttribute('key', "endtime");
                        $xml->endElement();

                        //jobid parameter
                        $xml->startElement('parameter');
                        $xml->writeAttribute('type', "string");
                        $xml->writeAttribute('key', "remarks");
                        $xml->endElement();
                    $xml->endElement();
                    $xml->endElement();
                    $xml->endDocument();
                    
                    $content 	= 	$xml->outputMemory();
                  
                    $filename 	=	$bookid.'_CUC.xml';
                    
                    //post reference pdf data
                    $newchapterdata     =   $chapaterDetails;
            
                    //get stage id for reference pdf
                    $getjobstageinfo    =   jobStage::getJobStageInforeferencepdf($job_id);
                    
                   
					$cmn_obj            =   new CommonMethodsController();
                    if(count($getjobstageinfo)>=1)
                    {   //update in progress
                        jobStage::where('JOB_STAGE_ID',$getjobstageinfo->JOB_STAGE_ID)->update(['CHECK_OUT'=>Carbon::now(),'STATUS'=>Config::get('constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS')]);
                        $ref_pdf_data       =   ['jobstageid'   =>  $getjobstageinfo->JOB_STAGE_ID,'chapterdata'=>$newchapterdata];
                        $ref_url            =   url('/').'/api/startreferencepdfProcess';
                        		
                        $postreferencepdf   =   $cmn_obj->PostcUrlExecution($ref_pdf_data,$ref_url);
						
                    }
                
                    $round                  =   $this->round_ID_5;
                    $spicast                =   [];
                    $spicast['JOB_ID']      =   $job_id;
                    $spicast['ROUND']       =   Config::get('constants.ROUND_ID.S5');
                    $spicast['START_TIME']  =   Carbon::now();
                    $spicast['TOKEN']       =   $token_key;
                    $spicast['created_at']  =   Carbon::now();
                    $spicast['REQUEST_LOG'] =   $content;
                    $spicast['CREATED_BY']  =   $this->loginUserId;
                    $storespicast           =   apiCucbackgroundprocessModel::insertGetId($spicast);
                   
                    // insert job time sheet entry
                    $spicastStageID    =   taskLevelMetadataModel::getcucStageID($job_id);
                    if(count($spicastStageID)>=1)
                    {
                        $spicastStId        =   $spicastStageID['0']->JOB_STAGE_ID;
                        $roundId            =   $spicastStageID['0']->JOB_ROUND_ID;
                        $setArr             =   array( 'CHECK_OUT'  => Carbon::now() , 'STATUS' => Config::get('constants.STATUS_ENUM_COLLEECTION.IN_PROGRESS'));
                        $updateQry          =   DB::table('job_stage')
                                            ->where('JOB_STAGE_ID', $spicastStId )
                                            ->update( $setArr );
                        app('App\Http\Controllers\Api\activeMqReportController')->roundStageandUserStageDetails($job_id,$round,'insert',$spicastStId);
                    }
                    
                    $userid     =   Config::get('constants.ADMIN_USER_ID');
                    if (Session()->has('users')) {
                        $userid     =   $this->loginUserId;
                    }
                    
                    $query_stmt     =   "CALL jobtimesheetentry('".$job_id."', '".Config::get('constants.ROUND_NAME.CUC')."', '".Config::get('constants.STAGE_COLLEECTION.CUC')."', '1','".$userid."', 'insert')";
                    $moveDetails    =   DB::query( $query_stmt );
//                  $successfileresponse    =	$ftpObj->put(Config::get('constants.WATCH_CUC').'/'.$filename, $content);
                    // check if cURL installed or not in your system?
                    if (!function_exists('curl_init'))
                    {
                            return 'Sorry cURL is not installed!';
                    }

                    $url        =   Config::get('constants.CUC_CALL_BACK_URL');
                    $ch 	=   curl_init();
                    curl_setopt($ch, CURLOPT_URL, $url);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:text/plain'));
                    curl_setopt($ch, CURLOPT_POSTFIELDS,$content);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    $contents       =   curl_exec($ch);
                    curl_close($ch);
                    header('Content-Type: application/json');
                    $returnstr          =   ['&#xD;','<string xmlns="http://schemas.microsoft.com/2003/10/Serialization/">','</string>'];
                    
                 
                    foreach($returnstr as $removestr)
                    {
                        if(strpos($contents,$removestr) !== false)
                        {
                            $contents   =   str_replace($removestr, "", $contents);
                        }
                    }
                    $getToolresponse    =   json_decode($contents);
                    if(count($getToolresponse)>=1)
                    {
                        //update cuc tool response
                        $token              =   trim($getToolresponse->tokenkey);
                        $status             =   trim($getToolresponse->status);
                        $endtime            =   trim($getToolresponse->endtime);
                        $updatedata         =   [];
                        $updatedata['END_TIME'] =   $endtime;
                        $updatedata['STATUS']   =   ($status    ==  "failure"?'3':'2');
                        $updatedata['REMARKS']  =   trim($getToolresponse->remarks);
                        $updatedata['RESPONSE_LOG'] =	$contents;
                        $updatemeta         =   apiCucbackgroundprocessModel::doupdate($token,$updatedata);
                        if($updatemeta)
                        {
                            $result         =   array('result'=>200,'status'=>1,'msg'=>'Success','errMsg'=>'Response received Successfully','token'=>'');   
                            return response()->json($result);
                        }
                        $result             =   array('result'=>400,'status'=>0,'msg'=>'Error','errMsg'=>'Response is not received Successfully','token'=>$token.' is not valid token');   
                        return response()->json($result);
                    }
                    $result             =   array('result'=>400,'status'=>0,'msg'=>'Error','errMsg'=>'Invalid response format','token'=>'');   
                    return response()->json($result);
                }
            }
        } catch (Exception $ex) {
            $result             =   array('result'=>400,'status'=>0,'errMsg'=>$ex->getMessage());   
            return response()->json($result);
        }
        
    }
}
