<?php

namespace App\Http\Controllers\users;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Redirect;
use Config;
use Session;
use Validator;
use PDF;
use DB; 


class usersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        parent::__construct();
            $this->loginUserId  =   Session::get('users')['user_id'];
            $this->teamId       =   Session::get('users')['team_id'];
            $this->roleId       =   Session::get('users')['role_id'];
            $this->empId        =   Session::get('users')['emp_id'];
            $this->userName     =   Session::get('users')['user_name'];
            $this->roleName     =   Session::get('users')['role_name'];
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                //return redirect('/');
            }
            return $next($request);
        });
    }

    public function getAmUserList(){
        
        $userList       =       array();
        $roleid           =       \Config::get('constants.AM');
        
        $rawinput       =       array( Db::RAW( "concat( u.FIRST_NAME , ' ' , u.LAST_NAME ) as userName ")  , 'u.USER_ID as userId' , 'r.NAME as ROLE_NAME' );
        
        $UserDetails = DB::table('user AS u')
                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
                ->where( 'ROLE' , 'LIKE', '%'.$roleid.'%')
                ->select( $rawinput )
                ->get();
        
        //Do bussiness logic here if needed
        
        echo json_encode( $UserDetails );
        
    }
    
    public function getPmUserList(){
        
        $userList       =       array();
        $roleid           =       \Config::get('constants.PM');
        
        $rawinput       =       array( Db::RAW( "concat( u.FIRST_NAME , ' ' , u.LAST_NAME ) as userName ")  , 'u.USER_ID as userId' , 'r.NAME as ROLE_NAME' );
        
        $UserDetails = DB::table('user AS u')
                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
                ->where( 'ROLE' , 'LIKE', '%'.$roleid.'%')
                ->select( $rawinput )
                ->get();
        
        //Do bussiness logic here if needed
        
        echo json_encode( $UserDetails );
        
    }
    
    public function getUserInfoByUserId( $user_id ){
        
        $userList       =       array();
        //$roleid           =       \Config::get('constants.PM');
        
        $rawinput       =       array( Db::RAW( "concat( u.FIRST_NAME , ' ' , u.LAST_NAME ) as userName ")  , 'u.USER_ID as userId' , 'r.NAME as ROLE_NAME' );
        
        $UserDetails = DB::table('user AS u')
                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
                ->where( 'u.USER_ID' , '=', $user_id )
                ->select()
                ->get()->first();
        
        return ( $UserDetails );
        
    }
    
    
     public function getCountryId( $countryId ){
        
        $userList       =       array();
            
        $UserDetails = DB::table('countries AS c')
                ->where( 'c.id' , '=', $countryId )
                ->select()
                ->get()->first();
        
        return ( $UserDetails );
        
    }
    
    
    
    
}