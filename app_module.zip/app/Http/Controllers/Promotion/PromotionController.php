<?php

namespace App\Http\Controllers\Promotion;

use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\bookinfoModel;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\requiredConstants;
use App\Models\jobRound;
use App\Models\jobStage;
use App\Models\workflowServerMapPathModel;
use App\Models\productionLocationModel;
use App\Models\componentCategoryModel;
use App\Models\componentSubCategoryModel;
use App\Models\chapterClientNameModel;
use App\Models\ChapterPromotion as CPModel;
use App\Models\taskLevelUserdefinedWorkflow;
use App\Models\roundModel;
use App\Models\fileHandler;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\production\movetoproductionController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB;

class PromotionController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index(Request $request) {
        $data = array();
        $sourceview = componentCategoryModel::Promotionactive()->get();
        $this->displayMenuName(Config::get('menuconstants.MENU.PROMOTION'),$data);
        $booksinfo = bookinfoModel::allBookinfo();
        $booksOpt = '<option value="">--Select--</option>';
        foreach ($booksinfo as $key => $value) {

            $booksOpt .= '<option data-bookid="'.$value['BOOK_ID'].'" value="'.$value['JOB_ID'].'">';
            $booksOpt .= $value['BOOK_ID'];
            $booksOpt .= '</option>';
        }
        $sourceOpt = '<option value="">--Select--</option>';
        foreach ($sourceview as $key => $value) {

            $sourceOpt .= '<option value="'.$value->ID.'" data-codeid="'.$value['CODE'].'">';
            $sourceOpt .= $value->NAME;
            $sourceOpt .= '</option>';
        }
        
        $rounddata = roundModel::Active()
//                ->whereIn('ID',[$this->round_ID_300,$this->round_ID_600])
                ->get();
        $roundOpt = '<option value="">--Select--</option>';
        foreach ($rounddata as $key => $value) {

            $roundOpt .= '<option value="' . ($value->ID) . '">';
            $roundOpt .= $value->NAME;
            $roundOpt .= '</option>';
        }
        
        $data['bookidCollect'] = $booksOpt;
        $data['sourceview'] = $sourceOpt;
        $data['round'] = $roundOpt;
        
        return view('Promotion.index')->with($data);
    }
    
    public function jobWorkflowlist(Request $request) {
        try {
            $validation =   Validator::make($request->all(), [
                            'jodId' => 'required|numeric',
                            'roundId' => 'required|numeric'
                            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }

            $jobId = $request->input('jodId');
            $roundId = $request->input('roundId');
            $wheredata              =   ['JOB_ID'=>$jobId,'ROUND'=>$roundId];
            $getexitdata            =   taskLevelUserdefinedWorkflow::select(DB::raw(' task_level_userdefined_workflow.WORKFLOW_MASTER_ID,wrf.WORKFLOW_MASTER_NAME '))->where($wheredata)
                                        ->join('workflow_master as wrf','wrf.WORKFLOW_MASTER_ID','=','task_level_userdefined_workflow.WORKFLOW_MASTER_ID')    
                                        ->groupby('WORKFLOW_MASTER_ID')->get();
            $response   =   $this->successResponse;
            $response['workflowlist']   =   $getexitdata;
            return response()->json($response);
            } catch (\Exception $e) {
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
    public function viewProcessStage(Request $request) {
        try {
            $validation =   Validator::make($request->all(), [
                            'jodId' => 'required|numeric'
                            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }

            $jobId = $request->input('jodId');
            $jobdata    =   jobInfoModel::select(DB::raw('WORKFLOW_TYPE'))->where('job_ID',$jobId)->first();
            if($jobdata     ==  null){
                $response   =   $this->notfoundResponse;
                $response['errMsg']   =   "WorkFlow not found..";
                return response()->json($response);
            }
            
            $workflowId = $jobdata->WORKFLOW_TYPE;
             $wheredata              =   ['JOB_ID'=>$jobId,'udwf.WORKFLOW_MASTER_ID' =>$workflowId];
            $checkexitdata          =   taskLevelUserdefinedWorkflow::from('task_level_userdefined_workflow as udwf')->select(DB::raw('s.STAGE_ID,s.STAGE_NAME,udwf.WORKFLOW_TYPE,udwf.ROUND,udwf.WORKFLOW_MASTER_ID,wrf.WORKFLOW_MASTER_NAME,udwf.STAGE'))->where($wheredata)
                                        ->join('stage as s','s.STAGE_ID','=','udwf.STAGE')    
                                        ->join('workflow_master as wrf','wrf.WORKFLOW_MASTER_ID','=','udwf.WORKFLOW_MASTER_ID')
                                        ->where('udwf.WORKFLOW_TYPE','!=',2)
                                        ->where('udwf.IS_AUTO',0)
                                        ->orderBy('udwf.STAGE_SEQ')
                                        ->get();
            
            $workflowlist           =   taskLevelUserdefinedWorkflow::from('task_level_userdefined_workflow as udwf')->select(DB::raw('w.WORKFLOW_ID,udwf.ROUND,udwf.WORKFLOW_MASTER_ID,wrf.WORKFLOW_MASTER_NAME,udwf.STAGE'))->where($wheredata)
                                        ->join('workflow_master as wrf','wrf.WORKFLOW_MASTER_ID','=','udwf.WORKFLOW_MASTER_ID')    
                                        ->join('workflow as w','w.WORKFLOW_MASTER_ID','=','udwf.WORKFLOW_MASTER_ID')    
                                        ->where('udwf.WORKFLOW_TYPE','!=',2)
                                        ->where('udwf.IS_AUTO',0)
                                        ->where('w.WORKFLOW_TYPE',0)
                                        ->groupBy('WORKFLOW_MASTER_ID')
                                        ->get();
            $getprocess             =   $checkexitdata->pluck('STAGE')->toArray();
            $roundId                =   (count($checkexitdata)>=1?$checkexitdata[0]->ROUND:'');
            $workflowtype           =   (count($checkexitdata)>=1?$checkexitdata[0]->WORKFLOW_TYPE:'');
            $workflowId             =   (count($workflowlist)>=1?$workflowlist[0]->WORKFLOW_ID:'');
            $response   =   $this->successResponse;
            $response['workflowId'] =   $workflowId;        
            $response['workflowtype']   =   $workflowtype;        
            $response['stage']          =   $roundId;        
            $response['workflowname']   =   $workflowlist;        
            $response['process']        =   $checkexitdata;        
            return response()->json($response);
            } catch (\Exception $e) {
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
    public function InputChapterNumberValidation($inputChapter){
        $result     =   '';
        $inputChapter   =   rtrim($inputChapter,',');
        $inputChapter   =   ltrim($inputChapter,',');
        $newArraychapter    =   [];
        $newArraynumbers    =   [];
        if((strpos($inputChapter,',') !== false || strpos($inputChapter,'-') !== false) && strpos($inputChapter,'--') === false){
            $newchapters    =   explode(',',$inputChapter);
            if(in_array('',$newchapters)){
                return $result  =   false;
            }else{
                // same value is repeating or not
                $checksamenumberisrepeatornot   = array_count_values($newchapters);
                if(count($checksamenumberisrepeatornot)>=1){
                    if(in_array(2,$checksamenumberisrepeatornot)){
                        return $result  =   false;
                    }
                }
                
                // check number is repeating or not
                if(count($newchapters)>=1){
                    foreach ($newchapters as $value){
                        
                        if(strpos($value,'-') === false){
                            $newArraychapter[]  =   $value;
                        }
                        
                        if(strpos($value,'-') != false){
                            $splitvalue     =   explode('-',$value);
                            if(isset($splitvalue[2])){
                                return $result  =   false;
                            }
                            if($splitvalue[1] >= $splitvalue[0]){
                                for($i  =  $splitvalue[0];$i<=$splitvalue[1];$i++){
                                    $newArraychapter[]  =   $i;
                                }
                            }else{
                                return $result  =   false;
                            }
                        } 
                    }
                }
                return $newArraychapter;
            }
        }else if(strpos($inputChapter,'--') != false){
            $newchapters    =   explode(',',$inputChapter);
            if(in_array('',$newchapters)){
                return $result  =   false;
            }else{
                $result  =   true;
            }
        }else{
            $newArraychapter[]  =   $inputChapter;
            return $newArraychapter;
        }
        return $result;
    }
    
    public function InputFmBmChapterNumberValidation($inputChapter){
        $result     =   '';
//        $inputChapter   =   rtrim($inputChapter,',');
//        $inputChapter   =   ltrim($inputChapter,',');
        $newArraychapter    =   [];
        $newArraynumbers    =   [];
        if((strpos($inputChapter,',') == true || strpos($inputChapter,'-') == true || strpos($inputChapter,'--') == true)){
            return $result  =   false;
        }else{
            $newArraychapter[]  =   $inputChapter;
            return $newArraychapter;
        }
        return $result;
    }
    
    public function addPromotionChapter(Request $request) {
       // try {
        
            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'inputChapter' => 'required',
                        'compenentCategory' => 'required|numeric',
                        'stage' => 'required|numeric',
                        'workflow' => 'required|numeric',
                        'currentStage' => 'required|numeric'
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }

            $jobId = $request->input('jobId');
            $inputChapter = $request->input('inputChapter');
            $compenentCategory  =   $request->input('compenentCategory');
            
            $compenentType  =   $request->input('compenentType');
            $workflow  =   $request->input('workflow');
            $process  =   $request->input('process');
            $workflowtype       =   $request->input('workflowtype');
           
           
            if(!empty($compenentType)){
               
             $componentdetails   =   componentSubCategoryModel::where('COMPONENT_ID',$compenentType)->Active()->first();
            
            }else{
              $componentdetails   =   componentCategoryModel::Active()->find($compenentCategory);
            }
            
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills = jobModel::where('JOB_ID', $jobId)->first();
            $clientnamecode     =   ($componentdetails != null?$componentdetails->CODE:'');
            
            $getclientname  =   chapterClientNameModel::where('COMPONENT_CODE',$clientnamecode)->Magnusactive()->first();
            
            $userprocessfolder  =   Config::get('serverconstants.CHAPTER_PROMOTION');
            $getfileconstant   =   requiredConstants::where('CONSTANT_NAME',$userprocessfolder)->first();
            $workflowtype   =   ($workflowtype  ==  0?'0':$workflowtype);
           
            if (count($getlocationftp) >= 1 && $bookdetaills != null && $componentdetails != null && $getclientname != null && $getfileconstant != null) {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                
                $ftpObj = \Storage::createFtpDriver([
                                'host' => $hostserver,
                                'username' => $hostusername,
                                'password' => $hostpassword,
                                'port' => '21',
                                'timeout' => '30',
                    ]);
                
                $newchapternames    =   [];
                $inputresult    =   $this->inputNumberFormatvalidation($inputChapter,$clientnamecode);
                if(isset($inputresult['status']) && $inputresult['status']  ==  0){
                    return response()->json($inputresult);
                }
                //full name preparation
                foreach ($inputresult['values'] as $value){
                    $newchapternames[]  =   $bookid.$getclientname->NAME.$value;
                }
                
                if($clientnamecode  == '#INDEX'){
                    $newchapternames = array();
                    $newchapternames[]  = 'INDEX';
                }
             
//                //check exist chapter promotion
                if(count($newchapternames)>=1){
                    $wheredata  =   ['JOB_ID'=>$jobId];
                    $checkexistchapters =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.JOB_ID,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_NAME'))->Active()
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                                ->where($wheredata)
                                                                ->wherein('task_level_metadata.CHAPTER_NO',$newchapternames)
								->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->get();   
                    if(count($checkexistchapters)>=1){
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   'Below Chapter is already exist !';
                        $response['validationerror']    =   'Below Chapter is already exist !';
                        $response['existchapter']   =   $checkexistchapters->pluck('CHAPTER_NO')->toArray();
                        $response['chapternames']   =   $newchapternames;
                        return response()->json($response);
                    }
                }
                
                $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                $userprocessfolder  =   $getfileconstant->CONSTANT_VALUE;
                $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                $getempId  =   $this->empId;
                $crd = "ftp://$hostusername:$hostpassword@";
                $userWorkDir        =   \Config::get('constants.USER_WORK_PATH');
                $cmn_obj = new CommonMethodsController();
                 $array = array(
                                    'USER_DIR' => $getempId
                                );
                $userWorkDir    =   $cmn_obj->arr_key_value_replace($array, $userWorkDir);
                $open_path     =   $hostserver.$ftp_root_dir.$hostpath.$userWorkDir.$bookid.'/'.$userprocessfolder;              
                //promotion path is exist or not
                $checkpromotionpath     =   $hostpath.$userWorkDir.$bookid.'/'.$userprocessfolder;
                if($ftpObj->has($checkpromotionpath)){
                }else{
                    $ftpObj->makeDirectory($checkpromotionpath,0777);
                }
                
                $postdata = [];
                $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                $postdata['system_ip'] = $request->ip();
                $postdata['method_name'] = "doOpenDriveServer";
                $postdata['processname'] = "checkout";
                $insertfilehandler = fileHandler::insertNew($postdata);

                if ($insertfilehandler) {
                    $response           =   $this->successResponse;
                    $response['errMsg'] = 'File open initialized..';
                    $response['rmID']   =   $insertfilehandler;
                    $response['validationerror'] = '';
                    $response['existchapter'] = [];
                    $response['chapternames'] = $newchapternames;
                    return response()->json($response);
                }
                return response()->json($this->fileNotCopiedResponse);
            }
            return response()->json($this->locationNotFoundResponse);
        /*} catch (\Exception $e) {
            return response()->json($this->locationNotFoundResponse);
        }*/
    }
    
    public function inputNumberFormatvalidation($inputChapter,$clientnamecode){
        $result['result']   =   "";
        $result['errMsg']   =   "";
        $result['status']   =   "";
//        if($clientnamecode  ==  "#CHAPTER" || $clientnamecode  ==  "#PART")
        $inputresult    =   $this->InputChapterNumberValidation($inputChapter);
//        else
//        $inputresult    =   $this->InputFmBmChapterNumberValidation($inputChapter);
        if($inputresult     ==  false){
            $result             =   $this->oopsErrorResponse;
            $result['errMsg']   =   'Input chapter format is invalid, ex : 1,5-8,10 !';
            return $result;
        }
        if(count($inputresult)  ==  0){
            $result             =   $this->oopsErrorResponse;
            $result['errMsg']   =   'Input chapter is empty';
            return $result;
        }
        //find repeating numbers
        $repeatingnumbers   =   array_count_values($inputresult);

        if(in_array(2,$repeatingnumbers)){
            $result             =   $this->oopsErrorResponse;
            $result['errMsg']   =   'Input chapter number is repeating, Kindly check it,for ex : 1,5-8,10 !';
            return $result;
        }
        $result['status'] = 1;
        $result['values'] = $inputresult;
        return $result;
    }
    
    public function submitPromotionChapter(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'jobId' => 'required|numeric',
                        'inputChapter' => 'required',
                        'compenentCategory' => 'required|numeric',
                        'stage' => 'required|numeric',
                        'process' => 'required|numeric',
                        'workflow' => 'required|numeric',
                        'currentStage' => 'required|numeric',
                        'chapterName' => "required|array|min:1",
                        'chapterName.*' => "required|distinct|min:1",
                        'chapterTitle' => "required|array|min:1",
                        'chapterTitle.*' => "required|min:1",
                        'msPages' => "required|array|min:1",
                        'msPages.*' => "required|min:1",
            ]);

            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $jobId = $request->input('jobId');
            $inputChapter = $request->input('inputChapter');
            $compenentCategory  =   $request->input('compenentCategory');
            $compType       =   $request->input('compType');
           
            $chapterName        =   $request->input('chapterName');
            $chapterTitle       =   $request->input('chapterTitle');
            $workflow       =   $request->input('workflow');
            $stage       =   $request->input('stage');
            $msPages       =   $request->input('msPages');
            $workflowtype       =   $request->input('workflowtype');
            $workflowtype   =   ($workflowtype  ==  0?'0':$workflowtype);
            $process       =   $request->input('process');
            $waitingProcess  = 0;
            $subcomCategory  = 0;
            if($compenentCategory != 2){
                
                $subcomCategory = 1;
                if($compType == 6 && $stage == '119' ){
                   $waitingProcess = 1;
                   $waitingProcess = 0;
                }
            }
            
            
            //check workflow stage 
            $checkexiststageactivity    =   DB::table('workflow_stage_activity')->where(['WORKFLOW'=>$workflow,'STAGE'=>$process])->first();
            if($checkexiststageactivity     ==  null){
                $response   =   $this->notfoundResponse;
                $response['errMsg']     =   'Your current process is not in work stage activity';
                return response()->json($response);
            }
            //check workflow server map path and previous stage
            $wheredata              =   ['udwf.JOB_ID'=>$jobId,'udwf.ROUND'=>$stage,'udwf.WORKFLOW'=>$workflow,'udwf.STAGE'=>$process,'wsm.JOB_ID'=>$jobId,'wsm.ROUND_ID'=>$stage,'wsm.WORKFLOW_ID'=>$workflow,'wsm.STAGE_ID'=>$process];
            $workflowservermap_obj  =   new workflowServerMapPathModel();
            $workflowservermappath  =   $workflowservermap_obj->checkWorkflowservermapandTaskLeveluserdefinedWorkflow($wheredata);
            if($workflowservermappath    ==  null){
                $response   =   $this->notfoundResponse;
                $response['errMsg']     =   'Your current process is not in work stage activity';
                return response()->json($response);
            }
            if($subcomCategory  == 1){
                 $componentdetails   =   componentSubCategoryModel::where('COMPONENT_ID',$compType)->Active()->first();
               
            }else{
                $componentdetails   =   componentCategoryModel::Active()->find($compenentCategory);
            }
          
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills = jobModel::getJobdetails($jobId);
            $clientnamecode     =   ($componentdetails != null?$componentdetails->CODE:'');
            $getclientname  =   chapterClientNameModel::where('COMPONENT_CODE',$clientnamecode)->Magnusactive()->first();
            $promotionfolder  =   Config::get('serverconstants.CHAPTER_PROMOTION');
            $getfileconstant   =   requiredConstants::where('CONSTANT_NAME',$promotionfolder)->first();
            if (count($getlocationftp) >= 1 && $bookdetaills != null && count($bookdetaills) >= 1 && $componentdetails != null && $getclientname != null && $getfileconstant != null) {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver = $getlocationftp->FTP_HOST;
                $hostusername = $getlocationftp->FTP_USER_NAME;
                $hostpassword = Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath = $getlocationftp->FTP_PATH;
                
                $ftpObj = \Storage::createFtpDriver([
                                'host' => $hostserver,
                                'username' => $hostusername,
                                'password' => $hostpassword,
                                'port' => '21',
                                'timeout' => '30',
                    ]);
                $deadline_array     =   json_decode( $bookdetaills->STAGE_DEADLINES_COLLECTION,true);
                if(count($deadline_array)>=1){
                    
                    $getroundstage  =   Config::get('constants.ROUND_NAME')[$stage];
                    $duedate    =   $deadline_array[$getroundstage];
                }else{
                    $duedate    =   date("Y-m-d");
                }
				
				$duedate    =   (empty($duedate)?date("Y-m-d"):$duedate);
                
                $newchapternames    =   [];
                $inputresult    =   $this->inputNumberFormatvalidation($inputChapter,$clientnamecode);
                
                
                if(isset($inputresult['status']) && $inputresult['status']  ==  0){
                    return response()->json($inputresult);
                }
                //full name preparation
                foreach ($inputresult['values'] as $value){
                    $newchapternames[]  =   $bookid.$getclientname->NAME.$value;
                }
                if($clientnamecode  == '#INDEX'){
                    $newchapternames = array();
                    $newchapternames[]  = 'INDEX';
                }
           
                //check exist chapter promotion
                if(count($newchapternames)>=1){
                    $wheredata  =   ['JOB_ID'=>$jobId];
                    $checkexistchapters =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.JOB_ID,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_NAME'))->Active()
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                                ->where($wheredata)
                                                                ->wherein('task_level_metadata.CHAPTER_NO',$newchapternames)
								->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->get();   
                    if(count($checkexistchapters)>=1){
                        $response   =   $this->notfoundResponse;
                        $response['errMsg']     =   'Below Chapter is already exist !';
                        $response['validationerror']    =   'Below Chapter is already exist !';
                        $response['existchapter']   =   $checkexistchapters->pluck('CHAPTER_NO')->toArray();
                        $response['chapternames']   =   $newchapternames;
                        return response()->json($response);
                    }
                }
                
                $ftp_obj = new ftpFileHandlerController($hostserver, $hostusername, $hostpassword);
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                $userprocessfolder  =   $getfileconstant->CONSTANT_VALUE;
                $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                $getempId  =   $this->empId;
                $crd = "ftp://$hostusername:$hostpassword@";
                $userWorkDir        =   \Config::get('constants.USER_WORK_PATH');
                $cmn_obj = new CommonMethodsController();
                $array = array(
                                    'USER_DIR' => $getempId
                                );
                $userworkfolder    =   $cmn_obj->arr_key_value_replace($array, $userWorkDir);
                $open_path     =   $crd.$hostserver.$hostpath.$userworkfolder.$bookid.'/'.$userprocessfolder;
                $serverDirFiles     =   $ftp_obj->getDirectoryFiles( $open_path );
                 $nofiles = 0;
                if(count($serverDirFiles ) == 0 && $compenentCategory != 2 ){
                     $nofiles = 1;
                }else{
                    if(count($serverDirFiles)   ==  0 ){
                        $nofiles = 1;
                        return response()->json($this->nofileResponse);
                    }
                    // validate equal chapter or not
                    if(count($serverDirFiles)   !=  count($newchapternames) && $nofiles == 0){
                        $response   =   $this->notfoundResponse;
                        $response['errMsg']     =   'Chapter File is mismatch which is given input chapter number and file, Kindly correct it !';
                        return response()->json($response);
                    }

                    $chapternewArray    =   [];
                    $chaptersplit   =   "";

                    foreach($serverDirFiles as $key=>$value){
                        $chaptersplit   =   substr(strrchr($value,'/'),1);
                        $chapternewArray[]  =   substr($chaptersplit,0, strrpos($chaptersplit, '.'));
                    }
                    // validate chapter file 
                    $findDiffchapter    =   array_diff($chapternewArray,$newchapternames);
                    natcasesort($findDiffchapter);
                    if(count($findDiffchapter)>=1){
                        $response['errMsg']     =   'Kindly correct invalid chapter names !';
                        $response['validationerror']    =   'Kindly correct invalid chapter names !';
                        $response['existchapter']   =   $findDiffchapter;
                        return response()->json($response);
                    }
                }   
                //file copy
                $promotionfolder    =   Config::get('constants.STAGE_NAME.SPLIT');
                $preprocessfolder   =   Config::get('constants.SPLIT_DESTINATION_PATH');
                $array = array(
                                'BOOK_ID' => $bookid,
                                'STAGE_NAME' => $promotionfolder
                            );
                $promotiondesfolder     =   $cmn_obj->arr_key_value_replace($array, $preprocessfolder);
                $desDir     =   $hostserver.$hostpath.$promotiondesfolder;
                $sourcepath     =   $open_path;
               
                if($nofiles == 0){
                    $response_copy  =   $ftp_obj->ftp_dir_copy($sourcepath, $desDir);
                    if(count($response_copy)>=1){
                        if(in_array('failed',$response_copy)){
                            return response()->json($this->fileNotCopiedResponse);
                        }
                    }
                }
                
                $chaptertype    =   '';
                switch($compenentCategory){
                    case 1:
                        $chaptertype =  1;
                        break;
                    case 2:
                        $chaptertype =  2;
                        break;
                    case 3:
                        $chaptertype =  3;
                        break;
                    case 4:
                        $chaptertype =  4;
                        break;
                    case 5:
                        $chaptertype =  5;
                        break;
                    case 6:
                        $chaptertype =  6;
                        break;
                    
                    default:
                        $chaptertype =  1;
                        break;
                }
                
                DB::beginTransaction();
                //insert metadata
                $insertdata     =   [];
                $insertrec      =   [];
                $insertMiStatus =   [];
                $lastId         =   '';
                $insertgetId    =   [];
                foreach($newchapternames as $key=>$value){
                    $insertdata['CHAPTER_NO']       =   $value;
                    $insertdata['CHAPTER_NAME']     =   $chapterTitle[$key];
                    $insertdata['JOB_ID']           =   $jobId;
                    $insertdata['CREATED_BY']       =   $this->loginUserId;
                    $insertdata['UNIT_OF_MEASURE']  =   Config::get('constants.CHAPTER_ENUM_ID');
                    $insertdata['CURRENT_ROUND']    =   Config::get('constants.ROUND_ID.S5');
                    $insertdata['IS_ACTIVE']        =   true;
                    $insertdata['CREATED_DATE']     =   Carbon::now();
                    $insertdata['QUANTITY']         =   '1';
                    $insertgetId[]  =   $lastId     =   taskLevelMetadataModel::insertGetId($insertdata);
                    if($lastId){
                        $insertrec['METADATA_ID'] =   $lastId;   
                        $insertrec['FM_ARTICLE_BM'] =   $chaptertype;   
                        $insertrec['NO_MSP'] =   $msPages[$key];   
                        $insertrec['CHAPTER_PROMOTION'] =  true;   
                        $insertMiStatus[]           =       DB::table('metadata_info')->insertGetId($insertrec);
                    }
                }
              
                $extn           =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                $filecopymessage    =   [];
                if(count($insertgetId)>=1){
                    $getallstageId  =   $this->movetoprocure($insertgetId,$jobId,$stage,$workflow,$workflowtype,$process,$msPages,$duedate,$waitingProcess);
                   
                    if(count($getallstageId)>=1 && $stage   !=  Config::get('constants.ROUND_ID.S5')){
                        foreach($getallstageId as $key=>$jobstageId){
                            $getpathfile    =   $workflowservermap_obj->getWorkflowServerMapPath($jobstageId,0,0,0);
               
                            if(count($getpathfile)>=1 && $getpathfile['status']  ==  1 && isset($getpathfile['detail']) && $nofiles == 0 ){
                                $destDir        =   $getpathfile['detail']['src'];
                                $response_copy  =   $ftp_obj->ftp_dir_copy_word_file_only($sourcepath, $destDir,[$newchapternames[$key]],$extn);
                                $filecopymessage[]  =   $response_copy;
                            }
                        }
                    }
                }
                
                if(count($filecopymessage)>=1 && $nofiles == 0){
                    foreach($filecopymessage as $key=>$value){
                        if(in_array('failed',$filecopymessage[$key])){
                            DB::rollback();
                            return response()->json($this->fileNotCopiedResponse);
                        }
                    }
                }
                
                $insertdata     =   [];
                $wheredata  =   ['JOB_ID'=>$jobId];
                $encodepromotionId      =   json_encode($insertgetId);
                $insertdata['PROMOTION_ID']   =   $encodepromotionId;
                $insertdata['JOB_ID']   =   $jobId;
                $insertdata['CREATED_BY']   =   $this->loginUserId;
                $chpemaillogchapters     =   CPModel\chapterPromotionEmailLogModel::insertGetId($insertdata);
                
                if(count($insertMiStatus) != count($insertgetId)){
                    DB::rollback();
                    return response()->json($this->insertedFailedResponse);
                }
                DB::commit();
                if($nofiles == 0 ){
                    if(count($response_copy)>=1   ){
                        if(in_array('failed',$response_copy)){
                            DB::rollback();
                            return response()->json($this->fileNotCopiedResponse);
                        }
                    }
                }
                if($chpemaillogchapters){
                    $this->sendPromotionMail($bookdetaills,$newchapternames,$chpemaillogchapters);
                }
                
                $response   =   $this->successResponse;
                $response['errMsg'] = 'Chapter promotion is completed for '.$bookid;
                return response()->json($response);
            }
            return response()->json($this->locationNotFoundResponse);
        } catch (\Exception $e) {
            $result = array('result' => 404, 'errMsg' => $e->getMessage());
            return response()->json($result);
        }
    }
    
    public function movetoprocure($insertgetId,$jobId,$stage,$workflow,$workflowtype,$process,$msPages,$duedate,$waitingProcess){
        $currentprocessJobStageId   =   [];
        $movproj_obj    =   new movetoproductionController();
        foreach($insertgetId as $key=>$metavalue){
            if($stage   !=  Config::get('constants.ROUND_ID.S5')){
                $movproj_obj->taskLevelMoveToProductionProcedure($jobId,$stage,$workflow,$metavalue,$msPages[$key],$duedate,$workflowtype,$this->loginUserId);
                //update job round and job stage process
                $wheredataofjround  =   ['METADATA_ID'=>$metavalue,'ROUND_ID'=>$stage];
                $getjobround    =   jobRound::where($wheredataofjround)->first();
                if($getjobround!=   null){
                    $wherecurjobround  =   ['METADATA_ID'=>$metavalue,'ROUND_ID'=>$stage,'STAGE_ID'=>$process];
                    $currentjobstageId  =   jobRound::select(DB::raw('js.JOB_STAGE_ID,js.STAGE_SEQ,js.STATUS'))->join('job_stage as js','js.JOB_ROUND_ID','=','job_round.JOB_ROUND_ID')->where($wherecurjobround)->first();
                    $currentprocessJobStageId[]     =   ($currentjobstageId !=  null?$currentjobstageId->JOB_STAGE_ID:''); 
                    $alljobstage    =   jobRound::select(DB::raw('js.STAGE_SEQ,js.STATUS'))->join('job_stage as js','js.JOB_ROUND_ID','=','job_round.JOB_ROUND_ID')->where($wheredataofjround)->get();
                    if(count($alljobstage)>=1){
                        $updatedata     =   ['STATUS'=>Config::get('constants.STATUS_ENUM_COLLEECTION.NEWACTIVITY')];
                        $getstageseq    =   jobStage::where('JOB_ROUND_ID',$getjobround->JOB_ROUND_ID)->update($updatedata);
                        //update current process
                        if($waitingProcess  == 1){
                           $updatecurrent  =   ['STATUS'=>Config::get('constants.STATUS_ENUM_COLLEECTION.WAITINGFORPARALLEL')]; 
                        }else{
                            $updatecurrent  =   ['STATUS'=>Config::get('constants.STATUS_ENUM_COLLEECTION.AVAILABLE')];
                        }
                        $wherestage     =   ['STAGE_ID'=>$process,'JOB_ROUND_ID'=>$getjobround->JOB_ROUND_ID];
                        $getstageseq    =   jobStage::where($wherestage)->update($updatecurrent);
                    }
                    //update current stage
                    $getjobround->CURRENT_STAGE     =   $process;
                    $getjobround->save();
                }
            }else{
                $movproj_obj->triggerTasklevelMoveToproduction($jobId,$stage);
            }
        }
        return $currentprocessJobStageId;
    }
    
    public function userOpenDrive(Request $request)
    {
        try
        {
            $validation             =   Validator::make($request->all(), [
                                                'jobId' 	=> 'required|numeric'
                                        ]);
            if ($validation->fails())
            {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId              =   $request->input('jobId');
            //get location for exist job id
            $getlocationftp = productionLocationModel::doGetLocationname($jobId);
            $bookdetaills   = jobModel::getJobdetails($jobId);
            $promotionfolder  =   Config::get('serverconstants.CHAPTER_PROMOTION');
            $getfileconstant   =   requiredConstants::where('CONSTANT_NAME',$promotionfolder)->first();
            if(count($getlocationftp)>=1 && $getfileconstant != null && $bookdetaills !=    null)
            {
                $bookid = $bookdetaills->BOOK_ID;
                $hostserver     =   $getlocationftp->FTP_HOST;
                $hostusername   =   $getlocationftp->FTP_USER_NAME;
                $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   $getlocationftp->FTP_PATH;
                $domuser = $getlocationftp->FILE_SERVER_USER_NAME;
                $domPass = $getlocationftp->FILE_SERVER_PASSWORD;
                // Do the FTP connection
                $ftpObj             =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                //file open path
                $userprocessfolder  =   $getfileconstant->CONSTANT_VALUE;
                $ftp_root_dir       =   rtrim(Config::get('serverconstants.FILE_SERVER_ROOT_DIR'),'/');
                $getempId  =   $this->empId;
                $crd = "ftp://$domuser:$domPass";
                $userWorkDir        =   \Config::get('constants.USER_WORK_PATH');
                $cmn_obj = new CommonMethodsController();
                 $array = array(
                                    'USER_DIR' => $getempId
                                );
                $userWorkDir    =   $cmn_obj->arr_key_value_replace($array, $userWorkDir);
                $open_path     =   $hostserver.$ftp_root_dir.$hostpath.$userWorkDir.$bookid.'/'.$userprocessfolder;              
                //promotion path is exist or not
                $checkpromotionpath     =   $hostpath.$userWorkDir.$bookid.'/'.$userprocessfolder;
                if($ftpObj->has($checkpromotionpath)){
                }else{
                    $ftpObj->makeDirectory($checkpromotionpath,0777);
                }
                $postdata = [];
                $postdata['file_path'] = $open_path . '/<>' . $domuser . '<>' . $domPass;
                $postdata['system_ip'] = $request->ip();
                $postdata['method_name'] = "doOpenDriveServer";
                $postdata['processname'] = "checkout";
                $insertfilehandler = fileHandler::insertNew($postdata);

                if ($insertfilehandler) {
                    $response   =   $this->successResponse;
                    $response['rmID'] = $insertfilehandler;
                    return response()->json($response);
                }
                return response()->json($this->fileNotCopiedResponse);
            }
            return response()->json($this->locationNotFoundResponse);
        }
        catch( \Exception $e )
        {           
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
    public function sendPromotionMail($job_info,$newchapternames,$lastInsertedId) 
    {   
        $mailArray          =   $mailData   =   [];
        if(count($job_info)>=1){
            $book_id    =   $job_info->BOOK_ID;
            $pm_userid          =   $job_info->PM;
            $am_userid          =   $job_info->AM;
            $jobId              =   $job_info->JOB_ID;
            if( !empty( $pm_userid ) ){
               $usrC_obj        =   new usersController();
               $user_arr        =   $usrC_obj->getUserInfoByUserId($pm_userid); 
               $pm_name         =   $user_arr->FIRST_NAME.' '.$user_arr->MIDDLE_NAME.' '.$user_arr->LAST_NAME;
               $pm_mail         =   $user_arr->EMAIL;
               $mailData['ToName']      =   $pm_name;
               $mailArray['ToMail']     =   $pm_mail;
            }else if( !empty( $am_userid )){
                $am_name                =   $job_info->AM_NAME;
                $am_mail                =   $job_info->AM_MAIL;
                $mailData['ToName']     =   $am_name;
                $mailArray['ToMail']    =   $am_userid;
            }else{
                return false;
            }
            $mailData['BookId']         =   $job_info->BOOK_ID;
            $mailData['listofchapter']  =   implode(',',$newchapternames);
            $mailData['BookTitle']      =   $job_info->JOB_TITLE;
            $mailArray['Data']          =   $mailData;
            $mailArray['EMAIL_LOG_ID']  =   $lastInsertedId;
            $mailArray['TemplateName']  =   'emailtemplate.Chapter_Promotion.promotionmail';
            $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
            $mailArray['FromName']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
            $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
            $titlewordname              =   $job_info->JOB_TITLE;
            if(is_array($findwordcount) && isset($findwordcount[2]))
            {
                $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
            }
            $mailArray['ToMail']        =   "vinoth.t@spi-global.com";
            $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_ONLINE.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
            $mailArray['CcMail']        =   array('shamu.shihabudeen@spi-global.com','mohan.m@spi-global.com','ananth.b@spi-global.com'); 
            $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
            $updatedata['TO_EMAIL']   =   $mailArray['ToMail'];
            $updatedata['CC_EMAIL']   =   implode(',',$mailArray['CcMail']);
            CPModel\chapterPromotionEmailLogModel::where($wheredatamail)->update($updatedata);
//            return view('emailtemplate.Chapter_Promotion.promotionmail',$mailData);
            $Response                   =   $this->sendMailBladeTemplate($mailArray);    
            $result                     =   array('result'=>200,'status'=>1,'errMsg'=>"Mail sent successfully");   
            return response()->json($result);
        }
    }
        
    public function sendMailBladeTemplate($mailArray) {
        try {
            if (is_array($mailArray)) {
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '3';
                        CPModel\chapterPromotionEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                        CPModel\chapterPromotionEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/promotionmail.log');
            Log::info( json_encode( $exception->getMessage() ) );
        }        
    }
}
