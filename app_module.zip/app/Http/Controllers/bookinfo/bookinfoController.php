<?php

namespace App\Http\Controllers\bookinfo;

use App\Http\Controllers\Controller;
use App\Models\bookinfoModel;
use App\Models\spicastProfileModel;
use App\Models\productionLocationModel;
use App\Models\customizationModel;
use App\Models\locationModel;
use App\Models\jobRoundModel;
use App\Models\jobRound;
use App\Models\jobModel;
use App\Models\taskLevelMetadataModel;
use App\Http\Controllers\CommonMethodsController;
use App\Models\jobEnumModel;
use App\Http\Controllers\finance\readJobSheetDataController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Validator;
use Carbon\Carbon;
use Config;
use PDF;
use DB; 

class bookinfoController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
	 
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    public function index() {
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.BOOKINFO'),$data);
        $data['workflowurl'] = url('/') . '/assignjobworkflow/';
        $data['user_name'] = $this->userName;
        $data['role_name'] = $this->roleName;
        return view('bookinfo.book-info')->with($data);
    }

    public function getAllBooklist(Request $request) {
        
        $Req            =   (object) $request->input();
        $orderColumn    =   3; //created date column
        if (isset($Req->order) && trim($Req->order[0]['column']) != '') {
            $orderColumn    =   $Req->order[0]['column'];
        }

        $sorting        =   'desc';
        if (isset($Req->order) && trim($Req->order[0]['dir']) != '') {
            $sorting    =   $Req->order[0]['dir'];
        }
            
        $start  =   '';
        if (isset($Req->start) && trim($Req->start) != '' && $Req->start >= 0) {
            $start      =   $Req->start;
        }

        $length     =   false;
        if (isset($Req->length) && $Req->length != -1) {
            $length =   $Req->length;
        }

        $searchStr  =   '';
        if (isset($Req->search) && trim($Req->search['value']) != '') {
            $searchStr  =   trim($Req->search['value']);
        }
        
        $data                   =   bookinfoModel::commonbookinfodetails($start,$length,$searchStr,$orderColumn,$sorting);
        $bookdata               =   array();
        if(isset($data['bookdetails']) && count($data['bookdetails'])>=1){
            foreach ($data['bookdetails'] as $row) {
                $tempArray                  =   array();
                $tempArray['BOOK_ID']       =   $row->BOOK_ID;
                $showauthorname             =   ($row->AUTHOR_NAME   ==  ""?$row->EDITOR_NAME:$row->AUTHOR_NAME);
                $tempArray['JOB_TITLE']     =   '<span  class="pointer" ng-click="bookinfodetails('."'".$row->JOB_ID."'".')">'.$row->JOB_TITLE.' - <span class="authornamestyle">'.$showauthorname.'</span></span>';
                $tempArray['PM_NAME']       =   $row->PM_NAME;
                $tempArray['CREATED_DATE']  =   $row->CREATED_DATE;
                $tempArray['QUERY']         =   '<a ng-click='.'qmsspike("'.$row->JOB_ID.'","'.$this->loginUserId.'","'.$row->BOOK_ID.'","qms")'.' data-toggle="modal" data-target="#qmsModal" class="fa fa-comments-o fa-2x pointer" /></a>';
                $tempArray['SPIKE']         =   '<a ng-click='.'qmsspike("'.$row->JOB_ID.'","'.$this->loginUserId.'","'.$row->BOOK_ID.'","spike")'.' data-toggle="modal" data-target="#spikeModal" class="fa fa-list-ul fa-2x pointer"/></a>';
		$tempArray['JSCOMPARE']         =   '<a title="Compare JobSheet" ng-click='.'compareJs("'.$row->BOOK_ID.'","'.$this->loginUserId.'","'.$row->BOOK_ID.'","JSCOMPARE")'.' data-toggle="modal" data-target="#iframejscompare" class="fa fa-file-code-o fa-2x pointer"/></a>';
                array_push($bookdata, $tempArray);
            }
        }
            
        $Response                       =   array();
        $Response["draw"]               =   $Req->draw;
        $Response["recordsTotal"]       =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["recordsFiltered"]    =   (isset($data['countbookinfo'])?$data['countbookinfo']:0);
        $Response["data"]               =   $bookdata;

        return response()->json($Response);
    }

    public function getBookinfodetails(Request $request, $jobId = null) {

        if ($jobId == null) {
            return redirect('/book_info');
        }
        
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.BOOKINFO'),$data);
        
        $data['pageTitle']  =   'Book Info Details';
        $data['pageName']   =   'Book Info Details';
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $bookdetails        =   bookinfoModel::getBookinfodetails( $jobId );

        if(count($bookdetails) >= 1){
        $bookdetails2       =       $bookdetails[0];
        
        $data['prdloc']     =       productionLocationModel::doGetLocationname($jobId);
        $jbrm_obj           =       new jobRoundModel();
        $jrm_rec            =       $jbrm_obj->getRecordInfo( $jobId );
        
        $milestone          =       array();
        
        if (count($bookdetails) == 0) {
            return redirect('/book_info')->with('Invalid book');
        }
        
        if ($jrm_rec->count() > 0) {
            foreach ($jrm_rec as $key => $value) {
                $round_arr = \Config::get('constants.ROUND_NAME');
                if (isset($round_arr[$value->ROUND_ID]))
                    $milestone[$round_arr[$value->ROUND_ID]] = $value->RECEIVED_DATE;
            }
        }
        
        $data['job_code_id']            =       null;
        $data['job_code_type']          =       null;

        $offSeries = 0;
        if ($bookdetails[0]->JOB_TYPE == 'S200 Of Series' || $bookdetails[0]->JOB_TYPE == 'Series') {
            $offSeries = 1;
        }
        //$authorInfo                 =   explode('|',$bookdetails['0']->AUTHOR_INFORMATION_STYLE);
        //	$authorInfo                 =    $bookdetails['0']->AUTHOR_INFORMATION_STYLE;
        //   $bookdetails['0']->AUTHOR_INFORMATION_STYLE  =   $authorInfo['0'];
        $readJobsheetObj2 = new readJobSheetDataController();

        $readAuthorInfoStyle = $readJobsheetObj2->getJobSheetData($jobId, '','','TechnicalInfo', 0, 'AuthorInformationStyle');
        $data['authorStyleBiography'] = '';
        $data['authorStylePhotograph'] = '';
        if (is_array($readAuthorInfoStyle)) {

            if (isset($readAuthorInfoStyle['@Biography'])) {
                $data['authorStyleBiography'] = $readAuthorInfoStyle['@Biography'];
            }
            if (isset($readAuthorInfoStyle['Biography'])) {
                $data['authorStyleBiography'] = $readAuthorInfoStyle['Biography'];
            }

            if (isset($readAuthorInfoStyle['@Photograph'])) {
                $data['authorStylePhotograph'] = $readAuthorInfoStyle['@Photograph'];
            }
            if (isset($readAuthorInfoStyle['Photograph'])) {
                $data['authorStylePhotograph'] = $readAuthorInfoStyle['Photograph'];
            }
        }

        $readAuthorInfo = '';
        $jsEmpty = 0;
        $readAuthorInfo = $readJobsheetObj2->getJobSheetData($jobId, '', 'AuthorGroup', 0, 'Author');

        if (is_array($readAuthorInfo)) {
            if (in_array('Json string is empty.', $readAuthorInfo)) {
                $jsEmpty = 1;
            }
        }
        $editorFlag = 0;
        // $readAuthorInfo     = array();

        if (!is_array($readAuthorInfo) && $jsEmpty == 0) {
            $readAuthorInfo = $readJobsheetObj2->getJobSheetData($jobId, '', 'EditorGroup', 0, 'Editor');
        }

        $authorName = array();
        if (is_array($readAuthorInfo) && $jsEmpty == 0 && false) {
            foreach ($readAuthorInfo as $key => $authName) {
                if ($editorFlag == 1) {
                    $authorName[] = (isset($authName['EditorName']['GivenName']) ? $authName['EditorName']['GivenName'] : '') . ' ' . (isset($authName['EditorName']['FamilyName']) ? $authName['EditorName']['FamilyName'] : '');
                } else {
                    $authorName[] = (isset($authName['AuthorName']['GivenName']) ? $authName['AuthorName']['GivenName'] : '') . ' ' . (isset($authName['AuthorName']['FamilyName']) ? $authName['AuthorName']['FamilyName'] : '');
                }
            }
        }

        $authorList = '';

        if (count($authorName) >= 1) {
            $authorList = implode(', ', $authorName);
        }
                
        if( count( $bookdetails2 ) ){
            $recinfo    =   DB::select( 'select JOB_CODE_TYPE+0 as JOB_CODE_TYPE FROM job where JOB_ID = '.$jobId );
            $recinfo    =   $recinfo[0];
            
            $data['job_code_id']        =   $bookdetails2->JOB_CODE_ID;
            $data['job_code_type']      =   isset( $recinfo->JOB_CODE_TYPE ) ? $recinfo->JOB_CODE_TYPE : 0;
            
        }

        $data['jobRoundMilestone'] = $milestone;
        $data['book_details'] = $bookdetails;
        $data['location_details'] = locationModel::getAllProductionAreaList();
        $data['projectId'] = $jobId;
        $data['profiles'] = spicastProfileModel::getSpicastlist();
        $data['book_title'] = (count($bookdetails) >= 1 ? $bookdetails[0]->JOB_TITLE : '');
        $data['book_id'] = (count($bookdetails) >= 1 ? $bookdetails[0]->BOOK_ID : '');
        $data['job_id'] = (count($bookdetails) >= 1 ? $bookdetails[0]->JOB_ID : '');
		$data['job_code_type'] = (count($bookdetails) >= 1 ? $bookdetails[0]->JOB_CODE_TYPE : '');
        $data['authorList'] = $authorList;

        $data['isOfseries'] = $offSeries;
        $booklocation = bookinfoModel::getBooklocation();
        $data["bookcategory"] = jobEnumModel::where(['FIELD_ENUM'=>'1','STATUS'=>'1'])->get();
        $data["booklocation"] = $booklocation;
        $data["embbedtypes"] = Config::get('constants.BOOK_EMBBED_TYPE');
        $customizationModelObj = new customizationModel();
        $data['workflowDetails'] = $customizationModelObj->getjobAssignedWorkflow($jobId);
        $rolerestrict = Config::get('constants.MANAGER_ROLE_ID');
        $data['workflowenable'] = ((in_array(Session::get('users')['role_id'], $rolerestrict) == true) ? 0 : 1);

        $ampmrole = Config::get('constants.CONSOLIDATE_MANAGER_ROLE_ID');
        $data['ampmrole'] = ((in_array(Session::get('users')['role_id'], $ampmrole) == true) ? 0 : 1);


//        $data['eproofingsystype'] = [['id' => '1', 'name' => 'E-proof'], ['id' => '2', 'name' => 'APS']];
        $data['eproofingtype'] = [['id' => '2', 'name' => 'Mono'], ['id' => '1', 'name' => 'Contri']];
        $data['projecttype'] = Config::get('constants.SPRINGER_PROJECT_TYPE');
        $data['backurl']        =   url('/').'/book_info';
        // check already requested for raw download
        $this->displayRawfileButton($jobId,$data);        
        $data['showrawdownloadbutton']  =   in_array($this->roleId,Config::get('constants.RAW_FILE_BUTTON'));
        $data['showeproofchaptertab']   =   in_array($this->roleId,Config::get('constants.BOOK_MODULE_EPROOF_CHAPTER'));
        
        return view('bookinfo.book-workflow-tab')->with($data);
        
        }
        
        return redirect('/book_info');
        
    }

    public function updateBookinfodetails(Request $request) {
        if ($request->isMethod('POST')) {
            $validation = Validator::make($request->all(), [
                        'book_title' => 'required',
//                                                                        'book_projectname' => 'required',
                        'book_type' => 'required',
                        'book_publishername' => 'required',
                        'book_publisher_location' => 'required',
                        //'contact_person' => 'required',
                        'book_authorname' => 'required',
                        'book_print_issn' => 'required',
                        'book_production_location' => 'required',
                        'eproof_system' =>'required',
//                                                                        'bookpename' => 'required',
//                                                                        'bookpeemail' => 'required|email',
//                                                                        'bookamemail' => 'required|email',
//                                                                        'bookprint' => 'required',
//                                                                        'bookeditcontactemail' => 'required',
//                                                                        'bookauthor' => 'required|max:40',
//                                                                        'bookcontactname' => 'required|max:40',
//                                                                        'bookcontactemail' => 'required|email',
//                                                                        'bookdoi' => 'required',
//                                                                        'bookcopyright' => 'required',
//                                                                        'bookpublisherlocation' => 'required',
//                                                                        'bookid' => 'required',
//                                                                        'bookpelocation' => 'required',
//                                                                        'bookamname' => 'required|max:40',
//                                                                        'booktrimsize' => 'required',
//                                                                        'bookeisbn' => 'required',
//                                                                        'bookeditorname' => 'required',
//                                                                        'bookauthoremail' => 'required|email',
//                                                                        'bookcontactpersoncity' => 'required',
//                                                                        'bookpublisherimprint' => 'required',
//                                                                        'bookjobtype' => 'required',
//                                                                        'bookcopyyear' => 'required|numeric',
                        'jobId' => 'required|numeric',
//                                                                        'workflowtype' => 'required|numeric',
                        'profilename' => 'required',
//                                                                        'embbedname' => 'required|numeric',
                        'book_application' => 'required'
            ]);
            
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $jobinfo = [];
            $jobdata = [];
            $jobid = $request->input('jobId');
            $book_ispar = ($request->input('book_ispar') == 'on' ? '1' : '0');

            //job update                
            $jobdata['LAST_MOD_DATE'] = Carbon::now();
            $jobdata['LAST_MOD_BY'] = $this->loginUserId;

            //$jobdata['JOB_TITLE'] 	=	$request->input('book_title');
            //$jobdata['BOOK_ID'] 		=	$request->input('bookid');
            //$jobdata['JOB_TYPE'] 		=	$request->input('bookjobtype');
		
			$book_jobtype   =       $request->input( 'book_jobtype' );
            $book_jobcode   =       $request->input( 'book_jobcode' );
           
            $this->prepareJobCodeInformation( $jobid , $book_jobcode , $book_jobtype , $jobdata , $jobinfo );
            
            //job info update
            $jobinfo['APPLICATION']     =   $request->input('book_application');
            $jobinfo['LAYOUT_PROFILE']  =   $request->input('profilename');
            $jobinfo['CE_REQUIRED']     =   $request->input('ce_required');
            $jobinfo['EMBBED_TYPE']     =   $request->input('embbedname');
            $jobinfo['WORKFLOW_TYPE']   =   $request->input('workflowtype');
            $jobinfo['CATEGORY_TYPE']   =   $request->input('categorytype');
            $jobinfo['EPROOFING_SYSTEM'] =  $request->input('eproof_system');
            $jobinfo['EPROOFING_TYPE']  =   $request->input('eproof_type');
			$jobinfo['BLANK_BM'] 		= 	$request->input('blankBm');
            $jobinfo['IS_PAR']          =   $book_ispar;
            $jobinfo['LAST_MOD_DATE']   =   Carbon::now();
            $jobinfo['LAST_MOD_BY']     =   $this->loginUserId;
            $jobinfo['PRODUCTION_SYSTEM'] = $request->input('ptype');
            $jobinfo['COPY_EDITING_LEVEL'] = $request->input('copyeditinglevel');
            $jobinfo['IS_INDEXING'] 	= 	$request->input('indexing');
            $jobinfo['TAPS_LOCATION'] 	= 	$request->input('tapslocation');
			$printtype	=		 $request->input('printtype');
			
			if( isset( $printtype )  ){
				if(  $printtype  == 1 ||   $printtype  == 0 ){
					$jobinfo['IS_BLEED'] 		= 	$request->input('printtype');
				}
			}
			
            //$jobinfo['PE_NAME'] 		=	$request->input('bookpename');
            //$jobinfo['PE_MAIL'] 		=	$request->input('bookpeemail');
            //$jobinfo['AM_MAIL'] 		=	$request->input('bookamemail');
            //$jobinfo['ISSN_PRINT'] 	=	$request->input('bookprint');
            //$jobinfo['AUTHOR_NAME'] 	=	$request->input('bookauthor');
            //$jobinfo['DOI'] 			=	$request->input('bookdoi');
            //$jobinfo['LOCATION'] 		=	$request->input('bookpublisherlocation');
            //$jobinfo['PE_LOCATION'] 	=	$request->input('bookpelocation');
            //$jobinfo['AM_NAME'] 		=	$request->input('bookamname');
            //$jobinfo['ISSN_ONLINE'] 	=	$request->input('bookeisbn');
            //$jobinfo['AUTHOR_EMAIL'] 	=	$request->input('bookauthoremail');
            $updatebookinfo = bookinfoModel::updateBookinfodetails($jobinfo, $jobdata, $jobid);
            
                if ( $updatebookinfo ) {
                
                    /** report data * */
                    $reportData['JOB_ID'] = $jobid;
                    $reportData['ACTION'] = '2';

                    $repSuccess             =       app('App\Http\Controllers\reports\wipreportsController')->wipReportData($reportData, 'job');
                    $successfileresponse    =       app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobid, '104', 'update', 'download', '');
                    $response   =   $this->updatedResponse;
                    $response['validation']   =   "";
                    return response()->json($response);
                    
                }else
                {
                    $response   =   $this->updatedFailedResponse;
                    $response['validation']   =   "";
                    return response()->json($response);
                }
        }
        return response()->json($this->failedResponse);
    }	
    
    public function prepareJobCodeInformation( $jobid , $book_jobcode , $book_jobtype , &$jobdata , &$jobinfo ){
       
        if( isset( $book_jobcode ) && isset( $book_jobtype ) ){
            
            $sequence_count     =       0;
            $query_stmt         =       " select * from job where YEAR(CREATED_DATE) LIKE '%".date('Y')."%' and JOB_CODE_TYPE= $book_jobtype ";
            
            $qr =   DB::select( $query_stmt );
            
            if( !empty( $qr ) ){
                $sequence_count  = count( $qr );
            }
            
            $has_job_code       =       DB::table('job')->select()
                                            ->where( 'JOB_ID' , '=' , $jobid )
                                            ->whereNull( 'JOB_CODE_ID')
                                            ->get()->count();
            
            $sequence_count         =   intval( $sequence_count )+1;
            
            if(strlen($sequence_count) < 2){
                $sequence_count     =   '0'.$sequence_count;
            }

            $input_arr      =       array( '[YY]' => date('y') , '[SEQ]' =>  $sequence_count );
            $cmn_obj        =       new CommonMethodsController();
            $book_jobcode   =       $cmn_obj->arr_key_value_replace( $input_arr , $book_jobcode );

            if( $has_job_code ){
                $jobdata['JOB_CODE_ID'] 	=	'M-'.$book_jobcode;
                $jobdata['JOB_REF']             =	'M-'.$book_jobcode;
                $jobdata['JOB_CODE_TYPE'] 	=	$book_jobtype;
            }

        }
        
    }
    public function generateJobCode(){
        $jobConstant        =   Config::get('constants.JOB_CODE_PATTERN');
        $book_jobtype       =   '2'; //default set a xml as per priya confirmation
        $book_jobcode       =  $jobConstant[2];
        $dat                 =    $this->generateJobCodeInformation($jobid ='' , $book_jobcode , $book_jobtype);
        
    }
    
    
    public function generateJobCodeInformation( $jobid , $book_jobcode , $book_jobtype){
        $jobdata        =   array();
        if( isset( $book_jobcode ) && isset( $book_jobtype ) ){
            
            $sequence_count     =       0;
            $query_stmt         =       " select * from job where YEAR(CREATED_DATE) LIKE '%".date('Y')."%' and JOB_CODE_TYPE= $book_jobtype ";
            
            $qr =   DB::select( $query_stmt );
            
            if( !empty( $qr ) ){
                $sequence_count  = count( $qr );
            }
            $has_job_code       =   1;
          
            if(!empty($jobid)) {
            $has_job_code       =       DB::table('job')->select()
                                            ->where( 'JOB_ID' , '=' , $jobid )
                                            ->whereNull( 'JOB_CODE_ID')
                                            ->get()->count();
            }
           
            $sequence_count         =   intval( $sequence_count )+1;
            
            if(strlen($sequence_count) < 2){
                $sequence_count     =   '0'.$sequence_count;
            }
          
            $input_arr      =       array( '[YY]' => date('y') , '[SEQ]' =>  $sequence_count );
            $cmn_obj        =       new CommonMethodsController();
            $book_jobcode   =       $cmn_obj->arr_key_value_replace( $input_arr , $book_jobcode );
           
            if( $has_job_code ){
                $jobdata['JOB_CODE_ID'] 	=	'M-'.$book_jobcode;
                $jobdata['JOB_REF']             =	'M-'.$book_jobcode;
                $jobdata['JOB_CODE_TYPE'] 	=	$book_jobtype;
            }

        }
        return $jobdata;
    }
    
    public function dogetEproofrecipient(Request $request) 
    {
        try{
			
            $validation     =   Validator::make($request->all(), [
                                                    'metadtaid'     => 'required|numeric'
                                                ]);
            if ($validation->fails()){
				
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
				
                return response()->json($response);
				
            }
			
            $metadataid = $request->input('metadtaid');
            $jobid = "";
			
            if (Input::has('jobid')) {
                $jobid = $request->input('jobid');
                $wheredata = (['JOB_ID' => $jobid]);
                $geteproof = taskLevelMetadataModel::Active()->Notunitmeasure()->select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,task_level_metadata.EPROOFING_RECIPIENT,task_level_metadata.ADDITIONAL_RECIPIENT,task_level_metadata.CHAPTER_NO'))->where($wheredata)->get();
                
                if( Input::has( 'type' ) ){
                    
                   if( $request->input('type') == 1 ){
                       
                       $jbo     =   new jobModel();
                       $jbinfo      =   $jbo->getJobdetails( $jobid );
                       
                       $preparedout['jobid'] = $jbinfo['JOB_ID'].'-<span class="label label-sm label-success arrowed-in pull-left ng-binding">
                                                       &nbsp;Mono&nbsp;- Regular
                                                    </span>';
                       
                       $preparedout['EPROOFING_RECIPIENT'] = $jbinfo['EPROOF_RECIPIENT'];
                       $preparedout['ADDITIONAL_RECIPIENT'] = $jbinfo['ADDITIONAL_EPROOF_RECIPIENT'];
                       $preparedout['CHAPTER_NO'] = $jbinfo['BOOK_ID'];
                       
                        $geteproof  =    (object)$preparedout;
                   }
                }
                
                $response   =   $this->successResponse;
                $response['errMsg']     =   $geteproof;
                return response()->json($response);
            }
            $wheredata = ['METADATA_ID' => trim($metadataid)];
            $geteproof = taskLevelMetadataModel::Active()->Notunitmeasure()->select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,task_level_metadata.EPROOFING_RECIPIENT,task_level_metadata.ADDITIONAL_RECIPIENT,task_level_metadata.CHAPTER_NO'))->where($wheredata)->first();
            $response   =   $this->successResponse;
            $response['errMsg']     =   $geteproof;
            return response()->json($response);
        } catch (\Exception $e) {
            $response   =   $this->failedResponse;
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response, 404);
        }
    }

    public function doEproofsystemchange(Request $request) {
        try {
            $validation = Validator::make($request->all(), [
                        'metadtaid' => 'required|numeric',
                        'jobid' => 'required|numeric',
                        'eproofsystem_type' => 'required|numeric'
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            $jobId = $request->input('jobid');
            $typeofeproof = $request->input('eproofsystem_type');
            $metadataid = $request->input('metadtaid');
            $wheredata = ['METADATA_ID' => $metadataid, 'JOB_ID' => $jobId];
            $updateeproof = taskLevelMetadataModel::where($wheredata)->update(['EPROOFING_SYSTEM' => trim($typeofeproof)]);
            
            if ($updateeproof >= 1) {
                $this->triggerEproofIfNeeded( $metadataid );
                return response()->json($this->updatedResponse);
            }
            
            return response()->json($this->updatedFailedResponse, 404);
        } catch (\Exception $e) {
            $response   =   $this->failedResponse;
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response, 404);
        }
    }
    
    public function triggerEproofIfNeeded( $metaid  ){
         
        $taskLevelMetaObj       =       new taskLevelMetadataModel();
        
        $tasklev_info           =       $taskLevelMetaObj->getMetadatadetailsChapter( $metaid );
        $job_id                 =       $tasklev_info[0]->JOB_ID;    
        $bookInfo               =       jobModel::getJobdetails( $job_id );
        $jobLevelProofing       =       $bookInfo->EPROOFING_SYSTEM;
        $haseProof              =       false;
        
        if( $tasklev_info->count() && $jobLevelProofing == 1)
            $haseProof               =       ( $tasklev_info[0]->EPROOFING_SYSTEM == 1 ) ? true : false;

        if( $haseProof ){	 		
            
            //if not already triggered check
            $eproof_result     =   DB::select( "SELECT * FROM api_eproof_packaging WHERE METADATA_ID=$metaid and ROUND=118 and STATUS = 2 ORDER BY ID DESC"  );
            
            $download_result     =   DB::select( "SELECT * FROM api_download WHERE METADATA_ID=$metaid and ROUND=118 and IS_COMPLETED = 1 ORDER BY ID DESC"  );

            if( count( $eproof_result ) == 0  && count( $download_result ) == 0 ){

                    //triggering the eproof package
                    $eprCntrl        =       new \App\Http\Controllers\eproof\eproofController();
                    $test            =       $eprCntrl->doEproofVendorpackagecreate( $job_id , $metaid , 118 , 'package' );    
				
            }
			
        }
        
    }
    
    
    public function dogeteprooflistdetails(Request $request) {
        
        $jobID          =       $request->input('jodId');
        $jbj_obj        =       new jobModel();
        $jobinfo        =       $jbj_obj->getJobdetails( $jobID );
        
        $prepareArr     =       taskLevelMetadataModel::getalleproofdetailslist( $jobID );
        
        $jobarr['ADDITIONAL_RECIPIENT']     =   $jobinfo['BOOK_ID'];
        $jobarr['BOOK_ID']          =   $jobinfo['BOOK_ID'];
        $jobarr['CHAPTER_NAME']     =   $jobinfo['JOB_TITLE'];
        $jobarr['CHAPTER_NO']       =   $jobinfo['BOOK_ID'];
        $jobarr['CHAPTER_SEQ']      =   $jobinfo['JOB_ID'];
        $jobarr['EPROOFING_RECIPIENT']  =   $jobinfo['JOB_TITLE'];
        $jobarr['EPROOFING_SYSTEM']     =   1;
        $jobarr['JOB_TITLE']            =   $jobinfo['BOOK_ID'];
        $jobarr['jobid']                =   $jobinfo['JOB_ID'];
        $jobarr['taskmetaid']           =   $jobinfo['JOB_ID'];
        $jobarr['type']                 =   1;
        $prepareArr2[]                  =   $jobarr; 
        //array_unshift(  $prepareArr ,  $jobarr);
        foreach( $prepareArr as $key => $value ){
            //$value['type']   =   2;
            $prepareArr2[]   =   $value;
        }
        $response["cuclist"]        =       ( $prepareArr2 );
        
        return response()->json($response);
    }

    public function doUpdateeproofrecipient(Request $request) {
        try {
			
            $validation = Validator::make($request->all(), [
                        'metadtaid' 			=> 	'required|numeric',
                        'additional_recipient' 	=> 	'required'
						//'eproof_recipient' 	=> 	'required'
            ]);
			
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
			
            $additionalrecipient=   rtrim(strtolower($request->input('additional_recipient')),',');
            $eproofrecipient    =   rtrim(strtolower($request->input('eproof_recipient')),',');
            $metadataid         =   trim($request->input('metadtaid'));
			
			//$updatedata         =   ["ADDITIONAL_RECIPIENT"=>$additionalrecipient,'EPROOFING_RECIPIENT'=>$eproofrecipient];

            $updatedata         =   [ "ADDITIONAL_RECIPIENT"	=>	$additionalrecipient ];
            $wheredata          =   [ 'METADATA_ID'	=>	$metadataid	];
			$type  				= 	$request->input('type');
			
			if( $type == 2 ){
				$updateeproof       =   taskLevelMetadataModel::where($wheredata)->update($updatedata);
            }
			
			if( $type == 1 ){
				$jobid				=	 $request->input( 'jobid' );
				$updatedata         =    [ "ADDITIONAL_EPROOF_RECIPIENT" => $additionalrecipient , 'EPROOF_RECIPIENT' =>  $eproofrecipient ];
				$wheredata          =    [ 'JOB_ID' => $jobid ] ;
				$updateeproof       =    DB::table('job_info')->where($wheredata)->update($updatedata);
			}
			
			if($updateeproof  >=1 ){
                return response()->json($this->updatedResponse);
            }
			
            return response()->json($this->updatedFailedResponse,404);
			
        }catch( \Exception $e ){
            $response   =   $this->failedResponse;
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response,404);
        }
    }
    
    public function updateEmailrecipientdetails(Request $request)
    {
        try
        {
            $validation = Validator::make($request->all(), [
                        'additional_recipient' => "required|array|min:1",
                        'additional_recipient.*' => "required|min:1",
                        'metadtaid' => "required|array|min:1",
                        'metadtaid.*' => "required|distinct|min:1|numeric"
            ]);
            if ($validation->fails()) {
                $response   =   $this->validationResponse;
                $response['validation']     =   $validation->errors();
                return response()->json($response);
            }
            
            $allinputofmetadataid   =   $request->input('metadtaid');
            $additionalrecipient=   $request->input('additional_recipient');
            $eproofrecipient    =   $request->input('eproof_recipient');
            $updateeproof       =   taskLevelMetadataModel::doupdateemailrecipient($allinputofmetadataid,$eproofrecipient,$additionalrecipient);
            if($updateeproof    >=1)
            {
                return response()->json($this->updatedResponse);
            }
            return response()->json($this->updatedFailedResponse,404);
        }catch( \Exception $e ){
            $response   =   $this->failedResponse;
            $response['errMsg']     =   $e->getMessage();
            return response()->json($response,404);
        }
    }	
       
    public function prepareSpringerNamingConvention_old( $jobid , $metaid , $round ,  $withTime = true , $eproof=false ){
        
        $tlm_obj            =   new taskLevelMetadataModel();
        $cmn_obj            =   new CommonMethodsController();
        $taskLevelInfo      =   $tlm_obj->getTaskLevelDetails( $metaid );
        $chapterlist        =   $taskLevelInfo->pluck('CHAPTER_NO')->toArray(); 
        $chapterid          =       '';
        
        if( !empty( $chapterlist ) ){
               $chapterid      =   $chapterlist[0];
               $chapterid      =    preg_replace('/[^0-9]/', '', $chapterid);
        }
        $jobinfo = $taskLevelInfo->pluck('JOB_ID')->toArray();
        $namingOfBookZip = '';

        if (empty($jobinfo))
            throw new \Exception('job table information is not found');

        $jb_obj = new jobModel();
        $job_id = $jobinfo[0];
        $jobDetai = $jb_obj->getJobdetails($job_id);
        $book_id = $jobDetai->BOOK_ID;
        $round_arr = Config::get('constants.ROUND_NAME');
        $roundname = $round_arr[$round];

        $bookid_split = explode('_', $book_id);

        $bookno = $bookid_split[0];
        $edition_no = $bookid_split[1];
        $language = $bookid_split[2];

        $chpater_id_text = '_ChapterID=';

        if ($eproof) {
            $chpater_id_text = '_Chapter=';
        }
        
        $namingOfBookZip        =       'BookTitleID='.$bookno.'_EditionNumber='.$edition_no.'_Language='.$language.$chpater_id_text.$chapterid.'_';
        
        if( $roundname == 'S300' &&  $eproof ){
            $namingOfBookZip.= 'eProof_Contri_';
        }
        
        if( $withTime ){
            $namingOfBookZip.= date('Y-m-d_H-i-s').'.zip';
        }
        
        return $namingOfBookZip;
    }
       
       
    public function prepareSpringerNamingConvention( $jobid , $metaid , $round ,  $withTime = true , $eproof=false , $withTimeWithoutZip = false ){
        
        $tlm_obj            =   new taskLevelMetadataModel();
        $cmn_obj            =   new CommonMethodsController();
        
        $namingOfBookZip    =   '';
        
        $jb_obj             =   new jobModel();
        $jobDetai           =   $jb_obj->getJobdetails( $jobid );
        $book_id            =   $jobDetai->BOOK_ID;
        $round_arr          =   Config::get('constants.ROUND_NAME');
        $roundname          =   $round_arr[$round];
       
        $query              =     DB::table('api_download');
        $query->select();
        $query->where( 'BOOK_ID' , '=' , $book_id );
        
        if (isset($metaid) && $roundname != 'S600' && $roundname != 'S650'){
            $query->where('METADATA_ID', '=', $metaid );
        }
        
        $result = $query->orderBY('ID', 'DESC')->get()->first();
        
        $chpater_id_text        =   '_ChapterID=';
        $filename_arr           =       ($result != ''?$result->FILE_NAME:'');
        $namingOfBookZip        =       $filename_arr;
         
        if( $eproof ){
            $chpater_id_text2    =   '_Chapter=';
            $namingOfBookZip    =   str_replace( $chpater_id_text , $chpater_id_text2 , $namingOfBookZip );
        }
        
        $str                =      $book_zipfile    =   $namingOfBookZip;
        $remove_last_len    =      -23;
        $strleng            =      strlen( $book_zipfile ) - $remove_last_len;
        $book_zipfile       =      substr( $book_zipfile ,  $remove_last_len , $strleng );
        $book_zipfile       =      str_replace( $book_zipfile , '' , $str );
        $ext                =      '.zip';
        $cur_time           =      date('Y-m-d_H-i-s');
        $namingOfBookZip      =      $book_zipfile;
        
        if( $roundname == 'S300' &&  $eproof ){
            $namingOfBookZip.= 'eProof_Contri_';
        }
        
        if( $roundname == 'S650' &&  $eproof ){
            $namingOfBookZip.= 'eProof_Mono_';
        }
        
        if( $withTime ){
            $namingOfBookZip.= date('Y-m-d_H-i-s').'.zip';
        }
        if( $withTimeWithoutZip ){
            $namingOfBookZip.= date('Y-m-d_H-i-s');
        }
        
        return $namingOfBookZip;
	
    }

    public function getjobChapterlist(Request $request){
        
        $jobID                  =   $request->input('jodId');
        $customizationModelObj  = new customizationModel();
        
        $response               =   [];
        $chapdata               =   taskLevelMetadataModel::getChapterInfo($jobID);
        $getmetadataid          =   array_unique($chapdata->pluck('METADATA_ID')->toarray());
        $getjobroundid          =   array_unique($chapdata->pluck('JR_METADATA_ID')->toarray());
        $roundId                =   Config::get('constants.ROUND_NAME.S200');
        $wfdata                 =   $customizationModelObj->getWorkflowByCategory($roundId);
        $category               =   array();
        foreach($wfdata as $key=>$data){
            $cat            =  $data->CATEGORY.'_'.$data->EMBBED_TYPE.'_'.$data->ROUND_ID;
            $category[$cat] =  $data->WORKFLOW_MASTER_ID;
        }
    
        $jobData                =   jobModel::getJobdetails($jobID);
       

        $s5notificationStatus = DB::table('api_client_acknowledgement as t')
                             ->where('t.JOB_ID', '=', $jobID)
                             ->where('t.ROUND', '=', Config::get('constants.ROUND_NAME.S5'))
                             ->where('STATUS', '=', 2)
                             ->select(DB::raw('t.*'))
                            ->get();
        
        if(count($s5notificationStatus)>=1){
            $s5notification  = 1;
        }else{
            $s5notification  = 0;
        }
              
       // if(count($s5notificationStatus))
       
        //$wfdata                 =   '';
        
        if(empty($wfdata)){
            $wfdata            =   $customizationModelObj->getjobAssignedWorkflowByRoundWithCategory($jobID,$roundId);
        }
        $response['bookWorkflowId'] =   $jobData->WORKFLOW_TYPE;
        $response["cuclist"]        =   $chapdata;
        $response['wfdata']         =   $wfdata;
        $response['embbedType']     =   (!empty($jobData->EMBBED_TYPE)?$jobData->EMBBED_TYPE:0);
        $response['roundId']        =   $roundId;
        $response['jobCategoryType']  =  $jobData->COPY_EDITING_LEVEL;
        $response['jobsheetless']    =  $jobData->JOBSHEET_LESS;
        $response['jobsheetlessbtn']    =  (count($getmetadataid) == count($getjobroundid)?0:1);
        $response['catData']        =   json_encode($category );
        $response['s5notification'] =   $s5notification;
       
        $response["user_id"]        =   Session::get('users')['user_id'];
        
       
        return response()->json($response);
        
    }
    
    public function configJobChapterlist(Request $request){
        $masterId               =   $request->input('masterId');
        $ceLevel                =   $request->input('categroy');
        $metaId                 =   $request->input('metaId');
         $roundId                =    Config::get('constants.ROUND_NAME.S200');
        
         $jbr_obj             =   new jobRound();
         $roundInfo1          =   $jbr_obj->getjobRoundEntryExistByMetaId(  $metaId , $roundId , null  );
         
         if( !empty( $roundInfo1 ) ){
            $response   =   $this->failedResponse;
            $response['errMsg']     =  "Move to production already done.kindly conduct support team"; 
         }
    
        $updatedata         =   ["PRODUCTION_WORKFLOW"=>$masterId,"ARTICLE_CATEGORY"=>$ceLevel];
        $wheredata          =   ['METADATA_ID'=>$metaId];
        $updateeproof       =    DB::table('metadata_info')->where($wheredata)->update($updatedata);
              
        if(!empty($updateeproof)){
            $response                =   $this->updatedResponse;
        }else{
           $response                =   $this->updatedResponse;
        }
        
        return response()->json($response);
        
    }
    
       public function configJobsheetless(Request $request){
        $jobId                  =   $request->input('jobId');
        $jsflag                 =   $request->input('jsflag');
        $roundList              =   \Config::get('constants.ROUND_ID');
        $roundId                =   $roundList['S200'];
      
        $updatedata         =   ["JOBSHEET_LESS"=>$jsflag];
        $wheredata          =   ['JOB_ID'=>$jobId];
        $updateeproof       =    DB::table('job_info')->where($wheredata)->update($updatedata);
        
        if($jsflag == 1){
        $workflowIds = \Config::get('constants.DEFAULT_S200_WORKFLOW_LIST_JS_LESS');
        
        $customizationModelObj  =       new customizationModel();
        $userId                 =   \Config::get('constants.ADMIN_USER_ID'); //admin User id
       
        $status['status']       =   0;
        foreach($workflowIds as $wfMid){ 
            $workflowList           =       $customizationModelObj->getUserdefinedInformation($jobId,$roundId,$wfMid);
            
            if($workflowList['0']->total == '0'){
                $roundSequence      =       '0';
                $workflowCount      =       $customizationModelObj->getWorkflowCount($jobId);
                $roundSequence      =       $workflowCount +1;
                $userDefineData     =       $customizationModelObj->insertUserdefineData($jobId,$roundId,$wfMid,$userId,$roundSequence);
                
                $serverpathCopyJOBId    =   \Config::get('constants.DEFAULT_S200_WORKFLOW_JS_LESS_COPYJOB_ID');
				
				$query  =  "select *from workflow_server_map where job_id =  '$jobId' and WORKFLOW_MASTER_ID = '$wfMid' ";
                
                $jbstg_info	= DB::select( $query );
                              
                if(count($jbstg_info)== 0){
				
                $sql                    =  "INSERT INTO `workflow_server_map` ( `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`, `JOB_ID`, `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ`)
                                            select `WORKFLOW_MASTER_ID`, `WORKFLOW_ID`,'".$jobId."', `ROUND_ID`, `STAGE_ID`, `FILE_SHARE_TYPE`, `SERVER_PATH`, `FOLDER_PATH`, `USER_NAME`, `PASSWORD`, `FOLDER_TYPE`, `LAST_MOD_DATE`, `LAST_MOD_BY`, `FILE_MOVEMENT`, `FILE_STRING`, `FILE_EXTENSION`, `ORDER_SEQ` from workflow_server_map where job_id =  '$serverpathCopyJOBId' and WORKFLOW_MASTER_ID = '$wfMid' ";
                $dtlList                = DB::insert($sql);
				}
                
                $autoStageList          = \Config::get('constants.DEFAULT_S200_JS_LESS_AUTO_STAGE_WORKFLOW_ID');
            
                $updateData2['IS_AUTO']       = '1';
                $updateQry2  =   DB::table('task_level_userdefined_workflow')
                                    ->where('JOB_ID', $jobId )
                                    ->whereIn( 'STAGE' , $autoStageList  )
                                    ->update( $updateData2 );
                
                $status['status']   =   2;
                
            }
        }
        
        }
        
        if(!empty($updateeproof)){
            $response                =   $this->updatedResponse;
        }else{
           $response                =   $this->updatedFailedResponse;
        }
        
        return response()->json($response);
        
    }
    
    
    
}