<?php
namespace App\Http\Controllers\parreport;
use App\Http\Controllers\Controller;
use App\Models\parreportModel;
use App\Models\taskLevelMetadataModel;
use App\Models\bookinfoModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Config;
use Storage;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
class parreportController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function parReportDetails(Request $request,$jobID = null)
    {
	$data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PAR_REPORT'),$data);
	$data['downloadURL']    =   url('downloadParReport/'.$jobID);
	$data['projectId'] 	=   $jobID;
        $data['user_name']      =   $this->userName;
        $data['role_name']      =   $this->roleName;
        $rolerestrict           =   Config::get('constants.MANAGER_ROLE_ID');
        $role_logistics         =   ["46"];
        $newrolerestrict        =   array_merge($rolerestrict,$role_logistics);
        $data['disablevalues']  =   ((in_array($this->roleId,$newrolerestrict)  ==  true)?1:0);
        // check already requested for raw download
        $this->displayRawfileButton($jobID,$data);
        return view('parreport.par-report-details')->with($data);
    }
    
    public function getParBooklist(Request $request)
    {
	$data 	=	bookinfoModel::getBookinfo();
        $userId =       $this->loginUserId;
	$response["book"] 	= 	$data;
        $response['userId']     =       $userId;
	return response()->json($response);
    }
    
    public function getPareportList(Request $request)
    {
        if ($request->input('jodId') == null) {
            $response = array('result' => 400, 'msg' => 'Bad Request sending kindly reload page');
//            return response()->json($response, 400);
        }
        //CHECK PART IS AVAILABLE OR NOT
        $jobID  =   $request->input('jodId');
        $checkpartavailable =   taskLevelMetadataModel::getreportofconsolidate("4",$jobID);
        //$checkpartavailable =   array();
        
        if(count($checkpartavailable)>=1)
        {
            $partresult     =   [];
            $partincrement  =   0;
            //get fm record 
            $getfrontmatter =   taskLevelMetadataModel::getreportofconsolidate("1",$jobID);
            
            if(count($getfrontmatter)>=1)
            {
                foreach($getfrontmatter     as     $frontdata)
                {
                    if($frontdata['CHAPTER_NO'] !=  null){
                        $partresult[$partincrement]  =   $frontdata;
                        $partincrement++;
                    }
                }
            }
            $partincrement  =   $partincrement;
            
            $onlyChapter    =   taskLevelMetadataModel::getChapterWithoutPart($jobID);
            
            if(count($onlyChapter)>=1)
            {
                foreach($onlyChapter     as     $onlyChapters)
                {
                    if($onlyChapters['CHAPTER_NO'] !=  null){
                        $partresult[$partincrement]  =   $onlyChapters;
                        $partincrement++;
                    }
                }
                $partincrement  =   $partincrement;
            }
            
            //get part then chapter record 
            foreach($checkpartavailable     as $partidvalue)
            {
                ++$partincrement;
                $partresult[$partincrement] =   $partidvalue;
                $chapterdataresult          =   taskLevelMetadataModel::getchapterlistagainpart($partidvalue->METADATA_ID,$jobID);
                if(count($chapterdataresult)>=1)
                {
                    foreach($chapterdataresult  as  $chapterdatavalue)
                    {
                        if($chapterdatavalue['CHAPTER_NO'] !=  null){
                            ++$partincrement;
                            $partresult[$partincrement]     =   $chapterdatavalue;
                        }
                    }
                }
            }
            //get bm then chapter record 
            $getbackmatter      =   taskLevelMetadataModel::getreportofconsolidate("3",$jobID);
            if(count($getbackmatter)>=1)
            {
                ++$partincrement;
                foreach($getbackmatter  as     $backdata)
                {
                    if($backdata['CHAPTER_NO'] !=  null){
                        $partresult[$partincrement]  =   $backdata;
                    }
                }
            }
            $data           =   collect($partresult);
        }
        else
        {
            $data           =   parreportModel::getConsolidatereport($jobID);
        }
       
//        $data           =   parreportModel::getParreport($request->input('jodId'));
        $response["parreport"] 	=   $data;
        return response()->json($response);
    }
    
    public function updatePareportList(Request $request,$jobId)
    {
        if($request->isMethod('post') == "post" && $request->input('updateprojectitemsall') == "Save All")
        {
            if(count($request->input('metaids')))
            {
                $metaids                    =	$request->input('metaids');
                $totalpage                  =	$request->input('totalpage');
                $nooftables                 =	$request->input('nooftables');
                $noofunnumberedtables       =	$request->input('noofunnumberedtables');
                $noofequations              =	$request->input('noofequations');
                $noofunnumberedequations    =	$request->input('noofunnumberedequations');
                $chaptername                =	$request->input('chaptername');
                $updatemeata                =	parreportModel::updateallParReportdetails($jobId,$metaids,
                                                                                                $totalpage,
                                                                                                $nooftables,
                                                                                                $noofunnumberedtables,
                                                                                                $noofequations,
                                                                                                $noofunnumberedequations,$chaptername);
                if($updatemeata)
                {
                    return redirect('/par_report/'.$jobId)->with('status', 'Updated successfully.');
                }
                return redirect('/par_report/'.$jobId)->with('status', 'Not Updated successfully.');
            }
            return redirect('/par_report/'.$jobId)->with('status', 'No Data to Save.');
	}
	return redirect('/par_report/'.$jobId)->with('status', 'Invalid Access');
    }
	
    public function updatePareport(Request $request)
    {
        $metadata 		=	[];
        $metadata['START_PAGE'] 			=	$request->input('STARTPAGE');
        $metadata['END_PAGE'] 				=	$request->input('ENDPAGE');
        $metadata['NO_MSP'] 				=	$request->input('NOMSP');
        $metadata['FIGURE_COUNT'] 			=	$request->input('FIGURECOUNT');
        $metadata['FIGURE_COUNT_LEGENDS'] 	=	$request->input('FIGURECOUNTLEGENDS');
        $metadata['FIGURE_COUNT_UNNUMBERED']=	$request->input('FIGURECOUNTUNNUMBERED');
        $metadata['NO_TABLES'] 				=	$request->input('NOTABLES');
        $metadata['NO_TABLES_LEGENDS'] 		=	$request->input('NOTABLESLEGENDS');
        $metadata['NO_TABLES_UNNUMBERED'] 	=	$request->input('NOTABLESUNNUMBERED');
        $metadata['NO_SCHEMES'] 			=	$request->input('NOSCHEMES');
        $metadata['NO_EQUATION'] 			=	$request->input('NOEQUATION');
        $metadata['NO_EQUATION_UNNUMBERED'] =	$request->input('NOEQUATIONUNNUMBERED');
        $metadata['NO_BOX'] 				=	$request->input('NOBOX');
        $metadata['NO_BOX_LEGENDS'] 		=	$request->input('NOBOXLEGENDS');
        $metadata['LAST_MOD_DATE'] 			=	Carbon::now();
        $metadata['LAST_MOD_BY'] 			=	$this->loginUserId;
        $taskleveldata 	=	[];
        $taskleveldata['LAST_MOD_DATE'] 	=	Carbon::now();
        $taskleveldata['LAST_MOD_BY'] 		=	$this->loginUserId;
        $updateData 		=	parreportModel::updateParReportdetails($metadata,$taskleveldata,$request->input('tasklevelid'));
        if($updateData)
        {
            $response 	=	array('result'=>201,'msg'=>'Updated successfully.');
            return response()->json($response);
        }else
        {
            $response 	=	array('result'=>400,'msg'=>'Updated Not successfully Try Again.');
            return response()->json($response,400);
        }
    }
	
    
    
    
	
	/*public function splitprocess(Request $request)
    {
		$pathurl 			=	public_path().'/test.json';
		$jsoncontents 		= 	File::get($pathurl);
		$decodefile 		=	json_decode($jsoncontents);
		if(count($decodefile)>=1)
		{
			$bookid 		=	$decodefile->BookID;
			//check BOOK ID IS EXIST
			$bookresult 	=	parreportModel::checkBookidexist($bookid);
			if(count($bookresult)>=1)
			{
				$jobID 			=	$bookresult->JOB_ID;
				$starttime 		=	$decodefile->StartTime;
				$endtime 		=	$decodefile->EndTime;
				$filesread 		=	$decodefile->Files;
				if(count($filesread)>=1)
				{
					$jsonfiles 	=	[];
					foreach($filesread as $key=>$jsonvalue)
					{
						if(strpos($jsonvalue->Name,'.') !== false)
						{
							$splitname 							=	explode('.',$jsonvalue->Name);
							$jsonfiles[$key]['Name'] 			=	trim($splitname[0]);
						}
						else{
							$jsonfiles[$key]['Name'] 			=	trim($jsonvalue->Name);
						}
						$jsonfiles[$key]['NoOfCharacters'] 		=	$jsonvalue->NoOfCharacters;
						$jsonfiles[$key]['PageCount_ByCharacters'] 	=	$jsonvalue->PageCount_ByCharacters;
						$jsonfiles[$key]['NoOfWords'] 			=	$jsonvalue->NoOfWords;
						$jsonfiles[$key]['PageCount_ByWords'] 	=	$jsonvalue->PageCount_ByWords;
					}
					$addresult 	=	parreportModel::storeSplitprocess($jsonfiles,$jobID,$bookid);
					if($addresult['result'] >= 1)
					{
						$response 	=	array('result'=>201,'msg'=>'Chapter is Added Successfully',
											'existchapter'=>$addresult['chapter']);
						return response()->json($response);
					}
					else
					{
						$response 	=	array('result'=>400,'msg'=>'Chapter is Not Added Successfully Kindly try again',
											'existchapter'=>$addresult['chapter']);
						return response()->json($response);
					}
				}
				$response 	=	array('result'=>404,'msg'=>'Chapter is not available for '.$bookid.' Book Id Try Again.');
				return response()->json($response);
			}
			$response 	=	array('result'=>404,'msg'=>$bookid.' Book Id is not exist with Books Try Again.');
			return response()->json($response);
		}
    }*/
}