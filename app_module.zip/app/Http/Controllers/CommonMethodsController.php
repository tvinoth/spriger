<?php

namespace App\Http\Controllers;
use App\Models\fileHandler;
use Session;
use Mail;
use Illuminate\Support\Facades\Crypt;
use Validator;
use DB; 
use Log;
use Config;
use Request;
use Storage;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class CommonMethodsController
{    
    public $soapOptions     =    array(
                                    'trace' =>  true , 
                                    'connection_timeout' => 500000 ,
                                    //'cache_wsdl' => WSDL_CACHE_BOTH,
                                    'keep_alive' => false 
                                ) ; 
    /*
     *      Input param 2 is optional ,
     *      required optional replaced string means give true to get forehead extra slashes
     * 
     */
    function filterAlphanumeric($string) {
        
        $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

        return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
    }

 
    public function backslashPathPrepare( $path , $addForeSlash  = false ){
        
        $path                =       str_replace(    '/'    ,   '\\'    ,   $path ); 
        $path                =       str_replace(    '//'   ,   '\\'    ,   $path ); 
        $path                =       str_replace(    '\\\\' ,   '\\'    ,   $path );
        
        if( $addForeSlash ){
            
            if( substr( $path , 0 , 1 ) == '\\' ){
                $path   =   substr( $path , 1 );
            }   
            $path                =       '\\\\'.$path;        
            
        }
        return $path;
        
    }
    
    public function forwardslashPathPrepare( $path , $addForeSlash  = false ){
        
        $path                =       str_replace(    '\\'    ,   '/'    ,   $path ); 
        $path                =       str_replace(    '\\\\'   ,   '//'    ,   $path ); 
        $path                =       str_replace(    '////' ,   '//'    ,   $path );
        
        if( $addForeSlash ){
            
            if( substr( $path , 0 , 1 ) == '/' ){
                $path   =   substr( $path , 1 );
            }   
            
            $path                =       '//'.$path;        
            
        }
        return $path;
        
    }
	
    //Support two types of string replace 
    // 1  -> With array key value replace
    // 2  -> Optional parameter , it will replace the sentence word from array value based on key matched on second parameter string
    
    public function arr_key_value_replace( $arr_input , $const_path = null ){
        
        $output     =       '';
        
        if( !empty( $arr_input ) ){
            
            $collect_key        =       array_keys( $arr_input );
            
            if( !is_null( $const_path ) ){
                $prepared_Str       =    $const_path;
            }else{
                $prepared_Str       =       implode( '/' , $collect_key );
            }
            
            foreach( $arr_input as $key => $value ){
                
                $prepared_Str   =   str_replace( $key , $value , $prepared_Str   );
                $output =   $prepared_Str;
                
            }
            
        }
        
        return $output;
       
    }
    
    public function soapServiceCall(  $serviceurl , $methodname , $inputData  , $ouputparameter = null ){
        
        try{
		
            $client     =   new \SoapClient(  $serviceurl , $this->soapOptions );
            dd( $client );
            $functions  =   $client->$methodname( $inputData );
		   
            $functions  =   (array)$functions;	
            $obj  =  ( $functions ); 
            
            if( isset( $ouputparameter ) && !is_null($ouputparameter) ){
               $obj    =       $obj["$ouputparameter"];
            }
        
        }catch( \Exception $e ){
            
            print_r($e->getMessage());
            throw new \Exception( $e->getTraceAsString() );
            
        }
       
        return $obj;
							
    }
     
    public function callService( $data , $url , $type = null ) {
        
        $header[]   = "Content-type: text/plain";
        
        if( !is_null( $type ) ){
            switch( $type ){
                case 'json': 
                    $header =  array( "Content-Type => application/json" );
                    $data   =   json_encode($data , TRUE );
                break;
            }
        }
       
        $ch         = curl_init();   
        curl_setopt($ch, CURLOPT_URL, $url );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 300 );
        curl_setopt($ch, CURLOPT_HTTPHEADER, $header );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data );

        $response   = curl_exec( $ch );  
        
        if (curl_errno($ch)) {
            print $eror	=	 curl_error($ch);
			throw new Exception(  $eror	 );
        } else {
            curl_close($ch);
            return json_decode($response,TRUE);
        }
        
    }
    
    public function formatXmlString( $str_xml ){
        
        $domxml = new \DOMDocument( '1.0', 'utf-8' );
        $domxml->preserveWhiteSpace = false;
        $domxml->formatOutput = true;
        
        try{

            $str_xml		=	 str_replace( '&' , '&amp;' , $str_xml ); 

            /* @var $xml SimpleXMLElement */
            $newfile    =   $domxml->loadXML($str_xml);

            $domxml->save($newfile);
            $getMetaFormat = $domxml->saveXML(); 

            $getMetaFormat		=	 str_replace( '&amp;#39;online&amp;#39;' , "'online'" , $getMetaFormat ); 
            $getMetaFormat		=	 str_replace( '&amp;#39;print&amp;#39;' , "'print'" , $getMetaFormat ); 
            $getMetaFormat		=	 str_replace( '&amp;#39;' , "'" , $getMetaFormat ); 
            $getMetaFormat		=	 str_replace( '&#39;' , "'" , $getMetaFormat ); 

            return $getMetaFormat;

        }catch(\Exception $e){
            
            return $str_xml;
            
        }
			
    }
     
    public function array2xml($array, $xml = false , $parent_tag =  null ){
       
        if($xml === false){
            $xml = new \SimpleXMLElement('<root/>');
        }
        
        if( !is_null( $parent_tag ) ){
             $xml = new \SimpleXMLElement("<$parent_tag/>");
        }
        
        foreach($array as $key => $value){
           
            if(is_array($value) || is_object( $value )){
                if( $key == '@attributes' ){
                    $this->addAttributeToXml($value, $xml);
                }else{
                    
                    if( !is_array( $value ) ){
                        $this->array2xml($value, $xml->addChild($key));
                    }
                    if( is_array( $value ) ){
                        foreach( $value as $key2 => $value2 ){
                            $this->array2xml( array( $key => $value2 ) , $xml );
                        }
                    }
                }
                
            }else{
                
                if( substr_count( $value , '/') >= 4 || substr_count( $value , '\\') >= 4 ){
                    $value  =   $this->backslashPathPrepare( $value , true );
                }
                    
                $xml->addChild($key, $value);
                
            }
        }
        
        return $xml->asXML();
        
    }
    
    //xml to array
    public function xml2arrayorobject($array,$obtorarray =  true ){
        $data   =   [];
        if(!empty($array))
        {
            $xml    =   simplexml_load_string($array);
            $json   =   json_encode($xml);
            $data   =   json_decode($json,($obtorarray  ==  TRUE?TRUE:FALSE));
        }
        return $data;
    }
    
    public function addAttributeToXml( $value , &$xml ){
       
        foreach( $value as $attrKey => $attrValue ){
          
            if( $attrKey == '@attributes' || is_object( $attrValue ) ){
                $this->addAttributeToXml( $attrValue , $xml );
            }
            
           @$xml->addAttribute( $attrKey , $attrValue );
        }
        
    }
    
    public function recurse2xml ($array, &$string = "") {
        $key_attr   =   '@attributes';
        
        foreach ($array as $key => $subArray) {
            if (substr($key, -5) == "_attr")
                continue;
            $attrs = "";
            var_dump( $array );
            if (isset($array["$key_attr"]))
                foreach ($array["$key_attr"] as $attr => $value)
                    $attrs .= " $attr='".str_replace($value, "'", "\\'")."'";
            if (empty($subArray)) {
                $string .= "<$key$attrs />";
            } else {
                $string .= "<$key$attrs>";
                if (is_scalar($subArray))
                    $string .= $subArray;
                else
                    $this->recurse2xml($subArray, $string);
                $string .= "</$key>";
            }
        }
        return $string;
    }
    
    public function logOnFileWrite_relative( $fileNameWithRelativePath = NULL , $eMsg = NULL ){
		
        if( !is_null( $fileNameWithRelativePath ) && !is_null( $eMsg ) ){		

            $pathname	=	explode( '/' , $fileNameWithRelativePath );
            $indexL		=	( count( $pathname ) - 1 );
            unset( $pathname[$indexL] );
            $temp		=	( $pathname );
            $pathname	=	implode( '/' , $temp );

            if (!is_dir( $pathname )) {
                    mkdir($pathname , '0777' , true);		
            }

            if (!file_exists( $fileNameWithRelativePath ) ) {

                    $filenam = $fileNameWithRelativePath;
                    $fp = fopen(  $filenam  , 'w+');
                    fwrite($fp , ' File created now '.PHP_EOL );
                    fclose($fp);
                    chmod( $filenam , 0777);	

            }				

            $writtenTxt		 =		''; //Declare
            $writtenTxt		.=		'';	//AdditionalHeads	
            $writtenTxt		.=		PHP_EOL.$eMsg.PHP_EOL;
            $writtenTxt		.=		'';	//AdditionalFooters	
            file_put_contents( $fileNameWithRelativePath , $writtenTxt , FILE_APPEND );

        }	
		
	}
	
    public function sendErrTraceMail( $to , $cc = null , $sub , $bdy  ){

            $mail = new PHPMailer;
            $mail->IsSMTP();
            $mail->Host = MAIL_HOST_IP;
            $mail->Port = 25;
            $mail->SMTPAuth = false;
            
            $from                   =       'noreply@spi-global.com';	
            $mail->setFrom( $from , \Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME') );
            $mail->addAddress( $to , 'Magnus-Springer');

            if(!is_null( $cc ))
            $mail->addCC( $cc );

            $mail->Subject  = $sub;
            $mail->Body     = $bdy;

            $mail->send();
		
        if (!$mail->send()) {
            
            $MailInfo = "Mailer Error: " . $mail->ErrorInfo;
            $this->logOnFileWrite( 'repository/temp/backgroundToolsLog/mail_failure.txt' ,  PHP_EOL.$MailInfo.PHP_EOL );
					
        } else {
            
            $MailInfo = "Mail sent successfully .!"; 
            $this->logOnFileWrite( 'repository/temp/backgroundToolsLog/mail_failure.txt' ,  PHP_EOL.$MailInfo.PHP_EOL );			
            return true;
            
        }
        
    }
	
    public function sendMailNotify( $to , $cc = null , $sub , $bdy  , $bcc = null , $attach = null ){		
				
        $mail = new PHPMailer();
        
        $response[ 'status' ]       =   0;
        $response[ 'msg' ]          =   'Failed';
        $response[ 'errMsg' ]       =   'Mail sending failed, Try again later..,';
        
        $mail->IsSMTP();
        $mail->SMTPDebug    =   0;
        $mail->Debugoutput  =       'html';
        
        $mail->Host         =       env( 'MAIL_HOST' );
        $mail->Port         =       env( 'MAIL_PORT' );
        $mail->SMTPAuth     =       false;
        
        $mailContent        =       $bdy;
        $mail->Subject      =       $sub;
        $content            =       $bdy;
        $addaddress         =       $to;
        
        $mailsendcheck      =       $mail->MsgHTML( $content );
        $mail->SetFrom( $addaddress ,   \Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME') );
        $mail->AddAddress( $addaddress );
        $mail->addCC( $cc );
        
        $tomanybcc = explode( ';' , $bcc );
        
            if( !empty(  $tomanybcc ) ){ 
                foreach ($tomanybcc as $address) {
                    $mail->addBCC($address);
                }
            }

            $tomanycc = explode( ';' , $cc);
            
            if( !empty(  $tomanycc ) ){ 
                foreach ($tomanycc as $address) {
                        $mail->addCC($address);
                }
            }
        if( !is_null( $attach ) ){
            $mail->addAttachment( $attach );
        }
        
        $mail->AddReplyTo(  \Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL') , \Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME') );
        //$sys_info		=	'Ip from : '.$_SERVER['REMOTE_ADDR'].'== @:'.date('Y-m-d H:i:s');	
        
        if (!$mail->send()) {
            
            $MailInfo = "Mailer Error: " . $mail->ErrorInfo;
            $response[ 'status' ]       =  0;
            $response[ 'msg' ]          =   'Failed';
            $response[ 'errMsg' ]       =   $MailInfo;
		
        } else {
            
            $MailInfo = "Mail sent successfully .!"; 
            $response[ 'status' ]       =   1;
            $response[ 'msg' ]          =   'Success';
            $response[ 'errMsg' ]       =   $MailInfo;
            
        }	
	
        return $response;
    }
	
     public function PostcUrlExecution( $data  = array() , $curl = NULL ,$jsondecode=1){
        
        $comn_curl  =   \Config::get('constants.WSDL_OF_METAEXTRACTOR');
        $url 			= 		( is_null( $curl ) ) ? $comn_curl  : $curl;
		$returnArr 		=		array();
		$curl           = 		curl_init($url);
        
        if( !empty( $data ) ){

            $content		= 		json_encode( $data );
            $curl               = 		curl_init($url);
            curl_setopt( $curl , CURLOPT_HEADER	, false);
            curl_setopt( $curl , CURLOPT_RETURNTRANSFER , true);
            curl_setopt( $curl , CURLOPT_HTTPHEADER	, array( "Content-type=> application/json" ) );
            curl_setopt( $curl , CURLOPT_POST , true);
            curl_setopt( $curl , CURLOPT_POSTFIELDS , $content);
            $exe_result =   $json_response = curl_exec( $curl );
			
            $status     = curl_getinfo( $curl , CURLINFO_HTTP_CODE );
           
        }
        
        if($jsondecode == 1) {
        $json_response                   =       (array)json_decode( $json_response );
        $json_response['http_code']      =       $status;
        
        // Check for errors and display the error message
       
            if( $status !== 200 ) {
                $errno = curl_errno( $curl );
                $error_message = curl_strerror($errno);
				$json_response['http_code']    =    "404";
                $json_response['curl_err']     =    "http status code :  ({$status}), cURL error ({$errno}):\n {$error_message}";
            }
        }
        
        curl_close( $curl );
        
        return $json_response;      
        
	}
       
    public function getcUrlExecution($curl = NULL ,$jsondecode=1){
        
        $comn_curl      =   Config::get('constants.WSDL_OF_METAEXTRACTOR');
        $url 		=   ( is_null( $curl ) ) ? $comn_curl  : $curl;
	$returnArr 	=   array();
	$curl           =   curl_init($url);
        curl_setopt( $curl , CURLOPT_HEADER	, false);
        curl_setopt( $curl , CURLOPT_RETURNTRANSFER , true);
        curl_setopt( $curl , CURLOPT_HTTPGET , true);
        $exe_result     =   $json_response = curl_exec( $curl );
       
        $status         =   curl_getinfo( $curl , CURLINFO_HTTP_CODE );
           
        if($jsondecode == 1) {
            $json_response                   =       (array)json_decode( $json_response );
            $json_response['http_code']      =       $status; 
            // Check for errors and display the error message
            if( $status !== 200 ) {
                $errno = curl_errno( $curl );
                $error_message = curl_strerror($errno);
                $json_response['curl_err']     =    "http status code :  ({$status}), cURL error ({$errno}):\n {$error_message}";
            }
        }
        curl_close( $curl );
        
        return $json_response;      
        
    }
        
    public function RestfulPostcUrlExecution( $data  = array() , $curl = NULL ,$jsondecode  =   0,$type = null){
        
        $comn_curl  =   \Config::get('constants.WSDL_OF_METAEXTRACTOR');
        
        $url 			= 		( is_null( $curl ) ) ? $comn_curl  : $curl;
	$returnArr 		=		array();
	$curl                   = 		curl_init($url);
        $json_response          =   "";
        $status                 =   "401";
       // echo json_encode($data);exit;
        if( !empty( $data ) ){

            $content		= 		 $data;
            $curl               = 		curl_init($url);
            curl_setopt( $curl , CURLOPT_HEADER	, false);
            curl_setopt( $curl , CURLOPT_RETURNTRANSFER , true);
            curl_setopt( $curl , CURLOPT_POST , true);
            
            if(  gettype( $data ) == 'string' ){
                curl_setopt( $curl , CURLOPT_HTTPHEADER	, array( "Content-Type => application/json" ) );
                curl_setopt( $curl , CURLOPT_POSTFIELDS , $content );
            }else if(  gettype( $data ) == 'array' ){
                if(empty($type)){
                    curl_setopt( $curl , CURLOPT_HTTPHEADER	, array( "Content-Type:application/json" ) );
                }else{
                    curl_setopt( $curl , CURLOPT_HTTPHEADER	, array( "Content-Type:application/".$type) );
                }
                if($jsondecode  ==  1)
                {
                    curl_setopt( $curl , CURLOPT_POSTFIELDS , json_encode($content) );
                }else{
                    curl_setopt( $curl , CURLOPT_POSTFIELDS , $content );
                }
            }else{
                 curl_setopt( $curl , CURLOPT_POSTFIELDS , http_build_query($content) );
            }
            
            $exe_result =   $json_response = curl_exec( $curl );
            $status = curl_getinfo( $curl , CURLINFO_HTTP_CODE );
            
        }
        
        $json_response      =       (array)json_decode( $json_response );
        $json_response['http_code']      =       $status;
		$json_response['result']   =  $exe_result ;
        
        //Check for errors and display the error message       
        if( $status !== 200 ) {
            $errno = curl_errno( $curl );
            $error_message = curl_strerror($errno);
            $json_response['curl_err']     =    "http status code :  ({$status}), cURL error ({$errno}):\n {$error_message}";
        }
            
        curl_close( $curl );
        
        return $json_response;      
        
    }
        
    public function logOnFileWrite( $fileNameWithAbsolutePath = NULL , $eMsg = NULL ){
 
        if( !is_null( $fileNameWithAbsolutePath ) && !is_null( $eMsg ) ){

            $pathname	=	explode( '/' , $fileNameWithAbsolutePath );

            if( count( $pathname ) > 1 ){

                    $indexL		=	( count( $pathname ) - 1 );
                    unset( $pathname[$indexL] );
                    $temp		=	( $pathname );
                    $pathname	=	implode( '/' , $temp );

                    //With read and write permissions
                    $this->createDirectoryOnAppln( $pathname , 0777 ); 

            }

            $this->createFileOnAppln( $fileNameWithAbsolutePath , 0777 );

            $writtenTxt		 =		''; //Declare
            $writtenTxt		.=		'';	//AdditionalHeads
            $writtenTxt		.=		PHP_EOL.$eMsg.PHP_EOL;
            $writtenTxt		.=		'';	//AdditionalFooters
            $relative_path       =              $this->getRelativePath( $fileNameWithAbsolutePath );

            $fileName		=		 $relative_path;
            $fileSize		=		 $this->getFileSize( $fileName );
            $size_in_unit	=		 trim( preg_replace( '/[0-9.]/' , '' , LOG_MAX_FILE_SIZE ) ); 
            $findInMb		=		 preg_match("/$size_in_unit/i", $fileSize );
            $sizeOfValue	=		 floor( preg_replace( '/[A-Za-z]/' , '' , $fileSize ) );

            if( $findInMb > 0 && $sizeOfValue <= $fileSize ){
                $write_string		=	$this->getLastlinesFromFile( $fileName );
                if( strlen( $write_string ) > 0 ){
                        file_put_contents( $fileName ,$write_string );				
                }else{
                        echo 'Constant mismatch occure LOG_MAX_FILE_SIZE , NO_OF_LINE_LOG_COPY'; 
                }				
            }

            $status 		 =		file_put_contents( $relative_path , $writtenTxt , FILE_APPEND );

            if( !$status )
                echo ('Write Permission issue : '.$fileNameWithAbsolutePath );			

        }

    }

    public function getRelativePath(  $absolutePathname ){
	
        $ds	=	DIRECTORY_SEPARATOR;

        $currntWrkDir	=		getcwd().$ds;
        $base_path 		= 		str_replace( '\\'  , $ds  ,  BASE_PATH  );
        $base_path 		= 		str_replace( '/'   , $ds  ,  BASE_PATH  );

        if( $base_path === 	$currntWrkDir ){

                $replace	=	$currntWrkDir;		
                $relative_path		=		str_replace( $replace , '' , $absolutePathname );

        }else{

                $replace			=		$currntWrkDir;
                $chmode_count		=		str_replace( $base_path , '' , $currntWrkDir );
                $countOf			=		substr_count( $chmode_count , $ds );
                $concat_str			=		str_repeat( '..'.$ds , $countOf );
                $relative_path		=		str_replace( $replace , '' , $absolutePathname );
                $relative_path		=		$concat_str.$relative_path;

        }	
        return $relative_path;
	
    }
        
    public function createFileOnAppln( $absoluteFilePathname = NULL , $permission = 0777 ){		

        $condition 		= 		file_exists( $absoluteFilePathname );
        $ds				=		DIRECTORY_SEPARATOR;			

        if ( empty( $condition ) ) {

                $relative_path	=	$this->getRelativePath( $absoluteFilePathname );

                $filenam 			= 		$relative_path;
                if ( !file_exists($filenam) ) {
                        $fp 				= 		fopen(  $filenam  , 'w+');
                        chmod( $filenam , $permission );
                        fwrite( $fp , ' File created now '.PHP_EOL );
                        fclose( $fp );
                        chmod( $filenam , $permission );			
                }

        return true;

        }else if( !empty( $condition )  ){

                return false;
        }

        return '-1'; // When condition fails with invalid input ;

    }

    public function createDirectoryOnAppln(  $absolutePathname = NULL , $permission = 0755 ){
	
        if( !is_null( $absolutePathname ) ){

            $relative_path	=	$this->getRelativePath( $absolutePathname );

            if ( !file_exists( $relative_path ) ) {				
                $oldmask = umask(0);
                //gives read and write permissions
                if( mkdir( $relative_path , $permission ) ){
                        return 'Folder Created Successfully.';
                }else{
                        return 'Folder Creation Failed.';
                }
            }else{
                    return 'Folder Already Exist.';
            }

        }else{
                return 'Parameter is empty.';
        }
			
    }

    public function delelteApplnServerFiles( $pathWithFileName = array() ){
		
        if( is_array( $pathWithFileName ) && !empty( $pathWithFileName ) ){

            foreach( $pathWithFileName as $key => $files ){				
                    unlink( $files );				
            }	
            
        }
        
        return false;
        
    }	
	
    public function connectFileServer(){
		
        $ftp_server 		= 		PDF_SERVER;
        $ftp_user 		= 		PDF_SERVER_USER;
        $ftp_password 		= 		PDF_SERVER_PASS;

        $conn_id 		= 		ftp_connect($ftp_server) or die("Couldn't connect to $ftp_server");
        $login_result 		= 		@ftp_login( $conn_id, $ftp_user, $ftp_password );

        return $conn_id;
	
    }

    public function disconnectFileServer( $conn ){
		
        return ftp_close( $conn );	
			
    }

    public function createDirectoryOnFileServer( $path = NULL ){

        $relt				=		$path;
        $conn_id			=		$this->connectFileServer();

        if( !is_null($relt) ){
            if( ftp_nlist($conn_id, $relt) === false ){
                    $status = gettype( ftp_mkdir($conn_id, $relt) );
            }
        }

        $this->disconnectFileServer( $conn_id );

        return ( $status=='string' ) ? 1 : 0;
		
    }
        
    public function getFileSize($path){
	
        $size = filesize($path);
        $units = array( 'B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB');
        $power = $size > 0 ? floor(log($size, 1024)) : 0;
        return number_format($size / pow(1024, $power), 2, '.', ',') . ' ' . $units[$power];
		
    }
    
    public function getLastlinesFromFile( $path_from = '' , $no_of_line = NO_OF_LINE_LOG_COPY	){
		
        $file 		= 		new SplFileObject( $path_from , 'r');
        $array		=		array();
        $file->seek(PHP_INT_MAX);
        $last_line 		= 		$file->key();
        if( $no_of_line < $last_line){		
                $lines 		= 		new LimitIterator( $file, $last_line - $no_of_line , $last_line );
                $array		=		(iterator_to_array($lines));		
        }
        return implode( '' , $array );
		
    }
        
    public function generateRandomString( $length = 16 , $tblname = null , $fieldname   =   'TOKEN_KEY') {
       
        $gotostat   =   false;    
        if ($gotostat) {
           geneateAgain:
        }
        
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	$charactersLength = strlen($characters);
	$randomString = '';
	
        for ($i = 0; $i < $length; $i++) {
	    $randomString .= $characters[rand(0, $charactersLength - 1)];
	}
        
        if( !is_null( $tblname ) ){ 
         
            $getRecords     =       DB::table( $tblname )
                                                ->select()
                                                ->where( $fieldname , $randomString )
                                                ->get()
                                                ->first();
            
            if( !empty( $getRecords ) ) 
                goto geneateAgain;
            
        }
        
	return $randomString;       
        
    }

    public function prepareAndCondition( $arr ){
		
	$count_of			 =		count( $arr );  
	$stringRet			 = 		'';
	if( !empty( $arr ) ){
            foreach ($arr as $key => $value) {
            	//$stringRet		.=		"`".strtoupper($key)."`";
		$stringRet		.=		"`".($key)."`";
		$stringRet		.=		" = ";
		$stringRet		.=		"'".$value."'";
		$stringRet		.=		" AND ";
            }
			
            $stringRet = substr( $stringRet , 0 , ( strlen($stringRet) - 5 )  );
	}
		
	return $stringRet;
		
    }
    
    function getFileMovementStatus($response_copy){

        if( in_array( 'failed' , $response_copy ) ){

            foreach ($response_copy as $key => $value ){
                if( $value == 'success' ){
                    unset( $response_copy[$key] );
                }
            }

            $response_copy   =       array( 'status' => 'failed'  , $response_copy );

        }else{
            
            $response_copy    =       array( 'status' => 'success' , $response_copy );
            
        }
        
        return $response_copy;
     }
     
      //insert record in filehandler table for delete ftp drive
    public function deletefilesInproduction($filepath)
    {
        $returndata     =   [];
        if(!empty($filepath))
        {
            $postdata               =   [];
            $postdata['file_path']  =   $filepath;
            $postdata['method_name']=   "deleteFileServer";
            $postdata['system_ip']  =   Request::ip();
            $postdata['processname']=   "deleteFileServer";
            
            $insertfilehandler      =   fileHandler::insertNew($postdata);
            
            if($insertfilehandler){
                $result             =   array('status'=>2,'errMsg'=>'File Production delete operation submitted Successfully...');   
                return $result;
            }
            
            $result                 =   array('status'=>0,'errMsg'=>'File Production delete operation not submitted Successfully...');   
            return $result;
        }
        $result                     =   array('status'=>0,'errMsg'=>'File Production path is empty kindly check it');   
        return $result;
        
    }
    
    //establish laravel ftp connection
    public function doLaravelftpconnection($getlocationftp)
    {
        // Do the FTP connection
        $hostserver     =   $getlocationftp->FTP_HOST;
        $hostusername   =   $getlocationftp->FTP_USER_NAME;
        $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath       =   $getlocationftp->FTP_PATH;
        $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
        $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
        $ftpObj         =   Storage::createFtpDriver([
                                        'host'     => $hostserver, 
                                        'username' => $hostusername,
                                        'password' => $hostpassword, // 
                                        'port'     => '21',
                                        'timeout'  => '30',
                                ]); 
        return $ftpObj;
    }
    
}