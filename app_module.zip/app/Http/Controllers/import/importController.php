<?php
namespace App\Http\Controllers\import;

use App\Http\Controllers\Controller;
use App\Models\projectModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Validator;
use PDF;
use DB; 
use Excel;
class importController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }

    /**
     * Import Controller 
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	$data= array();
        $data['pageTitle'] = 'Project List';
        $data['pageName']  = 'Project List';
        $data['user_name'] = $this->userName;
        $data['role_name'] = $this->roleName;
        return view('project.project-list')->with($data);
    }
	/**
     * Save Project Setup Excel in a Temp Location to insert the details in DB 
     *
     * @return \Illuminate\Http\Response
     */
	public static function projectSetupImport(Request $request) {
		$currentDir = getcwd()."/uploadFiles/";
		$fileName = "project_setup_".date("YmdHis").".xlsx";
		$fileSavePath  = $currentDir.$fileName;
		file_put_contents($fileSavePath  ,file_get_contents('php://input'));
		$res['fileName'] = $fileName;
		return response()->json($res); 
	}
	/**
     * Save Project Setup details in to DB from temp location
     *
     * @return \Illuminate\Http\Response
     */
	public static function projectSetupImportDB(Request $request) {
		$rowCnt = 0; $errMsg = ""; $errRows = ""; $importArray = array();
		
		$jobId = $request->input('jobId');
		$userId = $this->loginUserId;
		$lesson = $request->input('lesson');
		$grade = $request->input('grade');
		$myFile = $request->input('myFile');		
		
		$currentDir = getcwd()."/uploadFiles/";	
		$fileSavePath  = $currentDir.$myFile;
		
		Excel::load($fileSavePath, function($reader) use (&$importArray, $jobId, $userId, $lesson, $grade, $myFile, &$rowCnt, &$errMsg, &$errRows ) {

			$results = $reader->get();
			$results = $reader->all()->toArray();	
			$rowNo = 1;
		
			foreach($results as $row)
			{				
				$round = trim($row['round']);
				$stage = trim($row['stage']);
				$target = trim($row['target']);
				$unit = trim($row['unit']);
				$tolerance = trim($row['tolerance']);		
				
				if($round !="" && $stage != "" && $target != "" && $unit != "" && $tolerance != "") {
					$inpArray = array(); 
					$inpArray['jobId'] = $jobId;
					$inpArray['userId'] = $userId;	
					$inpArray['lesson'] = $lesson;	
					$inpArray['grade'] = $grade;	
					$inpArray['stageName'] = $stage;					
					$inpArray['roundName'] = $round;	
					$inpArray['unitName'] = $unit;	
					$inpArray['tolerance'] = $tolerance;	
					$inpArray['target'] = $target;	
					array_push($importArray, $inpArray);
				} else {
					if($round =="" && $stage == "" && $target == "" && $unit == "" && $tolerance == "") {
					} else {
						if($errRows != "") $errRows .= ", ";
						$errRows .= $rowNo;	
						$rowCnt++;	
					}					
				}	
				$rowNo++;
			}
		});
		unlink($fileSavePath);
		
		if($rowCnt > 0) {
			$errMsg = "Round, Stage, Target, Unit and Tolerance are mandatory. Please check your input for the row(s) ".$errRows.".";
		} else {		
            if(count($importArray) > 0) {					
				for($i=0; $i<count($importArray); $i++) {
					$response = projectModel::saveSetupRound($importArray[$i], 'Import');
				}			
				$errMsg = "Project Setup Successfully Imported.";
			} else {
				$errMsg = "No details found.";
			}
		}
		
		$res['rowCnt'] = $rowCnt;
		$res['errMsg'] = $errMsg;
		return response()->json($res); 
	}
	/**
     * Save Bookmap Excel in a Temp Location to insert the details in DB 
     *
     * @return \Illuminate\Http\Response
     */
	public static function bookmapImport(Request $request) {
		$currentDir = getcwd()."/uploadFiles/";
		$fileName = "Bookmap_".date("YmdHis").".xlsx";
		$fileSavePath  = $currentDir.$fileName;
		file_put_contents($fileSavePath  ,file_get_contents('php://input'));
		$res['fileName'] = $fileName;
		return response()->json($res); 
	}
	/**
     * Save Bookmap details in to DB from temp location
     *
     * @return \Illuminate\Http\Response
     */
	public static function bookmapImportDB(Request $request) {
		$rowCnt = 0; $invalid = 0; $errMsg = ""; $errRows = ""; $importArray = array();
		
		$jobId = $request->input('jobId');
		$userId = $this->loginUserId;
		$myFile = $request->input('myFile');		
		
		$currentDir = getcwd()."/uploadFiles/";	
		$fileSavePath  = $currentDir.$myFile;
		
		Excel::load($fileSavePath, function($reader) use (&$importArray, $jobId, $userId, $myFile, &$invalid, &$rowCnt, &$errMsg, &$errRows ) {

			$results = $reader->get();
			$results = $reader->all()->toArray();	
			$rowNo = 1;
		
			foreach($results as $row)
			{	
			
				$title = trim($row['title']);
				$number_type = trim($row['number_type']);
				$indd_folio_number = trim($row['indd_folio_number']);
				$page_type = trim($row['page_type']);
				$indd_version = trim($row['indd_version']);	
				$indd_file_name = trim($row['indd_file_name']);
				$indd_file_path = trim($row['indd_file_path']);
				$pdf_file_name = trim($row['pdf_file_name']);	
				$is_touched = trim($row['is_touched']);	
							
				if($is_touched == 'Yes'){
					$is_touched = 1; 
				} else {
					$is_touched = 0; 
				}	
				if ($number_type == "Numeric") {
					$number_type = 1;
				} else if ($number_type == "Alphanumeric") {
					$number_type = 2;
				} else if ($number_type == "RomanLC") {
					$number_type = 3;		
				} else if ($number_type == "RomanUC") {
					$number_type = 4;			
				}
				
				if($number_type !="" && $indd_folio_number != "" && $pdf_file_name != "" && $indd_file_path != "" && $indd_file_name != "") {
					if( (strpos($pdf_file_name, ".pdf") > -1) && (strpos($indd_file_name, ".indd") > -1)) {				
						$inpArray = array(); 
						$inpArray['jobId'] = $jobId;
						$inpArray['userId'] = $userId;
						$inpArray['inddFolioNo'] = $indd_folio_number;	
						$inpArray['pgTitle'] = $title;		
						$inpArray['pageType'] = $page_type;			
						$inpArray['numberType'] = $number_type;	
						$inpArray['inddVersion'] = $indd_version;			
						$inpArray['pdfFileName'] = $pdf_file_name;		
						$inpArray['inddFilePath'] = $indd_file_path;	
						$inpArray['inddFileName'] = $indd_file_name;
						$inpArray['isTouched'] = $is_touched;	
						array_push($importArray, $inpArray);
					} else {						
						if($errRows != "") $errRows .= ", ";
						$errRows .= $rowNo;	
						$invalid++;	
					}
					
				} else {
					if($number_type =="" && $indd_folio_number == "" && $pdf_file_name == "" && $indd_file_path == "" && $indd_file_name == "" && $indd_version == "" ) {
					} else {
						if($errRows != "") $errRows .= ", ";
						$errRows .= $rowNo;	
						$rowCnt++;	
					}					
				}					
				$rowNo++;
			}
		});
		unlink($fileSavePath);
		$response = "";
		if($rowCnt > 0) {
			$errMsg = "Indesign Folio #, PDF File name, Number type, Indesign file path, and Indesign file name are mandatory. Please check your input for the row(s) ".$errRows.".";
		} else if($invalid > 0) {
			$errMsg = "Please enter InDesign and PDF file names with extension for the row(s) ".$errRows.".";
			$rowCnt = $invalid ;
		} else {	
			if(count($importArray) > 0)	{	
			    $orderSeq = 0;$errMsg = "";
				for($i=0; $i<count($importArray); $i++) {
					$tmpArray = $importArray[$i];
					$tmpArray['orderSeq'] = $orderSeq;
					$response = projectModel::saveBookmapFolio($tmpArray, 'Import');
					if($response[0]->flag == 0) {
						$orderSeq = $response[0]->orderSeq;
					} else {
						$errMsg .= "Row #".($i+1)." - ".$response[0]->msg;
					}
				}			
				$errMsg .= "Bookmap details Successfully Imported.";
			} else {
				$errMsg = "No details found.";
			}
		}
		
		$res['rowCnt'] = $rowCnt;
		$res['errMsg'] = $errMsg;
		return response()->json($res); 
	}	
}