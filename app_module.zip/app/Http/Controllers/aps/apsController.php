<?php
namespace App\Http\Controllers\aps;
use App\Http\Controllers\Controller;
use App\Jobs\StageemailAlert;
use App\Models\taskLevelMetadataModel;
use App\Models\bookinfoModel;
use App\Models\jobModel;
use App\Models\roundModel;
use App\Models\productionLocationModel;
use App\Models\proofLetterTypesModel;
use App\Models\CountriesModel;
use App\Models\apsProofingStatusModel;
use App\Models\emailRemainderLogModel;
use App\Models\remainderEmailTemplateModel;
use App\Models\apiOpsStatus;
use App\Models\emailSetupStagewiseModel;
use App\Models\emailRemainderCorrectionHistoryModel;
use App\Models\apsProductionFilePathValidationModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\users\usersController;
use App\Http\Controllers\Api\autoPageController;
use App\Http\Controllers\dynamicConstantController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Session;
use Config;
use Storage;
use Mail;
use Log;
use Illuminate\Support\Facades\Crypt;
use File;
use Validator;
use Carbon\Carbon;
use PDF;
use DB; 
class apsController extends Controller
{
    public function __construct() {
        parent::__construct();        
    }
    
    public function apsSystemDetails(Request $request,$jobID = null)
    {
        $data                   =   array();
        $this->displayMenuName( Config::get( 'menuconstants.MENU.CPS' ) , $data );
		
        $data['downloadURL']    =   url('downloadParReport/'.$jobID);
        $data['projectId'] 	=   isset( $jobID ) ? $jobID : 1;
        $data['user_name']      =   Session::get('users')['user_name'];
        $data['role_name']      =   Session::get('users')['role_name'];
        $rolerestrict           =   Config::get('constants.MANAGER_ROLE_ID');
		
        $role_logistics         =   ["46"];
        $newrolerestrict        =   array_merge($rolerestrict,$role_logistics);
        $booksinfo              =   bookinfoModel::getApsBookinfo();
        $booksOpt               =   '';
		
        foreach ( $booksinfo as $key => $value ){
			
            $booksOpt      .=  '<option value="'.($value['JOB_ID']).'">';
            $booksOpt      .=  $value['BOOK_ID'];
            $booksOpt      .=  '</option>';
			
        }
		
        $data['bookidCollect']  =   $booksOpt;
        $data['disablevalues']  =   ( ( in_array( Session::get('users')['role_id'] , $newrolerestrict )  ==  true ) ? 1 : 0 );
		
        return view('aps.aps-details')->with( $data );
		
    }
    
    public function getApsChapterList(Request $request){   
        
        if( $request->input( 'jodId' ) == null ) {
			
            $response   =   $this->failedResponse;
            $response['errMsg']     =   "Job Id Field is required";
            
			return response()->json( $response , 400 );
            
        }
        
        $jobID  =   $request->input('jodId');  
        $stage  =   $request->input('stage');  
		$round_arr		=	\Config::get( 'constants.ROUND_NAME' );
		
		if( intval( $stage ) !==  intval($round_arr['S650']) ){
			$data   =   taskLevelMetadataModel::gettypeofarticle( $jobID , $stage , 2 );
		}else if( intval( $stage ) ==  intval($round_arr['S650']) ){
			$data   =   taskLevelMetadataModel::getJobLevelComponentApsinfo( $jobID , $stage );
		}else{
			$data   =   taskLevelMetadataModel::gettypeofarticle( $jobID , $stage , 2 );
		}
		
        $response["apschapter"] =   $data;
        
        return response()->json( $response );
        
    }
    
    public function getApsBookinfo(Request $request)
    {
        if ($request->input('jodId') == null) {
            $response   =   $this->failedResponse;
            $response['errMsg']     =   "Job Id Field is required";
            return response()->json($response, 400);
        }
        $jobID                  =   $request->input('jodId');  
        $bookinformationdetails =   jobModel::getJobdetails($jobID);
        $wheresfifty            =   ['ROUND_ID'=>Config::get('constants.ROUND_ID.S50'),'FILE_PATH_TYPE'=>'jobsheet'];
        $getjobsheetpath        =   apsProductionFilePathValidationModel::Active()->where($wheresfifty)->first();
        $getlocationftp         =   productionLocationModel::doGetLocationname($jobID);
        if(count($getjobsheetpath)>=1 && count($getlocationftp)>=1 && count($bookinformationdetails)>=1)
        {
            $hostserver         =   $getlocationftp->FTP_HOST;
            $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   $getlocationftp->FTP_PATH;
            $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
            $bookid             =           
            $array              =   array(  
                                            '{BID}' =>  $bookinformationdetails->BOOK_ID, 
                                            '{RNAME}' =>  Config::get('constants.ROUND_NAME.'.$getjobsheetpath->ROUND_ID)
                                        );
            $cmn_obj            =   new CommonMethodsController();         
            $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $array , $getjobsheetpath->FILE_PATH );
            $isfileavailable    =   $ftpObj->has($jobsheetpath);
            if($isfileavailable ==  true) 
            {
                $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver;   
                $jobsheetlocationpath   =   $crd.$jobsheetpath;
                $metadataXml            =   file_get_contents( $jobsheetlocationpath );
                $getjobsheetcontent     =   $cmn_obj->xml2arrayorobject($metadataXml);
                if(count($getjobsheetcontent)>=1)
                {
                    //get production editor email
                    $getccemail         =   (isset($getjobsheetcontent['BookJobSheet']['ProductionInfo']['ProductionEditor']['Contact']['Email'])?$getjobsheetcontent['BookJobSheet']['ProductionInfo']['ProductionEditor']['Contact']['Email']:'');
                    //get series info tilte and number
                    $getseriestitle     =   (isset($getjobsheetcontent['BookJobSheet']['SeriesInfo']['SeriesTitle'])?$getjobsheetcontent['BookJobSheet']['SeriesInfo']['SeriesTitle']:'');
                    
                    $getvolumenumber    =   (isset($getjobsheetcontent['BookJobSheet']['SeriesInfo']['SeriesTitle'])?$getjobsheetcontent['BookJobSheet']['SeriesInfo']['SeriesTitle']:'');
                    $getsubjectline     =   $getseriestitle.' '.$getvolumenumber;
                }
            }
        }
            
        $response["ccemail"]    =   @$getccemail;
        $response["subjectline"]=   @$getsubjectline;
        $response["jobinfo"]    =   $bookinformationdetails;
        $response["proofletter"]=   proofLetterTypesModel::active()->get();
        return response()->json($response);
    }
    
    public function doStoreapsproofsystem(Request $request)
    {      
        try
        {
            if($request->method()   ==  "POST")
            {
                $dateofproof    =   trim($request->input('proof_returned_date'));
                $todaydate      =   Carbon::Parse(Carbon::now())->format('Y-m-d');
                $validation 	=   Validator::make($request->all(), [
                                                                            'bookId' => 'required|numeric',
                                                                            'roundId' => 'required|numeric',
                                                                            'author_or_editor_type' => 'required|numeric',
                                                                            'chapter' => 'required|numeric',
                                                                            'toemail' => 'required|email',
                                                                            'author_or_editor_name' => 'required',
                                                                            'proof_letter_type' => 'required|numeric',
                                                                            //'Source_file' => 'required|file',
                                                                            //'mail_attachment_file' => 'required|file',
                                                                            'from_email' => 'required',
                                                                            'author_or_editor_subject_line' => 'required',
                                                                            'proof_returned_date' => 'required|date|date_format:Y-m-d|after:'.$todaydate,
                                                                            //'subject' => 'required'
                                                                    ]);
                if ($validation->fails())
                {
                    $showerror          =   [];
                    foreach ($validation->messages()->all('<li>:message</li>') as $message)
                    {
                        $showerror[]    =   $message;
                    }
                    $response   =   $this->validationResponse;
                    $response['validation']     =   $showerror;
                    return response()->json($response,400);
                }
                
                $jobId          =   trim($request->input('bookId'));
                $roundid        =   trim($request->input('roundId'));
                $chapterid      =   trim($request->input('chapter'));
                $typeofaureditr =   trim($request->input('author_or_editor_type'));
                $typeofaureditr =   ($typeofaureditr    ==  1?'AUTHOR':'EDITOR');
                $nameofaureditr =   trim($request->input('author_or_editor_name'));
                $prooftype      =   trim($request->input('proof_letter_type'));
                $from_email     =   trim($request->input('from_email'));
                $subjectline    =   trim($request->input('author_or_editor_subject_line'));
                $mailsubject    =   trim($request->input('author_or_editor_subject_line'));
                $toemail        =   rtrim(strtolower($request->input('toemail')),',');
                $ccemail        =   rtrim(strtolower($request->input('ccemail')),',');
                $getroundinfo   =   roundModel::where('ID',$roundid)->first();
                $roundname      =   "";
                $ccemail        =   ($ccemail   ==  "undefined"?'':$ccemail);
                $sourcefilename =   "";
                $sourcefullpath =   "";
                $fullpathmailattach         =   "";
                $mailattachfilename         =   "";
                $sourcefile                 =   $request->file('Source_file');
                $mailattachfile             =   $request->file('mail_attachment_file');
                $sourcetarget               =   public_path().'/apsSourcefile/';
                $mailattachtarget           =   public_path().'/apsAttachmentfile/';
                
                if(Input::hasFile('Source_file')) {
                    $sourcefilename         =   $sourcefile->getClientOriginalName();
                    $sourcefullpath         =   public_path().'/apsSourcefile/'.$sourcefilename;
                    $fileexetention         =   $sourcefile->getClientOriginalExtension();
                }
                if(Input::hasFile('mail_attachment_file')) {
                    $mailattachfilename     =   $mailattachfile->getClientOriginalName();
                    $fullpathmailattach     =   public_path().'/apsAttachmentfile/'.$mailattachfilename;
                    $mailattachexetention   =   $mailattachfile->getClientOriginalExtension();
                }

                //if(ctype_space($sourcefile) || strpos($sourcefilename,' ') !==    false){
                //$response       =	array('result'=>400,'errMsg'=>' Kindly remove white space in '.$sourcefilename,'validation'=>'');
                //return response()->json($response,400);
                //}
                
                //check delta pdf validation
                $getproof_letter_email  =   proofLetterTypesModel::Active()->find($prooftype);
                $getbookinfo            =   taskLevelMetadataModel::getbookChapteranduserinfo($jobId,$chapterid);
                $wheredata              =   ['ROUND_ID' => $roundid , 'FILE_PATH_TYPE' => 'jobsheet' ];
                $getjobsheetpath        =   apsProductionFilePathValidationModel::Active()->where($wheredata)->first();
                $getlocationftp         =   productionLocationModel::doGetLocationname($jobId);
                
                //check jobsheet and delta pdf file
                $deltafieldisavailornot =   $this->doCheckdeltarequiredornot( $getjobsheetpath, $getbookinfo , $getlocationftp );
                if(!empty($deltafieldisavailornot) && strtoupper($deltafieldisavailornot) == "YES"){
                    $checkdeltapdfvalidation    =   $this->doCheckfileisexistornot($getbookinfo,$getlocationftp,$roundid,'deltapdf');
                    if(empty($checkdeltapdfvalidation)){
                        $response   =   $this->failedResponse;
                        $response['errMsg']     =   'Delta PDF file not found, Kindly check it.!';
                        $response['validation'] =   [];
                        return response()->json($response,400);
                    }
                }
				
                //check jobsheet
                if(empty($deltafieldisavailornot)){
                    $response   =   $this->failedResponse;
                    $response['errMsg']     =   'Job sheet not found, Kindly check it.!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
                
                //check proofpdf
                $checkproofpdfvalidation    =   $this->doCheckfileisexistornot($getbookinfo,$getlocationftp,$roundid,'proofpdf');
                if(empty($checkproofpdfvalidation)){
                    $response   =   $this->failedResponse;
                    $response['errMsg']     =   'Proof PDF file not found, Kindly check it.!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
				
                //check chapterxml
                //$checkxmlfilevalidation =   $this->doCheckfileisexistornot($getbookinfo,$getlocationftp,$roundid,'chapterxml');
                //if(empty($checkxmlfilevalidation)){
                    
                 //   $response   =   $this->failedResponse;
                 //   $response['errMsg']     =   'Chapter XML file not found, Kindly check it.!';
                 //  $response['validation'] =   [];
                 //   return response()->json($response,400);
                //}
				
                //check merge pdf
                $checkmergefilevalidation   =   $this->doCheckfileisexistornot($getbookinfo,$getlocationftp,$roundid,'pdfmerge');
                if(empty($checkmergefilevalidation))
                {
                    $response   =   $this->failedResponse;
                    $response['errMsg']     =   'Merge PDF file not found, Kindly check it.!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
				
                $first_remainder    =   $correction_duedate     =   Carbon::parse($dateofproof);
                $second_duedate     =   Carbon::parse($dateofproof)->addDay(+3);
                $third_duedate      =   Carbon::parse($dateofproof)->addDay(+5);
                
                //check exist file or not
                if(file_exists($sourcefullpath)){
                    $response   =   $this->failedResponse;
                    $response['errMsg']     =   'Source file is already exists '.$sourcefilename.', Kindly rename it.!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
				
                //check exist mail attach file or not
                if(file_exists($fullpathmailattach)){
                    $response   =   $this->failedResponse;
                    $response['errMsg']     =   'Mail attachment file is already exists '.$mailattachfilename.', Kindly rename it.!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
				
                //generate token
                $cmn_obj            =   new CommonMethodsController();  
                $token_key          =   $cmn_obj->generateRandomString( 16 , 'aps_proofing_status','TOKEN' );
                $wheredata          =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>'aps_proofing_url'];
               
                //$aps_proofing_url   =   apsProductionFilePathValidationModel::Active()->where($wheredata)->first();
                $opsobj                 =       new apiOpsStatus();
                $aps_proofing_url       =       $opsobj->getProoflinkRecords( $chapterid , null , $roundid );
                
                // read mail part
                if(count($getproof_letter_email)>=1 && count($getbookinfo)>=1 && count($aps_proofing_url)>=1){
                    
                    $usrC_obj                   =   new usersController();
                    $currentuser_id             =   $getbookinfo[0]->PM;
                    $user_arr                   =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
                    
                    $data['bodycontent']        =   $this->docontentreplaceoriginalinfo( $getbookinfo , $dateofproof , $nameofaureditr , $getproof_letter_email , $aps_proofing_url->PROOF_LINK ); 
                    $data['Title']              =   $subjectline;
                    
                    $mailArray['TemplateName']  =   'emailtemplate.apsmailsetupalert.aps-emailalert';
                    $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                    $mailArray['FromName']      =   $from_email;
                    $mailArray['Subject']       =   $mailsubject;
                    
                    if(strpos($toemail,',') !==  false){
                        $toemailarray           =   explode(',',$toemail);
                        $mailArray['ToMail']    =   array_unique($toemailarray);
                    }else{
                        $mailArray['ToMail']    =   $toemail;
                    }
                    
                    $mailArray['ToMail']        =   "ananth.b@spi-global.com";
                    
//                    if(strpos($ccemail,',') !==  false)
//                    {
//                        $ccemailarray           =   explode(',',$ccemail);
//                        $mailArray['CcMail']    =   array_unique($ccemailarray);
//                    }else{
//                        $mailArray['CcMail']    =   $ccemail;
//                    }
//                    if(empty($mailArray['CcMail']))
//                    {
//                        unset($mailArray['CcMail']);
//                    }
                    
                    //move source file 
                    //$sourcefile->move( $sourcetarget , $sourcefilename );
                    //move attach file 
                    //$mailattachfile->move($mailattachtarget, $mailattachfilename);
//                    post metadata xml for get aps file link   
                    //$postapsmeta    =   $this->doPostApsmetaxml($getbookinfo,$roundid,$token_key,$cmn_obj,$getlocationftp);
                    
                    //if($postapsmeta['metapost'] ==  true){
                    
                    if(true){
                        
                        $mailArray['Data']          =   $data;
                        //insert data
                        DB::beginTransaction();
                        $datainsert                     =   [];
                        $datainsert['TOKEN']            =   $token_key;
                        $datainsert['JOB_ID']           =   $jobId;
                        $datainsert['ROUND']            =   $roundid;
                        $datainsert['METADATA_ID']      =   $chapterid;
                        $datainsert['METADATA_ID']      =   $chapterid;
                        $datainsert['PROOF_LETTER_TYPE_ID']     =   $prooftype;
                        $datainsert['TYPE']             =   $typeofaureditr;
                        $datainsert['NAME']             =   $nameofaureditr;
                        $datainsert['SUBJECT']          =   $mailsubject;
                        $datainsert['FROM_NAME']        =   $from_email;
                        $datainsert['TO_EMAIL']         =   $toemail;
                        $datainsert['CC_EMAIL']         =   $ccemail;
                        $datainsert['SUBJECT_LINE']     =   $subjectline;
                        $datainsert['EMAIL_CONTENT']    =   $data['bodycontent'];
                        $datainsert['CORRECTION_DUE']       =   $correction_duedate;
                        $datainsert['FIRST_CORRECTION_DUE'] =   $first_remainder;
                        $datainsert['SECOND_CORRECTION_DUE']=   $second_duedate;
                        $datainsert['THIRD_CORRECTION_DUE'] =   $third_duedate;
                        $datainsert['MAIL_ATTACHMENT_URL']  =   $mailattachfilename;
                        $datainsert['PROOFING_URL']     =   $aps_proofing_url->PROOF_LINK;
                        
                        //$datainsert['REQUEST_LOG']      =   $postapsmeta['metacontent'];
                        $datainsert['START_TIME']       =   Carbon::now();
                        $datainsert['CREATED_BY']       =   (isset(Session::get('users')['user_id'])?Session::get('users')['user_id']:Config::get('constants.ADMIN_USER_ID'));
                        $storeresponse                  =   apsProofingStatusModel::insertGetId($datainsert);
                        
                        if($storeresponse>=1){
                            $insertdata['METADATA_ID']          =   $chapterid;
                            $insertdata['ROUND']                =   $roundid;
                            $insertdata['CORRECTION_DUE']       =   $correction_duedate;
                            $insertdata['FIRST_CORRECTION_DUE'] =   $first_remainder;
                            $insertdata['SECOND_CORRECTION_DUE']=   $second_duedate;
                            $insertdata['THIRD_CORRECTION_DUE'] =   $third_duedate;
                            $insertdata['REMAINDER_TYPE']       =   Config::get('constants.REMAINDER_TYPE.APS');
                            $insertdata['CREATED_BY']           =   $datainsert['CREATED_BY'];
                            $storehistory                       =   emailRemainderCorrectionHistoryModel::insertGetId($insertdata);
                        }
                        
                        DB::commit();
                        
                        // mail send
                        $fileattachcont                 =   public_path().'/apsAttachmentfile/';
                        $getfileofattachmentloc         =   $mailattachtarget.$mailattachfilename;
                        
                        if(file_exists($getfileofattachmentloc)){
                            $mailArray['file']          =   $getfileofattachmentloc;
                            $mailArray['attachfile']    =   array('as' => $mailattachfilename, 'mime' => 'text/plain');
                        }
                        
                        $emailJob   =   (new StageemailAlert($mailArray));
                        dispatch($emailJob);
                        
						//	if(file_exists(public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL)){
						//unlink(public_path().'/apsAttachmentfile/'.$getproofingdata->MAIL_ATTACHMENT_URL);
						//}
                        
                        $chapterdata    =   taskLevelMetadataModel::gettypeofarticle($jobId,$roundid,2);
                        $response       =   $this->successResponse;
						
                        $response['errMsg'] =   'Email has been sent successfully to '.$nameofaureditr;
                        $response['validation'] =   [];
                        $response['apschapter'] =   $chapterdata;
						
                        return response()->json($response);
                        
                    }
					
                    $response   =   $this->failedResponse;
                    $response['errMsg'] =   'Meta Xml Not post!, Kindly retry';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
                
		if( !count($aps_proofing_url) ){
                    $response   =   $this->failedResponse;
                    $response['errMsg'] =   'Proof Link not yet generated!';
                    $response['validation'] =   [];
                    return response()->json($response,400);
                }
                $response   =   $this->failedResponse;
                $response['errMsg'] =   'Book or chapter data not found!';
                $response['validation'] =   [];
                return response()->json($response,400);
            }
            $response   =   $this->failedResponse;
            $response['errMsg'] =   'Bad request method';
            $response['validation'] =   [];
            return response()->json($response,400);
            
        }catch(\Exception $e ){
            
            /*
             * if(file_exists(public_path().'/apsSourcefile/'.$request->file('Source_file')->getClientOriginalName())){
                unlink(public_path().'/apsSourcefile/'.$request->file('Source_file')->getClientOriginalName());
            }
            if(file_exists(public_path().'/apsAttachmentfile/'.$request->file('mail_attachment_file')->getClientOriginalName())){
                unlink(public_path().'/apsAttachmentfile/'.$request->file('mail_attachment_file')->getClientOriginalName());
            }
             
            * 
            */
            
            DB::rollback();
            $response   =   $this->failedResponse;
            $response['errMsg'] =   $e->getMessage();
            $response['validation'] =   [];
            return response()->json($response,400);
            
        }
        
    }
    
    public function sendMailBladeTemplate($mailArray) {
        try {
            if (is_array($mailArray)) {
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/failedemailremainder.log');
            Log::info( json_encode( $exception->getMessage() ) );
        }        
    }
    
    public function doEmailpreview(Request $request)
    {      
        try
        {
            if($request->method()   ==  "POST")
            {
                $response   =   $this->failedResponse;
                $response['validation'] =   [];
                $validation 	=   Validator::make($request->all(), [
                                                                            'bookId' => 'required|numeric',
                                                                            'roundId' => 'required|numeric',
                                                                            'author_or_editor_type' => 'required|numeric',
                                                                            'chapter' => 'required|numeric',
                                                                            'toemail' => 'required|email',
                                                                            'author_or_editor_name' => 'required',
                                                                            'proof_letter_type' => 'required|numeric',
                                                                            'from_email' => 'required',
                                                                            'author_or_editor_subject_line' => 'required',
                                                                            'proof_returned_date' => 'required|date|date_format:Y-m-d|after:today',
                                                                            //'subject' => 'required'
                                                                    ]);
                
                if ($validation->fails()){
                    $showerror          =   [];
                    foreach ($validation->messages()->all('<li>:message</li>') as $message){
                        $showerror[]    =   $message;
                    }
                    $response   =   $this->validationResponse;
                    $response['validation']     =   $showerror;
                    return response()->json($response,400);
                }
                
                $jobId          =   trim($request->input('bookId'));
                $roundid        =   trim($request->input('roundId'));
                $chapterid      =   trim($request->input('chapter'));
                $typeofaureditr =   trim($request->input('author_or_editor_type'));
                $typeofaureditr =   ($typeofaureditr    ==  1?'AUTHOR':'EDITOR');
                $nameofaureditr =   trim($request->input('author_or_editor_name'));
                $prooftype      =   trim($request->input('proof_letter_type'));
                $from_email     =   trim($request->input('from_email'));
                $subjectline    =   trim($request->input('author_or_editor_subject_line'));
                $dateofproof    =   trim($request->input('proof_returned_date'));
                $mailsubject    =   trim($request->input('subject'));
                $toemail        =   rtrim(strtolower($request->input('toemail')),',');
                $ccemail        =   rtrim(strtolower($request->input('ccemail')),',');
                $getroundinfo   =   roundModel::where('ID',$roundid)->first();
                $roundname      =   "";
                $ccemail        =   ($ccemail   ==  "undefined"?'':$ccemail);
                
                $first_remainder    =   $correction_duedate     =   Carbon::parse( $dateofproof );
                
                // read mail part
                $getproof_letter_email  =   proofLetterTypesModel::Active()->find($prooftype);
                $getbookinfo            =   taskLevelMetadataModel::getbookChapteranduserinfo($jobId,$chapterid);
                $wheredata              =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>'aps_proofing_url'];
                
                $opsobj                 =       new apiOpsStatus();
                $aps_proofing_url       =       $opsobj->getProoflinkRecords( $chapterid , null , $roundid );
                 
                if(count($getproof_letter_email)>=1 && count($getbookinfo)>=1 ){
                    $prooflinkGenStatus         =   0;
                    $usrC_obj                   =   new usersController();
                    $currentuser_id             =   $getbookinfo[0]->PM;
                    $user_arr                   =   $usrC_obj->getUserInfoByUserId( $currentuser_id ); 
                    
                    $prooflinkGen               =   isset( $aps_proofing_url->PROOF_LINK ) ? $aps_proofing_url->PROOF_LINK : '';
                    $prooflinkGenStatus         =   ( isset( $aps_proofing_url->PROOF_LINK ) ) ? 1 : 0;
                    
                    $data['bodycontent']        =   $this->docontentreplaceoriginalinfo($getbookinfo,$dateofproof,$nameofaureditr,$getproof_letter_email, $prooflinkGen ); 
                    
                    $response 	=   array('result'=>200, 'errMsg'=>$data['bodycontent'],'validation'=>[] , 'params' => array( 'prooflinkstatus' => $prooflinkGenStatus ) );
                    return response()->json($response);
                    
                }
                
                if( !count($aps_proofing_url) ){
                    $response['errMsg'] =   'Proof Link not yet generated!';
                    return response()->json($response,400);
                }
                $response['errMsg'] =   'Proof Link not yet generated!';
                return response()->json($response,400);
            }
            $response['errMsg'] =   'Bad request method';
            return response()->json($response,400);
            
        }
        catch(\Exception $e )
        {
            $response   =   $this->failedResponse;
            $response['errMsg'] =   $e->getMessage();
            $response['validation'] =   [];
            return response()->json($response);
        }
    }
    
    public function doOpenMergepdf( Request $request ) 
    {
        try{
			
            $response       =   $this->notfoundResponse;
            $response['xmlcount']   =   0;
            
			$validation 	=   Validator::make( 
													$request->all() , [
																		'jobId' => 'required|numeric',
																		'roundid' => 'required|numeric',
																		'metadataid' => 'required|numeric'
                                                                      ] 
												);
            
            if ($validation->fails()){
                $response       =   $this->validationResponse;
                $response['validation'] =   $validation->errors();
                return response()->json($response,400);
            }
            
            $getlocationftp     =   productionLocationModel::doGetLocationname($request->input('jobId'));
            
            if( count( $getlocationftp ) >= 1 ){
                
                $metaid         =   	$request->input('metadataid');
				
                $jobId          =   	$request->input('jobId');
                $roundid        =   	$request->input('roundid');
                
                //get book id 
                $bookdetaills   =   	jobModel::where( 'JOB_ID' , $jobId )->first();
                $bookid         =   	( count( $bookdetaills ) >= 1 ?$bookdetaills->BOOK_ID : '' );
                $hostserver     =   	$getlocationftp->FTP_HOST;
                $hostusername   =   	$getlocationftp->FTP_USER_NAME;
                $hostpassword   =   	Crypt::decryptString($getlocationftp->FTP_PASSWORD);
                $hostpath       =   	$getlocationftp->FTP_PATH;
                
                // Do the FTP connection
                //get pdfmerge path
				
                $wheredelta     =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>'pdfmerge'];
                $getpdfpath     =   apsProductionFilePathValidationModel::Active()->where($wheredelta)->first();
                $wheredata      =   ['JOB_ID'=>$jobId  , 'METADATA_ID'=>$metaid ];
                
                $getchapterinfo =   taskLevelMetadataModel::where($wheredata)->first();
                
				if( count( $getpdfpath ) >= 1 && count( $getchapterinfo ) >= 1 ){
					
                    $chapterno      =   "";
                    $chapternumber  =   $getchapterinfo->CHAPTER_NO;
                    //check part
                    if(strpos(strtoupper($chapternumber),Config::get('constants.CHECK_PART')) !== false)
                    {
                        $chapterno  =   $chapternumber;
                    }else if(in_array(strtolower($chapternumber),Config::get('constants.READ_BM_FM_EXTENSTION'))) //check fm and bm
                    {
                        $chapterno  =   $chapternumber;
                    }else //check chapter
                    {
                        $chapterno  =   preg_replace( '/\D/', '', $chapternumber );
                        $ckey       =   preg_replace("/[0-9_]/", '', $chapternumber);
                    }
                    
                    $ftpObj         =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
                    
                    $pagObj             =       new autoPageController();
                    $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chapternumber ); 
                    extract( $paging_collect );
                    $round_arr		=	\Config::get( 'constants.ROUND_NAME' );
                    $array          =   array(  
                                                '{BID}'     =>  isset( $bookid ) ? $bookid : '', 
                                                '{CNO}'     =>  isset( $chapterno ) ? $chapterno : '' ,
                                                '{PAGING_FILENAMING}'   =>  $pagingfilnaming  ,
                                                '{RNAME}'   =>  $round_arr[$roundid]
                                            );
                    
                    $cmn_obj            =   new CommonMethodsController();         
                    $pdfmergepath       =   $cmn_obj->arr_key_value_replace( $array , $getpdfpath->FILE_PATH );
                    
                    $cucDirFiles        =   $ftpObj->has( $pdfmergepath );
					
                    if( $cucDirFiles     ==  true ){
                        
                        $pdfmergepath   =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver.$pdfmergepath;  
                        $response       =   array('result' => 200 , 'errMsg' => $pdfmergepath , 'xmlcount' => strlen( $pdfmergepath ) );
                        
                        return response()->json($response);
                    }
                    
                    $response['errMsg'] =   'Merge PDF file is not found';
                    return response()->json( $response , 400);   
					
                }
                $response['errMsg'] =   'Aps file validation path is not configured or chapter details not found';
                return response()->json($result,400);
            }
            $response['errMsg'] =   'No files found in the Production Location...';
            return response()->json($result);
        }
        catch( \Exception $e )
        {           
            return response()->json($this->locationNotFoundResponse);
        }
    }
    
    public function doCheckdeltarequiredornot($getjobsheetpath,$getbookinfo,$getlocationftp)
    {
        $validatedelta          =   '';
        if(count($getjobsheetpath)>=1 && count($getlocationftp)>=1 && count($getbookinfo)>=1)
        {
            $hostserver         =   $getlocationftp->FTP_HOST;
            $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   $getlocationftp->FTP_PATH;
            $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);

            $chapternumber      =   $getbookinfo[0]->CHAPTER_NO;
            $chapterno          =   preg_replace( '/\D/', '', $chapternumber );
            $ckey               =   preg_replace("/[0-9_]/", '', $chapternumber);
            $array              =   array(  
                                            '{BID}' =>  $getbookinfo[0]->BOOK_ID, 
                                            '{RNAME}' =>  Config::get('constants.ROUND_NAME.'.$getjobsheetpath->ROUND_ID),
                                            '{CNO}' =>  $chapterno
                                        );
            $round_arr	=	\Config::get( 'constants.ROUND_NAME' );
			
            $cmn_obj            =   new CommonMethodsController();         
            $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $array , $getjobsheetpath->FILE_PATH );
            $isfileavailable    =   $ftpObj->has($jobsheetpath);
            $roundid  =  $round_arr[$getjobsheetpath->ROUND_ID];
			
            if($isfileavailable ==  true){
                
                $crd                    =   'ftp://'.$hostusername.':'.$hostpassword.'@'.$hostserver;   
                $jobsheetlocationpath   =   $crd.$jobsheetpath;
                $metadataXml            =   file_get_contents( $jobsheetlocationpath );
				
                $getjobsheetcontent     =   $cmn_obj->xml2arrayorobject($metadataXml);
               
		if(count($getjobsheetcontent)>=1){
                    $validatedelta      =   (isset($getjobsheetcontent['ChapterJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['DeltaPDF'])?$getjobsheetcontent['ChapterJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForDiscreteBookObjects']['@attributes']['DeltaPDF']:'');
                }
				
		if(count($getjobsheetcontent)>=1 && 'S650' == $roundid ){
                    $validatedelta      =   (isset($getjobsheetcontent['BookJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForCompoundBookObjects']['@attributes']['BookDeltaPDF'])?$getjobsheetcontent['BookJobSheet']['ProductionInfo']['WorkflowInfo']['Supplier']['FullServiceVendor']['Deliverables']['DeliverablesForCompoundBookObjects']['@attributes']['BookDeltaPDF']:'');
                }
				
            }
            
        }
        
        return $validatedelta;
        
    }
    
    public function doCheckfileisexistornot( $getbookinfo ,$getlocationftp , $roundid , $typeoffile )
    {
        $validatedelta          =   '';
        $wheredelta             =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>$typeoffile];
        $getfilepath            =   apsProductionFilePathValidationModel::Active()->where($wheredelta)->first();
        if(count($getfilepath)>=1 && count($getlocationftp)>=1 && count($getbookinfo)>=1)
        {
            $hostserver         =   $getlocationftp->FTP_HOST;
            $hostusername       =   $getlocationftp->FTP_USER_NAME;
            $hostpassword       =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath           =   $getlocationftp->FTP_PATH;
            $ftpObj             =   \Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);

            $chapternumber      =   $getbookinfo[0]->CHAPTER_NO;
            $chapterno          =   preg_replace( '/\D/', '', $chapternumber );
            $ckey               =   preg_replace("/[0-9_]/", '', $chapternumber);
            
            
            $pagObj             =       new autoPageController();
            $paging_collect     =       $pagObj->getPagingFileNameing( $getbookinfo[0]->BOOK_ID , $chapternumber ); 
            extract( $paging_collect );
            
            $array              =   array(  
                                            '{BID}'     =>      $getbookinfo[0]->BOOK_ID,                 
                                            '{RNAME}'   =>      Config::get('constants.ROUND_NAME.'.$getfilepath->ROUND_ID),
                                            '{CNO}'     =>      $chapterno , 
                                            '{CID}'     =>      $chapternumber ,
                                            '{PAGING_FILENAMING}'   =>  $pagingfilnaming
                                        );
            
            $cmn_obj            =   new CommonMethodsController();         
            $jobsheetpath       =   $cmn_obj->arr_key_value_replace( $array , $getfilepath->FILE_PATH );
            
            $isfileavailable    =   $ftpObj->has($jobsheetpath);
            
            if($isfileavailable ==  true){
                $validatedelta  =   true;
            }else{
                //echo $jobsheetpath;
            }
            
        }
        
        return $validatedelta;
    }
    
    public function doPostApsmetaxml($getbookinfo,$roundid,$token_key,$cmn_obj,$getlocationftp)
    {
        $metapost['metapost']       =   false;
        $metapost['metacontent']    =   '';
        //get pdfmerge path
        $wheredelta             =   ['ROUND_ID'=>$roundid,'FILE_PATH_TYPE'=>'pdfmerge'];
        $getfilepath            =   apsProductionFilePathValidationModel::Active()->where($wheredelta)->first();
        if(count($getbookinfo)>=1 && count($getlocationftp)>=1 && count($getfilepath)>=1)
        {
            $book_id        =   $getbookinfo[0]->BOOK_ID;
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            $ftpObj         =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);

            $round_name     =   Config::get('constants.ROUND_NAME.'.$roundid);
            $_file_path     =   Config::get('constants.FILE_SERVER_ROOT_DIR').Config::get('constants.PACKAGE_PATH.DESTINATIONPATH'); 
            $chapternumber  =   $getbookinfo[0]->CHAPTER_NO;
            $chapterno      =   preg_replace( '/\D/', '', $chapternumber );
            $ckey           =   preg_replace("/[0-9_]/", '', $chapternumber);
            $array          =   array(  
                                            '{BID}' =>  $getbookinfo[0]->BOOK_ID, 
                                            '{CNO}' =>  $chapterno
                                        );
            $cmn_obj        =   new CommonMethodsController();         
            $tapsoutpath    =   $cmn_obj->arr_key_value_replace( $array , $getfilepath->FILE_PATH );
            $tapsoutpath    =   ltrim($tapsoutpath,'/');
            $_file_path     =   $hostserver.Config::get('constants.FILE_SERVER_ROOT_DIR').$tapsoutpath;
            $_file_path     =   $cmn_obj->backslashPathPrepare( $_file_path , true );
            $_upload_path   =   Config::get('constants.PACKAGE_PATH.PACKAGE_UPLOAD_PATH');    
            $ftp_host       =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.host');
            $ftp_username   =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.username');
            $ftp_password   =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.password');
            $ftp_type       =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.type');
            $fingerPrint    =   Config::get('constants.CLIENT_INFORMATION.UPLOAD_FTP_INFO.apsfingerprint');
            $ret_url        =   url('/api/apscallback');
            $chapter_id     =   $getbookinfo[0]->METADATA_ID;
            $uploadMeta = "";            
            $uploadMeta .= "<uploadMeta>";
            $uploadMeta .= "<bookid>" . $book_id. "</bookid>";
            $uploadMeta .= "<stage>" . $round_name . "</stage>";
            $uploadMeta .= "<uploadtype>PACKAGE_UPLOAD</uploadtype>";
            $uploadMeta .= "<sourceFile>";
            $uploadMeta .= "<filepath>" .$_file_path."</filepath>";
            $uploadMeta .= "</sourceFile>";
            $uploadMeta .= "<destPath>";
            $uploadMeta .= "<ftpType>".$ftp_type."</ftpType>";
            $uploadMeta .= "<fingerPrint>".$fingerPrint."</fingerPrint>";
            $uploadMeta .= "<ftpSite>".$ftp_host."</ftpSite>";
            $uploadMeta .= "<path>".$_upload_path."</path>";
            $uploadMeta .= "<username>".$ftp_username."</username>";
            $uploadMeta .= "<password>".$ftp_password."</password>";
            $uploadMeta .= "</destPath>";
            $uploadMeta .= '<WorkflowAPI>
                                <Url value="'.$ret_url.'"/>
                                <parameter key="process" value="upload" type="fixed"/>
                                <parameter key="jobid" value="'.$getbookinfo[0]->JOB_ID.'" type="fixed"/>
                                <parameter key="chapterid" value="'.$chapter_id.'" type="fixed"/>
                                <parameter key="bookid" value="'.$book_id.'" type="fixed"/>
                                <parameter key="tokenkey" value="'.$token_key.'" type="fixed"/>
                                <parameter key="round" value="'.$roundid.'" type="fixed"/>
                                <parameter key="status" type="boolean"/>
                                <parameter key="endtime" value="{0:yyyy-MM-dd HH-mm-ss}" type="data-time"/>
                                <parameter key="remarks" type="string"/>
                            </WorkflowAPI>';
            $uploadMeta .= "</uploadMeta>";

            $content 	= 	$uploadMeta;
            $filename 	=	$token_key.'_'.$chapter_id.'_aps_upload_meta.xml';
            $watchpath                  =   Config::get('constants.PRODUCTION_TOOLS_SETUP.UPLOAD_WATCH_FOLDER').'/';
            $ftpInfo['HOST']            =   $hostserver;
            $ftpInfo['FTP_USERNAME']    =   $hostusername;
            $ftpInfo['FTP_PASSWORD']    =   $hostpassword;
            $successfileresponse        =   app('App\Http\Controllers\Api\autostageController')->writeMetafiletoWatchFolder( $filename , $content , $ftpInfo , $watchpath  );
            $metapost['metacontent']    =   $content;
            $successfileresponse    =   true;
            if($successfileresponse == true)
            {
                $metapost['metapost']   =   true;
            }
        }
        return $metapost;
    }
    
    public function docontentreplaceoriginalinfo($getbookinfo,$dateofproof,$nameofaureditr,$getproof_letter_email,$aps_url)
    {
        $usrC_obj                   =   new usersController();
        $currentuser_id             =   $getbookinfo[0]->PM;
        $user_arr                   =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
        $mailData['ToName']         =   (count($user_arr)>=1?$user_arr->LAST_NAME:'').' '.(count($user_arr)>=1?$user_arr->FIRST_NAME:'');
        $mailData['PMNAME']         =   $mailData['ToName'];
        $faxnum                     =   (count($user_arr)>=1?$user_arr->FAX:''); 
        $mailData['T_ADDRESS']      =   (count($user_arr)>=1?$user_arr->T_ADDRESS:''); 
        $mailData['T_CITY']         =   (count($user_arr)>=1?$user_arr->T_CITY:''); 
        $mailData['T_STATE']        =   (count($user_arr)>=1?$user_arr->T_STATE:''); 
        $mailData['T_ZIP']          =   (count($user_arr)>=1?$user_arr->T_ZIP:''); 
        $mailData['P_COUNTRY']      =   (count($user_arr)>=1?$user_arr->P_COUNTRY:''); 
        $mailData['EMAIL']          =   (count($user_arr)>=1?$user_arr->EMAIL:''); 
        $mailData['WORK_PHONE']     =   (count($user_arr)>=1?$user_arr->WORK_PHONE:''); 
        $personalphone              =   (count($user_arr)>=1?$user_arr->PERSONAL_PHONE:''); 
        //get  country name
        $countryname                =   CountriesModel::find($mailData['P_COUNTRY']);
        $countryname                =   (count($countryname)>=1?$countryname->name:'');
        $inp_rep_arr                =   array( 
                                                '<BookTitle>'   =>      $getbookinfo[0]->JOB_TITLE,
                                                '<ChapterTitle>'=>      $getbookinfo[0]->CHAPTER_NAME,
                                                '<ProofDate>'   =>      Carbon::parse($dateofproof)->format('jS-M-Y') , 
                                                '<surname>'     =>      $nameofaureditr ,
                                                '<link>'        =>      ($aps_url     ==  ''? 'Proof Link not yet Generated.' : $aps_url) ,
                                                '<link1>'       =>      ($aps_url     ==  ''? 'Proof Link not yet Generated.' : $aps_url) ,
                                                '<signature>'   =>      $mailData['ToName'] ,
                                                '[T_ADDRESS]'   =>      ($mailData['T_ADDRESS']     ==  ''?'':$mailData['T_ADDRESS']),
                                                '[T_CITY]'      =>      ($mailData['T_CITY']        ==  ''?'':$mailData['T_CITY']),
                                                '[T_STATE]'     =>      ($mailData['T_STATE']       ==  ''?'':$mailData['T_STATE']),
                                                '[T_ZIP]'       =>      ($mailData['T_ZIP']         ==  ''?'':$mailData['T_ZIP']),
                                                '[P_COUNTRY]'   =>      ($countryname               ==  ''?'':$countryname),
                                                '<groupemail>'  =>      $mailData['EMAIL'] ,
                                                '<email>'       =>      $mailData['EMAIL'] ,
                                                '<telephone>'   =>      ($mailData['WORK_PHONE']    ==  ''?'':"T: ".$mailData['WORK_PHONE']),
                                                '<fax>'         =>      ($faxnum           ==  ''?'':"F: ".$faxnum),
                                                '<user_designation>'    =>      (count($user_arr)>=1?$user_arr->NAME:'')
                                            );

        $cmn_obj                    =   new CommonMethodsController();
        $bodycontent                =   stripslashes($getproof_letter_email->BODY);
        return $cmn_obj->arr_key_value_replace( $inp_rep_arr , $bodycontent ); 
    }
    
    public function apsremainderemailtemp()
    {
        $getremainderchapterlist    =   apsProofingStatusModel::getapsremaindermaillist();
        if(count($getremainderchapterlist)>=1)
        {
            foreach($getremainderchapterlist as $key=>$remaindervalue)
            {
                $metadataid         =   $remaindervalue->METADATA_ID;
                $jobid              =   $remaindervalue->JOB_ID;
                $round              =   $remaindervalue->ROUND;
                $PROOFING_URL       =   $remaindervalue->PROOFING_URL;
                $correction_date    =   $remaindervalue->CORRECTION_DUE;
                $mailArray          =   $mailData   =   [];
                $job_info           =   jobModel::getJobdetails($jobid);
                $getrecipientmail   =   taskLevelMetadataModel::where(['METADATA_ID'=>$metadataid])->first();
                $getemailcontent    =   remainderEmailTemplateModel::where('TEMP_TYPE',2)->first();
                if(count($job_info)>=1 && count($getrecipientmail)>=1 && count($getemailcontent)>=1)
                {
                    $mailsendFlag               =   false;
                    $mailtoAmFlag               =   false;
                    $mailtoPmFlag               =   false;
                    $pm_userid                  =   $job_info->PM;
                    $am_userid                  =   $job_info->AM;
                    $jobId                      =   $job_info->JOB_ID;
                    $mailArray['JOB_ID']        =   $jobId;
                    $mailArray['METADATA_ID']   =   $metadataid;
                    $mailArray['ROUND_ID']      =   $remaindervalue->ROUND;
                    $usrC_obj                   =   new usersController();
                    $mailArray['ToMail']        =   $remaindervalue->TO_EMAIL;
                    $mailData['ToName']         =   $remaindervalue->NAME;
                    
                    $mailData['BookId']         =   $job_info->BOOK_ID;
                    $mailData['Title']          =   $remaindervalue->SUBJECT_LINE;
                    $mailData['authorname']     =   $job_info->AUTHOR_NAME;
                    $mailData['editorname']     =   $job_info->EDITOR_NAME;
                    $mailData['BookIsbn']       =   $job_info->ISSN_ONLINE;
                    $mailData['ReceivedDate']   =   $job_info->JOB_ASSIGNED_DATE;
                    $mailData['AUTHORNAME']     =   $job_info->AUTHOR_NAME;
                    $mailData['BOOK_TITLE']     =   $job_info->JOB_TITLE;
                    $mailData['BookTitle']      =   $job_info->JOB_TITLE;
//                    echo Carbon::parse($remaindervalue->CORRECTION_DUE)->format('l jS \\of F Y');
                    $proofsentdate              =   Carbon::parse($remaindervalue->START_TIME)->format('jS M Y');
                    $mailData['INSERT_DATE']    =   Carbon::parse($remaindervalue->CORRECTION_DUE)->format('jS M Y');
                    $mailData["IMPRINT_NAME"]   =   $job_info->PUBLISHER_IMPRINT_NAME;
                    $usrC_obj                   =   new usersController();
                    $currentuser_id             =   $job_info->PM;
                    $user_arr                   =   $usrC_obj->getUserInfoByUserId($currentuser_id); 
                    $mailData['ToName']         =   (count($user_arr)>=1?$user_arr->LAST_NAME:'').' '.(count($user_arr)>=1?$user_arr->FIRST_NAME:'');
                    $mailData['PMNAME']         =   $mailData['ToName'];
                    $mailData['FAX']            =   (count($user_arr)>=1?$user_arr->FAX:''); 
                    $mailData['T_ADDRESS']      =   (count($user_arr)>=1?$user_arr->T_ADDRESS:''); 
                    $mailData['T_CITY']         =   (count($user_arr)>=1?$user_arr->T_CITY:''); 
                    $mailData['T_STATE']        =   (count($user_arr)>=1?$user_arr->T_STATE:''); 
                    $mailData['T_ZIP']          =   (count($user_arr)>=1?$user_arr->T_ZIP:''); 
                    $mailData['P_COUNTRY']      =   (count($user_arr)>=1?$user_arr->P_COUNTRY:''); 
                    $mailData['EMAIL']          =   (count($user_arr)>=1?$user_arr->EMAIL:''); 
                    $mailData['WORK_PHONE']     =   (count($user_arr)>=1?$user_arr->WORK_PHONE:''); 
                    $mailData['PERSONAL_PHONE'] =   (count($user_arr)>=1?$user_arr->PERSONAL_PHONE:''); 
                    $findwordcount              =   str_word_count($job_info->JOB_TITLE,'1');
                    $titlewordname              =   $job_info->JOB_TITLE;
                    if(is_array($findwordcount) && isset($findwordcount[2]))
                    {
                        $titlewordname          =   implode(" ",array_slice($findwordcount,0,3));
                    }
                    //get  country name
                    $countryname                =   CountriesModel::find($mailData['P_COUNTRY']);
                    $countryname                =   (count($countryname)>=1?$countryname->name:'');
                    $mailArray['Subject']       =   "Your book: ".$job_info->ISSN_ONLINE.", ".$job_info->EDITOR_NAME.": ".$titlewordname;
                    $mailArray['Subject']       =   $remaindervalue->SUBJECT_LINE;
                    $emailbodycontent           =   $remaindervalue->EMAIL_CONTENT;
                    $firstrememailbodycontent   =   $getemailcontent->FIRST_REMAINDER;
                    $secondrememailbodycontent  =   $getemailcontent->SECOND_REMAINDER;
                    $thirdrememailbodycontent   =   $getemailcontent->THIRD_REMAINDER;
                    $forwardbodycontent         =   $getemailcontent->FORWARD_TEMP;
                    $emailtextreplace           =   array(
                                                        '[BOOK_TITLE]'      =>  $mailData['BookTitle'],
                                                        '<surname>'         =>  $mailData['ToName'],
                                                        '<signature>'       =>  $mailData['ToName'] ,
                                                        '[AUTHORNAME]'      =>  ($mailData['authorname']    ==  ''?$mailData['editorname']:$mailData['authorname']),
                                                        '<link1>'           =>  $PROOFING_URL,
                                                        '<link>'            =>  $PROOFING_URL,
                                                        '<ProofDate>'       =>  $mailData['INSERT_DATE'],
                                                        '<SentDate>'        =>  $proofsentdate,
                                                        '[PMNAME]'          =>  $mailData['PMNAME'],
                                                        '[IMPRINT_NAME]'    =>  $mailData["IMPRINT_NAME"],
                                                        '[T_ADDRESS]'       =>  ($mailData['T_ADDRESS']     ==  ''?'':"<p>".$mailData['T_ADDRESS']."</p>"),
                                                        '[T_CITY]'          =>  ($mailData['T_CITY']        ==  ''?'':"<p>".$mailData['T_CITY']."</p>"),
                                                        '[T_STATE]'         =>  ($mailData['T_STATE']       ==  ''?'':"<p>".$mailData['T_STATE']."</p>"),
                                                        '[T_ZIP]'           =>  ($mailData['T_ZIP']         ==  ''?'':"<p>".$mailData['T_ZIP']."</p>"),
                                                        '[P_COUNTRY]'       =>  ($countryname               ==  ''?'':"<p>".$countryname."</p>"),
                                                        '[WORK_PHONE]'      =>  ($mailData['WORK_PHONE']    ==  ''?'':"<p>T: ".$mailData['WORK_PHONE']."</p>"),
                                                        '[FAX]'             =>  ($mailData['FAX']           ==  ''?'':"<p>F: ".$mailData['FAX']."</p>"),
                                                        '[TOEMAIL]'         =>  $mailData['EMAIL'],
                                                        '<email>'       =>      $mailData['EMAIL'] 
                                                     );
                    $emailforwardtextreplace        =   array(
                                                        '[SUBJECT_EMAIL]'   =>  $mailArray['Subject'],
                                                        '[FROM_EMAIL]'      =>  Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL'),
                                                        '[TIME_SENT_EMAIL]' =>  Carbon::parse($remaindervalue->START_TIME)->format('l jS \\of F Y'),
                                                        '[TO_EMAIL]'        =>  $remaindervalue->TO_EMAIL,
                                                        '[CC_EMAIL]'        =>  $remaindervalue->CC_EMAIL
                                                     );

                    $cmn_obj                    =   new CommonMethodsController();
                    $emailbodyoriginalcontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $emailbodycontent , true );
                    $firstremainderemailbodycontent =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $firstrememailbodycontent , true );
                    $secondrememailbodycontent  =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $secondrememailbodycontent , true );
                    $thirdrememailbodycontent   =   $cmn_obj->arr_key_value_replace( $emailtextreplace , $thirdrememailbodycontent , true );
                    $forwardbodycontent         =   $cmn_obj->arr_key_value_replace( $emailforwardtextreplace , $forwardbodycontent , true );
                    $checkexistemailid          =   $remaindervalue->APSEMAILLOG_ID;
                    $firstremainderalreadysent  =   $remaindervalue->FIRST_REMAINDER;
                    $secondremainderalreadysent =   $remaindervalue->SECOND_REMAINDER;
                    $thirdremainderalreadysent  =   $remaindervalue->THIRD_REMAINDER;
                    $firsttyperemainderemail    =   "";
                    $secondtyperemainderemail   =   "";
                    $thirdtyperemainderemail    =   "";
                    $emailsplithrline           =   '<div class="hr" style="height:2px;border-bottom:2px solid #afa7a7;clear: both;">&nbsp;</div><br><br>';
                    $bodywholecontent           =   "";
                    //mail data build
                    $mailArray['TemplateName']  =   'emailtemplate.apsmailsetupalert.aps-emailalert';
                    $mailArray['FromMail']      =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
                    $mailArray['FromName']      =   $remaindervalue->FROM_NAME;
                    $mailArray['Title']         =   $remaindervalue->SUBJECT_LINE;
                    $mailArray['ToMail']        =   "vinoth.t@spi-global.com";
                    
                    if(strpos($mailArray['ToMail'],',') !== false)
                    {
                        $toemailarray           =   explode(',',$mailArray['ToMail']);
                        $mailArray['ToMail']    =   array_unique($toemailarray);
                    }
                    $mailArray['CcMail']        =   $remaindervalue->CC_EMAIL; 
                    $mailArray['CcMail']        =   "vinoth.t@spi-global.com,vinoth.t@spi-global.com"; 
                    if(strpos($mailArray['CcMail'],',') !==  false)
                    {
                        $toemailarray           =   explode(',',$mailArray['CcMail']);
                        $mailArray['CcMail']    =   array_unique($toemailarray);
                    }else{
                        $mailArray['CcMail']    =   $mailArray['CcMail'];
                    }
                    
                    // mail send
                    $mailattachtarget               =   public_path().'/apsAttachmentfile/';
                    $mailattachfilename             =   $remaindervalue->MAIL_ATTACHMENT_URL;
                    $getfileofattachmentloc         =   $mailattachtarget.$mailattachfilename;
                    if(file_exists($getfileofattachmentloc))
                    {
                        $mailArray['file']          =   $getfileofattachmentloc;
                        $mailArray['attachfile']    =   array('as' => $mailattachfilename, 'mime' => 'text/plain');
                    }
                    
                    $mailArray['EMAIL_LOG_ID']  =   $checkexistemailid;
                    
                    if($remaindervalue->REM1    ==  1  && $remaindervalue->FIRST_REMAINDER_EMAIL_STATUS  ==  1  && $firstremainderalreadysent   !=  1)
                    {  
                        $mailData['THIRDMAIL']      =   "";
                        $mailData['SECONDMAIL']     =   "";
                        $mailData['FIRSTMAIL']      =   "";
                        $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                        $mailData['FORWARDMAIL']    =   "";
                        $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                        $bodywholecontent           .=   $firstremainderemailbodycontent;
                        $bodywholecontent           .=   $forwardbodycontent;
                        $bodywholecontent           =   $emailbodyoriginalcontent;
                        $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                        $mailData['bodycontent']    =   $bodywholecontent;
                        $mailArray['Data']          =   $mailData;
                        $mailArray['FIRST_REMAINDER']   =   '1';
                        // check exist aps log email
                        $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.APS')];
                        $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                        if(count($getapslogemail)>=1)
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                            $checkexistemailid      =   $getapslogemail->ID;
                        }
                        $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                        if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                        }
                        $Response                   =   $this->sendMailBladeTemplate($mailArray);
                    }
                    
                    if($remaindervalue->REM2    ==  1  && $remaindervalue->SECOND_REMAINDER_EMAIL_STATUS  ==  1 && $secondremainderalreadysent   !=  1)
                    {
                        $mailData['THIRDMAIL']      =   "";
                        $mailData['FIRSTMAIL']      =   "";
                        $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                        $mailData['SECONDMAIL']     =   "";
                        $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                        $mailData['FORWARDMAIL']    =   "";
                        $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                        $bodywholecontent           .=   $firstremainderemailbodycontent;
                        $bodywholecontent           .=   $forwardbodycontent;
                        $bodywholecontent           .=   $secondrememailbodycontent;
                        $bodywholecontent           =   $emailbodyoriginalcontent;
                        $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                        $mailData['bodycontent']    =   $bodywholecontent;
                        $mailArray['Data']          =   $mailData;
                        $mailArray['SECOND_REMAINDER']  =   '1';
                        // check exist aps log email
                        $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.APS')];
                        $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                        if(count($getapslogemail)>=1)
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                            $checkexistemailid      =   $getapslogemail->ID;
                        }
                        $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                        if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                        }
                        $Response                   =   $this->sendMailBladeTemplate($mailArray);
                    }
                    
                    if($remaindervalue->REM3    ==  1 && $remaindervalue->THIRD_REMAINDER_EMAIL_STATUS  ==  1 &&  $thirdremainderalreadysent   !=   1)
                    {   
                        $mailData['FIRSTMAIL']      =   "";
                        $mailData['FIRSTMAIL']      .=  $firstremainderemailbodycontent;
                        $mailData['SECONDMAIL']     =   "";
                        $mailData['SECONDMAIL']     .=  $secondrememailbodycontent;
                        $mailData['THIRDMAIL']      =   "";
                        $mailData['THIRDMAIL']      .=  $thirdrememailbodycontent;
                        $mailData['FORWARDMAIL']    =   "";
                        $mailData['FORWARDMAIL']    .=  $forwardbodycontent;
                        $bodywholecontent           .=   $firstremainderemailbodycontent;
                        $bodywholecontent           .=   $forwardbodycontent;
                        $bodywholecontent           .=   $secondrememailbodycontent;
                        $bodywholecontent           .=   $forwardbodycontent;
                        $bodywholecontent           .=   $thirdrememailbodycontent;
                        $bodywholecontent           =   $emailbodyoriginalcontent;
                        $mailData['DEFAULTTEMP']    =   $emailbodyoriginalcontent;
                        $mailData['bodycontent']    =   $bodywholecontent;
                        $mailArray['Data']          =   $mailData;
                        $mailArray['THIRD_REMAINDER']   =   '1';
                        // check exist aps log email
                        $apswheredata               =   ['METADATA_ID'=>$metadataid,'JOB_ID'=>$jobId,'ROUND'=>$round,'REMAINDER_TYPE'=>Config::get('constants.REMAINDER_TYPE.APS')];
                        $getapslogemail             =   emailRemainderLogModel::where($apswheredata)->orderby('ID','desc')->first();
                        if(count($getapslogemail)>=1)
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getapslogemail->ID;
                            $checkexistemailid      =   $getapslogemail->ID;
                        }
                        $getemaillogid              =   $this->doProcessMaillog($checkexistemailid,$bodywholecontent,$mailArray);
                        if(array_key_exists('EMAIL_LOG_ID', $getemaillogid))
                        {
                            $mailArray['EMAIL_LOG_ID']  =   $getemaillogid['EMAIL_LOG_ID'];
                        }
                        $Response                   =   $this->sendMailBladeTemplate($mailArray);
                    }
//                        return view('emailtemplate.apsmailsetupalert.aps-emailalert')->with( $mailData );
                }
            }
        }
    }
    
    public function doProcessMaillog($checkexistemailid,$bodywholecontent = null,$mailArray)
    {
        $firsttyperemainderemail            =   (isset($mailArray['FIRST_REMAINDER'])?$mailArray['FIRST_REMAINDER']:0);
        $secondtyperemainderemail           =   (isset($mailArray['SECOND_REMAINDER'])?$mailArray['SECOND_REMAINDER']:0);
        $thirdtyperemainderemail            =   (isset($mailArray['THIRD_REMAINDER'])?$mailArray['THIRD_REMAINDER']:0);
        if(!empty($checkexistemailid)>=1)
        {
            $updatedata                         =   [];
            $updatedata['BODY_OF_MAIL']         =   $bodywholecontent;
            $updatedata['TO_EMAIL']             =   $mailArray['ToMail'];    
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $updatedata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else{
                $updatedata['CC_EMAIL']         =   $mailArray['CcMail'];
            }
            if(!empty($firsttyperemainderemail))
            {
                $updatedata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $updatedata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $updatedata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            emailRemainderLogModel::where('ID',$checkexistemailid)->update($updatedata);
            $lastemaillogid                     =   $checkexistemailid;
        }else{
            $insertdata                         =   [];
            $insertdata['JOB_ID']               =   $mailArray['JOB_ID'];
            $insertdata['METADATA_ID']          =   $mailArray['METADATA_ID'];
            $insertdata['ROUND']                =   $mailArray['ROUND_ID'];
            $insertdata['STATUS']               =   Config::get('constants.STATUS_ENUM.INPROGRESS');
            $insertdata['BODY_OF_MAIL']         =   $bodywholecontent;
            $insertdata['TO_EMAIL']             =   $mailArray['ToMail'];
            if(is_array($mailArray['CcMail']) && count($mailArray['CcMail'])>=1)
            {
                $insertdata['CC_EMAIL']         =   implode(',',$mailArray['CcMail']);
            }else
            {
                $insertdata['CC_EMAIL']         =   $mailArray['CcMail'];   
            }
            if(!empty($firsttyperemainderemail))
            {
                $insertdata['FIRST_REMAINDER']  =   $firsttyperemainderemail;
            }
            if(!empty($secondtyperemainderemail))
            {
                $insertdata['SECOND_REMAINDER'] =   $secondtyperemainderemail;
            }
            if(!empty($thirdtyperemainderemail))
            {
                $insertdata['THIRD_REMAINDER']  =   $thirdtyperemainderemail;
            }
            $insertdata['CREATED_DATE']         =   Carbon::now();
            $insertdata['REMAINDER_TYPE']       =   Config::get('constants.REMAINDER_TYPE.APS');
            $lastemaillogid                     =   emailRemainderLogModel::insertGetId($insertdata);
            $mailArray['EMAIL_LOG_ID']          =   $lastemaillogid;
        }
        return $mailArray;
    }

    public function uploadPdfForOps( $metavalueid , $round ){
        
        $metaid         =       $metavalueid;
        $tsklMeta       =       new taskLevelMetadataModel();
        $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
        
        $metadata       =       $meta_info->toArray();
        $metadata       =       $metadata[0];
        $appFolder      =       'proofing_upload/';
        $job_id =   $jobid          =       $insertData['JOB_ID']  =       ( $metadata['JOB_ID'] );
        
        $bi_obj                  =       new bookinfoModel();
        $bookinfo                =       $bi_obj->getBookinfodetails( $jobid );
        $bookinfo                =       $bookinfo->pluck('BOOK_ID')->toArray(); 
        
        if(empty( $bookinfo ))  
            throw new \Exception( 'Job information is not found' );        
        
        $book_id                 =       $bookinfo[0];
        $getlocationftp          =       productionLocationModel::doGetLocationname( $job_id );

        if( empty( $getlocationftp ) )            
           $getlocationftp      =       productionLocationModel::getDefaultProductionLocationInfo();
        
        $host                   =       $getlocationftp->FTP_HOST.'/';
        $ftp_path               =       $getlocationftp->FTP_PATH;
        $file_ser_path          =       $getlocationftp->FILE_SERVER_PATH;
        $metaPostInfo['ftpInfo']=       $getlocationftp;
        
        $hostserver     =   $getlocationftp->FTP_HOST;
        $hostusername   =   $getlocationftp->FTP_USER_NAME;
        $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        $hostpath       =   $getlocationftp->FTP_PATH;
        $hostuserfieserver      =   $getlocationftp->FILE_SERVER_USER_NAME;
        $hostpasswordfieserver  =   $getlocationftp->FILE_SERVER_PASSWORD;
        
        $_file_path          =   \Config::get('dynamicConstant.PDF_MERGE_OUTPUT_PATH');
        
        $pagObj             =       new autoPageController();
        $cmn_obj            =       new CommonMethodsController();
        
        $paging_collect     =       $pagObj->getPagingFileNameing( $book_id , $metadata['CHAPTER_NO'] ); 
        extract( $paging_collect );
        
        $inp_rep_arr['{PAGING_FILENAMING}'] =   $pagingfilnaming;
        $file_name      =       $pagingfilnaming.'_Author.pdf';
        
        $_file_path     =       $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $_file_path )  , false );
       
        // Do the FTP connection
        $ftpObj         =       Storage::createFtpDriver([
                                            'host'     => $hostserver, 
                                            'username' => $hostusername,
                                            'password' => $hostpassword, // 
                                            'port'     => '21',
                                            'timeout'  => '30',
                                    ]); 
        
        
        $file_ob        	=           $ftpObj->get( $_file_path );
        
        if (!file_exists(public_path( $appFolder ))){
            File::makeDirectory( public_path($appFolder) , $mode = 0777 , true , true );
        }

        $putfile            =       file_put_contents( public_path($appFolder.$file_name) , $file_ob );
       
        return $putfile;
        
    }
    
    public function prepareCollabarativePdf( $metavalueid , $round  ){
        
        $insertData     =       array();
        
        $chapterno          =       '';
        $pagingfilnaming    =       '';
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        
        $roundname          =       $round_arr[ $round ];
        $inp_rep_arr        =       array();
        
        $insertData['ROUND']            =       $round;
        $insertData['START_TIME']       =       date('Y-m-d H:i:s');
        $insertData['STATUS']           =       1;
        $insertData['REMARKS']          =       '';
        $inputpathPdf           =       '\\\\'.$_SERVER['SERVER_NAME'].'\\'.\Config::get('dynamicConstant.OPS_PDF_INPUT_PATH');
        $cmn_obj                =       new CommonMethodsController();
        
        switch( $roundname ){
            
            case 'S600' :   
                
                $insertData['VOLUME_ISSUE']         =       $metavalueid;
                $jobid      =       $insertData['JOB_ID']           =       '';                
                break;
            
            default : 
                
                $insertData['METADATA_ID']      =   $metavalueid;
                
                $metaid         =       $metavalueid;
                $tsklMeta       =       new taskLevelMetadataModel();
                $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
                
                $metadata       =       $meta_info->toArray();
                $metadata       =       $metadata[0];
                
                $jobid          =       $insertData['JOB_ID']  =       ( $metadata['JOB_ID'] );
                $bookInfo               =       jobModel::getJobdetails( $jobid );
                $chapterno      =       $metadata['CHAPTER_NO'];
                
                $inp_rep_arr    =       array( '{CID}' => $chapterno  , '{BID}' =>  $bookInfo->BOOK_ID );
                
                break;
            
        }
        
        $pagObj             =       new autoPageController();
        $getJobInfo         =       DB::table('job')->select()->where('JOB_ID', '=' , $jobid )->get()->last();

        if( count( $getJobInfo ) ){
            
            $bookid             =       $getJobInfo->BOOK_ID;
            $paging_collect     =       $pagObj->getPagingFileNameing( $bookid , $chapterno ); 
            extract( $paging_collect );
            
        }
        
        $inp_rep_arr['{PAGING_FILENAMING}']      =              $pagingfilnaming;
        $insertData['META_VALUE']                =              $pagingfilnaming.'_Author';
        
        $this->uploadPdfForOps( $metavalueid  , $round );
        
        $inputpathPdf                   =       $cmn_obj->backslashPathPrepare( $cmn_obj->arr_key_value_replace( $inp_rep_arr , $inputpathPdf )  , true );
	    $insertData['INPUT_PDF_PATH']   =       $inputpathPdf;
         
        return  DB::table('api_ops_status')->insertGetId( $insertData );    
        
    }
    
    public function pmProofOutMailNotificationSend(){
        
        $mailsendThreads        =       $this->getMailThreadIds();
        
        $response['status']     =       0;
        $response['msg']        =       'Success';
        $response['errMsg']     =       'Queye is free now';
        
        if( count( $mailsendThreads ) ){
            
            foreach( $mailsendThreads as $key => $recData ){
                
                $ops_id         =       isset( $recData->OPS_PROOF_ID ) ? $recData->OPS_PROOF_ID : null;
                
                if( !empty( $ops_id ) ){
                    
                    $recod_meta     =       DB::table('api_ops_status')
                                                ->select()
                                                ->where( 'ID' , '=' , $ops_id )
                                                ->first();
                    
                    if( count( $recod_meta ) ){
                        
                        $metaid         =      $recod_meta->METADATA_ID;
                        $round          =      $recod_meta->ROUND;
                        
                        $mailArray      =      $this->preparePmMailRequiredInformation( $metaid , $round );
                        
                        if( $mailArray ){
                            
                            $response       =       $this->sendCmnMail( $mailArray );
                            $status         =       ( $response['status'] == 1 ) ? 2 : 3;
                            
                            //update the status
                            $upstatus       =       $this->updatePmMailStatus( array('STATUS' => $status , 'REMARKS' => $response['errMsg'] )  , $ops_id );
                            $response['updatestatus']       =   $upstatus;
                            
                        }else{
                            
                            $response['errMsg']     =   'Invalid try..,Required information is missing';
                            
                            //update the status
                            $upstatus       =   $this->updatePmMailStatus( array('STATUS' => 3 , 'REMARKS' => $response['errMsg'] ) , $ops_id );
                            $response['updatestatus']       =   $upstatus;
                            
                        }
                        
                        //$this->sendMailBladeTemplate( $mailArray );
                        
                        
                    }
                    
                }else{
                    
                    $response['errMsg']     =       'Invalid try..,';
                    
                }
                
                
            }
        
        }
        
        
        return response()->json( $response );
        
    }
    
    public function preparePmMailRequiredInformation( $metaid , $round ){
        
        //return array( 'to' => 'ananth.b@spi-global.com' , 'sub' => 'testing' , 'bdy' => 'hello test' );
        
        $tsklMeta       =       new taskLevelMetadataModel();
        $meta_info      =       $tsklMeta->getMetadatadetailsChapter( $metaid );
        $response       =       array();
        
        $cmnobj         =       new CommonMethodsController();
        
        if( count( $meta_info ) ){
            
            $metadata       =       $meta_info[0];
            $jbid           =       $metadata->JOB_ID;
            $jobDetails     =       DB::table('job')->where('JOB_ID', $jbid )->get();
            
            if( count( $jobDetails ) ){
                
                $jobInf         =       $jobDetails[0];
                $userpmid       =       $jobInf->PM;
                
                $usercont       =       new usersController();
                $userinfo       =       $usercont->getUserInfoByUserId( $userpmid );
                $bookid         =       $jobInf->BOOK_ID;
                
                if( isset( $userinfo->EMAIL ) && !empty( $userinfo->EMAIL ) ){
                    
                    $response['to']         =       'ananth.b@spi-global.com';
                    //$response['to']       =       $userinfo->EMAIL;
                    $chpter_no              =       preg_replace( '/\D/' , '', $metadata->CHAPTER_NO );
                    
                    $subject                =       'Springer :: Collaborative Pdf Notification :: BookID: '.$bookid.' :: Chapter No. - : '.$chpter_no;
                    
                    $tmplate                =       'Hi [PMNAME],<br/>
                                                        This Chapter <b>"[CHAPTER_TITLE]"</b> successfully Proofed out by the Author/Editor ,<br/>
                                                        Kindly do the furhter actions.<br/>
                                                     Regards<br/>
                                                     -Magnus';
        
                    $stageid                =       \Config::get('dynamicConstant.STAGE_COLLEECTION.EPROOF');
                    $roundid                =       \Config::get('constants.ROUND_NAME.S300');
                    
                    $wheredata              =       [
                                                        'STAGE_ID'  =>      $stageid , 
                                                        'ROUND_ID'  =>      $roundid 
                                                    ];
                    
                    $templateinfo           =       emailSetupStagewiseModel::Active()->where($wheredata)->get();
                   
                    if( count( $templateinfo ) ){
                        
                        $tempObj    =       $templateinfo[0];
                        $subject    =       $tempObj->EMAIL_SUBJECT;
                        $filepathloc        =   $tempObj->EMAIL_TEMP_PATH;
                        
                        if(file_exists(public_path().'/'.$filepathloc)){
                            $logfiles       =       file_get_contents(public_path().'/'.$filepathloc );
                            $tmplate        =      $logfiles;
                        }
                        
                    }
                    
                    $response['sub']                =       $subject;
                    $arr_input['[PMNAME]']          =       $userinfo->FIRST_NAME.' '.$userinfo->LAST_NAME;
                    $arr_input['[CHAPTER_TITLE]']   =       $metadata->CHAPTER_NAME;
                    $arr_input['[AUTHORNAME]']      =       '';
                    
                    $tmplate                =       $cmnobj->arr_key_value_replace( $arr_input , $tmplate );
                    $response['bdy']        =       stripslashes(nl2br($tmplate));
                    
                    $response['attach']     =      'D:\xampp\htdocs\Magnus_Springer\public\proofing_upload\\450217_1_En_1_Chapter_Author_archive.pdf';
                   // public_path().'/proof_upload/'.'450217_1_En_1_Chapter_Author_review.pdf';
                    
                    return $response;
                    
                }
                
                return false;
                
            }else{
                return false;
            }
            
        }else{
            return false;
        }
        
        return false;
        
    }
    
    public function getMailThreadIds( $limit = 1 ){
        
        $queryStmt      =       'SELECT * FROM `ops_proofout_mail_to_pm_status` WHERE STATUS = 1 ORDER BY ID ASC limit '.$limit;
        $recGetInf      =       DB::select( $queryStmt );
        
        return $recGetInf;
        
        
    }
    
    public function updatePmMailStatus( $setArr , $opsid ){
        
        $status     =   DB::table('ops_proofout_mail_to_pm_status')
                        ->where( 'OPS_PROOF_ID' ,  '=' , "$opsid" )
                        ->update( $setArr );
        
        return $status;
        
    }
    
    
    }