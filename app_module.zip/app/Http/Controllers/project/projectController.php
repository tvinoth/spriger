<?php
namespace App\Http\Controllers\project;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\projectModel;
use App\Models\productionLocationModel;
use App\Models\jobTimeSheet;
use App\Models\downloadModel;
use App\Models\bookinfoModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;

class projectController extends Controller
{    
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        parent::__construct();
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
    
    public function Jobassigned(){
        $data                   =   array();
        $this->displayMenuName(Config::get('menuconstants.MENU.PROJECT_LIST'),$data);
        $data['user_name']  =   $this->userName;
        $data['role_name']  =   $this->roleName;
        $data['role_id']    =   $this->roleId;
            
        return view('project.project-assigned-list')->with($data);	
        
    }
    
    public function JobassignedDetail(Request $request){
       
        if ($this->loginUserId > 0) {
            $Req = (object) $request->input();
             
            $arrData    =   array();
            $arrData['user_id']     = $this->loginUserId;
            $arrData['circle_id']   = $request->input('circle_id');
            $arrData['manager']     = $request->input('manager');
            $arrData['team_id']     = explode(',',$this->teamId);
           
            $roleid     =       $this->roleId;
            $role_const =       array( 45 => 'AM' , 12 => 'PM' , 9 => 'CL'  , 10 => 'TL' );
            
            $assignedJob    =       array();
            $teamUser   =   array();
            $amUserList =   array();
            
            if( isset( $role_const[$roleid] ) ){
                $assignedJob             = projectModel::getJobAssignedList( $arrData['user_id']  , $role_const[$roleid] );
                $teamUser                = projectModel::getUserListByTeam($arrData['team_id']);
                $amUserList              = downloadModel::getUserListByRole('45');
            }
          
            
           
            $response["assignjob"]  = $assignedJob;
            $response["teamMember"] = $teamUser;
            $response["AmMember"]   = $amUserList;
            
            return response()->json($response);
        }	
        
        
    }
    
    public function JobassignedtoUser(Request $request){
       
        if ($this->loginUserId  > 0) {
            $Req = (object) $request->input();
            $arrData    =   array();
            $arrData['user_id']       =    $request->input('user_id');
            $arrData['book_id']       =    $request->input('book_id');
           
            $assignedJob              =     projectModel::JobAssignedToUser($arrData);
            
           
            
            $this->assignPEmail($arrData);
            $this->assignPMmail($arrData);
            
            $message = "Not assign";
            
            $response['status'] =       0;
            $response['msg'] =       'Pm Assignmet got failed.';
            $response['errMsg'] =       'Try again after sometimes..';
            
            
            if($assignedJob['0'] == 'success'){
                $response['status']     =       1;
                $response['msg']        =       'Successfully assigned to new Project Manager';
                $response['errMsg']     =       'success';
            }
            
            return response()->json($response);
        }	
        
        
    }
        
    public function assignPMmail($arrData1){
        
         $assignedJob              =     projectModel::getJobAndOwnerDetails($arrData1);
         
        $mailArray = $mailData = array();

        $mailData['Title']      =   'Notification';
        $mailData['HeadLine']   =   'New Title Assigned';
        $mailData['ToName']     =   $assignedJob->PMname;
        $mailData['AM_NAME']    =   $assignedJob->AMname;
        $mailData['BookID']     =   $assignedJob->BOOK_ID;
        $mailData['BookTitle']  =   $assignedJob->JOB_TITLE;
        $mailData['BookIsbn']   =   $assignedJob->ISSN_ONLINE;
        $mailData['ReceivedDate']   =   $assignedJob->CREATED_DATE;
        $mailData['PublisherName']  =   $assignedJob->PUBLISHER_NAME;
        $mailData['ContactPersonName']          =   $assignedJob->PE_NAME;
        $mailData['ProductionClassification']   =   $assignedJob->PRODUCTION_CLASSIFICATION;
        $mailArray['Data']       = $mailData;
        $mailArray['TemplateName'] = 'emailtemplate.download.jobNotification';
       // $mailData['Title'] = 'New Quote Created';
      
        $mailArray['Subject'] = $assignedJob->BOOK_ID.'- New Title Assigned';
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail'] =  trim($assignedJob->PMemail);
        //$mailArray['CcMail'] = array('mohan.m@spi-global.com','shamu.shihabudeen@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com');
        $mailArray['BccMail']    =   Config::get('constants.BCC_EMAIL_LIST');
        
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
    
    public function assignPEmail($arrData1){
        
         $assignedJob              =     projectModel::getJobAndOwnerDetails($arrData1);
         
        $mailArray = $mailData = array();
        $mailArray = $mailData = array();

        $mailData['Title']      = 'Acknowledgement';
        $mailData['HeadLine']   = 'Job has assigned';
        $mailData['ToName']     = $assignedJob->PRODUCTION_EDITOR;
        $mailData['AM_NAME']    = $assignedJob->PMname;
        $mailData['BookID']     = $assignedJob->BOOK_ID;
        $mailData['BookTitle']  = $assignedJob->JOB_TITLE;
        $mailArray['Data']       = $mailData;
        $mailArray['TemplateName'] = 'emailtemplate.download.jobAssign';
       // $mailData['Title'] = 'New Quote Created';
        $nameauthororeditor     =   ($assignedJob->AUTHOR_NAME  ==  ""?$assignedJob->EDITOR_NAME:$assignedJob->AUTHOR_NAME);
        $mailArray['Subject'] = 'BFlux_'.$assignedJob->BOOK_ID.' - '.$nameauthororeditor.' - '.$assignedJob->ISSN_ONLINE.'/Acknowledgement';
        $mailArray['FromMail']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.REPLAY_EMAIL');
        $mailArray['FromName']  =   Config::get('constants.NEW_JOB_MAIL_CONTENT.MAIL_FROM_NAME');
        $mailArray['ToMail'] = $assignedJob->PRODUCTION_EDITOR_EMAIL;
        //$mailArray['CcMail'] = array( 'mohan.m@spi-global.com','ananth.b@spi-global.com','H.Sanitha@spi-global.com');
        $mailArray['BccMail']    =   Config::get('constants.BCC_EMAIL_LIST');
        return $Response = $this->sendMailBladeTemplate($mailArray);

    }
    
    public function sendMailBladeTemplate($mailArray) {
        if (is_array($mailArray)) {
			
			try{
            Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                $message->subject($mailArray['Subject']);
                $message->from($mailArray['FromMail'], $mailArray['FromName']);
                $message->to($mailArray['ToMail']);

                if (array_key_exists('CcMail', $mailArray)) {
                    $message->cc($mailArray['CcMail']);
                }
                
               if (array_key_exists('BccMail', $mailArray)) {
                    $message->bcc($mailArray['BccMail']);
                }

               // $message->getSwiftMessage();
            });
				}
				catch( \Exception $e )
				{           
					$Response['Status'] = 1;
					$Response['Msg'] = 'Success';
					return $Response;
				}

            if (Mail::failures()) {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
                //$Response['MsgText'] = Mail::failures();
            } else {
                $Response['Status'] = 1;
                $Response['Msg'] = 'Success';
            }

            return $Response;
        }

    }

    public static function getProjectList(Request $request) {
	
        if ($this->loginUserId  > 0) {
            $arrData    =   array();
            $arrData['user_id']     =   $this->loginUserId;
            $arrData['team_id']     =   $this->teamId;
            $data    =    bookinfoModel::getBookinfo( );
            //$data = projectModel::getProjectList($arrData);           
            $response["data"] = $data;
            return response()->json($response);
        }
        
    }
    
    public static function projectStatus(Request $request, $jobID) {
		$projData = projectModel::getProjectTitle($jobID);    
		$data= array();
        $data['pageTitle'] = 'Project Status';
        $data['pageName']  = 'Project Status';
		$data['JobID']  = $jobID;		
		$data['JobTitle']  = isset($projData->JOB_TITLE) ? $projData->JOB_TITLE : "";
		
        $data['user_name'] =  $this->userName;
        $data['role_name'] =  $this->roleName;
        return view('project.project-status')->with($data);
	}
	
    public static function getSchoolRounds(Request $request) {	
     	
		$jobrounds = projectModel::getSchoolRounds(getenv('SCHOOL_ROUNDS'));      
		$response["data"] = $jobrounds;
		return response()->json($response);
   
	}
    
    public function production(Request $request, $tab = null, $jobID = null) {
		
            if(Session::has('users')== ''){
            return redirect('/');
            }else if($jobID == null) {
                return redirect('/project-list');
            }
            
		$WFData = $projData = $roundData = array();
		$schoolData = projectModel::getSchoolRounds(getenv('SCHOOL_ROUNDS')); 
		$unitData = projectModel::getUnits(); 

		if($jobID > 0) {
			$projData = projectModel::getProjectTitle($jobID);    
			$WFData = projectModel::getWorkflowStartedCount($jobID); 
			$roundData = projectModel::getRounds($jobID); 
		
		//	$roundDtl = projectModel::getRoundDetails($jobID);
			
			$data= array();
			$data['pageTitle'] = 'Production - Project Bin';
			$data['pageName']  = 'Production - Project Bin';
			$data['JOB_ID']  = $jobID;
			
			$data['JobTitle']  = $projData->JOB_TITLE;
			$data['workflowData'] =  $WFData;
			$data['schoolData'] =  $schoolData;
			$data['roundData'] =  $roundData;
			$data['unitData'] =  $unitData;
		//	$data['roundDetail'] =  $roundDtl;
			
			$data['user_name'] =  $this->userName;
			$data['role_name'] =  $this->roleName;
			return view('project.production')->with($data);
		} 
	}	

            public function projectSetup(Request $request, $tab = null, $jobID = null) {
                
                if(Session::has('users')== ''){
                    return redirect('/');
                }else if($jobID == null) {
                    return redirect('/project-list');
                }
		
                $WFData = $projData = $roundData = array();
		$schoolData = projectModel::getSchoolRounds(getenv('SCHOOL_ROUNDS')); 
		$unitData = projectModel::getUnits(); 

		if($jobID > 0) {
			$projData = projectModel::getProjectTitle($jobID);    
			$WFData = projectModel::getWorkflowStartedCount($jobID); 
			$roundData = projectModel::getRounds($jobID); 
		
		//	$roundDtl = projectModel::getRoundDetails($jobID);
			
			$data= array();
			$data['pageTitle'] = 'Pre-Production - Project Setup';
			$data['pageName']  = 'Pre-Production - Project Setup';
			$data['JOB_ID']  = $jobID;
			
			$data['JobTitle']  = $projData->JOB_TITLE;
			$data['workflowData'] =  $WFData;
			$data['schoolData'] =  $schoolData;
			$data['roundData'] =  $roundData;
			$data['unitData'] =  $unitData;
		//	$data['roundDetail'] =  $roundDtl;
			
			$data['user_name'] =  $this->userName;
			$data['role_name'] =  $this->roleName;
			return view('project.project-setup')->with($data);
		} 
	}
	public static function getRoundDetails(Request $request) {
		if ($request->input('job_id') > 0) {
            $roundDtl = projectModel::getRoundDetails($request->input('job_id'));      
            $response["data"] = $roundDtl;
            return response()->json($response);
        }
	}
	public static function deleteRoundInfo(Request $request) {
		if ($request->input('gradeId') > 0) {
            $response = projectModel::deleteRoundInfo($request->input('gradeId'), $request->input('projectId'));
            return response()->json($response);
        }		
	}
	public static function updateRoundTarget(Request $request) {
		$inpArray = array(); 
		$inpArray['gradeId'] = $request->input('gradeId');
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['target'] = $request->input('target');
		$inpArray['user'] = $this->loginUserId;

		if ($request->input('gradeId') > 0) {
            $response = projectModel::updateRoundTarget($inpArray);
            return response()->json($response);
        }		
	}	
	public static function getChapterArtStatus(Request $request) {
		if ($request->input('job_id') > 0) {
            $chaterArtDtl = projectModel::getChapterArtStatus($request->input('job_id'), $request->input('opt'));      
            $response["data"] = $chaterArtDtl;
            return response()->json($response);
        }
	}
	public static function getComments(Request $request) {		
		if ($request->input('stageId') != '') {
            $remarkDtl = projectModel::getComments($request->input('stageId'),$request->input('opt'));      
            $response["data"] = $remarkDtl;
            return response()->json($response);
        }
	}
	public static function getWorkflowDetails(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('job_id');
		$inpArray['stageId'] = $request->input('stageId');
		
		$workflowDtl = projectModel::getWorkflowDetails($inpArray);      
		$response["data"] = $workflowDtl;
		return response()->json($response);  
	}
	public static function checkout(Request $request, $jobId, $stageId) {
		if(Session::has('users')== ''){
           return redirect('/');
        }
		$inpArray = array(); $roundName = $stageName = '';
		$inpArray['jobId'] = $jobId;
		$inpArray['stageId'] = $stageId;
		$inpArray['opt'] = "checkout";
		
		$chkData = projectModel::getCheckoutDetails($inpArray); 

		if(count($chkData) > 0) {
			for($k=0; $k<count($chkData); $k++) {
				$chatperno[] = $chkData[$k]->CHAPTER_NO;
				$stageName = $chkData[$k]->STAGE_NAME;
				
				$stagename_previous = $chkData[$k]->STAGE_NAME;
				$jobstageid_previous= $chkData[$k]->JOB_STAGE_ID;
				$roundName = $chkData[$k]->ROUND_NAME;
				$roundid = $chkData[$k]->ROUND_ID;
				$stageid = $chkData[$k]->STAGE_ID;
				$stageidnew = $chkData[$k]->STAGE_ID;
				$workflowid = $chkData[$k]->WORKFLOW_ID;
				$stageseq = $chkData[$k]->STAGE_SEQ;
				$jobstageid = $chkData[$k]->JOB_STAGE_ID;
				$jobstageid_previous = $chkData[$k]->JOB_STAGE_ID;
				$duedate = $chkData[$k]->duedate;
			}
		}
		
		$inpArray['opt'] = "page";
		$pageData = projectModel::getCheckoutDetails($inpArray); 
		$inpArray['roundName'] = $roundName;
		$inpArray['stageName'] = $stageName;
		
		$instData = projectModel::getInstructions($jobId, $stageId); 
		$targetCnt = projectModel::getTargetPageCount($inpArray); 
		$files = projectModel::getSupportingFiles($jobId);

		$data= array();
        $data['pageTitle'] = 'Check-In / Check-Out';
        $data['pageName']  = 'Check-In / Check-Out';
        $data['JobID'] =  $jobId;
        $data['StageID'] =  $stageId;
		$data['Round'] =  $roundName;
		$data['Stage'] =  $stageName;
		$data['Chapter'] =  $chatperno;
		$data['Instruction'] =  $instData;
		$data['targetCount'] =  $targetCnt;
		$data['supportingFiles'] =  $files;
		$data['pageData'] =  $pageData;
		//print_r($data); exit();
        return view('project.checkout')->with($data);
	}
	public static function getAllRounds(Request $request) {	
		$rndDtl = projectModel::getAllRounds();      
		$response["data"] = $rndDtl;
		return response()->json($response);
	}
	public static function getBookmapDetails(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('job_id');

		$bookmapDtl = projectModel::getBookmapDetails($inpArray);      
		$response["data"] = $bookmapDtl;
		return response()->json($response);		
	}
	public static function getPrdTabInfo(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$response = projectModel::getPrdTabInfo($inpArray);
	//	$response["data"] = $data;
		return response()->json($response);
	}
	public static function getPrdPages(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		$inpArray['fromPg'] = $request->input('fromPg');
		$inpArray['toPg'] = $request->input('toPg');
		$response = projectModel::getPrdPages($inpArray);
		return response()->json($response);		
	}
	public static function moveToPrd(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		$inpArray['workflowId'] = $request->input('workflowId');
		$inpArray['userId'] = $this->loginUserId;
		$inpArray['metadata'] = $request->input('metadata');
		$response = projectModel::moveToPrd($inpArray);
		//print_r($response);
		return response()->json($response);				
	}
	public static function getInstruction(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		$inpArray['fromPg'] = $request->input('fromPg');
		$inpArray['toPg'] = $request->input('toPg');
		$response = projectModel::getInstruction($inpArray);
		return response()->json($response);	
	}
	public static function deleteInstruction(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['instructionId'] = $request->input('instructionId');
		$response = projectModel::deleteInstruction($inpArray);
		return response()->json($response);	
	}
	public static function saveInstruction(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		$inpArray['fromRange'] = $request->input('fromRange');
		$inpArray['toRange'] = $request->input('toRange');
		$inpArray['instruction'] = $request->input('instruction');
		$inpArray['instructionId'] = $request->input('instructionId');
		$inpArray['createdDate'] = $request->input('createdDate');
		$inpArray['createdBy'] = $this->loginUserId;
		$response = projectModel::saveInstruction($inpArray);
		return response()->json($response);	
	}
	public static function getProcessPath(Request $request) {
		$inpArray = array(); $data= array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$path = projectModel::getProcessPath($inpArray);
		$data['path'] = $path;
		
		$inpArray['workflowId'] = $path[0]->workflow_id;
		$ftp = projectModel::getFTPPath($inpArray);
		$data['ftp'] = $ftp;
		
		$ftp = projectModel::getWorkflowPath($inpArray);
		$data['wfpath'] = $ftp;

		$inpArray['workflowType'] = $path[0]->workflow_type;
		$preset = projectModel::getPresetList($inpArray);
		$data['preset'] = $preset;
		
		return response()->json($data);			
	}
	public static function getPresetList(Request $request) {
		$inpArray = array(); $data= array(); 
		$inpArray['workflowType'] = $request->input('workflowType');
		
		$preset = projectModel::getPresetList($inpArray);
		$data['preset'] = $preset;
		
		return response()->json($data);			
		
	}
	public static function saveMetadata(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['workflow_type'] = $request->input('workflow_type');
		
		$inpArray['pr_pdf_path'] = $request->input('pr_pdf_path');
		$inpArray['pr_dest_path'] = $request->input('pr_dest_path');
		$inpArray['pit_log_path'] = $request->input('pit_log_path');
		$inpArray['pit_fail_path'] = $request->input('pit_fail_path');
		$inpArray['sample_indd_path'] = $request->input('sample_indd_path');
		$inpArray['fonts'] = $request->input('fonts');
		$inpArray['pdf_output_path'] = $request->input('pdf_output_path');
		
		$inpArray['ftp'] = $request->input('ftp');
		
		$inpArray['path'] = $request->input('path');
		
		$inpArray['createdBy'] = $this->loginUserId;
		$response = projectModel::saveMetadata($inpArray);
		return response()->json($response);
	}
	public static function getAssignWFTabInfo(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['circleId'] = $request->input('circleId');
		$inpArray['subCircle'] = $request->input('subCircle');
		$inpArray['schoolIds'] = getenv('SCHOOL_ROUNDS');
	
		$response = projectModel::getAssignWFTabInfo($inpArray);
		return response()->json($response);
	}
	public static function getAssignedWF(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
	
		$response = projectModel::getAssignedWF($inpArray);
		return response()->json($response);		
	}
	public static function saveAssignWF(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['WFInfo'] = $request->input('WFInfo');
		$inpArray['userId'] = $this->loginUserId;
	
		$response = projectModel::saveAssignWF($inpArray);
		return response()->json($response);	
	}
	public static function deleteAssignWF(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['workflowMasterId'] = $request->input('workflowMasterId');
		$inpArray['roundId'] = $request->input('roundId');
	
		$response = projectModel::deleteAssignWF($inpArray);
		return response()->json($response);	
	}
	public static function getWorkflowView(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		
		$workflowDtl = projectModel::getWorkflowView($inpArray);      
		$response["data"] = $workflowDtl;
		return response()->json($response);  
	}
	public static function getJobRoundWorkflow(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');
		$inpArray['workflowMasterId'] = $request->input('workflowMasterId');
		$inpArray['workflowType'] = $request->input('workflowType');
		
		$workflowDtl = projectModel::getJobRoundWorkflow($inpArray);      
		$response["data"] = $workflowDtl;
		return response()->json($response);		
	}
	public static function getTPS(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$response = projectModel::getTPS($inpArray);     
		return response()->json($response);  
	}
	public static function saveTPS(Request $request) {
		$inpArray = array(); 
		$inpArray['projectId'] = $request->input('projectId');
		$inpArray['tpsContact'] = $request->input('tpsContact');
		$inpArray['workflowType'] = $request->input('workflowType');
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['percentage'] = $request->input('percentage');
		$inpArray['target'] = $request->input('target');
		$inpArray['components'] = $request->input('components');
		$inpArray['grade'] = $request->input('grade');
		$inpArray['pageCnt'] = $request->input('pageCnt');
		$inpArray['batchInfo'] = $request->input('batchInfo');
		$inpArray['productionDate'] = $request->input('productionDate');
		$inpArray['lwProjMgr'] = $request->input('lwProjMgr');
		$inpArray['projDtl'] = $request->input('projDtl');
		$inpArray['pendDtl'] = $request->input('pendDtl');
		
		$response = projectModel::saveTPS($inpArray);     
		return response()->json($response);  
	}
	public static function getTPSContact(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$response = projectModel::getTPSContact($inpArray);     
		return response()->json($response); 
	}
	public static function getSetupWorkflowStages(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['roundId'] = $request->input('roundId');		
		$response = projectModel::getSetupWorkflowStages($inpArray);     
		return response()->json($response); 		
	}
	public static function saveSetupRound(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['lesson'] = $request->input('lesson');	
		$inpArray['grade'] = $request->input('grade');	
		$inpArray['stageId'] = $request->input('stageId');	
		$inpArray['roundId'] = $request->input('roundId');	
		$inpArray['unitId'] = $request->input('unitId');	
		$inpArray['tolerance'] = $request->input('tolerance');	
		$inpArray['target'] = $request->input('target');		
					
		$response = projectModel::saveSetupRound($inpArray);     
		return response()->json($response); 
	}
	public static function addRemoveWorkfowStages(Request $request) {
		$inpArray = array(); 
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['roundId'] = $request->input('roundId');	
		$inpArray['workflowMasterId'] = $request->input('workflowMasterId');	
		$inpArray['workflowId'] = $request->input('workflowId');	
		$inpArray['stageInfo'] = $request->input('stageInfo');	
		$response = projectModel::addRemoveWorkfowStages($inpArray);     
		return response()->json($response); 
	}
	public static function saveProfitabilityPercentage(Request $request) {
		$inpArray = array(); 
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['roundInfo'] = $request->input('roundInfo');	
		$response = projectModel::saveProfitabilityPercentage($inpArray);     
		return response()->json($response); 
	}
	public static function getProfitabilityPercentage(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$response = projectModel::getProfitabilityPercentage($inpArray);     
		return response()->json($response); 
	}
	public static function getStagesForRound(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['roundId'] = $request->input('roundId');	
		$response = projectModel::getStagesForRound($inpArray);     
		return response()->json($response); 
	}
	public static function getProjectBinList(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		if($this->roleId == 9 || $this->roleId == 10)  $inpArray['roleId'] = "";
		else $inpArray['roleId'] = $this->roleId;	
		$inpArray['roundId'] = $request->input('roundId');	
		$inpArray['stageId'] = $request->input('stageId');	
		$inpArray['searchType'] = $request->input('searchType');	
		$inpArray['searchTerm'] = $request->input('searchTerm');	
		$inpArray['start'] = $request->input('start');	
		$inpArray['noOfRec'] = $request->input('noOfRec');	
		
		$response = projectModel::getProjectBinList($inpArray);     
		return response()->json($response); 
	}	
	public static function getProjectBinDetails(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		if($this->roleId == 9 || $this->roleId == 10)  $inpArray['roleId'] = "";
		else $inpArray['roleId'] = $this->roleId;	
		$inpArray['roundId'] = $request->input('roundId');	
		$inpArray['documentName'] = $request->input('documentName');	
		$inpArray['searchType'] = $request->input('searchType');	
		$inpArray['searchTerm'] = $request->input('searchTerm');	
		$response = projectModel::getProjectBinDetails($inpArray);     
		return response()->json($response); 		
	}
	public static function deleteBookmapPages(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['bookmapInfo'] = $request->input('bookmapInfo');
		$response = projectModel::deleteBookmapPages($inpArray);     
		return response()->json($response); 
	}
	public static function getInDesignVersion(Request $request) {
		$inpArray = array(); 
		$response = projectModel::getInDesignVersion($inpArray);     
		return response()->json($response); 		
	}
	public static function getBookmapInfoById(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['pageId'] = $request->input('pageId');	
		$inpArray['seqId'] = $request->input('seqId');	
		$inpArray['seq'] = $request->input('seq');	
		$response = projectModel::getBookmapInfoById($inpArray);     
		return response()->json($response); 		
	}
	public static function saveBookmapFolio(Request $request) {
		$inpArray = array(); 

		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['pageId'] = $request->input('pageId');	
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['pageNo'] = $request->input('pageNo');	
		$inpArray['inddFolioNo'] = $request->input('inddFolioNo');	
		$inpArray['pgTitle'] = $request->input('pgTitle');	
		$inpArray['pageType'] = $request->input('pageType');	
		$inpArray['numberType'] = $request->input('numberType');	
		$inpArray['pref'] = $request->input('pref');	
		$inpArray['suff'] = $request->input('suff');	
		$inpArray['batchNo'] = $request->input('batchNo');	
		$inpArray['inddVersion'] = $request->input('inddVersion');	
		$inpArray['pdfFileName'] = $request->input('pdfFileName');	
		$inpArray['inddFilePath'] = $request->input('inddFilePath');
		$inpArray['inddFileName'] = $request->input('inddFileName');	
		$inpArray['saveOpt'] = $request->input('saveOpt');	
		$inpArray['savePos'] = $request->input('savePos');					
		$response = projectModel::saveBookmapFolio($inpArray);     
		return response()->json($response); 		
	}
	public static function updateTouched(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['pageId'] = $request->input('pageId');	
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['touched'] = $request->input('touched');	
		$response = projectModel::updateTouched($inpArray);     
		return response()->json($response); 		
	}
	public static function folioTakeOwnership(Request $request) {
		$inpArray = array(); 
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['roundId'] = $request->input('roundId');	
		$inpArray['metadataId'] = $request->input('metadataId');
		$inpArray['metaInfo'] = $request->input('metaInfo');
		$inpArray['teamId'] = $this->teamId;
		$response = projectModel::folioTakeOwnership($inpArray);     
		return response()->json($response); 		
	}
	public static function getInstructionList(Request $request) {
		$response =  projectModel::getInstructions($request->input('jobId'), $request->input('stageId')); 
		return response()->json($response); 		
	}
	public static function saveRMIInfo(Request $request) {
		$inpArray = array(); 
		$inpArray['filePath'] = $request->input('filePath');	
		$inpArray['scptPath'] = getenv('APPLESCRIPT_FILE_PATH');	
		$inpArray['projectId'] = $request->input('projectId');
		$inpArray['methodName'] = $request->input('methodName');
		$inpArray['systemIP'] = self::get_ip_address();
		$inpArray['inddVersion'] = $request->input('inddVersion');
		
		$response = projectModel::saveRMIInfo($inpArray);     
		return response()->json($response); 
	}
	public static function indesignReturn(Request $request, $rtype, $fileStatus, $batchId) {
		$response = array();
		if($rtype=="closeSignal"){
			$inpArray = array();
            $inpArray['fileStatus'] = $fileStatus;
			$inpArray['batchId'] = $batchId;
			$inpArray['errorLog'] = "";
			$response = projectModel::indesignReturn($inpArray);     
		}
		return response()->json($response); 		
	}
	public static function checkRMIStatus(Request $request) {
		$inpArray = array(); 
		$inpArray['rmiID'] = $request->input('rmiID');	
		$inpArray['systemIP'] = self::get_ip_address();
		
		$response = projectModel::checkRMIStatus($inpArray);     
		return response()->json($response); 
		
	}
	public static function unlockDocument(Request $request) {
		$inpArray = array(); 
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['metaInfo'] = $request->input('metaInfo');
		$response = projectModel::unlockDocument($inpArray);     
		return response()->json($response); 		
	}
	public static function skipStage(Request $request) {
		$inpArray = array(); 
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['metaInfo'] = $request->input('metaInfo');
		$response = projectModel::skipStage($inpArray);     
		return response()->json($response); 		
	}
	public static function getCheckoutInfo(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['jobStageId'] = $request->input('jobStageId');
		$response = projectModel::getCheckoutInfo($inpArray);     
		return response()->json($response); 	
	}
	public static function getFileStatus(Request $request) {
		$inpArray = array(); 
		$inpArray['batchId'] = $request->input('batchId');	
		$response = projectModel::getFileStatus($inpArray);     
		return response()->json($response); 	
	}
	public static function checkoutProcess(Request $request) {
		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['jobStageId'] = $request->input('jobStageId');	
		$inpArray['userId'] = $this->loginUserId;	
		$inpArray['teamId'] = $this->teamId;	
		$response = projectModel::checkoutProcess($inpArray);     
		return response()->json($response); 	
	}
	public static function checkInProcess(Request $request) {

		$inpArray = array(); 
		$inpArray['jobId'] = $request->input('jobId');	
		$inpArray['jobStageId'] = $request->input('jobStageId');	
		$inpArray['batchId'] = $request->input('batchId');	
		$inpArray['selectedPages'] = $request->input('selectedPages');	
		$inpArray['fileStatus'] = $request->input('fileStatus');
		
		$inpArray['pdfCreationPath'] = getenv('PDF_CREATION_WATCHFOLDER');		
		$inpArray['fileServerFTP'] = getenv('FILE_SERVER_FTP_CREDENTIAL');	
		$inpArray['pdfCallbackURL'] = getenv('PDF_AUTOMATION_CALLBACK_URL');
		$inpArray['pdfPitstopStage'] = getenv('PDF_PITSTOP_STAGE');
		$response = projectModel::checkInProcess($inpArray);     
		return response()->json($response); 	
	}
	public static function get_ip_address() {
		// check for shared internet/ISP IP
		if (!empty($_SERVER['HTTP_CLIENT_IP']) && validate_ip($_SERVER['HTTP_CLIENT_IP'])) {
			return $_SERVER['HTTP_CLIENT_IP'];
		}
	
		// check for IPs passing through proxies
		if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			// check if multiple ips exist in var
			if (strpos($_SERVER['HTTP_X_FORWARDED_FOR'], ',') !== false) {
				$iplist = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
				foreach ($iplist as $ip) {
					if (validate_ip($ip))
						return $ip;
				}
			} else {
				if (validate_ip($_SERVER['HTTP_X_FORWARDED_FOR']))
					return $_SERVER['HTTP_X_FORWARDED_FOR'];
			}
		}
		if (!empty($_SERVER['HTTP_X_FORWARDED']) && validate_ip($_SERVER['HTTP_X_FORWARDED']))
			return $_SERVER['HTTP_X_FORWARDED'];
		if (!empty($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']) && validate_ip($_SERVER['HTTP_X_CLUSTER_CLIENT_IP']))
			return $_SERVER['HTTP_X_CLUSTER_CLIENT_IP'];
		if (!empty($_SERVER['HTTP_FORWARDED_FOR']) && validate_ip($_SERVER['HTTP_FORWARDED_FOR']))
			return $_SERVER['HTTP_FORWARDED_FOR'];
		if (!empty($_SERVER['HTTP_FORWARDED']) && validate_ip($_SERVER['HTTP_FORWARDED']))
			return $_SERVER['HTTP_FORWARDED'];
	
		// return unreliable ip since all else failed
		return $_SERVER['REMOTE_ADDR'];
	}
}