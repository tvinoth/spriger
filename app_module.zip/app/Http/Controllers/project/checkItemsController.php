<?php

namespace App\Http\Controllers\project;
use App\Http\Controllers\Controller;
use App\Models\projectModel;
use App\Models\checkItemsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Session;
use Validator;
use PDF;
use DB; 
use Illuminate\Http\Response;
use Excel;

class checkItemsController extends Controller 
{
	protected $loginUserId;
        protected $teamId;
        protected $roleId;
        protected $empId;
        protected $userName;
        protected $roleName;

        public function __construct() {
            parent::__construct();
                $this->loginUserId  =   Session::get('users')['user_id'];
                $this->teamId       =   Session::get('users')['team_id'];
                $this->roleId       =   Session::get('users')['role_id'];
                $this->empId        =   Session::get('users')['emp_id'];
                $this->userName     =   Session::get('users')['user_name'];
                $this->roleName     =   Session::get('users')['role_name'];
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
	
	public function index($projectID 	=	null)
	{
		if(Session::has('users')=='')
		{
			return redirect('/');
		}
		$data 				= 	array();
		$data['project_name'] 	=	[];
		$data['pageTitle'] 	= 	'Check List Items';
		$data['pageName']  	= 	'Check List Items';
		$data['user_name'] 	=  	Session::get('users')['user_name'];
		$data['role_name'] 	= 	Session::get('users')['role_name'];
		$projectnames 	 	= 	checkItemsModel::getProject($projectID);
		if(count($projectnames)>=1)
		{
			$data['project_name'] 	=	$projectnames;
		}
		return view('project.check-items-index')->with($data);
	}
	
	public function getCheckItemsList( Request $request)
	{
		if(!empty($request->input('jobId')))
		{
			$checkItemsList 	= 	checkItemsModel::getCheckItemsList($request->input('jobId'));
			return $checkItemsList;
		}
		$message 	=	array('msg'=>'Bad request sending','result'=>400);
		return response()->json($message,400); 
	}
	
	public function getCheckItemsParentList( Request $request )
	{
		if(!empty($request->input('jobId')))
		{
			$checkItemsParentList 	= 	checkItemsModel::getCheckItemsParentList($request->input('jobId'));
			return $checkItemsParentList;
		}
		$message 	=	array('msg'=>'Bad request sending','result'=>400);
		return response()->json($message,400); 
	}
	
	public function getCheckItemsTypeList( Request $request )
	{	
		return response()->json([['ID' => 1, 'TEXT' => 'INTAKE']]);	
	}
	/* ADD CHECK ITEMS*/
	public function addCheckItem(Request $request) 
	{
		$rules['checkItemTitle'] 	= 	'required';
		$rules['checkItemIsParent'] = 	'required';
		$rules['checkItemType'] 	= 	'required';
		$rules['jobId'] 			= 	'required';
		$response['status'] 		= 	0;
		$response['msg'] 			= 	'Failed';
		$response['errMsg'] 		= 	'Error occured. Try again.';	
		$validator 		= 	Validator::make($request->all(), $rules);
		if ($validator->fails()) 
		{
			$response['errMsg'] 	= 	'Required field validation error occured.';
		} 
		else 
		{
			$data 				= 	[];
			$data['TITLE'] 		= 	$request->get('checkItemTitle');
			$data['IS_PARENT'] 	= 	$request->get('checkItemIsParent');
			$jobid['PROJECT_ID']= 	$request->get('jobId');
			$data['PARENT_ID'] 	= 	($request->get('checkItemIsParent') ==	1?0:$request->get('checkItemParentId'));
			$data['TYPE'] 		= 	'INTAKE'; // $request->get('checkItemType');
			$data['STATUS'] 	= 	1	;
			try 
			{
				
				$checkItemexist = 	checkItemsModel::checkItemExist($request->get('checkItemTitle'),$request->get('jobId'));
				if(count($checkItemexist)>=1)
				{
					$response['status'] 	=	0;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Parent title is already exist.';
				}
				else{
					$jobID 					=	$request->get('jobId');
					$checkItemquickinfo 	=	$request->get('checkItemquickinfo');
					$status 				= 	checkItemsModel::addCheckItem($data,$jobID,$checkItemquickinfo);
					$response['status'] 	=	1;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Check Items Added Successfully.';
				}
			} 
			catch( \Exception $e ) 
			{                 
				logger($e->getMessage());
				
			}			
		}
		return $response;
	}  

	public function editCheckItem(Request $request) 
	{
		$rules['checkItemTitle'] 	= 	'required';
		$rules['checkItemIsParent'] = 	'required';
		$rules['checkItemType'] 	= 	'required';
		$rules['checkItemId'] 		= 	'required';
		$rules['jobId'] 			= 	'required';
		$response['status'] 		= 	0;
		$response['msg'] 			= 	'Failed';
		$response['errMsg'] 		= 	'Error occured. Try again.';
		$validator 		= 	Validator::make($request->all(), $rules);
		if ($validator->fails()) 
		{
			$response['errMsg'] 	= 	'Required field validation error occured.';
		} 
		else 
		{
			$data 				= 	[];
			$data['ID'] 		= 	$request->get('checkItemId');
			$data['TITLE'] 		= 	$request->get('checkItemTitle');
			$jobID 				= 	$request->get('jobId');
			$checkItemquickinfo = 	$request->get('checkItemquickinfo');
			$data['IS_PARENT'] 	= 	$request->get('checkItemIsParent');
			$data['PARENT_ID'] 	= 	($request->get('checkItemIsParent') ==	1?0:$request->get('checkItemParentId'));
			$data['TYPE'] 		= 	'INTAKE'; // $request->get('checkItemType');
			try 
			{
				$checkItemexist = 	checkItemsModel::checkItemExistItemid($data['ID'],$data['TITLE'],$jobID,$checkItemquickinfo);
				if(count($checkItemexist)>=1)
				{
					$response['status'] 	=	0;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Parent title is already exist.';
				}
				else{
					$status 		= 	checkItemsModel::editCheckItem($data);
					$response['status'] 	=  	1;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Check Items Updated Successfully.';
				}
			} 
			catch( \Exception $e ) 
			{                 
				logger($e->getMessage());
			}
		}
		return $response;
	}
	
	public function deleteCheckItem(Request $request)
	{
		if(!empty($request->input('ID')))
		{
			$ID 	= 	$request->input( 'ID' );
			return  checkItemsModel::deleteCheckItem($ID);
		}
		$message 		=	array('msg'=>'Bad request sending','result'=>400);
		return response()->json($message,400);
	}
	
	public function project(Request $request, $projectId = 0, $download = '') 
	{
		$data  	= 	[];
		$data['downloadURL'] 		= 	url('project/check-items/'.$projectId.'/download');
		$data['pageTitle'] 			= 	'Intake Reports';
		$data['pageName']  			= 	'Intake Reports';
		$data['user_name'] 			=  	Session::get('users')['user_name'];
		$data['role_name'] 			=  	Session::get('users')['role_name'];
		$data['projectId'] 			= 	$projectId;
		$data['project_name'] 		=	[];
		$projectnames 	 			= 	checkItemsModel::getProject($projectId);
		if(count($projectnames)>=1)
		{
			$data['project_name'] 	=	$projectnames;
		}
		$getparentsdata 			= 	checkItemsModel::getCheckItemsParent($projectId);
		$projectcheckitems 			=	array();
		if(!empty($getparentsdata)) 
		{
			foreach($getparentsdata as $key => $checkItemParent) 
			{
				$projectcheckitems[$key] 	=	$checkItemParent;
				$getchild			= 	checkItemsModel::getCheckItemsChildren($checkItemParent['ID'],$projectId);
				if(count($getchild)>=1)
				{
					$data['parents'] 	=	$checkItemParent;
					foreach($getchild as $ckey=>$child)
					{
						$projectcheckitems[$key]['checkItemsChildren'][] 	=	$child;
					}
				}
				else{
					$projectcheckitems[$key]['checkItemsChildren'] 	=	[];
				}
			}
		}
		$data['checkItemsParent'] 	= 	$projectcheckitems;
		if($request->isMethod('post') && $request->input('updateprojectitemsall') 	==	"Save All") 
		{
			if(count($request->input('checkitemsid')))
			{
				$checkitemsid 		=	$request->input('checkitemsid');
				$projCheckItem 		=	$request->input('projCheckItemOk_');
				$checkitemsproblem 	=	$request->input('projCheckItemProblem_');
				//$checkitemsinfo 	=	$request->input('projCheckItemQuickInfo_');
				checkItemsModel::saveProjectCheckItemsAll($checkitemsid,$projCheckItem,$checkitemsproblem);
				return redirect('/project/check-items/' . $projectId)->with('status', 'Saved successfully.');
			}
			return redirect('/project/check-items/' . $projectId)->with('status', 'No Data to update.');
		}
		return view('project.project-check-items')->with($data);
	}
	
	public function editProjectCheckItem(Request $request) 
	{
		$rules['jobId'] 		= 	'required';
		$response['status'] 	= 	0;
		$response['msg'] 		= 	'Failed';
		$response['errMsg'] 	= 	'Error occured. Try again.';
		$validator 		= 	Validator::make($request->all(), $rules);
		if ($validator->fails()) 
		{
			$response['errMsg'] 	= 	'Required field validation error occured.';
		} 
		else 
		{
			$data 					= 	[];
			$data['CHECK_ITEM_ID'] 	= 	$request->get('checkItemId');
			$data['PROJECT_ID'] 	= 	$request->get('jobId');
			$data['OK_DATA'] 		= 	$request->get('checkOkdata');
			$data['PROBLEM_DATA'] 	= 	$request->get('checkProblem');
			$data['QUICK_INFO_DATA']= 	$request->get('checkQuick');
			if($data['CHECK_ITEM_ID'] 	==	'others')
			{
				$data['TITLE'] 		= 	'Others';
				$othersexist 		=	checkItemsModel::getCheckOthersItems($data);
				if(count($othersexist)>=1)
				{
					$data['CHECK_ITEM_ID'] 	=	$othersexist[0]['ID'];
					unset($data['TITLE']);
					$status 				= 	checkItemsModel::updateProjectCheckItem($data,$request->get('jobId'));
					$response['status'] 	=  	1;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Project Check Items Updated Successfully.';
				}
				else{
					$data['IS_PARENT'] 	= 	'1';
					unset($data['CHECK_ITEM_ID']);
					unset($data['PROBLEM_DATA']);
					unset($data['QUICK_INFO_DATA']);
					unset($data['PROJECT_ID']);
					unset($data['OK_DATA']);
					$jobid['PROJECT_ID']= 	$request->get('jobId');
					$data['PARENT_ID'] 	= 	0;
					$data['TYPE'] 		= 	'INTAKE'; // $request->get('checkItemType');
					$data['STATUS'] 	= 	1	;
					//$jobid['OK_DATA']   =	$request->get('checkOkdata');
					$jobid['OK_DATA']   =	0;
					$jobid['PROBLEM_DATA']   =	$request->get('checkProblem');
					$jobid['QUICK_INFO_DATA']   =	$request->get('checkQuick');
					$status 			= 	checkItemsModel::addprojectCheckItemOthers($data,$jobid);
					$response['status'] 	=  	1;
					$response['msg'] 		= 	'Success';
					$response['errMsg'] 	= 	'Project Check Items Updated Successfully.';
				}
			}
			else{
				$status 				= 	checkItemsModel::updateProjectCheckItem($data,$request->get('jobId'));
				$response['status'] 	=  	1;
				$response['msg'] 		= 	'Success';
				$response['errMsg'] 	= 	'Project Check Items Updated Successfully.';
			}
		}
		return $response;
	}
	public function deleteProjectCheckItem(Request $request) 
	{
		$rules['checkItemId'] 	= 	'required';
		$response['status'] 	= 	0;
		$response['msg'] 		= 	'Failed';
		$response['errMsg'] 	= 	'Error occured. Try again.';
		$validator 		= 	Validator::make($request->all(), $rules);
		if ($validator->fails()) 
		{
			$response['errMsg'] 	= 	'Required field validation error occured.';
		} 
		else 
		{
			$data 					= 	[];
			$data['CHECK_ITEM_ID'] 	= 	$request->get('checkItemId');
			$data['PROBLEM_DATA'] 	= 	'';
			$data['QUICK_INFO_DATA']= 	'';
			if($data['CHECK_ITEM_ID'] 	==	'others')
			{
				$response['status'] 	=  	1;
				$response['msg'] 		= 	'Success';
				$response['errMsg'] 	= 	'Project Check Items Deleted Successfully.';
			}
			else
			{
				$status 				= 	checkItemsModel::deleteProjectCheckItem($data,$request->get('checkItemId'));
				$response['status'] 	=  	1;
				$response['msg'] 		= 	'Success';
				$response['errMsg'] 	= 	'Project Check Items Deleted Successfully.';
			}
		}
		return $response;
	}
}