<?php

    namespace App\Http\Controllers\job;

    use App\Http\Controllers\Controller;
    use App\Models\projectModel;
    use Illuminate\Http\Request;
    use Illuminate\Support\Facades\Redirect;
    use Session;
    use Validator;
    use PDF;
    use DB; 
    use Illuminate\Http\Response;
    use Excel;
    
    class jobController extends Controller
    {
        protected $loginUserId;
        protected $teamId;
        protected $roleId;
        protected $empId;
        protected $userName;
        protected $roleName;

        public function __construct() {
            parent::__construct();
            $this->middleware(function ($request, $next) {
                if (Session::has('users') == '') {
                    return redirect('/');
                }
                return $next($request);
            });
        }
        
        public function index(){
            
             
            $data= array();
            $data['pageTitle'] = 'Job Contact Import';
            $data['pageName']  = 'Job Contact Information';
            $data['user_name'] =  Session::get('users')['user_name'];
            $data['role_name'] =  Session::get('users')['role_name'];
            return view('job.contact-list')->with($data);
            
        }
        
        public function insert( Request $request ){
           
            $rules['contact_name']      =       'required';
            $rules['contact_email']     =       'required';
            $rules['location_id']       =       'required';
            $response   =   $this->oopsErrorResponse;
            $validator  =   Validator::make( $request->all(), $rules );
          
            if ($validator->fails()) { 
              
               $response['errMsg']      =       'Required field validation error occured.';
                
            }else{
            
                $in_data                             =       array();
                $in_data['contact_name']             =       $request->input( 'contact_name' );
                $in_data['contact_email']            =       $request->input( 'contact_email' );
                $in_data['location_id']              =       $request->input( 'location_id' );
                //$in_data['location_name']            =       $request->input( 'location_name' );
                $in_data['created_date']             =       date('Y-m-d H:i:s');
                $user_info                           =       ( $request->session()->get('users') );
                $in_data['created_by']               =       $user_info['user_id'];
               
                try{
                    
                    $insertId   =    DB::table('contact_details')->insertGetId( $in_data ); 
                    $response   =   $this->insertedResponse;
                }catch( \Exception $e ){                  
                                      
                }
                                
            }
            
             echo json_encode( $response );    
        }  

        public function getList( Request $request ){
            
            $response       =       array();
            
            $response['contacts']       =       \App\Models\contactDetailsModel::getContactInformation();
            
            echo json_encode( $response , true);
            
        }
        
        public function update( Request $request ){
            
            $inpArray = array();
            
            $inpArray['ID']              =   $request->input('contactId');	
            $inpArray['CONTACT_NAME']    =   $request->input('contactName');	
            $inpArray['CONTACT_EMAIL']   =   $request->input('contactEmail');	
            $inpArray['LOCATION_ID']     =   $request->input('locationId');	
            $inpArray['user_id']        =    '';
            
            $response = \App\Models\contactDetailsModel::updateContact( $inpArray );     
            
            return response()->json($response); 		
                
        }
        
        public function delete( Request $request ){
            
            $rowid          =       $request->input( 'ID' );
            $response       =       false;
            //$rowid          =       40;
            
            if( !empty( $rowid ) ){
                $response   =       \App\Models\contactDetailsModel::deleteContact( $rowid );
            }
            
            echo $response;
        }
        
        public function uploadExcel(){
            
            $currentDir = getcwd()."/uploadFiles/";
            $fileName = "contact_input_".date("YmdHis").".xlsx";
            $fileSavePath  = $currentDir.$fileName;
            file_put_contents( $fileSavePath , file_get_contents('php://input') );
            $res['fileName'] = $fileName;
            return response()->json($res);    
            
        }
        
        public function importDataFromExcel( Request $request ){      
            
            $rowCnt = 0; $invalid = 0; $errMsg = ""; $errRows = ""; $importArray = array();
            
            $fileName       =       $request->input( 'fileName' );  
            $userId         =       $request->input( 'userId' );
            
            $currentDir         =       getcwd()."/uploadFiles/";	
            $fileSavePath       =       $currentDir.$fileName;
            $filterArr          =       array ( DB::RAW( 'LOWER(LOCATION_NAME) as low_location_name' )  , 'LOCATION_NAME'  , 'ID' );
            $allLocations       =       \App\Models\locationModel::getLocationListWithFilter( $filterArr );
            $locationIdCollect  =       array();
            
            foreach( $allLocations as $key => $value ){
                $locationIdCollect[$value['low_locationname']]        =       $value['ID'];
            }
            
            //Excel reader used in laravel
            Excel::load($fileSavePath, function( $reader ) use (&$importArray , $userId, $fileName , &$invalid, &$rowCnt, &$errMsg, &$errRows ) {
                
                $results = $reader->get();
                $results = $reader->all()->toArray();	
                $results = $results[0];	
                
                foreach( $results as $key => $records ){
              
                    $input_array        =       array();
                    $input_array['cName']      =   $records['Name'];
                    $input_array['cEmail']      =   $records['Email'];
                    //$input_array['cLocation']      =   $records['Location'];
                    $input_array['cLocationId']     =   $locationIdCollect[strtolower($records['Location'])];
                    array_push( $importArray , $input_array );
                    
                }
                
                
                
                
            });
            
        }
        
    }