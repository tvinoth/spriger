<?php
namespace App\Http\Controllers\correction;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\taskLevelMetadataModel;
use App\Models\projectModel;
use App\Models\fileHandler;
use App\Models\jobModel;
use App\Models\jobInfoModel;
use App\Models\bookinfoModel;
use App\Models\spicastProfileModel;
use App\Models\apiCorrectionDownload;
use App\Models\jobTimeSheet;
use App\Models\productionLocationModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Http\Controllers\fileHandler\fileHandlerController;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\production\movetoproductionController;
use App\Http\Controllers\Api\clientAcknowledgementController;
use Session;
use Storage;
use Validator;
use Illuminate\Support\Facades\Crypt;
use Mail;
use DB; 
use Config;
use Log;

class correctionController extends Controller{
    
    protected $loginUserId;
    protected $teamId;
    protected $roleId;
    protected $empId;
    protected $userName;
    protected $roleName;

    public function __construct() {
        parent::__construct();
        $this->loginUserId  =   Session::get('users')['user_id'];
        $this->teamId       =   Session::get('users')['team_id'];
        $this->roleId       =   Session::get('users')['role_id'];
        $this->empId        =   Session::get('users')['emp_id'];
        $this->userName     =   Session::get('users')['user_name'];
        $this->roleName     =   Session::get('users')['role_name'];
        $this->middleware(function ($request, $next) {
            if (Session::has('users') == '') {
                return redirect('/');
            }
            return $next($request);
        });
    }
	
    public function index(){
		
        $data               =   array();
        $data['pageTitle']  = 	'Correction';
        $data['pageName']   =   'Correction';
		
        $data['user_name']  =   Session::get('users')['user_name'];
        $data['role_name']  =   Session::get('users')['role_name'];
        $data["userId"]     =   Session::get('users')['user_id'];
		
        return view('cucprocess.cuc-index')->with($data);
		
    }
    
    public function sendInputForCorrectionTableDataInsert( $jobid , $metaid , $round , $inputarr ){
        
        $addionalobj        =       isset( $inputarr->eproof ) ? $inputarr->eproof : $inputarr;
							
        $cr_response        =       isset( $addionalobj->CorrectionDetails ) ? $addionalobj->CorrectionDetails : 'nocorrectionxml';
        $round_arr          =       \Config::get('constants.ROUND_NAME');
        
        if( is_object( $cr_response ) ){

            $chap_name          =       $cr_response->ChapterID;
            $chp_obj            =       explode( '_' , $cr_response->ChapterID );

            $inst_arr           =       array();
            $text_cor           =       (array)$cr_response->TextCorrection;
            $imag_cor           =       (array)$cr_response->ImageCorrection;
            $indx_cor           =       (array)$cr_response->IndexCorrection;
            $author_corr        =       $cr_response->NumberOfAuthorQueries;
            $attachmentno       =       $cr_response->NumberOfAttachments;

        }
		
        $inst_arr['METADATA_ID']            =   $metaid;
        $inst_arr['ROUND']                  =   $round;
        $inst_arr['TEXT_NO_CORRECTION']     =   isset( $text_cor['NumberOfCorrections'] ) ? json_encode($text_cor['NumberOfCorrections']) : '0';
        $inst_arr['IMAGE_NO_CORRECTION']    =   isset( $imag_cor['NumberOfCorrections'] ) ? $imag_cor['NumberOfCorrections'] : '0';
        $inst_arr['INDEX_NO_CORRECTION']    =   isset( $indx_cor['NumberOfCorrections'] ) ? $indx_cor['NumberOfCorrections'] : '0';
        $inst_arr['STATUS'] =   2;
        
        $jobDetails         =       DB::table('job')->where('JOB_ID', $jobid )->get();
        $book_id            =       $bookId             =       $jobDetails[0]->BOOK_ID;
		
        $returnLatest_      =       DB::select( "SELECT round FROM api_download WHERE BOOK_ID LIKE '%".$book_id."%' AND ROUND IN( ".$round_arr['S600']." )"  );
        $returnLatest2_     =       DB::select( "SELECT round FROM api_download WHERE BOOK_ID LIKE '%".$book_id."%' AND ROUND IN( ".$round_arr['S650']." )"  );
        
        if( count( $returnLatest_ ) && ( count( $returnLatest2_ ) == 0 ) ){
            $round = $round_arr['S600'];
        }
        
        if( $round == $round_arr['S600'] ){
            $inst_arr['STATUS'] =   4;
        }
        
        $inst_arr['DOWNLOAD_LOG']           =   json_encode( $inputarr );
        $inst_arr['AUTHOR_QUERIES_NO']      =   isset( $author_corr ) ? $author_corr : 0;
        $inst_arr['ATTACHMENT_NO']          =   isset( $attachmentno ) ? $attachmentno : 0;
        
        $cdm_obj        =      new apiCorrectionDownload();
        
        $cdm_obj->insertNew( $inst_arr );
         
        return true;
                
    }
    
    public function sendInputForCorrectionTableDataInsertMonoDataPrepare( $jobId , $metaid , $round , $addionalobj , &$insert_arr_mono ){
    
        $insert_arr_mono['JOB_ID']    =   $jobId;
        $insert_arr_mono['METADATA_ID']    =   $metaid;
        $insert_arr_mono['ROUND_ID']    =   $round;
        $insert_arr_mono['CORRECTION_DETAILS']    = json_encode($addionalobj);
        $insert_arr_mono['STATUS']    =   0;
        
    }
    
    public function handleS650CorrectionDownload( $priority = 0 , $metaid = null ){
		
        //Log::useDailyFiles(storage_path().'/Api/correctionDownloads650.log');
		//Log::info( "correction call" );
		
        $response[ 'status' ]   =       0;
        $response[ 'Msg' ]      =       'Failed';
        $response[ 'errMsg' ]   =       'Movetoproduction initiation';
        
		$query_stmt     =       "SELECT  cd.ID ,cd.JOB_ID , cd.METADATA_ID , cd.ROUND_ID , cd.CORRECTION_DETAILS , cd.STATUS, mn.FM_ARTICLE_BM FROM api_correction_download_mono as cd 
					join metadata_info as mn on mn.METADATA_ID = cd.METADATA_ID
					WHERE STATUS = 0 ORDER BY ID ASC limit 1 ";
        $findRecord     =       DB::select( $query_stmt );
        
        if( count( $findRecord ) ){
            
            $recset         =       $findRecord[0];
            $eproofresponse =       json_decode( $recset->CORRECTION_DETAILS );
            
            $jobid          =       $recset->JOB_ID;
            $metaid         =       $recset->METADATA_ID;
            $roundid        =       $recset->ROUND_ID;
            $inputarr       =       $eproofresponse;
            $recid          =       $recset->ID;
            
            $mvPrdObj       =       new clientAcknowledgementController();
            $moveRes        =       $mvPrdObj->correctionWorkflowMovetoProduction(  $jobid , $metaid , $roundid , $eproofresponse->CorrectionDetails , $response,$recset->FM_ARTICLE_BM  );
            
            //store correction details            
            $corrCntrl      =        new \App\Http\Controllers\correction\correctionController();
            $returnins      =       $corrCntrl->sendInputForCorrectionTableDataInsert(  $jobid , $metaid , $roundid , $inputarr );
            $moveRes		=		json_encode( $moveRes );
	        $updateval      =   	array( 'STATUS' =>  3 , 'REMARKS' => $moveRes );
			
            if( $returnins ){                
                $updateval      =   array( 'STATUS' =>  2 , 'REMARKS' => $moveRes );                
                $response['Msg']        =   'Success';
                $response['errMsg']     =   'correction download chapter successfully moved to projectbin';                        
            }
			
			DB::table('api_correction_download_mono')->where( 'ID' , $recid )->update( $updateval );
               
                            
        }else{
            
            $response['errMsg']     =   'There is no record to proceed';
            
        }
        
        return response()->json( $response );
        
        
    }
    
}