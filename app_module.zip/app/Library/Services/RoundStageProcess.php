<?php
namespace App\Library\Services;
use App\Models\stageModel;
use App\Models\roundModel;
class RoundStageProcess
{
    public function dogetroundandstagedetails()
    {
        $response["stgaelist"]  =   stageModel::Active()->get();
        $response["roundlist"]  =   roundModel::Active()->get();
        return $response;
    }	
}