<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Models\jobInfoModel;
use Carbon\Carbon;
use Session;

class eproofPackageModel extends Model 
{
    protected $table        =   'api_eproof_packaging';
    public  $primaryKey     =   'ID';
	const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "UPDATED_DATE";
        
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $randomtoken  =   "";
            do
            {
                $randomtoken 	=   str_random(10);
                $tokenexist 	=   eproofPackageModel::where('TOKEN_KEY',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $data['TOKEN_KEY']  =   $randomtoken;
            $spicastadd     =   eproofPackageModel::insertGetId($data);
            if($spicastadd >=1)
            {
                $spicastadd  =   eproofPackageModel::where('ID',$spicastadd)->first();
            }
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
    
     //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	eproofPackageModel::where('TOKEN_KEY',$token)->where('STATUS', '1.5' )->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
}

