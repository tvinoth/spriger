<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiCucbackgroundprocessModel extends Model 
{    
    protected $table        = 	'api_cuc';
    public $timestamps      = 	true;
    public  $primaryKey     =   'JOB_ID';
    protected $dateFormat   = 	'Y-m-d H:i:s';
    
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $randomtoken    =   "";
            do
            {
                $randomtoken=   str_random(10);
                $tokenexist =   apiCucbackgroundprocessModel::where('TOKEN',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $data['TOKEN']  =   $randomtoken;
            $spicastadd     =   apiCucbackgroundprocessModel::insertGetId($data);
            if($spicastadd >=1)
            {
                $spicastadd  =   apiCucbackgroundprocessModel::where('ID',$spicastadd)->first();
            }
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
    
    //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	apiCucbackgroundprocessModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
}
