<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class jobRoundModel extends Model {
    
    protected $table    =   'job_round_milestone';
    public $primaryKey  =   'JOB_ID';
    public $timestamps  =   true;
    protected $fillable =   array('CREATED_DATE');
    const UPDATED_AT    =   "LAST_MOD_DATE";
    
    
    //sample input array
    // 0 => id
    // 1 => limit start
    // 2 => limit  
    // 3 => order by
    
    public function getRecordInfo( $jobid ){          
    
        $info   =       array();
        $tblname        =       'job_round_milestone as jrm';
       
        try{
            
            $info   =       DB::table( $tblname )
                                        ->select( )
                                        ->where( 'jrm.JOB_ID', '=' , $jobid )
                                        ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $info;        
        
    }
           
}

