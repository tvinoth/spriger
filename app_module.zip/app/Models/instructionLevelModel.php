<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use App\Models\instructionModel;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use DB;

class instructionLevelModel extends Model 
{
    protected $table        =   'instruction_level';
    public  $primaryKey     =   'ID';
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',true);
    }
    
    public static function getInsructionleveldata($id)
    {
        return instructionModel::join('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->where('instruction_level.ID','=', $id )
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->first();
    }

    public static function getInsructionlevelChecklistById( $id ){
        
        return instructionModel::select( 
                        DB::raw('stage.STAGE_NAME,round_enum.NAME AS ROUND_NAME ,instruction.INSTRUCTION_TITLE, instruction_type_enum.NAME AS LEVEL_NAME , '
                        . 'instruction_level.INSTRUCTION , instruction_level.MANDATORY_TYPE as MANDATORY_TYPE_VALUE ,case instruction_level.MANDATORY_TYPE when 1 then "YES" when 0 then "NO" else "--" end as MANDATORY_TYPE ,'
                        . ' instruction_level.INSTRUCTION_ID , instruction_level.ID As INSTRUCTIONLEVEL_ID , instruction.ROUND_ENUM_ID AS ROUND_ID , instruction.STAGE_ID') 
                    )
                    ->leftjoin( 'instruction_level' , 'instruction_level.INSTRUCTION_ID' , '=' , 'instruction.INSTRUCTION_ID' )
                    ->leftjoin( 'instruction_type_enum' , 'instruction_type_enum.ID', '=' , 'instruction_level.INSTRUCTION_TYPE_ENUM_ID' )
                    ->join( 'stage' , 'stage.STAGE_ID' , '=' , 'instruction.STAGE_ID' )
                    ->join( 'round_enum' , 'round_enum.ID' , '=' , 'instruction.ROUND_ENUM_ID' )
                    ->where( 'instruction_level.ID' , '=' , $id )
                    ->where( 'instruction.IS_ACTIVE' , '=' , true )
                    ->where( 'instruction_level.IS_ACTIVE' , '=' , true)
                    ->first();

    }
    
}

