<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class customizationModel extends Model {

    /**
     * Get all the stage List 
     */
    public static function getStageDetail($stageId, $opt){
		$info = array();
		
		$stage = DB::table('stage as s')
			->where('s.IS_ACTIVE',1)
			->select(DB::raw('s.STAGE_ID, s.STAGE_NAME'))
			->orderBy('s.STAGE_NAME','asc')
			->get();
			
	
		return $stage;        
    }
	public static function getStageRole($stageId) {
		 $rounds = DB::table('stage_role as s')
				->join('ROLE_ENUM AS r', 'r.ID', '=', 's.role')
                ->where('s.stage', $stageId)
                ->select(DB::raw('r.ID, r.Name'))
				->orderBy('r.Name','asc')
                ->get();
        return $rounds;
	}
	public static function getRoundMasterDetail($roundId, $opt){
       $query = "CALL Proc_GetRoundList('".$roundId."','".$opt."')";  
       $dtlList = DB::select($query);
       return $dtlList;        
    }
	public static function deleteRound($inpArr) {		
		$updateQry = DB::table('round_enum')
			->where('ID', $inpArr['roundId'])
			->update(array('IS_ACTIVE' => 0));
		return $updateQry;
	}
	public static function saveRound($inpArr){
       $query = "CALL Proc_SaveRound('".$inpArr['userId']."','".$inpArr['roundId']."','".$inpArr['roundName']."','".$inpArr['description']."')";  
       $dtlList = DB::select($query);
       return $dtlList;        
    }

    public static function getWorkflowList(){
        $query = "SELECT wm.WORKFLOW_MASTER_ID,wf.WORKFLOW_ID,wm.CODE,wm.WORKFLOW_MASTER_NAME, c.CIRCLE_NAME, sc.SUB_CIRCLE_NAME, DATE_FORMAT(wm.CREATED_DATE,'%m-%d-%Y') AS CREATED_DATE
                                    FROM workflow_master wm
                                    JOIN workflow wf ON wf.WORKFLOW_MASTER_ID = wm.WORKFLOW_MASTER_ID 
                                    LEFT OUTER
                                    JOIN circle c ON c.CIRCLE_ID=wm.CIRCLE_ID
                                    LEFT OUTER
                                    JOIN sub_circle sc ON sc.SUB_CIRCLE_ID=wm.SUB_CIRCLE_ID
                                    WHERE wm.IS_ACTIVE=1
                                    AND wf.WORKFLOW_TYPE = 0
                                    ORDER BY wm.CREATED_DATE DESC"; 
        $dtlList = DB::select($query);
        return $dtlList;        
    }
    public static function getAssignedStages($workflowId) {
            $info = array();
            $assignedStage = DB::table('workflow_stage_activity as ws')
                            ->join('stage AS s', 's.STAGE_ID', '=', 'ws.STAGE')
                            ->where('ws.WORKFLOW', $workflowId)
                            ->select(DB::raw('ws.STAGE as STAGE_ID, s.STAGE_NAME'))
                            ->orderBy('ws.STAGE_SEQ','asc')
                            ->get();

            $stg    =   [];
            for($i=0; $i<count($assignedStage); $i++) {
                    $stg[] = $assignedStage[$i]->STAGE_ID;
            }		
            $stage = DB::table('stage as s')
                    ->whereNotIn('s.STAGE_ID',$stg)
                    ->where('s.IS_ACTIVE',1)
                    ->select(DB::raw('s.STAGE_ID, s.STAGE_NAME'))
                    ->orderBy('s.STAGE_NAME','asc')
                    ->get();

            $info['stage'] = $stage;
            $info['assignedStage'] = $assignedStage;
            
            return $info;		
    }

	public static function getWorkflowAndStagesassignbyrule($workflowMasterId,$jobid,$roundId) {

            $info = array(); $stageInfo = array();
            $wfInfo = DB::table('workflow as w')
                            ->leftjoin('stage AS s1', 's1.STAGE_ID', '=', 'w.START_STAGE')
                            ->leftjoin('stage AS s2', 's2.STAGE_ID', '=', 'w.END_STAGE')
                            ->where('w.WORKFLOW_MASTER_ID', $workflowMasterId)
                            ->select(DB::raw(' w.WORKFLOW_ID, w.WORKFLOW_TYPE, w.WORKFLOW_NAME, s1.STAGE_NAME as START_STAGE, s2.STAGE_NAME as END_STAGE '))
                            ->orderByRaw("w.WORKFLOW_ID ASC,w.WORKFLOW_TYPE ASC")
                            ->get();
                
                if(count($wfInfo) > 0) {
                    
			for($k=0; $k<count($wfInfo); $k++) {
		
                            $tmpArray = DB::table('workflow_stage_activity as wa')
					->join('stage AS s', 's.STAGE_ID', '=', 'wa.STAGE')
					->where('wa.WORKFLOW', $wfInfo[$k]->WORKFLOW_ID)
					->select(DB::raw(' s.STAGE_NAME,s.STAGE_ID '))
                                        ->orderBy( 'wa.STAGE_SEQ' , 'ASC' )
					->get();
                           
                            $stageInfo[$wfInfo[$k]->WORKFLOW_ID] = $tmpArray;
                                
			}
                        
		}
               
		$info['workflow'] = $wfInfo;
		$info['stage'] = $stageInfo;

		return $info;
                
	}
        
        public function getWorkflowRuleByStage($wfMid,$jobid,$roundId,$wfId,$stageId){
            
            $sql    =  "select ur.* from task_level_userdefined_workflow as uw 
                        join user_defined_workflow_rule as ur ON ur.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = uw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID
                        where uw.JOB_ID = '$jobid' and uw.ROUND = '$roundId' and uw.WORKFLOW_MASTER_ID = '$wfMid' and uw.WORKFLOW = '$wfId' and ur.STAGE_ID ='$stageId' ";
           
           $dtlList = DB::select($sql);
            
            return $dtlList;
            
            
        }
        
        
        public static function getWorkflowAndStages($workflowMasterId) {
            
                //DB::enableQueryLog();
		$info = array(); $stageInfo = array();
		$wfInfo = DB::table('workflow as w')
				->leftjoin('stage AS s1', 's1.STAGE_ID', '=', 'w.START_STAGE')
				->leftjoin('stage AS s2', 's2.STAGE_ID', '=', 'w.END_STAGE')
				->where('w.WORKFLOW_MASTER_ID', $workflowMasterId)
                ->select(DB::raw(' w.WORKFLOW_ID, w.WORKFLOW_TYPE, w.WORKFLOW_NAME, s1.STAGE_NAME as START_STAGE, s2.STAGE_NAME as END_STAGE '))
				->orderBy('w.WORKFLOW_TYPE','asc')
                ->get();
                
                if(count($wfInfo) > 0) {
			for($k=0; $k<count($wfInfo); $k++) {
		
				$tmpArray = DB::table('workflow_stage_activity as wa')
					->join('stage AS s', 's.STAGE_ID', '=', 'wa.STAGE')
					->where('wa.WORKFLOW', $wfInfo[$k]->WORKFLOW_ID)
					->select(DB::raw(' s.STAGE_NAME,s.STAGE_ID '))
                                        ->orderBy( 'STAGE_SEQ' , 'ASC' )
					->get();
				$stageInfo[$wfInfo[$k]->WORKFLOW_ID] = $tmpArray;
			}
		}
		$info['workflow'] = $wfInfo;
		$info['stage'] = $stageInfo;
		return $info;
	}
        
        public static function getWorkflowAndStagesForbgsetup($workflowMasterId) {
            
                //DB::enableQueryLog();
		$info = array(); $stageInfo = array();
		$wfInfo = DB::table('workflow as w')
				->leftjoin('stage AS s1', 's1.STAGE_ID', '=', 'w.START_STAGE')
				->leftjoin('stage AS s2', 's2.STAGE_ID', '=', 'w.END_STAGE')
				->where('w.WORKFLOW_MASTER_ID', $workflowMasterId)
                ->select(DB::raw('w.WORKFLOW_MASTER_ID, w.WORKFLOW_ID, w.WORKFLOW_TYPE, w.WORKFLOW_NAME, s1.STAGE_NAME as START_STAGE, s2.STAGE_NAME as END_STAGE '))
				->orderBy('w.WORKFLOW_TYPE','asc')
                ->get();
                
                if(count($wfInfo) > 0) {
			for($k=0; $k<count($wfInfo); $k++) {
		
				$tmpArray = DB::table('workflow_stage_activity as wa')
					->join('stage AS s', 's.STAGE_ID', '=', 'wa.STAGE')
					->where('wa.WORKFLOW', $wfInfo[$k]->WORKFLOW_ID)
					->select(DB::raw(' s.STAGE_NAME,s.STAGE_ID , wa.IS_AUTO '))
                                        ->orderBy( 'STAGE_SEQ' , 'ASC' )
					->get();
				$stageInfo[$wfInfo[$k]->WORKFLOW_ID] = $tmpArray;
			}
		}
                
		$info['workflow'] = $wfInfo;
		$info['stage'] = $stageInfo;
                
                $stagetypes_arr =   array();
                $assignedround  =   null;
                $stagetypes     =   DB::select( "select stage_id , stage_types from bgprocess_stage_type_enum where is_active = 1" );
                
                if( count( $stagetypes ) ){
                    foreach( $stagetypes as $key => $value ){                        
                       $stagetypes_arr[$value->stage_id][] =  $value->stage_types;
                    }
                }
                
                $roundtypes     =   DB::select( "select round from task_level_userdefined_workflow where WORKFLOW_MASTER_ID = $workflowMasterId LIMIT 1" );
                
                if( count( $roundtypes ) ){
                    foreach( $roundtypes as $key => $value ){                        
                       $assignedround   =     $value->round;
                    }
                }
                
                $info['stagetypes'] =   $stagetypes_arr;
		$info['activeround']    =   $assignedround;
                return $info;
                
	}
        
	public static function deleteWorkflow($workflowMasterId) {
		$updateQry = DB::table('workflow_master')
			->where('WORKFLOW_MASTER_ID', $workflowMasterId)
			->update(array('IS_ACTIVE' => 0));
		return $updateQry;
	}
	public static function getCircle() {
		 $info = DB::table('circle')
                ->select(DB::raw('CIRCLE_ID, CIRCLE_NAME'))
				->orderBy('CIRCLE_NAME','asc')
                ->get();
        return $info;
	}
	public static function getSubCircle($circleId) {
		 $info = DB::table('sub_circle')
                ->where('circle_id', $circleId)
                ->select(DB::raw('SUB_CIRCLE_ID, SUB_CIRCLE_NAME'))
				->orderBy('SUB_CIRCLE_NAME','asc')
                ->get();
        return $info;
	}
	public static function saveWorkflowbackup($inpArr){
		$seq = 0;$wfId = 0;$wfMasterId = 0;
		$stageArray = explode(",", $inpArr['wfStage']);
		$wfId = $inpArr['wfId'];
		$wfMasterId = $inpArr['wfMasterId'];
		for($i=0; $i<count($stageArray); $i++) {
			$query = "CALL Proc_SaveWorkflow('".$inpArr['opt']."','".$seq."','".$inpArr['userId']."','".$wfMasterId."','".$wfId."','".$inpArr['wfEG']."','".$inpArr['wfCluster']."','".$inpArr['wfName']."','".$stageArray[$i]."')";  
			$dtlList = DB::select($query);
			$wfId = $dtlList[0]->wfId;
			$wfMasterId = $dtlList[0]->wfMasterId;
			$seq = $dtlList[0]->seq;
		}
		return $dtlList;        
    }
	public static function getPresetMasterDetail($presetId, $opt){
       $query = "CALL Proc_GetPresetList('".$presetId."','".$opt."')";  
       $dtlList = DB::select($query);
       return $dtlList;        
    }
	public static function deletePreset($inpArr) {	
		$updateQry = DB::table('schools_presets')->where('Preset_id', $inpArr['presetId'])->delete();	
		return $updateQry;
	}
	public static function savePreset($inpArr){
       $query = "CALL Proc_SavePreset('".$inpArr['userId']."','".$inpArr['presetId']."','".$inpArr['presetName']."','".$inpArr['presetType']."')";  
       $dtlList = DB::select($query);
       return $dtlList;        
    }
    
     public static function getPackageList(){
         $package 		=	array();
        try{
            // DB::enableQueryLog();
             
              $package  = DB::table('transaction_package')
                            ->where('is_active', true)
                            ->select(DB::raw('transaction_package_id id, code, name, description'))
                            ->get();
         //   $qw         =       DB::getQueryLog();
       //    print_r($qw);
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
        
    }
    
    
    public static function getPackageListById($pid){
         $package 		=	array();
        try{
            // DB::enableQueryLog();
             
              $package  = DB::table('transaction_package')
                            ->where('is_active', true)
                            ->where('transaction_package_id','=',$pid)
                            ->select(DB::raw('transaction_package_id id, code, name, description'))
                            ->get();
         //   $qw         =       DB::getQueryLog();
       //    print_r($qw);
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
        
    }
    
    
    
    public static function getMenuList(){
         $package 		=	array();
        try{
             
              $package  = DB::table('transaction_menu')
                            ->where('is_active', true)
                            ->select(DB::raw('transaction_menu_id id, transaction_name'))
                            ->get();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
        
    }
    
    public static function getUnassignMenuList($assignedMenu){
         $package 		=	array();
        try{
             //DB::enableQueryLog();
              $package  = DB::table('transaction_menu')
                            ->where('is_active', true)
                            ->whereNotIn('TRANSACTION_MENU_ID',$assignedMenu)
                            ->select(DB::raw('transaction_menu_id id, transaction_name'))
                            ->get();
            //  $qw         =       DB::getQueryLog();
          //print_r($qw);
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
        
    }
    
    public static function generatePackageCode(){
        $package 		=	array();
        try{
             
              $package  = DB::table('document_type')
                            ->where('OBJECT_TYPE_ENUM_ID','=', '42')
                            ->select(DB::raw('concat(CODE,"",CURRENT_RANGE+1) as code'))
                            ->get();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
    }
    
    
     public static function getpackageName($packageName){
        $package 		=	array();
        
        if(empty($packageName))
            return false;
        try{
             
              $package  = DB::table('transaction_package')
                            ->where('NAME', '=',$packageName)
                            ->select(DB::raw('NAME'))
                            ->first();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
    }
    
    public static function getworkflowName($packageName){
        $package 		=	array();
        
        if(empty($packageName))
            return false;
        try{
             
              $package  = DB::table('workflow_master')
                            ->where('WORKFLOW_MASTER_NAME', '=',$packageName)
                            ->select(DB::raw('WORKFLOW_MASTER_NAME'))
                            ->first();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
    }
    
     public static function getParallelworkflowName($packageName,$wfMId){
        $package 		=	array();
        
        if(empty($packageName))
            return false;
        try{
            //  DB::enableQueryLog();
              $package  = DB::table('workflow')
                            ->where('WORKFLOW_MASTER_ID', '=',$wfMId)
                            ->where('WORKFLOW_NAME', '=',$packageName)
                            ->select(DB::raw('WORKFLOW_NAME as WORKFLOW_MASTER_NAME '))
                            ->first();
            ///     $qw         =       DB::getQueryLog();
          //print_r($qw);
        }catch( \Exception $e ){   
            echo "<pre>";print_r($e);exit;
            return false;
        }
	
        return $package;
    }
    
    
    public static function getAssignedPackageMenuList($packageId){
        
        $package 		=	array();
        
        if(empty($packageId))
            return false;
        try{
             
              $package  = DB::table('transaction_package As tp')
                      
                            ->join('transaction_package_item AS tpi', 'tp.TRANSACTION_PACKAGE_ID', '=', 'tpi.TRANSACTION_PACKAGE_ID')
                            ->join('transaction_menu AS tm', 'tm.TRANSACTION_MENU_ID', '=', 'tpi.TRANSACTION_MENU_ID')
                            ->where('tp.TRANSACTION_PACKAGE_ID', '=',$packageId)
                            ->select(DB::raw('tm.TRANSACTION_MENU_ID as id,tm.TRANSACTION_NAME as transaction_name'))
                            ->get();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
    }
    
    public static function deletepackage($packageId){
        if(empty($packageId))
            return false;
        try{    
            $itemTrans =  DB::table('transaction_package_item')->where('TRANSACTION_PACKAGE_ID', '=', $packageId)->delete();
            $itemTrans1 =  DB::table('transaction_package')->where('TRANSACTION_PACKAGE_ID', '=', $packageId)->delete();
            if($itemTrans !=0 && $itemTrans1 !=0){
                return true;
            }else{
                return false;
            }
        }catch( \Exception $e ){           
            return false;
        }
    }
    
    
     public static function generateWorkflowCode(){
        $package 		=	array();
        try{
             
              $package  = DB::table('document_type')
                            ->where('OBJECT_TYPE_ENUM_ID','=', '31')
                            ->select(DB::raw('concat(CODE,"",CURRENT_RANGE+1) as code'))
                            ->get();
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
    }
    
    
    
    /** workflow  * */
    public static function getWorkflowMaster($wfmId) {

        $workflowMaster = array();
        try {

            $workflowMaster = DB::table('workflow_master')
                    ->where('WORKFLOW_MASTER_ID', '=', $wfmId)
                    ->where('IS_ACTIVE', '=', '1')
                    ->select(DB::raw('WORKFLOW_MASTER_ID,CIRCLE_ID,SUB_CIRCLE_ID,CODE,WORKFLOW_MASTER_NAME,DESCRIPTION'))
                    ->get();
           
        } catch (\Exception $e) {
            return false;
        }

        return $workflowMaster;
    }
    
    
    
    public static function getWorkflowInformation($wfmId){
       
        if(empty($wfmId))
            return false;
        
        try { 
                $query =  "select c.CIRCLE_ID,c.CIRCLE_NAME,sc.SUB_CIRCLE_ID,sc.SUB_CIRCLE_NAME,wm.WORKFLOW_MASTER_NAME,wm.CODE,wf.WORKFLOW_NAME,wf.WORKFLOW_ID,wf.WORKFLOW_TYPE from workflow_master as wm
                                 left join workflow as wf ON wf.WORKFLOW_MASTER_ID = wm.WORKFLOW_MASTER_ID
                                 join circle as c ON c.CIRCLE_ID = wm.CIRCLE_ID
                                 join sub_circle as sc ON sc.SUB_CIRCLE_ID = wm.SUB_CIRCLE_ID
                                 where wm.WORKFLOW_MASTER_ID = '$wfmId'";

                $dtlList = DB::select($query);
        } catch (\Exception $e) {
            return false;
        }
        return $dtlList;
    }
    
    public static function getMasterWorkflowAssignStages($wfmId){
       
        if(empty($wfmId))
            return false;
        
        try { 
                $query =  "select s.STAGE_NAME,sa.STAGE as STAGE_ID from workflow_master as wm 
                            join workflow as wf ON wf.WORKFLOW_MASTER_ID = wm.WORKFLOW_MASTER_ID and wf.WORKFLOW_TYPE = 0
                            join workflow_stage_activity as sa ON sa.WORKFLOW = wf.WORKFLOW_ID
                            join stage as s ON sa.STAGE = s.STAGE_ID 
                            where wm.WORKFLOW_MASTER_ID = '$wfmId' 
                            order by sa.STAGE_SEQ asc ";

                $dtlList = DB::select($query);
                
        } catch (\Exception $e) {
            return false;
        }
        return $dtlList;
    }
    
    public static function getWorkflowDetails($wfId){
         $workflowDetails = array();
        try {

            $workflowDetails = DB::table('workflow')
                    ->where('WORKFLOW_ID', '=', $wfId)
                    ->select(DB::raw('WORKFLOW_MASTER_ID,WORKFLOW_NAME,WORKFLOW_TYPE,START_STAGE,END_STAGE'))
                    ->get();
           
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
    }
    
    public static function getMasterWorkflowDetails($wfId){
         $workflowDetails = array();
        try {

            $workflowDetails = DB::table('workflow')
                    ->where('WORKFLOW_MASTER_ID', '=', $wfId)
                    ->where('WORKFLOW_TYPE','=','0')
                    ->select(DB::raw('WORKFLOW_MASTER_ID,WORKFLOW_ID,WORKFLOW_NAME,WORKFLOW_TYPE,START_STAGE,END_STAGE'))
                    
                    ->get();
           
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
    }
    
    public static function getUserdefinedInformation ($jobid,$round,$wfMid) {
        
         $workflowDetails = array();
        try {

            $workflowDetails = DB::table('task_level_userdefined_workflow as udw')
                    ->where('WORKFLOW_MASTER_ID', '=', $wfMid)
                    ->where('ROUND', '=', $round)
                    ->where('JOB_ID','=', $jobid)
                    ->select(DB::raw('count(udw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID) as total'))
                    ->get();
           
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
    
    public static function getWorkflowCount($jobId){
        
          $workflowDetails = array();
        try {

            $workflowDetails = DB::table('task_level_userdefined_workflow as udw')
                    ->where('JOB_ID','=', $jobId)
                    ->select(DB::raw('distinct(udw.ROUND_SEQ) as total'))
                    ->count();
           
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
    
    public static function insertUserdefineData($jobId,$roundId,$wfMId,$userId,$roundSequence){
       
        if(empty($wfMId))
            return false;
        
        try { 
                $query =    "insert into task_level_userdefined_workflow (JOB_ID, ROUND, WORKFLOW_MASTER_ID, WORKFLOW, STAGE, STAGE_SEQ, SKIP_STAGE, START_STAGE, END_STAGE,WORKFLOW_TYPE, LAST_MOD_DATE, LAST_MOD_BY,ROUND_SEQ, IS_AUTO)
                                        select '".$jobId."' as JOB_ID, '".$roundId."' as ROUND_ID, w.WORKFLOW_MASTER_ID, w.WORKFLOW_ID, ws.STAGE, ws.STAGE_SEQ, ws.IS_SKIP, w.START_STAGE, w.END_STAGE, w.WORKFLOW_TYPE, now(),'".$userId."','".$roundSequence."' , ws.IS_AUTO from workflow_stage_activity ws
                                        join workflow w where w.WORKFLOW_MASTER_ID='".$wfMId."' and ws.WORKFLOW=w.WORKFLOW_ID";
                
                $dtlList = DB::select($query);
                
        } catch (\Exception $e) {
            return false;
        }
        return $dtlList;
    }
    
    
    public static function getjobAssignedWorkflow ($jobid) {
        
       //  $workflowDetails = array();
        try {
             
            $workflowDetails = DB::table('task_level_userdefined_workflow as udw')
                                    ->join('round_enum AS r', 'udw.ROUND', '=', 'r.ID')
                                    ->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID')
                                    ->where('udw.JOB_ID','=', $jobid)
                                    ->where('udw.WORKFLOW_TYPE','=', '0')
                                    ->groupBy('udw.WORKFLOW_MASTER_ID')
                                    ->orderBy('udw.ROUND_SEQ','asc')
                                    ->select()
                                    ->get();
            
          //$qw         =       DB::getQueryLog();
        //  print_r($qw);
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
    
    public static function getjobAssignedWorkflowByRound ($jobid, $round) {
        
       //  $workflowDetails = array();
        try {
           
              DB::enableQueryLog();
             
            $workflowDetails = DB::table('task_level_userdefined_workflow as udw')
                                    ->join('round_enum AS r', 'udw.ROUND', '=', 'r.ID')
                                    ->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID')
                                    ->where('udw.JOB_ID','=', $jobid)
                                    ->where('udw.ROUND','=', $round)
                                    ->where('udw.WORKFLOW_TYPE','=', '0')
                                    ->groupBy('udw.WORKFLOW_MASTER_ID')
                                    ->orderBy('udw.ROUND_SEQ','asc')
                                    ->select()
                                    ->get();
            
          //$qw         =       DB::getQueryLog();
        //  print_r($qw);
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
	
	 public static function getjobAssignedWorkflowByRoundWithCategory ($jobid, $round) {
        
       //  $workflowDetails = array();
        try {
          
              DB::enableQueryLog();
             
            $workflowDetails = DB::table('task_level_userdefined_workflow as udw')
                                    ->join('round_enum AS r', 'udw.ROUND', '=', 'r.ID')
                                    ->Leftjoin('workflow_category as udw1',function($join){
                                        $join->on('udw1.ROUND_ID', '=', 'r.ID');
                                        $join->on('udw1.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID');
                                    })
                                    ->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID')
                                    ->where('udw.JOB_ID','=', $jobid)
                                    ->where('udw.ROUND','=', $round)
                                    ->where('udw.WORKFLOW_TYPE','=', '0')
                                    ->groupBy('udw.WORKFLOW_MASTER_ID')
                                    ->orderBy('udw.ROUND_SEQ','asc')
                                    ->select()
                                    ->get();
            
         // $qw         =       DB::getQueryLog();
        //  print_r($qw);
        } catch (\Exception $e) {
                 //   print_r($e->getMessage());
            return false;
        }

        return $workflowDetails;
        
        
    }
    
    public static function getWorkflowByCategory ( $round) {
        
       //  $workflowDetails = array();
        try {
           
              DB::enableQueryLog();
             
            $workflowDetails = DB::table('workflow_category as udw')
                                    ->join('round_enum AS r', 'udw.ROUND_ID', '=', 'r.ID')
                                    ->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID')
                                    ->where('udw.ROUND_ID','=', $round)
                                    //->groupBy('udw.WORKFLOW_MASTER_ID')
                                    ->select()
                                    ->get();
            
          //$qw         =       DB::getQueryLog();
        //  print_r($qw);
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
    
     public static function getWorkflowByCategoryByEmbbed ( $round, $category) {
        
       //  $workflowDetails = array();
        try {
           
              DB::enableQueryLog();
             
            $workflowDetails = DB::table('workflow_category as udw')
                                    ->join('round_enum AS r', 'udw.ROUND_ID', '=', 'r.ID')
                                    ->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'udw.WORKFLOW_MASTER_ID')
                                    ->where('udw.ROUND_ID','=', $round)
                                    ->where('udw.CATEGORY','=', $category)
                                    ->groupBy('udw.WORKFLOW_MASTER_ID')
                                    ->select()
                                    ->get();
            
          //$qw         =       DB::getQueryLog();
        //  print_r($qw);
        } catch (\Exception $e) {
            return false;
        }

        return $workflowDetails;
        
        
    }
    
  

}