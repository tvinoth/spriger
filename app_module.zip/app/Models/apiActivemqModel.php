<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Models\jobInfoModel;
use Carbon\Carbon;
use Session;

class apiActivemqModel extends Model 
{
    protected $table        =   'api_activemq_log';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "UPDATED_DATE";
     //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	apiActivemqModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
}

