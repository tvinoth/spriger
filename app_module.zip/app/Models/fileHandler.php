<?php
namespace App\Models;
use App\Models\fileHandler;
use Illuminate\Database\Eloquent\Model;
use DB;

class fileHandler extends Model {
    
    protected $table = 'file_handler';
    public $timestamps = false;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    public static function checkFhStatus($inpArr) {
	
        $info = DB::table('file_handler')
            	->where('system_ip', $inpArr['systemIP'])
		->where('ID', $inpArr['FhID'])
                ->select(DB::raw('* '))
                ->get();
        
        return $info;
    }	
	
    public static function checkFileStatus($inpArr) {
	$wheredata  =   array('ID'=>$inpArr['FhID'],'system_ip'=>$inpArr['systemIP']);
        $info       =   fileHandler::where($wheredata)->first();
        return $info;
    }
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new fileHandler();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $table_name         =       'file_handler';
        //$insert_r         =       $api_obj->save();
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
       
        $record_id      =       $insert_r;
        
        if( $insert_r )
            return $record_id;
        
        return false;
    }
    
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                           );
        
        $updateQry  =   DB::table('file_handler')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByBookid( $bookid , $round ){
        
         $getRec       =         DB::table('api_meta_extractor as ame')
                                            ->where('BOOK_ID', '=', $bookid)
                                            ->where('ROUND', '=', $round )                                            
              ->orderBy('ame.ID', 'desc')
              ->get()->first();
      
      return $getRec;
      
    }
    
}
