<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class jobInfoModel extends Model {
    
    protected $table    =   'job_info';
    public $primaryKey  =   'JOB_ID';
    public $timestamps  =   true;
    protected $fillable =   array('CREATED_DATE');
    const UPDATED_AT    =   "LAST_MOD_DATE";
    public static function updateContact( $inpArr ){
        
        $setArr     =   array( 
                               'CONTACT_NAME'   =>  $inpArr['CONTACT_NAME']   , 
                               'CONTACT_EMAIL'  =>  $inpArr['CONTACT_EMAIL'] ,
                               'LOCATION_ID'    =>  $inpArr['LOCATION_ID'] ,
                               'LAST_MOD_DATE'  =>  'NOW()' , 
                               'LAST_MOD_BY'    =>  $inpArr['user_id']
                        );
        
        
        $updateQry  =   DB::table('contact_details')
			->where('ID', $inpArr['ID'])
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    //sample input array
    // 0 => id
    // 1 => limit start
    // 2 => limit  
    // 3 => order by
    
    public static function getContactInformation( $input = array() ){          
    
        //$limit_start =  $input['limit_start'];
        //$contact_info     =     DB::table('contact_details')->skip(10)->take(5)->get();
        
        $contact_info   =       array();
        $tblname        =       'contact_details as cd';
        
        try{
            
            $select_field   =       array( 'cd.ID' , 'cd.CONTACT_NAME' , 'cd.CONTACT_EMAIL' , 'cd.LOCATION_ID' , 'cd.STATUS' , 'lc.LOCATION_NAME' );
            
            $contact_info   =       DB::table( $tblname )
                                    ->join( 'location as lc' , 'cd.LOCATION_ID', '=', 'lc.ID')           
                                    ->select( $select_field )
                                    ->Where( 'cd.STATUS', '=' , 'ACTIVE' )
                                    ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;        
        
    }
    
    public static function deleteContact( $rowid  =   null ){
        
        $response   =   false;
        $tbl      =   'contact_details';
        
        if( !is_null( $rowid ) ){
            
            $response       =       DB::table( $tbl )->where( 'ID' , '=' ,  $rowid )->delete();
           
        }
        
        return $response;
        
    }
    
    
    public static function updateJobdata($jobid     =   null,$data = [])
    {
        $contact_info   =   false;
        try
        {
            //DB::enableQueryLog();
            
            $contact_info   =	DB::table('job_info' )->where('JOB_ID',$jobid)->update($data);
            //$qu =   DB::getQueryLog();
            //print_r( $qu );
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $contact_info;    
    }
       
    public static function checkExistbookjob($jobId = null){
        
        $bookinfo 		=	array();
        
        try{
            $bookinfo           =       jobInfoModel::select(DB::raw('PE_MAIL'))->where('JOB_ID',$jobId)
                                        ->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
        
    }
}

