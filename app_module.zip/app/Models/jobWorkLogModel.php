<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class jobWorkLogModel extends Model {
    
    protected 	$table    		=   'job_work_log';
    public      $primaryKey     =   'JOB_WORK_LOG_ID';
    
	public function getRecordsByJobStageId( $jobstageid , $custom_condition = array() ){
          
        $table      =   'job_work_log';
        
        if( !is_null( $jobstageid ) && empty( $custom_condition ) ){
        
            return DB::table( $table )->where( 'JOB_STAGE_ID', '=', $jobstageid )
                    ->orderBy('JOB_WORK_LOG_ID','desc')
                    ->get()->first();
            
        }
        
        if( !is_null( $jobstageid ) && !empty( $custom_condition ) ){
        
            return DB::table( $table )->where( 'JOB_STAGE_ID', '=', $jobstageid )
                    ->WhereNotNull('CHECK_IN')
                    ->orderBy('JOB_WORK_LOG_ID','desc')
                    ->get()->first();
            
        }
        
        return false;   
    }
    
    public function getRecordByBatchId( $batchId  = null ){
        
           
        $table      =   'job_work_log';
        
        if( !is_null( $batchId ) ){
        
            return DB::table( $table )->where( 'BATCH_ID', '=', $batchId )
                    ->orderBy('JOB_WORK_LOG_ID','desc')
                    ->get()->first();
            
        }
        
        return false;
        
    }
    
}

