<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ApiDownloadModel extends Model
{
    protected $table    =   "api_download";
    public  $primaryKey =   'ID';
    const   CREATED_AT  =   "DOWNLOAD_START";
    const   UPDATED_AT  =   "DOWNLOAD_END";
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',true);
    }
}
