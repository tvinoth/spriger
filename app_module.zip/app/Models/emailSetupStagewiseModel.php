<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;

class emailSetupStagewiseModel extends Model 
{
    protected $table        =   'email_setup_stagewise';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "UPDATED_DATE";    
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',true);
    }
}

