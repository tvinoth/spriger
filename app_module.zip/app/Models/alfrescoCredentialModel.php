<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class alfrescoCredentialModel extends Model {
    
    protected $table    =   'alfresco_credential';
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',1);
    }
    
}

