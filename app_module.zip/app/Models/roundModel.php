<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class roundModel extends Model {
    
    protected $table    =   'round_enum';
    public static function getAllRoundInfo( $select_arr = array() ){        
        
        if( !empty( $select_arr ) ){
            $round_arr      =       roundModel::select( $select_arr )->where('IS_ACTIVE',true)->get();
        }else{
            $round_arr      =       roundModel::where('IS_ACTIVE',true)->get();
        }
        return $round_arr;
      
    }
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',1);
    }
    
}

