<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class bgprocessSubPathSetup extends Model{    
    
    protected   $table        =   'bgprocess_sub_path_setup';
    public      $primaryKey     =   'ID';
    
    public function getBgProcessTags( $parentId ){
        
        $query      =   DB::table('bgprocess_sub_path_setup')
                            ->select()
                            ->where('STATUS' , '=' , 1 );
        
        if( !is_null( $parentId ) )
            $query->where( 'PARENT_ID' , '=' , $parentId );
        
        $query->orderBy( 'ORDER' , 'asc' );
        
        return $query->get();
        
    }
    
    public function getBgProcessSubTags( $subparentId ){
        
        $query      =   DB::table('bgprocess_sub_path_setup')
                            ->select()
                            ->where('STATUS' , '=' , 1 );

        if( !is_null( $subparentId ) )
            $query->where( 'SUB_PARENT_ID' , '=' , $subparentId );

        $query->orderBy( 'ORDER' , 'asc' );
        return $query->get();
         
     }
   
}

