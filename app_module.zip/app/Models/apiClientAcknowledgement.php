<?php
namespace App\Models;
use App\Models\apiClientAcknowledgement;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiClientAcknowledgement extends Model {
    
    protected $table        =   'api_client_acknowledgement';
    public $timestamps      =   true;
    protected $dateFormat   =   'Y-m-d H:i:s';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_AT";
    const UPDATED_AT        =   "UPDATED_AT";
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiClientAcknowledgement();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                  'PROCESS_TYPE'   =>     $inpArr['PROCESS_TYPE'] , 
                                  'FILE_NAME' =>      $inpArr['FILE_NAME'] , 
                                  'START_TIME' =>     $inpArr['START_TIME'] , 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $updateQry  =   DB::table('api_client_acknowledgement')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequest( $jobid , $round , $filenameinlog = null ){
        
        if( is_null( $filenameinlog ) ){
            
            $getRec       =         DB::table('api_client_acknowledgement as aca')
                                            ->where('JOB_ID', '=' , $jobid )
                                            ->where('ROUND' , '=' , $round )                                            
                                            ->where('STATUS', '=' , '1.5' )                                            
                                            ->orderBy( 'aca.ID', 'desc' )
                                            ->get()->first();
            
        }else{ 
            
            $getRec       =         DB::table('api_client_acknowledgement as aca')
                                            ->where('JOB_ID', '=', $jobid )
                                            //->where('ROUND', '=', $round )                                            
                                            ->where('FILE_NAME_IN_LOG', '=', $filenameinlog )   
                                            ->where('STATUS', '=' , '1.5' )                                            
                                            ->orderBy( 'aca.ID' , 'desc' )
                                            ->get()->first();
            
        }
        
       
      return $getRec;
      
    }
    
    
}
