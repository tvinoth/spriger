<?php
namespace App\Models;
use App\Models\apiMetaExtractor;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiMetaExtractor extends Model {
    
    protected   $table      =   'api_meta_extractor';
    public      $timestamps =   true;
    protected   $dateFormat =   'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiMetaExtractor();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        $table_name         =       'api_meta_extractor';
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                           );
        
        $updateQry  =   DB::table('api_meta_extractor')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByBookid( $bookid , $round ){
        
         $getRec       =         DB::table('api_meta_extractor as ame')
                                            ->where('BOOK_ID', '=', $bookid)
                                            ->where('ROUND', '=', $round )                                            
              ->orderBy('ame.ID', 'desc')
              ->get()->first();
      
      return $getRec;
      
    }
    
    public function getJobsheetStatus( $pageno = null,$limit = null,$type = null,$jobid = null,$metaid = null){
        
        $query_stmt      =   '';
        $query_stmt     .=   ' select r.* ,ame.ID as AMEID,ac.ID as ACKID,afu.ID as AFUID, r.Job_Id as JOB_ID ,  ame.PROCESS_TYPE ,  r.Round as ROUND_ID ,  CASE r.ROUND WHEN 114 THEN "S50" WHEN 116 THEN "S200" WHEN 118 THEN "S300" WHEN 119 THEN "S600" WHEN 120 THEN "S650" ';
        $query_stmt     .=   ' ELSE "S5" END AS ROUND_NAME , ame.created_at';
        $query_stmt     .=   ' , ame.`STATUS` as  JOB_SHEET_UPDATE, ame.`REMARKS` as  UPDATE_REMARKS ';
        $query_stmt     .=   ' , afu.`STATUS` as  JOB_SHEET_UPLOAD, afu.`REMARKS` as  UPLOAD_REMARKS ';
        $query_stmt     .=   ' , ac.`STATUS` as  SUCCESS_REDO , ac.`REMARKS` as  SR_REMARKS , 1 as SHEET_FLAG from ( select j.JOB_ID as Job_Id , ad.ROUND as Round , j.BOOK_ID from api_download ad  ';
        $query_stmt     .=   ' left join job j on j.BOOK_ID = ad.BOOK_ID and ad.is_completed = 1 and ad.is_active = 1 ) as r  ';
        $query_stmt     .=   ' left JOIN api_meta_extractor ame	on ame.JOB_ID = r.Job_Id and ame.ROUND = r.Round and ame.ID IN  ';
        if(empty($type)){
        $query_stmt     .=   ' ( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND process_type in (2,4,5)  order by ame2.ID desc ) ';
        $query_stmt     .=   ' left join api_file_upload afu on afu.JOB_ID = r.Job_Id and afu.ROUND = r.Round and afu.ID IN  ';
        $query_stmt     .=   ' ( select max(afu2.ID) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND process_type in (2,4,6)order by afu2.ID desc ) ';
        $query_stmt     .=   ' left join api_client_acknowledgement ac on ac.JOB_ID = r.Job_Id and ac.ROUND = r.Round and ac.ID IN ( select max( ac2.ID ) from api_client_acknowledgement ac2  ';
        $query_stmt     .=   ' where ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF in (2,4,6) order by ac2.ID desc)';
        }else{
            $processtype    =   "";
            $metaprctype    =   "";
            if($type    ==  "NOTIFICATION"){
                $processtype    =   "2";
                $metaprctype    =   "2";
            }else if($type    ==  "CORRECTION"){
                $processtype    =   "6";
                $metaprctype    =   "5";
            }else{
                $processtype    =   "4";
                $metaprctype    =   "4";
            }
            
            $query_stmt     .=   ' ( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND process_type = '.$metaprctype.'  order by ame2.ID desc ) ';
            $query_stmt     .=   ' left join api_file_upload afu on afu.JOB_ID = r.Job_Id and afu.ROUND = r.Round and afu.ID IN  ';
            $query_stmt     .=   ' ( select max(afu2.ID) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND process_type = '.$processtype.' order by afu2.ID desc ) ';
            $query_stmt     .=   ' left join api_client_acknowledgement ac on ac.JOB_ID = r.Job_Id and ac.ROUND = r.Round and ac.ID IN ( select max( ac2.ID ) from api_client_acknowledgement ac2  ';
            $query_stmt     .=   ' where ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = '.$processtype.' order by ac2.ID desc)';
        }
        $query_stmt     .=  " where ame.PROCESS_TYPE is not null and afu.PROCESS_TYPE is not null and ac.PROCESS_TYPE_DIFF is not null ";
        if(!empty($jobid))
        $query_stmt     .=   ' and ame.JOB_ID = '.$jobid.' group by AMEID,ACKID,AFUID';
        else
        $query_stmt     .=   ' group by AMEID,ACKID,AFUID order by ame.created_at DESC ';
        
        $getRec        =   DB::select( $query_stmt );
        
        return $getRec;
        
    }
    
   public function getmovetowomatsignallist( $pageno = null,$limit = null,$type = null,$jobid = null,$metaid = null){
        
      
       $query_stmt      = 'select j.BOOK_ID, tm.ROUND,rm.NAME, tam.CHAPTER_NO, tm.`STATUS`, tm.CREATED_DATE from taps_metadata as tm 
            join job as j on tm.JOB_ID = j.JOB_ID
            left join task_level_metadata as tam on tm.METADATA_ID = tam.METADATA_ID
            join round_enum as rm on rm.ID = tm.ROUND';
           
       
       if(!empty($jobid))
            $query_stmt     .=   ' where j.JOB_ID = '.$jobid. '';
		
		 if(!empty($type))
            $query_stmt     .=   ' AND tm.WOMAT_TYPE = '.$type. '';
       
       // $query_stmt         .= ' group by tm.METADATA_ID';
	   
	   $query_stmt         .= ' order by tm.CREATED_DATE DESC';
       
        $getRec        =   DB::select( $query_stmt );
        
        return $getRec;
        
    }
    
}

