<?php 

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;

class checkItemsModel extends Model {
    
    protected $table 	= 	'check_items';
    public $primaryKey 	= 	'ID';
    public $timestamps 	= 	true;
    protected $fillable = 	['CREATED_DATE'];

    public static function getCheckItemsList($jobid) 
	{
		$checkItemsList 		= 	[];
		try 
		{
			$checkItemsList = 	checkItemsModel::select('check_items.*','check_items_project.PROJECT_ID',
										'check_items_project.CHECK_ITEM_ID',
										'check_items_project.OK_DATA',
										'check_items_project.PROBLEM_DATA',
										'check_items_project.QUICK_INFO_DATA',
										DB::raw('IF(TYPE = "INTAKE", 1, 0) AS TYPE_ID'))
										->join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items_project.PROJECT_ID',$jobid)										
										->get();            
        } 
		catch( \Exception $e ) 
		{
			logger($e->getMessage());
            return false;
        }
        return $checkItemsList;
    }
	
	public static function getCheckItemsParentList($jobid) 
	{
		$checkItemsParentList = [];
		try 
		{
            $checkItemsParentList 	= 	checkItemsModel::select('check_items.*')
										->join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items_project.PROJECT_ID',$jobid)
										->where('check_items.IS_PARENT', 1)
										->get();            
        } 
		catch( \Exception $e ) 
		{
			logger($e->getMessage());
            return false;
        }
        return $checkItemsParentList;
    }
    
	public static function addCheckItem($inpArr = [],$job 	= 	null,$checkItemquickinfo = null) 
	{
		$inpArr['CREATED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['CREATED_BY'] 	= 	\Session::get('users')['user_id'];
		$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
		$insertid 				=	DB::table('check_items')->insertGetId($inpArr);
		$checkitempro 			=	array('CHECK_ITEM_ID'=>$insertid,
											'PROJECT_ID'=>$job,
											'OK_DATA'=>true,
											'QUICK_INFO_DATA'=>$checkItemquickinfo,
											'MODIFIED_AT'=>date('Y-m-d H:i:s'),
											'CREATED_BY'=>\Session::get('users')['user_id'],
											'MODIFIED_BY'=>\Session::get('users')['user_id']
										);
		//insert in check items projects
		return DB::table('check_items_project')->insert($checkitempro);
	}
	
	public static function addprojectCheckItemOthers($inpArr = [],$job 	= 	[]) 
	{
		$inpArr['CREATED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['CREATED_BY'] 	= 	\Session::get('users')['user_id'];
		$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
		$insertid 				=	DB::table('check_items')->insertGetId($inpArr);
		$checkitempro 			=	array('CHECK_ITEM_ID'=>$insertid,'PROJECT_ID'=>$job['PROJECT_ID'],
											'OK_DATA'=>$job['OK_DATA'],
											'PROBLEM_DATA'=>$job['PROBLEM_DATA'],
											'QUICK_INFO_DATA'=>$job['QUICK_INFO_DATA'],
											'MODIFIED_AT'=>date('Y-m-d H:i:s'),
											'CREATED_BY'=>\Session::get('users')['user_id'],
											'MODIFIED_BY'=>\Session::get('users')['user_id']
										);
		//insert in check items projects
		return DB::table('check_items_project')->insert($checkitempro);
	}
	public static function editCheckItem($inpArr = [],$checkItemquickinfo = null) 
	{
		$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
		$updatecheckitems 		=	DB::table('check_items')->where('ID', $inpArr['ID'])->update($inpArr);
		if($updatecheckitems >=	1)
		{
			$updateproject 		=	array('MODIFIED_AT'=>date('Y-m-d H:i:s'),'MODIFIED_BY'=>\Session::get('users')['user_id'],
											'QUICK_INFO_DATA'=>$checkItemquickinfo);
			return DB::table('check_items_project')->where('CHECK_ITEM_ID', $inpArr['ID'])->update($updateproject);
		}
		return $updatecheckitems;
	}
	
	public static function checkItemExist($title = null,$jobid) 
	{
		$existcheckitems 	= 	checkItemsModel::join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items.TITLE',$title)
										->where('check_items.IS_PARENT',true)
										->where('check_items.STATUS',true)
										->where('check_items_project.PROJECT_ID',$jobid)
										->first();     
		return $existcheckitems;
	}
	public static function checkItemExistItemid($id=null,$title = null,$jobid) 
	{
		$existcheckitems 	= 	checkItemsModel::join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items.TITLE',$title)
										->where('check_items.ID', '!=',$id)
										->where('check_items.IS_PARENT',true)
										->where('check_items.STATUS',true)
										->where('check_items_project.PROJECT_ID',$jobid)
										->first();     
		return $existcheckitems;
	}
	
	public static function updateProjectCheckItem($inpArr = [],$jobid = null) 
	{
		$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
		$updatecheckitems 		=	DB::table('check_items_project')->where('CHECK_ITEM_ID', $inpArr['CHECK_ITEM_ID'])->update($inpArr);
		if($updatecheckitems >=	1)
		{
			$updateproject 		=	array('MODIFIED_AT'=>date('Y-m-d H:i:s'),'MODIFIED_BY'=>\Session::get('users')['user_id']);
			return DB::table('check_items')->where('ID', $inpArr['CHECK_ITEM_ID'])->update($updateproject);
		}
		return $updatecheckitems;
	}
	public static function deleteCheckItem($ID = null)
	{        
        $response 	= 	checkItemsModel::where('ID', $ID)->delete();
		if($response)
		{
			$response 	= 	DB::table('check_items_project')->where('CHECK_ITEM_ID', $ID)->delete();
		}
        return $response;
    }
    
	public static function deleteProjectCheckItem($inpArr = [],$jobid = null) 
	{
		$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
		$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
		$updatecheckitems 		=	DB::table('check_items_project')->where('CHECK_ITEM_ID', $inpArr['CHECK_ITEM_ID'])->update($inpArr);
		if($updatecheckitems >=	1)
		{
			$updateproject 		=	array('MODIFIED_AT'=>date('Y-m-d H:i:s'),'MODIFIED_BY'=>\Session::get('users')['user_id']);
			return DB::table('check_items')->where('ID', $inpArr['CHECK_ITEM_ID'])->update($updateproject);
		}
		return $updatecheckitems;
	}
	
	public static function getCheckOthersItems($jobid) 
	{
		$checkItemsList 		= 	[];
		try 
		{
			$checkItemsList = 	checkItemsModel::join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items.TITLE',$jobid['TITLE'])
										->where('check_items_project.PROJECT_ID',$jobid['PROJECT_ID'])->get()->toArray();            
        } 
		catch( \Exception $e ) 
		{
			logger($e->getMessage());
            return false;
        }
        return $checkItemsList;
    }
	
    public static function getProject($projectId = 0) 
	{
		return 	DB::table('job')->select('job.*','job_info.JOURNAL_ACRONYM',
												'job_info.DOI',
												'job_info.EES_ACRONYM',
												'job_info.ISSN_ONLINE',
												'job_info.ISSN_PRINT',
												'job_info.AUTHOR_NAME',
												'job_info.AUTHOR_EMAIL')
										->join('job_info','job_info.JOB_ID','=','job.JOB_ID')
										->where('job.JOB_ID', $projectId)
										->first();
	}
	
	public static function getCheckItemsParent($jobid = null) 
	{
		$checkItemsParentList = [];
		try {
			$checkItemsParentList = 	checkItemsModel::select('check_items.*')
								->Join('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
								->where('check_items_project.PROJECT_ID',$jobid)
								->where('check_items.IS_PARENT', 1)
								->get()
								->toArray();
        } 
		catch( \Exception $e ) 
		{
			logger($e->getMessage());
            return false;
        }
        return $checkItemsParentList;
    }
	
	public static function getCheckItemsChildren($parentId = 0, $jobid = null) 
	{
		$checkItemsChildrenList = [];
		try 
		{
			$checkItemsChildrenList = 	checkItemsModel::select('check_items.*','check_items_project.CHECK_ITEM_ID','check_items_project.PROJECT_ID',
											'check_items_project.OK_DATA',
											'check_items_project.PROBLEM_DATA',
											'check_items_project.QUICK_INFO_DATA')
										->leftjoin('check_items_project', 'check_items_project.CHECK_ITEM_ID', '=', 'check_items.ID')
										->where('check_items_project.PROJECT_ID',$jobid)
										->where('check_items.PARENT_ID', $parentId)
										->where('check_items.IS_PARENT', 0)
										->get()
										->toArray(); 
        } 
		catch( \Exception $e ) 
		{
			logger($e->getMessage());
            return false;
        }
        return $checkItemsChildrenList;
    }
	
	public static function saveProjectCheckItems($inpArr = []) {
		$cIChildren 	= 	self::getCheckItemsChildren(0, true);

		$insArr = [];
		$insArr['CREATED_AT'] = date('Y-m-d H:i:s');
		$insArr['CREATED_BY'] = \Session::get('users')['user_id'];
		$insArr['MODIFIED_AT'] = date('Y-m-d H:i:s');
		$insArr['MODIFIED_BY'] = \Session::get('users')['user_id'];

		if(!empty($cIChildren)) {
			foreach($cIChildren as $cIItem) {
				$insArr['CHECK_ITEM_ID'] = $cIItem->ID;
				$insArr['PROJECT_ID'] = $inpArr['projectId'];
				$insArr['OK_DATA'] = $inpArr['projCheckItemOk_' . $cIItem->PARENT_ID.'_'.$cIItem->ID];
				$insArr['PROBLEM_DATA'] = $inpArr['projCheckItemProblem_' . $cIItem->PARENT_ID.'_'.$cIItem->ID];
				$insArr['QUICK_INFO_DATA'] = $inpArr['projCheckItemQuickInfo_' . $cIItem->PARENT_ID.'_'.$cIItem->ID];
				
				if($inpArr['projCheckItemHidden_' . $cIItem->PARENT_ID.'_'.$cIItem->ID] != '') {
					DB::table('check_items_project')
						->where('ID', $inpArr['projCheckItemHidden_' . $cIItem->PARENT_ID.'_'.$cIItem->ID])
						->update($insArr);
				} else {
					DB::table('check_items_project')
					->insert($insArr);
				}
				
			}
		}
		
		// Handle the others data
		$insArr2 = [];
		$insArr2['CREATED_AT'] = date('Y-m-d H:i:s');
		$insArr2['CREATED_BY'] = \Session::get('users')['user_id'];
		$insArr2['MODIFIED_AT'] = date('Y-m-d H:i:s');
		$insArr2['MODIFIED_BY'] = \Session::get('users')['user_id'];
		$insArr2['CHECK_ITEM_ID'] = 0;
		$insArr2['PROJECT_ID'] = $inpArr['projectId'];
		$insArr2['OK_DATA'] = 0;
		$insArr2['PROBLEM_DATA'] = $inpArr['projCheckItemProblem_Others'];
		$insArr2['QUICK_INFO_DATA'] = $inpArr['projCheckItemQuickInfo_Others'];
		
		if($inpArr['projCheckItemHidden_Others']) {
			DB::table('check_items_project')
				->where('ID', $inpArr['projCheckItemHidden_Others'])
				->update($insArr2);
		} else {
			DB::table('check_items_project')
				->insert($insArr2);
		}

	}
	
	public static function getCheckItemsProject($projectId = 0) 
	{
		$checkItemsProjectData = [];
		try 
		{
            $checkItemsProjectData 	= 	DB::table('check_items_project')
											->where('PROJECT_ID', $projectId);
			$checkItemsProjectData 	= 	$checkItemsProjectData->get()->toArray();
        } catch( \Exception $e ) {
			logger($e->getMessage());
            return false;
        }
        return $checkItemsProjectData;
	}
	
	public static function saveProjectCheckItemsAll($checkitemsid =	[],$projCheckItem = [],$checkitemsproblem = []) 
	{
		if(count($checkitemsid)>=1)
		{
			$inpArr 	=	array();
			foreach($checkitemsid as $key=>$val)
			{
				$inpArr['MODIFIED_AT'] 	= 	date('Y-m-d H:i:s');
				$inpArr['MODIFIED_BY'] 	= 	\Session::get('users')['user_id'];
				$inpArr['OK_DATA'] 		= 	$projCheckItem[$val];
				$inpArr['PROBLEM_DATA'] = 	$checkitemsproblem[$val];
				//$inpArr['QUICK_INFO_DATA'] = 	$checkitemsinfo[$val];
				$updatecheckitems 		=	DB::table('check_items_project')->where('CHECK_ITEM_ID', $val)->update($inpArr);
				if($updatecheckitems >=	1)
				{
                                    $updateproject 		=	array('MODIFIED_AT'=>date('Y-m-d H:i:s'),'MODIFIED_BY'=>\Session::get('users')['user_id']);
                                    DB::table('check_items')->where('ID', $val)->update($updateproject);
				}
				unset($inpArr);
			}
			return $updatecheckitems;
		}
		return false;
	}
}

