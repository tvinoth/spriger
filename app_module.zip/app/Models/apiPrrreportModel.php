<?php
namespace App\Models;
use App\Models\apiFileUpload;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiPrrreportModel extends Model {
    
    protected $table 	= 	'api_prr_report';
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $randomtoken  =   "";
            do
            {
                $randomtoken 	=   str_random(10);
                $tokenexist 	=   apiPrrreportModel::where('TOKEN',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $data['TOKEN']  =   $randomtoken;
            $spicastadd     =   apiPrrreportModel::insertGetId($data);
            
            if($spicastadd >=1)
            {
                $spicastadd  =   apiPrrreportModel::where('ID',$spicastadd)->first();
            }
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
}
