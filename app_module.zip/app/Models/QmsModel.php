<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class QmsModel extends Model {

      
    
   public static function getTeamIdByUser($userId){
        
      $contact_info   =       array();
        $tblname        =       'user_team_map as utm';
        
        try{
            $select_field   =       array( 't.SUB_CIRCLE');
            $contact_info   =       DB::table( $tblname )
                                    ->select( $select_field )
                                    ->Join( 'team as t' , 't.TEAM_ID', '=', 'utm.TEAM_ID')           
                                    ->Where( 'utm.USER_ID', '=' , $userId )
                                    ->get();            
            
       }catch( \Exception $e ){           
            return false;
       }
        
        return $contact_info;     
    }
    
    public static function getUserDetailByTeam($subcircle,$team){
        
      $contact_info   =       array();
        $tblname        =       'sub_circle as sc';
        
        try{
        DB::enableQueryLog();
            $select_field   =       array( 'u.USER_ID','u.EMAIL','u.FIRST_NAME','u.LAST_NAME');
            $contact_info   =       DB::table( $tblname )
                                    ->select( $select_field )
                                    ->Join( 'team as t' , 't.SUB_CIRCLE', '=', 'sc.SUB_CIRCLE_ID')
                                    ->Join( 'user as u' , 'u.USER_ID', '=', 't.TEAM_HEAD') 
                                    ->Where( 'sc.SUB_CIRCLE_ID', '=' , $subcircle )
                                    ->groupby('t.TEAM_HEAD')
                                    ->get();  
		$res = DB::getQueryLog($contact_info);
		//print_r($res);
     
      }catch( \Exception $e ){           
            return false;
       }
     
        return $contact_info;     
    }
    
	
	public static function getUserDetailByTeamTemp($subcircle,$team){
        
      $contact_info   =       array();
        $tblname        =       'user as u';
        
        try{
       // DB::enableQueryLog();
            $select_field   =       array( 'u.USER_ID','u.EMAIL','u.FIRST_NAME','u.LAST_NAME');
            $contact_info   =       DB::table( $tblname )
                                    ->select( $select_field )
                                    ->WhereIn( 'u.role', array(12) )
                                    ->get();  
		//$res = DB::getQueryLog($contact_info);
		//print_r($res);
     
      }catch( \Exception $e ){           
            return false;
       }
     
        return $contact_info;     
    }
    
    
    
    
    
}
