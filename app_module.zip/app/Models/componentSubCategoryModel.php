<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;

class componentSubCategoryModel extends Model 
{
    protected $table        =   'component_sub_category';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_DATE";
    const CREATED_AT        =   "CREATED_DATE";
	
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
    
    public function scopePromotionactive($query)
    {
        return $query->where('PROMOTION_IS_ACTIVE', 1);
    }
    
    
    
//    public function pathInfo() {
//        return $this->hasOne('App\Models\requiredConstants','ID','REQUIRED_CONSTANT_ID')
//                ->select(DB::raw('required_constants.CONSTANT_NAME,required_constants.CONSTANT_VALUE'));
//    }
}

