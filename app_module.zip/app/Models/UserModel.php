<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class UserModel extends Model {

    // 
    protected $table = 'user';
    public $primaryKey = 'USER_ID';
    public $timestamps = false;
    const UPDATED_AT        =   "LAST_MOD_DATE";

	//protected $fillable = array('CreatedAt');
    
    /**
     * 
     * @param type $userID = USER_ID - user table
     * @return type
     */
//    public static function verifyLogin($arrData){
//
//        $UserDetails = DB::table('user_credential as a')
//        ->join('user_credential as b', 'b.INTERNAL_USER_ID', '=', 'a.USER_ID' )
//        ->join('ROLE_ENUM as c', 'c.ID', '=', 'a.ROLE')
//        ->where('b.LOGIN_ID', $arrData['user_name'])
//        ->where('b.PASSWORD', $arrData['password'])
//        ->where('a.IS_ACTIVE', $arrData['is_active'])
//        ->select(DB::raw('a.EMPLOYEE_ID,a.USER_ID, a.FIRST_NAME,a.LAST_NAME ,a.ROLE, c.ID, c.NAME'))
//        ->get();
//        return $UserDetails;
//
//    }
    
     public static function verifyLogin($whereData){

        $UserDetails = DB::table('user as a')
        ->join('user_credential as b', 'b.INTERNAL_USER_ID', '=', 'a.USER_ID' )
        ->join('role_enum as c', 'c.ID', '=', 'a.ROLE')
        ->where($whereData)
        ->select(DB::raw('a.EMPLOYEE_ID as employee_code, a.USER_ID as user_id, a.FIRST_NAME as first_name, a.LAST_NAME as last_name, a.ROLE as role_id,c.ID, c.NAME as role_name'))
        ->get();
        
        return $UserDetails;

    }
    
    public static function getTeam($arrData){
       $query = "CALL Proc_GetTeam('".$arrData['user_id']."')";  
       $teamList = DB::select($query);
       return $teamList;    
    }
    
//    public static function getMenu($userID) {
//        $menus = DB::table('user AS u')
//                ->join('user_role AS ur', 'ur.USER_ID', '=', 'u.USER_ID')
//                ->join('role_package AS rp', 'rp.ROLE_ID', '=', 'ur.ROLE_ENUM_ID')
//                ->join('transaction_package_item AS tpi', 'tpi.TRANSACTION_PACKAGE_ID', '=', 'rp.TRANSACTION_PACKAGE_ID')
//                ->join('transaction_menu AS tm', 'tm.TRANSACTION_MENU_ID', '=', 'tpi.TRANSACTION_MENU_ID')
//                ->where('u.USER_ID', $userID)
//                ->select(DB::raw('tm.CODE AS NAVIGATION_CODE'))
//                ->get();
//
//        $menuArray = [];
//        foreach ($menus as $m) {
//            $menuArray[] = $m->NAVIGATION_CODE;
//        }
//
//        return $menuArray;
//    }
    
    public static function getMenu($userID) {
        $menus = DB::table('user AS u')
               // ->join('user_role AS ur', 'ur.USER_ID', '=', 'u.USER_ID')
                ->join('role_package AS rp', 'rp.ROLE_ID', '=', 'u.ROLE')
                ->join('transaction_package_item AS tpi', 'tpi.TRANSACTION_PACKAGE_ID', '=', 'rp.TRANSACTION_PACKAGE_ID')
                ->join('transaction_menu AS tm', 'tm.TRANSACTION_MENU_ID', '=', 'tpi.TRANSACTION_MENU_ID')
                ->rightJoin('menu AS m', 'tm.code', '=', 'm.menu_code')
                ->where('u.USER_ID', $userID)
                ->where('m.is_active', 1)
                ->select(DB::raw('tm.CODE AS NAVIGATION_CODE, m.menu_name, m.menu_link, m.depth'))
                //->get();
                ->toSql();
         return $menus;        
       
    }
    
    public static function getUserDetails($userID) {
        $UserDetails = DB::table('user AS u')
                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
                ->where('u.USER_ID', $userID)
                ->select(DB::raw('u.FIRST_NAME, u.LAST_NAME, r.ID as ROLE_ID, r.NAME as ROLE_NAME'))
                ->first();
        return $UserDetails;
    }
    

//    public static function getUserDetails($userID) {
//        $UserDetails = DB::table('user AS u')
//                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
//                ->where('u.USER_ID', $userID)
//                ->select(DB::raw('u.FIRST_NAME, u.LAST_NAME, r.NAME as ROLE_NAME'))
//                ->first();
//        return $UserDetails;
//    }
    
     public static function getUserIdBasedOnEmployeeId($empId) {
        DB::enableQueryLog();
        $UserDetails = DB::table('user AS u')
                ->where( 'u.EMPLOYEE_ID' , '=', $empId)
                ->select( DB::raw( 'u.FIRST_NAME, u.LAST_NAME,  u.USER_ID' ) )
                ->get();
        
        DB::getQueryLog();
       
        return $UserDetails;
        
    }
    
    public static function getUserTeamDetails($userID) {
        $UserDetails = DB::table('user_team_map AS utm')
                ->join('team AS t', 'utm.team_id', '=', 't.team_id')
                ->where('utm.USER_ID', $userID)
                ->select(DB::raw('utm.team_id as departmentId, t.SUB_CIRCLE as TeamId'))
                ->first();
        return $UserDetails;
    }   

//    public static function getUserSearchBasedOnRole($roleid) {
//        
//        echo $roleid;exit;
//       DB::enableQueryLog();
//        $UserDetails = DB::table('user AS u')
//                ->join('role_enum AS r', 'u.ROLE', '=', 'r.ID')
//                ->where( 'ROLE' , 'LIKE', '%'.$roleid.'%')
//                ->select( DB::raw( 'u.FIRST_NAME, u.LAST_NAME, r.NAME as ROLE_NAME , u.USER_ID' ) )
//                ->get();
//        DB::getQueryLog();
//        return $UserDetails;
//        
//    }
    
    

}
