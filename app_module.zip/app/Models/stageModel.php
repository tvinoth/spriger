<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class stageModel extends Model {
    
    protected $table    =   'stage';
    public  $primaryKey =   'STAGE_ID';
   
    public static function getAllStageInfo( $field_arr = array() , $whereCondion = array() ){        
        
        if( !empty( $field_arr ) ){
            //yet to do for where condition
            $round_arr      =       stageModel::select( $field_arr )->where('IS_ACTIVE',true)->get();
        }else{
            $round_arr      =       stageModel::where('IS_ACTIVE',true)->get();
        }
        
        return $round_arr;
      
    }
    
    public static function getStageInfoByStageId( $stgid ){
        
        $getRec       =         DB::table('stage as stg')
                                    ->where('STAGE_ID', '=', $stgid )
                                    ->where('IS_ACTIVE', '=', '1' )
                                    ->get()->first();
      
        return $getRec;
      
    }
	
	public function scopeActive($query){
        return $query->where('IS_ACTIVE',true);
    }
	
}

