<?php
namespace App\Models;
use App\Models\api_production_file_transfer;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiProductionFileTransfer extends Model {
    
    protected $table = 'api_production_file_transfer';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiProductionFileTransfer();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function insertRecord( $inp_arr ){
        $insert_r       =   false;
        $api_obj        =       new apiProductionFileTransfer();
        $insert_r       =       $api_obj->insertGetId($inp_arr);
        return $insert_r;
    }
    
    
        
    public static function updateIfExist( $inpArr  , $rowid ){
       
        /*
         * $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                           );
        */
        
        $setArr     =   $inpArr;
        
        $updateQry  =   DB::table('api_production_file_transfer')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByBookid( $bookid , $round ){
        
         $getRec       =         DB::table('api_production_file_transfer as pft')
                                            ->where('BOOK_ID', '=', $bookid)
                                            ->where('ROUND', '=', $round )                                            
              ->orderBy('pft.ID', 'desc')
              ->get()->first();
      
      return $getRec;
      
    }
    
    public function getApiRequest( $jobid , $round , $token = null ){
        
        if( is_null( $token ) ){
            $getRec       =         DB::table('api_production_file_transfer as pft')
                                            ->where('JOB_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )                                            
                                            ->where('STATUS', '=', 1 )                                            
              ->orderBy('pft.ID', 'desc')
              ->get()->first();
        }else{         
            $getRec       =         DB::table('api_production_file_transfer as pft')
                                            ->where('JOB_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )                                            
                                            ->where('TOKEN_KEY', '=', $token )   
                                            ->where('STATUS', '=', 1 )
              ->orderBy('pft.ID', 'desc')
              ->get()->first();
        }
       
      return $getRec;
      
    }
    
    /*
     * Condition arr parameters are :
     * ( token_key || user id )  and proces name
     */
    
    public function hasInProgressActivity( $jobid  = null , $round = null , $condi_arr ){
        
        DB::enableQueryLog();
        
        if( empty( $condi_arr ) ){
         
            $getRec       =         DB::table('api_production_file_transfer as pft')
                                            ->where('JOB_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )
                                            ->where('STATUS', '=' , '' )
                                            ->where('IS_ACTIVE', '<>', 0 )
                                            ->orderBy('pft.ID', 'desc')
                                            ->get()->first();
        
        }else{
            
            $query = DB::table('api_production_file_transfer as pft');
            
//            foreach($condi_arr as $column => $value)
//            {
//              $query->where($column, '=', $value);
//            }
            $query->where($condi_arr);
            $query->where('JOB_ID', '=', $jobid );
            $query->where('ROUND', '=', $round );
            $query->where('STATUS', '=' , NULL );
            $query->where('IS_ACTIVE', '<>', 0 );
            $query->orderBy('pft.ID', 'desc');
                            
            $getRec = $query->get()->first();
            
        }
        
        $qr     =       DB::getQueryLog();  
        
        return $getRec;
         
    }
    
}
