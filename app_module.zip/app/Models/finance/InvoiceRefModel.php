<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class InvoiceRefModel extends Model {

    protected $table = 'fin_invoice_ref';
    public $primaryKey = 'INVOICE_REF_ID';
    public $timestamps = false;
    protected $fillable = array('INVOICE_REF_ID', 'AUTHOR');

   

}
