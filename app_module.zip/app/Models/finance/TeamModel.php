<?php

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class TeamModel extends Model {

    // 
    protected $table = 'team';
    public $primaryKey = 'TEAM_ID';
    public $timestamps = false;


}
