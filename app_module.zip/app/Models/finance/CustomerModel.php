<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class CustomerModel extends Model {

    protected $table = 'customer';
    public $primaryKey = 'CUSTOMER_ID';
    public $timestamps = false;
    protected $fillable = array('CUSTOMER_ID', 'CUSTOMER_NAME');

    public static function getData($select = ['customer.*'], $where = '') {
//        DB::enableQueryLog();
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                ->where('IS_ACTIVE', 1)
                ->orderBy('CUSTOMER_ID', 'ASC')
                ->select($select)
                ->get();
//        $queryChk = DB::getQueryLog();
        return $query;
    }

}
