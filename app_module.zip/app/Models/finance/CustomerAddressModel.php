<?php 

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class CustomerAddressModel extends Model {
    
    protected $table    =   'customer_address';
    public $primaryKey  =   'CUSTOMER_ADDRESS_ID';
    public $timestamps  =   false;
    protected $fillable =   array('CUSTOMER_ADDRESS_ID','CUSTOMER_ID');
    
    
    
//    function clientName() {
//        return $this->belongsTo('App\Models\finance\CustomerModel', 'CUSTOMER_ID', 'CUSTOMER_ID')->select('CUSTOMER_ID', 'CUSTOMER_NAME');
//    }
    
//    function country() {
//        return $this->belongsTo('App\Models\finance\CurrencyEnumModel', 'ID', 'COUNTRY')->select('ID', 'NAME');
//    }
    
}

