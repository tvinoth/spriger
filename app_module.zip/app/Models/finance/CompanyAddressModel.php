<?php 

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class CompanyAddressModel extends Model {
    
    protected $table    =   'fin_company_address';
    public $primaryKey  =   'COMPANY_ADDRESS_ID';
    public $timestamps  =   false;
    protected $fillable =   array('COMPANY_ADDRESS_ID','COMPANY_NAME');

}

