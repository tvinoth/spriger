<?php 
namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class InvoiceApprovalLogModel extends Model {
    
       protected $table = 'fin_invoice_approval_log';
       public $primaryKey = 'INVOICE_APPROVAL_LOG_ID';
       public $timestamps = false;
       
   

}