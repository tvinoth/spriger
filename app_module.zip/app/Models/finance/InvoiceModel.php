<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class InvoiceModel extends Model {

    protected $table = 'fin_invoice';
    public $primaryKey = 'INVOICE_ID';
    public $timestamps = false;
    protected $fillable = array('INVOICE_ID', 'INVOICE_TITLE');

    public function InvoiceItems() {
        return $this->hasMany('App\Models\finance\InvoiceItemsModel', 'INVOICE_ID', 'INVOICE_ID');
    }

    public function InvoiceRef() {
        return $this->hasOne('App\Models\finance\InvoiceRefModel', 'INVOICE_ID', 'INVOICE_ID');
    }

    public function project() {
        return $this->hasOne('App\Models\finance\JobModel', 'JOB_ID', 'JOB_ID')->select('JOB_ID', 'JOB_TITLE', 'JOB_REF', 'BOOK_ID');
    }

    public function Customer() {
        return $this->hasOne('App\Models\finance\CustomerModel', 'CUSTOMER_ID', 'CLIENT_ID');
    }

    public function CustomerDivision() {
        return $this->hasOne('App\Models\finance\CustomerDivisionModel', 'CUSTOMER_DIVISION_ID', 'CLIENT_DIVISION_ID');
    }
    public function InvoiceAccountCode() {
        return $this->hasMany('App\Models\finance\InvoiceAccountCodeModel', 'INVOICE_ID', 'INVOICE_ID');
    }

    function customerBillingAddress() {

        $select = array('customer_address.CUSTOMER_ID',
            'customer_address.CONTACT_NAME',
            'customer_address.ADDRESS_LINE_1',
            'customer_address.ADDRESS_LINE_2',
            'customer_address.ADDRESS_LINE_3',
            'customer_address.CITY',
            'customer_address.STATE',
            'customer_address.COUNTRY',
            'customer_address.ZIP',
            'customer_address.PHONE',
            'customer_address.CUSTOMER_ADDRESS_ID',
            DB::raw('c.NAME AS COUNTRY_NAME')
        );

        return $this->hasMany('App\Models\finance\CustomerAddressModel', 'CUSTOMER_ID', 'CLIENT_ID')
                        ->join('country_enum AS c', 'c.ID', '=', 'customer_address.COUNTRY')
                        ->where('customer_address.CUST_ADDR_TYPE', 1)
                        ->where('customer_address.IS_ACTIVE', 1)
                        ->select($select);
    }
    
    function InvoiceBillingAddress() {
        return $this->hasOne('App\Models\finance\InvoiceBillingAddressModel', 'INVOICE_ID', 'INVOICE_ID')
                        ->join('country_enum AS c', 'c.ID', '=', 'fin_invoice_billing_address.COUNTRY');
    }

    public function Currency() {
        return $this->hasOne('App\Models\finance\CurrencyEnumModel', 'ID', 'CURRENCY_ID');
    }

    public function cluster() {
        return $this->hasOne('App\Models\finance\ClusterModel', 'SUB_CIRCLE_ID', 'CLUSTER_ID')->select('SUB_CIRCLE_ID', 'SUB_CIRCLE_NAME');
    }

    public function team() {
        return $this->hasOne('App\Models\finance\TeamModel', 'TEAM_ID', 'TEAM_ID')->select('TEAM_ID', 'TEAM_NAME');
    }

    public function invoiceStatus() {
        return $this->hasOne('App\Models\finance\InvoiceApprovalModel', 'REQUEST_LEVEL_ID', 'CURRENT_STATUS');
    }

    public function invoiceStatusName() {
        return $this->hasOne('App\Models\finance\InvoiceApprovalModel', 'REQUEST_LEVEL_ID', 'CURRENT_STATUS')->select(array('fin_request_level.LEVEL_NAME', 'fin_request_level.REQUEST_LEVEL_ID'));
    }

    public function approvalLog() {
        return $this->hasMany('App\Models\finance\InvoiceApprovalLogModel', 'INVOICE_ID', 'INVOICE_ID')
                        ->join('fin_request_level', 'fin_request_level.REQUEST_LEVEL_ID', '=', 'fin_invoice_approval_log.REQUEST_LEVEL_ID')
                        ->join('user', 'user.USER_ID', '=', 'fin_invoice_approval_log.USER_ID')
                        ->select(array('fin_request_level.LEVEL_NAME', 'INVOICE_ID', 'fin_invoice_approval_log.REMARKS', 'IS_APPROVE', 'fin_invoice_approval_log.REQUEST_LEVEL_ID', 'fin_invoice_approval_log.CREATED_DATE', 'user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME')));
    }

    public function createdBy() {
        return $this->hasOne('App\Models\finance\UserModel', 'USER_ID', 'CREATED_BY')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME')));
    }

    public function updatedBy() {
        return $this->hasOne('App\Models\finance\UserModel', 'USER_ID', 'LAST_MOD_BY')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME')));
    }

    public function holdBy() {
        return $this->hasOne('App\Models\finance\UserModel', 'USER_ID', 'HOLD_BY')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME')));
    }

    public function cancelledBy() {
        return $this->hasOne('App\Models\finance\UserModel', 'USER_ID', 'CANCELLED_BY')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME')));
    }
	
	public function serviceItems() {
        return $this->hasOne('App\Models\finance\ServiceItemsModel', 'ITEM_CODE', 'ITEM_CODE')->select('ITEM_DISPLAY_NAME');
    }

}
