<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class UnitEnumModel extends Model {

    //protected $connection = 'mysql2'; // this will use the specified database connection (DB::connection('mysql2');)
    protected $table = 'fin_unit_enum'; //->table((new static)->getTable())
    public $primaryKey = 'UNIT_ENUM_ID';
    public $timestamps = false;

    //protected $fillable = array('CreatedAt');   

    public static function getData($select = ['fin_unit_enum.*'], $where = '') {
        DB::enableQueryLog();
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                //->where('IS_ACTIVE',1)
                ->orderBy('UNIT_ENUM_ID', 'ASC')
                ->select($select)
                ->get();
        /* if(!empty($select)){
          $query->select($select);
          } */
        $queryChk = DB::getQueryLog();
        //echo $queryChk;
        return $query;
    }

    public static function insertData($data = array()) {
        if (count($data) > 0) {
            $id = DB::table((new static)->getTable())->insert($data);

            return $id;
        }
        return 0;
    }

    public static function updateData($data = array(), $where = array()) {
        if (count($data) > 0) {
            $affectedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->update($data);

            return $affectedRows;
        }
        return 0;
    }

    public static function deleteData($where = array()) {
        if (count($where) > 0) {
            $deletedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->delete();

            return $deletedRows;
        }
        return 0;
    }

}
