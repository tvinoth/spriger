<?php namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class HelperModel extends Model
{
	public static function get_encrypt($value){
        return rtrim(base64_encode($value),'=');
    }
               
    public static function get_decrypt($enc_value){
        return base64_decode( $enc_value.str_repeat('=', strlen($enc_value) % 4));                          
	}    
}
