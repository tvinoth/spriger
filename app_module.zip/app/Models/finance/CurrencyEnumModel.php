<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class CurrencyEnumModel extends Model {

    protected $table = 'currency_enum';
    public $primaryKey = 'ID';
    public $timestamps = false;
    protected $fillable = array('ID', 'NAME');

    public static function getData($select = ['currency_enum.*'], $where = '') {
//        DB::enableQueryLog();
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                ->where('IS_ACTIVE', 1)
                ->orderBy('ID', 'ASC')
                ->select($select)
                ->get();
//        $queryChk = DB::getQueryLog();
        return $query;
    }

}
