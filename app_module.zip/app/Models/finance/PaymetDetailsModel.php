<?php 

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class PaymetDetailsModel extends Model {
    
    protected $table    =   'fin_payment_address';
    public $primaryKey  =   'PAYMENT_ADDRESS_ID';
    public $timestamps  =   false;
    protected $fillable =   array('PAYMENT_ADDRESS_ID','PAYMENT_INFO_LABEL','PAYMENT_INFO_NAME');
    
    

}

