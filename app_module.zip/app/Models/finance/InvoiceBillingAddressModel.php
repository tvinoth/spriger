<?php 

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class InvoiceBillingAddressModel extends Model
{
    // 
       protected $table = 'fin_invoice_billing_address';
       public $primaryKey = 'AUTO_ID';
       public $timestamps = false;
       
       
       public function clientName()
       {
            return $this->hasOne('App\Models\CustomerModel','CUSTOMER_ID','CUSTOMER_ID')
                     ->select(DB::raw('CUSTOMER_NAME,CUSTOMER_ID')); 
       }
       public function country()
       {
            return $this->hasOne('App\Models\CountryEnumModel','ID','COUNTRY'); 
       }
    
}


