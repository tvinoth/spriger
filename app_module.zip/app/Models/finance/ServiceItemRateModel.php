<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class ServiceItemRateModel extends Model {

    // 
    protected $table = 'fin_service_item_rate';
    public $primaryKey = 'SERVICE_ITEM_RATE_ID';
    public $timestamps = false;

    //protected $fillable = array('CreatedAt');     

    public static function getData($select = ['fin_service_item_rate.*'], $where = '', $date = '') {
        DB::enableQueryLog();
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                ->where(function ($query) use ($date) {
                    if ($date != '') {
                        $query->whereRaw('"' . $date . '" between `START_DATE` and `END_DATE`');
                    }
                })
                //->where('IS_ACTIVE',1)
                ->orderBy('SERVICE_ITEM_RATE_ID', 'ASC')
                ->select($select)
                ->get();
        $queryChk = DB::getQueryLog();
        //print_r($queryChk);
        return $query;
    }

    public static function insertData($data = array()) {
        if (count($data) > 0) {
            $id = DB::table((new static)->getTable())->insert($data);

            return $id;
        }
        return 0;
    }

    public static function updateData($data = array(), $where = array()) {
        if (count($data) > 0) {
            //DB::enableQueryLog();
            $affectedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->update($data);
            //$queryChk = DB::getQueryLog();
            //print_r($queryChk);die;
            return $affectedRows;
        }
        return 0;
    }

    public static function deleteData($where = array()) {
        if (count($where) > 0) {
            $deletedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->delete();

            return $deletedRows;
        }
        return 0;
    }

    public static function generateInsertDataArray($data, $pricingValue, $trimType, $workType, $currencySymbol, $otherColPricingValue) {

        $insertUploadedDocumentItemsData = $data;
        /* if(!empty($pricingValue) && !empty($otherColPricingValue)){
          $insertUploadedDocumentItemsData['PRICING_PER_UNIT'] = trim(str_replace($currencySymbol, "", $pricingValue));
          }else if(!empty($pricingValue) && empty($otherColPricingValue)){
          $insertUploadedDocumentItemsData['PRICING_PER_UNIT'] = trim(str_replace($currencySymbol, "", $pricingValue));
          }else if(empty($pricingValue) && !empty($otherColPricingValue)){
          $insertUploadedDocumentItemsData['PRICING_PER_UNIT'] = trim(str_replace($currencySymbol, "", $otherColPricingValue));
          } */

        if (!empty($pricingValue)) {
            $insertUploadedDocumentItemsData['RATE'] = trim(str_replace($currencySymbol, "", $pricingValue));
        }
        return $insertUploadedDocumentItemsData;
    }

    public function finUploadedDocuments() {
        return $this->hasOne('App\Models\finance\FinUploadedDocumentsModel', 'CUSTOMER_ID', 'CUSTOMER_ID');
    }

}
