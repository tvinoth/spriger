<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class CustomerDivisionModel extends Model {

    protected $table = 'customer_division';
    public $primaryKey = 'CUSTOMER_DIVISION_ID';
    public $timestamps = false;
    protected $fillable = array('CUSTOMER_DIVISION_ID', 'DIVISION_NAME');

    public static function getData($select = ['customer_division.*'], $where = '') {
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                ->where('IS_ACTIVE', 1)
                ->orderBy('CUSTOMER_DIVISION_ID', 'ASC')
                ->select($select)
                ->get();
        return $query;
    }

}
