<?php

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class PrefixEnumModel extends Model {

    // 
    protected $table = 'fin_prefix_enum';
    public $primaryKey = 'PREFIX_ENUM_ID';
    public $timestamps = false;


}
