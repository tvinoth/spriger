<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class InvoiceAccountCodeModel extends Model {

    protected $table = 'fin_invoice_account_code';
    public $primaryKey = 'INVOICE_ACCOUNT_CODE_ID';
    public $timestamps = false;
    protected $fillable = array('INVOICE_ID','CODE_DESCRIPTION','AMOUNT');

   

}
