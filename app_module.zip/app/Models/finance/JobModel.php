<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class JobModel extends Model {

    protected $table = 'job';
    public $primaryKey = 'JOB_ID';
    public $timestamps = false;
    protected $fillable = array('JOB_ID', 'JOB_TITLE');

//    function JobInfo() {
//        return $this->hasOne('App\Models\JobInfoModel', 'JOB_ID', 'JOB_ID');
//    }
//    
    function customerDivision() {
        return $this->hasOne('App\Models\finance\CustomerDivisionModel', 'CUSTOMER_DIVISION_ID', 'CUSTOMER_DIVISION_ID')
                ->join('currency_enum AS c','c.ID','=','customer_division.CURRENCY')
                ->select('customer_division.CUSTOMER_DIVISION_ID', 'customer_division.DIVISION_NAME','customer_division.CURRENCY',
                        DB::raw('c.id AS CURRENCY_ID, CONCAT(c.name," ",c.SYMBOL) AS CURRENCY_NAME')
                        );
    }

    function customer() {
        return $this->hasOne('App\Models\finance\CustomerModel', 'CUSTOMER_ID', 'CUSTOMER_ID')->select('CUSTOMER_ID', 'CUSTOMER_NAME');
    }

    function customerBillingAddress() {
        
        $select = array('customer_address.CUSTOMER_ID',
            'customer_address.CONTACT_NAME',
            'customer_address.ADDRESS_LINE_1',
            'customer_address.ADDRESS_LINE_2',
            'customer_address.ADDRESS_LINE_3',
            'customer_address.CITY',
            'customer_address.STATE',
            'customer_address.COUNTRY',
            'customer_address.ZIP',
            'customer_address.PHONE',
            'customer_address.CUSTOMER_ADDRESS_ID',
            DB::raw('c.NAME AS COUNTRY_NAME')
            );
        
        return $this->hasMany('App\Models\finance\CustomerAddressModel', 'CUSTOMER_ID', 'CUSTOMER_ID')
                ->join('country_enum AS c','c.ID','=','customer_address.COUNTRY')
                ->where('customer_address.CUST_ADDR_TYPE', 1)
                ->where('customer_address.IS_ACTIVE', 1)
                ->select($select);
    }

//
//    function ProjectManager() {
//        return $this->hasOne('App\Models\UserModel', 'USER_ID', 'PM')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME'), 'user.WORK_EMAIL_ID'));
//    }
//
//    function TeamLead() {
//        return $this->hasOne('App\Models\UserModel', 'USER_ID', 'TL')->select(array('user.USER_ID', DB::raw('employeename(user.FIRST_NAME,user.MIDDLE_NAME,user.LAST_NAME) AS NAME'), 'user.WORK_EMAIL_ID'));
//    }
//    function Cluster() {
//        return $this->hasOne('App\Models\ClusterModel', 'SUB_CIRCLE_ID', 'SUB_CIRCLE')->select('SUB_CIRCLE_ID','SUB_CIRCLE_NAME');
//    }
//    function Team() {
//        return $this->hasOne('App\Models\TeamModel', 'TEAM_ID', 'TEAM')->select('TEAM_ID','TEAM_NAME');
//    }
}
