<?php

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class ClusterModel extends Model {

    // 
    protected $table = 'sub_circle';
    public $primaryKey = 'SUB_CIRCLE_ID';
    public $timestamps = false;


}
