<?php namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class InvoiceApprovalModel extends Model
{
       protected $table = 'fin_request_level';
       public $primaryKey = 'REQUEST_LEVEL_ID';
       public $timestamps = false;
       
    public function newQuery($excludeDeleted = true) {
        return parent::newQuery($excludeDeleted)
            ->where(array('REQUEST_MASTER_ID' => 2, 'IS_ACTIVE' => 1)); // 1 = invoice
    }
    
   
  
}
