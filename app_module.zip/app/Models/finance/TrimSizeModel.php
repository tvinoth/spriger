<?php namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class TrimSizeModel extends Model
{
    // 
    protected $table = 'fin_trim_size';
    public $primaryKey = 'TRIM_SIZE_ID';
    public $timestamps = false;
	//protected $fillable = array('CreatedAt');   
	
	public static function getData($select = ['fin_trim_size.*'], $where = '') {
        DB::enableQueryLog();
        $query = DB::table((new static)->getTable())
			->where(function ($query) use ($where) {
                if ($where != '') {
                    $query->where($where);
				}
            })
            //->where('IS_ACTIVE',1)
            ->orderBy('TRIM_SIZE_ID','ASC')
            ->select($select) 
            ->get();
		$queryChk = DB::getQueryLog();
		//echo $queryChk;
        return $query;
        
    }
	
	public static function insertData($data = array()){
		if(count($data) > 0){
			$id = DB::table((new static)->getTable())->insert($data);
			
			return $id;
		}
		return 0;
	}
	
	public static function updateData($data = array(), $where = array()){
		if(count($data) > 0){
			$affectedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                if (!empty($where) || $where != '') {
                    $query->where($where);
				}
            })->update($data);
			
			return $affectedRows;
		}
		return 0;
	}
	
	public static function deleteData($where = array()){
		if(count($where) > 0){
			$deletedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                if (!empty($where) || $where != '') {
                    $query->where($where);
				}
            })->delete();
			
			return $deletedRows;
		}
		return 0;
	}
	
	public static function getTrimSizeValue($str = ""){
		if(!empty($str)){
			$replaceTrimSizeValue = trim(str_replace(array(' x ', ' mm (', ' inch) ', ' inch)', 'until ', ' mmm (', ' inch)'), array('x','_mm_','_inch_','_inch_','_','_mmm_','_inch_'), $str)); 
			$replaceTrimSizeValue = trim(preg_replace('/\s+/', '_', $replaceTrimSizeValue));
			$replaceTrimSizeValue = trim(str_replace('___', '_', $replaceTrimSizeValue));
			
			return $replaceTrimSizeValue;
		}
		return "";
	}
	
	public static function splitTrimWidthAndHeight($str = ""){
		if(!empty($str)){
			$getData = explode("x", $str);				
			return array($getData[0], $getData[1]);
		}
		return array("", "");
	}
	
	public static function generateMetricsData($minValue = '', $maxValue = '', $metricsValue = '', $dataArr = array()){
		if(!empty($minValue) && !empty($maxValue) && !empty($metricsValue) && count($dataArr) > 0){
			$getMinWidthAndHeight = self::splitTrimWidthAndHeight($minValue);				
			$dataArr['MIN_WIDTH'] = $getMinWidthAndHeight[0];
			$dataArr['MIN_HEIGHT'] = $getMinWidthAndHeight[1];
							
			$getMaxWidthAndHeight = self::splitTrimWidthAndHeight($maxValue);
			$dataArr['MAX_WIDTH'] = $getMaxWidthAndHeight[0];
			$dataArr['MAX_HEIGHT'] = $getMaxWidthAndHeight[1];
				
			$dataArr['METRIC_UNITS'] = $metricsValue;
		}
		return $dataArr;
	}
	
	public static function generateInsertDataArray($data = array(), $size = ''){	
				
		$insertDataArr = array();
		if(count($data) > 0 && !empty($size)){
			//127x190_mm_5x7,5_inch_178x254_mmm_7x10_inch_----------------193x242_mm_7,5x9,5_inch_210x297_mmm_8,5x11,75_inch_
			$splitTrimSize = explode("_", $size);
			if(count($splitTrimSize) == 9){
				
				$insertDataArr[] =  self::generateMetricsData($splitTrimSize[0], $splitTrimSize[4], $splitTrimSize[1], $data);
				$insertDataArr[] =  self::generateMetricsData($splitTrimSize[2], $splitTrimSize[6], $splitTrimSize[3], $data);
			}
		}
		return $insertDataArr;
	}
}
