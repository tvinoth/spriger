<?php

namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class UploadedDocumentsModel extends Model {

    // 
    protected $table = 'fin_uploaded_documents';
    public $primaryKey = 'UPLOADED_DOCUMENT_ID';
    public $timestamps = false;

    //protected $fillable = array('CreatedAt');

    public static function getData($select = ['fin_uploaded_documents.*'], $where = '') {
        DB::enableQueryLog();
        //->where('IS_ACTIVE',1)
        $query = DB::table((new static)->getTable())
                ->where(function ($query) use ($where) {
                    if ($where != '') {
                        $query->where($where);
                    }
                })
                ->orderBy('UPLOADED_DOCUMENT_ID', 'ASC')
                ->select($select)
                ->get();
        $queryChk = DB::getQueryLog();
        //print_r($queryChk);die;
        return $query;
    }

    public static function insertData($data = array()) {
        if (count($data) > 0) {
            $id = DB::table((new static)->getTable())->insert($data);

            return $id;
        }
        return 0;
    }

    public static function updateData($data = array(), $where = array()) {
        if (count($data) > 0) {
            $affectedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->update($data);

            return $affectedRows;
        }
        return 0;
    }

    public static function deleteData($where = array()) {
        if (count($where) > 0) {
            $deletedRows = DB::table((new static)->getTable())->where(function ($query) use ($where) {
                        if (!empty($where) || $where != '') {
                            //$query->where($where);
                            foreach ($where as $key => $val) {
                                $query->where($key, $val);
                            }
                        }
                    })->delete();

            return $deletedRows;
        }
        return 0;
    }

    public static function getDataWithSearch($searchStr, $otherSearchArray = array(), $columnArray, $orderColumn, $sorting, $start, $length, $recordsTotal = false, $recordFilteredCntOnly = false) {
        $query = DB::table((new static)->getTable())->join('customer AS c', 'fin_uploaded_documents.CUSTOMER_ID', '=', 'c.CUSTOMER_ID')->join('customer_division AS cd', 'fin_uploaded_documents.CUSTOMER_DIVISION_ID', '=', 'cd.CUSTOMER_DIVISION_ID');

        if (!empty($otherSearchArray)) {
			foreach($otherSearchArray as $key => $val){
				$query->where('fin_uploaded_documents.'.$key, 'like', '%' . $val . '%');
			}
            //$query->where($otherSearchArray);
        }
        if ($recordsTotal) {
			//$query->groupBy('c.CUSTOMER_NAME', 'cd.DIVISION_NAME', 'fin_uploaded_documents.START_DATE', 'fin_uploaded_documents.END_DATE');
            $resp = $query->count();
        } else {
            $query->where(function ($query) use ($searchStr) {
                        if ($searchStr != '') {
                            $query->where('fin_uploaded_documents.UPLOADED_DOCUMENT_ID', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.ORG_FILENAME', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.CURRENCY_NAME', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.CURRENCY_SYMBOL', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.VENDOR_NAME', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.START_DATE', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.END_DATE', 'like', '%' . $searchStr . '%')
                            ->Orwhere('fin_uploaded_documents.CREATED_DATE', 'like', '%' . $searchStr . '%')
                            ->Orwhere('c.CUSTOMER_NAME', 'like', '%' . $searchStr . '%')
                            ->Orwhere('cd.DIVISION_NAME', 'like', '%' . $searchStr . '%');
                            //->Orwhere('DATE', 'like', '%' . $searchStr . '%')
                            //->Orwhere('CREATED_BY', 'like', '%' . $searchStr . '%');
                        }
                    })
                    ->select('fin_uploaded_documents.UPLOADED_DOCUMENT_ID', 'fin_uploaded_documents.ORG_FILENAME', DB::raw('CONCAT_WS("", fin_uploaded_documents.CURRENCY_NAME, fin_uploaded_documents.CURRENCY_SYMBOL) AS CURRENCY'), 'fin_uploaded_documents.VENDOR_NAME', 'fin_uploaded_documents.DATE', 'fin_uploaded_documents.START_DATE', 'fin_uploaded_documents.END_DATE', 'fin_uploaded_documents.CREATED_DATE', 'fin_uploaded_documents.CUSTOMER_ID', 'fin_uploaded_documents.CUSTOMER_DIVISION_ID',DB::raw('CONCAT_WS("/", c.CUSTOMER_NAME, cd.DIVISION_NAME) AS CUSTOMER_NAME')); //, 'CREATED_BY'
			//$query->groupBy('c.CUSTOMER_NAME', 'cd.DIVISION_NAME', 'fin_uploaded_documents.START_DATE', 'fin_uploaded_documents.END_DATE');
            if (!$recordFilteredCntOnly) {
                //$query->orderBy($columnArray[$orderColumn], $sorting)->skip($start)->take($length); 'fin_uploaded_documents.CUSTOMER_ID', 'fin_uploaded_documents.CUSTOMER_DIVISION_ID'
                $query->orderBy('fin_uploaded_documents.CUSTOMER_ID', 'asc')
				->orderBy('fin_uploaded_documents.CUSTOMER_DIVISION_ID', 'asc')
				->orderBy('fin_uploaded_documents.START_DATE', 'desc')
				->orderBy('fin_uploaded_documents.END_DATE', 'desc')->skip($start)->take($length);
            }
            $resp = $query->get();
        }
        return $resp;
    }

    public function finUploadedDocumentItems() {
        return $this->hasMany('App\Models\finance\FinUploadedDocumentItemsModel', 'UPLOADED_DOCUMENT_ID', 'UPLOADED_DOCUMENT_ID');
    }

    public function finServiceItemRate() {
        return $this->hasMany('App\Models\finance\FinServiceItemRateModel', 'CUSTOMER_ID', 'CUSTOMER_ID')->where('fin_service_item_rate.IS_ACTIVE', 1);
    }

    public function finCurrencyEnum() {
        return $this->hasOne('App\Models\finance\FinCurrencyEnumModel', 'CURRENCY_ENUM_ID', 'CURRENCY_ENUM_ID');
    }

}
