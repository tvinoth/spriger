<?php namespace App\Models\finance;

use Illuminate\Database\Eloquent\Model;
use DB;

class LineItemStageMapModel extends Model
{
    // 
    protected $table = 'fin_lineitem_stage_map';
    public $primaryKey = 'STAGE_MAPPING_ID';
    public $timestamps = false;
    //protected $fillable = array('CreatedAt'); 

    
}
