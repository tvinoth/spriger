<?php

namespace App\Models\finance;
use Illuminate\Database\Eloquent\Model;
use DB;

class UserModel extends Model {

    // 
    protected $table = 'user';
    public $primaryKey = 'USER_ID';
    public $timestamps = false;

	//protected $fillable = array('CreatedAt');

    /**
     * 
     * @param type $userID = USER_ID - user table
     * @return type
     */
    

}
