<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class jobStage extends Model {
    
    protected   $table       =      'job_stage';
    public      $primaryKey  =      'JOB_STAGE_ID';
    public      $timestamps  =      false;
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new jobStage();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $table      =   'job_stage';
        
        $updateQry  =   DB::table( $table )
                            ->where('JOB_STAGE_ID', $rowid )
                            ->update( $setArr );
        
        
        return $updateQry;
        
    }
    
    public function getJobStageInfoByJobStageId( $jobstageid = null , $return = 'object'){
        
        $table      =   'job_stage';
        
        if( !is_null( $jobstageid ) && $return == 'object' ){
            return DB::table( $table )->where( 'JOB_STAGE_ID', '=', $jobstageid )->get()->first();
        }
        
        if( !is_null( $jobstageid ) && $return == 'array' ){
            $records    =    DB::table( $table )->where( 'JOB_STAGE_ID', '=', $jobstageid )->get()->first();
            return collect($records)->toArray();
        }
        return false;
        
    }
    
    public function getJobStageInfoByArtMetaId( $artmetaid = null ){
        
        $sql = 'SELECT tlam.FIGURE_NO,tlam.FILE_NAME,tlam.ART_METADATA_ID,js.JOB_STAGE_ID,jr.METADATA_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID
                    FROM task_level_art_metadata tlam 
                    JOIN job_round jr ON jr.ART_METADATA_ID = tlam.ART_METADATA_ID
                    JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_STAGE = js.STAGE_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID
                    WHERE tlam.ART_METADATA_ID IN ('.$artmetaid.')';
      
        $getRec        =   DB::select( $sql );
        
        return $getRec;
        
    }
    
    public function getCurrentJobStageInfo( $metaid , $round , $status ){
        //WITHOUT ART ONLY 
        
        $sqlSmt     =   " SELECT * from task_level_metadata tlmd left join job_round jr "
                . " on tlmd.METADATA_ID = $metaid and tlmd.METADATA_ID = jr.METADATA_ID and tlmd.CURRENT_ROUND = $round and jr.IS_ART IS NULL "
                . " left join job_stage js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                . " where tlmd.METADATA_ID = $metaid and jr.ROUND_ID = $round and js.`STATUS`  = $status "
                . " order by js.JOB_STAGE_ID DESC LIMIT 1 ";
     
        return DB::select( $sqlSmt );
        
    }
    
    public function getCurrentJobStageInfoByStage( $metaid , $round , $stage ){
        //WITHOUT ART ONLY 
        
        $sqlSmt     =   " SELECT * from task_level_metadata tlmd left join job_round jr "
                . " on tlmd.METADATA_ID = $metaid and tlmd.METADATA_ID = jr.METADATA_ID and tlmd.CURRENT_ROUND = $round and jr.IS_ART IS NULL "
                . " left join job_stage js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID "
                . " where tlmd.METADATA_ID = $metaid and jr.ROUND_ID = $round and js.`STAGE_ID`  = $stage "
                . " order by js.JOB_STAGE_ID DESC LIMIT 1 ";
         
        return DB::select( $sqlSmt );
        
    }
    
    public function getJobStageInfoByArtMetaIdStageId( $artmetaid = null , $stageid = null ){
        
        $sql = 'SELECT tlam.FIGURE_NO,tlam.FILE_NAME,tlam.ART_METADATA_ID,js.JOB_STAGE_ID,jr.METADATA_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID FROM task_level_art_metadata tlam JOIN job_round jr ON jr.ART_METADATA_ID = tlam.ART_METADATA_ID JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID and js.STAGE_ID = '.$stageid.' and jr.CURRENT_ITERATION_ID = js.ITERATION_ID WHERE tlam.ART_METADATA_ID IN ('.$artmetaid.')';
		
		$sql	=	'SELECT tlam.FIGURE_NO,tlam.FILE_NAME,tlam.ART_METADATA_ID,js.JOB_STAGE_ID,jr.METADATA_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID
FROM task_level_art_metadata tlam
JOIN job_round jr ON tlam.METADATA_STATUS_ID = jr.METADATA_STATUS_ID
JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND js.STAGE_ID = '.$stageid.' AND jr.CURRENT_ITERATION_ID = js.ITERATION_ID
WHERE tlam.ART_METADATA_ID IN ('.$artmetaid.')';
		
        $getRec        =   DB::select( $sql );
        
        return $getRec;
        
    }
    
    public static function getJobStageInforeferencepdf( $jobid = null){
        
        $records    =    jobStage::join('job_round','job_round.JOB_ROUND_ID','=','job_stage.JOB_ROUND_ID')
                            ->where( 'job_round.JOB_ID', '=', $jobid )
                            ->where( 'job_round.CURRENT_STAGE', '=',  Config::get('constants.STAGE_COLLEECTION.AUTO_REFERENCE_PDF') )
                            ->where( 'job_round.ROUND_ID', '=', Config::get('constants.ROUND_NAME.S5') )
                            ->first();
        return $records;
    }
    
    
}

