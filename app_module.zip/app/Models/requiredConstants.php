<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;
use App\Models\requiredConstants;

class requiredConstants extends Model {    
    
    protected   $table          =   'required_constants';
    public      $primaryKey     =   'ID';
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new requiredConstants();
        if( !empty( $inp_arr ) ){
            foreach( $inp_arr as  $index => $value ){
                $api_obj->$index    =   $value;
            }
        }
        $insert_r       =       $api_obj->save();
        if( $insert_r )
            return 2;
        
        return 1;
        
    }
    
    public function getRequiredConstants( $constname = null , $arrayin = array() ){
       
        $query      =   DB::table('required_constants')
                            ->select()
                            ->where('STATUS' , '=' , 'Y' );
        
        if( !is_null( $constname ) ){
            $query->where( 'CONSTANT_NAME' , '=' , $constname );
            $records        =       $query->get()->first();
        }
        
        if( !empty( $arrayin ) ){
           
            $query->whereIn( 'CONSTANT_NAME' , $arrayin );
            $records        =       $query->get();
            
        }
        
        return $records;
        
    }
    
    public function getRequiredConstantsChild( $parentid = null ){
       
        $query      =   DB::table('required_constants')
                            ->select()
                            ->where('STATUS' , '=' , 'Y' );
        
        $records_sub    =   array();
        
        if( !is_null( $parentid ) ){
            
            $query->where( 'PARENT_ID' , '=' , $parentid );
            $records_        =       $query->get();
            
            $parentinfo     =       DB::select('select * from required_constants where id ='.$parentid );
            $parentname     =       $parentinfo[0]->CONSTANT_NAME;
            
        }
        
        if( !empty( $records_ ) ){
            
            foreach( $records_ as $key => $value ){
               $records_sub["$value->CONSTANT_NAME"]   =   $value->CONSTANT_VALUE;
            }
          
            //$records[$parentname]   =   $records_sub;
            $records   =   $records_sub;
                    
        }else{
            
        }
        
        return $records;
    }
    
    public function getRequiredConstantsAll( $parentid = null , &$records ){
        
        //$records    =   array();
        
        $query      =   DB::table('required_constants')
                            ->select()
                            ->where('STATUS' , '=' , 'Y')
                            ->whereNull('PARENT_ID');
        
        $records_qry        =       $query->get();
        
        if( count( $records_qry ) ){
            
            foreach( $records_qry as $index => $value ){
                $records[$value->CONSTANT_NAME] =   $value->CONSTANT_VALUE;
               
            }

        }
          
        //ChildrensQry  =   ''';
        $query2      =   DB::table('required_constants')
                            ->select()
                            ->where('STATUS' , '=' , 'Y')
                            ->whereNotNull('PARENT_ID')
                            ->orderBy(  'ID' , 'asc' )
                            ->groupBy('PARENT_ID')
                ->get();
        
        if( count( $query2 ) ){
            
            foreach( $query2 as $key => $value ){
                if( !empty( $value->PARENT_ID ) ){
                    $parentid   =   $value->PARENT_ID;
                    $parentInfo =   DB::select('select * from required_constants where ID = '.$parentid);
                    $childrens_const  =    $this->getRequiredConstantsChild( $parentid );   
                    $records[$parentInfo[0]->CONSTANT_NAME] =   $childrens_const;
                }
            }
        }
            
        //return $records;
        
    }
   
    
    
}

