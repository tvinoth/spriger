<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class opsMail extends Model {
    
    protected   $table       =      'ops_proofout_mail_to_pm_status';
    public      $primaryKey  =      'ID';
    public      $timestamps  =      false;
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new opsMail();

        if( !empty( $inp_arr ) ){
            foreach( $inp_arr as  $index => $value ){
                $ins_obj->$index    =   $value;
            }
        }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
      
    }
    
    public function insertRecordGetId( $inp_arr = array() ){
        
        if( !empty( $inp_arr ) ){
            return opsMail::insertGetId( $inp_arr );
        }
        
        return false;
        
    }
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $updateQry  =   opsMail::update( $setArr )->where('ID', $rowid );
        return $updateQry;
        
    }
    
    
}

