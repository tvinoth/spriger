<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class teamModel extends Model {
    
    protected $table    =   'team';
    
    public function getTeamUsers( $user_id = null , $role_id = null ){
        
        if( !is_null( $user_id ) ){
            
            $custom_query   =        ' select distinct(u.USER_ID),ut.team_id ,re.NAME , re.ID , ';
            $custom_query   .=       " trim(CONCAT(IF(u.FIRST_NAME IS NULL,'', CONCAT(u.FIRST_NAME,' ')), IF(u.MIDDLE_NAME IS NULL,'', CONCAT(u.MIDDLE_NAME,' ')), ";
            $custom_query   .=       " IF(u.LAST_NAME IS NULL,'', u.LAST_NAME))) AS EMPLOYEE_NAME ";
            $custom_query   .=       ' from user u join role_enum re on re.ID = u.ROLE join user_team_map ut on ut.USER_ID=u.USER_ID and ut.TEAM_ID ';
            $custom_query   .=       ' in( select t.team_id from team as t where t.sub_circle in ( select s.sub_circle_id from sub_circle as s ';
            $custom_query   .=       " where s. circle_id in ( select c.circle_id from circle as c where c.circle_head = '".$user_id."' and u.IS_ACTIVE = 1)) ";
            $custom_query   .=       ' union select t.team_id from team as t where t.sub_circle in (  select s.sub_circle_id from sub_circle as s ';
            $custom_query   .=       " where s.sub_circle_head = '".$user_id."' and u.IS_ACTIVE = 1) ";
            $custom_query   .=       " union select t.team_id from team as t  where t.team_head = '".$user_id."' and u.IS_ACTIVE = 1 ";
            $custom_query   .=       " union select ut.team_id from user_team_map as ut where ut.user_id = '".$user_id."' and u.IS_ACTIVE = 1) ";
            
            if( !is_null( $role_id ) )
                $custom_query   .=  " and re.id = 9 ";
        
            return DB::select( $custom_query );
            
        }
        
        return false;
        
    }
    
}

