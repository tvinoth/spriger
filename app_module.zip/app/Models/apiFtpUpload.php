<?php
namespace App\Models;
use App\Models\apiFileUpload;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiFtpUpload extends Model {
    
    protected $table = 'api_ftp_upload';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiFtpUpload();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        $insert_r           =       apiFtpUpload::insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                           );
        
        $updateQry  =   DB::table('api_ftp_upload')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByJobid( $jobid , $round ){
        
         $getRec       =         DB::table('api_ftp_upload as afu')
                                            ->where('BOOK_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )                                            
              ->orderBy('afu.ID', 'desc')
              ->get()->first();
      
      return $getRec;
      
    }
    
    public function getApiRequest( $jobid , $round , $token = null ){
        
        if( is_null( $token ) ){
            $getRec       =         DB::table('api_ftp_upload as afu')
                                            ->where('JOB_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )                                            
                                            ->where('STATUS', '=', 1 )                                            
              ->orderBy('afu.ID', 'desc')
              ->get()->first();
        }else{         
            $getRec       =         DB::table('api_ftp_upload as afu')
                                            ->where('JOB_ID', '=', $jobid )
                                            ->where('ROUND', '=', $round )                                            
                                            ->where('TOKEN_KEY', '=', $token )   
                                            ->where('STATUS', '=', 1 )
              ->orderBy('afu.ID', 'desc')
              ->get()->first();
        }
        
      return $getRec;
      
    }
    
}
