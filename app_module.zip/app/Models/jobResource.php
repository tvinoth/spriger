<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class jobResource extends Model {
    
    protected   $table          =   'job_resource';
    public      $primaryKey     =   'JOB_RESOURCE_ID';
    public      $timestamps     =   false;
    protected   $fillable       =   array('CREATED_DATE');
    
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new jobResource();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $table      =   'job_stage';
        
        $updateQry  =   DB::table( $table )
                            ->where('JOB_STAGE_ID', $rowid )
                            ->update( $setArr );
        
        
        return $updateQry;
        
    }
    
    public function getJobResourceEntryByJobStageId( $jobstage_id  ){
        
        $tblname        =   $this->table;
        
        if( !is_null( $jobstage_id ) ){
            
             $response   =      DB::table( $tblname )
                                    ->where( 'JOB_STAGE_ID', '=', $jobstage_id )
                                    ->get()
                                    ->first();
             return $response;
        }
       
        return false;
    }
   
    public function getOtherJobResourceEntryExist( $userid , $jobstageid ){
        $tblname        =   $this->table;

           if( !is_null( $userid ) ){

                $response   =      DB::table( $tblname )
                                       ->where( 'CREATED_BY' , '=', $userid )
                                       ->whereNotIn( 'JOB_STAGE_ID', array($jobstageid) )
                                       ->get()
                                       ->first();
                return $response;
           }

        return false;
    }
    
    public function buildInputAndinsertNewRecord( $inp ){
           
        extract( $inp );
        
        $res_ins_arr        =           array();
        try{
            
            $res_ins_arr['METADATA_ID']     =       $metaid;
            $res_ins_arr['IS_ART']          =       $is_art;
            $res_ins_arr['JOB_ID']          =       $jobid;
            $res_ins_arr['ASSIGNED_TO']     =       $userTo;
            $res_ins_arr['TEAM_ID']         =       $team_id;
            $res_ins_arr['JOB_STAGE_ID']    =       $jobstageid;
            $res_ins_arr['CREATED_BY']      =       $userBy;
            $res_ins_arr['CREATED_DATE']    =       $time;  //date('Y-m-d H:i:s');
            
            if( $is_art == 1 ){
                $res_ins_arr['ART_METADATA_ID'] =       $artMetaid;
                 $res_ins_arr['METADATA_STATUS'] =       $artMetaid;
                $res_ins_arr['BATCH_ID']        =       $batchid;
            }
            
        }catch( \Exception $e ){
            throw new Exception( 'Required information is missing.' );
        }
        
        return $this->insertNew( $res_ins_arr );
        
    }
    
    public function deleteByJobStageId( $jbstid ){
       return DB::table('job_resource')->where('JOB_STAGE_ID', '=', $jbstid )->delete();
    }
   
    
    public function getRecordByBatchId( $batchId  = null ){
        
        $table      =   'job_resource';
        
        if( !is_null( $batchId ) ){
            
            $condition  =   array( 
                    'BATCH_ID'  =>      $batchId ,
                    'IS_ART'    =>      1
                );
            
            return DB::table( $table )->where( $condition )
                    ->orderBy('JOB_RESOURCE_ID','desc')
                    ->get()->first();
            
        }
        
        return false;
        
    }
    
}

