<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models\ServiceManager;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class ServiceManagerUrlModel extends Model 
{
    protected $table        =   'service_manager_url';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "CREATED_DATE";
    const CREATED_AT        =   "UPDATED_DATE";
	
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
}

