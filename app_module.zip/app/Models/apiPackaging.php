<?php
namespace App\Models;
use App\Models\apiClientAcknowledgement;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiPackaging extends Model {
    
    protected $table = 'api_dataset';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiPackaging();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $table      =   'api_dataset';
        if(isset( $inpArr['NEW_PACKAGE_NAME'] ) && !empty( $inpArr['NEW_PACKAGE_NAME']  ) ){
            $setArr['NEW_PACKAGE_NAME']       =   $inpArr['NEW_PACKAGE_NAME'] ;
         }
         
        if(isset( $inpArr['PACKAGE_RESUME_AT']  ) ){
            $setArr['PACKAGE_RESUME_AT']       =   $inpArr['PACKAGE_RESUME_AT'] ;
        }
		
        $updateQry  =   DB::table( $table )
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByTokenKey( $tokenKey ){
        
        $table        =         'api_dataset';
        $getRec       =         DB::table($table)
                                    ->where('TOKEN_KEY', '=', $tokenKey )
                                    ->where('STATUS', '=', '1.5' )
                                    ->get()->first();
      
        return $getRec;
      
    }
    
}
