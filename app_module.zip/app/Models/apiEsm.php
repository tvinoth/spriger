<?php
namespace App\Models;
use App\Models\apiClientAcknowledgement;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiEsm extends Model {
    
    protected $table = '';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    
    public static function getApiRequestByTokenKey( $tokenKey ){
        
        $getRec       =         DB::table('api_esm_validate as alr')
                                    ->where('TOKEN_KEY', '=', $tokenKey )
                                    ->where('STATUS', '=', '1.5' )
                                    ->get()->first();
      
        return $getRec;
      
    }
    
     public static function getApiRequestByTokenKeyByProcess( $tokenKey ){
        
        $getRec       =         DB::table('api_esm_filename as alr')
                                    ->where('TOKEN_KEY', '=', $tokenKey )
                                    ->where('STATUS', '=', '1.5' )
                                    ->get()->first();
      
        return $getRec;
      
    }
    
     public static function updateIfExist( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $updateQry  =   DB::table('api_esm_validate')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
     public static function updateIfExistVID( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $updateQry  =   DB::table('api_esm_filename')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    
    public function getEsmValidationByJob( $jobId ){
        
       $getRec       =         DB::table('api_esm_validate as alr')
                                    ->where('JOB_ID', '=', $jobId )
                                    ->whereNull('METADATA_ID')
                                    ->orderBy('ID','desc')
                                    ->get()->first();
      
        return $getRec;
      
    }
    
    public static function getEsmValidationByMetaId( $metaId, $jobId ){
        
       $getRec       =         DB::table('api_esm_validate as alr')
                                    ->where('JOB_ID', '=', $jobId )
                                    ->where('METADATA_ID', '=', $metaId )
                                    ->orderBy('ID','desc')
                                    ->get()->first();
      
        return $getRec;
      
    }
    
    public static function getEsmVidByMetaId( $metaId, $jobId ){
        
       $getRec       =         DB::table('api_esm_filename as alr')
                                    ->where('JOB_ID', '=', $jobId )
                                    ->where('METADATA_ID', '=', $metaId )
                                    ->orderBy('ID','desc')
                                    ->get()->first();
      
        return $getRec;
      
    }
    
     public static function getMetaEsmDetails( $metaId, $jobId ){
        
       $getRec       =         DB::table('metadata_esm as alr')
                                    ->where('JOB_ID', '=', $jobId )
                                    ->where('METADATA_ID', '=', $metaId )
                                    ->where('IS_DELETED', '=', 0 )
                                    ->get();
      
        return $getRec;
      
    }
    
    public static function getMetaEsmDetailsByJobId( $jobId ){
        
       $getRec       =         DB::table('metadata_esm as alr')
                                    ->where('JOB_ID', '=', $jobId )
                                    ->where('IS_DELETED', '=', 0 )
                                    ->groupBy('alr.METADATA_ID')
                                    ->get();
      
        return $getRec;
      
    }
    
    
}
