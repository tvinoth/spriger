<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class taskLevelUserdefinedWorkflow extends Model {
    
    protected $table        =   'task_level_userdefined_workflow';
    public  $primaryKey     =   'TASK_LEVEL_USERDEFINED_WORKFLOW_ID';
    const UPDATED_AT        =   "LAST_MOD_DATE";
   
    public static function getUserDefineStageDetails($jobId, $workflowId,$roundId,$stage ){
      
        $getRec       =         DB::table('task_level_userdefined_workflow')
                                            ->where('JOB_ID', '=', $jobId )
                                            ->where('WORKFLOW', '=', $workflowId )
                                            ->where('STAGE', '=', $stage )
                                            ->where('ROUND', '=', $roundId )                                            
                                            ->get()->first();
      
        return $getRec;
        
    }
    
    //Required Parameter jobid , round , workflowmaster id
    
    public static function getUserdefinedWorkflowInformation ($jobid,$round,$wfMid,$wfid,$wftype=0) {
        
        $getRec = (object)array();
        
        if( !is_null($jobid) && !is_null($round) && !is_null($wfMid) ){
           
            $getRec    =       DB::table( 'task_level_userdefined_workflow as tluw' )
                                    //->join('user_defined_workflow_rule as udwr' ,  'tluw.WORKFLOW_MASTER_ID' , '=' , 'udwr.TASK_LEVEL_USERDEFINED_WORKFLOW_ID' )
                                    ->join('workflow_master as wm' ,  'wm.WORKFLOW_MASTER_ID' , '=' , 'tluw.WORKFLOW_MASTER_ID' )
                                    ->join('workflow as wf' ,  'wf.WORKFLOW_ID' , '=' , 'tluw.WORKFLOW' )
                                    ->join( 'round_enum as re' , 're.ID' , '=' , 'tluw.ROUND' )
                                    ->join( 'stage as stg' , 'stg.STAGE_ID' , '=' , 'tluw.STAGE' )
                                    ->where( 'tluw.JOB_ID' , '=' , $jobid )
                                    ->where( 'tluw.ROUND' , '=' , $round )
                                    ->where( 'tluw.WORKFLOW_TYPE' , '=' , $wftype )
                                    ->where( 'tluw.WORKFLOW' , '=' , $wfid )
                                    ->where( 'tluw.WORKFLOW_MASTER_ID',  '=' , $wfMid )
                                    ->select( DB::RAW( 'tluw.JOB_ID , tluw.ROUND , tluw.ROUND_SEQ , tluw.WORKFLOW_MASTER_ID , tluw.WORKFLOW , wf.WORKFLOW_ID ,tluw.WORKFLOW_SEQ , tluw.STAGE , tluw.STAGE_SEQ , tluw.IS_AUTO , tluw.WORKFLOW_TYPE , stg.STAGE_NAME ' ) )
                                    ->orderByRaw("tluw.STAGE_SEQ ASC")->get();
           
        }
            
        return $getRec;
        
    }
    
    public function getWorkflowStages( $jobid , $roundid , $workflowid ){
       
       $getStagesRec        =           DB::table( 'task_level_userdefined_workflow as tluw' )
                                                ->join( 'stage as stg'     , 'stg.STAGE_ID'    ,   '='     ,   'tluw.STAGE' )
                                                ->where('tluw.JOB_ID'   , '=' , $jobid )
                                                ->where('tluw.ROUND'    , '=' , $roundid )
                                                ->where('tluw.WORKFLOW' , '=' , $workflowid )
                                                ->select()
                                                ->get();
       
       return $getStagesRec;
        
    }
    
    public function getWorkflowMasterIdByJobidAndRound( $jobid , $round , $type  = 0 ){
        
      //  DB::enableQueryLog();
        
        $rec    =       DB::table('task_level_userdefined_workflow')
                                ->select()
                                ->where( 'JOB_ID' , '=' , $jobid )
                                ->where( 'ROUND'  , '=' , $round )
                                ->where( 'WORKFLOW_TYPE'  , '=' , $type )
                                ->orderBy( 'TASK_LEVEL_USERDEFINED_WORKFLOW_ID' , 'DESC' )
                                ->get();
        
      //  $qw     =       DB::getQueryLog();
       
        return $rec;
        
    }
    
}

