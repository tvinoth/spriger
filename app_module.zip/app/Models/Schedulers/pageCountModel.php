<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models\Schedulers;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class pageCountModel extends Model 
{
    protected $table        =   'cron_fetchpagecount';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_AT";
    const CREATED_AT        =   "CREATED_AT";
	
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new pageCountModel();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $id ){
        
        $updateQry  =   DB::table('cron_fetchpagecount')
			->where( "ID" , $id )
			->update( $inpArr );
        
        return $updateQry;
        
    }
    
    public function getRunableRecord( $priority = null ){
       // DB::enableQueryLog();
		
        $return_result  =   DB::table('cron_fetchpagecount')->select()
                                ->where( 'PRIORITY' , NULL )
                                ->where( 'STATUS'   , 0 )
                                ->where( function ($q) {
                                    $q->where('ITERATION', NULL )->orWhere('ITERATION', '<', 4 ); } )
                                ->where( 'DELETION'   , NULL )->get()->first();
        
		//$pr = DB::getQueryLog();
		//print_r( $pr );
	
        return $return_result;

    }
	
	
    public function getRunableRecordWithPriority( $priority = 1 ){
        
        $return_result  =   DB::table('cron_fetchpagecount')->select()
                                ->where( 'PRIORITY' , $priority )
                                ->where( 'STATUS'   , 0 )
                                ->where( function ($q) {
                                    $q->where('ITERATION', NULL )->orWhere('ITERATION', '<', 4 ); } )
                                ->where( 'DELETION'   , 2 )->get()->first();
                                    
        return $return_result;

    }
    
    
}

