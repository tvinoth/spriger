<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models\ChapterPromotion;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class chapterPromotionEmailLogModel extends Model 
{
    protected $table        =   'chapter_promotion_email_log';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "CREATED_DATE";
    const CREATED_AT        =   "UPDATED_DATE";
	
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
}

