<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class jobModel extends Model {
    
    protected $table    =   'job';
    public $primaryKey  =   'JOB_ID';
    public $timestamps  =   true;
	const UPDATED_AT        =   "LAST_MOD_DATE"; 
    protected $fillable =   array('CREATED_DATE');

    //sample input array
    // 0 => id
    // 1 => limit start
    // 2 => limit  
    // 3 => order by
    
    public function getSplitProcessJobList( $userid  ){
        
        $contact_info   =       array();
        $tblname        =       'job as jb';
        
        try{
            
            $select_field   =       array( 'jb.JOB_ID' , DB::RAW( '104 AS ROUND' ) , 'jb.BOOK_ID' , 'jb.JOB_TITLE' , 'jb.PM' , DB::RAW( 'concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME' ) ,  'jb.IS_ACTIVE' , 'jb.CREATED_DATE',DB::RAW( 'jts.JOB_ID as jtsjobid' ),DB::RAW( 'jts.CREATED_BY as jtscreated' ) ,DB::RAW( 'jts.CHECK_OUT' ),DB::RAW( 'jts.CHECK_IN' ),DB::RAW( 'jts.STATUS' ));
            $stage      =     \Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'); 
            $query1     =       ' select `jts`.`STAGE`, `jts`.`JOB_ID`, `jts`.`ROUND_ID` , `ji`.`AUTHOR_NAME` , `ji`.`EDITOR_NAME` , `jb`.`JOB_ID`, 104 AS ROUND, `jb`.`BOOK_ID`, `jb`.`JOB_TITLE`, `jb`.`PM`, ';
            $query1     .=      ' concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME, `jb`.`IS_ACTIVE`, `jb`.`CREATED_DATE`, jts.JOB_ID as jtsjobid, jts.CREATED_BY as jtscreated, ';
            $query1     .=      ' jts.CHECK_OUT, jts.CHECK_IN, jts.STATUS from `job` as `jb`inner join `job_info` as `ji` on `ji`.`JOB_ID` = `jb`.`JOB_ID` ';
            $query1     .=      ' LEFT JOIN task_level_metadata AS tlm ON tlm.JOB_ID = ji.JOB_ID ';
            $query1     .=      ' inner join `user` as `u` on `jb`.`PM` = `u`.`USER_ID` left join `job_time_sheet` as `jts` on `jb`.`JOB_ID` = `jts`.`JOB_ID` and ';
            $query1     .=      ' jts.JOB_TIME_SHEET_ID in ( select max(jts2.JOB_TIME_SHEET_ID) from job_time_sheet jts2 WHERE jts.JOB_ID = jts2.JOB_ID AND jts.STAGE = jts2.STAGE ';
            $query1     .=      ' group by jts2.JOB_ID , jts2.STAGE ) where `jb`.`STATUS` = 1 and `ji`.`LOCATION` <> "" and tlm.JOB_ID is null and `jts`.`STATUS` = 1 and jb.IS_ACTIVE= 1 and `jts`.`STAGE` = '.$stage.' and jb.JOB_TYPE != "'.Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES').'"';
            $query1     .=      ' order by `jts`.`created_at` desc';
            
            $contact_info = DB::select( $query1 );
            $query_stmt         =    "SELECT `jb`.`JOB_ID`, 104 AS ROUND, `jb`.`BOOK_ID`, `jb`.`JOB_TITLE`, `jb`.`PM`, concat(u.FIRST_NAME,' ',u.LAST_NAME) AS PM_NAME,`ji`.`AUTHOR_NAME` , `ji`.`EDITOR_NAME` , `jb`.`IS_ACTIVE`, `jb`.`CREATED_DATE`, null as  jtsjobid,null as jtscreated  from job as jb LEFT JOIN job_info as ji on jb.JOB_ID = ji.JOB_ID LEFT JOIN task_level_metadata AS tlm ON tlm.JOB_ID = jb.JOB_ID inner join `user` as `u` on `jb`.`PM` = `u`.`USER_ID` WHERE `ji`.`LOCATION` <> '' and  jb.`STATUS`  = 1 and  jb.IS_ACTIVE = 1 and tlm.JOB_ID is null and jb.JOB_TYPE != '".Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES')."' and jb.JOB_ID NOT IN ( select JOB_ID from job_time_sheet jts where jts.ROUND_ID = 104 and jts.STAGE = 1291 group by jts.JOB_ID )";
            
            $contact_info2       =    DB::select( $query_stmt );
            
            if( !empty( $contact_info ) && !empty( $contact_info2 ) ){
             $final_result    =   array();
             foreach( $contact_info as $key => $value ){
                $final_result = array_push( $contact_info2 , $value  );
             }
             $final_result      =   $contact_info2;
            }elseif( $contact_info ){
             $final_result  =   $contact_info;
            }elseif( $contact_info2 ){
                $final_result   =   $contact_info2;
            }
            $contact_info       =       $final_result;
            
        }catch( \Exception $e ){   
            return false;
        }
           
        return $contact_info;        
   }
   
       public function getSplitCompletedProcessJobList( $userid  ){
        
        $contact_info   =       array();
        $tblname        =       'job as jb';
        
        try{
            
            $select_field   =       array( 'jb.JOB_ID' , DB::RAW( '104 AS ROUND' ) , 'jb.BOOK_ID' , 'jb.JOB_TITLE' , 'jb.PM' , DB::RAW( 'concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME' ) ,  'jb.IS_ACTIVE' , 'jb.CREATED_DATE',DB::RAW( 'jts.JOB_ID as jtsjobid' ),DB::RAW( 'jts.CREATED_BY as jtscreated' ) ,DB::RAW( 'jts.CHECK_OUT' ),DB::RAW( 'jts.CHECK_IN' ),DB::RAW( 'jts.STATUS' ));
            $stage      =     \Config::get('constants.STAGE_COLLEECTION.SPLIT_PROCESS'); 
            $query1     =       ' select `jts`.`STAGE`, `jts`.`JOB_ID`, `jts`.`ROUND_ID` , `ji`.`AUTHOR_NAME` , `ji`.`EDITOR_NAME` , `jb`.`JOB_ID`, 104 AS ROUND, `jb`.`BOOK_ID`, `jb`.`JOB_TITLE`, `jb`.`PM`, ';
            $query1     .=      ' concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME, `jb`.`IS_ACTIVE`, `jb`.`CREATED_DATE`, jts.JOB_ID as jtsjobid, jts.CREATED_BY as jtscreated, ';
            $query1     .=      ' jts.CHECK_OUT, jts.CHECK_IN, jts.STATUS from `job` as `jb`inner join `job_info` as `ji` on `ji`.`JOB_ID` = `jb`.`JOB_ID` ';
            $query1     .=      ' inner join `user` as `u` on `jb`.`PM` = `u`.`USER_ID` left join `job_time_sheet` as `jts` on `jb`.`JOB_ID` = `jts`.`JOB_ID` and ';
            $query1     .=      ' jts.JOB_TIME_SHEET_ID in ( select max(jts2.JOB_TIME_SHEET_ID) from job_time_sheet jts2 WHERE jts.JOB_ID = jts2.JOB_ID AND jts.STAGE = jts2.STAGE ';
            $query1     .=      ' group by jts2.JOB_ID , jts2.STAGE ) where `jb`.`STATUS` = 1 and `ji`.`LOCATION` <> "" and `jts`.`STATUS` = 2 and jb.IS_ACTIVE= 1 and `jts`.`STAGE` = '.$stage.' and jb.JOB_TYPE != "'.Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES').'"';
            $query1     .=      ' order by `jts`.`created_at` desc';
            
            $contact_info = DB::select( $query1 );
            $query_stmt         =    "SELECT `jb`.`JOB_ID`, 104 AS ROUND, `jb`.`BOOK_ID`, `jb`.`JOB_TITLE`, `jb`.`PM`, concat(u.FIRST_NAME,' ',u.LAST_NAME) AS PM_NAME,`ji`.`AUTHOR_NAME` , `ji`.`EDITOR_NAME` , `jb`.`IS_ACTIVE`, `jb`.`CREATED_DATE`, null as  jtsjobid,null as jtscreated  from job as jb LEFT JOIN job_info as ji on jb.JOB_ID = ji.JOB_ID inner join `user` as `u` on `jb`.`PM` = `u`.`USER_ID` WHERE `ji`.`LOCATION` <> '' and  jb.`STATUS`  = 1 and  jb.IS_ACTIVE = 1 and jb.JOB_TYPE != '".Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES')."' and jb.JOB_ID NOT IN ( select JOB_ID from job_time_sheet jts where jts.ROUND_ID = 104 and jts.STAGE = 1291 group by jts.JOB_ID )";
            
            $contact_info2       =    DB::select( $query_stmt );
            
            if( !empty( $contact_info ) && !empty( $contact_info2 ) ){
             $final_result    =   array();
             foreach( $contact_info as $key => $value ){
                $final_result = array_push( $contact_info2 , $value  );
             }
             $final_result      =   $contact_info2;
            }elseif( $contact_info ){
             $final_result  =   $contact_info;
            }elseif( $contact_info2 ){
                $final_result   =   $contact_info2;
            }
            $contact_info       =       $final_result;
           
        }catch( \Exception $e ){   
            return false;
        }
           
        return $contact_info;        
   }
    
    public static function getJobdetails($jobId){
        
        $bookinfo 		=	array();
        
        try{
            $bookinfo   =   jobModel::select(DB::raw('job.*,job_info.*'))
					->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                        		->where('job.JOB_ID',$jobId)
                                        ->get()->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
        return $bookinfo;
    }
    
    public static function getJobdetailsRawQuery($jobId,$selectField){
        
        $bookinfo 		=	array();
        
        try{
            $bookinfo   =   jobModel::select(DB::raw($selectField))
					->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                        		->where('job.JOB_ID',$jobId)
                                        ->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
        return $bookinfo;
    }
    
    public static function getBookinfo(){
        
	$bookinfo 		=	array();
        
        try{
            
            $bookinfo   =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME'))
                            	->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                ->where('job.IS_ACTIVE',1)
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
    }
    
    public static function getjobInfodetails($jobId)
    {    
        $spicastinfo        =   false;   
        try
        {
            $spicastinfo    =   jobModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME,u.USER_ID as USER_ID,u.EMAIL AS PM_EMAIL,u.EMPLOYEE_ID as PM_EMPLOYEE_ID,u1.EMPLOYEE_ID as AM_EMPLOYEE_ID'))
                                ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )
                                ->leftjoin( 'user as u1' , 'job_info.AM', '=', 'u1.USER_ID' )   
                                ->where('job.JOB_ID',$jobId)
                                ->get()->first();        
        }catch( \Exception $e ){           
            
            return $spicastinfo;
            
        }    
        return $spicastinfo;
    }
    
    public static function getjobInfoaandUserdetails($jobId,$selectField)
    {    
        $spicastinfo        =   [];   
        try
        {
            $spicastinfo    =   jobModel::select(DB::raw($selectField))
                                ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )
                                ->leftjoin( 'user as u1' , 'job_info.AM', '=', 'u1.USER_ID' )   
                                ->where('job.JOB_ID',$jobId)
                                ->get()->first();        
        }catch( \Exception $e ){
            return $spicastinfo;
        }    
        return $spicastinfo;
    }
    
    public static function getjobalertemailInfodetails($jobId,$roundId,$stageId)
    {    
        $spicastinfo        =   false;   
        try
        {
            $sql = 'SELECT job.JOB_ID,job.BOOK_ID,job.PROJECT_NAME,job.PM,jbinfo.AM,jbinfo.AM_NAME,jbinfo.AM_MAIL,jbinfo.PE_NAME,jbinfo.PE_LOCATION,jbinfo.PE_MAIL, CONCAT(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME,u.EMAIL,u.USER_ID AS USER_ID,ul.EMAIL as AM_EMAIL,rnd.NAME,rnd.ID,rnd.DESCRIPTION,st.STAGE_ID,st.STAGE_NAME,st.DESCRIPTION
                    FROM `job` INNER JOIN `job_info` as jbinfo ON `job`.`JOB_ID` = jbinfo.JOB_ID  inner join round_enum as rnd 	on rnd.ID = '.$roundId.'  inner join stage as st on st.STAGE_ID 	= '.$stageId.' LEFT JOIN `user` AS `u` ON `job`.`PM` = `u`.`USER_ID` LEFT JOIN `user` AS `ul` ON `jbinfo`.`AM` = `ul`.`USER_ID`
                    WHERE `job`.`JOB_ID` = '.$jobId.' and rnd.IS_ACTIVE = true and st.IS_ACTIVE = true';
            $spicastinfo        =   DB::select( $sql );    
        }catch( \Exception $e ){
            return $spicastinfo;
        }    
        return $spicastinfo;
    }
    
    public static function getPrrreportdetails()
    {    
        $spicastinfo        =   false;   
        try
        {
            DB::enableQueryLog();
            $spicastinfo    =   DB::select("select job.JOB_ID,job.BOOK_ID,job.JOB_TITLE,job_info.JOB_ID as jobid,job_info.AUTHOR_EMAIL,job_info.EDITOR_NAME,job_info.AUTHOR_NAME,job_info.ISSN_ONLINE,job.CREATED_DATE,job_info.SPICAST_STATUS,
job_info.PRR_REPORT_STATUS,job_info.PE_MAIL,job_info.PRR_REPORT_STATUS,job_info.SPICAST_XML_STATUS,job_info.SPICAST_FILE_STATUS,job_info.LAYOUT_PROFILE,
spct.STATUS,spct.ID as spicastid , spct.REMARKS,spct.END_TIME, ame.ID as apimetaid ,ame.JOB_ID,ame.STATUS as META_STATUS,ame.PROCESS_TYPE, ame.REMARKS as METAREMARKS,ame.END_TIME as META_END_TIME,
ac.STATUS AS SUCCESS_REDO, ac.REMARKS AS SR_REMARKS,ac.ID as CLIACKID,afu.REMARKS AS AFU_REMARKS, afu.STATUS AS AFU_STATUS,afu.END_TIME AS AFU_END_TIME,spct.ROUND as ROUND_ID
from job inner join job_info on job.JOB_ID = job_info.JOB_ID 
left JOIN api_spicast spct	on spct.JOB_ID = job.JOB_ID and spct.ROUND = '".\Config::get('constants.ROUND_ID.S5')."'
and spct.ID IN  ( select max( spct2.ID ) from api_spicast spct2 where spct2.JOB_ID = spct.JOB_ID AND spct2.ROUND = spct.ROUND order by spct2.ID desc )
LEFT JOIN api_client_acknowledgement ac ON ac.JOB_ID = job.JOB_ID AND ac.ROUND = '".\Config::get('constants.ROUND_ID.S5')."' AND ac.ID IN (SELECT MAX(ac2.ID) FROM api_client_acknowledgement ac2 WHERE ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = '".\Config::get('constants.ROUND_ID.S5')."' ORDER BY ac2.ID DESC)
left JOIN api_meta_extractor ame	on ame.JOB_ID = job.JOB_ID and ame.ROUND = '".\Config::get('constants.ROUND_ID.S5')."' and ame.PROCESS_TYPE = '".\Config::get('constants.PROCESS_TYPE')."' and ame.ID IN 
( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND order by ame2.ID desc )
left JOIN api_file_upload afu	on afu.JOB_ID = job.JOB_ID and afu.ROUND = '".\Config::get('constants.ROUND_ID.S5')."' and afu.PROCESS_TYPE = '".\Config::get('constants.PROCESS_TYPE')."' and afu.ID IN 
( select max( afu2.ID ) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND order by afu2.ID desc ) where job.IS_ACTIVE  =   1 and job_info.SPICAST_STATUS =   1");
        $qw     =       DB::getQueryLog();
          // print_r($qw);
            
        }
        catch( \Exception $e )
        {               
            return $spicastinfo;
        }    
        return $spicastinfo;
    }
    
    public static function getQmsportdetails($data)
    {    
        $spicastinfo        =   false;   
        try
        {
            $spicastinfo    =   jobModel::select(DB::raw('job.JOB_ID,job.BOOK_ID,job.JOB_TITLE,job_info.JOB_ID as jobid,job_info.AUTHOR_EMAIL,job_info.ISSN_ONLINE,job.CREATED_DATE,job_info.SPICAST_STATUS,job_info.PRR_REPORT_STATUS,job_info.PE_MAIL'))
				->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->where('job.IS_ACTIVE',1)
                                ->where($data)->first();        
            
        }
        catch( \Exception $e )
        {               
            return $spicastinfo;
        }    
        return $spicastinfo;
    }
    
    public static function getConsolitedetails($data    =   [])
    {    
        $spicastinfo        =   false;   
        try
        {
            DB::enableQueryLog();
            $spicastinfo    =   jobModel::select(DB::raw('job.JOB_ID,job.BOOK_ID,job.JOB_TITLE,job_info.JOB_ID as jobid,job_info.AUTHOR_EMAIL,job_info.EDITOR_NAME,job_info.AUTHOR_NAME,job_info.ISSN_ONLINE,job.CREATED_DATE,job_info.SPICAST_STATUS,job_info.PRR_REPORT_STATUS,job_info.PE_MAIL,apidwld.ROUND as cround,
                    afu.ID as afuID,afu.STATUS as afuSTATUS,afu.REMARKS as afuREMARKS,afu.ROUND as afuROUND,aca.ID as acaID,aca.STATUS as acaSTATUS,aca.REMARKS as acaREMARKS,aca.ROUND as acaROUND'))
				->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin('api_download as apidwld',function($join)
                                {
                                    $join->on('apidwld.BOOK_ID', '=', 'job.BOOK_ID');
                                    $join->where('apidwld.ID',DB::raw('(select max(ID) from api_download WHERE api_download.ROUND = '.\Config::get('constants.ROUND_ID.S50').' and job.BOOK_ID = api_download.BOOK_ID and IS_COMPLETED = true and IS_ACTIVE = true )'));
                                })
								->leftjoin('api_file_upload as afu',function($join)
                                {
                                    $join->on('afu.JOB_ID', '=', 'job.JOB_ID');
                                    $join->where('afu.ID',DB::raw('(select max(ID) from api_file_upload WHERE api_file_upload.ROUND = '.\Config::get('constants.ROUND_ID.S50').' and job.JOB_ID = api_file_upload.JOB_ID and PROCESS_TYPE = 2 )'));
                                })
                                ->leftjoin('api_client_acknowledgement as aca',function($join)
                                {
                                    $join->on('aca.JOB_ID', '=', 'job.JOB_ID');
                                    $join->where('aca.ID',DB::raw('(select max(ID) from api_client_acknowledgement WHERE api_client_acknowledgement.ROUND = '.\Config::get('constants.ROUND_ID.S50').' and job.JOB_ID = api_client_acknowledgement.JOB_ID and PROCESS_TYPE_DIFF = 2 )'));
                                })
                                ->where($data)->get();        
            $qw     =       DB::getQueryLog();
          //print_r($qw);exit;
        }
        catch( \Exception $e )
        {               
            return $spicastinfo;
        }    
        return $spicastinfo;
    }
    
    public static function checkExistbookjob($jobId = null,$book = null){
        
        $bookinfo 		=	array();
        
        try{
            $bookinfo   =   jobModel::where('JOB_ID',$jobId)
                                        ->where('BOOK_ID',$book)
                                        ->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
        
    }
    
    public function getJobListForArtWork(){
        
        $job_list           =           array();
        
        try{
           //DB::enableQueryLog();
            $job_list       =    jobModel::select( DB::RAW( 'job.*,job_info.* , concat( usr.FIRST_NAME , " " , usr.LAST_NAME )  as PM_NAME ' ) )
                                ->join( 'job_info' , 'job.JOB_ID' , '=' , 'job_info.JOB_ID' )
                                ->join( 'user as usr' , 'usr.USER_ID' , '=' , 'job.PM' )
                                ->where( 'job.STATUS' , '=' , '1'  )
                                ->whereNotNull('job_info.LOCATION')
                                ->orWhere('job_info.LOCATION','!=',"")
                                ->get();
           //$qw     =       DB::getQueryLog($job_list);
           //print_r($qw);  
        }catch( \Exception $e ){
            
            return $job_list;
        }   
        
        return $job_list;
        
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){

       $updateQry  =       false;
       $time       =       date( 'Y-m-d H:i:s' );
        
       /*$setArr     =      array( 
                                    'CREATED_DATE' => $time  ,
                                    'LAST_MOD_DATE' => $time ,
                                );*/
								
		$setArr     =      array( 
                                   'LAST_MOD_DATE' => $time ,
                                );

       if( !is_null( $rowid ) ){
        $updateQry  =   DB::table('job')
                        ->where('JOB_ID', $rowid )
                        ->update( $setArr );
       }
       return $updateQry;

   }
    
    public function scopeActive($query) {
        return $query->where('job.IS_ACTIVE', 1);
    }
}

