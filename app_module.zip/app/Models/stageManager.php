<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Http\Controllers\CommonMethodsController;
use Session;

class stageManager extends Model {
    
   
    public static function getStageInfo( $jobStageId){

        $sql = 'SELECT js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID
                FROM job_stage js
                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                LEFT OUTER
                JOIN round_enum r ON r.ID = jr.ROUND_ID
                LEFT OUTER
                JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                WHERE js.JOB_STAGE_ID IN ('.$jobStageId.')';
        
        $getRec        =   DB::select( $sql );
        
        return $getRec;
      
    }
    
    public static function getAutoStageInformation($metaId, $round){
        
        $cstge = "SELECT js.JOB_STAGE_ID
                                FROM job_stage js
                                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                                where jr.METADATA_ID=".$metaId." and jr.ROUND_ID=".$round." and js.`STATUS`=23";
          $getRec        =   DB::select( $cstge );
        
        return $getRec;
        
    }
    
    function autoStageMovement($metaId, $round, $endTime, $remarks, $stgSeq){
	/** Not required **/
	
    }
    
   
    
}

