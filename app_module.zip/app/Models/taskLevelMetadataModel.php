<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Models\chapterPartMapModel;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class taskLevelMetadataModel extends Model 
{    
    protected $table    =   'task_level_metadata';
    protected $primaryKey   =   'METADATA_ID';
    const UPDATED_AT    =   "LAST_MOD_DATE";
    public static function insertNew( $inp_arr ){
    
       $ins_obj        =       new taskLevelMetadataModel();
        
       if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $ins_obj->$index    =   $value;
                
            }
            
        }
        
        $table_name         =       'task_level_metadata';
       
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
        
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
        
    }
    
    public function scopeActive($query)
    {
        return $query->where('task_level_metadata.IS_ACTIVE', 1);
    }
    
    public function scopeNotunitmeasure($query)
    {
        return $query->where('task_level_metadata.UNIT_OF_MEASURE','!=', Config::get('constants.UNIT_OF_MEASURE'));
    }
    
    public static function searchchapterDetails($jobID = null,$metadataID = '')
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.JOB_ID,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_NAME,metadata_info.FM_ARTICLE_BM'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                                ->where(function ($query) use ($metadataID) {
                                                                    if (trim($metadataID) != '') {
                                                                        return $query->Where('task_level_metadata.METADATA_ID', $metadataID);
                                                                    }
                                                                })
                                                                ->where('task_level_metadata.JOB_ID',$jobID)
								->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getMetadatadetailsChapter($meatadataId = null)
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$meatadataId)
								->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getMetadatadetailsChapterwithbook($meatadataId = null)
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$meatadataId)
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    
    public static function getMetadatadetailsChapterBook($meatadataId = null)
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$meatadataId)
								->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function checkexistbookandChapter($jobid = null, $meatadataId = null)
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'job' , 'job.JOB_ID', '=', 'task_level_metadata.JOB_ID')
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$meatadataId)
								->where('job.JOB_ID',$jobid)
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->get();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getalleproofdetailslist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
            DB::enableQueryLog();
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.EPROOFING_SYSTEM,task_level_metadata.EPROOFING_RECIPIENT,task_level_metadata.ADDITIONAL_RECIPIENT,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                            ->where('metadata_info.FM_ARTICLE_BM','=',Config::get('constants.ARTICLE_CHAPTER'))
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.METADATA_ID')
                                                            ->orderBy('CHAPTER_SEQ','asc')
                                                            ->get();      
            $a  =   DB::getQueryLog($cucinfo);
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getbookChapteranduserinfo($jobid = null, $meatadataId = null)
    {    
        $bookinfo       =   array();
        
        try{
            
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME,task_level_metadata.*,metadata_info.*'))
                            	->join( 'job' , 'job.JOB_ID', '=', 'task_level_metadata.JOB_ID')
                                ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                ->where('task_level_metadata.METADATA_ID',$meatadataId)
                                ->where('job.JOB_ID',$jobid)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->where('job.IS_ACTIVE',1)
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        return $bookinfo;
    }
    
    public static function getMetadatadetailsChapterwithjob($meatadataId = null)
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.METADATA_ID',$meatadataId)
                                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->first();               
            
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getMetadatadetailsJob($jobId = null){
        
        $bookinfo 		=	array();
        
        try{     
            
            $bookinfo   =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->where('task_level_metadata.JOB_ID',$jobId)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                ->get();  
            
        }catch( \Exception $e ){           
            return false;
        }
        
	return $bookinfo;   
    }
    
    public static function getDownloadedChapterdetails($jobId = null){
        
        $bookinfo 		=	array();
        
        try{     
            
            $bookinfo   =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.JOB_ID,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_NAME'))
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->join( 'api_download' , 'api_download.METADATA_ID', '=', 'task_level_metadata.METADATA_ID')
                                ->where('task_level_metadata.JOB_ID',$jobId)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                ->groupBy('api_download.METADATA_ID')
                                ->get();  
            
        }catch( \Exception $e ){           
            return false;
        }
        
	return $bookinfo;   
    }
    
    public static function getMetadatadetailsJobPreproduction($jobId = null){
        
        $bookinfo 		=	array();
        
        try{     
            
            $bookinfo   =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->where('task_level_metadata.JOB_ID',$jobId)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                    
                                ->get();  
            
        }catch( \Exception $e ){           
            return false;
        }
        
	return $bookinfo;
        
    }
    
    
    public static function getremaindermailsetupjoblist($start,$length,$searchStr,$orderColumn,$sorting)
    {    
        $bookinfo 		=	array();
        
		try{
			
            $columnArray    =   [];
            $columnArray[]  =   'job.JOB_TITLE';
            $columnArray[]  =   'job.BOOK_ID';
            $columnArray[]  =   DB::raw('concat(u.FIRST_NAME," ",u.LAST_NAME)');
            $columnArray[]  =   'job.CREATED_DATE';
            
            $bookinfo['countbookinfo']  =   bookinfoModel::select(DB::raw('job.JOB_ID'))
                                            ->join('job_info', 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->leftjoin('user as u', 'job.PM', '=', 'u.USER_ID')
                                            ->where('job.IS_ACTIVE', Config::get('constants.STATUS_ENUM.ONE'))
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                            })
                                            ->count();
             
            $bookinfo['bookdetails']    =   bookinfoModel::select(DB::raw( 'job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME ,IF( job_info.EPROOFING_SYSTEM=1, "E-PROOF" ,  "APS" ) as EPROOFING_SYSTEM' ))
                ->join('job_info', 'job.JOB_ID', '=', 'job_info.JOB_ID')
                ->leftjoin('user as u', 'job.PM', '=', 'u.USER_ID')
                ->where('job.IS_ACTIVE', Config::get('constants.STATUS_ENUM.ONE'))
                ->orderBy($columnArray[$orderColumn], $sorting)
                ->when($searchStr, function ($query) use ($searchStr) {
                                    return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                        ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                })
                ->skip($start)->take($length)
                ->get();
            
        }catch( \Exception $e ){
			
            return false;
			
        }
	
        return $bookinfo;
        
    } 
    
	public static function getremaindermailsetupjoblist2( $jobID , $roundid , $metaid ){
		
		$bookinfo       =   array();   
        
		try{   
			
			$remaindertype		=		Config::get('constants.REMAINDER_TYPE.EPROOF');
			$stsOne				=		Config::get('constants.STATUS_ENUM.ONE');
			
            $bookinfo   =   "SELECT acd.ID as CRCID,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,tlm.EPROOFING_SYSTEM,
                        tlm.EPROOFING_RECIPIENT,tlm.ADDITIONAL_RECIPIENT,tlm.CHAPTER_NO,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,erl.FIRST_REMAINDER,erl.SECOND_REMAINDER,erl.THIRD_REMAINDER,erl.BODY_OF_MAIL,aps.ID as APSID,aps.ROUND AS ROUND_ID,DATE_FORMAT(aps.CORRECTION_DUE, '%Y-%m-%d') as CORRECTION_DUE,DATE_FORMAT(aps.FIRST_CORRECTION_DUE, '%Y-%m-%d') as FIRST_CORRECTION_DUE,DATE_FORMAT(aps.SECOND_CORRECTION_DUE, '%Y-%m-%d') as SECOND_CORRECTION_DUE,DATE_FORMAT(aps.THIRD_CORRECTION_DUE, '%Y-%m-%d') as THIRD_CORRECTION_DUE,
                        remonoff.ID as REMAINDER_ID,erl.ID as EMAIL_ID 
                        FROM `task_level_metadata` tlm                        
                        join metadata_info mi on mi.METADATA_ID = tlm.METADATA_ID                        
                        join job jb on jb.JOB_ID = tlm.JOB_ID                        
                        join job_info jbinfo on jbinfo.JOB_ID = jb.JOB_ID                        
                        LEFT JOIN email_remainder_log erl on erl.METADATA_ID = tlm.METADATA_ID AND erl.JOB_ID = tlm.JOB_ID AND erl.REMAINDER_TYPE   =   ".$remaindertype." AND  erl.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog WHERE emaillog.REMAINDER_TYPE   =   ".$remaindertype." AND erl.METADATA_ID = emaillog.METADATA_ID group by emaillog.METADATA_ID)                          
                        LEFT JOIN remainder_email_onoff remonoff on remonoff.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = ".$roundid." AND remonoff.REMAINDER_TYPE = ".$remaindertype."
                        AND remonoff.IS_ACTIVE  =   '".$stsOne."' AND remonoff.ID = ( select MAX(ID) as rid from remainder_email_onoff remonoff1 WHERE remonoff.METADATA_ID = remonoff1.METADATA_ID AND remonoff1.IS_ACTIVE = '".$stsOne."' group by remonoff1.METADATA_ID )                            
                        LEFT JOIN api_correction_download_mono acd ON acd.METADATA_ID = tlm.METADATA_ID AND acd.ROUND_ID = ".$roundid." AND acd.ID = ( SELECT MAX(id) AS erlid FROM api_correction_download_mono acd2 WHERE acd2.METADATA_ID = acd.METADATA_ID and acd2.ROUND_ID = acd.ROUND_ID GROUP BY acd2.METADATA_ID )
                        LEFT JOIN api_proofing_status aps on aps.METADATA_ID = tlm.METADATA_ID AND aps.ROUND = ".$roundid." AND aps.ID = ( select MAX(ID) as apsid from api_proofing_status apsemail WHERE aps.METADATA_ID = apsemail.METADATA_ID AND apsemail.STATUS = '".Config::get('constants.STATUS_ENUM.SUCCESS')."' AND 
                        apsemail.ROUND = ".$roundid."   group by apsemail.METADATA_ID )                             
                        WHERE `tlm`.`IS_ACTIVE` = '".$stsOne."' AND jbinfo.EPROOFING_SYSTEM = '".$remaindertype."'  
						AND tlm.JOB_ID   =   ".$jobID." AND `tlm`.`UNIT_OF_MEASURE` = ".Config::get('constants.UNIT_OF_MEASURE')." and tlm.METADATA_ID = $metaid
                        GROUP BY tlm.JOB_ID order by tlm.CHAPTER_SEQ desc";
						
				//exit;		//AND `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')." AND tlm.JOB_ID   =   ".$jobID." and mi.FM_ARTICLE_BM != '".Config::get('constants.FM_ARTICLE_BM')."'
            
            $bookinfo   =   DB::select( $bookinfo );
			
        }catch( \Exception $e ){      
		
            return false;
	
        }
		
		return $bookinfo;  
	
	}
	
    public static function getremaindermailsetupchapterlist( $jobID , $roundid ) {
		
        $bookinfo       =   array();   
        
		try{   
			
			$remaindertype		=		Config::get('constants.REMAINDER_TYPE.EPROOF');
			$stsOne				=		Config::get('constants.STATUS_ENUM.ONE');
			
            $bookinfo   =   "SELECT acd.ID as CRCID,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,tlm.EPROOFING_SYSTEM,
                        tlm.EPROOFING_RECIPIENT,tlm.ADDITIONAL_RECIPIENT,tlm.CHAPTER_NO,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,erl.FIRST_REMAINDER,erl.SECOND_REMAINDER,erl.THIRD_REMAINDER,erl.BODY_OF_MAIL,aps.ID as APSID,aps.ROUND AS ROUND_ID,DATE_FORMAT(aps.CORRECTION_DUE, '%Y-%m-%d') as CORRECTION_DUE,DATE_FORMAT(aps.FIRST_CORRECTION_DUE, '%Y-%m-%d') as FIRST_CORRECTION_DUE,DATE_FORMAT(aps.SECOND_CORRECTION_DUE, '%Y-%m-%d') as SECOND_CORRECTION_DUE,DATE_FORMAT(aps.THIRD_CORRECTION_DUE, '%Y-%m-%d') as THIRD_CORRECTION_DUE,
                        remonoff.ID as REMAINDER_ID,erl.ID as EMAIL_ID 
                        FROM `task_level_metadata` tlm                        
                        join metadata_info mi on mi.METADATA_ID = tlm.METADATA_ID                        
                        join job jb on jb.JOB_ID = tlm.JOB_ID                        
                        join job_info jbinfo on jbinfo.JOB_ID = jb.JOB_ID                        
                        LEFT JOIN email_remainder_log erl on erl.METADATA_ID = tlm.METADATA_ID AND erl.JOB_ID = tlm.JOB_ID AND erl.REMAINDER_TYPE   =   ".$remaindertype." AND  erl.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog WHERE emaillog.REMAINDER_TYPE   =   ".$remaindertype." AND erl.METADATA_ID = emaillog.METADATA_ID group by emaillog.METADATA_ID)                          
                        LEFT JOIN remainder_email_onoff remonoff on remonoff.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = ".$roundid." AND remonoff.REMAINDER_TYPE = ".$remaindertype."
                        AND remonoff.IS_ACTIVE  =   '".$stsOne."' AND remonoff.ID = ( select MAX(ID) as rid from remainder_email_onoff remonoff1 WHERE remonoff.METADATA_ID = remonoff1.METADATA_ID AND remonoff1.IS_ACTIVE = '".$stsOne."' group by remonoff1.METADATA_ID )                            
                        LEFT JOIN api_correction_download acd ON acd.METADATA_ID = tlm.METADATA_ID AND acd.ROUND = ".$roundid." AND acd.ID = ( SELECT MAX(id) AS erlid FROM api_correction_download acd2 WHERE acd2.METADATA_ID = acd.METADATA_ID and acd2.ROUND = acd.ROUND GROUP BY acd2.METADATA_ID )
                        LEFT JOIN api_proofing_status aps on aps.METADATA_ID = tlm.METADATA_ID AND aps.ROUND = ".$roundid." AND aps.ID = ( select MAX(ID) as apsid from api_proofing_status apsemail WHERE aps.METADATA_ID = apsemail.METADATA_ID AND apsemail.STATUS = '".Config::get('constants.STATUS_ENUM.SUCCESS')."' AND 
                        apsemail.ROUND = ".$roundid."   group by apsemail.METADATA_ID )                             
                        WHERE `tlm`.`IS_ACTIVE` = '".$stsOne."' AND jbinfo.EPROOFING_SYSTEM = '".$remaindertype."'  
						AND tlm.JOB_ID   =   ".$jobID." and mi.FM_ARTICLE_BM in (2) and `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')."
                        GROUP BY tlm.METADATA_ID order by tlm.CHAPTER_SEQ desc";
						
						//AND `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')." AND tlm.JOB_ID   =   ".$jobID." and mi.FM_ARTICLE_BM != '".Config::get('constants.FM_ARTICLE_BM')."'
            
            $bookinfo   =   DB::select($bookinfo);
			
        }catch( \Exception $e ){           
            return false;
        }
	return $bookinfo;   
    }
    
    public static function getremaindermaillist()
    {    
        $bookinfo       =   array();   
        try{      
		
            $bookinfo   =   "SELECT acd.ID AS CRCRECIVEDORNOT,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                        IF( DATE_ADD( date(asps.FIRST_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now()), 1 , 0 ) as REM1  ,
                        IF( DATE_ADD( date(asps.SECOND_CORRECTION_DUE) , INTERVAL  0 DAY) = DATE(now()),  1 , 0 ) as REM2  ,
                        IF( DATE_ADD( date(asps.THIRD_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now()), 1 , 0 ) as REM3  ,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,tlm.EPROOFING_SYSTEM,
                        tlm.EPROOFING_RECIPIENT,tlm.ADDITIONAL_RECIPIENT,tlm.CHAPTER_NO,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,asps.*,asps.ID as APS_ID,apsemaillog.FIRST_REMAINDER,apsemaillog.SECOND_REMAINDER,apsemaillog.THIRD_REMAINDER,apsemaillog.ID as APSEMAILLOG_ID
                        FROM `task_level_metadata` tlm
                        
                        join api_proofing_status asps on asps.METADATA_ID = tlm.METADATA_ID
                        INNER JOIN (select MAX(id) as idm, METADATA_ID from api_proofing_status  group by api_proofing_status.METADATA_ID)  AS aps ON aps.METADATA_ID = asps.METADATA_ID
                        AND aps.idm = asps.ID
                        
                        join remainder_email_onoff remonoff on remonoff.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = ".Config::get('constants.ROUND_ID.S300')." AND remonoff.REMAINDER_TYPE = ".Config::get('constants.REMAINDER_TYPE.EPROOF')."
                        AND remonoff.IS_ACTIVE  =   '".Config::get('constants.STATUS_ENUM.ONE')."' AND remonoff.ID = (select MAX(ID) as rid from remainder_email_onoff remonoff1 where remonoff.METADATA_ID = remonoff1.METADATA_ID AND remonoff1.IS_ACTIVE = '".Config::get('constants.STATUS_ENUM.ONE')."'
                            group by remonoff1.METADATA_ID)
                        
                        LEFT JOIN api_correction_download acd ON acd.METADATA_ID = tlm.METADATA_ID AND acd.ROUND = ".Config::get('constants.ROUND_ID.S300')." AND acd.ID = 
                        (SELECT MAX(id) AS erlid FROM api_correction_download acd2 WHERE acd2.METADATA_ID = acd.METADATA_ID AND acd2.ROUND = acd.ROUND GROUP BY acd2.METADATA_ID)
                            
                        left join email_remainder_log apsemaillog on apsemaillog.METADATA_ID = tlm.METADATA_ID AND apsemaillog.JOB_ID = tlm.JOB_ID AND apsemaillog.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.EPROOF')." AND  apsemaillog.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog where emaillog.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.EPROOF')." AND apsemaillog.METADATA_ID = emaillog.METADATA_ID group by emaillog.METADATA_ID)  
                            
                        WHERE `tlm`.`IS_ACTIVE` = 1 AND `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')."
                        AND
                        (
                        IF( DATE_ADD( date(asps.FIRST_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now() ) , 1 , 0 ) = 1
                        or IF( DATE_ADD( date(asps.SECOND_CORRECTION_DUE) , INTERVAL  0 DAY) = DATE(now() ) , 1 , 0 ) = 1
                        or IF( DATE_ADD( date(asps.THIRD_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now() ) , 1 , 0 ) = 1
                        )
                        GROUP BY asps.METADATA_ID ORDER BY asps.ID DESC";
            
            $bookinfo   =   DB::select($bookinfo);
        }catch( \Exception $e ){           
            return false;
        }
	return $bookinfo;   
    }
    
	
    public static function getS650RemainderList()
    {    
        $bookinfo       =   array();  
		
        try{     
		
			$s650		=	Config::get('constants.ROUND_ID.S650');
			$eproof		=	Config::get('constants.REMAINDER_TYPE.EPROOF');
			$stsOne		=	Config::get('constants.STATUS_ENUM.ONE');
		
			$bookinfo   =   "SELECT acd.ID AS CRCRECIVEDORNOT,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                        IF( DATE_ADD( date(asps.FIRST_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now()), 1 , 0 ) as REM1  ,
                        IF( DATE_ADD( date(asps.SECOND_CORRECTION_DUE) , INTERVAL  0 DAY) = DATE(now()),  1 , 0 ) as REM2  ,
                        IF( DATE_ADD( date(asps.THIRD_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now()), 1 , 0 ) as REM3  ,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,tlm.EPROOFING_SYSTEM,
                        tlm.EPROOFING_RECIPIENT,tlm.ADDITIONAL_RECIPIENT,tlm.CHAPTER_NO,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,asps.*,asps.ID as APS_ID,apsemaillog.FIRST_REMAINDER,apsemaillog.SECOND_REMAINDER,apsemaillog.THIRD_REMAINDER,apsemaillog.ID as APSEMAILLOG_ID
                        FROM `task_level_metadata` tlm
                        
                        JOIN api_proofing_status asps on asps.JOB_ID = tlm.JOB_ID
                        INNER JOIN (                         
									select MAX(id) as idm, JOB_ID , ROUND AS ROUND_ID from api_proofing_status WHERE ROUND = 120 group by api_proofing_status.JOB_ID
								)  AS aps 
									ON aps.JOB_ID = asps.JOB_ID and aps.ROUND_ID = asps.ROUND
                       		AND aps.idm = asps.ID
                        	join remainder_email_onoff remonoff on remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = 120 
									AND remonoff.REMAINDER_TYPE = 1
                        	AND remonoff.IS_ACTIVE  =   '1' AND remonoff.ID = ( 
										select MAX(ID) as rid from remainder_email_onoff remonoff1 
										where remonoff.JOB_ID = remonoff1.JOB_ID AND remonoff.ROUND_ID = 120 
										AND remonoff1.IS_ACTIVE = '1'
	                        	group by remonoff1.JOB_ID 
								)
                        
                        LEFT JOIN api_correction_download_mono acd ON acd.JOB_ID = tlm.JOB_ID AND acd.ROUND_ID = 120 AND acd.ID = 
                        (SELECT MAX(id) AS erlid FROM api_correction_download_mono acd2 WHERE acd2.JOB_ID = acd.JOB_ID AND acd2.ROUND_ID = acd.ROUND_ID GROUP BY acd2.JOB_ID )
                            
                        left join email_remainder_log apsemaillog on apsemaillog.JOB_ID = tlm.JOB_ID AND apsemaillog.JOB_ID = tlm.JOB_ID AND apsemaillog.REMAINDER_TYPE   =   1 AND  apsemaillog.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog where emaillog.REMAINDER_TYPE   =   1 AND apsemaillog.JOB_ID = emaillog.JOB_ID group by emaillog.JOB_ID)  
                           
                        WHERE `tlm`.`IS_ACTIVE` = 1 AND  remonoff.ROUND_ID = 120 
                       
                        GROUP BY asps.JOB_ID ORDER BY asps.ID DESC";
						
						/*
						 AND
	                        (
								IF( DATE_ADD( date(asps.FIRST_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now() ) , 1 , 0 ) = 1
								or IF( DATE_ADD( date(asps.SECOND_CORRECTION_DUE) , INTERVAL  0 DAY) = DATE(now() ) , 1 , 0 ) = 1
								or IF( DATE_ADD( date(asps.THIRD_CORRECTION_DUE) , INTERVAL 0 DAY) = DATE(now() ) , 1 , 0 ) = 1
	                        )
                        
						*/
            
            $bookinfo   =   DB::select($bookinfo);
			
        }catch( \Exception $e ){ 
		
            return false;
			
        }
		
		return $bookinfo;   
	
    }
    
	
    public static function getreportofconsolidate($typeofarticle   =   null, $jobId     =   null)
    {    
        $resultinfo     =   array();   
        try{                 
            DB::enableQueryLog();
            $resultinfo     =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,task_level_metadata.*,metadata_info.*,tmd.METADATA_ID as part_Id,tmd.CHAPTER_NO as part_name,pm.CHAPTER_PART_ID,pm.CHAPTER_METADATA_ID,pm.PART_METADATA_ID,count(mesm.METADATA_ID) as TOTALESM'))
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->leftjoin('part_mapping as pm',function($join)
                                {
                                    $join->on('pm.CHAPTER_METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                    $join->on('task_level_metadata.JOB_ID', '=', 'pm.JOB_ID');
                                    $join->where('pm.STATUS',true);
                                })
                                ->leftjoin('metadata_esm as mesm',function($join)
                                {
                                    $join->on('mesm.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                    $join->on('mesm.JOB_ID', '=', 'task_level_metadata.JOB_ID');
                                    $join->where('mesm.IS_DELETED',false);
                                })
                                ->leftjoin( 'task_level_metadata as tmd' , 'tmd.METADATA_ID', '=', 'pm.PART_METADATA_ID')
                                ->where('task_level_metadata.JOB_ID',$jobId)
                                ->where('metadata_info.FM_ARTICLE_BM','=',$typeofarticle)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                ->groupBy('task_level_metadata.METADATA_ID')
                                ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                ->get(); 
            
            
        }catch( \Exception $e ){           
            return false;
        }
	return $resultinfo;   
    }
    
    public static function getChapterWithoutPart($jobId){
        
         DB::enableQueryLog();
        $resultinfo     =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,task_level_metadata.*,metadata_info.*,tmd.METADATA_ID as part_Id,tmd.CHAPTER_NO as part_name,pm.CHAPTER_PART_ID,pm.CHAPTER_METADATA_ID,pm.PART_METADATA_ID,count(mesm.METADATA_ID) as TOTALESM'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                                ->leftjoin('part_mapping as pm',function($join)
                                                                {
                                                                    $join->on('pm.CHAPTER_METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                    $join->on('task_level_metadata.JOB_ID', '=', 'pm.JOB_ID');
                                                                    $join->where('pm.STATUS',true);
                                                                })
                                                                ->leftjoin('metadata_esm as mesm',function($join)
                                                                {
                                                                    $join->on('mesm.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                    $join->on('mesm.JOB_ID', '=', 'task_level_metadata.JOB_ID');
                                                                    $join->where('mesm.IS_DELETED',false);
                                                                })
                                                                ->leftjoin( 'task_level_metadata as tmd' , 'tmd.METADATA_ID', '=', 'pm.PART_METADATA_ID')
								->where('task_level_metadata.JOB_ID',$jobId)
                                                                ->where('metadata_info.FM_ARTICLE_BM','=',2)
                                                                ->whereNull('pm.CHAPTER_METADATA_ID')
								->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->groupBy('task_level_metadata.METADATA_ID')
                                                                ->orderBy('task_level_metadata.CHAPTER_NO','asc')
                                                                ->get();
        return $resultinfo;   
                                                                
        //$ss =  DB::getQueryLog($resultinfo);
       // print_r($ss);exit;
    } 
    
    public static function getchapterlistagainpart($partid  =   null,$jobId     =   null)
    {    
        $resultinfo     =   array();   
        try{ 
                $resultinfo     =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,task_level_metadata.*,metadata_info.*,tmd.METADATA_ID as part_Id,tmd.CHAPTER_NO as part_name,pm.CHAPTER_PART_ID,pm.CHAPTER_METADATA_ID,pm.PART_METADATA_ID,count(mesm.METADATA_ID) as TOTALESM'))
                                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                ->join('part_mapping as pm',function($join)
                                                {
                                                    $join->on('pm.CHAPTER_METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                    $join->on('task_level_metadata.JOB_ID', '=', 'pm.JOB_ID');
                                                    $join->where('pm.STATUS',true);
                                                })
                                                ->leftjoin('metadata_esm as mesm',function($join)
                                                    {
                                                        $join->on('mesm.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                        $join->on('mesm.JOB_ID', '=', 'task_level_metadata.JOB_ID');
                                                        $join->where('mesm.IS_DELETED',false);
                                                    })
                                                ->leftjoin( 'task_level_metadata as tmd' , 'tmd.METADATA_ID', '=', 'pm.PART_METADATA_ID')
                                                ->where('task_level_metadata.JOB_ID',$jobId)
                                                ->where('task_level_metadata.IS_ACTIVE',true)
                                                ->where('pm.PART_METADATA_ID',$partid)
                                                ->where('metadata_info.FM_ARTICLE_BM','=','2')
                                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                ->groupBy('pm.CHAPTER_METADATA_ID')
                                                ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                                ->get(); 
        }catch( \Exception $e ){           
            return false;
        }
	return $resultinfo;   
    }  
                                                                
    

    public static function doAddTaskLevelmetadata($chapter = [],$getchapternumber =    [],$chaptersequence = [],$partnames = [],$jobID = null,$bookid = null,$chpatetile,$getchapterpagecount)
    {
       
        $result         =	[];
        $chapterexist   =	[];
        $addresult      =	false;
        $map_arr_bf         =       array();
        $map_arr_af         =       array();
        $part_meta_arr           =       array();
        $insertTlmStatus        =   array();
        $insertMiStatus     =   '';
        $insertMapStatus       =   '';
        
        try
        {
            if(count($chapter)>=1)
            {
                $taskmetadata                       =	array();
                $inpArr                             =   array();
                foreach($chapter as $key=>$val)
                {   
//                    $taskmetadata['CHAPTER_NAME']   =   trim($getchapternumber[$key]);
                    $taskmetadata['CHAPTER_NO']     =   ucfirst($val);
                    if(!empty($chpatetile[$key])){
                        $taskmetadata['CHAPTER_NAME']   =   $chpatetile[$key];
                    }
                    $taskmetadata['UNIT_OF_MEASURE']=   \Config::get('constants.CHAPTER_ENUM_ID');//chapter unit_enum id
                    $taskmetadata['CURRENT_ROUND']  =   \Config::get('constants.ROUND_ID.S5');//chapter unit_enum id
                    $taskmetadata['JOB_ID']         =   $jobID;
                    $taskmetadata['IS_ACTIVE']      =   true;
                    $taskmetadata['CHAPTER_SEQ']    =   $chaptersequence[$key];
                    $taskmetadata['CREATED_DATE']   =   Carbon::now();
                    
                    if(!empty($getchapterpagecount[$key])){
                       $taskmetadata['QUANTITY']       =   $getchapterpagecount[$key];
                    }else{
                      $taskmetadata['QUANTITY']       =   '1';  
                    }
                    
                    $taskmetadata['CREATED_BY']     =   Session::get('users')['user_id'];     
                   
                    if(strpos(strtolower($val),strtolower(Config::get('constants.CHECK_PART'))) !== false){
                        $insertTlmStatus        =   $addresult                  =   DB::table('task_level_metadata')->insertGetId($taskmetadata);
                        if( !empty($partnames[$key]) )
                            $map_arr_bf[$insertTlmStatus]   =       $partnames[$key];
                        
                        $part_meta_arr[$val]    =   $insertTlmStatus;
                                               
                    }else{
                        $insertTlmStatus       =   $addresult                  =   DB::table('task_level_metadata')->insertGetId($taskmetadata);
                        if( !empty($partnames[$key]) )
                            $map_arr_bf[$insertTlmStatus]   =       $partnames[$key];
                    }
                    if($addresult >=	1){
                        
                        $insertrec              =   array(  
                                                            'METADATA_ID'=> $addresult ,
                                                            'LAST_MOD_DATE'=>Carbon::now(),
                                                            'LAST_MOD_BY'=>\Session::get('users')['user_id']
                                                         );
                      /*  if(in_array($val,$getesm)){
                            $insertrec['ESM']     =   1; 
                        }*/
                        

                        if(strpos(strtolower($val),strtolower(Config::get('constants.CHECK_PART'))) !== false){                             
                           $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.FM_ARTICLE_BM');                            
                        }

                        if(strpos( strtolower($val),strtolower(Config::get('constants.CHECK_FM'))) !== false){

                           $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.ARTICLE_FM');

                        }
 
                       if(strpos( strtolower($val),strtolower(Config::get('constants.CHECK_BM'))) !== false){

                           $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.ARTICLE_BM');
                        }
                        
                         if(!empty($getchapterpagecount[$key])){
                            $insertrec['NO_MSP']   =   $getchapterpagecount[$key];
                         }
                       
                        //insert meta info details
                        $insertMiStatus       =       DB::table('metadata_info')->insert($insertrec);
                       
                    }
                    unset($inpArr);
                    unset($taskmetadata);
                    
                }
                
                foreach( $map_arr_bf as $key => $value ){ 
                    if( !empty( $value ) ){
                        $inpArrMap['CHAPTER_METADATA_ID']   =   $key;
                        $inpArrMap['JOB_ID']                =   $jobID;
                        $inpArrMap['PART_METADATA_ID']      =   $part_meta_arr[$value];
                        $inpArrMap['CREATED_AT']            = 	Carbon::now();
                        $inpArrMap['CREATED_BY']            = 	\Session::get('users')['user_id'];
                        DB::table('part_mapping')->insertGetId( $inpArrMap );
                    }
               }     
            }
          
        }
        catch( \Exception $e ){ 
            $result['result']	 =	0;
            $result['chapter']	 =	$chapterexist;
            
          return $result;
        }
        
        $result['result']	 =	1;
        $result['chapter']	 =	$chapterexist;
        
        return $result;
    }
    
    //check exist job id
    public static function checkexistjob($jobId 	=	null)
    {
        return DB::table('job')->where('IS_ACTIVE',true)->where('JOB_ID',$jobId)->first();
    }
    
    public function getChapterListByJobid( $jobId = null  , $lm_start = null  , $lm_end = null ){
        
            $tbl            =       $this->table;
            $select_field   =       '';
            
            $getInfo        =       array();
            $cur_round      =       Config::get('constants.ROUND_ID');
            $cur_round      =       $cur_round['S5'];
            $response   =   array();
            
            if( !is_null( $jobId ) ){
            
                if( !is_null( $lm_start ) && !is_null( $lm_end ) || true ){

                $query_stmt      =         'select tlmd.METADATA_ID , tlmd.CHAPTER_SEQ,tlmd.JOB_ID, tlmd.CHAPTER_NO ,jts.ROUND_ID as CURRENT_ROUND,tlmd.CURRENT_ROUND as metaRound, jf.LOCATION, jts.JOB_TIME_SHEET_ID as jbtid , jts.CHECK_IN , jts.status,ca.`STATUS` as clientstatus  from task_level_metadata tlmd'
                                             .' join job as j on j.JOB_ID = tlmd.JOB_ID'
                                             .' join job_info as jf on jf.JOB_ID = j.JOB_ID'
                                             .' LEFT join api_client_acknowledgement as ca on ca.JOB_ID = j.JOB_ID and tlmd.METADATA_ID=ca.METADATA_ID and ca.status = 2'
                                            .' left join job_time_sheet jts on tlmd.METADATA_ID = jts.METADATA_ID and jts.JOB_TIME_SHEET_ID =  (select max(jts2.JOB_TIME_SHEET_ID) from job_time_sheet jts2 WHERE jts2.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION')
                                            .' and  jts2.ROUND_ID IN ( '.\Config::get('constants.ROUND_ID.S5').','.\Config::get('constants.ROUND_ID.S200').' ) and tlmd.METADATA_ID = jts2.METADATA_ID )'
                                            .' where tlmd.JOB_ID = '.$jobId.' and tlmd.UNIT_OF_MEASURE !=556 order by  tlmd.CHAPTER_SEQ asc';
                
                $response       =       DB::select( $query_stmt );
                $arrays =   array();

                foreach($response as $object){
                    $arrays[$object->METADATA_ID] =  (array) $object;
                }
                
                $response    =   $arrays;
                
                }
            
            }
            
        return $response;
        
    }
    
    public static function getallcuclist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
            DB::enableQueryLog();
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.EPROOFING_SYSTEM,task_level_metadata.EPROOFING_RECIPIENT,task_level_metadata.ADDITIONAL_RECIPIENT,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME,concat(u.FIRST_NAME," ",u.LAST_NAME) AS Chapter_User_Name,u.EMPLOYEE_ID,apicuctable.STATUS as APICUCSTATUS,apicuctable.REMARKS as APICUCREMARKS'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid,jt.CREATED_BY as Chapteruser, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.CUC').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.CUC').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftJoin(DB::raw('(select ID as apicucid,acuc.JOB_ID,acuc.REMARKS, acuc.STATUS from api_cuc acuc 
                                                                where  acuc.JOB_ID = '.$jobID.' order by acuc.ID desc limit 0,1) apicuctable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('job.JOB_ID', '=', 'apicuctable.JOB_ID');
                                                                 })
                                                            ->join('api_cuc','api_cuc.ID','=','apicuctable.apicucid')
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->leftjoin('user as u','u.USER_ID','=','jobtimetable.Chapteruser')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->groupBy('job.BOOK_ID')
                                                            ->orderBy('CHAPTER_SEQ','asc')
                                                            ->get();      
            $a  =   DB::getQueryLog($cucinfo);
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getallesmJoblist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
            DB::enableQueryLog();
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('count(mesm.ID) as esmcount,task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.EPROOFING_SYSTEM,task_level_metadata.EPROOFING_RECIPIENT,task_level_metadata.ADDITIONAL_RECIPIENT,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME,concat(u.FIRST_NAME," ",u.LAST_NAME) AS Chapter_User_Name,u.EMPLOYEE_ID'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid,jt.CREATED_BY as Chapteruser, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.ESM').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.ESM').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftJoin('metadata_esm as mesm',function($join)
                                                                {
                                                                     $join->on('mesm.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                     $join->where('mesm.IS_DELETED', '=', false);
                                                                 })
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->leftjoin('user as u','u.USER_ID','=','jobtimetable.Chapteruser')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->groupBy('job.BOOK_ID')
                                                            ->orderBy('CHAPTER_SEQ','asc')
                                                            ->get();    
                                                                 
            $a  =   DB::getQueryLog($cucinfo);
            
          // echo "<pre>";print_r($a);exit;
          
            return $cucinfo;
        }
        catch( \Exception $e )
                {      
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getallIndexinglist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
//            DB::enableQueryLog();
            //$cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,job_time_sheet.CREATED_BY,metadata_info.METADATA_ID as metainfoid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,metadata_info.DOI,metadata_info.ACCEPTED_DATE,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,job_time_sheet.STATUS,job_time_sheet.ROUND_ID,job_time_sheet.CHECK_OUT,job_time_sheet.CHECK_IN,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME'))
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,alfrescotable.*,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME,concat(u.FIRST_NAME," ",u.LAST_NAME) AS Chapter_User_Name,u.EMPLOYEE_ID'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid, jt.CREATED_BY as Chapteruser, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.INDEXING').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.S5').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftJoin(DB::raw('(select max(ID) as ALFESCO_ID,max(al.STATUS) as AL_STATUS, max(al.JOB_ID) as JOB_ID,max(al.REMARKS) as AL_REMARKS,al.METADATA_ID from alfresco_log al 
                                                               where al.MODE = "1" and al.STAGE_ID = '.\Config::get('constants.STAGE_COLLEECTION.INDEXING').' and al.ROUND = '.\Config::get('constants.ROUND_ID.S5').' group by al.JOB_ID,al.METADATA_ID ) alfrescotable'), 
                                                                function($join)
                                                                {
                                                                    $join->on('task_level_metadata.JOB_ID', '=', 'alfrescotable.JOB_ID');
                                                                    $join->on('alfrescotable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                })     
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->leftjoin('user as u','u.USER_ID','=','jobtimetable.Chapteruser')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->groupBy('job.BOOK_ID')
                                                            ->orderBy('CHAPTER_SEQ','asc')
                                                            ->get();      
//            $qu =   DB::getQueryLog();
//            echo "<pre>";
//            print_r( $qu ); exit;
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getSpicastInfo($jobid    =   null){
        
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,metadata_info.NO_ART_FIGURES,metadata_info.SPICAST_TOTALPAGES'))
                                    ->join('metadata_info','metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
        
    }
    
    public static function getallConsolidatelist()
    {
        $cucinfo        =   [];
        try
        {
//            DB::enableQueryLog();            
            $cucinfo    =   taskLevelMetadataModel::select(DB::raw('task_level_metadata.*,job.*,metadata_info.*'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->join('metadata_info','metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')
															->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->get();   
//            $qu =   DB::getQueryLog();
//            print_r( $qu );exit;
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function updateallConsolidatedetails($jobId,
                                                        $metaids,
                                                        $chapters,   
                                                        $chaptertypesselect,
                                                        $titlecontent,
                                                        $chaptersequence,
                                                        $containesm,
                                                        $noofmsp,
//                                                        $noofjsmsp,
                                                        $nooftables,
                                                        $noofunnumberedtables,
                                                        $noofequations,
                                                        $noofunnumberedequations,
                                                        $nooffigure,
                                                        $noofnumberedfigure,
                                                        $noofunnumberedfigure,
//                                                        $noofartables,
//                                                        $noofartunnumberedtables,
                                                        $noofartfigure,
                                                        $noofartunnumberedfigure,
                                                        $noofschemes,
                                                        $noofnumberedschemes,
                                                        $noofartstructure,
                                                        $noofartstructureunnumbered,
                                                        $noofartequations,
                                                        $noofartunnumberedequations,
                                                        $pagecountbychar,
                                                        $pagecountbyword,
                                                        $noofspicastpages,
                                                        $noofspicastartpages,
                                                        $noofspicastblankpages,
                                                        $noofspicasttotalpages)
    {
	$updateparreport 			=	false;
        try
        {
            $addresult          =   false;
            $map_arr_bf         =   array();
            $map_arr_af         =   array();
            $part_meta_arr      =   array();
            $insertTlmStatus    =   array();
            $insertMiStatus     =   '';
            $insertMapStatus    =   '';
            $inpArrMap          =   [];
            $updatedmeta        =   false;
            if(count($metaids)>=1)
            {
                $metadata 					=	array();
                foreach($metaids as $key=>$val)
                {
//                    $metadata['TYPE_OF_CHAPTER'] 		= 	$chaptertypesselect[$key];
                    $metadata['TYPE_OF_CONTAINESM'] 		= 	$containesm[$key];
                    $metadata['NO_MSP'] 			= 	$noofmsp[$key];
//                    $metadata['NO_JSMS_PAGES'] 			= 	$noofjsmsp[$key];
                    $metadata['NO_TABLES'] 			= 	$nooftables[$key];
                    $metadata['NO_TABLES_UNNUMBERED']           = 	$noofunnumberedtables[$key];
                    $metadata['NO_EQUATION'] 			= 	$noofequations[$key];
                    $metadata['NO_EQUATION_UNNUMBERED']         = 	$noofunnumberedequations[$key];
                    $metadata['FIGURE_COUNT']                   = 	$nooffigure[$key];
                    $metadata['FIGURE_COUNT_NUMBERED']          = 	$noofnumberedfigure[$key];
                    $metadata['FIGURE_COUNT_UNNUMBERED']        = 	$noofunnumberedfigure[$key];
//                    $metadata['NO_ART_TABLES']                  = 	$noofartables[$key];
//                    $metadata['NO_ART_TABLES_UNNUMBERED']       = 	$noofartunnumberedtables[$key];
                    $metadata['NO_ART_FIGURES']                 = 	$noofartfigure[$key];
                    $metadata['NO_ART_FIGURE_UNNUMBERED']       = 	$noofartunnumberedfigure[$key];
                    $metadata['NO_SCHEMES']                     = 	$noofschemes[$key];
                    $metadata['NO_SCHEME_UNNUMBERED']           = 	$noofnumberedschemes[$key];
                    $metadata['NO_ART_STRUCTURE']               = 	$noofartstructure[$key];
                    $metadata['NO_ART_STRUCTURE_UNNUMBERED']    = 	$noofartstructureunnumbered[$key];
                    $metadata['NO_ART_EQUATION']                = 	$noofartequations[$key];
                    $metadata['NO_ART_UNNUMBERED_EQUATION']     = 	$noofartunnumberedequations[$key];
                    $metadata['PAGE_COUNT_BY_CHARACTERS']       = 	$pagecountbychar[$key];
                    $metadata['PAGE_COUNT_BY_WORDS']            = 	$pagecountbyword[$key];
                    $metadata['SPICAST_PAGES']                  = 	$noofspicastpages[$key];
                    $metadata['SPICAST_ARTPAGES']               = 	$noofspicastartpages[$key];
                    $metadata['SPICAST_BLANKS']                 = 	$noofspicastblankpages[$key];
                    $metadata['SPICAST_TOTALPAGES']             = 	$noofspicasttotalpages[$key];
                    $metadata['LAST_MOD_DATE'] 			=	Carbon::now();
                    $metadata['LAST_MOD_BY'] 			=	Session::get('users')['user_id'];
                    if(strpos(strtolower($chapters[$key]),strtolower(Config::get('constants.CHECK_PART'))) !== false)
                    {                             
                        $metadata['FM_ARTICLE_BM']              =   \Config::get('constants.FM_ARTICLE_BM');                            
                    }
                    if(strpos(strtolower($chapters[$key]),strtolower(Config::get('constants.CHECK_FM'))) !== false)
                    {   
                        $metadata['FM_ARTICLE_BM']              =   \Config::get('constants.ARTICLE_FM');
                    }
                    
                    if(strpos(strtolower($chapters[$key]),strtolower(Config::get('constants.CHECK_BM'))) !== false)
                    {
                        $metadata['FM_ARTICLE_BM']              =   \Config::get('constants.ARTICLE_BM');
                    }
                    $updateparreport                            =   DB::table('metadata_info')->where('METADATA_ID', $val)->update($metadata);
                    if($updateparreport >=	1)
                    {
                        $updatepar 				=   array('LAST_MOD_DATE'=>Carbon::now(),
                                                                            'LAST_MOD_BY'=>\Session::get('users')['user_id'],
                                                                            'CHAPTER_NAME'=>$titlecontent[$key],
                                                                            'CHAPTER_SEQ'=>$chaptersequence[$key],
                                                                            'QUANTITY'=>$noofspicasttotalpages[$key]
                                                                        );
                        $updatedmeta                            =   DB::table('task_level_metadata')->where('METADATA_ID', $val)->update($updatepar);
                        if(strpos(strtolower($chapters[$key]),strtolower(Config::get('constants.CHECK_PART'))) !== false)
                        {
                            $insertTlmStatus                    =   $addresult  =   $val;
                            if( !empty($chaptertypesselect[$key]))
                            $map_arr_bf[$insertTlmStatus]       =   $chaptertypesselect[$key];    
                            $part_meta_arr[$val]                =   $insertTlmStatus;                   
                        }
                        else
                        {
                            $insertTlmStatus       =   $addresult   =   $val;
                            if( !empty($chaptertypesselect[$key]) )
                                $map_arr_bf[$insertTlmStatus]       =   $chaptertypesselect[$key];
                        }
                       
                    }
                    unset($metadata);
                }
                
                if($updatedmeta)
                {
                    DB::table('part_mapping')->where('JOB_ID', $jobId)->update(['STATUS'=>0]);
                    foreach( $map_arr_bf as $key => $value )
                    {    
                        if( !empty( $value ) )
                        {
                            $inpArrMap['CHAPTER_METADATA_ID']  =   $key;
                            $inpArrMap['JOB_ID']  =   $jobId;
                            $inpArrMap['PART_METADATA_ID']  =   $part_meta_arr[$value];
                            $inpArrMap['CREATED_AT']   = 	Carbon::now();
                            $inpArrMap['CREATED_BY']   = 	\Session::get('users')['user_id'];
                            DB::table('part_mapping')->insertGetId( $inpArrMap );
                            unset($inpArrMap);
                        }
                    } 
                }
                return $updateparreport;
            }
	}
	catch( \Exception $e )
	{           
            return false;
        }
        return $updateparreport;
    }
    
    public function getTaskLevelDetails( $metaid ){
        
        return DB::table('task_level_metadata as tlm')
                ->join('metadata_info as mi' ,  'tlm.METADATA_ID' , '=' , 'mi.METADATA_ID' )
                ->where( 'tlm.METADATA_ID'  , $metaid )->select()->get();
        
    }
    
    public function getUnitMeasureChapterLevelDetails( ){
        
        return DB::table('task_level_metadata as tlm')
                ->join('metadata_info as mi' ,  'tlm.METADATA_ID' , '=' , 'mi.METADATA_ID' )
                ->where('task_level_metadata.UNIT_OF_MEASURE',Config::get('constants.UNIT_OF_MEASURE'))
                ->select()->get();
        
    }
    
    public static function getArtfigureInfo($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,art.INPUT_FILE,art.FIGURE_TYPE,art.FIGURE_ID,complexity_enum.NAME as COMPLEXITY,art.INPUT_MODE,art.FIGURE_FULL_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','art.COMPLEXITY')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                     ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getArtfigureillustrationInfo($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,art.INPUT_FILE,art.FIGURE_TYPE,art.FIGURE_ID,complexity_enum.NAME as COMPLEXITY,art.INPUT_MODE,art.FIGURE_FULL_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','art.COMPLEXITY')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
									 ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->groupBy('task_level_metadata.METADATA_ID')
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getArtfigurequalityInfo($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,art.INPUT_FILE,art.FIGURE_TYPE,art.FIGURE_ID,complexity_enum.NAME as COMPLEXITY,art.INPUT_MODE,art.FIGURE_FULL_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','art.COMPLEXITY')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->whereNotNull('art.REMARKS')
                                    ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    
    public static function getArtfigurecatlogueInfo($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,art.INPUT_FILE,art.FIGURE_ID,art.FIGURE_TYPE,art.COMPLEXITY,art.INPUT_MODE,art.FIGURE_FULL_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->groupBy('task_level_metadata.CHAPTER_NO')
                                    ->orderBy('task_level_metadata.CHAPTER_SEQ','asc')
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getArtfigurecatloguechapterInfo($jobid    =   null,$metadataId   =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,art.FIGURE_ID,art.ART_METADATA_ID,art.INPUT_FILE,art.FIGURE_TYPE,complexity_enum.NAME as COMPLEXITY,art.INPUT_MODE,art.FIGURE_FULL_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','art.COMPLEXITY')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->where('task_level_metadata.METADATA_ID',$metadataId)
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getBatchArtfigurecatloguechapterInfo($jobid    =   null,$metadataId   =   null, $batchId)
    {    
        $cucinfo        =   [];
        try
        { 
            DB::enableQueryLog();
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('art.FIGURE_STATUS,case art.FIGURE_STATUS when 1 then true else false end as selected, task_level_metadata.METADATA_ID,jr.JOB_STAGE_ID,task_level_metadata.CHAPTER_NO,art.FILE_NAME,SUBSTRING_INDEX(art.FILE_NAME, ".", 1) as FILE_NAME_EXT, art.ART_METADATA_ID,art.INPUT_FILE,art.FIGURE_TYPE,complexity_enum.NAME as COMPLEXITY,art.INPUT_MODE,art.WORK_INVOLVED,art.INPUTCOLOR,art.OUTPUTCOLOR,art.REMARKS'))
                                    ->join('task_level_art_metadata as art','art.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->join('job_resource as jr','jr.ART_METADATA_ID','=','art.METADATA_STATUS_ID')
                                    ->join('metadata_status as ms',function($join)
                                                {
                                                    $join->on('ms.ID','=', 'art.METADATA_STATUS_ID');
                                                    $join->on('art.CURRENT_ITERATION','=','ms.CURRENT_ITERATION');
                                                })
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','art.COMPLEXITY')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->where('jr.BATCH_ID',$batchId)
                                    ->where('task_level_metadata.METADATA_ID',$metadataId)
                                    ->get();  
            $qu =   DB::getQueryLog($cucinfo);
          // print_r( $qu );exit;
            
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    
    
    public static function getArtcompletedChpter($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO'))
                                    ->join('job_time_sheet as jt','jt.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->where('jt.ROUND_ID',Config::get('constants.ROUND_ID.S5'))
                                    ->where('jt.STAGE',Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'))
                                    ->where('jt.STATUS',Config::get('constants.STATUS_ENUM.COMPLETED'))
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;        
    }
    
      public static function getArtcompletedChpterMetaid($jobid, $metaId)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO'))
                                    ->join('job_time_sheet as jt','jt.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                     ->where('task_level_metadata.METADATA_ID',$metaId)
                                    ->where('jt.ROUND_ID',Config::get('constants.ROUND_ID.S5'))
                                    ->where('jt.STAGE',Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION'))
                                    ->where('jt.STATUS',Config::get('constants.STATUS_ENUM.COMPLETED'))
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;        
    }
    
    public static function getCopyeditingcompletedChpterNew($jobid    =   null){
        
      $sql = "  select tm.CHAPTER_NO,js.`STATUS` from task_level_metadata as tm
                join job_round as jr on jr.METADATA_ID = tm.METADATA_ID  and jr.ROUND_ID = 104
                join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = ".Config::get('constants.STAGE_COLLEECTION.COPY_EDITING')." and js.`STATUS`='24'
                where tm.JOB_ID = '$jobid' and tm.unit_of_measure != '556'";
     
      $records         =       DB::select( $sql );
      return $records;
    }
    
    
    
    
    public static function getCopyeditingcompletedByMetaidChpterNew($jobid ,$metaid){
        
      $sql = "  select tm.CHAPTER_NO,js.`STATUS` from task_level_metadata as tm
                join job_round as jr on jr.METADATA_ID = tm.METADATA_ID  and jr.ROUND_ID = 104
                join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = ".Config::get('constants.STAGE_COLLEECTION.COPY_EDITING')." and js.`STATUS`='24'
                where tm.JOB_ID = '$jobid' and tm.METADATA_ID = '$metaid' and tm.unit_of_measure != '556'";
      
      $records         =       DB::select( $sql );
      return $records;
    }
    
    public static function getIndexingcompletedByMetaidChpterNew($jobid ,$metaid){
        
      $sql = "  select tm.CHAPTER_NO,js.`STATUS` from task_level_metadata as tm
                join job_round as jr on jr.METADATA_ID = tm.METADATA_ID  and jr.ROUND_ID = 104
                join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = ".Config::get('constants.STAGE_COLLEECTION.INDEXING')." and js.`STATUS`='24'
                where tm.JOB_ID = '$jobid' and tm.METADATA_ID = '$metaid' and tm.unit_of_measure != '556'";
      
      $records         =       DB::select( $sql );
      return $records;
    }
    
    
    
    
    public static function getCopyeditingStageAvailable($jobid    =   null){
        
      $sql = "  select tm.CHAPTER_NO,js.`STATUS` from task_level_metadata as tm
                join job_round as jr on jr.METADATA_ID = tm.METADATA_ID  and jr.ROUND_ID = 104
                join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = ".Config::get('constants.STAGE_COLLEECTION.COPY_EDITING')."
                where tm.JOB_ID = '$jobid' and tm.unit_of_measure != '556'";
      
      $records         =       DB::select( $sql );
      return $records;
    }
    
    
    public static function getAllOthersJobChaptersCompleted( $jobid  =   null , $metaid = null , $roundid  , $stageid ){
        
        $sql = "select tm.CHAPTER_NO,js.`STATUS` from task_level_metadata as tm
                join job_round as jr on jr.METADATA_ID = tm.METADATA_ID  and jr.ROUND_ID = '$roundid'
                join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = '$stageid' and js.`STATUS` != '24'
                where tm.JOB_ID = '$jobid' and tm.METADATA_ID != '$metaid' and tm.unit_of_measure != '556'";
      
        $records         =       DB::select( $sql );
      return $records;
      
    }
    
    
    public static function getspicastStageID($jobid){
        
        $sql = "select tm.CHAPTER_NO,js.`STATUS`, js.JOB_STAGE_ID,js.JOB_ROUND_ID from task_level_metadata as tm join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = 104 join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = 1321  where tm.JOB_ID = '$jobid' and tm.unit_of_measure = '556'";
        
         $records         =       DB::select( $sql );
         return $records;
    }
    
    public static function getcucStageID($jobid){
        
        $sql = "select tm.CHAPTER_NO,j.BOOK_ID,js.`STATUS`, js.JOB_STAGE_ID,js.JOB_ROUND_ID from task_level_metadata as tm join job j on j.JOB_ID = tm.JOB_ID join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = 104 join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = ".Config::get('constants.STAGE_COLLEECTION.CUC')."  where tm.JOB_ID = '$jobid' and tm.unit_of_measure = ".Config::get('constants.UNIT_OF_MEASURE')." ";
        
         $records         =       DB::select( $sql );
         return $records;
    }
    
    public static function getCestimationStageID($jobid){
        
        $sql = "select tm.CHAPTER_NO,js.`STATUS`, js.JOB_STAGE_ID,js.JOB_ROUND_ID from task_level_metadata as tm join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = 104 join job_stage as js on jr.JOB_ROUND_ID = js.JOB_ROUND_ID and js.STAGE_ID = 1320  where tm.JOB_ID = '$jobid' and tm.unit_of_measure = ".Config::get('constants.UNIT_OF_MEASURE')." ";
        
         $records         =       DB::select( $sql );
         return $records;
    }
    public static function getCopyeditingcompletedChpter($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,task_level_metadata.CHAPTER_NO'))
                                    ->join('job_time_sheet as jt','jt.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->where('jt.ROUND_ID',Config::get('constants.ROUND_ID.S5'))
                                    ->where('jt.STAGE',Config::get('constants.STAGE_COLLEECTION.COPY_EDITING'))
                                    ->where('jt.STATUS',Config::get('constants.STATUS_ENUM.COMPLETED'))
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;        
    }
    
    public static function getpartnameBook($jobid    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $part       =   Config::get('constants.READ_TYPEOF_PART_STRING');            
            $cucinfo    =   DB::select('SELECT METADATA_ID,CHAPTER_NO FROM task_level_metadata WHERE JOB_ID = "'.$jobid.'" and  CHAPTER_NO LIKE "'.$part.'%"');
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;        
    }
    
    public function updateCurrentStageColumfromJobRound( $meta_id  = null ){
        
        if( !is_null( $meta_id ) ){
            
            $query_stmt      =       "SELECT jr.CURRENT_STAGE FROM task_level_metadata t JOIN job_round jr ON t.METADATA_ID=jr.METADATA_ID ";
            $query_stmt     .=       " and t.CURRENT_ROUND=jr.ROUND_ID WHERE t.CURRENT_STAGE <> jr.CURRENT_STAGE and t.METADATA_ID =".$meta_id;
            $records         =       DB::select( $query_stmt );
            
            if( count( $records ) > 0 ){
                $update_query    =       "update task_level_metadata t join job_round jr on t.METADATA_ID=jr.METADATA_ID ";
                $update_query   .=       " and t.CURRENT_ROUND=jr.ROUND_ID set t.CURRENT_STAGE = jr.CURRENT_STAGE ";
                $update_query   .=       " where t.METADATA_ID = ".$meta_id;
                $update_task     =       DB::select( $update_query );
                return $update_task;
            }
            
        return true;
        
        }
        
        return false;        
        
    }
    
    public function insertChapterInfo( $data, $jobID ){
       
        $taskmetadata['CHAPTER_NO']             =   $data->ChapterID;
        $taskmetadata['UNIT_OF_MEASURE']        =   \Config::get('constants.CHAPTER_ENUM_ID');//chapter unit_enum id
        $taskmetadata['CURRENT_ROUND']          =   \Config::get('constants.ROUND_ID.S200');//chapter unit_enum id
        $taskmetadata['JOB_ID']                 =   $jobID;
        $taskmetadata['IS_ACTIVE']              =   true;
        $taskmetadata['CHAPTER_NAME']           =  ( (isset($data->ChapterTitle)&& !empty($data->ChapterTitle))?$data->ChapterTitle:'');
        //$taskmetadata['CHAPTER_SEQ']    =   $chaptersequence[$key];
        $taskmetadata['CREATED_DATE']           =   Carbon::now();
        //$taskmetadata['CREATED_BY']             =   Session::get('users')['user_id'];
       
         $insertTlmStatus        =   $addresult  = DB::table('task_level_metadata')->insertGetId($taskmetadata);

        /*if(strpos($data->ChapterID,\Config::get('constants.CHECK_PART')) !== false){
            $insertTlmStatus        =   $addresult                  =   DB::table('task_level_metadata')->insertGetId($taskmetadata);
            if( !empty($partnames[$key]) )
                $map_arr_bf[$insertTlmStatus]   =       $partnames[$key];

            $part_meta_arr[$val]    =   $insertTlmStatus;

        }else{
            $insertTlmStatus       =   $addresult                  =   DB::table('task_level_metadata')->insertGetId($taskmetadata);
            if( !empty($partnames[$key]) )
                $map_arr_bf[$insertTlmStatus]   =       $partnames[$key];
        }*/

        if($addresult >= 1){

            $insertrec              =   array(  
                                                'METADATA_ID'=> $addresult ,
                                                'LAST_MOD_DATE'=>Carbon::now()
                                             );

           /* if(strpos($val,\Config::get('constants.CHECK_PART')) !== false){                             
               $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.FM_ARTICLE_BM');                            
            }

            if(strpos( $val,\Config::get('constants.CHECK_FM') ) !== false){

               $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.ARTICLE_FM');

            }

           if(strpos( $val,\Config::get('constants.CHECK_BM') ) !== false){

               $insertrec['FM_ARTICLE_BM']     =   \Config::get('constants.ARTICLE_BM');

            }*/

            //insert meta info details
            $insertMiStatus       =       DB::table('metadata_info')->insert($insertrec);
            
        }
        
        return true;
    }
    
    public function getRecordByCustomCondition( $condition_array =   array() ){

       $table_name     =       'task_level_metadata';
       
       DB::enableQueryLog();
       
       $rec     =    DB::table( $table_name )
               ->select()
               ->where( $condition_array )
               ->get()
               ->first();
       
       $pr  =       DB::getQueryLog();
       
       print_r( $pr );
       
       return $rec;
       
    }
    
    public static function doupdateemailrecipient($allinputofmetadataid,$eproofrecipient,$additionalrecipient)
    {
	$updaterecipient	=   false;
        try
        {
            $addresult          =   false;
            $map_arr_bf         =   array();
            $map_arr_af         =   array();
            $part_meta_arr      =   array();
            $insertTlmStatus    =   array();
            $insertMiStatus     =   '';
            $insertMapStatus    =   '';
            $updatedata         =   [];
            if(count($allinputofmetadataid)>=1)
            {
                foreach($allinputofmetadataid as $key=>$val)
                {
//                    $updatedata['EPROOFING_RECIPIENT'] 	=   rtrim(strtolower($eproofrecipient[$key]),',');
                    $updatedata['ADDITIONAL_RECIPIENT'] =   rtrim(strtolower($additionalrecipient[$key]),',');
                    $wheredata                          =   ['METADATA_ID'=>trim($val)];
                    $updateeproofrecipient              =   taskLevelMetadataModel::where($wheredata)->update($updatedata);
                    if($updateeproofrecipient)
                    {
                        $updaterecipient    =   true;
                    }
                    unset($updatedata);
                }
            }
	}
	catch( \Exception $e )
	{           
            return false;
        }
        return $updaterecipient;
    }
    
    
    public static function gettypeofarticle( $jobid = null , $roundid = NULL , $typeofarticle = null ){
		
        $cucinfo        =   [];
		
        try{
			
            //DB::enableQueryLog();
			
				$cucinfo    	=   	taskLevelMetadataModel::select( DB::raw('task_level_metadata.*,job.*,metadata_info.*,job_info.EDITOR_NAME,job_info.EDITOR_EMAIL,job_info.AUTHOR_NAME,job_info.AUTHOR_EMAIL,aps_proofing.ID as APS_ID,jobtimetable.DOWNID as DOWNID' ) )
										->join( 'job' , 'job.JOB_ID' , '=' , 'task_level_metadata.JOB_ID' )
										->join( 'job_info' , 'job_info.JOB_ID' , '=' , 'job.JOB_ID' )
										->join( 'metadata_info' , 'metadata_info.METADATA_ID' ,'=','task_level_metadata.METADATA_ID' )
										//->join('api_download','api_download.METADATA_ID','=','task_level_metadata.METADATA_ID')
										->join( DB::raw('(select max(ID) as DOWNID, count(ID) as DOWNTOTAL, BOOK_ID,ROUND,METADATA_ID, max(CREATED_DATE) as CHECK_OUT,max(IS_COMPLETED) as IS_COMPLETED from api_download apidown 
											where apidown.IS_COMPLETED = '.\Config::get('constants.STATUS_ENUM.ONE').' and apidown.ROUND = '.$roundid.' group by apidown.BOOK_ID,apidown.METADATA_ID ) jobtimetable'), 
											function( $join ){
												$join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
											})                               
										->leftjoin( 'aps_proofing_status as aps_proofing' , function($join) use ( $roundid , $jobid ){
											$join->on('aps_proofing.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
											$join->where('aps_proofing.JOB_ID', '=', $jobid);
											$join->where('aps_proofing.ROUND','=', $roundid);
										})
										->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
										->where('metadata_info.FM_ARTICLE_BM','=',$typeofarticle)
										->where('task_level_metadata.JOB_ID','=',$jobid)
										//->where('api_download.ROUND','=',$roundid)
										//->where('api_download.IS_COMPLETED','=',true)
										->orderBy( 'task_level_metadata.CHAPTER_SEQ','asc' )
										->groupBy( 'task_level_metadata.METADATA_ID' )
										->get();  
							
            //print_r( DB::getQueryLog( $cucinfo ) );
			
            return $cucinfo;
			
        }catch( \Exception $e ){
			
            return $cucinfo;
			
        }
		
        return $cucinfo;
		
    }
    
	public static function getJobLevelComponentApsinfo( $jobid , $roundid ){
		
		$componentmeasure		=		\Config::get( 'constants.UNIT_OF_MEASURE' );
		
		$query_stmt   			=  		"SELECT tlmd.*,job.*,mdi.*,job_info.EDITOR_NAME,job_info.EDITOR_EMAIL,
											job_info.AUTHOR_NAME,job_info.AUTHOR_EMAIL,aps_proofing.ID AS APS_ID,aps_proofing.ID AS DOWNID
											FROM `task_level_metadata` AS tlmd
											INNER JOIN `job` ON `job`.`JOB_ID` = tlmd.`JOB_ID`
											INNER JOIN `job_info` ON `job_info`.`JOB_ID` = `job`.`JOB_ID`
											INNER JOIN `metadata_info` as mdi ON mdi.`METADATA_ID` = tlmd.`METADATA_ID`
											LEFT JOIN `aps_proofing_status` AS `aps_proofing` ON `aps_proofing`.`METADATA_ID` = tlmd.`METADATA_ID`
											AND `aps_proofing`.`JOB_ID` = tlmd.`JOB_ID` 
											AND `aps_proofing`.`JOB_ID` = $jobid AND `aps_proofing`.`ROUND` = $roundid
											WHERE tlmd.UNIT_OF_MEASURE = $componentmeasure AND  tlmd.`JOB_ID` = $jobid
											GROUP BY tlmd.`METADATA_ID`
											ORDER BY tlmd.`CHAPTER_SEQ` ASC";
										
		$recordset				=	 	DB::select( $query_stmt );						
		
		return $recordset;
							
	}
	
    public static function getChapterInfo($jobid    =   null){
        
        $cucinfo        =   [];
        try
        { 
           
            DB::enableQueryLog();
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.*,metadata_info.*,jr.JOB_ROUND_ID as productionStart,jr.METADATA_ID as JR_METADATA_ID'))
                                    ->join('metadata_info','metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')
                    
                                    ->leftjoin('job_round as jr',function($join) use ($jobid)
                                        {
                                            $join->on('jr.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                            $join->where('jr.ROUND_ID', '=', Config::get('constants.ROUND_ID.S200') );
                                            $join->whereNull('IS_ART');
                                        })
                                    
                                    #->leftjoin('job_round as jr','jr.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->where('task_level_metadata.IS_ACTIVE',true)
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->get();    
                                        
                                     //   dd(DB::getQueryLog());exit;
            return $cucinfo;
        }
        catch( \Exception $e )
        {   
            return $cucinfo;
        }
        return $cucinfo;
        
    }
    
    public static function getAllChapterBasedOnComponentInfo($jobid =   null , $componenttype = 2 ){
        
        $cucinfo        =   [];
        
        $round_arr      =       \Config::get( 'constants.ROUND_ID' );
        $roundarr       =       array( $round_arr['S200'] , $round_arr['S300'] , $round_arr['S600'] , $round_arr['S650'] );
       
        try{ 
            
           $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.*,metadata_info.*,jr.JOB_ROUND_ID as productionStart'))
                                    ->join('metadata_info' ,'metadata_info.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                    ->leftjoin('job_round as jr' , function($join) use ($jobid){
                                            $join->on('jr.METADATA_ID' , '=', 'task_level_metadata.METADATA_ID');
                                            $join->on('jr.ROUND_ID' , '=', 'task_level_metadata.CURRENT_ROUND');
                                            $join->whereNull('IS_ART');
                                    })->whereIn( 'jr.ROUND_ID' , $roundarr )
                                    ->where('task_level_metadata.IS_ACTIVE' , true)
                                    ->whereIn('metadata_info.FM_ARTICLE_BM', $componenttype )
                                    ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                    ->where('task_level_metadata.JOB_ID',$jobid)
                                    ->get();   
			return $cucinfo;
            
        }catch( \Exception $e ){   
            
            var_dump( $e->getTraceAsString() );
            
            return $cucinfo;
            
        }
        
        return $cucinfo;
        
    }
    
   
    
}

