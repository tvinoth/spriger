<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Log;
use Carbon\Carbon;
class projectModel extends Model {

    /**
     * 
     * @param type $userID = USER_ID - user table
     * @return type
     */
    
    public static function getJobAssignedList( $userId , $role = 'AM' ){
       
        if(empty($userId ))
            return false;
        
        try{
            
            if( $role == 'PM' ){
                $query_stmt =   'call getJobList( '.$userId.' , "PM" , "104,114" , null , null )';      
            }else{
                $query_stmt =   'call getJobList( '.$userId.' , "AM" , "104,114" , null , null )';     
            }        
            $jobDetails       =       DB::select( $query_stmt ); 
            
        }catch( \Exception $e ){
            echo $e->getMessage();
            return false;
        }
        
        return $jobDetails;
        
    }
    
    public static function getUserListByTeam( $teamId , $role_id =  12 ){
       
        if(empty($teamId ))
            return false;
        
        try{
          if(is_array($teamId)){
            $UserDetails = DB::table('user_team_map as t')
                ->join('user as u','u.USER_ID','=','t.USER_ID')
                 ->whereIn ('t.TEAM_ID', $teamId )
                 ->where('u.role','=', $role_id)
                ->select(DB::raw('concat (u.FIRST_NAME," ", u.LAST_NAME) as userName,u.USER_ID as userId'))
                ->get();
          }else {
              $UserDetails = DB::table('user_team_map as t')
                ->join('user as u','u.USER_ID','=','t.USER_ID')
                 ->where ('t.TEAM_ID','=',$teamId)
                 ->where ('u.role','=', $role_id )
                ->select(DB::raw('concat (u.FIRST_NAME," ", u.LAST_NAME) as userName,u.USER_ID as userId'))
                ->get();
          }
          
       }catch( \Exception $e ){
            return false;
        }
            
        return $UserDetails;
    }
    
    public static function getUserListByAssignedTeam( $teamId , $usrid ){
        
        return  DB::table('user_team_map as t')
                ->join('user as u','u.USER_ID','=','t.USER_ID')
                ->where ('t.TEAM_ID','=',$teamId)
                ->where('u.USER_ID','!=',$usrid)
                ->select(DB::raw('concat (u.FIRST_NAME," ", u.LAST_NAME) as userName,u.USER_ID as userId'))
                ->get();
    }
	public static function rollBackStages($JOB_STAGE_ID){
		// DB::enableQueryLog();
    	//$out = DB::getQueryLog($getStageDetails);	
		$getStageDetails 	=	'SELECT   s.STAGE_ID, s.STAGE_NAME,js1.JOB_STAGE_ID   
		FROM `job_stage` AS `js`
		INNER JOIN `job_stage` AS `js1` ON `js1`.`JOB_ROUND_ID` = `js`.`JOB_ROUND_ID`
		INNER JOIN `stage` AS `s` ON `s`.`STAGE_ID` = `js1`.`STAGE_ID`
		INNER JOIN `job_round` AS `jr` ON `jr`.`JOB_ROUND_ID` = `js1`.`JOB_ROUND_ID`
		JOIN task_level_userdefined_workflow as tuw on tuw.JOB_ID = jr.JOB_ID and tuw.WORKFLOW = js1.WORKFLOW_ID and tuw.STAGE = js1.STAGE_ID
		WHERE `js1`.`ITERATION_ID` = 1 AND `js`.`JOB_STAGE_ID` = '.$JOB_STAGE_ID.' AND `js1`.`STAGE_SEQ` < js.STAGE_SEQ and tuw.IS_AUTO != 1';
		$getStageDetails 	=	DB::select($getStageDetails);		
		return $getStageDetails;
    }
	 public static function skipStage($STAGE_SEQ, $JOB_STAGE_ID, $INPUT_QUANTITY, $JOB_ROUND_ID,$ITERATION_ID ){
        try{
			$STAGE_SEQ = $STAGE_SEQ+1;
			
				$updateQry =    DB::table('job_stage as js')
								->where ('js.JOB_STAGE_ID','=',$JOB_STAGE_ID)
								->update(array('STATUS' => 24, 'IS_SKIPPED' => 1));
				if($updateQry)
				{
					$updateQry =    DB::table('job_stage as js')
								->where ('js.JOB_ROUND_ID','=',$JOB_ROUND_ID)
								->where ('js.ITERATION_ID','=',$ITERATION_ID)
								->where ('js.STAGE_SEQ','=',$STAGE_SEQ)
								->update(array('STATUS' => 27, 'INPUT_QUANTITY' => $INPUT_QUANTITY));
							
				$getStageDetails = DB::table('job_stage as js')
					->join('job_round as jr','jr.JOB_ROUND_ID','=','js.JOB_ROUND_ID')
					->where ('js.JOB_ROUND_ID','=',$JOB_ROUND_ID)
					->where ('js.STAGE_SEQ','=',$STAGE_SEQ)
					->select(DB::raw('js.STAGE_ID,jr.METADATA_ID'))
					->first();
					
				   if(count($getStageDetails)>=1)
					{
							$updateQry =    DB::table('job_round as j')
											->where ('j.JOB_ROUND_ID','=',$JOB_ROUND_ID)
											->update(array('j.CURRENT_STAGE' => $getStageDetails->STAGE_ID));
							
							$updateQry =    DB::table('task_level_metadata as tlm')
											->where ('tlm.METADATA_ID','=',$getStageDetails->METADATA_ID)
											->update(array('tlm.CURRENT_STAGE' => $getStageDetails->STAGE_ID));
					}
					
					
					return array('success');  
				  
				}
				else {
					return array('failed');   
				}
			
		}catch( \Exception $e ){
            return false;
        }
    }
    public static function JobAssignedToUser($data){
       
        if(empty($data ))
            return false;
        
        try{
         
         $updateQry     =       DB::table('job')
                                        ->where('BOOK_ID', $data['book_id'])
                                        ->update(array('PM' => $data['user_id']));
         
        if($updateQry)
        {
            $getjobid   =   DB::table('job')->where('BOOK_ID', $data['book_id'])->first();
            if(count($getjobid)>=1)
            {
                $updateQry = DB::table('job_info')
		->where('JOB_ID', $getjobid->JOB_ID)
		->update(array('JOB_ASSIGNED_DATE' => Carbon::now()));
            }
        }
        return array('success');   
         
         
        
       }catch( \Exception $e ){
            return false;
        }
        
        return array('failed');   
            
    }
      
    public static function getJobAndOwnerDetails($data){
        
        if(empty($data ))
            return false;
        try{
            
            $bookId     =   $data['book_id'];
            $userId     =   $data['user_id'];
            
         $UserDetails = DB::table('job AS j')
                ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                ->join('user as u','j.PM','=','u.USER_ID')
                 ->join('user as u1','ji.AM','=','u1.USER_ID')
                ->where('j.BOOK_ID','=',$bookId)
                ->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_ONLINE,u.EMAIL as PMemail,ji.AUTHOR_NAME,ji.EDITOR_NAME,u1.EMAIL as AMemail ,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,concat(u1.FIRST_NAME," ",u1.LAST_NAME) AS AMname,ji.PE_NAME,ji.PE_MAIL,ji.PUBLISHER_NAME,j.CREATED_DATE,ji.PRODUCTION_EDITOR,ji.PRODUCTION_EDITOR_EMAIL,ji.PRODUCTION_CLASSIFICATION'))
               ->first();
               
       }catch( \Exception $e ){
            return false;
        }
            
        return $UserDetails;
    }
    
    public static function getProjectList($arrData){
       $query = "CALL Proc_ProjectList('".$arrData['user_id']."', '".$arrData['team_id']."')";  
       $projectList = DB::select($query);
       return $projectList;        
    }
    
    public static function getProjectTitle($jobID) {
		 $jobDetails = DB::table('job')
                ->where('JOB_ID', $jobID)
                ->select(DB::raw('JOB_TITLE'))
                ->first();
        return $jobDetails;
	}
    
    public static function getWorkflowStartedCount($jobID) {
		 $jobDetails = DB::table('task_level_userdefined_workflow')
                ->where('JOB_ID', $jobID)
                ->select(DB::raw(' DISTINCT ROUND, WORKFLOW_MASTER_ID '))
                ->first();
        return $jobDetails;
	}
    
    public static function getSchoolRounds($schoolRoundId) {
		// $schoolRoundId = [162, 163 ,164 ,165,166,159 ,160 ,167,100,170];
		 $schoolRounds = DB::table('round_enum')
                ->whereIn('ID', explode(",",$schoolRoundId))
                ->select(DB::raw('ID, NAME '))
                ->get();
        return $schoolRounds;
	}
    
    public static function getRounds($jobID) {
		 $rounds = DB::table('task_level_userdefined_workflow as tlw')
				->join('round_enum AS re', 're.ID', '=', 'tlw.ROUND')
                ->where('tlw.JOB_ID', $jobID)
                ->select(DB::raw('DISTINCT tlw.ROUND,re.NAME'))
				->orderBy('re.NAME','asc')
                ->get();
        return $rounds;
	}
    
    public static function getUnits() {
		 $units = DB::table('unit_enum')
                ->select(DB::raw('*'))
                ->get();
        return $units;
	}
    
    public static function getStages() {
		 $units = DB::table('stage')
				->where('IS_ACTIVE', 1)
                ->select(DB::raw(' STAGE_ID, STAGE_NAME '))
				->orderBy('STAGE_NAME','asc')
                ->get();
        return $units;
	}

    public static function getRoundDetails($jobID) {
		 $roundDtl = DB::table('sctabschoolstargetpagecount as stp')
			    ->join('sctabschoolprojectslesson AS spl', function($join)
						 {
						   $join->on('spl.ProjectID', '=', 'stp.projectid');
						   $join->on('spl.GradeId', '=', 'stp.GradeId');
						 })
			    ->join('sctabschoolprojectsgrade AS pg', function($join)
						 {
						   $join->on('stp.projectid', '=', 'pg.ProjectID');
						   $join->on('spl.GradeId', '=', 'pg.GradeId');
						   $join->on('stp.GradeId', '=', 'pg.GradeId');
						 })
                ->where('stp.projectid', $jobID)
                ->select(DB::raw('DISTINCT stp.ProjectId,stp.GradeId,stp.tolerance,stp.*, pg.GradeName, spl.LessonName'))
			//	->orderBy('LENGTH(pg.GradeName)','asc')
				->orderBy('pg.GradeName','asc')
                ->get();
        return $roundDtl;
	}
	
    public static function updateRoundTarget($inpArr) {
		$updateQry = DB::table('sctabschoolstargetpagecount')
		->where('GradeId', $inpArr['gradeId'])
		->where('projectid', $inpArr['jobId'])
		->update(array('tragetPageCount' => $inpArr['target'], 'modifiedDate' => date("Y-m-d H:i:s"), 'modifiedBy' => $inpArr['user']));
        return $updateQry;
	}
	
    public static function deleteRoundInfo($gradeId, $projectId) {
       $query = "CALL Proc_DeleteSetupRound('".$gradeId."','".$projectId."')";  
       $chkDtl = DB::select($query);
       return $chkDtl;		
	}
    
    public static function getChapterArtStatus($jobID,$opt) {
       $query = "CALL Proc_GetCharterArtStatus('".$jobID."','".$opt."')";  
       $chaterArtDtl = DB::select($query);
       return $chaterArtDtl;        
    }
    
    public static function getInstructions($jobId, $stageId) {
       $query = "CALL Proc_GetInstructions('".$jobId."','".$stageId."')";  
       $instrDtl = DB::select($query);
       return $instrDtl;
    }
    
    public static function getSupportingFiles($jobId) {
       $files = DB::table('schools_workflow_process_path')
				->where('JOB_ID', $jobId)
                ->select(DB::raw('*'))
                ->first();
        return $files; 
    }
    
    public static function getTargetPageCount($inpArr) {
		 $targetCnt = DB::table('sctabschoolstargetpagecount')
				->where('projectid', $inpArr['jobId'])
				->where('stageName', $inpArr['stageName'])
				->where('roundName', $inpArr['roundName'])
                ->select(DB::raw('*'))
                ->get();
        return $targetCnt; 
	}
	public static function getCheckoutDetails($inpArr) {
       $query = "CALL Proc_GetCheckoutDetails('".$inpArr['stageId']."','".$inpArr['jobId']."','".$inpArr['opt']."')";  
       $chkDtl = DB::select($query);
       return $chkDtl;		
	}
	public static function getComments($stageId, $opt) {
       $query = "CALL Proc_GetComments('".$stageId."', '".$opt."')";  
       $commentsDtl = DB::select($query);
       return $commentsDtl;			
	}
	public static function getWorkflowDetails($inpArr) {
		 $res = array();
		 $jobRoundInfo = DB::table('job_stage as js')
				->join('job_round AS jr', 'jr.job_round_id', '=', 'js.job_round_id')
				->join('job AS tj', 'tj.JOB_ID', '=', 'jr.JOB_ID')
				->where('js.JOB_STAGE_ID', $inpArr['stageId'])
                ->select(DB::raw('js.WORKFLOW_MASTER_ID, jr.ROUND_ID, tj.JOB_TITLE, tj.JOB_ID'))
                ->get();
        $res['roundInfo'] = $jobRoundInfo; 
		
		$inpArr['roundId'] = $jobRoundInfo[0]->ROUND_ID;
		$workflow = self::getWorkflowInfo($inpArr);

		//$query = "CALL Proc_GetWorkflow('".$inpArr['jobId']."', '".$jobRoundInfo[0]->ROUND_ID."')";  
		//$workflow = DB::select($query);
		$res['workflow'] = $workflow; 
		
		$inpArr['workflowId'] = $workflow[0]->WORKFLOW;
		
	//	 $stageInfo = DB::table('task_level_userdefined_workflow as tw')
	//			->join('stage AS s', 's.STAGE_ID', '=', 'tw.STAGE')
	//			->where('tw.JOB_ID', $inpArr['jobId'])
	//			->where('tw.ROUND', $jobRoundInfo[0]->ROUND_ID)
	//			->where('tw.WORKFLOW',$workflow[0]->WORKFLOW)
    //            ->select(DB::raw('s.STAGE_NAME'))
    //            ->get();
        $res['stageInfo'] = self::getWorkflowStages($inpArr); 		
		return $res;		
	}
	public static function getWorkflowInfo($inpArr) {
		$query = "CALL Proc_GetWorkflow('".$inpArr['jobId']."', '".$inpArr['roundId']."')";  
		$workflow = DB::select($query);
		return $workflow;		
	}
	public static function getWorkflowStages($inpArr) {		
		 $stageInfo = DB::table('task_level_userdefined_workflow as tw')
				->join('stage AS s', 's.STAGE_ID', '=', 'tw.STAGE')
				->where('tw.JOB_ID', $inpArr['jobId'])
				->where('tw.ROUND', $inpArr['roundId'])
				->where('tw.WORKFLOW',$inpArr['workflowId'])
                ->select(DB::raw('s.STAGE_NAME'))
                ->get();
       return $stageInfo; 		
	}
	public static function getJobRoundWFStages($inpArr) {		
		 $stageInfo = DB::table('task_level_userdefined_workflow as ws')
				->join('stage AS s', 's.STAGE_ID', '=', 'ws.STAGE')
				->where('ws.JOB_ID', $inpArr['jobId'])
				->where('ws.ROUND', $inpArr['roundId'])
				->where('ws.WORKFLOW_TYPE',0)
				->where('ws.WORKFLOW_MASTER_ID',$inpArr['workflowMasterId'])
                ->select(DB::raw('ws.STAGE, s.STAGE_NAME'))
				->orderBy('ws.STAGE_SEQ','asc')
                ->get();
       return $stageInfo; 		
	}
 
	public static function getAllRounds() {
		$allRounds = DB::table('round_enum')
                ->where('is_active', 1)
                ->select(DB::raw('ID, NAME '))
				->orderBy('name','asc')
                ->get();
        return $allRounds;
	}
	public static function getBookmapDetails($inpArr){
       $query = "CALL Proc_GetBookmapDetails('".$inpArr['jobId']."')";  
       $chkDtl = DB::select($query);
       return $chkDtl;			
	}
	public static function getPrdTabInfo($inpArr) {
		$res = array();
		$roundInfo = self::getRounds($inpArr['jobId']);
        $res['roundInfo'] = $roundInfo; 
		
		$wfInfo = DB::table('task_level_userdefined_workflow as udw')
				->join('workflow AS w', 'w.WORKFLOW_ID', '=', 'udw.WORKFLOW')
				->where('w.WORKFLOW_TYPE', 0)
				->where('udw.JOB_ID', $inpArr['jobId'])
				->where('udw.ROUND', $roundInfo[0]->ROUND)
                ->select(DB::raw(' distinct udw.WORKFLOW, w.WORKFLOW_NAME '))
                ->get();
        $res['workflowInfo'] = $wfInfo;
		
		return $res;
	}
	public static function getStageInfo($jobId) {
		$stageInfo = array();
		$wfInfo = DB::table('task_level_userdefined_workflow as tluw')
				->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'tluw.WORKFLOW_MASTER_ID')
				->join('round_enum AS re', 're.ID', '=', 'tluw.ROUND')
				->where('tluw.JOB_ID', $jobId)
                ->select(DB::raw(' DISTINCT tluw.ROUND, tluw.WORKFLOW_MASTER_ID,wm.WORKFLOW_MASTER_NAME '))
                ->get();
        if(count($wfInfo) > 0) {
			for($k=0; $k<count($wfInfo); $k++) {
				$wfMasterId[] =  $wfInfo[$k]->WORKFLOW_MASTER_ID;
			}
		
			$stageInfo = DB::table('task_level_userdefined_workflow as tluw')
					->join('stage AS s', 's.STAGE_ID', '=', 'tluw.STAGE')
					->where('tluw.JOB_ID', $jobId)
					->whereIn('tluw.WORKFLOW_MASTER_ID', $wfMasterId)
					->select(DB::raw(' DISTINCT s.stage_id,s.STAGE_NAME,tluw.STAGE '))
					->get();
		}
		return $stageInfo;
	}
	public static function getPrdPages($inpArr) {
		$query = "CALL Proc_GetProductionPages('".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['fromPg']."','".$inpArr['toPg']."')";  
        $pages = DB::select($query);
		$res['pages'] = $pages; 
		return $res;		
	}

	public static function moveToPrd($inpArr) {
		$result = ''; $res = array();
		$duedate = date("Y-m-d", strtotime("+5 days"));
		
		for($i=0; $i<count($inpArr['metadata']); $i++) {
			$query = "CALL Proc_MoveToProduction('".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['workflowId']."','".$inpArr['metadata'][$i]['metaId']."',NULL,'".$inpArr['metadata'][$i]['quantity']."','".$duedate."',0,'".$inpArr['userId']."')";  
			$result = DB::select($query);
			array_push($res, $result);			
		}
		return $res;			
	}
	public static function getInstruction($inpArr) {
		$query = "CALL Proc_GetAllInstructions('".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['fromPg']."','".$inpArr['toPg']."')";  
        $pages = DB::select($query);
		$res['instructions'] = $pages; 
		return $res;				
	}	
	public static function deleteInstruction($inpArr) {		
		$updateQry = DB::table('bookmap_instruction')
			->where('JOB_ID', $inpArr['jobId'])
			->where('BOOKMAP_INSTRUCTION_ID', $inpArr['instructionId'])
			->update(array('IS_ACTIVE' => 0));
		return $updateQry;
	}
	public static function saveInstruction($inpArr) {
		$query = "CALL Proc_SaveInstruction('".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['fromRange']."','".$inpArr['toRange']."','".$inpArr['instructionId']."','".$inpArr['instruction']."','".$inpArr['createdDate']."','".$inpArr['createdBy']."')";  
        $msg = DB::select($query);
		return $msg;				
	}
	public static function getProcessPath($inpArr) {
		$allRounds = DB::table('schools_workflow_process_path')
                ->where('JOB_ID', $inpArr['jobId'])
                ->select(DB::raw('* '))
                ->get();
        return $allRounds;		
	}
	public static function getFTPPath($inpArr) {
		$info = DB::table('schools_wf_source_path')
                ->where('workflow_id', $inpArr['workflowId'])
                ->select(DB::raw('* '))
                ->get();
        return $info;		
	}
	public static function getWorkflowPath($inpArr) {
		$info = DB::table('schools_wf_dest_path')
                ->where('workflow_id', $inpArr['workflowId'])
                ->select(DB::raw('wf_dest_id, workflow_id, destination_path,destination_ps_path, missing_link, missing_font, overset, cast(folio_digits as char(2)) as folio_digits, cast(pdf_preset as char(2)) as pdf_preset,is_active, is_pitstop_required '))
                ->get();
        return $info;		
	}
	public static function getPresetList($inpArr) {
		$info = DB::table('schools_presets')
                ->where('TYPE', $inpArr['workflowType'])
                ->select(DB::raw('cast(Preset_id as char(10))as Preset_id,Preset_name  '))
                ->get();
        return $info;		
	}
	public static function saveMetadata($inpArr) {
      ///  $msg = DB::select("START TRANSACTION");
		$wRes = self::saveWorkflowProcessPath($inpArr);
	//	print_r($wRes);
		$inpArr['workflowId'] = $wRes[0]->workflowId ;
		$wf_source_path_idCnt =0; $wf_dest_idCnt = 0;
		
		if($wRes[0]->workflowId > 0) {
			if(count($inpArr['ftp']) > 0) {
				for($i=0; $i<count($inpArr['ftp']); $i++) {
					$newArr = $inpArr['ftp'][$i];
					$newArr['workflowId'] = $inpArr['workflowId'];
					$newArr['createdBy'] = $inpArr['createdBy'];
					$fRes = self::saveWorkflowFTPPath($newArr);
					if($fRes[0]->wf_source_path_id > 0)  $wf_source_path_idCnt++;
				}
			}
			if(count($inpArr['path']) > 0) {
				for($i=0; $i<count($inpArr['path']); $i++) {
					$newArr = $inpArr['path'][$i];
					$newArr['workflowId'] = $inpArr['workflowId'];
					$newArr['createdBy'] = $inpArr['createdBy'];	
					
					$pRes = self::saveWorkflowPath($newArr);
					if($pRes[0]->wf_dest_id > 0)  $wf_dest_idCnt++;
				}
			}
			//echo count($inpArr['ftp']). "-- ".$wf_source_path_idCnt."====  path ".count($inpArr['path']) ."-- ".$wf_dest_idCnt;
			
			if(count($inpArr['ftp']) == $wf_source_path_idCnt && count($inpArr['path']) == $wf_dest_idCnt) {
			///	$msg = DB::select("COMMIT");
				$msg = array('msg'=> 'Successfully inserted / updated.', 'ftp'=> count($inpArr['ftp']). "-- ".$wf_source_path_idCnt, 'path'=> count($inpArr['path']) ."-- ".$wf_dest_idCnt);
			} else {
				$msg = array('msg'=> 'Failed.',  'ftp'=> count($inpArr['ftp']). "-- ".$wf_source_path_idCnt, 'path'=> count($inpArr['path']) ."-- ".$wf_dest_idCnt);
			///	$msg = DB::select("ROLLBACK");
			}
		} else {
			$msg = array('msg'=> 'Failed.');
			///$msg = DB::select("ROLLBACK");
		}
		return $msg;				
	}
	public static function saveWorkflowProcessPath($inpArr) {
		$query = "CALL Proc_SaveWorkflowProcessPath('".$inpArr['jobId']."','".addslashes($inpArr['pr_pdf_path'])."','".addslashes($inpArr['pr_dest_path'])."','".addslashes($inpArr['pit_log_path'])."','".addslashes($inpArr['pit_fail_path'])."','".addslashes($inpArr['sample_indd_path'])."','".addslashes($inpArr['fonts'])."','".addslashes($inpArr['pdf_output_path'])."','".$inpArr['workflow_type']."','".$inpArr['createdBy']."')";  
        $msg = DB::select($query);
		//echo "WF - " .  $query;
		return $msg;				
	}
	public static function saveWorkflowFTPPath($inpArr) {
		$query = "CALL Proc_SaveWorkflowFTPPath('".$inpArr['workflowId']."','".addslashes($inpArr['source_path'])."','".addslashes($inpArr['dest_path'])."','".$inpArr['user_name']."','".$inpArr['password']."','".$inpArr['createdBy']."')";  
 
		$msg = DB::select($query);
		return $msg;				
	}	
	public static function saveWorkflowPath($inpArr) {
		$query = "CALL Proc_SaveWorkflowPath('".$inpArr['workflowId']."','".addslashes($inpArr['destination_path'])."','".addslashes($inpArr['destination_ps_path'])."','".$inpArr['missing_link']."','".$inpArr['missing_font']."','".$inpArr['overset']."','".$inpArr['folio_digits']."','".$inpArr['pdf_preset']."','".$inpArr['is_pitstop_required']."','".$inpArr['createdBy']."')";  
        $msg = DB::select($query);
		return $msg;				
	}	
	public static function getAssignWFTabInfo($inpArr) {
		$res = array();
		$roundInfo = self::getSchoolRounds($inpArr['schoolIds']);
        $res['roundInfo'] = $roundInfo; 
		
		$query = "CALL Proc_GetWorkflowForJob('".$inpArr['jobId']."','".$inpArr['circleId']."','".$inpArr['subCircle']."')";  
 
		$wfInfo = DB::select($query);
        $res['workflowInfo'] = $wfInfo;
		
	//	$res['workflowAssigned'] = self::getJobAssignWF($inpArr);
		
		return $res;
	}
	public static function getJobAssignWF($inpArr) {
		$res = array();		
		$query = "CALL Proc_GetJobAssignWF('".$inpArr['jobId']."')";   
		$wfInfo = DB::select($query);
		return $wfInfo;
	}
	public static function getAssignedWF($inpArr) {
		$res = array();	
	//	$query = "CALL Proc_GetAssignedWorkflow('".$inpArr['jobId']."')";  
		$query = "CALL Proc_GetJobAssignWF('".$inpArr['jobId']."')";   	
		$wfInfo = DB::select($query);
        $res['workflow'] = $wfInfo;		
		return $res;
	}	
	public static function saveAssignWF($inpArr) {
		if(count($inpArr['WFInfo']) > 0) {
			$resCnt = 0; $totCnt = 0;
			for($i=0; $i<count($inpArr['WFInfo']); $i++) {
				if( isset($inpArr['WFInfo'][$i]['newWF']) &&  $inpArr['WFInfo'][$i]['newWF']> 0) {
					$totCnt++;
					$query = "CALL Proc_SaveAssignedWorkflow('".$inpArr['jobId']."', '".$inpArr['WFInfo'][$i]['ROUND']."', '".$inpArr['WFInfo'][$i]['WORKFLOW_MASTER_ID']."', '".$inpArr['userId']."')";   
					$pRes = DB::select($query);
				
					if($pRes[0]->task_level_userdefined_workflow_id > 0)  $resCnt++;
				}
			}
			if($totCnt == $resCnt) {
				$msg = array('msg'=> 'Successfully inserted / updated.', 'count'=> $totCnt. "-- ".$resCnt);
			} else {
				$msg = array('msg'=> 'Failed.', 'count'=> $totCnt. "-- ".$resCnt);
			}
		} else {
			$msg = array('msg'=> 'Nothing to Save.', 'count'=> $totCnt. "-- ".$resCnt);
		}
		return $msg;		
	}
	public static function deleteAssignWF($inpArr) {		
		$query = "CALL Proc_DeleteAssignedWorkflow('".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['workflowMasterId']."')";   
		$res = DB::select($query);
 		return $res;
	}
	public static function getWorkflowView($inpArr) {
		$res = array();
		$workflow = self::getWorkflowInfo($inpArr);
		$res['workflow'] = $workflow; 
		
		$inpArr['workflowId'] = $workflow[0]->WORKFLOW;
        $res['stageInfo'] = self::getWorkflowStages($inpArr); 		
		return $res;		
	}
	public static function getWorkflowName($inpArr) {
		$info = DB::table('workflow')
                ->where('workflow_master_id', $inpArr['workflowMasterId'])				
                ->where('workflow_type', $inpArr['workflowType'])
                ->select(DB::raw('* '))
                ->get();
        return $info;		
	}

	public static function getJobRoundWorkflow($inpArr) {
		$res = array();
		$res['workflow'] = self::getWorkflowName($inpArr);
		$res['workflowStages'] = self::getJobRoundWFStages($inpArr);		
        $res['stages'] = self::getStages($inpArr); 		
		return $res;		
	}
	public static function getTPS($inpArr) {		
		$query = "CALL Proc_GetTPSDetails('".$inpArr['jobId']."')";   
		$res = DB::select($query);
 		return $res;
	}
	public static function saveTPS($inpArr) {		
		$query = "CALL Proc_SaveTPSSetup('".$inpArr['projectId']."','".$inpArr['tpsContact']."','".$inpArr['workflowType']."','".$inpArr['jobId']."','".$inpArr['percentage']."','".$inpArr['target']."','".$inpArr['components']."','".$inpArr['grade']."','".$inpArr['pageCnt']."','".$inpArr['batchInfo']."','".$inpArr['productionDate']."','".$inpArr['lwProjMgr']."','".$inpArr['projDtl']."','".$inpArr['pendDtl']."')";  
		
		$res = DB::select($query);
 		return $res;
	}
	public static function getTPSContact($inpArr) {
		$info = DB::table('USER AS u')		
				->join('user_team_map AS ut', 'ut.USER_ID', '=', 'u.USER_ID')
				->where('ut.IS_ACTIVE', 1)
				->join('team as t', 'ut.TEAM_ID', '=', 't.TEAM_ID')
				->where('t.SUB_CIRCLE', 34)
                ->select(DB::raw(" u.USER_ID,ut.team_id, TRIM(CONCAT(IF(u.FIRST_NAME IS NULL,'', CONCAT(u.FIRST_NAME,' ')), IF(u.MIDDLE_NAME IS NULL,'', CONCAT(u.MIDDLE_NAME,' ')), IF(u.LAST_NAME IS NULL,'', u.LAST_NAME))) AS EMPLOYEE_NAME "))
                ->get();
        return $info;		
	}
	public static function getSetupWorkflowStages($inpArr) {		
		$res = array();
		$wfInfo = DB::table('task_level_userdefined_workflow as tluw')
				->join('workflow_master AS wm', 'wm.WORKFLOW_MASTER_ID', '=', 'tluw.WORKFLOW_MASTER_ID')
				->join('round_enum AS re', 're.ID', '=', 'tluw.ROUND')
				->where('tluw.JOB_ID', $inpArr['jobId'])
				->where('tluw.ROUND', $inpArr['roundId'])
                ->select(DB::raw('DISTINCT tluw.ROUND, tluw.WORKFLOW_MASTER_ID,wm.WORKFLOW_MASTER_NAME '))
                ->get();
		$res['wfInfo'] = $wfInfo;
		$inpArr['workflow_master_id'] = $wfInfo[count($wfInfo)-1]->WORKFLOW_MASTER_ID;
		$res['stageInfo'] = self::getSetupStage($inpArr);
		return $res;
	}
	public static function getSetupStage($inpArr) {		
					
		$wfInfo = DB::table('task_level_userdefined_workflow as tluw')
				->join('stage AS s', 's.STAGE_ID', '=', 'tluw.STAGE')
				->where('tluw.JOB_ID', $inpArr['jobId'])
				->where('tluw.WORKFLOW_MASTER_ID', $inpArr['workflow_master_id'])
				->where('tluw.ROUND', $inpArr['roundId'])
                ->select(DB::raw(' s.STAGE_NAME,tluw.STAGE'))
                ->get();
		
		return $wfInfo;
	}
	public static function getStagesForRound($inpArr) {		
					
		$wfInfo = DB::table('task_level_userdefined_workflow as tluw')
				->join('stage AS s', 's.STAGE_ID', '=', 'tluw.STAGE')
				->where('tluw.JOB_ID', $inpArr['jobId'])
				//->where('tluw.WORKFLOW_MASTER_ID', $inpArr['workflow_master_id'])
				->where('tluw.ROUND', $inpArr['roundId'])
                ->select(DB::raw(' s.stage_id,s.STAGE_NAME,tluw.STAGE'))
                ->get();

		return $wfInfo;
	}
	public static function saveSetupRound($inpArr, $saveOpt = '') {	
		if($saveOpt == "Import") {	
			$query = "CALL Proc_ImportSetupRound('".$inpArr['jobId']."','".$inpArr['userId']."','".$inpArr['lesson']."','".$inpArr['grade']."','".$inpArr['stageName']."','".$inpArr['roundName']."','".$inpArr['unitName']."','".$inpArr['tolerance']."','".$inpArr['target']."')";  
		}	else {
			$query = "CALL Proc_SaveSetupRound('".$inpArr['jobId']."','".$inpArr['userId']."','".$inpArr['lesson']."','".$inpArr['grade']."','".$inpArr['stageId']."','".$inpArr['roundId']."','".$inpArr['unitId']."','".$inpArr['tolerance']."','".$inpArr['target']."')";  
		}
		$res = DB::select($query);
 		return $res;
	}
	
	public static function addRemoveWorkfowStages($inpArr) {	
	    $stAr = explode(",",$inpArr['stageInfo']);
        for($i=0; $i<count($stAr); $i++) {			
			
			$query = "CALL Proc_AddRemoveJobWorkflowStages('".$i."','".$inpArr['userId']."','".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['workflowMasterId']."','".$inpArr['workflowId']."','".$stAr[$i]."','".($i+1)."')";  
				
			$res = DB::select($query);
		}
 		return $res;
	}	
	public static function saveProfitabilityPercentage($inpArr) {
        for($i=0; $i<count($inpArr['roundInfo']); $i++) {			
			$query = "CALL Proc_SaveProfitabilityPercentage('".$inpArr['jobId']."','".$inpArr['roundInfo'][$i]['ROUND']."','".$inpArr['userId']."','".$inpArr['roundInfo'][$i]['PERCENTAGE']."')";		
			$res = DB::select($query);
		}
 		return $res;
	}
	public static function getProfitabilityPercentage($inpArr) {		
		$query = "CALL Proc_GetProfitabilityPercentage('".$inpArr['jobId']."')";  		
		$res = DB::select($query);
 		return $res;
	}
	public static function getProjectBinList($inpArr) {		
		$query = "CALL Proc_ProjectBinList('".$inpArr['roleId']."','".$inpArr['roundId']."','".$inpArr['stageId']."','".$inpArr['jobId']."','".$inpArr['searchType']."','".$inpArr['searchTerm']."','".$inpArr['start']."','".$inpArr['noOfRec']."')";  		
		$res = DB::select($query);
 		return $res;
	}
	public static function getProjectBinDetails($inpArr) {		
		$query = "CALL Proc_ProjectBinListByDocument('".$inpArr['roleId']."','".$inpArr['jobId']."','".$inpArr['roundId']."','".$inpArr['documentName']."','".$inpArr['searchType']."','".$inpArr['searchTerm']."')";
		$res = DB::select($query);
 		return $res;
	}
	public static function deleteBookmapPages($inpArr) {
        for($i=0; $i<count($inpArr['bookmapInfo']); $i++) {	
			$query = "CALL Proc_DeleteBookmapPages('".$inpArr['userId']."','".$inpArr['jobId']."','".$inpArr['bookmapInfo'][$i]['pageId']."')";
			$res = DB::select($query);
		}
 		return $res;
	}
	public static function getInDesignVersion($inpArr) {
		$info = DB::table('tbl_indesign_version')
                ->select(DB::raw('* '))
                ->get();
        return $info;
	}
	public static function getBookmapInfoById($inpArr) {		
		$query = "CALL Proc_GetBookmapInfoById('".$inpArr['jobId']."','".$inpArr['pageId']."','".$inpArr['seqId']."','".$inpArr['seq']."')";
		$res = DB::select($query);
 		return $res;
	}
	public static function saveBookmapFolio($inpArr, $saveOpt = '') {	
		if($saveOpt == "Import") {	
			$query = "CALL Proc_ImportBookmapFolio('".$inpArr['jobId']."','".$inpArr['userId']."','".$inpArr['inddFolioNo']."','".$inpArr['pgTitle']."','".$inpArr['pageType']."','".$inpArr['numberType']."','".$inpArr['inddVersion']."','".$inpArr['pdfFileName']."','".addslashes($inpArr['inddFilePath'])."','".$inpArr['inddFileName']."','".$inpArr['isTouched']."','".$inpArr['orderSeq']."')";
		} else {
			$query = "CALL Proc_SaveBookmapFolio('".$inpArr['jobId']."','".$inpArr['pageId']."','".$inpArr['userId']."','".$inpArr['pageNo']."','".$inpArr['inddFolioNo']."','".$inpArr['pgTitle']."','".$inpArr['pageType']."','".$inpArr['numberType']."','".$inpArr['pref']."','".$inpArr['suff']."','".$inpArr['batchNo']."','".$inpArr['inddVersion']."','".$inpArr['pdfFileName']."','".addslashes($inpArr['inddFilePath'])."','".$inpArr['inddFileName']."','".$inpArr['saveOpt']."','".$inpArr['savePos']."')";
		}
		$res = DB::select($query);
		return $res;
	}	
	public static function updateTouched($inpArr) {		
		$updateQry = DB::table('bookmap_schools')
			->where('job_id', $inpArr['jobId'])
			->where('page_id', $inpArr['pageId'])
			->update(array('is_touched' => $inpArr['touched'], 'modified_on' => 'NOW()','modified_by' => $inpArr['userId']));
		return $updateQry;
	}
	public static function folioTakeOwnership($inpArr) {
		$res  = array(); $msg = array(); $batchId = 0;$insRes = array();
		$query = "CALL Proc_ValidateTakeOwnership('".$inpArr['userId']."','".$inpArr['roundId']."','".$inpArr['metadataId']."')";
		$valid = DB::select($query);
		if(!$valid[0]->erFlag) {
			
			//DB::select("START TRANSACTION");
			$saveIdCnt = 0; $jobStageId = ''; $jobId = ''; $batchId = 0;
			for($i=0; $i<count($inpArr['metaInfo']); $i++) {
				
				$insQry = "CALL Proc_TakeOwnership('".$inpArr['userId']."','".$inpArr['metaInfo'][$i]['jobId']."','".$inpArr['metaInfo'][$i]['jobStageId']."','".$inpArr['metaInfo'][$i]['jobRoundId']."','".$inpArr['teamId']."','".$inpArr['metaInfo'][$i]['metadataId']."','".$inpArr['metaInfo'][$i]['artMetadataId']."', '".$batchId."')";	
				
				if($i > 0) $jobStageId .= ',';
				$jobStageId .= 	$inpArr['metaInfo'][$i]['jobStageId'];	
				$jobId = $inpArr['metaInfo'][$i]['jobId'];		
											  
				$insRec = DB::select($insQry);
				if($insRec[0]->saveId > 0)  $saveIdCnt++;
				
				$batchId = $insRec[0]->batchId;
			}
			if(count($inpArr['metaInfo']) == $saveIdCnt) {
				//DB::select("COMMIT");
				$msg = array('msg'=> 'Successfully inserted / updated.');
				
				$insRes = self::getInstructions($jobId, $jobStageId);
			} else {
				//DB::select("ROLLBACK");
				$msg = array('msg'=> 'Failed.');
			}				
		}
		$res['batchId'] = $batchId;
		$res['error'] = $valid;
		$res['msg'] = $msg;
		$res['ins'] = $insRes; //."-- j  ".$jobId. "--st  ".$jobStageId;
 		return $res;
	}
	public static function saveRMIInfo($inpArr) {
		$query = "CALL Proc_SaveRMIStatus('".$inpArr['filePath']."','".$inpArr['scptPath']."','".$inpArr['projectId']."','".$inpArr['methodName']."','".$inpArr['systemIP']."','".$inpArr['inddVersion']."')";
		$valid = DB::select($query);
		return $valid;		
	}	
	public static function checkRMIStatus($inpArr) {
		$info = DB::table('rmi_status')
				->where('system_ip', $inpArr['systemIP'])
				->where('ID', $inpArr['rmiID'])
                ->select(DB::raw('* '))
                ->get();
        return $info;
	}	
	public static function unlockDocument($inpArr) {		
	    $msg = array();
		//DB::select("START TRANSACTION");
		$saveIdCnt = 0; $inpArr['pending'] = 1;
		for($i=0; $i<count($inpArr['metaInfo']); $i++) {
			
			$insQry = "CALL Proc_UnlockDocuments('".$inpArr['userId']."','".$inpArr['metaInfo'][$i]['jobId']."','".$inpArr['metaInfo'][$i]['jobStageId']."','".$inpArr['metaInfo'][$i]['jobRoundId']."','".$inpArr['pending']."')";	
			
			$insRec = DB::select($insQry);
			if($insRec[0]->flag > 0)  $saveIdCnt++;
		}
		if(count($inpArr['metaInfo']) == $saveIdCnt) {
			//DB::select("COMMIT");
			$msg = array('msg'=> 'Folio(s) unlocked succesfully.');;
		} else {
			//DB::select("ROLLBACK");
			$msg = array('msg'=> 'Folio(s) unlocked failed.');
		}	
 		return $msg;
	}
	/*public static function skipStage($inpArr) {
		$res  = array(); $msg = array(); $batchId = 0;$insRes = array();
		$query = "CALL Proc_ValidateSkipStage('".$inpArr['metaInfo'][0]['jobRoundId']."','".$inpArr['metaInfo'][0]['stageSeq']."','".$inpArr['metaInfo'][0]['currentStage']."')";
		$valid = DB::select($query);
		if(!$valid[0]->erFlag) {
			
			//DB::select("START TRANSACTION");
			$saveIdCnt = 0; $jobStageId = ''; $jobId = ''; $batchId = 0;
			for($i=0; $i<count($inpArr['metaInfo']); $i++) {
				
				$insQry = "CALL Proc_SkipStage( '".$batchId."', '".$inpArr['userId']."','".$inpArr['metaInfo'][$i]['jobStageId']."','".$inpArr['metaInfo'][$i]['inpQty']."','".$inpArr['teamId']."','".$inpArr['metaInfo'][$i]['metadataId']."','".$inpArr['metaInfo'][$i]['jobId']."')";
											  
				$insRec = DB::select($insQry);
				if($insRec[0]->flag > 0)  $saveIdCnt++;
				
				$batchId = $insRec[0]->batchId;
			}
			if(count($inpArr['metaInfo']) == $saveIdCnt) {
				//DB::select("COMMIT");
				$msg = array('msg'=> 'Folio(s) submitted to next stage successfully.');
				
				$insRes = self::getInstructions($jobId, $jobStageId);
			} else {
				//DB::select("ROLLBACK");
				$msg = array('msg'=> 'Folio(s) is not skipped to next stage.');
			}				
		}
		$res['error'] = $valid;
		$res['msg'] = $msg;
		return $res;
	}*/
	public static function getCheckoutInfo($inpArr) {
		$info = DB::table('bookmap_schools as bs')
				->leftjoin('job_round AS jr', 'jr.METADATA_ID', '=', 'bs.metadata_id')
				->leftjoin('job_stage AS js', 'js.JOB_ROUND_ID', '=', 'jr.JOB_ROUND_ID')
				->where('bs.job_id', $inpArr['jobId'])
				->whereIn('js.JOB_STAGE_ID', explode(",",$inpArr['jobStageId']))
                ->select(DB::raw(' distinct bs.indd_version, bs.indd_file_path, bs.indd_file_name, js.batch_id'))
                ->get();
		
		return $info;		
	}
	public static function indesignReturn($inpArr) {
		$updateQry = DB::table('schools_file_status')
		->where('batch_id', $inpArr['batchId'])
		->update(array('file_status' => $inpArr['fileStatus'], 'modified_on' => date("Y-m-d H:i:s"), 'error_log' => $inpArr['errorLog']));
        return $updateQry;
	}
	public static function getFileStatus($inpArr) {
		$info = DB::table('schools_file_status')
				->where('batch_id', $inpArr['batchId'])
	            ->select(DB::raw(' file_status'))
				->orderBy('id', 'desc')
                ->first();
		return $info;	
	}	
	public static function checkoutProcess($inpArr) {
		$jobStageArray = explode(",", $inpArr['jobStageId']);
		for($i=0; $i<count($jobStageArray); $i++) {
			$teamArray = explode(",",$inpArr['teamId']);
			$query = "CALL Proc_Checkout('".$inpArr['jobId']."','".$jobStageArray[$i]."','".$inpArr['userId']."','".$teamArray[0]."','".count($jobStageArray)."','".$i."')";
			$valid = DB::select($query);			
		}
		return $valid;		
	}
	public static function checkInProcess($inpArr) {	
	    $info = DB::table('job_stage as js')
				->join('job_round AS jr', 'jr.JOB_ROUND_ID', '=', 'js.JOB_ROUND_ID')
				->join('task_level_metadata AS tlm', 'tlm.METADATA_ID', '=', 'jr.METADATA_ID')
				->leftjoin('round_enum AS r', 'r.ID', '=', 'jr.ROUND_ID')
				->leftjoin('stage AS s', 's.STAGE_ID', '=', 'js.STAGE_ID')
				->whereIn('js.JOB_STAGE_ID', explode(",",$inpArr['jobStageId']))
                ->select(DB::raw('js.STAGE_ID, js.WORKFLOW_MASTER_ID,js.ITERATION_ID,js.STAGE_SEQ,js.JOB_ROUND_ID,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,s.STAGE_NAME,r.NAME AS ROUND_NAME,r.ID AS roundid '))
                ->get();
		
        for($i=0; $i<count($info); $i++) {
			$roundId = $info[$i]->roundid;
			
			$query = "CALL Proc_CheckIn('".$roundId."','".$info[$i]->STAGE_ID ."','".$info[$i]->JOB_STAGE_ID."','".$teamArray[0]."','".count($jobStageArray)."','".$i."')";
			
			if($info[$i]->STAGE_ID == 5) {
				
			} 
			
		}
		
		
		if ($info[0]->STAGE_NAME == $inpArr['pdfPitstopStage'] && $inpArr['fileStatus'] == 2) {

			$bookmap = 	DB::table('task_level_metadata as a')
					->leftjoin('job_round AS b', 'b.METADATA_ID', '=', 'a.METADATA_ID')
					->leftjoin('job_stage AS c', function($join)
							 {
							   $join->on('c.JOB_ROUND_ID', '=', 'b.JOB_ROUND_ID');
							   $join->on('c.STAGE_ID', '=', 'b.CURRENT_STAGE');
							   $join->on('c.ITERATION_ID', '=', 'b.CURRENT_ITERATION_ID');
							 })						 
					->leftjoin('bookmap_schools AS d', 'd.METADATA_ID', '=', 'a.METADATA_ID')
					->where('a.job_id', $inpArr['jobId'])
					->whereIn('a.CHAPTER_NO', explode(",",$inpArr['selectedPages']))
					->where('IS_ACTIVE', 1)
					->where('d.is_touched', 0)
					->select(DB::raw('a.metadata_id,a.chapter_no,d.indd_version,d.indd_folio_number,d.order_seq,d.indd_file_name,d.pdf_file_name,d.indd_file_path '))			   
					->orderBy('d.order_seq', 'asc')
					->get();
				
			$path = DB::table('schools_workflow_process_path as swp')
					->join('schools_wf_dest_path AS swdp', 'swp.workflow_id', '=', 'swdp.workflow_id')
					->join('schools_presets AS sp', 'sp.preset_id', '=', 'swdp.pdf_preset')
					->where('JOB_ID', $inpArr['jobId'])
					->select(DB::raw(' * '))			   
					->orderBy('wf_dest_id', 'asc')
					->first();
					
			$team = DB::table('team as t')
					->join('job AS j', 'j.TEAM', '=', 't.TEAM_ID')
					->where('j.JOB_ID', $inpArr['jobId'])
					->select(DB::raw(' t.TEAM_NAME '))			   
					->first();
					
			$inpArr['path'] = $path;	
			$inpArr['team'] = $team;
			$inpArr['bookmap'] = $bookmap;
			self::createMetaXmlFile($inpArr);
		}
        return $info; 
	}

	public static function createMetaXmlFile($inpArr) {
		$export_type = ''; $pitstop_path = ''; $processType = "single";
		
		if($inpArr['path']->workflow_type == 1){
			$export_type = 'PDF';
			$pitstop_path = '';
		} else {
			$export_type = 'PS';
			$pitstop_path = stripslashes($inpArr['path']->destination_ps_path);			
		}
	
		$pagesArry = array();
		$pdfNameArry = array();
		$metaDataArry = array();
		$indd_version = '';
		$indd_file_name = '';

		for($i=0; $i<count($inpArr['bookmap']); $i++) {			
			$pages = $inpArr['bookmap'][$i]->order_seq.'|'.$inpArr['bookmap'][$i]->chapter_no;
			array_push($pagesArry,$pages);
			array_push($pdfNameArry,$inpArr['bookmap'][$i]->pdf_file_name);
			array_push($metaDataArry,$inpArr['bookmap'][$i]->metadata_id);
			$indd_file_path	= $inpArr['bookmap'][$i]->indd_file_path;	
			$indd_version = $inpArr['bookmap'][$i]->indd_version;
			$indd_file_name = $inpArr['bookmap'][$i]->indd_file_name;
		}
		
		$selected_pages = implode(',',$pagesArry);
		$selected_pdf_names = implode(',',$pdfNameArry);
		$metaDataIds = implode(',',$metaDataArry);
		
		$xml = '<pdfMetaData>
						<exportType>'.$export_type.'</exportType>
						<jobId>'.$inpArr['jobId'].'</jobId>
						<batchId>'.$inpArr['batchId'].'</batchId>
						<client>'.$inpArr['team']->TEAM_NAME.'</client>
						<version>'.$indd_version.'</version>
						<jobOption>'.$inpArr['path']->Preset_name.'</jobOption>
						<processType>'.$processType.'</processType>
						<inputFile>'.$indd_file_path.'</inputFile>
						<outputPath>'. stripslashes($inpArr['path']->destination_path).'</outputPath><PSPath>'.$pitstop_path.'</PSPath>		
						<selectedPages>'.$selected_pages.'</selectedPages>
						<selectedPagesPDFFileName>'.$selected_pdf_names.'</selectedPagesPDFFileName>
						<folioDigit>'.$inpArr['path']->folio_digits.'</folioDigit>
						<ignoreMissingLink>'.$inpArr['path']->missing_link.'</ignoreMissingLink>
						<ignoreMissingFont>'.$inpArr['path']->missing_font.'</ignoreMissingFont>
						<ignoreOverset>'.$inpArr['path']->overset.'</ignoreOverset>
						<isPitstopRequired>'.$inpArr['path']->is_pitstop_required.'</isPitstopRequired>         
						<pitstopLogPath>'.stripslashes($inpArr['path']->pit_log_path).'</pitstopLogPath>
						<pitstopLogFailPath>'.stripslashes($inpArr['path']->pit_fail_path).'</pitstopLogFailPath>
						<pdfCallBack>
							<Url value="'.$inpArr['pdfCallbackURL'].'" /> 
							<parameter key="jobId" value="'.$inpArr['jobId'].'" type="fixed" />
							<parameter key="batchId" value="'.$inpArr['batchId'].'" type="fixed" />
							<parameter key="folioNo" value="" type="string" />
							<parameter key="status" value="" type="string" />             
							<parameter key="description" value="" type="string" />
							<parameter key="pdfFileName" value="" type="string" />
							<parameter key="endTime" value="{0: yyyy-MM-dd HH-mm-ss}" type="data-time" />	              
						</pdfCallBack>
				</pdfMetaData>';
	
		$time = strtotime(date('Y-m-d H:i:s')); 	
		$fileName =  "pdf_creation_".$time."_".$inpArr['jobId'].".xml";				
		$serverPath  = $inpArr['fileServerFTP'].$inpArr['pdfCreationPath'].$fileName;
		self::fileUploadFTP($serverPath, $xml);
	}	
				
    public static function fileUploadFTP($fileName, $fileData)
    {
        // Allows overwriting of existing files on the remote FTP server
        $stream_options = array('ftp' => array('overwrite' => true));

        // Creates a stream context resource with the defined options
        $stream_context = stream_context_create($stream_options);

        // Opens the file for writing and truncates it to zero length
        if ($fh = fopen($fileName, 'w', 0, $stream_context))
        {
                fputs($fh, $fileData);
                fclose($fh);
        }
        return $fh;
    }	
    //THIS METHOD FOR GET CUC LIST
    public static function doGetCuclist()
    {
        $cucinfo        =	array();
        try
        {
            
            $cucinfo    =   parreportModel::select(DB::raw('task_level_metadata.METADATA_ID,metadata_info.METADATA_ID as metainfoid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,metadata_info.DOI,metadata_info.ACCEPTED_DATE,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,job_time_sheet.STATUS,job_time_sheet.ROUND_ID,job_time_sheet.CHECK_OUT,job_time_sheet.CHECK_IN,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME'))
                                                            ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->join('job_time_sheet','job_time_sheet.METADATA_ID','=','task_level_metadata.METADATA_ID')
                                                            ->join('round_enum','round_enum.ID','=','job_time_sheet.ROUND_ID')
                                                            ->join('stage','stage.STAGE_ID','=','job_time_sheet.STAGE')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('job_time_sheet.STATUS',1)
                                                            ->where('job_time_sheet.STAGE',\Config::get('constants.STAGE_COLLEECTION.CUC')) 
                                                            ->get();            

        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $cucinfo;
    }
    
    public static function doUpdatecheckout($jodID  =   null,$data  =   [])
    {
        $updateQry      =   false;
        try
        {
            $updateQry  =   DB::table('job_time_sheet')->where('JOB_ID', $jodID)->update($data);
       }catch( \Exception $e ){
            return false;
        }
        
        return $updateQry;           
    }
}