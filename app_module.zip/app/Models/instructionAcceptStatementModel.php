<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use DB;

class instructionAcceptStatementModel extends Model 
{
    protected $table        =   'instruction_accept_statement';
    public  $primaryKey     =   'ID';
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',true);
    }
}

