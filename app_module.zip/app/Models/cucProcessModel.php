<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
class cucProcessModel extends Model 
{
    //THIS METHOD FOR GET CUC LIST
    public static function doGetCuclist()
    {
        $cucinfo        =   array();
        try
        {
            //$cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID,job_time_sheet.CREATED_BY,metadata_info.METADATA_ID as metainfoid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,metadata_info.DOI,metadata_info.ACCEPTED_DATE,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,job_time_sheet.STATUS,job_time_sheet.ROUND_ID,job_time_sheet.CHECK_OUT,job_time_sheet.CHECK_IN,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME'))
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.CUC').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.CUC').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->get();      
            
            //('td.METADATA_ID,metadata_info.METADATA_ID as metainfoid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,metadata_info.DOI,metadata_info.ACCEPTED_DATE,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,job_time_sheet.STATUS,job_time_sheet.ROUND_ID,job_time_sheet.CHECK_OUT,job_time_sheet.CHECK_IN,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME')
//            $cucinfo   =   DB::select('SELECT td.METADATA_ID,mi.METADATA_ID as metainfoid,td.PII,jt.CHECK_OUT,jt.CHECK_IN,jt.JOB_TIME_SHEET_ID,mi.DOI,td.JOB_ID,td.CHAPTER_NO
//								From task_level_metadata td 
//								LEFT JOIN  metadata_info mi	ON mi.METADATA_ID = td.METADATA_ID
//								LEFT JOIN job_time_sheet jt ON td.JOB_ID = jt.JOB_ID AND td.METADATA_ID = jt.METADATA_ID AND jt.STAGE="1236"
//								group by td.CHAPTER_NO');
//echo "<pre>";
//print_r($cucinfo);exit;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function doUpdatecheckout($jodID  =   null,$data  =   [])
    {
        $updateQry      =   false;
        try
        {
            $updateQry  =   DB::table('job_time_sheet')->where('JOB_ID', $jodID)->update($data);
        }
        catch( \Exception $e )
        {
            return false;
        }
        return $updateQry;           
    }
}