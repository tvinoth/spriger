<?php
namespace App\Models;
use App\Models\apiClientAcknowledgement;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiFigureValidation extends Model {
    
    protected $table        =   'api_figurevalidation';
    public $timestamps      =       true;
    protected $dateFormat =     'Y-m-d H:i:s';    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiFigureValidation();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                'END_TIME'   =>     $inpArr['END_TIME'] , 
                                'STATUS'     =>     $inpArr['STATUS'] ,
                                'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $updateQry  =   DB::table('api_figurevalidation')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequest( $batchid , $round ){
        
        $getRec       =         DB::table('api_figurevalidation as afv')
                                        ->where('BATCH_ID', '=' , $batchid )
                                        ->where('ROUND' , '=' , $round )                                            
                                        ->where('STATUS', '=' , '1.5' )                                            
                                        ->orderBy( 'afv.ID', 'desc' )
                                        ->get()->first();
      
      return $getRec;
      
    }
    
    public static function getApiRequestByTokenkey( $tokenkey ){
        
        $getRec     =       array();
        
        if( !is_null( $tokenkey ) ){
         
            $getRec       =         DB::table('api_figurevalidation as afv')
                                        ->where('TOKEN_KEY', '=', $tokenkey )   
                                        ->where('STATUS', '=', '1.5' )
                                        ->orderBy('afv.ID', 'desc')
                                        ->get()->first();
            
         
        }
        
      return $getRec;
      
    }
    
    public function buildInputAndStore( $metaFileInput ){
        
        $api_tbl_input['TOKEN_KEY']         =       $metaFileInput['tokenkey'];
        $api_tbl_input['JOB_ID']            =       $metaFileInput['jobid'];
        $api_tbl_input['BATCH_ID']          =       $metaFileInput['batchid'];
        $api_tbl_input['METADATA_ID']       =       $metaFileInput['metaid'];
        $api_tbl_input['STATUS']            =       '1.5';
        $api_tbl_input['ROUND']             =       $metaFileInput['round'];
        $api_tbl_input['START_TIME']        =       date('Y-m-d H:i:s');
        $api_tbl_input['CREATED_BY']        =       $metaFileInput['createdBy'];
        $api_tbl_input['CREATED_DATE']      =       date('Y-m-d H:i:s');
        
        if( isset( $metaFileInput['requestlog'] ) )
            $api_tbl_input['REQUEST_LOG']      =       $metaFileInput['requestlog'];
        
        return $this->insertNew( $api_tbl_input );         
        
    }
    
}
