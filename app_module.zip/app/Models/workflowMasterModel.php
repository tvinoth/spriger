<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class workflowMasterModel extends Model 
{
    protected $table        =   'workflow_master';
    public  $primaryKey     =   'WORKFLOW_MASTER_ID';
    const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "LAST_MOD_DATE";
        
    public static function store($data)
    {
        $workfolw           =   [];   
        try
        {
            $workfolw       =   workflowMasterModel::insertGetId($data);
        }
        catch( \Exception $e )
        {               
//            return $e->getMessage();
        }
        return $workfolw;
    }
    
    
    public function getProjectWorkflows( $circle = null , $subcircle = null ){
        
        $query_str      =   "SELECT wflm.WORKFLOW_MASTER_ID , wflm.WORKFLOW_MASTER_NAME , wflw.WORKFLOW_ID , wflw.WORKFLOW_NAME , wflw.WORKFLOW_TYPE, "
                                . " wflw.START_STAGE , wflw.END_STAGE FROM workflow_master wflm LEFT JOIN workflow wflw "
                                . " ON wflw.WORKFLOW_MASTER_ID  = wflm.WORKFLOW_MASTER_ID WHERE wflm.IS_ACTIVE = 1 ";

        if( !is_null( $circle )   )
            $query_str .= " and wflm.CIRCLE = $circle ";
        
        if( !is_null( $subcircle )   )
            $query_str .= " and wflm.SUB_CIRCLE_ID = $subcircle ";
        
        $query_str .=   "  ORDER BY wflm.WORKFLOW_MASTER_ID DESC";
        
        return DB::select( $query_str );
        
        
    }
    
}

