<?php
namespace App\Models;
use App\Models\apiFileUpload;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiProofingStatus extends Model {
    
    protected $table = 'api_proofing_status';
    public $timestamps = true;
    protected $dateFormat = 'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiProofingStatus();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        $insert_r           =       apiProofingStatus::insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      array( 
                                  'updated_at'  =>     $inpArr['updated_at'] , 
                                  'STATUS'      =>     $inpArr['STATUS'] ,
                                  'REMARKS'     =>     $inpArr['REMARKS']
                           );
        
        $updateQry  =   DB::table('api_proofing_status')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByMetaid( $metaid , $round , $type="AUTHOR" ){
        
         $getRec       =         DB::table('api_proofing_status as afu')
                                            ->where('METADATA_ID', '=', $metaid )
                                            ->where('ROUND', '=', $round )                                            
                                            ->where('TYPE', '=', $type )                                            
              ->orderBy('afu.ID', 'desc')
              ->get()->first();
      
      return $getRec;
      
    }
    
    
}
