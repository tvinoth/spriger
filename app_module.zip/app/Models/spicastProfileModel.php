<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class spicastProfileModel extends Model 
{    
    protected   $table    =   'spicast_profile';
    
    public static function getSpicastlist(){   
        
        $spicastinfo        =   [];   
        try{
            $spicastinfo    =   spicastProfileModel::where('STATUS','=','1')->get();        
        }catch( \Exception $e ){               
            return $spicastinfo;
        }
        
        return $spicastinfo;
        
    }    
}

