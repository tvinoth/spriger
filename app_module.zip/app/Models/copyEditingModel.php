<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Models\chapterPartMapModel;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class copyEditingModel extends Model 
{    
    protected $table    =   'task_level_metadata';
    
    public static function getallcopyeditinglist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,alfrescotable.*,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME,concat(u.FIRST_NAME," ",u.LAST_NAME) AS Chapter_User_Name,u.EMPLOYEE_ID'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid,jt.CREATED_BY as Chapteruser, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.COPY_EDITING').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.S5').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftJoin(DB::raw('(select max(ID) as ALFESCO_ID,max(al.STATUS) as AL_STATUS, max(al.JOB_ID) as JOB_ID,max(al.REMARKS) as AL_REMARKS,al.METADATA_ID from alfresco_log al 
                                                                where al.MODE = "1" and al.STAGE_ID = '.\Config::get('constants.STAGE_COLLEECTION.COPY_EDITING').' and al.ROUND = '.\Config::get('constants.ROUND_ID.S5').' group by al.JOB_ID,al.METADATA_ID ) alfrescotable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'alfrescotable.JOB_ID');
                                                                     $join->on('alfrescotable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })     
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->leftjoin('user as u','u.USER_ID','=','jobtimetable.Chapteruser')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->groupBy('job.BOOK_ID')
                                                            ->orderBy('CHAPTER_SEQ','asc')
                                                            ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getJimetimelastcopyediting($id = null)
    {
        $getJob     =	false;
        try
        {
            $getJob =   DB::select('SELECT tlm.METADATA_ID as taskmetaid,tlm.PII,tlm.CHAPTER_NAME,tlm.CHAPTER_NO,tlm.JOB_ID,job.BOOK_ID,job.JOB_ID AS jobid,job.JOB_TITLE,jt.JOB_TIME_SHEET_ID as jobtimesheetid,count(jt.METADATA_ID) as totalcount,jt.JOB_ID,jt.JOB_ID,jt.METADATA_ID,jt.ROUND_ID,jt.STAGE,jt.CHECK_OUT,jt.CHECK_IN,jt.CREATED_BY,jt.STATUS,round_enum.NAME AS roundname,stage.STAGE_ID,stage.STAGE_NAME FROM task_level_metadata as tlm
                        JOIN job on job.JOB_ID  = tlm.JOB_ID JOIN  job_time_sheet as jt on tlm.METADATA_ID = jt.METADATA_ID  JOIN round_enum ON round_enum.ID = jt.ROUND_ID
                        JOIN stage ON stage.STAGE_ID = jt.STAGE where jt.JOB_TIME_SHEET_ID = '.$id.' and jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.COPY_EDITING').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.S5'));
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
}

