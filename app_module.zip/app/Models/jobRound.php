<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class jobRound extends Model {
    
    protected   $table       =      'job_round';
    public      $primaryKey  =      'JOB_ROUND_ID';
    public      $timestamps  =      false;
    
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new jobRound();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    
    public function insertRecordGetId( $inp_arr = array() ){
        
        if( !empty( $inp_arr ) ){
            return DB::table('job_round')->insertGetId( $inp_arr );
        }
        
        return false;
    }
    
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $table      =   'job_round';
        
        $updateQry  =   DB::table( $table )
                            ->where('JOB_ROUND_ID', $rowid )
                            ->update( $setArr );
        
        
        return $updateQry;
        
    }
    
    public function getjobRoundEntryExistByMetaId( $metaid , $round , $isart = null ){
       
        $table      =   'job_round';
        $query      =   DB::table( $table ); 
        
        if( !is_null( $metaid )  ){  
            
            if( is_null( $isart ) ){
                $wherearray       =       array( 'METADATA_ID' => $metaid  , 'ROUND_ID' => $round  );
                $query->where( $wherearray );
                $query->whereRaw( '( `IS_ART` < ?  or is_art is null )' , array(1));
                
            }else{
                $wherearray       =       array( 'METADATA_ID' => $metaid  , 'ROUND_ID' => $round  , 'IS_ART' => 1 );
                $query->where( $wherearray );
            }
            $res   = $query->get()->first();
        
            return $res;
        }
        
        return array();
    }
    
}

