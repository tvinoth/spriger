<?php 


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
Use Illuminate\Support\Facades\Crypt;
use DB;
use Session;

class productionLocationModel extends Model {
    
    public $table    =   'production_location_ftp';
    public $primaryKey  =   'ID';
    public $timestamps  =   true;
    protected $fillable =   array('CREATED_DATE');

   
    public static function getProductionLocationName_old( ){
        
       $query_stmt     =       'SHOW COLUMNS FROM production_location LIKE "PRODUCTION_LOCATION"';
       
       $result     =       DB::select( $query_stmt );
       
       if ($result) {
           $option_array = explode("','",preg_replace("/(enum|set)\('(.+?)'\)/","\\2", $result[0]->Type));
       }
        
       return $option_array;
        
    }
    
    public static function getProductionLocationName( ){
        
       $query_stmt     =       '';
       $result     =       DB::table( 'production_area_location' )->select('LOCATION_NAME')->get()->toArray();
       
       $response    =   array();
       
       foreach( $result as $key => $value ){
           
           $response[]  =   $value->LOCATION_NAME;
         
           
       }
       return $response;
        
    }
    
    public function getAllPrductionDetails(){
    
        return DB::select(  'select * from production_location_ftp where 1=1 order by ID desc' );
    }
    
    //THIS METHOD FOR GET job info and location
    public static function doGetLocationname($jobID = null)
    {
        $cucinfo        =	array();
        try
        {
             DB::enableQueryLog();
            $cucinfo    =   DB::table('job_info')->select(DB::raw('job_info.JOB_ID,job_info.TAPS_LOCATION,job_info.LOCATION , pla.LOCATION_NAME , pla.ADDRESS , plf.PRODUCTION_LOCATION,plf.FTP_HOST,plf.FTP_USER_NAME,plf.FTP_PASSWORD,plf.FTP_PATH,plf.FTP_PATH,plf.FILE_SERVER_PATH,plf.FILE_SERVER_USER_NAME,plf.FILE_SERVER_PASSWORD'))
                                                            ->join( 'production_location_ftp as plf' , 'plf.PRODUCTION_LOCATION', '=', 'job_info.LOCATION')
                                                            ->leftjoin( 'production_area_location as pla' , 'pla.ID' , '=' , 'job_info.LOCATION' )
                                                            ->where('plf.STATUS','ACTIVE')
                                                            ->where('job_info.JOB_ID',$jobID)
                                                            ->first();            
            $q          =       DB::getQueryLog( $cucinfo );
            
            //$cucinfo->FTP_PASSWORD      =        \Crypt::decryptString($cucinfo->FTP_PASSWORD);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $cucinfo;
    }
    
     //THIS METHOD FOR GET job info and location
    public static function doGetLocationnameByDefault($jobID = null,$locationId=null)
    {
        
        $cucinfo        =	array();
        try
        {
             DB::enableQueryLog();
            $cucinfo    =   DB::table('production_location_ftp as plf')->select(DB::raw('pla.LOCATION_NAME , pla.ADDRESS , plf.PRODUCTION_LOCATION,plf.FTP_HOST,plf.FTP_USER_NAME,plf.FTP_PASSWORD,plf.FTP_PATH,plf.FTP_PATH,plf.FILE_SERVER_PATH,plf.FILE_SERVER_USER_NAME,plf.FILE_SERVER_PASSWORD'))
                                                            ->join( 'production_area_location as pla' , 'pla.ID' , '=' , 'plf.PRODUCTION_LOCATION' )
                                                            ->where('plf.STATUS','ACTIVE')
                                                            ->where('plf.PRODUCTION_LOCATION',$locationId)
                                                            ->first();            
            $q          =       DB::getQueryLog();
          
           
            
            //$cucinfo->FTP_PASSWORD      =        \Crypt::decryptString($cucinfo->FTP_PASSWORD);
       }
        catch( \Exception $e )
        {           
            return false;
        }
        return $cucinfo;
    }
    
    
    public static function getProductionLocationList( $input = array() ){          
        
        $tbl              =     'production_location_ftp as plf'; 
        DB::enableQueryLog();
        $response       =       array();
        $contact_info     =     DB::table( $tbl )
                                            ->select( 'plf.ID' , DB::RAW( 'plf.PRODUCTION_LOCATION+0 as PRODUCTION_LOCATION_ID'   ) , 'pal.LOCATION_NAME as PRODUCTION_LOCATION'  , 'plf.FTP_HOST' , 'plf.FTP_USER_NAME' , 'plf.FTP_PASSWORD' , 'plf.FTP_PATH' ) 
                                            ->leftJoin( 'production_area_location as pal' , 'pal.ID' , '=' , 'plf.PRODUCTION_LOCATION' )
                                            ->where('plf.STATUS', '=', 'ACTIVE') 
                                            ->get();
        $qr         =       DB::getQueryLog();
        $contact_info  =   $contact_info;
        
        if( !empty( $contact_info ) ){
            
            foreach( $contact_info as $key => $value ){
                $value->FTP_PASSWORD  =   Crypt::decryptString( $value->FTP_PASSWORD );
                $response[]   =   $value;
            }
            
        }
        
        return $response;
        
    }
    
    public static function getpmProductionLocationList( $pmid){          
        
        $contact_info   =       array();
        $tblname        =       'pm_location_mapping as pml';
        try{
           
            $select_field   =       array( 'pml.ID' , 'pml.PRODUCTION_AREA' , DB::RAW( 'pml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 'pml.PROJECT_MANAGER_ID' , 'pml.STATUS' , 'usr.FIRST_NAME as MANAGER_NAME');
            
            $contact_info   =       DB::table( $tblname )
                                    ->leftJoin( 'user as usr' , 'pml.PROJECT_MANAGER_ID', '=', 'usr.USER_ID')           
                                    ->select( $select_field )
                                    ->where('pml.PROJECT_MANAGER_ID', '=', $pmid) 
                                    ->Where( 'pml.STATUS', '=' , 'ACTIVE' )
                                    ->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;
        
        
    }
    
    
     public static function updateLocation( $inpArr ){
        
        $setArr     =   array( 
                               'PRODUCTION_LOCATION'   => ( $inpArr['PRODUCTION_LOCATION'] )   , 
                               'FTP_HOST'  =>  $inpArr['FTP_HOST'] ,
                               'FTP_USER_NAME'    =>  $inpArr['FTP_USER_NAME'] ,
                               'FTP_PASSWORD'  =>  Crypt::encryptString(  $inpArr['FTP_PASSWORD'] ) , 
                               'FTP_PATH'  =>  $inpArr['FTP_PATH'] , 
                               'LAST_MOD_DATE'  =>  date( 'Y-m-d H:i:s' ) , 
                               'LAST_MOD_BY'    =>  $inpArr['user_id']
                        );
        
        
        $updateQry  =   DB::table('production_location_ftp')
			->where('ID', $inpArr['ID'])
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function deletePrdLocation( $rowid  =   null ){
        
        $response   =   false;
        $tbl      =   'production_location_ftp';
        
        if( !is_null( $rowid ) ){            
            $response       =       DB::table( $tbl )->where( 'ID' , '=' ,  $rowid )->delete();           
        }
        
        return $response;
        
    }
    
    public static function getListWithPmDetails( ){
        
        $contact_info   =       array();
        $tblname        =       'pm_location_mapping as pml';
        
        try{
           
            $select_field   =       array( 'pml.ID' , 'pml.PRODUCTION_AREA' , DB::RAW( 'pml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 'pml.PROJECT_MANAGER_ID' , 'pml.STATUS' , 'usr.FIRST_NAME as MANAGER_NAME');
            
            $contact_info   =       DB::table( $tblname )
                                    ->leftJoin( 'user as usr' , 'pml.PROJECT_MANAGER_ID', '=', 'usr.USER_ID')           
                                    ->select( $select_field )
                                    ->Where( 'pml.STATUS', '=' , 'ACTIVE' )
                                    ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;     
    }
    
    public static function getlocationofPmDetails( ){
        
        $contact_info   =       array();
        $tblname        =       'pm_location_mapping as pml';
        
        try{
            $select_field   =       array( 'pml.ID' , 'pml.PRODUCTION_AREA' , DB::RAW( 'pml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 'pml.PROJECT_MANAGER_ID' , 'pml.STATUS' , 'usr.FIRST_NAME as MANAGER_NAME');
            
            $contact_info   =       DB::table( $tblname )
                                    ->leftJoin( 'user as usr' , 'pml.PROJECT_MANAGER_ID', '=', 'usr.USER_ID')           
                                    ->select( $select_field )
                                    ->Where( 'pml.STATUS', '=' , 'ACTIVE' )
                                    ->Where( 'pml.PROJECT_MANAGER_ID', '=' , Session::get('users')['user_id'] )
                                    ->first();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;     
    }
    
    public static function insertPmLocation( ){
        
    }
    
    public static function getJobLocationServerPath($jobId){
       $pathArray = array();
       $getlocationftp     =      productionLocationModel::doGetLocationname( $jobId );
       
       if(empty($getlocationftp))
           return false;
       
        $host   =   $hostserver         =       $getlocationftp->FTP_HOST;
        $usr    =   $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $psw    =   $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        
        $hostpath           =       ($getlocationftp->FTP_PATH);
        
        $crd                =       'ftp://'.$usr.':'.$psw.'@'; 
        $ftp_path   =       \Config::get('serverconstants.FILE_SERVER_FTP_PATH');
        $pathArray['HOST'] = $host;
        $pathArray['FTP_PATH'] = $ftp_path;
        $pathArray['HOST_PATH'] = $hostpath;
        $pathArray['FTP_HOST'] = $host;
        $pathArray['FTP_USERNAME'] = $usr;
        $pathArray['FTP_PASSWORD'] = $psw;
        $pathArray['FTP_PATH_CREDENTIAL'] = $crd;
        $pathArray['SERVER_PATH'] = $host.$hostpath;
        $pathArray['FILE_SERVER_PATH'] = $host.$getlocationftp->FILE_SERVER_PATH;
        $pathArray['FILE_SERVER_USER_NAME'] = $getlocationftp->FILE_SERVER_USER_NAME;
        $pathArray['FILE_SERVER_PASSWORD'] = $getlocationftp->FILE_SERVER_PASSWORD;
        $pathArray['FILE_SERVER_USER_PASSWORD'] = '<>'.$getlocationftp->FILE_SERVER_USER_NAME.'<>'.$getlocationftp->FILE_SERVER_PASSWORD;
        
        return $pathArray;
    }
   
    public static function getDefaultProductionLocationInfo(){
        
        $location_arr       =       array();
        
        $host       =       \Config::get('serverconstants.FILE_SERVER_HOST');
        $user       =       \Config::get('serverconstants.FILE_SERVER_USER');
        $pass       =       \Config::get('serverconstants.FILE_SERVER_PASS');
        $ftp_path   =       \Config::get('serverconstants.FILE_SERVER_FTP_PATH');
        $file_server        =       \Config::get('serverconstants.FILE_SERVER_ROOT_DIR').\Config::get('serverconstants.FILE_SERVER_FTP_PATH');
        $crd                =       'ftp://'.$user.':'.$pass.'@'; 
        
        $location_arr       =   array( 'FTP_HOST' => $host , 'HOST' => $host ,'HOST_PATH' => $ftp_path,'FTP_USER_NAME' => $user ,'FTP_USERNAME' => $user , 
                                       'FTP_PASSWORD' => \Crypt::encryptString( $pass ), 'FTP_PATH' => $ftp_path , 
                                       'FILE_SERVER_PATH'   =>  $file_server,
                                       'SERVER_PATH'   =>  $host.'/'.$ftp_path,
                                       'FTP_PATH_CREDENTIAL' => $crd,
                                       'FILE_SERVER_USER_NAME'=>\Config::get('serverconstants.MAGNUS_DOMAIN_USERNAME'),
                                       'FILE_SERVER_PASSWORD'=>\Config::get('serverconstants.MAGNUS_DOMAIN_PASSWORD')
                                     );
        
        return (object)$location_arr;
        
    }
    
    public static function getJobLocationServerPathWithDefaultProductionLocation($jobId,$location){
       $pathArray = array();
       $getlocationftp     =      productionLocationModel::doGetLocationnameByDefault( $jobId, $location );
       
       if(empty($getlocationftp))
           return false;
       
        $host   =   $hostserver         =       $getlocationftp->FTP_HOST;
        $usr    =   $hostusername       =       $getlocationftp->FTP_USER_NAME;
        $psw    =   $hostpassword       =       \Crypt::decryptString($getlocationftp->FTP_PASSWORD);
        
        $hostpath           =       ($getlocationftp->FTP_PATH);
        
        $crd                =       'ftp://'.$usr.':'.$psw.'@'; 
        
        $pathArray['HOST'] = $host;
        $pathArray['HOST_PATH'] = $hostpath;
        $pathArray['FTP_USERNAME'] = $usr;
        $pathArray['FTP_PASSWORD'] = $psw;
        $pathArray['FTP_PATH_CREDENTIAL'] = $crd;
        $pathArray['SERVER_PATH'] = $host.$hostpath;
        $pathArray['FILE_SERVER_PATH'] = $host.$getlocationftp->FILE_SERVER_PATH;
        $pathArray['FILE_SERVER_USER_NAME'] = $getlocationftp->FILE_SERVER_USER_NAME;
        $pathArray['FILE_SERVER_PASSWORD'] = $getlocationftp->FILE_SERVER_PASSWORD;
        $pathArray['FILE_SERVER_USER_PASSWORD'] = '<>'.$getlocationftp->FILE_SERVER_USER_NAME.'<>'.$getlocationftp->FILE_SERVER_PASSWORD;
        
        return $pathArray;
    }
    
   
}

