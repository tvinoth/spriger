<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class jobTimeSheet extends Model {
    
    protected $table    =   'job_time_sheet';
    public $primaryKey  =   'JOB_TIME_SHEET_ID';
    public $timestamps  =   true;
    protected $fillable =   array('CREATED_DATE');
    protected $dateFormat = 'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $ins_obj        =       new jobTimeSheet();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $ins_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $ins_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    
    /*
     * parameters are jobid , round  , stage , USER_ID
     */
    
    
    public function hasCheckedoutEntry( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $re_status   =   DB::table( $tblname )
                                        ->where( 'JOB_ID', '=', $inp_arr['JOB_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['CREATED_BY'] )  
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                       // ->where( 'CHECK_IN', '<>',  '' )
                                        ->whereNull( 'CHECK_IN' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        
        $qu =   DB::getQueryLog();
        
        if( !empty( $re_status ) )
            return true;
        
        return false;
        
    }
    
    public function hasOtherJobCheckedOutEntry( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $re_status   =   DB::table( $tblname )
                                        ->where( 'JOB_ID', '!=', $inp_arr['JOB_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['CREATED_BY'] )  
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                       // ->where( 'CHECK_IN', '<>',  '' )
                                        ->whereNull( 'CHECK_IN' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        
		
        $qu =   DB::getQueryLog();
        //print_r( $qu );
        if( !empty( $re_status ) )
            return $re_status;
        
        return false;
        
    }
    
	public function hasChapterCheckedOutOtherByMe( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $re_status   =   DB::table( $tblname )
                                        ->where( 'METADATA_ID', '!=', $inp_arr['METADATA_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['CREATED_BY'] )  
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                       // ->where( 'CHECK_IN', '<>',  '' )
                                        //->whereNull( 'CHECK_IN' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        
		
        $qu =   DB::getQueryLog();
        
        if( !empty( $re_status ) )
            return $re_status;
        
        return false;
        
    }
	
	public function hasChapterCheckedOutEntry( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $re_status   =   DB::table( $tblname )
                                        ->where( 'METADATA_ID', '=', $inp_arr['METADATA_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['CREATED_BY'] )  
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                       // ->where( 'CHECK_IN', '<>',  '' )
                                        ->whereNull( 'CHECK_IN' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        
		
        $qu =   DB::getQueryLog();
        
        if( !empty( $re_status ) )
            return $re_status;
        
        return false;
        
    }
    
	public function hasOthersChapterCheckedOutEntry( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $re_status   =   DB::table( $tblname )
                                        ->where( 'METADATA_ID', '=', $inp_arr['METADATA_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '!=',  $inp_arr['CREATED_BY'] )  
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                       // ->where( 'CHECK_IN', '<>',  '' )
                                        ->whereNull( 'CHECK_IN' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        
		
        $qu =   DB::getQueryLog();
        
        if( !empty( $re_status ) )
            return $re_status;
        
        return false;
        
    }
    
    /*
     * parameters are jobid , round  , stage , USER_ID
     */
    
    public function getRecordsOfPartialCheckin( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        $information   =   DB::table( $tblname )
                                        ->where( 'JOB_ID', '=', $inp_arr['JOB_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        //->where( 'CREATED_BY', '!=',  $inp_arr['CREATED_BY'] )
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                        ->where( 'CHECK_IN', '<>',  '' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        $qu =   DB::getQueryLog();
        
        return $information;
        
    }
    
    
    /*
     * parameters are jobid , round  , stage , USER_ID
     */
    
    public function getCheckedOutRecords( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $information   =   DB::table( $tblname )
                                        ->where( 'JOB_ID', '=', $inp_arr['JOB_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['USER_ID'] )
                                        ->where( 'STATUS', '=',  1 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        $qu =   DB::getQueryLog();
        
        //print_r( $qu );
        return $information;
        
    }
    
    public function getCheckedOutComplete( $inp_arr ){
        
        $tblname    =   'job_time_sheet';
        
        DB::enableQueryLog();
        
        $information   =   DB::table( $tblname )
                                        ->where( 'JOB_ID', '=', $inp_arr['JOB_ID'] )
                                        ->where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        ->where( 'CREATED_BY', '=',  $inp_arr['USER_ID'] )
                                        ->where( 'STATUS', '=',  2 )
                                        ->where( 'CHECK_OUT', '<>',  '' )
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->first();
        
        $qu =   DB::getQueryLog();
        
        //print_r( $qu );
        return $information;
        
    }
    
    public static function updateIfExist( $setArr = array() , $rowid ){
        
        DB::enableQueryLog();
        
         $updateQry  =   DB::table('job_time_sheet')
			->where('JOB_TIME_SHEET_ID', $rowid )
			->update( $setArr );
        
        
         $qr        =       DB::getQueryLog();
         
        return $updateQry;
    }
    
    // check id exist
    public static function checkMetaidexist($metaid = null)
    {
        $getJob =   [];
        try
	{
            $getJob     =   jobTimeSheet::where('METADATA_ID',$metaid)->first();
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
    // check metaid,stage,round exist
    public static function checkMetaRundStageexist($metaid = null,$round = null,$stage = null)
    {
        $getJob =   [];
        try
	{
            $getJob     =   jobTimeSheet::where('METADATA_ID',$metaid)->where('ROUND_ID',$round)->where('STAGE',$stage)->first();
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
    public static function doAddNewTime($data = [])
    {
        $getJob     =	false;
        try
        {
            $getJob =   jobTimeSheet::insertGetId($data);
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
    public static function getJimetimelastcuc($id = null)
    {
        $getJob     =	false;
        try
        {
            $getJob =   DB::select('SELECT tlm.METADATA_ID as taskmetaid,tlm.PII,tlm.CHAPTER_NAME,tlm.CHAPTER_NO,tlm.JOB_ID,job.BOOK_ID,job.JOB_ID AS jobid,job.JOB_TITLE,jt.JOB_TIME_SHEET_ID as jobtimesheetid,count(jt.METADATA_ID) as totalcount,jt.JOB_ID,jt.JOB_ID,jt.METADATA_ID,jt.ROUND_ID,jt.STAGE,jt.CHECK_OUT,jt.CHECK_IN,jt.CREATED_BY,jt.STATUS,round_enum.NAME AS roundname,stage.STAGE_ID,stage.STAGE_NAME FROM task_level_metadata as tlm
                        JOIN job on job.JOB_ID  = tlm.JOB_ID JOIN  job_time_sheet as jt on tlm.METADATA_ID = jt.METADATA_ID  JOIN round_enum ON round_enum.ID = jt.ROUND_ID
                        JOIN stage ON stage.STAGE_ID = jt.STAGE where jt.JOB_TIME_SHEET_ID = '.$id.' and jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.CUC').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.CUC'));
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
    public static function getJimetimelastindexing($id = null)
    {
        $getJob     =	false;
        try
        {
            $getJob =   DB::select('SELECT tlm.METADATA_ID as taskmetaid,tlm.PII,tlm.CHAPTER_NAME,tlm.CHAPTER_NO,tlm.JOB_ID,job.BOOK_ID,job.JOB_ID AS jobid,job.JOB_TITLE,jt.JOB_TIME_SHEET_ID as jobtimesheetid,count(jt.METADATA_ID) as totalcount,jt.JOB_ID,jt.JOB_ID,jt.METADATA_ID,jt.ROUND_ID,jt.STAGE,jt.CHECK_OUT,jt.CHECK_IN,jt.CREATED_BY,jt.STATUS,round_enum.NAME AS roundname,stage.STAGE_ID,stage.STAGE_NAME FROM task_level_metadata as tlm
                        JOIN job on job.JOB_ID  = tlm.JOB_ID JOIN  job_time_sheet as jt on tlm.METADATA_ID = jt.METADATA_ID  JOIN round_enum ON round_enum.ID = jt.ROUND_ID
                        JOIN stage ON stage.STAGE_ID = jt.STAGE where jt.JOB_TIME_SHEET_ID = '.$id.' and jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.INDEXING').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.S5'));
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
    public static function getJimetimelastcopyediting($id = null)
    {
        $getJob     =	false;
        try
        {
            $getJob =   DB::select('SELECT tlm.METADATA_ID as taskmetaid,tlm.PII,tlm.CHAPTER_NAME,tlm.CHAPTER_NO,tlm.JOB_ID,job.BOOK_ID,job.JOB_ID AS jobid,job.JOB_TITLE,jt.JOB_TIME_SHEET_ID as jobtimesheetid,count(jt.METADATA_ID) as totalcount,jt.JOB_ID,jt.JOB_ID,jt.METADATA_ID,jt.ROUND_ID,jt.STAGE,jt.CHECK_OUT,jt.CHECK_IN,jt.CREATED_BY,jt.STATUS,round_enum.NAME AS roundname,stage.STAGE_ID,stage.STAGE_NAME FROM task_level_metadata as tlm
                        JOIN job on job.JOB_ID  = tlm.JOB_ID JOIN  job_time_sheet as jt on tlm.METADATA_ID = jt.METADATA_ID  JOIN round_enum ON round_enum.ID = jt.ROUND_ID
                        JOIN stage ON stage.STAGE_ID = jt.STAGE where jt.JOB_TIME_SHEET_ID = '.$id.' and jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.COPY_EDITING').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.S5'));
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
	//cuc check out exist already
    public function checkcucCheckedOutEntryexist( $inp_arr )
	{    
        DB::enableQueryLog();
        $re_status   =   jobTimeSheet::where( 'ROUND_ID', '=', $inp_arr['ROUND_ID'] )
                                        ->where( 'METADATA_ID', '=', $inp_arr['METADATA_ID'] )
                                        ->where( 'STAGE', '=',  $inp_arr['STAGE'] )
                                        //->where( 'CREATED_BY', '=',  $inp_arr['CREATED_BY'] )  
                                        ->orderBy('JOB_TIME_SHEET_ID', 'desc')
                                        ->get();
        $qu =   DB::getQueryLog();       
		
        if( !empty( $re_status ) )
            return $re_status;
		
        return false;
		
    }
	
    public static function getMaxoftimesheetrecords( $data ){
        
        DB::enableQueryLog();
        $re_status   =   jobTimeSheet::select(DB::raw('max(JOB_TIME_SHEET_ID) as timesheetid'))
                                        ->where( $data )
                                        ->first();
        
        
        $qu =   DB::getQueryLog();
        
        if( !empty( $re_status ) )
            return $re_status;
        return false;
    }
    
    public static function doCheckexistTimeSheetId($wheredata)
    {
        $getJob     =	false;
        try
        {
            $getJob =   jobTimeSheet::where($wheredata)->first();
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
    
}

