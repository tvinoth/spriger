<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;
use App\Models\bgprocessSupPathSetup;
use App\Models\bgprocessTagsSetup;

class bgprocessPathSetup extends Model {    
    
    protected   $table          =   'bgprocess_path_setup';
    public      $primaryKey     =   'ID';
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new bgprocessPathSetup();
        if( !empty( $inp_arr ) ){
            foreach( $inp_arr as  $index => $value ){
                $api_obj->$index    =   $value;
            }
        }
        $insert_r       =       $api_obj->save();
        if( $insert_r )
            return 2;
        
        return 1;
        
    }
    
    public function getBgProcessSetup( $round , $processname = null , $stageid = null , $type = null , $wrflmstid = null ){
        
        $query      =   DB::table('bgprocess_path_setup')
                            ->select()
                            ->where('STATUS' , '=' , 1 );
        
        if( !is_null( $processname ) )
            $query->where( 'PROCESS_NAME' , '=' , $processname );
        
        if( !is_null( $round ) )
            $query->where( 'ROUND' , '=' , $round );
        
        if( !is_null( $stageid ) )
            $query->where( 'STAGE_ID' , '=' , $stageid  );
        
        if( !is_null( $type ) )
            $query->where( 'TYPE' , '=' , $type  );
        
        if( !is_null( $wrflmstid ) )
            $query->where( 'WORKFLOW_MASTER_ID' , '=' , $wrflmstid  );
       
        
        $records        =       $query->get()->first();
      
     
        return $records;
        
    }
    
    public function getSetup($stageid , $round , $wmid , $wfid  , $bgtype = null ){
    
        $query      =   DB::table('bgprocess_path_setup')
                            ->select()
                            ->where('STATUS' , '=' , 'ACTIVE' )
                            ->where('ROUND' , '=' , $round )
                            ->where('STAGE_ID' , '=' , $stageid )
                            ->where('WORKFLOW_MASTER_ID' , '=' , $wmid )
                            ->where('WORKFLOW_ID' , '=' , $wfid );  
        
        if( !is_null( $bgtype ) ){
            $query->where( 'TYPE' , '=' , strtoupper( $bgtype ) );
        }
        
        $records    =   $query->orderBy( 'order' ,  'asc' )
        ->get();    
       
        return $records;
        
    }   
    
    public function getBgProcessMetaXmlFormat( $round , $processname , $stageid ){
        
        $parent_info        =       $this->getBgProcessSetup( $round , $processname , $stageid );
        $parentid           =       $parent_info->ID;
        
        $subtbl_obj         =       new bgprocessSubPathSetup();
        $tags_              =       $subtbl_obj->getBgProcessTags( $parentid );
        
        $parent_info->children      =       $tags_;
        
        $preparedData         =       $this->prepareFormatedData( $parent_info );
        
        return $preparedData;
        
    }
    
    public function getChunkProcessName( $round , $stageid , $type = null , $workflowid = null ){
       
        $query      =   DB::table('bgprocess_path_setup')
                            ->select()
                            ->where('STATUS' , '=' , 'ACTIVE' )
                            ->where('ROUND'  , '=' , $round )
                            ->where('STAGE_ID' , '=' , $stageid )
                            ->where( 'STATUS' , '=' , 'ACTIVE' );
        
        if( !is_null( $type ) ) 
            $query->where( 'TYPE' , '=' , $type );
        
        if( !is_null( $workflowid ) ) 
            $query->where( 'WORKFLOW_MASTER_ID' , '=' , $workflowid );
        
        $query2     =    $query->orderBy( 'order' ,  'asc' )->get();    
      
        return $query2;
        
    }
    
    public function getBgProcessMetaDirectXmlArray( $round , $processname , $stageid , $type = null ,  $wmstrid = null ){
        
        $parent_info        =       $this->getBgProcessSetup( $round , $processname , $stageid , $type , $wmstrid );
        
        $parentid           =       $parent_info->ID;
        
        $subtbl_obj         =       new bgprocessTagsSetup();
       
        $tags_              =       $subtbl_obj->getBgProcessTags( $parentid );
       
        $attributestr          =       '';
        
        if( count( $tags_ ) ){
            
            $subtags    =        $tags_[0]->TAG_FORMAT;
            
           if( isset( $parent_info->ATTRIBUTE ) && !empty( $parent_info->ATTRIBUTE ) ){
               
                $attribute  = json_decode( $parent_info->ATTRIBUTE );
               
                foreach( $attribute as $key => $index ){
                    $attributestr      .=    " $key='$index' ";
                }
                
                $xmlstr     =        "<$parent_info->TAG_NAME $attributestr>$subtags</$parent_info->TAG_NAME>";
                
           }else{ 
                $xmlstr     =        "<$parent_info->TAG_NAME>";
                $xmlstr     .=       $subtags;
                $xmlstr     .=       "</$parent_info->TAG_NAME>";
           }
           
            $xmlstr = str_replace(array("\n", "\r", "\t"), '', $xmlstr);
            $xmlstr = trim(str_replace('"', "'", $xmlstr));
           
            if( is_null( $type ) ){
                //return json_decode( json_encode(simplexml_load_string( $xmlstr ) , true ) );
            }
           
            return $xmlstr;    
            
        }
        
        return array();
        
    }
    
    public function getBgProcessMetaDirectXmlArrayObserveXml( $round , $processname , $stageid , $type = null ){
        
        $parent_info        =       $this->getBgProcessSetup( $round , $processname , $stageid , $type );
        $parentid           =       $parent_info->ID;
        
        $subtbl_obj         =       new bgprocessTagsSetup();
       
        $tags_              =       $subtbl_obj->getBgProcessTags( $parentid );
        $attributestr          =       '';
        
        if( count( $tags_ ) ){
            
            $subtags    =        $tags_[0]->TAG_FORMAT;
            
           if( isset( $parent_info->ATTRIBUTE ) && !empty( $parent_info->ATTRIBUTE ) ){
               
                $attribute  = json_decode( $parent_info->ATTRIBUTE );
                
                foreach( $attribute as $key => $index ){
                    $attributestr      .=    " $key='$index' ";
                }
                
                $xmlstr     =        "<$parent_info->TAG_NAME $attributestr>$subtags</$parent_info->TAG_NAME>";
                
           }else{
               
               if( !empty( $parent_info->TAG_NAME ) ){
                   
                    $xmlstr     =        "<$parent_info->TAG_NAME>";
                    $xmlstr     .=       $subtags;
                    $xmlstr     .=       "</$parent_info->TAG_NAME>";
                    
               }else{
                    $xmlstr     .=       $subtags;                    
               }
                
           }
           
            $xmlstr = str_replace(array("\n", "\r", "\t"), '', $xmlstr);
            $xmlstr = trim(str_replace('"', "'", $xmlstr));
           
            if( is_null( $type ) ){
                //return json_decode( json_encode(simplexml_load_string( $xmlstr ) , true ) );
            }
            
            return $xmlstr;    
            
        }
        
        return array();
        
    }
    
    
    public function prepareFormatedData( $rec_obj = array() ){
        
        $preparedData       =       array( );
        $parent_tag         =       $rec_obj->TAG_NAME;   
        $preparedData[$parent_tag]   =   $parent_tag;
        $preparedDataChild      =       array();
                
            if( !empty( $rec_obj->ATTRIBUTE ) ){
                $preparedDataChild['@attributes']    =   array( $rec_obj->ATTRIBUTE => '' );
            }else if( !empty( $rec_obj->TEXT ) ){
                $preparedDataChild['tagtext']       =   array( $rec_obj->TEXT  => '' );
            }
        
            $parent_id              =       $rec_obj->ID;
            
            $this->tagArrayPrepare( $rec_obj->children , $parent_id , $preparedDataChild['tagCollect'] );
            
            $preparedData[$parent_tag]         =   $preparedDataChild;
            
        return $preparedData;
        
    }
    
    public function tagArrayPrepare( $rec_obj , $parent_id , &$preparedData ){
       
        //finding child is avail
        $subtbl_obj         =       new bgprocessSubPathSetup();
        
        foreach( $rec_obj as $index => $value ){
            
            $sub_tag_obj    =   $subtbl_obj->getBgProcessSubTags( $value->ID );
            
            if( !empty( $sub_tag_obj ) ){
                if( $sub_tag_obj->count() ){
                    foreach( $sub_tag_obj as $inner_key => $inner_value  ){
                        $this->tagArrayPrepare( array( $inner_value ) , $inner_value->ID , $preparedData[$value->TAG_NAME] );
                    }
                }
            }
            
            if( $value->PARENT_ID == $parent_id && empty( $value->SUB_PARENT_ID ) ){
                
                if( !empty( $value->ATTRIBUTE ) ){
                    $preparedData[$value->TAG_NAME]['@attributes']    =   array( $value->ATTRIBUTE => '' );
                }

                if( !empty( $value->TEXT ) ){
                    $preparedData[$value->TAG_NAME]['tagtext']       =   $value->TEXT;
                }
                
            }
            
            if( !empty( $value->SUB_PARENT_ID ) ){
               if( !empty( $value->ATTRIBUTE ) ){
                    $preparedData['tagCollect'][$value->TAG_NAME]['@attributes']    =   array( $value->ATTRIBUTE => '' );
                }
                if( !empty( $value->TEXT ) ){
                    $preparedData['tagCollect'][$value->TAG_NAME]['tagtext']       =   $value->TEXT;
                }
                
            }
            
        }
        
    }
    
}

