<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;
class bgProcessModel extends Model 
{    
    protected $table        =   'bgprocess';
    public  $primaryKey     =   'ID';
      
    public static function getChapterlevelretry( $type , $status ){
      
        switch($type){
			
				case 38:
                $roundid    =   ($type  ==  38?Config::get('constants.ROUND_ID.S600'):Config::get('constants.ROUND_ID.S650'));
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = ".$roundid."
                    GROUP BY aep.METADATA_ID,aep.ROUND";
					
            break;
			
			case 39 :
                $roundid    =   ($type  ==  28?Config::get('constants.ROUND_ID.S600'):Config::get('constants.ROUND_ID.S650'));
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = ".$roundid."
                    GROUP BY aep.METADATA_ID,aep.ROUND";
					
					
            break;
            
            case 1: 
            // spice                
            $query_stmt         =       "SELECT j.JOB_ID,j.BOOK_ID,tlmd.METADATA_ID, aas.ROUND AS ROUND_ID,CASE aas.ROUND WHEN 116 THEN 'S200' ELSE 'S200' END AS ROUND_NAME,
            j.JOB_TITLE,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
            aas.STATUS ,aas.START_TIME,aas.REMARKS,aas.END_TIME,js.JOB_STAGE_ID FROM task_level_metadata tlmd 
            INNER JOIN job j ON j.JOB_ID = tlmd.JOB_ID
            INNER JOIN api_auto_stage aas on aas.METADATA_ID = tlmd.METADATA_ID 
            INNER JOIN job_round jr ON jr.METADATA_ID = aas.METADATA_ID AND jr.ROUND_ID = aas.ROUND
            INNER JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND js.ITERATION_ID = jr.CURRENT_ITERATION_ID AND js.STAGE_ID = aas.STAGE
				and aas.ID IN ( select max( ame2.ID ) from api_auto_stage ame2 where ame2.METADATA_ID = aas.METADATA_ID order by ame2.ID desc )
            WHERE tlmd.is_active = 1 and  aas.STATUS = '".$status."' AND (aas.PROCESS_TYPE= 1 OR aas.PROCESS_TYPE is null)  GROUP BY tlmd.METADATA_ID ";
           
            break;
            
            case 2: //taps
			
            $query_stmt         =       "SELECT j.JOB_ID,j.BOOK_ID,tlmd.METADATA_ID, apitps.ROUND AS ROUND_ID,CASE apitps.ROUND WHEN 116 THEN 'S200' ELSE 'S200' END AS ROUND_NAME,
            j.JOB_TITLE,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
            apitps.`TAPSCOMPLETION_STATUS` as STATUS, apitps.`REMARKS`,apitps.START_TIME,apitps.END_TIME FROM task_level_metadata tlmd 
            INNER JOIN job j ON j.JOB_ID = tlmd.JOB_ID
            inner join api_taps apitps on apitps.METADATA_ID = tlmd.METADATA_ID and apitps.ID IN ( select max( ac2.ID ) from api_taps ac2 where ac2.METADATA_ID = apitps.METADATA_ID order by ac2.ID desc)
            WHERE tlmd.is_active = 1 ";
                
            if($status   ==  '1.5'){
                $query_stmt.=  " and  apitps.TAPSCOMPLETION_STATUS = '".$status."' ";
            }else if( $status   ==  '3' ) { 
                $query_stmt.=  " and ( apitps.TAPSCOMPLETION_STATUS = '".$status."' ) and apitps.REMARKS <> '' ";
            }else{
                $query_stmt.=  " and  apitps.TAPSCOMPLETION_STATUS = '".$status."' ";
            }    
			
            $query_stmt.=  "GROUP BY tlmd.METADATA_ID";
        
			break;
            
            case 3 :
                //eproof packaging
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID, re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
					api_eproof_packaging aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_eproof_packaging aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND 
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND IN ( 118 )
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                            
                break;
            
            case 4 : //eproof submission check
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID, re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_eproof_packaging aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_eproof_packaging aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND AND aep2.PROCESS_TYPE = 2
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.PROCESS_TYPE = 2 
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
            
            case 5 : //success redo 
                
                $query_stmt =    "SELECT apu.ID , jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
					aca.ID AS CLIACKID , aca.`STATUS` , aca.CREATED_AT AS START_TIME , aca.END_TIME , aca.REMARKS 
					FROM task_level_metadata tlmd join 
					api_ftp_upload apu on apu.METADATA_ID = tlmd.METADATA_ID AND apu.ID IN (
					SELECT MAX(apu2.ID)
					FROM api_ftp_upload apu2
					WHERE apu2.METADATA_ID = apu.METADATA_ID AND apu2.ROUND = apu.ROUND
					ORDER BY apu2.ID DESC )
					join api_client_acknowledgement aca ON aca.METADATA_ID = tlmd.METADATA_ID AND aca.ID IN ( 
					SELECT MAX(aca2.ID)
					FROM api_client_acknowledgement aca2
					WHERE aca2.METADATA_ID = aca.METADATA_ID AND aca2.ROUND = aca.ROUND
					ORDER BY aca2.ID DESC )
					LEFT JOIN  job jb on jb.JOB_ID = tlmd.JOB_ID 
					LEFT JOIN round_enum re ON re.ID = aca.ROUND 
					WHERE aca.`STATUS` = '$status' AND aca.ROUND =  116 
					AND aca.PROCESS_TYPE_DIFF = 5 AND apu.ROUND =   116
					AND apu.PROCESS_TYPE = 1 AND apu.`STATUS`  =	2 
					GROUP BY aca.METADATA_ID,aca.ROUND";
                
                break;
            
            case 6 : //Cuc check
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME AS ROUND_NAME, re.ID AS ROUND_ID, 
                                acuc.`STATUS`, acuc.START_TIME,acuc.ID, acuc.END_TIME, acuc.REMARKS
                               FROM  job jb
                               JOIN job_info ji ON jb.JOB_ID = ji.JOB_ID
                               LEFT JOIN api_cuc acuc ON acuc.JOB_ID = ji.JOB_ID AND acuc.ID IN (
                               SELECT MAX(acuc2.ID)
                               FROM api_cuc acuc2
                               WHERE acuc2.JOB_ID = acuc.JOB_ID AND acuc2.ROUND = acuc.ROUND
                               ORDER BY acuc.ID DESC)
                               LEFT JOIN round_enum re ON re.ID = acuc.ROUND
                               WHERE acuc.`STATUS` = '$status'
                               GROUP BY ji.JOB_ID";
                break;
            case 8 : 
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 118
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
            
            case 9 : 
                
                $status     =  ( $status == 3 ) ? '3,0' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_ftp_upload aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_ftp_upload aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 118 and PROCESS_TYPE = 'DESPATCH'
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
            
            case 10 : 
                
                $status     =  ( $status == 3 ) ? '3,0' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_pdfcompare aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_pdfcompare aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 118 
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
            
            case 11 : 
                    $status     =  ( $status == 3 ) ? '3,0' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_pitstop aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_pitstop aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 118 
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
            
            
            case 13 : //success redo 
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
					aca.ID AS CLIACKID , aca.`STATUS` , aca.CREATED_AT AS START_TIME  , aca.END_TIME , aca.REMARKS 
					FROM task_level_metadata tlmd join 
					api_ftp_upload apu on apu.METADATA_ID = tlmd.METADATA_ID AND apu.ID IN (
					SELECT MAX(apu2.ID)
					FROM api_ftp_upload apu2
					WHERE apu2.METADATA_ID = apu.METADATA_ID AND apu2.ROUND = apu.ROUND
					ORDER BY apu2.ID DESC ) join 
					api_client_acknowledgement aca ON aca.METADATA_ID = tlmd.METADATA_ID AND aca.ID IN ( 
					SELECT MAX(aca2.ID)
					FROM api_client_acknowledgement aca2
					WHERE aca2.METADATA_ID = aca.METADATA_ID AND aca2.ROUND = aca.ROUND
					ORDER BY aca2.ID DESC )
					LEFT JOIN  job jb on jb.JOB_ID = tlmd.JOB_ID 
					LEFT JOIN round_enum re ON re.ID = aca.ROUND 
					WHERE aca.`STATUS` = '$status' AND aca.ROUND = 118 
					AND aca.PROCESS_TYPE_DIFF = 5 AND apu.ROUND 	= 	118
					AND apu.PROCESS_TYPE = 1 AND  aca.FILE_NAME_IN_LOG NOT LIKE '%eProof_Contri%' AND apu.`STATUS`  	=	2 
					GROUP BY aca.METADATA_ID,aca.ROUND";
                
                break;
            
            case 14 : 
                
                //$status     =  ( $status == 3 ) ? '3,0' : $status;

                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,tlmd.METADATA_ID , re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                   aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.RESPONSE_LOG AS REMARKS 
                   from task_level_metadata tlmd join 
                   api_low_res aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                   SELECT MAX(aep2.ID)
                   FROM api_low_res aep2
                   WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                   ORDER BY aep2.ID DESC )
                   left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                   left join round_enum re on re.ID = aep.ROUND 
                   WHERE aep.`STATUS` IN ( '$status' ) 
                   GROUP BY aep.METADATA_ID,aep.ROUND";
               break;

            case 15 : 
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 116
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                
                break;
            
            case 16 : 
                
                $status     =  ( $status == 3 ) ? '3' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_ftp_upload aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_ftp_upload aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 116 and PROCESS_TYPE = 'DESPATCH'
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                 
                break;
            
            case 17: //taps
			
            $query_stmt         =       "SELECT j.JOB_ID,j.BOOK_ID,tlmd.METADATA_ID, apitps.ROUND AS ROUND_ID,CASE apitps.ROUND WHEN 116 THEN 'S200' ELSE 'S200' END AS ROUND_NAME,
            j.JOB_TITLE,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
            apitps.`TAPSCOMPLETION_STATUS` as STATUS, apitps.`REMARKS`,apitps.START_TIME,apitps.END_TIME FROM task_level_metadata tlmd 
            INNER JOIN job j ON j.JOB_ID = tlmd.JOB_ID
            inner join api_taps apitps on apitps.METADATA_ID = tlmd.METADATA_ID and apitps.ID IN ( select max( ac2.ID ) from api_taps ac2 where ac2.METADATA_ID = apitps.METADATA_ID order by ac2.ID desc)
            WHERE tlmd.is_active = 1 ";
                
            if($status   ==  '1.5'){
                $query_stmt.=  " and  apitps.TAPS_CE_STATUS = '".$status."' ";
            }else if( $status   ==  '3' ) { 
                $query_stmt.=  " and ( apitps.TAPS_CE_STATUS = '".$status."' )";
            }else{
                $query_stmt.=  " and  apitps.TAPS_CE_STATUS = '".$status."' ";
            }    
			
            $query_stmt.=  "GROUP BY tlmd.METADATA_ID";
        
			break;
                        
            case 18 : 
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_pdfmerge aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_pdfmerge aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 116
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
           
		   case 19: 
              // spice                
            $query_stmt         =       "SELECT j.JOB_ID,j.BOOK_ID,tlmd.METADATA_ID, aas.ROUND AS ROUND_ID,CASE aas.ROUND WHEN 116 THEN 'S200' ELSE 'S200' END AS ROUND_NAME,
            j.JOB_TITLE,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
            aas.STATUS ,aas.START_TIME,aas.REMARKS,aas.END_TIME,js.JOB_STAGE_ID FROM task_level_metadata tlmd 
            INNER JOIN job j ON j.JOB_ID = tlmd.JOB_ID
            INNER JOIN api_auto_stage aas on aas.METADATA_ID = tlmd.METADATA_ID 
            INNER JOIN job_round jr ON jr.METADATA_ID = aas.METADATA_ID AND jr.ROUND_ID = aas.ROUND
                INNER JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND js.ITERATION_ID = jr.CURRENT_ITERATION_ID
                                    and aas.ID IN ( select max( ame2.ID ) from api_auto_stage ame2 where ame2.METADATA_ID = aas.METADATA_ID and ame2.STAGE = '".Config::get('constants.STAGE_COLLEECTION.INDEXING_VALIDATION')."' order by ame2.ID desc )
            WHERE tlmd.is_active = 1 and  aas.STATUS = '".$status."' and aas.PROCESS_TYPE=2 GROUP BY tlmd.METADATA_ID ";
                break;
		
                case 20 : //success redo 

                        $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                aca.ID AS CLIACKID , aca.`STATUS` , aca.CREATED_AT AS START_TIME , aca.END_TIME , aca.REMARKS 
                FROM task_level_metadata tlmd JOIN 
                api_ftp_upload apu on apu.METADATA_ID = tlmd.METADATA_ID AND apu.ID IN (
                SELECT MAX(apu2.ID)
                FROM api_ftp_upload apu2
                WHERE apu2.METADATA_ID = apu.METADATA_ID AND apu2.ROUND = apu.ROUND AND apu2.PROCESS_TYPE = 2
                ORDER BY apu2.ID DESC 
                )
                JOIN
                api_client_acknowledgement aca ON aca.METADATA_ID = tlmd.METADATA_ID AND aca.ID IN ( 
                        SELECT MAX(aca2.ID)
                        FROM api_client_acknowledgement aca2 
                        WHERE aca2.METADATA_ID = aca.METADATA_ID AND aca2.ROUND = aca.ROUND 
                        ORDER BY aca2.ID DESC 
                )
                LEFT JOIN  job jb on jb.JOB_ID = tlmd.JOB_ID 
                LEFT JOIN round_enum re ON re.ID = aca.ROUND 
                WHERE aca.`STATUS` = '$status' AND aca.ROUND = 118 AND apu.status = 2 AND aca.PROCESS_TYPE_DIFF = 5 AND aca.FILE_NAME_IN_LOG LIKE '%eProof_Contri%' 
                GROUP BY aca.METADATA_ID,aca.ROUND";

                break;
                    
            case 21: 
                $roundid    =   Config::get('constants.ROUND_ID.S600');
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = ".$roundid."
                    GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
			
			
        
             case 22 : 
                
            $query_stmt = "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE,aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                  	api_bookMerge aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_bookMerge aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 119
                    GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
        
        case 23 : //Indexer check
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,ji.EMBBED_TYPE,re.NAME AS ROUND_NAME, re.ID AS ROUND_ID, 
                                ainx.`STATUS`, ainx.START_TIME,ainx.ID, ainx.END_TIME, ainx.REMARKS
                               FROM  job jb
                               JOIN job_info ji ON jb.JOB_ID = ji.JOB_ID
                               LEFT JOIN api_indexer ainx ON ainx.JOB_ID = ji.JOB_ID AND ainx.ID IN (
                               SELECT MAX(ainx2.ID)
                               FROM api_indexer ainx2
                               WHERE ainx2.JOB_ID = ainx.JOB_ID 
                               ORDER BY ainx.ID DESC)
                               LEFT JOIN round_enum re ON re.ID = ainx.ROUND
                               WHERE ainx.`STATUS` = '$status'
                               GROUP BY ji.JOB_ID";
                break;
            
            case 24 : 
                
            $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    apr.`STATUS` , apr.START_TIME , apr.END_TIME , apr.REMARKS 
                    from task_level_metadata tlmd join 
                              api_razor apr ON apr.METADATA_ID = tlmd.METADATA_ID AND apr.ID IN ( 
                    SELECT MAX(apr2.ID)
                    FROM api_razor apr2
                    WHERE apr2.METADATA_ID = apr.METADATA_ID and apr2.ROUND = apr.ROUND
                    ORDER BY apr2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = apr.ROUND 
                    WHERE apr.`STATUS` = '$status' and apr.ROUND = '".Config::get('constants.ROUND_NAME.S5')."'
                    GROUP BY apr.METADATA_ID,apr.ROUND";
        break;
         case 28 : 
                
            $query_stmt = "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE,aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                  	api_bookMerge aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_bookMerge aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 120
                    GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
		
            case 25 : 
                $status     =  ( $status == 3 ) ? '3,0' : $status;

             $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                from task_level_metadata tlmd join 
                          api_pitstop aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                SELECT MAX(aep2.ID)
                FROM api_pitstop aep2
                WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND and aep2.PRODUCT_TYPE = 6
                ORDER BY aep2.ID DESC )
                left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                left join round_enum re on re.ID = aep.ROUND 
                WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 119 and aep.PRODUCT_TYPE = 6
                GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
            case 26 : 
                $status     =  ( $status == 3 ) ? '3,0' : $status;

            $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                from task_level_metadata tlmd join 
                          api_pitstop aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                SELECT MAX(aep2.ID)
                FROM api_pitstop aep2
                WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND and aep2.PRODUCT_TYPE = 7
                ORDER BY aep2.ID DESC )
                left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                left join round_enum re on re.ID = aep.ROUND 
                WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND = 119 and aep.PRODUCT_TYPE = 7
                GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
			
			case 27 : 
                
            $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_dataset aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_dataset aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND = 120
                    GROUP BY aep.METADATA_ID,aep.ROUND";
            break;
			
            case $type == 29 || $type == 30 : //success redo 
                $roundid    =   ($type  ==  29?Config::get('constants.ROUND_ID.S600'):Config::get('constants.ROUND_ID.S650'));        
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
					aca.ID AS CLIACKID ,ad1.`STATUS` as PACKAGE_STATUS, aca.`STATUS`, aca.CREATED_AT AS START_TIME  , aca.END_TIME , aca.REMARKS 
					FROM task_level_metadata tlmd join 
					api_ftp_upload apu on apu.METADATA_ID = tlmd.METADATA_ID AND apu.ID IN (
					SELECT MAX(apu2.ID)
					FROM api_ftp_upload apu2
					WHERE apu2.METADATA_ID = apu.METADATA_ID AND apu2.ROUND = apu.ROUND
					ORDER BY apu2.ID DESC ) join 
					api_client_acknowledgement aca ON aca.METADATA_ID = tlmd.METADATA_ID AND aca.ID IN ( 
					SELECT MAX(aca2.ID)
					FROM api_client_acknowledgement aca2
					WHERE aca2.METADATA_ID = aca.METADATA_ID AND aca2.ROUND = aca.ROUND
					ORDER BY aca2.ID DESC )
					left join api_dataset ad1 on ad1.METADATA_ID= tlmd.METADATA_ID and ad1.ID in (
					select max(ad2.ID) from api_dataset ad2 where ad2.METADATA_ID = ad1.METADATA_ID and ad2.ROUND = ".$roundid." order by ad2.ID desc)
					LEFT JOIN  job jb on jb.JOB_ID = tlmd.JOB_ID 
					LEFT JOIN round_enum re ON re.ID = aca.ROUND 
					WHERE aca.`STATUS` = '$status' and tlmd.UNIT_OF_MEASURE = ".Config::get('constants.UNIT_OF_MEASURE')." AND aca.ROUND = ".$roundid." 
					AND aca.PROCESS_TYPE_DIFF = 5 AND apu.ROUND 	= 	".$roundid."
					AND apu.PROCESS_TYPE = 1 AND  aca.FILE_NAME_IN_LOG NOT LIKE '%eProof_Contri%' AND apu.`STATUS`  	=	2 
					GROUP BY aca.METADATA_ID,aca.ROUND";
                
            break;
            
            case $type == 31 || $type == 32 : 
                $roundid    =   ($type  ==  31?Config::get('constants.ROUND_ID.S600'):Config::get('constants.ROUND_ID.S650'));        
                $status     =  ( $status == 3 ) ? '3,0' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_ftp_upload aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_ftp_upload aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and tlmd.UNIT_OF_MEASURE = ".Config::get('constants.UNIT_OF_MEASURE')." and aep.ROUND = ".$roundid." and PROCESS_TYPE = 'DESPATCH'
                    GROUP BY aep.METADATA_ID,aep.ROUND";
					
                break;
        case 33 :
                //eproof packaging
            $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID , re.NAME as ROUND_NAME , re.ID as ROUND_ID , tlmd.JOB_ID , tlmd.BOOK_ID AS CHAPTER_NO , tlmd.BOOK_ID AS CHAPTER_TITLE , 
					aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from job tlmd join 
					api_eproof_packaging aep ON aep.JOB_ID = tlmd.JOB_ID AND aep.ROUND= 120 AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_eproof_packaging aep2
                    WHERE aep2.JOB_ID = aep.JOB_ID AND aep2.ROUND = aep.ROUND 
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND IN ( 120 )
                    GROUP BY aep.JOB_ID,aep.ROUND";
                            
                break;
				
        case 36 : //success redo 

				$query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                aca.ID AS CLIACKID , aca.`STATUS` , aca.CREATED_AT AS START_TIME , aca.END_TIME , aca.REMARKS 
                FROM task_level_metadata tlmd JOIN 
                api_ftp_upload apu on apu.METADATA_ID = tlmd.METADATA_ID AND apu.ID IN (
                SELECT MAX(apu2.ID)
                FROM api_ftp_upload apu2
                WHERE apu2.METADATA_ID = apu.METADATA_ID AND apu2.ROUND = apu.ROUND AND apu2.PROCESS_TYPE = 2
                ORDER BY apu2.ID DESC 
                )
                JOIN
                api_client_acknowledgement aca ON aca.METADATA_ID = tlmd.METADATA_ID AND aca.ID IN ( 
                        SELECT MAX(aca2.ID)
                        FROM api_client_acknowledgement aca2 
                        WHERE aca2.METADATA_ID = aca.METADATA_ID AND aca2.ROUND = aca.ROUND 
                        ORDER BY aca2.ID DESC 
                )
                LEFT JOIN  job jb on jb.JOB_ID = tlmd.JOB_ID 
                LEFT JOIN round_enum re ON re.ID = aca.ROUND 
                WHERE aca.`STATUS` = '$status' AND aca.ROUND = 118 AND apu.status = 2 AND aca.PROCESS_TYPE_DIFF = 5 AND aca.FILE_NAME_IN_LOG LIKE '%eProof_Contri%' 
                GROUP BY aca.METADATA_ID,aca.ROUND";

                break;
        
		case 37 : 
                
                $status     =  ( $status == 3 ) ? '3,0' : $status;
                
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_pdfcompare aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_pdfcompare aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` IN ( '$status' ) and aep.ROUND in ( 119  ,120 )
                    GROUP BY aep.METADATA_ID,aep.ROUND";
                break;
	
        
            
			case 40 :                 
                $query_stmt =    "SELECT jb.BOOK_ID,jb.JOB_ID,re.NAME as ROUND_NAME, re.ID as ROUND_ID, tlmd.METADATA_ID ,  tlmd.CHAPTER_NO , tlmd.CHAPTER_NAME as CHAPTER_TITLE, 
                    aep.`STATUS` , aep.START_TIME , aep.END_TIME , aep.REMARKS 
                    from task_level_metadata tlmd join 
                              api_pdfmerge aep ON aep.METADATA_ID = tlmd.METADATA_ID AND aep.ID IN ( 
                    SELECT MAX(aep2.ID)
                    FROM api_pdfmerge aep2
                    WHERE aep2.METADATA_ID = aep.METADATA_ID AND aep2.ROUND = aep.ROUND
                    ORDER BY aep2.ID DESC )
                    left join  job jb on jb.JOB_ID = tlmd.JOB_ID 
                    left join round_enum re on re.ID = aep.ROUND 
                    WHERE aep.`STATUS` = '$status' and aep.ROUND in ( 119 )
                    GROUP BY aep.METADATA_ID,aep.ROUND";
					
                break;
           
            default:
            //sharing about spice
                
            $query_stmt         =       "SELECT j.JOB_ID,j.BOOK_ID,tlmd.METADATA_ID, aas.ROUND AS ROUND_ID,CASE aas.ROUND WHEN 116 THEN 'S200' ELSE 'S200' END AS ROUND_NAME,
            j.JOB_TITLE,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
            aas.STATUS,aas.START_TIME,aas.REMARKS,aas.END_TIME,js.JOB_STAGE_ID FROM task_level_metadata tlmd 
            INNER JOIN job j ON j.JOB_ID = tlmd.JOB_ID
            INNER JOIN api_auto_stage aas on aas.METADATA_ID = tlmd.METADATA_ID 
            INNER JOIN job_round jr ON jr.METADATA_ID = aas.METADATA_ID AND jr.ROUND_ID = aas.ROUND
            INNER JOIN job_stage js ON js.JOB_ROUND_ID = jr.JOB_ROUND_ID AND js.ITERATION_ID = jr.CURRENT_ITERATION_ID AND js.STAGE_ID = aas.STAGE
				and aas.ID IN ( select max( ame2.ID ) from api_auto_stage ame2 where ame2.METADATA_ID = aas.METADATA_ID order by ame2.ID desc )
            WHERE tlmd.is_active = 1 GROUP BY tlmd.METADATA_ID";
                
            break;    
        }
		
        $jobDetails     =   DB::select( $query_stmt );  
		
        return $jobDetails;   
    }
    
    public static function getallcuclist($jobID     =   null)
    {
        $cucinfo        =   [];
        try
        {
            $cucinfo    =   DB::table('task_level_metadata')->select(DB::raw('task_level_metadata.METADATA_ID taskmetaid,task_level_metadata.PII,task_level_metadata.CHAPTER_NAME,task_level_metadata.CHAPTER_NO,task_level_metadata.CHAPTER_SEQ,job.JOB_ID as jobid,job.BOOK_ID,job.JOB_TITLE,jobtimetable.*,round_enum.NAME as roundname,stage.STAGE_ID,stage.STAGE_NAME'))
                                                            ->join('job','job.JOB_ID','=','task_level_metadata.JOB_ID')
                                                            ->leftJoin(DB::raw('(select max(job_time_sheet_id) as jobtimesheetid, count(job_time_sheet_id) as totalcount, jt.JOB_ID, jt.METADATA_ID, jt.ROUND_ID, jt.STAGE, max(check_out) as CHECK_OUT, max(check_in) as CHECK_IN,max(CREATED_BY) as CREATED_BY,max(STATUS) as STATUS from job_time_sheet jt 
                                                                where jt.STAGE = '.\Config::get('constants.STAGE_COLLEECTION.CUC').' and jt.ROUND_ID = '.\Config::get('constants.ROUND_ID.CUC').' group by jt.JOB_ID,jt.METADATA_ID ) jobtimetable'), 
                                                             function($join)
                                                                {
                                                                     $join->on('task_level_metadata.JOB_ID', '=', 'jobtimetable.JOB_ID');
                                                                     $join->on('jobtimetable.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                 })
                                                            ->leftjoin('round_enum','round_enum.ID','=','jobtimetable.ROUND_ID')
                                                            ->leftjoin('stage','stage.STAGE_ID','=','jobtimetable.STAGE')
                                                            ->where('task_level_metadata.IS_ACTIVE',true)
                                                            ->where('job.JOB_ID',$jobID)
                                                            ->groupBy('task_level_metadata.CHAPTER_NO')
                                                            ->groupBy('job.BOOK_ID')
                                                            ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
}

