<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Models\jobInfoModel;
use Carbon\Carbon;
use Session;

class apiSpicastModel extends Model 
{
    protected $table        =   'api_spicast';
    public  $primaryKey     =   'JOB_ID';
    
    public static function getSpicastdetails(){    
        $spicastinfo        =   false;   
        try
        {
    
			$spicastinfo    =   jobModel::select(DB::raw('job.JOB_ID,job.BOOK_ID,job.JOB_TITLE,job_info.JOB_ID as jobid,job_info.AUTHOR_EMAIL,job_info.ISSN_ONLINE,job.CREATED_DATE'))
				->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                        		->where('job_info.SPICAST_STATUS','!=','1')
                                        ->orwhere('job_info.SPICAST_STATUS','=',null)
                                        ->get();        
            
        }catch( \Exception $e ){           
            
            return $spicastinfo;
            
        }
        
        return $spicastinfo;
    }
    
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $randomtoken  =   "";
            do
            {
                $randomtoken 	=   str_random(10);
                $tokenexist 	=   apiSpicastModel::where('TOKEN',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $data['TOKEN']  =   $randomtoken;
            $spicastadd     =   apiSpicastModel::insertGetId($data);
            
            if($spicastadd)
            {
                $jobdata    =   [];
                $jobdata['SPICAST_STATUS']  =   1;
                $jobdata['LAST_MOD_BY']     =   Session::get('users')['user_id'];
                $jobdata['LAST_MOD_DATE']   =   Carbon::now();;
                $updatejob  =   jobInfoModel::updateJobdata($data['JOB_ID'],$jobdata);
            }
            if($spicastadd >=1)
            {
                $spicastadd  =   apiSpicastModel::where('ID',$spicastadd)->first();
            }
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
    
     //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	apiSpicastModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
}

