<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiCeestimationModel extends Model 
{    
    protected $table 	= 	'api_ce_estimation';
    public $timestamps 	= 	true;
    protected $dateFormat 	= 	'Y-m-d H:i:s';
    const UPDATED_AT    =   "UPDATED_AT";
    public static function checkexistjob($jobId 	=	null)
    {
            return DB::table('job')->where('IS_ACTIVE',true)->where('JOB_ID',$jobId)->first();
    }
	
    public static function doAdd($cedata    =	[])
    {
        $querydata  =	[];
        try
        {
            $randomtoken  		=   "";
            do
            {
                    $randomtoken 	=   str_random(10);
                    $tokenexist 	=   apiCeestimationModel::where('TOKEN',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $cedata['TOKEN']            =   $randomtoken;
            $getid                      =   apiCeestimationModel::insertGetId($cedata);
            if($getid >=1)
            {
                    $querydata 		=   apiCeestimationModel::where('ID',$getid)->first();
            }
        }
        catch( \Exception $e )
        {           
        return false;
        }
        return $querydata;
    }
    //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	apiCeestimationModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    //get meta id 
    public static function checkexistMetaId($jobId 	=	null,$chapter = null)
    {
        return DB::table('task_level_metadata')->where('IS_ACTIVE',true)->where('JOB_ID',$jobId)->where('CHAPTER_NO',$chapter)->first();
    }
	//check book id exist
    public static function checkBookidexist($bookid = null)
    {
	$getJob     =	false;
        try
        {
            $getJob     =   DB::table('job')->where('BOOK_ID',$bookid)->where('IS_ACTIVE',true)->first();
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $getJob;
    }
	// check id exist
    public static function checkMetaidexist($metaid = null)
    {
        $getJob     =	[];
        try
        {
           $getJob  =   DB::table('metadata_info')->where('METADATA_ID',$metaid)->first();
        }
        catch( \Exception $e )
        {           
            return false;
        }
	return $getJob;
    }
	
    public static function updatemetainfo($metadata = [],$metaid = null)
    {
	$update     =	false;
        try
        {
            $update =	DB::table('metadata_info')->where('METADATA_ID',$metaid)->update($metadata);
	}
	catch( \Exception $e )
	{           
            return false;
        }
	return $update;
    }
}
