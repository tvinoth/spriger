<?php 
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Models\chapterPartMapModel;
use App\Models\metaDataStatus;
use App\Models\taskLevelArtMetadataModel;
use DB;
use Carbon\Carbon;
use Session;

class taskLevelArtMetadataModel extends Model 
{    
    protected $table    =   'task_level_art_metadata';
    
      
    public static function insertNew( $inp_arr ){
    
        $ins_obj        =       new taskLevelArtMetadataModel();
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        $table_name         =       $this->table;
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
    }
    
    public static function doAddTaskLevelArtmetadata($chapter = [],$partnames = [],$jobID = null,$bookid = null)
    {
        $result         =	[];
        $chapterexist   =	[];
        $addresult      =	false;
        try
        {
            if(count($chapter)>=1)
            {
                $taskmetadata                       =	array();
                $inpArr                             =   array();
                foreach($chapter as $key=>$val)
                {
                    $taskmetadata['CHAPTER_NO']     =   ucfirst($val);
                    $taskmetadata['UNIT_OF_MEASURE']=   \Config::get('constants.CHAPTER_ENUM_ID');//chapter unit_enum id
                    $taskmetadata['JOB_ID']         =   $jobID;
                    $taskmetadata['IS_ACTIVE']      =   true;
                    $taskmetadata['CREATED_DATE']   =   Carbon::now();
                    $taskmetadata['CREATED_BY']     =   Session::get('users')['user_id'];
                    //check exist chapter
                    $checkexistchapter              =   taskLevelMetadataModel::where('JOB_ID',$jobID)->where('CHAPTER_NO',ucfirst($val))->where('IS_ACTIVE',true)->first();
                    if(count($checkexistchapter)>=1)
                    {		
                        $chapterexist[]             =   ucfirst($val)." is already exist with Book Id ".$bookid;		
                    }
                    else
                    {
                        $addresult                  =   DB::table('task_level_metadata')->insertGetId($taskmetadata);
                        if($addresult >=	1)
                        {
                            $insertrec              =   array('METADATA_ID'=>$addresult,
                                                                'LAST_MOD_DATE'=>Carbon::now(),
                                                                'LAST_MOD_BY'=>\Session::get('users')['user_id']
                                                            );
                            //insert meta info details
                            DB::table('metadata_info')->insert($insertrec);
                            //chapter part map insert
                            $inpArr['JOB_ID']       = 	$jobID;
                            $inpArr['METADATA_ID']  = 	$addresult;
                            $inpArr['CHAPTER_NAME'] = 	ucfirst($val);
                            $inpArr['PART_NAME']    = 	ucfirst($partnames[$key]);
                            $inpArr['CREATED_BY']   = 	\Session::get('users')['user_id'];
                            $checkexistchapterpart  =   chapterPartMapModel::where('JOB_ID',$jobID)->where('CHAPTER_NAME',ucfirst($val))->where('STATUS',true)->first();
                            if(count($checkexistchapterpart)<=0)
                            {
                                DB::table('chapter_part_map')->insert($inpArr);
                            }
                        }
                    }
                    unset($inpArr);
                    unset($taskmetadata);
                }
            }
        }
        catch( \Exception $e )
        {           
            return false;
        }
        $result['result']	 =	$addresult;
        $result['chapter']	 =	$chapterexist;
        return $result;
    }
    
    //check exist job id
    public static function checkexistjob($jobId 	=	null)
    {
        return DB::table('job')->where('IS_ACTIVE',true)->where('JOB_ID',$jobId)->first();
    }
    
    
    public static function getArtChapterwisefigureInfo($metaID    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_art_metadata')->select(DB::raw('task_level_art_metadata.METADATA_ID,task_level_art_metadata.ART_METADATA_ID,task_level_art_metadata.FILE_NAME,task_level_art_metadata.INPUT_FILE,task_level_art_metadata.FIGURE_TYPE,complexity_enum.NAME AS COMPLEXITY,task_level_art_metadata.INPUT_MODE,task_level_art_metadata.FIGURE_FULL_MODE,task_level_art_metadata.WORK_INVOLVED,task_level_art_metadata.INPUTCOLOR,task_level_art_metadata.OUTPUTCOLOR,task_level_art_metadata.REMARKS'))
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','task_level_art_metadata.COMPLEXITY')
                                    ->where('task_level_art_metadata.METADATA_ID',$metaID)
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public static function getArtpdfcreationfigureInfo($metaID    =   null)
    {    
        $cucinfo        =   [];
        try
        { 
            $cucinfo    =   DB::table('task_level_art_metadata')->select(DB::raw('task_level_art_metadata.METADATA_ID,task_level_art_metadata.FILE_NAME,task_level_art_metadata.INPUT_FILE,task_level_art_metadata.FIGURE_TYPE,complexity_enum.NAME AS COMPLEXITY,task_level_art_metadata.INPUT_MODE,task_level_art_metadata.WORK_INVOLVED,task_level_art_metadata.INPUTCOLOR,task_level_art_metadata.OUTPUTCOLOR,task_level_art_metadata.REMARKS'))
                                    ->leftjoin('complexity_enum','complexity_enum.ID','=','task_level_art_metadata.COMPLEXITY')
                                    ->wherein('task_level_art_metadata.ART_METADATA_ID',$metaID)
                                    ->get();      
            return $cucinfo;
        }
        catch( \Exception $e )
        {           
            return $cucinfo;
        }
        return $cucinfo;
    }
    
    public function getRecordByCustomCondition( $condition_array =   array() ){
        
        $table_name     =       $this->table;
        
        return DB::table( $table_name )
                ->select()
                ->where( $condition_array )
                ->get()
                ->first();
        
    }
    
    public function isAllartStagesCompleted( $metaid , $round ){
        
        $query_string        =       'select * from task_level_art_metadata tlamd left join job_round jr on tlamd.METADATA_ID = jr.METADATA_ID '
               . 'and jr.IS_ART = 1 left join job_stage js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and jr.CURRENT_ITERATION_ID = js.ITERATION_ID '
               . 'where js.`STATUS` != 24 and tlamd.METADATA_ID = '.$metaid.' and jr.ROUND_ID = '.$round;
               
        return DB::select( $query_string );
        
    }
    
    public function isAllartStagesCompletedWithMetastatusTable( $metaid , $round , $withJobstgeAvailInfo = true ){

        //getMetastatus id      =   
        $query_string       =       '';
        
        $mds_obj                =       new metaDataStatus();
        
        $mds_rec               =        $mds_obj::select()->where( 'METADATA_ID' , $metaid  )
                                        ->where('CURRENT_ROUND' , $round)
                                        ->where('IS_ART' , 1 )
                                        ->whereNotIn( 'CURRENT_STATUS' , ['47'] )
                                        ->get()->first();
        
       
        if( count( $mds_rec ) > 0 && $withJobstgeAvailInfo ){
            
            $mds_id     =   $mds_rec->ID;
            $jbstg_info         =       DB::table('task_level_art_metadata as tlam')->select('js.*')
                                            ->leftjoin( 'job_round as jr' , 'tlam.METADATA_STATUS_ID' , '=' , 'jr.METADATA_STATUS_ID' )
                                            ->leftjoin( 'job_stage as js' , 'js.JOB_ROUND_ID' , '='  ,'jr.JOB_ROUND_ID' )
                                            ->where( 'js.STATUS' , '=' , 27 )
                                            ->where( 'tlam.METADATA_STATUS_ID' , '=' , $mds_id )
                                            ->get()
                                            ->first();
            
            return $jbstg_info;
                                            
            
        }
        
        if( count( $mds_rec ) > 0 ){
            return $mds_rec;
        }             
        
        return array();
        
    }
    
    
    
}

