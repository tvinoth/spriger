<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class newComponent extends Model {
    
    protected   $table      =   'books_component_creation';
    public      $timestamps =   true;
    protected   $dateFormat =   'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new newComponent();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $table_name         =       'books_component_creation';
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
        
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      $inpArr;
        	
        $updateQry  =   DB::table('books_component_creation')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public function getRecordsByJobId( $jobid ){
        
                
            $query_stmt =   'select bcc.ID, bcc.JOB_ID , bcc.ROUND_ID , bcc.NAMING_CONVENTION , bcc.COMPONENT_TYPE , bcc.WORKFLOW_ID , '
               . ' bcc.status+0 AS STATUS , bcc.DESCRIPTION , re.NAME AS ROUND_NAME , wflw.WORKFLOW_NAME , cc.NAME as COMPONENT_NAME , '
               . ' bcc.CREATED_AT from books_component_creation bcc '
               . ' left join round_enum re on re.id = bcc.round_id '
               . ' left join workflow wflw on wflw.WORKFLOW_ID = bcc.WORKFLOW_ID '
               . ' left join component_category cc on cc.id = bcc.COMPONENT_TYPE '
               . ' where bcc.job_id = '.$jobid.' and bcc.status in ( 1,2 )';

        return DB::select( $query_stmt );
        
    }
    
    public function getRoundBasedComponetInformation( $round ){
    
        $query_smt      =   'SELECT NAMING_CONVENTION , COMPONENT_TYPE FROM books_component_creation WHERE ROUND_ID = '.$round.' AND STATUS = 1';
        return DB::select( $query_smt );
                
    }
    
    
    
}
