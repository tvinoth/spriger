<?php 


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Session;
use Config;

class locationModel extends Model {
    
    protected $table    =   'am_location_mapping';
    public $primaryKey  =   'ID';
    public $timestamps  =   true;
    protected $fillable =   array('CREATED_DATE');

    
    //sample input array
    // 0 => id
    // 1 => limit start
    // 2 => limit  
    // 3 => order by
    
    public static function getLocationList( $input = array() ){          
        
        $tbl              =     'am_location_mapping';
        $contact_info     =     DB::table( $tbl )
                                            ->select() 
                                            ->where('STATUS', '=', 'ACTIVE') 
                                            ->get();
        
        return $contact_info;
        
    }
    
    public static function getLocationListWithFilter( $selectFilter   =   '' ){          
        
        $tbl              =     'am_location_mapping';
        $location_info     =     DB::table( $tbl )
                                            ->select( $selectFilter  ) 
                                            ->where( 'STATUS', '=', 'ACTIVE' ) 
                                            ->get();
        
        
        return $location_info;
        
    }
    
    public static function getListWithAmDetails( ){
        
        $contact_info   =       array();
        $tblname        =       'am_location_mapping as aml';
        
        try{
            
            $select_field   =       array( 'aml.ID' , 'aml.LOCATION_NAME' , 'aml.PRODUCTION_AREA' , DB::RAW( 'aml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 'aml.ACCOUNT_MANAGER_ID' , 'aml.STATUS' ,  DB::RAW( 'UPPER(usr.FIRST_NAME) as MANAGER_NAME' ));
            
            $contact_info   =       DB::table( $tblname )
                                    ->leftJoin( 'user as usr' , 'aml.ACCOUNT_MANAGER_ID', '=', 'usr.USER_ID')           
                                    ->select( $select_field )
                                    ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;     
        
    }
    
    
    public static function getListWithPmDetails( ){
        
        $contact_info       =   array();
        try{
            DB::enableQueryLog();
            $select_field   =   array( 'aml.ID' , 'aml.PRODUCTION_AREA' ,'pal.LOCATION_NAME', DB::RAW( 'aml.PRODUCTION_AREA+0 as PRODUCTION_AREA_ID'   )  , 'aml.PROJECT_MANAGER_ID' , 'aml.STATUS' , 'usr.FIRST_NAME as MANAGER_NAME');
            
            $contact_info   =   DB::table( 'pm_location_mapping as aml' )
                                    ->leftJoin( 'production_area_location as pal' , 'pal.ID', '=', 'aml.PRODUCTION_AREA')           
                                    ->leftJoin( 'user as usr' , 'aml.PROJECT_MANAGER_ID', '=', 'usr.USER_ID')           
                                    ->leftJoin( 'user_team_map as utm' , 'utm.USER_ID', '=', 'usr.USER_ID')           
                                    ->select( $select_field )
                                    ->where('utm.TEAM_ID',Session::get('users')['team_id'])
                                    ->where('usr.ROLE', Config::get('constants.CONSOLIDATE_MANAGER_ROLE_ID')[0])
                                    ->where('utm.USER_ID','<>',Session::get('users')['user_id'])
                                    ->get();           
            $a=  DB::getQueryLog($contact_info);
        }catch( \Exception $e ){           
            return false;
        }
        
        return $contact_info;        
        
    }
    
    public function insert( $input =  array() ){
        
    }
    
    public static function deleteAmLocation( $rowid  =   null ,$statusid    =   null){
        
        $response   =   false;
        $tbl      =   'am_location_mapping';
        
        if( !is_null( $rowid ) ){
            
            $response       =       DB::table( $tbl )->where( 'ID' , '=' ,  $rowid )->update(['STATUS'=>$statusid]);
           
        }
        
        return $response;
        
    }
    
    public static function getProductionAreaList(){
        
       $query_stmt     =       '';
       $result     =       DB::table( 'production_area_location' )->select('LOCATION_NAME')->get()->toArray();
       $response    =   array();
       foreach( $result as $key => $value ){
           $response[]  =   $value->LOCATION_NAME;
       }
       return $response;
       
    }
    
    public static function getAllProductionAreaList(){
        
       $result     =       DB::table( 'production_area_location' )->get();
       return $result;
       
    }
    
    public static function updateLocation( $inpArr ){
        
        $setArr     =   array( 
                               'LOCATION_NAME'   => strtoupper( $inpArr['LOCATION_NAME'] )   , 
//                               'PRODUCTION_AREA'  =>  $inpArr['PRODUCTION_AREA'] ,
                               'ACCOUNT_MANAGER_ID'    =>  $inpArr['ACCOUNT_MANAGER_ID'] ,
                               'LAST_MOD_DATE'  =>  'NOW()' , 
                               'LAST_MOD_BY'    =>  $inpArr['user_id']
                        );
        
        
        $updateQry  =   DB::table('am_location_mapping')
			->where('ID', $inpArr['ID'])
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getPmLocationInfo( $userid = null ){
                
        $tbl             =      'pm_location_mapping';        
        $query_smt       =      'select * from '.$tbl;
        $query_smt      .=      ' plm left join production_area_location pal on pal.ID = plm.PRODUCTION_AREA ';
        $query_smt      .=      ' where plm.STATUS = 1 AND plm.PROJECT_MANAGER_ID = '.$userid;       
       
        $get_info       =       DB::select( $query_smt );
        
        return $get_info; 
        
    }
    
}

