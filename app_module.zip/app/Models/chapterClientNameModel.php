<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;

class chapterClientNameModel extends Model 
{
    protected $table        =   'chapter_client_name';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_DATE";
    const CREATED_AT        =   "CREATED_DATE";
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
    
    public function scopeMagnusactive($query)
    {
        return $query->where('IS_ACTIVE', 1)->where('TYPE',1);
    }
    
    public function scopeOstactive($query)
    {
        return $query->where('IS_ACTIVE', 1)->where('TYPE',2);
    }
}

