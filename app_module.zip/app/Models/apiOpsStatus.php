<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use DB;

class apiOpsStatus extends Model 
{
    protected $table        =   'api_ops_status';
    public  $primaryKey     =   'ID';
    
    public function scopeActive($query){
        return $query->where('IS_ACTIVE',true);
    }
    
    public function getProoflinkRecords( $metaid = null , $volumeissue = null , $round = null ){
    
        $query_stmt     =   	DB::table('api_ops_status')
									->select()
									->where('round' , '=' ,  $round )
									->where('status' , '=' , 2 );

		if( !is_null( $metaid ) )
			$query_stmt->where( 'metadata_id' , '=' , $metaid );

		if( !is_null( $volumeissue ) )
			$query_stmt->where( 'metadata_id' , '=' , $volumeissue );

        $records_ret        =       $query_stmt->orderBy('ID' , 'DESC' )->get()
                                    ->first();
        
        return $records_ret;
        
    }
    
}

