<?php
namespace App\Models;
use App\Models\apiCorrectionDownload;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiCorrectionDownload extends Model {
    
    protected   $table      =   'api_correction_download';
    public      $timestamps =   true;
    protected   $dateFormat =   'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiCorrectionDownload();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        $table_name         =       'api_correction_download';
        $insert_r           =       DB::table( $table_name )->insertGetId( $inp_arr );
        
        if( $insert_r )
            return $insert_r;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
       
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                           );
        
        $updateQry  =   DB::table('api_dataset')
			->where('ID', $rowid )
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByArtMetaid( $artMetaid , $round ){
        
        $getRec       =         DB::table('api_correction_download as ds')
                                    ->where('ART_METADATA_ID', '=', $artMetaid )
                                    ->where('ROUND', '=', $round )                                            
                                    ->orderBy('ds.ID', 'desc')
                                    ->get()->first();
      
        return $getRec;
      
    }
    
    public static function getApiRequestByTokenKey( $tokenKey ){
        
        $getRec       =         DB::table('api_correction_download as ds')
                                    ->where('TOKEN_KEY', '=', $tokenKey )
                                    ->where('STATUS', '=', '1.5' )
                                    ->get()->first();
      
        return $getRec;
      
    }
    
    
}
