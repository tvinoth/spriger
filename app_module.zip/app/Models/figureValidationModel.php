<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class figureValidationModel extends Model 
{
    protected $table        =   'api_figurevalidation';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_DATE";
        
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $randomtoken  =   "";
            do
            {
                $randomtoken 	=   str_random(10);
                $tokenexist 	=   figureValidationModel::where('TOKEN',$randomtoken)->first();
            }
            while(!empty($tokenexist));
            $data['TOKEN']  =   $randomtoken;
            $spicastadd     =   figureValidationModel::insertGetId($data);
            if($spicastadd >=1)
            {
                $spicastadd  =   figureValidationModel::where('ID',$spicastadd)->first();
            }
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
    
     //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	figureValidationModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
}

