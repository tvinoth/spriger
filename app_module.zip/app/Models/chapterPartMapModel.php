<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class chapterPartMapModel extends Model {

    // 
    protected $table 	=   'part_mapping';    
    const   CREATED_AT  =   "CREATED_AT";
    const   UPDATED_AT  =   "UPDATED_AT";
    public static function saveChapterPartitems($jobID,$getinputchapters =	[],$getinputparts = []) 
    {
        $updatecheckitems   =   false;
        if(count($getinputchapters)>=1)
        {
            $inpArr 	=	array();
            foreach($getinputchapters as $key=>$val)
            {
                $inpArr['PARTMETADATA_ID'] = 	$val;
                $inpArr['PART_NAME']    = 	$getinputparts[$key];
                $inpArr['CREATED_BY']   = 	\Session::get('users')['user_id'];
                $updatecheckitems       =	chapterPartMapModel::insert($inpArr);
                unset($inpArr);
            }
            return $updatecheckitems;
        }
        return $updatecheckitems;
    }
}
