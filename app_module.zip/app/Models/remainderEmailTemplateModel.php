<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class remainderEmailTemplateModel extends Model 
{
    protected $table        =   'remainder_email_template';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_AT";
    const UPDATED_AT        =   "UPDATED_AT";
     //update tool response
}

