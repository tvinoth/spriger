<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use DB;

class apsProofingStatusModel extends Model 
{
    protected $table        =   'aps_proofing_status';
    public  $primaryKey     =   'ID';
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE',true);
    }
    
    public static function getapsremaindermaillist()
    {    
        $bookinfo       =   array();   
        try{
            $bookinfo   =   "SELECT acd.ID AS CRCRECIVEDORNOT,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                         IF( DATE(asps.FIRST_CORRECTION_DUE) =  CURDATE(), 1 , 0 ) as REM1  ,
                        IF( date(asps.SECOND_CORRECTION_DUE) = CURDATE(),  1 , 0 ) as REM2  ,
                        IF( date(asps.THIRD_CORRECTION_DUE) = CURDATE(), 1 , 0 ) as REM3  ,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,asps.PROOF_LETTER_TYPE_ID,
                        asps.PROOFING_URL,asps.NAME,tlm.CHAPTER_NO,asps.NAME,asps.ROUND,asps.SUBJECT,asps.FROM_NAME,asps.TO_EMAIL,asps.CC_EMAIL,asps.SUBJECT_LINE,asps.MAIL_ATTACHMENT_URL,asps.EMAIL_CONTENT,asps.CORRECTION_DUE,asps.START_TIME,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,asps.ID as APS_ID,apsemaillog.FIRST_REMAINDER,apsemaillog.SECOND_REMAINDER,apsemaillog.THIRD_REMAINDER,apsemaillog.ID as APSEMAILLOG_ID
                        FROM `task_level_metadata` tlm
                        
                        join remainder_email_onoff remonoff on remonoff.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = ".Config::get('constants.ROUND_ID.S300')." AND remonoff.REMAINDER_TYPE = ".Config::get('constants.REMAINDER_TYPE.APS')."
                        AND remonoff.IS_ACTIVE  =   '".Config::get('constants.STATUS_ENUM.ONE')."' AND remonoff.ID = (select MAX(ID) as rid from remainder_email_onoff remonoff1 where remonoff.METADATA_ID = remonoff1.METADATA_ID AND remonoff1.IS_ACTIVE = '".Config::get('constants.STATUS_ENUM.ONE')."'
                            group by remonoff1.METADATA_ID)
                                                    
                        join aps_proofing_status asps on asps.METADATA_ID = tlm.METADATA_ID AND asps.ROUND = ".Config::get('constants.ROUND_ID.S300')." AND asps.STATUS = '".Config::get('constants.STATUS_ENUM.SUCCESS')."'  
                        INNER JOIN (select MAX(ID) as idm, METADATA_ID,ROUND,IS_ACTIVE from aps_proofing_status  group by aps_proofing_status.METADATA_ID)  AS aps ON aps.METADATA_ID = asps.METADATA_ID
                        AND aps.idm = asps.ID AND aps.ROUND     =   asps.ROUND AND aps.IS_ACTIVE = '".Config::get('constants.STATUS_ENUM.ONE')."'

                        LEFT JOIN api_correction_download acd ON acd.METADATA_ID = tlm.METADATA_ID AND acd.ROUND = ".Config::get('constants.ROUND_ID.S300')." AND acd.ID = 
                        (SELECT MAX(id) AS erlid FROM api_correction_download acd2 WHERE acd2.METADATA_ID = acd.METADATA_ID AND acd2.ROUND = acd.ROUND GROUP BY acd2.METADATA_ID)

                        left join email_remainder_log apsemaillog on apsemaillog.METADATA_ID = tlm.METADATA_ID AND apsemaillog.JOB_ID = tlm.JOB_ID AND apsemaillog.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.APS')." AND  apsemaillog.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog where emaillog.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.APS')." AND apsemaillog.METADATA_ID = emaillog.METADATA_ID group by emaillog.METADATA_ID)  
                            
                        WHERE `tlm`.`IS_ACTIVE` = 1 AND `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')." AND
                        (
                        IF( date(asps.FIRST_CORRECTION_DUE) = CURDATE() , 1 , 0 ) = 1
                        or IF(date(asps.SECOND_CORRECTION_DUE) = CURDATE() , 1 , 0 ) = 1
                        or IF( date(asps.THIRD_CORRECTION_DUE)  = CURDATE() , 1 , 0 ) = 1
                        )
                        GROUP BY asps.METADATA_ID ORDER BY asps.ID DESC";
            
            $bookinfo   =   DB::select($bookinfo);
        }catch( \Exception $e ){           
            return false;
        }
	return $bookinfo;   
    }
    
    
    public static function getapsremaindermailsetupchapterlist($jobID,$roundid){    
	
        $bookinfo       =   array();   
		
        try{
			
            $bookinfo   =   "SELECT acd.ID as CRCID,tlm.METADATA_ID,remonoff.FIRST_REMAINDER_EMAIL_STATUS,remonoff.SECOND_REMAINDER_EMAIL_STATUS,remonoff.THIRD_REMAINDER_EMAIL_STATUS,
                        tlm.JOB_ID,tlm.PII,tlm.CHAPTER_NAME,tlm.EPROOFING_SYSTEM,
                        tlm.EPROOFING_RECIPIENT,tlm.ADDITIONAL_RECIPIENT,tlm.CHAPTER_NO,
                        tlm.CHAPTER_SEQ+0 AS CHAPTER_SEQ,erl.FIRST_REMAINDER,erl.SECOND_REMAINDER,erl.THIRD_REMAINDER,erl.BODY_OF_MAIL,asps.ID as APSID,asps.ROUND AS ROUND_ID,DATE_FORMAT(asps.CORRECTION_DUE, '%Y-%m-%d') as CORRECTION_DUE,DATE_FORMAT(asps.FIRST_CORRECTION_DUE, '%Y-%m-%d') as FIRST_CORRECTION_DUE,DATE_FORMAT(asps.SECOND_CORRECTION_DUE, '%Y-%m-%d') as SECOND_CORRECTION_DUE,DATE_FORMAT(asps.THIRD_CORRECTION_DUE, '%Y-%m-%d') as THIRD_CORRECTION_DUE,
                        remonoff.ID as REMAINDER_ID,erl.ID as EMAIL_ID  
                        FROM `task_level_metadata` tlm
                        
                        join metadata_info mi on mi.METADATA_ID = tlm.METADATA_ID
                        
                        join job jb on jb.JOB_ID = tlm.JOB_ID
                        
                        join job_info jbinfo on jbinfo.JOB_ID = jb.JOB_ID
                        
                        left join email_remainder_log erl on erl.METADATA_ID = tlm.METADATA_ID AND erl.JOB_ID = tlm.JOB_ID AND erl.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.APS')." AND  erl.ID = 
                        (select MAX(id) as erlid from email_remainder_log emaillog where emaillog.REMAINDER_TYPE   =   ".Config::get('constants.REMAINDER_TYPE.APS')." AND erl.METADATA_ID = emaillog.METADATA_ID group by emaillog.METADATA_ID)  
                            
                        join remainder_email_onoff remonoff on remonoff.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = tlm.JOB_ID AND remonoff.ROUND_ID = ".$roundid." AND remonoff.REMAINDER_TYPE = ".Config::get('constants.REMAINDER_TYPE.APS')."
                        AND remonoff.IS_ACTIVE  =   '".Config::get('constants.STATUS_ENUM.ONE')."' AND remonoff.ID = (select MAX(ID) as rid from remainder_email_onoff remonoff1 where remonoff.METADATA_ID = remonoff1.METADATA_ID AND remonoff1.IS_ACTIVE = '".Config::get('constants.STATUS_ENUM.ONE')."'
                            group by remonoff1.METADATA_ID)
                        
                        LEFT JOIN api_correction_download acd ON acd.METADATA_ID = tlm.METADATA_ID AND acd.ROUND = ".$roundid." AND acd.ID = (SELECT MAX(id) AS erlid FROM api_correction_download acd2 WHERE 
                        acd2.METADATA_ID = acd.METADATA_ID and acd2.ROUND = acd.ROUND GROUP BY acd2.METADATA_ID)

                        left join aps_proofing_status asps on asps.METADATA_ID = tlm.METADATA_ID AND remonoff.JOB_ID = asps.JOB_ID AND asps.ROUND = ".Config::get('constants.ROUND_ID.S300')." AND asps.STATUS = '".Config::get('constants.STATUS_ENUM.SUCCESS')."' AND 
                        asps.ID = (select MAX(ID) as idm from aps_proofing_status aps where aps.METADATA_ID  =  asps.METADATA_ID AND asps.ROUND = ".$roundid." AND aps.IS_ACTIVE = '".Config::get('constants.STATUS_ENUM.ONE')."' group by aps.METADATA_ID)  
                        
                        WHERE `tlm`.`IS_ACTIVE` = 1 and jbinfo.EPROOFING_SYSTEM = '".Config::get('constants.REMAINDER_TYPE.APS')."' AND `tlm`.`UNIT_OF_MEASURE` != ".Config::get('constants.UNIT_OF_MEASURE')." AND tlm.JOB_ID   =   ".$jobID." and mi.FM_ARTICLE_BM != '".Config::get('constants.FM_ARTICLE_BM')."'
                        GROUP BY tlm.METADATA_ID order by tlm.CHAPTER_SEQ desc";
            
            $bookinfo   =   DB::select( $bookinfo );
			
        }catch( \Exception $e ){
			
            return false;
			
        }
		
		return $bookinfo;  
	
    }
}

