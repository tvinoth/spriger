<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;
class parreportModel extends Model 
{    
    protected $table    =   'task_level_metadata';
    public static function getParreport($jobId = null)
    {
	$bookinfo 		=	array();
        try
	{
            $bookinfo   =   parreportModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
								->where('task_level_metadata.JOB_ID',$jobId)
								->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                ->get();  
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getConsolidatereport($jobId = null)
    {
	$bookinfo 		=	array();
        try
	{
            $bookinfo   =   parreportModel::select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.CHAPTER_SEQ+0 as CHAPTER_SEQ,task_level_metadata.*,metadata_info.*,tmd.METADATA_ID as part_Id,tmd.CHAPTER_NO as part_name,pm.CHAPTER_PART_ID,pm.CHAPTER_METADATA_ID,pm.PART_METADATA_ID,count(mesm.METADATA_ID) as TOTALESM'))
								->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                                                ->leftjoin('part_mapping as pm',function($join)
                                                                {
                                                                    $join->on('pm.CHAPTER_METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                    $join->on('task_level_metadata.JOB_ID', '=', 'pm.JOB_ID');
                                                                    $join->where('pm.STATUS',true);
                                                                })      
                                                                 ->leftjoin('metadata_esm as mesm',function($join)
                                                                {
                                                                    $join->on('mesm.METADATA_ID', '=', 'task_level_metadata.METADATA_ID');
                                                                    $join->on('mesm.JOB_ID', '=', 'task_level_metadata.JOB_ID');
                                                                    $join->where('mesm.IS_DELETED',false);
                                                                })
                                                                ->leftjoin( 'task_level_metadata as tmd' , 'tmd.METADATA_ID', '=', 'pm.PART_METADATA_ID')
								->where('task_level_metadata.JOB_ID',$jobId)
								->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->where('task_level_metadata.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->orderBy('CHAPTER_SEQ','asc')
                                                                ->groupBy('task_level_metadata.METADATA_ID')                    
                                                                ->get();            
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function updateParReportdetails($metadata,$taskdata,$metaid)
    {
	$updateparreport 			=	false;
        try
	{
            $updateparreport   		=   DB::table('metadata_info')->where('METADATA_ID',$metaid)->update($metadata);
            if($updateparreport)
            {
                    $updateparreport   	=   DB::table('task_level_metadata')->where('METADATA_ID',$metaid)->update($taskdata);
            }   
        }
	catch( \Exception $e )
	{           
            return false;
        }
	return $updateparreport;
    }
	
    public static function updateallParReportdetails($jobId,$metaids,$totalpage,$nooftables,$noofunnumberedtables,$noofequations,$noofunnumberedequations,$chaptername)
    {
	$updateparreport 			=	false;
        try
        {
            if(count($metaids)>=1)
            {
                $metadata 					=	array();
                foreach($metaids as $key=>$val)
                {
                    $metadata['NO_MSP'] 			= 	$totalpage[$key];
                    $metadata['NO_TABLES'] 			= 	$nooftables[$key];
                    $metadata['NO_TABLES_UNNUMBERED']           = 	$noofunnumberedtables[$key];
                    $metadata['NO_EQUATION'] 			= 	$noofequations[$key];
                    $metadata['NO_EQUATION_UNNUMBERED']         = 	$noofunnumberedequations[$key];
                    $metadata['LAST_MOD_DATE'] 			=	Carbon::now();
                    $metadata['LAST_MOD_BY'] 			=	Session::get('users')['user_id'];
                    $updateparreport                            =	DB::table('metadata_info')->where('METADATA_ID', $val)->update($metadata);
                    if($updateparreport >=	1)
                    {
                        $updatepar 				=	array('LAST_MOD_DATE'=>Carbon::now(),'LAST_MOD_BY'=>\Session::get('users')['user_id'],'CHAPTER_NAME'=>$chaptername[$key]);
                        DB::table('task_level_metadata')->where('METADATA_ID', $val)->update($updatepar);
                    }
                    unset($metadata);
                }
                $successfileresponse        =       app('App\Http\Controllers\Api\activeMqReportController')->Activemqrequesthandling($jobId,'116','update','chapter','');
            return $updateparreport;
            }
	}
	catch( \Exception $e )
	{           
            return false;
        }
        return $updateparreport;
    }
	
    public static function checkBookidexist($bookid = null)
    {
        $getJob     =	false;
        try
	{
                $getJob =   DB::table('job')->where('BOOK_ID',$bookid)->where('IS_ACTIVE',true)->first();
        }
        catch( \Exception $e )
        {           
            return false;
        }
	return $getJob;
    }
    
	/*public static function storeSplitprocess($chapter = [],$jobID = null,$bookid = null)
	{
		$result 			=	[];
		$chapterexist 		=	[];
		$addresult 			=	false;
        try
        {
                if(count($chapter)>=1)
                {
                        $taskmetadata 		=	array();
                        foreach($chapter as $key=>$val)
                        {
                                $taskmetadata['CHAPTER_NO'] 	=	$val['Name'];
                                $taskmetadata['UNIT_OF_MEASURE']=	70;//chapter unit_enum id
                                $taskmetadata['JOB_ID'] 		=	$jobID;
                                $taskmetadata['IS_ACTIVE'] 		=	true;
                                $taskmetadata['CREATED_DATE'] 	=	Carbon::now();
                                $taskmetadata['CREATED_BY'] 	=	Session::get('users')['user_id'];
                                //check exist chapter
                                $checkexistchapter 				=	DB::table('task_level_metadata')->where('JOB_ID',$jobID)
                                                                                                                                                                        ->where('CHAPTER_NO',$val['Name'])
                                                                                                                                                                        ->where('IS_ACTIVE',true)->first();
                                if(count($checkexistchapter)>=1)
                                {
                                        $chapterexist[] 	 		=	$val['Name']." is already exist with Book Id ".$bookid;		
                                }
                                else
                                {
                                        $addresult 					=	DB::table('task_level_metadata')->insertGetId($taskmetadata);
                                        if($addresult >=	1)
                                        {
                                                $insertrec 				=	array('METADATA_ID'=>$addresult,
                                                                                                                                'NO_CHARACTERS'=>$val['NoOfCharacters'],
                                                                                                                                'PAGE_COUNT_BY_CHARACTERS'=>$val['PageCount_ByCharacters'],
                                                                                                                                'NO_WORDS'=>$val['NoOfWords'],
                                                                                                                                'PAGE_COUNT_BY_WORDS'=>$val['PageCount_ByWords'],
                                                                                                                                'LAST_MOD_DATE'=>Carbon::now(),
                                                                                                                                'LAST_MOD_BY'=>\Session::get('users')['user_id']
                                                                                                                        );
                                                DB::table('metadata_info')->insert($insertrec);
                                        }
                                }
                                unset($taskmetadata);
                        }
                }
        }
        catch( \Exception $e )
        {           
    return false;
}
        $result['result']	 =	$addresult;
        $result['chapter']	 =	$chapterexist;
        return $result;
    }*/
	
	
    public static function checkexistjob($jobId 	=	null)
    {
            return DB::table('job')->where('IS_ACTIVE',true)->where('JOB_ID',$jobId)->first();
    }
}

