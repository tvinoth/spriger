<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class ApiModel extends Model {

      
    public static function getAmUserDetails( $mappingEmail ) {
        
        $UserDetails        =       DB::table('contact_details AS cd')
                                        ->join('am_location_mapping  as lm', 'lm.ID', '=', 'cd.LOCATION_ID')
                                        ->join('user  as u', 'u.USER_ID', '=', 'lm.ACCOUNT_MANAGER_ID')
                                        ->whereRaw('LOWER(cd.CONTACT_EMAIL) LIKE ? ', '%'.trim( strtolower( $mappingEmail ) ).'%')
                                        //->where('cd.CONTACT_EMAIL', 'like', strtolower( $mappingEmail ) )
                                        ->select(DB::raw('u.USER_ID,concat (u.FIRST_NAME," ", u.LAST_NAME) as amName, u.EMAIL as amEmail,lm.PRODUCTION_AREA+0 as PRODUCTION_AREA'))
                                        ->first();
        return $UserDetails;
        
    }
    
    public static function updateDownloadLog($bookId) {
		$updateQry = DB::table('api_download')
		->where('BOOK_ID', $bookId)
		->update(array('IS_COMPLETED' => '1'));
        return $updateQry;
	}
   
     public static function getBookID($bookId) {
        
        $fileUploadInfo = DB::table('api_file_upload')
               ->where('BOOK_ID',$bookId)
               ->orderBy('CREATED_DATE','DESC')
               ->select() 
               ->first();

        return $fileUploadInfo;
        
     }
       
    public static function getJobDetails($bookId) {
        
        $fileUploadInfo = DB::table('job')
               ->where('BOOK_ID',$bookId)
               ->select() 
               ->first();
 
        return $fileUploadInfo;
        
    }
    
    public static function getJobDetailsWithInfo($bookId) {
        
        $fileUploadInfo = DB::table('job AS j')
                ->join('job_info  as ji', 'ji.job_id', '=', 'j.job_id')
               ->where('j.BOOK_ID',$bookId)
               ->select() 
               ->first();
 
        return $fileUploadInfo;
        
    }
     
   /*public static function insertFileUPloadDetails($bookId) {
		$updateQry = DB::table('api_file_upload')
		->where('BOOK_ID', $bookId)
		->update(array('IS_COMPLETED' => '1'));
        return $updateQry;
	}*/
   
    public static function updateFileUPloadDetails($bookId, $updateInfo) {
		$updateQry = DB::table('api_file_upload')
		->where('BOOK_ID', $bookId)
		->update($updateInfo);
        return $updateQry;
	}

}
