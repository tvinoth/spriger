<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class errorTypeEnum extends Model {
    
    protected   $table       =      'error_type_enum';
    public      $primaryKey  =      'ERROR_TYPE_ENUM_ID';
    public      $timestamps  =      false;
    
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new errorTypeEnum();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    
    public function insertRecordGetId( $inp_arr = array() ){
        $table      =   $this->table;
        if( !empty( $inp_arr ) ){
            return DB::table($table)->insertGetId( $inp_arr );
        }
        
        return false;
    }
    
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $table      =   $this->table;
        
        $updateQry  =   DB::table( $table )
                            ->where('JOB_ROUND_ID', $rowid )
                            ->update( $setArr );
        
        
        return $updateQry;
        
    }
    
    public function getErrorRecordBysubCircleId( $subcircleid = null){
       
        $table      =   $this->table;
        $res        =   false; 
        
        if( !is_null( $subcircleid )  ){
            
            //DB::enableQueryLog();
            
            $query      =   DB::table( $table );
            $wherearray     =       array( 'SUB_CIRCLE_ID' => $subcircleid );
            $query->where( $wherearray );
            
            $res   = $query->orderBy('ORDER_SEQ' ,'ASC')->get();        
            
            //$pr  = DB::getQueryLog();
            //dd( $pr );
            
        }
      
        return $res;
    }
    
}

