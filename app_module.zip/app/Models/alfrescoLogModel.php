<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;

class alfrescoLogModel extends Model 
{
    protected $table        =   'alfresco_log';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "UPDATED_DATE";
     //update tool response
    public static function doupdate($token = null,$cedata 	=	[])
    {
        $update     =	false;
        try
        {
            $update =	alfrescoLogModel::where('TOKEN',$token)->update($cedata);
        }
        catch( \Exception $e )
        {           
            return $data;
        }
        return $update;
    }
    
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
    
    public static function retrievestageData($wheredata){
        $data       =	[];
        try
        {
            $data   =   alfrescoLogModel::from('alfresco_log as al')->select(DB::Raw('ID,stage.STAGE_ID,stage.STAGE_NAME'))
                    ->join('stage','stage.STAGE_ID','=','al.STAGE_ID')
                    ->where($wheredata)
                    ->groupBy('al.STAGE_ID')->get();
        }
        catch( \Exception $e )
        {           
            return $data;
        }
        return $data;
    }
    
    public static function retrieveJobData($wheredata){
        $data       =	[];
        try
        {
            $data   =   alfrescoLogModel::from('alfresco_log as al')->select(DB::Raw('job.JOB_ID,job.BOOK_ID'))
                    ->join('job','job.JOB_ID','=','al.JOB_ID')
                    ->where($wheredata)
                    ->groupBy('al.JOB_ID')->get();
        }
        catch( \Exception $e )
        {           
            return $data;
        }
        return $data;
    }
    
    public static function retrieveChapterData($jobID,$roundID,$stageID){
        $data       =	[];
        try
        {
            $data   =   DB::select("SELECT al.ID,al.STATUS,al.REMARKS,al.JOB_ID,al.METADATA_ID,tlm.CHAPTER_NO from `task_level_metadata` as tlm LEFT JOIN alfresco_log al ON al.METADATA_ID = tlm.METADATA_ID AND  al.ID IN (
                        SELECT MAX(al2.ID) FROM alfresco_log al2 WHERE al2.METADATA_ID = al.METADATA_ID AND al2.ROUND = al.ROUND AND mode = 1 ORDER BY al2.ID DESC)
                        where al.ROUND = $roundID and al.JOB_ID = $jobID and al.STAGE_ID = $stageID and al.IS_ACTIVE = 1 and al.STATUS = 2 ORDER BY al.METADATA_ID asc");
        }
        catch( \Exception $e )
        {           
            return $data;
        }
        return $data;
    }
}

