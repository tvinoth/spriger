<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use App\Models\checkoutModel;
use App\Http\Controllers\CommonMethodsController;
use App\Http\Controllers\Api\autoPageController;
use Illuminate\Support\Facades\Crypt;
use Session;
use Config;

class workflowServerMapPathModel extends Model {
    
    protected   $table       =      'workflow_server_map';
    public      $primaryKey  =      'WORKFLOW_SERVER_MAP_ID';
    public      $timestamps  =      false;
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new workflowServerMapPathModel();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    public function deleteOld( $whereCondition ){
        
        return DB::table('workflow_server_map')->where( $whereCondition )->delete();
    }
    
    public function getPreviousActivityWithoutSkip( $chekedout ){
        
        if( isset( $checkedout[0] ) ){

            $checkedout     =       $checkedout[0];
            $jobRid         =       $checkedout->JOB_ROUND_ID;
            $iteration      =       $checkedout->ITERATION_ID;
            $orderseq       =       $checkedout->STAGE_SEQ;

            $qry_find       =       'SELECT STAGE_ID FROM workflow_server_map WHERE ITERATION_ID = "$iteration" and JOB_ROUND_ID = "$jobRid" AND IS_SKIPPED  = 0 AND STAGE_SEQ <= $orderseq  ORDER BY STAGE_SEQ DESC LIMIT 1,1';

            $recordset      =       DB::select( $qry_find );

            if( count( $recordset ) ){
                
                if( isset( $recordset[0] ) )
                    $recordset      =   $recordset[0];

                return $recordset->STAGE_ID;


            }

        }

        return false;

    }
    
    public static function getWorkflowServerMapPath($stageId,$artflag=0,$artGroup=0,$autostge = 0){
       
        $checkoutStage   =      "SELECT j.JOB_ID,tm.METADATA_ID,j.BOOK_ID,j.JOB_TYPE,tm.CHAPTER_NO,js.WORKFLOW_ID,js.IS_PARTIAL,js.STAGE_ID,jr.ROUND_ID,re.NAME as ROUND_NAME, js.JOB_ROUND_ID,js.STAGE_SEQ FROM job_stage js
                                        LEFT OUTER JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                                        JOIN round_enum as re ON jr.ROUND_ID = re.ID
                                        JOIN task_level_metadata tm ON tm.METADATA_ID = jr.METADATA_ID
                                        LEFT OUTER JOIN job j ON j.JOB_ID=jr.JOB_ID
                                        WHERE js.JOB_STAGE_ID IN('" . $stageId . "')";
      
  
        $sql_checkout_worpath =  DB::select( $checkoutStage );
        
       
       
        if(count($sql_checkout_worpath)>=1){
        $jobId      = $sql_checkout_worpath['0']->JOB_ID;
        $chatperId  = $sql_checkout_worpath['0']->CHAPTER_NO;
        $metaId     = isset( $sql_checkout_worpath['0']->METADATA_ID ) ? $sql_checkout_worpath['0']->METADATA_ID : null;
        
        $sessionEmpId   =   Session::get('users')['emp_id'];
        
        $bookId         =   $sql_checkout_worpath['0']->BOOK_ID;
        $roundname      =   $sql_checkout_worpath['0']->ROUND_NAME;
        $chaptername    =   $sql_checkout_worpath['0']->CHAPTER_NO;
        $partial        =   $sql_checkout_worpath['0']->IS_PARTIAL;
        
        $workModle      =    new workflowServerMapPathModel();
        //$stageSkip    =   $workModle->checkStageSkip($sql_checkout_worpath['0']);
        
        $curSrcStage        =       $sql_checkout_worpath['0']->STAGE_ID; 
        $prev_stageid       =       $this->getPreviousActivityWithoutSkip( $sql_checkout_worpath  );
        $srcingtype         =       6;

        if( $prev_stageid ){
            $curSrcStage        =       $prev_stageid;
            $srcingtype         =       '9';
        }


        $autoPgeContObj     =       new autoPageController();
        $paginginfo         =       $autoPgeContObj->getPagingFileNameing( $bookId , $chaptername ,$metaId );
        
        $pagingfilnaming =   '';
        $chapnoonly         =        preg_replace( '/\D/', '', $chatperId );
        extract( $paginginfo );
		
        $extentionforapp		=	'3d';
		
		$job_inf_ob		=	DB::select( 'SELECT APPLICATION FROM job_info WHERE JOB_ID = '.$jobId.' ORDER BY JOB_ID DESC LIMIT 1' );
		
		if( count( $job_inf_ob ) )	{
			
			$jobinf		=	$job_inf_ob[0];
			
			if( strtolower( $jobinf->APPLICATION ) == '3b2'  ){
                            $extentionforapp		=	'3d';
			}
			
			if( strtolower( $jobinf->APPLICATION ) == 'indesign'  ){
                            $extentionforapp		=	'indd';
			}
			
			if( strtolower( $jobinf->APPLICATION ) == ''  ){
                            $extentionforapp		=	'';
			}
			
		}
		
	    $inp_rep_arr            =   array('{BID}' => $bookId ,'{ROUND_NAME}' => $roundname,'{RID}' => $roundname,'{CID}' => $chaptername , '{PAGING_FILENAMING}' => $pagingfilnaming ,'{PCID}' => $packagecomponaming, '{CNO}' => $chapnoonly , '{APP_EXT}' =>  $extentionforapp );
	
        $cmn_obj                =   new CommonMethodsController();
        $ds                     =       '/';
        
        $sql2                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID. "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $curSrcStage . "' AND `FOLDER_TYPE` in ( $srcingtype ) ";
        $sql_checkout_sourcepath = DB::select($sql2);
        
        $sql3                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $sql_checkout_worpath['0']->STAGE_ID . "' AND `FOLDER_TYPE` = 7 ";
        $sql_checkout_workingpath = DB::select($sql3);
       
        $sql4                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $sql_checkout_worpath['0']->STAGE_ID . "' AND `FOLDER_TYPE` = 9 ";
        $sql_checkout_destinationpath = DB::select($sql4);

      
	   /* 
	   $sql5                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` ='" . $sql_checkout_worpath['0']->STAGE_ID. "' AND `FOLDER_TYPE` IN (6,7,9) AND FILE_MOVEMENT !=1";
		*/
		 
		 
		$sql5                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` ='" . $sql_checkout_worpath['0']->STAGE_ID. "' AND `FOLDER_TYPE` IN (6,7,9)";
       
	   
		
        $checkingpath_is_exist  = count( DB::select($sql5) );
        $filemovement = false;
		
        if( $sql_checkout_worpath['0']->STAGE_ID == \Config::get('constants.STAGE_COLLEECTION.AUTO_PAGE') ){
                $checkingpath_is_exist	=	0;
        }
        
        if ($checkingpath_is_exist >= 1) {

            if ($sql_checkout_sourcepath['0']->FILE_MOVEMENT != 1 || !empty($sql_checkout_workingpath)) {
				
                $filemovement = true;
                
                $sql6   =   "select CHECK_OUT,IS_PARTIAL from job_stage where JOB_STAGE_ID='" . $stageId . "'";
                $sql_checkout_check = DB::select($sql6);
                
                $sql7   =  "select wl.JOB_WORK_LOG_ID, wl.CHECK_IN from job_work_log wl where wl.JOB_STAGE_ID='" . $stageId . "' order by wl.JOB_WORK_LOG_ID desc limit 1";
                $sql_worklog_checkin =  DB::select($sql7);
                
                $clientDetails = '';
                $jobClientId = $clientDetails;
                
                $source_serverpath  =   $sql_checkout_sourcepath['0']->SERVER_PATH;
                $source_folderpath  =   $sql_checkout_sourcepath['0']->FOLDER_PATH;
                $source_filestring  =   $sql_checkout_sourcepath['0']->FILE_STRING;
                $source_extension   =   $sql_checkout_sourcepath['0']->FILE_EXTENSION;
                $source_movement    =   $sql_checkout_sourcepath['0']->FILE_MOVEMENT;
                $sourceHost         =   explode('/',$source_serverpath);
                $host               =   $sourceHost['0'];
                $source_username    =   $sql_checkout_sourcepath['0']->USER_NAME;
                $source_password    =   $sql_checkout_sourcepath['0']->PASSWORD;
				
				if(!empty($source_password)){
					$source_password   			=  		( strlen($source_password) > 20 ) ? \Crypt::decryptString($source_password) : $source_password;
				}
                 
                $user_directory     = '/' . $sessionEmpId;
                $working_serverpath =   $sql_checkout_workingpath['0']->SERVER_PATH;
                $working_folderpath =   $sql_checkout_workingpath['0']->FOLDER_PATH.$user_directory . '/';
                $working_username   =   $sql_checkout_workingpath['0']->USER_NAME;
                $working_password   =   $sql_checkout_workingpath['0']->PASSWORD;
				if(!empty($working_password)){
					//$working_password   			=  		\Crypt::decryptString($working_password);
					$working_password   			=  		( strlen($working_password) > 20 ) ? \Crypt::decryptString($working_password) : $working_password;
				}
				
                $working_filestring =   $sql_checkout_workingpath['0']->FILE_STRING;
                $working_extension  =   $sql_checkout_workingpath['0']->FILE_EXTENSION;
                $working_movement   =   $sql_checkout_workingpath['0']->FILE_MOVEMENT;
                
                $workHost              =   explode('/',$working_serverpath);
                $working_host          =   $workHost['0'];

                $destination_serverpath =   $sql_checkout_destinationpath['0']->SERVER_PATH;
                $destination_folderpath =   $sql_checkout_destinationpath['0']->FOLDER_PATH;
                $destination_username   =   $sql_checkout_destinationpath['0']->USER_NAME;
				
                $destination_password   =   $sql_checkout_destinationpath['0']->PASSWORD;
				if(!empty($destination_password)){
					//$destination_password   			=  		\Crypt::decryptString($destination_password);
					$destination_password   			=  		( strlen($destination_password) > 20 ) ? \Crypt::decryptString($destination_password) : $destination_password;
				}
				
                $destination_filestring =   $sql_checkout_destinationpath['0']->FILE_STRING;
                $destination_extension  =   $sql_checkout_destinationpath['0']->FILE_EXTENSION;
                $destination_movement   =   $sql_checkout_destinationpath['0']->FILE_MOVEMENT;
                
                $sourcepath = $source_serverpath . $source_folderpath;
                if (!empty($source_filestring) && $source_filestring != "NA") {
                    $source_filestring  =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $source_filestring );
                }
                
                $sourcepath =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $sourcepath );
                
                if( $autostge ){ 
                    $working_folderpath =   $sql_checkout_workingpath['0']->FOLDER_PATH;                    
                }else{
                    $working_folderpath =   $sql_checkout_workingpath['0']->FOLDER_PATH.$user_directory . '/';                     
                }
                
                $mSourcepath            = array();
                $mfullfileSourcepath    = array();
                $mSource_filestring     = array();
                $mSource_extension      = array();
                
                 $bookprocess = 0;
              
			
                if( ($sql_checkout_worpath['0']->ROUND_ID == '119' || $sql_checkout_worpath['0']->ROUND_ID == '120') && $sql_checkout_worpath['0']->STAGE_ID == '1296'){
                    $bookprocess = 1;
                }
				
                if(count($sql_checkout_sourcepath)>=2 && $bookprocess ==0){
                   
                    foreach($sql_checkout_sourcepath as $key => $mdata ){
                        $msource_serverpath    =   $mdata->SERVER_PATH;
                        $msource_folderpath    =   $mdata->FOLDER_PATH;
                        $mSource_filestring[$key]   =   $cmn_obj->arr_key_value_replace( $inp_rep_arr ,$mdata->FILE_STRING);
                        $mSource_extension[$key]    =   $mdata->FILE_EXTENSION;
                        $mSource_movement[$key]     =   $mdata->FILE_MOVEMENT;
                        $mSourcepath[$key]          =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_serverpath . $msource_folderpath);
                        $fullpathstring             =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_folderpath);
                        $rootpathconcatnate         =   \Config::get('serverconstants.HOST_FILE_ROOT_SERVER_PATH').$fullpathstring;
                        $mfullfileSourcepath[$key]  =   $rootpathconcatnate;
                    }
                   
                    
                }else if($bookprocess == 1){
                     $i   = 0 ;
                     
                     
                    foreach($sql_checkout_sourcepath as $key => $mdata ){
                        
                        if($key == 0){
                             $tasklevelMetadataModel           =      new taskLevelMetadataModel();
                            $getJobChapters                    =   $tasklevelMetadataModel->getMetadatadetailsJob($jobId);
                            
                            foreach($getJobChapters as $bdata){
                                
                                if($chaptername != $bdata->CHAPTER_NO){
                                $msource_serverpath    =   $mdata->SERVER_PATH;
                                $msource_folderpath    =   $mdata->FOLDER_PATH;
                                $mSource_filestring[$i]   =   $cmn_obj->arr_key_value_replace( $inp_rep_arr ,$mdata->FILE_STRING);
                              //  echo "<pre>";print_r($mSource_filestring);
                                $mSource_extension[$i]    =   $mdata->FILE_EXTENSION;
                             //   echo "<pre>";print_r($mSource_extension);
                                $mSource_movement[$i]     =   $mdata->FILE_MOVEMENT;
                                $mSourcepath1        =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_serverpath . $msource_folderpath);
                                $mSourcepath[$i]          =        $mSourcepath1.$bdata->CHAPTER_NO.'/';
                               
                              //    echo "<pre>";print_r($mSourcepath);
                                $fullpathstring             =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_folderpath);
                                $rootpathconcatnate         =   \Config::get('serverconstants.HOST_FILE_ROOT_SERVER_PATH').$fullpathstring;
                                $mfullfileSourcepath[$i]  =   $rootpathconcatnate.$bdata->CHAPTER_NO.'/';;
                                 $i   = $i+1;
                                }
                            }
                            
                            
                        }else{
                            $msource_serverpath    =   $mdata->SERVER_PATH;
                            $msource_folderpath    =   $mdata->FOLDER_PATH;
                            $mSource_filestring[$i]   =   $cmn_obj->arr_key_value_replace( $inp_rep_arr ,$mdata->FILE_STRING);
                          //  echo "<pre>";print_r($mSource_filestring);
                            $mSource_extension[$i]    =   $mdata->FILE_EXTENSION;
                         //   echo "<pre>";print_r($mSource_extension);
                            $mSource_movement[$i]     =   $mdata->FILE_MOVEMENT;
                            $mSourcepath[$i]          =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_serverpath . $msource_folderpath);
                          //    echo "<pre>";print_r($mSourcepath);
                            $fullpathstring             =   $cmn_obj->arr_key_value_replace($inp_rep_arr ,$msource_folderpath);
                            $rootpathconcatnate         =   \Config::get('serverconstants.HOST_FILE_ROOT_SERVER_PATH').$fullpathstring;
                            $mfullfileSourcepath[$i]  =   $rootpathconcatnate;
                            $i   = $i+1;
                        }
                     //   exit;
                    }
                }
                
                $workingpath    =   $working_serverpath . $working_folderpath;
                $closepath      =   $working_serverpath . $working_folderpath.'{BID}/';
                $drivePath       =   \Config::get('serverconstants.DRIVE_FILE_SERVER_PATH');
                $driveUsername   =   \Config::get('serverconstants.MAGNUS_DOMAIN_USERNAME');
                $drivePassword   =   \Config::get('serverconstants.MAGNUS_DOMAIN_PASSWORD');
               
                if (!empty($working_filestring) && $working_filestring != "NA") {
                    $workingpath .= $working_filestring;
                }
                
                $workingpathwithoutcredentials =  $workingpath = $cmn_obj->arr_key_value_replace( $inp_rep_arr , $workingpath );
                $closepath = $cmn_obj->arr_key_value_replace( $inp_rep_arr , $closepath );
                $destinationpath = $destination_serverpath . $destination_folderpath;
                
                if (!empty($destination_filestring) && $destination_filestring != "NA") {
                    $destinationpath .= $cmn_obj->arr_key_value_replace( $inp_rep_arr , $destination_filestring );
                }
                
				$workdirectorylistpath 		=	$workingpath;
				if($checkrootdirworkpath	=	strpos($workingpath,Config::get('serverconstants.FILE_SERVER_FTP_PATH'))){
					$workdirectorylistpath 	=	substr($workingpath,$checkrootdirworkpath,strlen($workingpath));
				}
				
                $destinationpath    =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $destinationpath );
                $isdeletesrc    =       '0';
                $temppath       =       '';
                $temppath1      =       '';
                $arttemppath    =       array();
                
                if ($sql_checkout_worpath['0']->IS_PARTIAL == 1) {
                    if ($artflag == 1) {
                        $temppath2 = Config::get('serverconstants.ART_TEMP_FILE_ROOT_SERVER_PATH');
                        $arttemppath    =   $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId.'/';                      
                        $isdeletesrc = '1';
                    } else {

                        $temppath2 = Config::get('serverconstants.TEMP_FILE_ROOT_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        
                        $temppathroot = Config::get('serverconstants.TEMP_DRIVE_FILE_ROOT_SERVER_PATH');
                        $temppath1 = $temppathroot . $jobId . '_' . $chatperId . '_' . $stageId;
                        
                        $isdeletesrc = '1';
                    }
                } else {

                    if ($artflag == 1) {
                        $temppath2 = Config::get('serverconstants.ART_TEMP_FILE_ROOT_SERVER_PATH');
                        $arttemppath    =   $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId.'/';                      
                        $isdeletesrc = '1';
                    } else {

                        $temppath2 = Config::get('serverconstants.TEMP_FILE_ROOT_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        
                        $temppathroot = Config::get('serverconstants.TEMP_DRIVE_FILE_ROOT_SERVER_PATH');
                        $temppath1 = $temppathroot . $jobId . '_' . $chatperId . '_' . $stageId;
                        
                        $isdeletesrc = '1';
                    }
                }
                $fileCheckout = 0;
                $openWrokpath = str_replace('//','/',$host.str_ireplace($working_serverpath, $drivePath, $workingpath));
                $closepath = str_replace('//','/',$host.str_ireplace($working_serverpath, $drivePath, $closepath));
                
                if(!empty($openWrokpath)){
                    $openWrokpath .= "<>" . $driveUsername . "<>" . $drivePassword;
                    $closepath .= "<>" . $driveUsername . "<>" . $drivePassword;
                }
                
                $artSupportPath     =   \Config::get( 'constants.ART_SUPPORTING_FOLDER_PATH' );
                $artworkupPath      =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $artSupportPath );
                $artworkupPathwithHost  =   $host.'/'.$artworkupPath;
                $artworkupOpenpath = $artworkupPath."<>" . $driveUsername . "<>" . $drivePassword;
                
                //open raw file
                $typeofseries       =   $sql_checkout_worpath[0]->JOB_TYPE;
                $checktypeofseries  =   Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES');
                $rawpath            =   ($checktypeofseries   ==  $typeofseries?Config::get('serverconstants.S50_COPY_EDITING_PATH'):Config::get('serverconstants.RAW_PATH'));
                $rawfilepath        =   "";
                switch($typeofseries)
                {
                    case 'S200 Of Series':
                    $inp_rep_arr    =   array( 
                                        '{BID}'     =>  $bookId , 
                                        '{RID}'     =>  $roundname,
                                        '{CID}/'    =>  $chatperId
                                        
                                     );
                    
                    $serverDir      =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $rawpath );
                    $rawfilepath    =   $host.$drivePath.$serverDir;                    
                    $rawfilepath    =   str_replace( '//' , '/' , $rawfilepath );
                    break;
                    case ('Regular title' || 'Regular title'):
                    $sfifty         =   Config::get('constants.ROUND_OF_NAME.S5');
                    $rawfilepath    =   $host.$drivePath.$rawpath.$bookId.'/'.$sfifty;
                    $rawfilepath    =   str_replace( '//' , '/' , $rawfilepath );
                    break;
                }
                
                if(!empty($rawfilepath)){
                    $rawfilepath .= "<>" . $driveUsername . "<>" . $drivePassword;
                }          
                //get source file path
                $opensourceDir      =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $source_folderpath );
                $opensourcepath     =   $host.$drivePath.$opensourceDir."<>" . $driveUsername . "<>" . $drivePassword;
                
                $path['detail']['src'] = $sourcepath;
                $path['detail']['opensrcpath'] = $opensourcepath;
                $path['detail']['srcfilestring'] = $source_filestring;
                $path['detail']['srcfileextension'] = $source_extension;
                
                $path['detail']['mSrc'] = $mSourcepath;
                $path['detail']['mSrcFullapth'] = $mfullfileSourcepath;
                $path['detail']['mSrcfilestring'] = $mSource_filestring;
                $path['detail']['mSrcfileextension'] = $mSource_extension;
               
                $path['detail']['work'] = str_replace('//','/',$workingpath);
                $path['detail']['workdirlistpath'] = str_replace('//','/',$workdirectorylistpath);
                $path['detail']['dest'] = $destinationpath;
                $path['detail']['temp'] = $temppath;
                $path['detail']['rawfile']  =   $rawfilepath;
                $path['detail']['arttemp']  =   $arttemppath;
                
                $path['detail']['tempdrive'] = $temppath1;
                $path['detail']['filecheout'] = $fileCheckout;
                $path['detail']['opendrive'] = $openWrokpath;
                $path['detail']['closedrive']= $closepath;//$openWrokpath;
                $path['detail']['ispartial'] = $partial;
                $path['detail']['artworkuppath'] = $artworkupPath;
                $path['detail']['artworkuppathwithHost'] = $artworkupPathwithHost;
                
                $path['detail']['artworkupopenpath'] = $artworkupOpenpath;
                $path['detail']['username']     =   $driveUsername;
                $path['detail']['password']     =   $drivePassword;
                $path['detail']['bookid']       =   $bookId;
                $path['detail']['roundname']    =   $roundname;
                $path['detail']['chaptername']  =   $chaptername;
                
                
                $path['serverCredential']['host'] = $host;
                $path['serverCredential']['username'] = $source_username;
                $path['serverCredential']['pasword'] = $source_password;
                $path['workingpathCredential']['host'] = $working_host;
                $path['workingpathCredential']['username'] = $working_username;
                $path['workingpathCredential']['pasword'] = $working_password;
                $path['status'] =   1;
            }
        } else {
             $path['status'] = 0;
        }
        }else{
             $path['status'] = 0;
        }
        
     
        return $path;
    }
    
    
    public function checkStageSkip($stageDetails){
        $getPath            =           DB::table( 'job_stage as js' )
                                            ->select()
                                            ->where( 'js.JOB_ROUND_ID'  , '=' , $stageDetails->JOB_ROUND_ID )
                                            ->where( 'js.STAGE_SEQ'     , '<' , $stageDetails->STAGE_SEQ )
                                            ->orderByRaw("js.STAGE_SEQ DESC")
                                            ->get();
        echo "<pre>";print_r($getPath);exit;
        /*foreach($getPath as $key => $data ){
            
            
        }*/
        
        
    }
    
    public function getServerPathBasedOnWorkflowStages( $jobid , $wrkflw , $stageid , $folertype = array(6) ){
      
        $getPath            =           DB::table( 'workflow_server_map as wsm' )
                                            ->select()
                                            ->where( 'wsm.WORKFLOW_ID'  , '=' , $wrkflw )
                                            ->where( 'wsm.JOB_ID'       , '=' , $jobid )
                                            ->where( 'wsm.STAGE_ID'     , '=' , $stageid )
                                            ->whereIn( 'wsm.FOLDER_TYPE'  , $folertype )
                                            ->orderByRaw("wsm.FOLDER_TYPE ASC, wsm.ORDER_SEQ ASC")
                                            ->get();
      
        return $getPath;
        
    }
    
     public function getWorkflowPathBasedOnJobStageIdAndType( $jbstgid = null , $foldertype = 6 , $options = array( ) ){
        
        //single level record get from workflow server map path
        // use only one option 
        
        $filepath           =   false;    
        
        if( empty( $options ) ){
            //default options
            $options    =   array(
                        'backSlash' =>  false , 
                        'backSlashWithFrontDoubleSlash' =>  false , 
                        'withoutHost'   =>  false , 
                        'withCredentials'       =>  false  
            );
            
        }
        
        extract( $options );
        
        $checkoutObj            =       new checkoutModel();
        $stageDetails           =       $checkoutObj->getStageInfo($jbstgid);
        
        if(count( $stageDetails )){
            
            $stageDetails           =       $stageDetails[0];
            $wrkSerModelObj         =       $this;
            $folertype              =       array( $foldertype );

            $round                  =       $stageDetails->ROUND_ID;
            $chapterid              =       $metaid      =   $stageDetails->METADATA_ID;
            $jobid                  =       $stageDetails->JOB_ID;
            $wrkflw                 =       $stageDetails->WORKFLOW_ID;
            $stageid                =       $stageDetails->STAGE_ID;

            $recordset              =       $wrkSerModelObj->getServerPathBasedOnWorkflowStages( $jobid , $wrkflw , $stageid , $folertype );
            
            if( count( $recordset ) ){
                $recordset          =       $recordset->first();
                
                $serverpath         =       $recordset->SERVER_PATH;
                $folderpath         =       $recordset->FOLDER_PATH;
				
                $file_string        =       ( strtolower( $recordset->FILE_STRING ) == 'na' ) ? '' : $recordset->FILE_STRING;
                $file_ext           =       ( strtolower( $recordset->FILE_EXTENSION ) == 'na' ) ? '' : $recordset->FILE_EXTENSION;
                
                $cmn_obj        =       new CommonMethodsController();
                
                if( !empty( $serverpath ) && !empty( $folderpath ) ){
                    
                    if( strtolower( $serverpath ) !== 'na' && strtolower( $folderpath ) !== 'na' ){
						
						$filepath           =       $serverpath.$folderpath.$file_string.$file_ext;
						
                        if( isset( $backSlash ) ){
                            if( $backSlash  ){
                                $filepath       =       $cmn_obj->backslashPathPrepare( $filepath , true );
                            }
                        }

                        if( isset( $backSlashWithFrontDoubleSlash ) ){
                             if( $backSlashWithFrontDoubleSlash  ){
                                $filepath        =       '\\\\';
                                $filepath       .=       $cmn_obj->backslashPathPrepare( $filepath , true );
                            }
                        }

                    } 

                }
            }
            
        }
        
        return $filepath;
        
    }
    
    public function checkWorkflowservermapandTaskLeveluserdefinedWorkflow( $wheredata){
      
        $getPath            =           DB::table( 'task_level_userdefined_workflow as udwf' )->select(DB::raw('udwf.ROUND,udwf.STAGE_SEQ,udwf.WORKFLOW_MASTER_ID,udwf.STAGE'))
                                            ->join('workflow_server_map as wsm','wsm.WORKFLOW_ID','=','udwf.WORKFLOW')    
                                            ->where( $wheredata)
                                            ->first();
      
        return $getPath;
        
    }
    
}

