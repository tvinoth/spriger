<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models\Ost;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class ostTrackingSystemModel extends Model 
{
    protected $table        =   'ost_tracking_system';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_AT";
    const CREATED_AT        =   "CREATED_AT";
	
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
}

