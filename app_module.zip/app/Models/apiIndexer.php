<?php
namespace App\Models;
use App\Models\apiClientAcknowledgement;
use Illuminate\Database\Eloquent\Model;
use DB;

class apiIndexer extends Model {
    
    protected $table        =   'api_indexer';
    public $timestamps      =   true;
    public  $primaryKey     =   'ID';
    protected $dateFormat   =   'Y-m-d H:i:s';
    
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiIndexer();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
         
        $setArr     =      array( 
                                  'END_TIME'   =>     $inpArr['END_TIME'] , 
                                  'STATUS'     =>     $inpArr['STATUS'] ,
                                  'REMARKS'    =>     $inpArr['REMARKS']
                            );
        
        $updateQry  =   DB::table('api_indexer')
			->where('JOB_ID', $rowid )
                        ->orderBy('ID','desc')
                        ->take(1)
			->update( $setArr );
        
        return $updateQry;
        
    }
    
    public static function getApiRequestByTokenKey( $tokenKey ){
        
        $getRec       =         DB::table('api_cap as aap')
                                    ->where('TOKEN_KEY', '=', $tokenKey )
                                    ->where('STATUS', '=', '1.5' )
                                    ->get()->first();
      
        return $getRec;
      
    }
    
    
}
