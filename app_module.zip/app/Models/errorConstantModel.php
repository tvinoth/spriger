<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;

class errorConstantModel extends Model 
{
    protected $table        =   'error_constants';
    public  $primaryKey     =   'ID';
    public function scopeActive($query)
    {
        return $query->where('IS_ACTIVE', 1);
    }
    
}

