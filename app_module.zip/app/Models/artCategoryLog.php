<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class artCategoryLog extends Model {
    
    protected   $table          =   'art_category_log';
    public      $primaryKey     =   'LOG_ID';
    public      $timestamps     =   false;
    protected   $fillable       =   array('CREATED_DATE');
    
    
    public static function insertNew( $inp_arr ){

      $ins_obj        =       new artCategoryLog();

      if( !empty( $inp_arr ) ){

          foreach( $inp_arr as  $index => $value ){

              $ins_obj->$index    =   $value;

          }

      }

      $insert_r       =       $ins_obj->save();

      if( $insert_r )
          return 2;

      return 1;
    }
    
    public static function updateIfExist( $setArr  , $rowid ){
        
        $table      =   'art_category_log';
        
        $updateQry  =   DB::table( $table )
                            ->where('LOG_ID', $rowid )
                            ->update( $setArr );
        
        
        return $updateQry;
        
    }
    
     public function insertRecordGetId( $inp_arr = array() ){
        
        if( !empty( $inp_arr ) ){
            return DB::table('art_category_log')->insertGetId( $inp_arr );
        }
        
        return false;
    }
    
    public function getRecordByBatchId( $mds_id  = null ){
        
        $table      =   'task_level_art_metadata';
        
        if( !is_null( $mds_id ) ){
            
            $condition  =   array( 
                    'METADATA_STATUS_ID'  =>      $mds_id 
                );
            
            return DB::table( $table )->where( $condition )
                    ->orderBy('ART_METADATA_ID','desc')
                    ->get()->first();            
        }
        
        return false;
        
    }
    
    public function deleteByBatchId( $batchid ){
       return DB::table('art_category_log')->where('LOG_ID', '=', $batchid )->delete();
    }
    
}

