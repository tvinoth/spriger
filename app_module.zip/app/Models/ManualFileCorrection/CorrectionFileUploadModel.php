<?php namespace App\Models\ManualFileCorrection;

use Illuminate\Database\Eloquent\Model;
use DB;

class CorrectionFileUploadModel extends Model
{
    // 
    protected $table = 'correction_file_upload';
    public $primaryKey = 'UPLOAD_ID';
    public $timestamps = false;
	//protected $fillable = array('CreatedAt'); 
	
}
