<?php namespace App\Models\ManualFileCorrection;

use Illuminate\Database\Eloquent\Model;
use DB;

class CorrectionUploadChapterModel extends Model
{
    // 
    protected $table = 'correction_upload_chapter';
    public $primaryKey = 'UPLOAD_CHAPTER_ID';
    public $timestamps = false;
	//protected $fillable = array('CreatedAt'); 
	
}
