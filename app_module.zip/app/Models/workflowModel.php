<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class workflowModel extends Model {
    
    protected $table    =   'workflow';
    
    public function getWorkflosByMasterId( $wmid ){
        
      DB::enableQueryLog();
       $getStagesRec        =           DB::table( 'workflow as wf' )
                                                ->join( 'workflow_master as wm'  , 'wm.WORKFLOW_MASTER_ID'    ,   '='     ,   'wf.WORKFLOW_MASTER_ID' )
                                                ->where('wf.WORKFLOW_MASTER_ID'   , '=' , $wmid )
                                                ->where('wm.IS_ACTIVE'    , '=' , 1 )
                                                ->orderBy('wf.WORKFLOW_TYPE','asc')
                                                ->select()
                                                ->get();
       $qw1     =       DB::getQueryLog();
      
       return $getStagesRec;
        
    }
    
    public function getWorkflosByMasterIdAndType( $wmid , $type ){
       
       
        $getStagesRec        =           DB::table( 'workflow as wf' )
                                                ->join( 'workflow_master as wm'  , 'wm.WORKFLOW_MASTER_ID'    ,   '='     ,   'wf.WORKFLOW_MASTER_ID' )
                                                ->where('wf.WORKFLOW_MASTER_ID'   , '=' , $wmid )
                                                ->where('wf.WORKFLOW_TYPE'   , '=' , $type )
                                                ->where('wm.IS_ACTIVE'    , '=' , 1 )
                                                ->select()
                                                ->get()->first();
       
       return $getStagesRec;
        
    }
    
    
    
}

