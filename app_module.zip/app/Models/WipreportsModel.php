<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class WipreportsModel extends Model {

      
    
   public static function getArtReportDetails($jobId,$metaId,$roundId,$serviceType){
        
      $getStagesRec   =       array();
        $tblname        =       'report_wip_art as rwa';
        
        try{
             $getStagesRec        =           DB::table( 'report_wip_art as rwa' )
                                                ->where('rwa.JOB_ID'   , '=' , $jobId )
                                                ->where('rwa.METADATA_ID'    , '=' , $metaId )
                                                ->where('rwa.ROUND', '=' , $roundId)
                                                ->where('rwa.SERVICE_TYPE_NAME', '=' , $serviceType)
                                                ->select('rwa.ID')
                                                ->get();     
            
       }catch( \Exception $e ){           
            return false;
       }
        
        return $getStagesRec;     
    }
    
    public static function getProcessDetails($jobId,$metaId,$roundId,$stageId){
        
      $getStagesRec   =       array();
               
        try{
             $getStagesRec        =           DB::table( 'report_wip_stageprocess as rwa' )
                                                ->where('rwa.JOB_ID'   , '=' , $jobId )
                                                ->where('rwa.METADATA_ID'    , '=' , $metaId )
                                                ->where('rwa.ROUND_ID', '=' , $roundId)
                                                ->where('rwa.STAGE_ID', '=' , $stageId)
                                                ->select('rwa.ID')
                                                ->get();     
            
       }catch( \Exception $e ){           
            return false;
       }
        
        return $getStagesRec;     
    }
    
    
    public static function getJobinfo(){
        
      $getStagesRec   =       array();
     
        try{
            DB::enableQueryLog();

            $groupby2              =     array('rwj.ACTION','rwj.JOB_ID');
           
            $getStagesRec         =           DB::table( 'report_wip_job as rwj' )
                                                ->join('job as j','j.JOB_ID','=','rwj.JOB_ID')
                                                ->join('job_info as ji','ji.JOB_ID','=','j.JOB_ID')
                                                ->leftJoin('user as us','us.USER_ID','=','j.PM')
                                                ->where('rwj.SYNC_STATUS'   , '=' , 0 )
                                                ->where('rwj.IS_ACTIVE'   , '=' , 1 )
                                                ->select('rwj.ID as RID' ,'rwj.JOB_ID','rwj.ACTION','j.*','ji.*','us.FIRST_NAME as PM_FIRST_NAME','us.LAST_NAME as PM_LAST_NAME')
                                               // ->groupBy($groupby2)
                                                ->get();  
            $ddd =  DB::getQueryLog($getStagesRec); 
           
        
       }catch( \Exception $e ){           
            return false;
       }
        
        return $getStagesRec;     
    }
    
    
     public static function getArtinfo(){
        
      $getStagesRec   =       array();
     
        try{
            DB::enableQueryLog();

            $groupby2              =     array('rwj.ACTION','rwj.JOB_ID');
           
            $getStagesRec         =           DB::table( 'report_wip_art as rwj' )
                                                ->join('job as j','j.JOB_ID','=','rwj.JOB_ID')
                                                ->join('job_info as ji','ji.JOB_ID','=','j.JOB_ID')
                                                ->join('round_enum as re','re.id','=','rwj.ROUND')
                                                ->where('rwj.SYNC_STATUS'   , '=' , 0 )
                                                ->where('rwj.IS_ACTIVE'   , '=' , 1 )
                                                ->select('rwj.ID as RID','rwj.METADATA_ID','rwj.JOB_ID','rwj.ROUND as ROUND_ID','rwj.ACTION','rwj.SERVICE_TYPE_NAME','rwj.SERVICE_TYPE_QTY','re.NAME','j.*','ji.*')
                                               // ->groupBy($groupby2)
                                                ->get();     
          $ddd =  DB::getQueryLog($getStagesRec);  
		//  echo "<pre>";print_r( $ddd);exit;
        
       }catch( \Exception $e ){           
            return false;
       }
        
        return $getStagesRec;     
    }
    
     public static function getProcessinfo(){
        
      $getStagesRec   =       array();
     
        try{
            DB::enableQueryLog();

            $groupby2              =     array('rwj.ACTION','rwj.JOB_ID');
            
            $getStagesRec         =           DB::table( 'report_wip_stageprocess as rwj' )
                                                ->join('job as j','j.JOB_ID','=','rwj.JOB_ID')
                                                ->join('job_info as ji','ji.JOB_ID','=','j.JOB_ID')
                                                ->join('round_enum as re','re.id','=','rwj.ROUND_ID')
                                                ->where('rwj.SYNC_STATUS'   , '=' , 0 )
                                                ->where('rwj.IS_ACTIVE'   , '=' , 1 )
                                                    ->select('rwj.ID as RID','rwj.METADATA_ID','rwj.JOB_ID','rwj.ROUND_ID','rwj.OUTPUT_QUANTITY','rwj.ACTION','rwj.CREATED_DATE as STAGE_COMPLETED_DATE','re.NAME','j.*','ji.*')
                                               // ->groupBy($groupby2)
                                                ->get();     
          //$ddd =  DB::getQueryLog($getStagesRec);  
          
          
       }catch( \Exception $e ){           
            return false;
       }
        
        return $getStagesRec;     
    }
    
    public function getStageCompletionDetails($jobId,$roundId){
		
		$sql = "select *
				from (
				select count(tm.METADATA_ID) as tcnt, tm.JOB_ID as tjobid
				from task_level_metadata as tm 
				where tm.JOB_ID = '$jobId'  group by tm.JOB_ID
				) as ts
				JOIN 
				(
				select count(rs.METADATA_ID) as rcint, rs.JOB_ID as rjobid, max(rs.CREATED_DATE)as created_date
				from report_wip_stageprocess rs
				where rs.JOB_ID = '$jobId' and rs.ROUND_ID = '$roundId' group by rs.JOB_ID
				) as r on r.rjobid = ts.tjobid ";
			
	$result =  DB::select( $sql );
        return $result;

	}	
    
    
    
    
    
    
    
    
}
