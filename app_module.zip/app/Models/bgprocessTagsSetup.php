<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class bgprocessTagsSetup extends Model{    
    
    protected   $table        =   'bgprocess_tags_setup';
    public      $primaryKey     =   'ID';
    
    public function getBgProcessTags( $parentId ){
        
        $query      =   DB::table('bgprocess_tags_setup')
                            ->select()
                            ->where('STATUS' , '=' , 1 );
        
        if( !is_null( $parentId ) )
            $query->where( 'PARENT_ID' , '=' , $parentId );
        
        $query->orderBy( 'ORDER' , 'asc' );
        
        return $query->get();
        
    }
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new bgprocessTagsSetup();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
    }
    
    public static function updateIfExist( $inpArr  , $rowid ){
        
        $updateQry  =   DB::table('bgprocess_tags_setup')
			->where('ID', $rowid )
			->update( $inpArr );
        
        return $updateQry;
        
    }
    
    
}

