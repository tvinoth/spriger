<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class applicationMenuNameModel extends Model 
{
    protected $table        =   'application_menu_name';
    public  $primaryKey     =   'APPLICATION_MENU_NAME_ID';
    const UPDATED_AT        =   "CREATED_DATE";
    const CREATED_AT        =   "UPDATED_DATE";
	
    public function scopeActive($query)
    {
        return $query->where('application_menu_name.IS_ACTIVE', 1);
    }
}

