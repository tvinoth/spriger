<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Config;

class bookinfoModel extends Model
{  
    
    protected $table    =   'job';
    public  $primaryKey     =   'JOB_ID';
    
    public static function getBookinfo(){
        
	$bookinfo 		=	array();
        
        try{
            
            $bookinfo   =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME'))
                            	->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                ->where('job.IS_ACTIVE',Config::get('constants.STATUS_ENUM.ONE'))
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
    }
    
    public function scopeActive($query)
    {
        return $query->where('job.is_active', 1);
    }
    
    public function BookInfo() {
        return $this->belongsTo('App\Models\jobInfoModel','JOB_ID')->select(DB::raw('job_info.JOB_ID'));
    }
    
    public static function commonbookinfodetails($start,$length,$searchStr,$orderColumn,$sorting){
        
        $bookinfo 		=	array();
        try{
            $columnArray    =   [];
            $columnArray[]  =   'job.JOB_TITLE';
            $columnArray[]  =   'job.BOOK_ID';
            $columnArray[]  =   DB::raw('concat(u.FIRST_NAME," ",u.LAST_NAME)');
            $columnArray[]  =   'job.CREATED_DATE';
            
            $bookinfo['countbookinfo']  =   bookinfoModel::select(DB::raw('job.JOB_ID'))
                                            ->join('job_info', 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                            ->leftjoin('user as u', 'job.PM', '=', 'u.USER_ID')
                                            ->where('job.IS_ACTIVE', Config::get('constants.STATUS_ENUM.ONE'))
                                            ->when($searchStr, function ($query) use ($searchStr) {
                                                return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                                    ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                            })
                                            ->count();
             
            $bookinfo['bookdetails']    =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME'))
                ->join('job_info', 'job.JOB_ID', '=', 'job_info.JOB_ID')
                ->leftjoin('user as u', 'job.PM', '=', 'u.USER_ID')
                ->where('job.IS_ACTIVE', Config::get('constants.STATUS_ENUM.ONE'))
                ->orderBy($columnArray[$orderColumn], $sorting)
                ->when($searchStr, function ($query) use ($searchStr) {
                                    return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                        ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                })
                ->skip($start)->take($length)
                ->get();
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
        
    }
    
    public static function getApsBookinfo(){
	
	$bookinfo 		=	array();
	
        try{   
		
            $bookinfo   =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME'))
                            	->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                ->where('job.IS_ACTIVE',1)
                                ->where( 'job_info.EPROOFING_SYSTEM' , Config::get('constants.REMAINDER_TYPE.APS'))
                                ->get();            
            
        }catch( \Exception $e ){     
		
            return false;
        }
		
        return $bookinfo;
		
    }
    
    public static function allBookinfo(){
	$bookinfo 		=	array();
        try{   
            $bookinfo   =   bookinfoModel::select(DB::raw('job.JOB_ID AS JOB_ID,job.BOOK_ID AS BOOK_ID,job.JOB_TITLE AS JOB_TITLE'))->Active()
                            	->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        return $bookinfo;
    }
    
    public static function getBookinfoexceptoffseries(){
        
	$bookinfo       =   array();
        try{
            $bookinfo   =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME'))
                            	->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                ->where('job.JOB_TYPE','=',Config::get('constants.BOOK_SERIES_TYPE.S200_SERIES'))
                                ->where('job.IS_ACTIVE',Config::get('constants.STATUS_ENUM.ONE'))
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
    }
    
    public static function getCucBookinfo($start,$length,$searchStr,$orderColumn,$sorting){
        
	$bookinfo 		=	array();
        try{
            $columnArray    =   [];
            $columnArray[]  =   'job.JOB_TITLE';
            $columnArray[]  =   'job.BOOK_ID';
            $columnArray[]  =   'apicuc.END_TIME';
            $columnArray[]  =   'apicuc.REMARKS';
            $columnArray[]  =   DB::raw('apicuc.STATUS');
            $columnArray[]  =   'job.CREATED_DATE';
            
            $bookinfo['countbookinfo']  =   bookinfoModel::select(DB::raw('job.JOB_ID'))
                                    ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                    ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                    ->leftjoin('api_cuc as apicuc',function($join)
                                    {
                                        $join->on('apicuc.JOB_ID', '=', 'apicuc.JOB_ID');
                                        $join->where('apicuc.ID',DB::raw('(select max(ID) from api_cuc WHERE api_cuc.ROUND = '.Config::get('constants.ROUND_ID.S5').' and job.JOB_ID = api_cuc.JOB_ID)'));
                                    })
                                    ->when($searchStr, function ($query) use ($searchStr) {
                                    return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                        ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                    })
                                    ->where('job.IS_ACTIVE',Config::get('constants.STATUS_ENUM.ONE'))
                                    ->count(); 
                                
            $bookinfo['cucdetails']     =   bookinfoModel::select(DB::raw('job.*,job_info.*,concat(u.FIRST_NAME," ",u.LAST_NAME) AS PM_NAME,apicuc.STATUS as CUCSTATUS,apicuc.END_TIME,apicuc.REMARKS'))
                                    ->join( 'job_info' , 'job.JOB_ID', '=', 'job_info.JOB_ID')
                                    ->leftjoin( 'user as u' , 'job.PM', '=', 'u.USER_ID' )      
                                    ->leftjoin('api_cuc as apicuc',function($join)
                                    {
                                        $join->on('apicuc.JOB_ID', '=', 'apicuc.JOB_ID');
                                        $join->where('apicuc.ID',DB::raw('(select max(ID) from api_cuc WHERE api_cuc.ROUND = '.Config::get('constants.ROUND_ID.S5').' and job.JOB_ID = api_cuc.JOB_ID)'));
                                    })
                                    ->orderBy($columnArray[$orderColumn], $sorting)
                                    ->when($searchStr, function ($query) use ($searchStr) {
                                    return $query->where('job.JOB_TITLE', 'like', '%' . $searchStr . '%')
                                        ->orWhere('job.BOOK_ID', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.FIRST_NAME', 'like', '%' . $searchStr . '%')
                                        ->orWhere('u.LAST_NAME', 'like', '%' . $searchStr . '%');
                                    })
                                    ->where('job.IS_ACTIVE',Config::get('constants.STATUS_ENUM.ONE'))
                                    ->skip($start)->take($length)
                                    ->get();                    
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
    }
	
    public static function getBookinfodetails($jobId){
        
        $bookinfo 		=	array();
        try{
           $bookinfo   =   bookinfoModel::select(DB::raw('job.*,job_info.*,pal.LOCATION_NAME as LOCATIONJOBINFO'))
                                           ->join(  'job_info'   ,  'job.JOB_ID' , '=' , 'job_info.JOB_ID' )
                                            ->leftjoin( 'production_area_location as pal' , 'pal.ID', '=', 'job_info.LOCATION' )      
                                           ->where( 'job.JOB_ID' ,  $jobId)
                                           ->get();            
           
        }catch( \Exception $e ){           
            return false;
        }
	
        return $bookinfo;
        
    }
	
    public static function getBooklocation(){
	
        $bookinfo 	=	array();
        
        try{
            
            $bookinfo   =       DB::table('production_location_ftp')
                                            ->where('STATUS','ACTIVE')
                                            ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
        
        return $bookinfo;
        
    }
    
    public static function updateBookinfodetails($jobinfodata,$jobdata,$jobId){
	
        $updatebookinfo 	=	false;
        try{            
            $updatebookinfo   =   DB::table('job_info')->where('JOB_ID',$jobId)->update($jobinfodata);
            	if($updatebookinfo){
                    $updatebookinfo   =   DB::table('job')->where('JOB_ID',$jobId)->update($jobdata);
		}                   
        }catch( \Exception $e ){           
            return false;
        }
        
        return $updatebookinfo;
        
    }
       
}

