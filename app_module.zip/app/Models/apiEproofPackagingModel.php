<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Models\jobInfoModel;
use Carbon\Carbon;
use Session;

class apiEproofPackagingModel extends Model 
{
    protected $table        =   'api_eproof_packaging';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "UPDATED_AT";
    const CREATED_AT        =   "CREATED_AT";
	
    public function scopeActive($query){
        return $query->where('IS_ACTIVE', 1);
    }
    
    public static function insertNew( $inp_arr ){
    
        $api_obj        =       new apiEproofPackagingModel();
        
        if( !empty( $inp_arr ) ){
            
            foreach( $inp_arr as  $index => $value ){
                
                $api_obj->$index    =   $value;
                
            }
            
        }
        
        $insert_r       =       $api_obj->save();
        
        if( $insert_r )
            return 2;
        
        return 1;
        
    }
    
    
}

