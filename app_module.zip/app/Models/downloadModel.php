<?php // 


/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Config;
use App\Models\jobModel;

class downloadModel extends Model {
    
    //sample input array
    // 0 => id
    // 1 => limit start
    // 2 => limit  
    // 3 => order by
    protected $table        =   'api_download';
    
    public static function getDownloadFailedList( $input = array() ){          
    
        $download_info   =       array();
        $tblname        =       'api_download';
        
        try{
         
            $download_info   =       DB::table( $tblname )
                                    ->whereRaw("ID in(SELECT max(ID) from api_download group by BOOK_ID)" )
                                    ->where('IS_COMPLETED','0')
                                    ->wherein('ROUND',$input)
                                    ->orwhereNull('ROUND')
                                    ->orderBy('CREATED_DATE','DESC')
                                    ->select(DB::raw("*,IF( DOWNLOAD_STATUS = 1, 'Success',IF(DOWNLOAD_STATUS = 0,'Failed','--')) as DOWNLOAD_STATUS,IF( ZIP_EXTRACTION_STATUS = 1, 'Success',IF(ZIP_EXTRACTION_STATUS = 0,'Failed','--')) as EXTRACTION_STATUS,IF( META_EXTRACTION_STATUS = 1, 'Success',IF(META_EXTRACTION_STATUS = 0,'Failed','--')) as META_STATUS "))
                                    ->get();            
        
       }catch( \Exception $e ){
            return false;
        }
        return $download_info;    
    }
    
    public static function searchDownloadedChapter($jobID = null,$bookID = null,$roundID = null,$metadataID = '')
    {
        $bookinfo 		=	array();
        try
        {
            $bookinfo   =   downloadModel::select(DB::raw('tlm.METADATA_ID,tlm.JOB_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,round_enum.NAME as ROUND_NAME'))
								->join( 'job' , 'job.BOOK_ID', '=', 'api_download.BOOK_ID')
                                                                ->join( 'round_enum' , 'round_enum.ID', '=', 'api_download.ROUND')
                                                                ->join('task_level_metadata as tlm',function($join) use ($roundID)
                                                                {
                                                                    $join->on('tlm.JOB_ID', '=', 'job.JOB_ID');
                                                                    $join->on('tlm.METADATA_ID', '=', 'api_download.METADATA_ID');
                                                                })
                                                                ->where(function ($query) use ($metadataID) {
                                                                    if (trim($metadataID) != '') {
                                                                        return $query->Where('api_download.METADATA_ID', $metadataID);
                                                                    }
                                                                })
                                                                ->where(function ($query) use ($roundID) {
                                                                    if (trim($roundID) != '') {
                                                                        return $query->Where('api_download.ROUND', $roundID);
                                                                    }
                                                                })
                                                                ->where('api_download.BOOK_ID',$bookID)
                                                                ->where('api_download.IS_COMPLETED',true)
                                                                ->where('tlm.JOB_ID',$jobID)
								->where('tlm.UNIT_OF_MEASURE','!=',Config::get('constants.UNIT_OF_MEASURE'))
                                                                ->where('tlm.IS_ACTIVE',true)
                                                                ->groupBy('api_download.ROUND','api_download.METADATA_ID')
                                                                ->get();  
        }
        catch( \Exception $e )
	{           
            return false;
        }
	return $bookinfo;
    }
    
    public static function getChapterdownoadlist( $round = 116 ){
        
        $bookinfo 		=	array();
        
        try{
           
            $bookinfo   =   DB::table('task_level_metadata')->select(DB::raw("task_level_metadata.METADATA_ID as taskmetaid,task_level_metadata.*,IF( apidown.DOWNLOAD_STATUS = 1, 'Success',IF(apidown.DOWNLOAD_STATUS = 0,'Failed','--')) as DOWNLOAD_STATUS,IF( apidown.ZIP_EXTRACTION_STATUS = 1, 'Success',IF(apidown.ZIP_EXTRACTION_STATUS = 0,'Failed','--')) as EXTRACTION_STATUS,IF(apidown.META_EXTRACTION_STATUS = 1, 'Success',IF(apidown.META_EXTRACTION_STATUS = 0,'Failed','--')) as META_STATUS,apidown.*"))
								->join( 'api_download as apidown' , 'task_level_metadata.METADATA_ID', '=', 'apidown.METADATA_ID')
								->where('task_level_metadata.CURRENT_ROUND', $round )
								->where('task_level_metadata.IS_ACTIVE',true)
                                                                ->where('apidown.IS_COMPLETED',0)
                                                                ->orderBy('apidown.CREATED_DATE','DESC')
                                                                ->get();                
        
        }catch( \Exception $e ){           
            return false;
        }
        
	return $bookinfo;
        
    }
    
    public static function getJobassigned(){
     
        $query_stmt         =       'call getJobList( null , null , "104,114" , null , null )';
        $jobDetails         =       DB::select( $query_stmt );  
       
        return $jobDetails;   
    }
    
    public static function getJobAssignedS600( ){

        $query_stmt         =   "select j.JOB_ID,ad.BOOK_ID , ad.ROUND AS ROUND_ID , ad.ROUND AS ROUND_ID ,
                                CASE ad.ROUND
                                WHEN 116 THEN 'S200'
                                WHEN 118 THEN 'S300' 
                                WHEN 119 THEN 'S600'
                                WHEN 114 then 'S50'
                                WHEN 104 then 'S5'
                                ELSE 'S5' END AS ROUND_NAME,ad.is_active as ACTIVE,  j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,";
        
        $query_stmt         .=      'ji.AUTHOR_NAME , ji.EDITOR_NAME , j.CREATED_DATE as receivedDate , ji.ISSN_PRINT ,ji.ISSN_ONLINE , concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,
 j.PM , ji.AM , ji.AM_NAME,ji.STAGE_DEADLINES_COLLECTION as deadline,ji.PLATFORM_TYPE,j.JOB_TYPE, ame.`STATUS` as  JOB_SHEET_UPDATE, ame.`REMARKS` as  UPDATE_REMARKS
, afu.`STATUS` as  JOB_SHEET_UPLOAD, afu.`REMARKS` as  UPLOAD_REMARKS
,apft.`STATUS` as  APFT_SUCCESS_REDO ,apft.ID as APFTID, apft.`REMARKS` as  APFT_REMARKS
, ac.`STATUS` as  SUCCESS_REDO ,ac.ID as CLIACKID, ac.`REMARKS` as  SR_REMARKS 
from api_download ad 
INNER join job j on j.BOOK_ID = ad.BOOK_ID 
LEFT join `job_info` as `ji` on `ji`.`JOB_ID` = `j`.`JOB_ID` 
LEFT join `user` as `u` on `j`.`PM` = `u`.`USER_ID` 
left JOIN api_meta_extractor ame	on ame.JOB_ID = j.JOB_ID and ame.ROUND = ad.ROUND and ame.ID IN ( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND process_type =1  order by ame2.ID desc )
left join api_file_upload afu on afu.JOB_ID = j.JOB_ID and afu.ROUND = ad.Round and afu.ID IN ( select max(afu2.ID) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND process_type = 1 order by afu2.ID desc )
left join api_client_acknowledgement ac on ac.JOB_ID = j.Job_Id and ac.ROUND = ad.ROUND and ac.ID IN ( select max( ac2.ID ) from api_client_acknowledgement ac2 where ac2.JOB_ID = ac.JOB_ID 
AND ac2.ROUND = ac.ROUND and ac2.PROCESS_TYPE_DIFF=1 order by ac2.ID desc)
left join api_production_file_transfer apft on apft.ROUND = ad.Round and apft.JOB_ID = j.JOB_ID and apft.ID IN ( 
            select max(apft2.ID) from api_production_file_transfer apft2 where apft2.ROUND = apft.ROUND AND apft2.JOB_ID = ad.JOB_ID AND PROCESS_NAME = "PRODUCTION_CHANGE" order by apft2.ID desc )
WHERE ad.ROUND IN ( 119 )
AND ad.is_completed = 1 and ad.is_active = 1
GROUP BY ad.book_id,ad.ROUND,j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM,ji.AM,ji.AM_NAME order by ad.CREATED_DATE DESC';
       
    $jobDetails     =       DB::select( $query_stmt );
    return $jobDetails;   
        
    }
    
    public static function getLateCorrectionDownload( $round ){
        
        $query_stmt         =   "SELECT j.JOB_ID,ad.BOOK_ID , acd.ROUND AS ROUND_ID , acd.ROUND AS ROUND_ID ,
                                CASE acd.ROUND
                                WHEN 116 THEN 'S200'
                                WHEN 118 THEN 'S300' 
                                WHEN 119 THEN 'S600'
                                WHEN 114 then 'S50'
                                WHEN 104 then 'S5'
                                ELSE 'S5' END AS ROUND_NAME,ad.is_active as ACTIVE, acd.STATUS as CD_STATUS, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,";
        
        $query_stmt         .=      'ji.AUTHOR_NAME , ji.EDITOR_NAME , j.CREATED_DATE as receivedDate , ji.ISSN_PRINT ,ji.ISSN_ONLINE , concat(u.FIRST_NAME," ",u.LAST_NAME) AS PMname,
 j.PM , ji.AM , ji.AM_NAME,tlmd.METADATA_ID,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,tlmd.FIGURE_COUNT,ji.STAGE_DEADLINES_COLLECTION as deadline,ji.PLATFORM_TYPE,j.JOB_TYPE, ame.`STATUS` as  JOB_SHEET_UPDATE, ame.`REMARKS` as  UPDATE_REMARKS
, afu.`STATUS` as  JOB_SHEET_UPLOAD, afu.`REMARKS` as  UPLOAD_REMARKS
,apft.`STATUS` as  APFT_SUCCESS_REDO ,apft.ID as APFTID, apft.`REMARKS` as  APFT_REMARKS
, ac.`STATUS` as  SUCCESS_REDO ,ac.ID as CLIACKID, ac.`REMARKS` as  SR_REMARKS 
from 
api_correction_download acd 
INNER JOIN api_download ad on acd.METADATA_ID = ad.METADATA_ID 
INNER join job j on j.BOOK_ID = ad.BOOK_ID 
INNER JOIN task_level_metadata tlmd ON acd.METADATA_ID = tlmd.METADATA_ID
LEFT join `job_info` as `ji` on `ji`.`JOB_ID` = `j`.`JOB_ID` 
LEFT join `user` as `u` on `j`.`PM` = `u`.`USER_ID` 
left JOIN api_meta_extractor ame	on ame.JOB_ID = j.JOB_ID and ame.ROUND = acd.ROUND and ame.ID IN ( select max( ame2.ID ) from api_meta_extractor ame2 where ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND process_type =5  order by ame2.ID desc )
left join api_file_upload afu on afu.JOB_ID = j.JOB_ID and afu.ROUND = acd.Round and afu.ID IN ( select max(afu2.ID) from api_file_upload afu2 where afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND process_type = 6 order by afu2.ID desc )
left join api_client_acknowledgement ac on ac.JOB_ID = j.Job_Id and ac.ROUND = acd.ROUND and ac.ID IN ( select max( ac2.ID ) from api_client_acknowledgement ac2 where ac2.JOB_ID = ac.JOB_ID 
AND ac2.ROUND = ac.ROUND and ac2.PROCESS_TYPE_DIFF=6 order by ac2.ID desc)
left join api_production_file_transfer apft on apft.ROUND = acd.Round and apft.METADATA_ID = acd.METADATA_ID and apft.ID IN ( 
            select max(apft2.ID) from api_production_file_transfer apft2 where apft2.ROUND = apft.ROUND AND apft2.METADATA_ID = ad.METADATA_ID AND PROCESS_NAME = "JOBSHEET_DOWNLOAD" order by apft2.ID desc )
WHERE ad.ROUND = 118 and acd.status = 4
AND ad.is_completed = 1 and ad.is_active = 1
GROUP BY ad.book_id,ad.ROUND,j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM,ji.AM,ji.AM_NAME order by ad.CREATED_DATE DESC';
        
        $jobDetails     =       DB::select( $query_stmt );
        return $jobDetails;   
    
    }
    
    public static function getChapterlevelassigned( $roundid = 116 ){
            
         $query_stmt     =   "SELECT j.JOB_ID,ad.BOOK_ID,ad.METADATA_ID, ad.ROUND AS ROUND_ID, 
            CASE ad.ROUND 
            WHEN 116 THEN 'S200' 
            WHEN 118 THEN 'S300' 
            WHEN 119 THEN 'S600' 
            ELSE 'S200' END AS ROUND_NAME,ad.is_active AS ACTIVE,
            j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,IF(jrm.RECEIVED_DATE is not null,jrm.RECEIVED_DATE,j.CREATED_DATE) as receivedDate, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname, IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,tlmd.FIGURE_COUNT,metainfo.JOBSHEET_LESS,metainfo.PRODUCTION_SYSTEM,
            ame.`STATUS` AS JOB_SHEET_UPDATE, ame.`REMARKS` AS UPDATE_REMARKS,ame.START_TIME AS META_START_TIME, TIMESTAMPDIFF(MINUTE, ame.START_TIME, NOW()) AS metaMinutes,
            afu.`STATUS` AS JOB_SHEET_UPLOAD, afu.`REMARKS` AS UPLOAD_REMARKS,afu.START_TIME AS UPLOAD_START_TIME, TIMESTAMPDIFF(MINUTE, afu.START_TIME, NOW()) AS uploadMinutes,
            ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID, ac.`REMARKS` AS SR_REMARKS,ac.START_TIME AS CLIENT_START_TIME, TIMESTAMPDIFF(MINUTE, ac.START_TIME, NOW()) AS clientMinutes,
            apft.`STATUS` as  APFT_SUCCESS_REDO ,apft.ID as APFTID, apft.`REMARKS` as  APFT_REMARKS,
            tapmeta.`REMARKS` AS TAPS_REMARKS,tapmeta.`STATUS` AS TAPS_STATUS, TIMESTAMPDIFF(MINUTE, tapmeta.START_TIME, NOW()) AS tapsMinutes, IFNULL(tapmeta.`END_TIME`,'') AS TAPS_END_TIME, 1 AS SHEET_FLAG,j.JOB_TYPE,js1.STAGE,js1.`STATUS` AS STATUS_COMPLETE
            FROM api_download ad
            INNER JOIN job j ON j.BOOK_ID = ad.BOOK_ID
            INNER JOIN task_level_metadata tlmd ON ad.METADATA_ID = tlmd.METADATA_ID
            INNER JOIN metadata_info metainfo ON metainfo.METADATA_ID = tlmd.METADATA_ID
            LEFT JOIN job_round_milestone as jrm on jrm.JOB_ID = j.JOB_ID and jrm.ID IN (select MIN(jm.ID) from job_round_milestone as jm 
            where jm.JOB_ID = jrm.JOB_ID and jm.ROUND_ID = ad.ROUND  and tlmd.METADATA_ID = jm.METADATA_ID
            order by id asc)
            LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
            LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID`
            LEFT JOIN api_meta_extractor ame ON ame.METADATA_ID = ad.METADATA_ID AND ame.ROUND = ad.Round AND ame.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_meta_extractor ame2
            WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND AND process_type = 1
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_file_upload afu ON afu.METADATA_ID = ad.METADATA_ID AND afu.ROUND = ad.Round AND afu.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_file_upload afu2
            WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2.ROUND = afu.ROUND AND process_type = 1
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac ON ac.METADATA_ID = ad.METADATA_ID AND ac.ROUND = ad.Round AND ac.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 1
            ORDER BY ac2.ID DESC)
            LEFT JOIN taps_metadata tapmeta ON tapmeta.METADATA_ID = ad.METADATA_ID AND tapmeta.ROUND = ad.Round AND tapmeta.ID IN (
            SELECT MAX(tapmeta2.ID)
            FROM taps_metadata tapmeta2
            WHERE tapmeta2.METADATA_ID = tapmeta.METADATA_ID AND tapmeta2.ROUND = tapmeta.ROUND
            ORDER BY tapmeta2.ID DESC)
            left join api_production_file_transfer apft on apft.ROUND = ad.Round and apft.METADATA_ID = ad.METADATA_ID and apft.ID IN ( 
            select max(apft2.ID) from api_production_file_transfer apft2 where apft2.ROUND = apft.ROUND AND apft2.METADATA_ID = ad.METADATA_ID AND (PROCESS_NAME = 'JOBSHEET_DOWNLOAD' or PROCESS_NAME = 'CHAPTER_FILE_DOWNLOAD') order by apft2.ID desc )
            LEFT JOIN job_time_sheet js1 ON js1.METADATA_ID = ad.METADATA_ID AND js1.ROUND_ID IN(104,116) AND js1.STAGE = ".Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION')." AND js1.JOB_TIME_SHEET_ID IN (
            SELECT MAX(js2.JOB_TIME_SHEET_ID)
            FROM job_time_sheet js2
            WHERE js2.METADATA_ID = js1.METADATA_ID AND js2.ROUND_ID = js1.ROUND_ID AND js2.STAGE = ".Config::get('constants.STAGE_COLLEECTION.S5_ART_CREATION')." AND js2.STATUS =	".Config::get('constants.STATUS_ENUM.COMPLETED')."
            ORDER BY js2.JOB_TIME_SHEET_ID DESC)
            WHERE ad.ROUND = $roundid AND ad.is_completed = 1 AND ad.is_active = 1 
            GROUP BY ad.METADATA_ID,ad.Round, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM, ji.AM, ji.AM_NAME ORDER BY ad.CREATED_DATE DESC";
           
                
            $jobDetails         =       DB::select( $query_stmt );  
            
        return $jobDetails;   
    }
    
    public static function getChapterlevelCorrectionDownload650( $roundid = 120 , $status = 2 , $userid = null , $bookid = null ){
        
        $query_stmt     =   " SELECT j.JOB_ID,j.BOOK_ID,ad.METADATA_ID, 120 AS ROUND_ID, CASE ad.ROUND_ID WHEN 116 THEN 'S200' WHEN 118 THEN 'S650' WHEN 119 THEN 'S600' WHEN 120 THEN 'S650' ELSE 'S200' END AS ROUND_NAME,
tlmd.EPROOFING_SYSTEM, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname,
 IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,
 tlmd.FIGURE_COUNT,metainfo.PRODUCTION_SYSTEM, ad.STATUS AS CD_STATUS, ame.`STATUS` AS JOB_SHEET_UPDATE, replace(replace(replace(ame.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS,ame.START_TIME AS META_START_TIME, TIMESTAMPDIFF(MINUTE, ame.START_TIME, NOW()) AS metaMinutes,
            afu.`STATUS` AS JOB_SHEET_UPLOAD,replace(replace(replace( afu.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPLOAD_REMARKS,afu.START_TIME AS UPLOAD_START_TIME, TIMESTAMPDIFF(MINUTE, afu.START_TIME, NOW()) AS uploadMinutes,
            ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID,replace(replace(replace(  ac.`REMARKS` ,'\\r','<br>'),'\\n','<br>'),'<br><br>','<br>') AS SR_REMARKS,ac.START_TIME AS CLIENT_START_TIME, TIMESTAMPDIFF(MINUTE, ac.START_TIME, NOW()) AS clientMinutes,
            
			ame_2.`STATUS` AS JOB_SHEET_UPDATE2,replace(replace(replace(ame_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPDATE_REMARKS2 ,ame_2.START_TIME AS META_START_TIME2, TIMESTAMPDIFF(MINUTE, ame_2.START_TIME, NOW()) AS metaMinutes2,
            afu_2.`STATUS` AS JOB_SHEET_UPLOAD2,replace(replace(replace( afu_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS2,afu_2.START_TIME AS UPLOAD_START_TIME2, TIMESTAMPDIFF(MINUTE, afu_2.START_TIME, NOW()) AS uploadMinutes2,
            ac_2.`STATUS` AS SUCCESS_REDO2,ac_2.ID as CLIACKID2,replace(replace(replace( ac_2.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS2,ac_2.START_TIME AS CLIENT_START_TIME2, TIMESTAMPDIFF(MINUTE, ac_2.START_TIME, NOW()) AS clientMinutes2,
            
			ame_3.`STATUS` AS JOB_SHEET_UPDATE3, replace(replace(replace( ame_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS3,ame_3.START_TIME AS META_START_TIME3, TIMESTAMPDIFF(MINUTE, ame_3.START_TIME, NOW()) AS metaMinutes3,
            afu_3.`STATUS` AS JOB_SHEET_UPLOAD3,replace(replace(replace(afu_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS3,afu_3.START_TIME AS UPLOAD_START_TIME3, TIMESTAMPDIFF(MINUTE, afu_3.START_TIME, NOW()) AS uploadMinutes3,
            ac_3.`STATUS` AS SUCCESS_REDO3,ac_3.ID as CLIACKID3, replace(replace(replace(ac_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS3,ac_3.START_TIME AS CLIENT_START_TIME3, TIMESTAMPDIFF(MINUTE, ac_3.START_TIME, NOW()) AS clientMinutes3,
            1 AS SHEET_FLAG,j.JOB_TYPE FROM api_correction_download_mono ad
INNER JOIN job j ON j.JOB_ID = ad.JOB_ID
INNER JOIN task_level_metadata tlmd ON ad.METADATA_ID = tlmd.METADATA_ID
INNER JOIN metadata_info metainfo ON metainfo.METADATA_ID = tlmd.METADATA_ID
LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID` AND j.PM = u.USER_ID
LEFT JOIN api_correction_download acd ON acd. ROUND = ad.ROUND_ID AND acd.ID IN (
SELECT MAX( acd2.ID )
FROM api_correction_download acd2
WHERE acd.METADATA_ID = acd2.METADATA_ID AND acd2.ROUND = acd.ROUND
ORDER BY acd2.ID )
LEFT JOIN api_eproof_packaging ame ON ame.METADATA_ID = ad.METADATA_ID AND ame.ROUND = ad.ROUND_ID AND ame.ID IN (
SELECT MAX(ame2.ID)
FROM api_eproof_packaging ame2
WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND AND ame2.IS_ACTIVE = 1
ORDER BY ame2.ID DESC )
LEFT JOIN api_ftp_upload afu ON afu.METADATA_ID = ad.METADATA_ID AND afu. ROUND = ad. ROUND_ID AND afu.ID IN (
SELECT MAX(afu2.ID)
FROM api_ftp_upload afu2
WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2.ROUND = afu. ROUND AND afu2.PROCESS_TYPE = 2 AND afu2.IS_ACTIVE = 1
ORDER BY afu2.ID DESC)
LEFT JOIN api_client_acknowledgement ac ON ac.METADATA_ID = ad.METADATA_ID AND ac. ROUND = ad. ROUND_ID AND ac.ID IN (
SELECT MAX(ac2.ID)
FROM api_client_acknowledgement ac2
WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 5 AND ac2.IS_ACTIVE = 1
ORDER BY ac2.ID DESC)
LEFT JOIN api_meta_extractor ame_2 ON ame_2.METADATA_ID = ad.METADATA_ID AND ame_2. ROUND = ad. ROUND_ID AND ame_2.ID IN (
SELECT MAX(ame2.ID)
FROM api_meta_extractor ame2
WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND AND ame2.PROCESS_TYPE = 2
ORDER BY ame2.ID DESC)
LEFT JOIN api_file_upload afu_2 ON afu_2.METADATA_ID = ad.METADATA_ID AND afu_2. ROUND = ad. ROUND_ID AND afu_2.ID IN (
SELECT MAX(afu2.ID)
FROM api_file_upload afu2
WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2. ROUND = afu. ROUND AND afu2.PROCESS_TYPE = 2
ORDER BY afu2.ID DESC)
LEFT JOIN api_client_acknowledgement ac_2 ON ac_2.METADATA_ID = ad.METADATA_ID AND ac_2. ROUND = ad. ROUND_ID AND ac_2.ID IN (
SELECT MAX(ac2.ID)
FROM api_client_acknowledgement ac2
WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2. ROUND = ac. ROUND AND ac2.PROCESS_TYPE_DIFF = 2
ORDER BY ac2.ID DESC)
LEFT JOIN api_meta_extractor ame_3 ON ame_3.METADATA_ID = ad.METADATA_ID AND ame_3. ROUND = ad. ROUND_ID AND ame_3.ID IN (
SELECT MAX(ame2.ID)
FROM api_meta_extractor ame2
WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2. ROUND = ame. ROUND AND ame2.PROCESS_TYPE = 5
ORDER BY ame2.ID DESC)
LEFT JOIN api_file_upload afu_3 ON afu_3.METADATA_ID = ad.METADATA_ID AND afu_3. ROUND = ad. ROUND_ID AND afu_3.ID IN (
SELECT MAX(afu2.ID)
FROM api_file_upload afu2
WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2. ROUND = afu. ROUND AND afu2.PROCESS_TYPE = 6
ORDER BY afu2.ID DESC)
LEFT JOIN api_client_acknowledgement ac_3 ON ac_3.METADATA_ID = ad.METADATA_ID AND ac_3. ROUND = ad. ROUND_ID AND ac_3.ID IN (
SELECT MAX(ac2.ID)
FROM api_client_acknowledgement ac2
WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2. ROUND = ac. ROUND AND ac2.PROCESS_TYPE_DIFF = 6
ORDER BY ac2.ID DESC)
WHERE ad. ROUND_ID IN ( 120 ) ";
    
    if( !is_null( $bookid ) ){
        $query_stmt    .=  " AND and j.BOOK_ID like '%$bookid%' GROUP BY ad.METADATA_ID ,ad.ROUND_ID ORDER BY ad.ID DESC ";
    }else{
        $query_stmt    .=  " AND acd. STATUS = 2 GROUP BY ad.METADATA_ID ,ad.ROUND_ID ORDER BY ad.ID DESC LIMIT 500 ";
    }
          
    $jobDetails         =       DB::select( $query_stmt );  
            
    return $jobDetails;   
        
}
    
    public static function getChapterlevelassignedForEproof( $roundid = 118 , $status = 2 ){
            
         $query_stmt     =   " SELECT j.JOB_ID,ad.BOOK_ID,ad.METADATA_ID, ad.ROUND AS ROUND_ID, 
            CASE ad.ROUND 
            WHEN 116 THEN 'S200' 
            WHEN 118 THEN 'S300' 
            WHEN 119 THEN 'S600' 
            WHEN 120 THEN 'S650' 
            ELSE 'S200' END AS ROUND_NAME,ad.is_active AS ACTIVE,tlmd.EPROOFING_SYSTEM,
            j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ad.CREATED_DATE AS receivedDate, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname, IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME,tlmd.CHAPTER_NO,tlmd.CHAPTER_NAME AS CHAPTER_TITLE,tlmd.FIGURE_COUNT,metainfo.PRODUCTION_SYSTEM,
            acd.STATUS as CD_STATUS ,
			ame.`STATUS` AS JOB_SHEET_UPDATE, replace(replace(replace(ame.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS,ame.START_TIME AS META_START_TIME, TIMESTAMPDIFF(MINUTE, ame.START_TIME, NOW()) AS metaMinutes,
            afu.`STATUS` AS JOB_SHEET_UPLOAD,replace(replace(replace( afu.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPLOAD_REMARKS,afu.START_TIME AS UPLOAD_START_TIME, TIMESTAMPDIFF(MINUTE, afu.START_TIME, NOW()) AS uploadMinutes,
            ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID,replace(replace(replace(  ac.`REMARKS` ,'\\r','<br>'),'\\n','<br>'),'<br><br>','<br>') AS SR_REMARKS,ac.START_TIME AS CLIENT_START_TIME, TIMESTAMPDIFF(MINUTE, ac.START_TIME, NOW()) AS clientMinutes,
            
			ame_2.`STATUS` AS JOB_SHEET_UPDATE2,replace(replace(replace(ame_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPDATE_REMARKS2 ,ame_2.START_TIME AS META_START_TIME2, TIMESTAMPDIFF(MINUTE, ame_2.START_TIME, NOW()) AS metaMinutes2,
            afu_2.`STATUS` AS JOB_SHEET_UPLOAD2,replace(replace(replace( afu_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS2,afu_2.START_TIME AS UPLOAD_START_TIME2, TIMESTAMPDIFF(MINUTE, afu_2.START_TIME, NOW()) AS uploadMinutes2,
            ac_2.`STATUS` AS SUCCESS_REDO2,ac_2.ID as CLIACKID2,replace(replace(replace( ac_2.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS2,ac_2.START_TIME AS CLIENT_START_TIME2, TIMESTAMPDIFF(MINUTE, ac_2.START_TIME, NOW()) AS clientMinutes2,
            
			ame_3.`STATUS` AS JOB_SHEET_UPDATE3, replace(replace(replace( ame_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS3,ame_3.START_TIME AS META_START_TIME3, TIMESTAMPDIFF(MINUTE, ame_3.START_TIME, NOW()) AS metaMinutes3,
            afu_3.`STATUS` AS JOB_SHEET_UPLOAD3,replace(replace(replace(afu_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS3,afu_3.START_TIME AS UPLOAD_START_TIME3, TIMESTAMPDIFF(MINUTE, afu_3.START_TIME, NOW()) AS uploadMinutes3,
            ac_3.`STATUS` AS SUCCESS_REDO3,ac_3.ID as CLIACKID3, replace(replace(replace(ac_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS3,ac_3.START_TIME AS CLIENT_START_TIME3, TIMESTAMPDIFF(MINUTE, ac_3.START_TIME, NOW()) AS clientMinutes3,
            1 AS SHEET_FLAG,j.JOB_TYPE,apft.`STATUS` as  APFT_SUCCESS_REDO ,apft.ID as APFTID, apft.`REMARKS` as  APFT_REMARKS
            FROM api_download ad
            INNER JOIN job j ON j.BOOK_ID = ad.BOOK_ID
            INNER JOIN task_level_metadata tlmd ON ad.METADATA_ID = tlmd.METADATA_ID
            INNER JOIN metadata_info metainfo ON metainfo.METADATA_ID = tlmd.METADATA_ID
            LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
            LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID`		
            
            LEFT JOIN api_correction_download acd ON acd.METADATA_ID = ad.METADATA_ID AND acd.ROUND = ad.ROUND AND acd.ID IN ( 
            SELECT MAX( acd2.ID) FROM api_correction_download acd2 WHERE acd.METADATA_ID = acd2.METADATA_ID AND acd2.ROUND = acd.ROUND ORDER BY acd2.ID ) 
            
            LEFT JOIN api_eproof_packaging ame ON ame.METADATA_ID = ad.METADATA_ID AND ame.ROUND = ad.Round  AND ame.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_eproof_packaging ame2
            WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND AND ame2.IS_ACTIVE = 1
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_ftp_upload afu ON afu.METADATA_ID = ad.METADATA_ID AND afu.ROUND = ad.Round AND afu.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_ftp_upload afu2
            WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 2 AND afu2.IS_ACTIVE = 1
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac ON ac.METADATA_ID = ad.METADATA_ID AND ac.ROUND = ad.Round AND ac.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 5 AND ac2.IS_ACTIVE = 1
            ORDER BY ac2.ID DESC)
			
            LEFT JOIN api_meta_extractor ame_2 ON ame_2.METADATA_ID = ad.METADATA_ID AND ame_2.ROUND = ad.Round  AND ame_2.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_meta_extractor ame2
            WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND and ame2.PROCESS_TYPE = 2
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_file_upload afu_2 ON afu_2.METADATA_ID = ad.METADATA_ID AND afu_2.ROUND = ad.Round AND afu_2.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_file_upload afu2
            WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 2
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac_2 ON ac_2.METADATA_ID = ad.METADATA_ID AND ac_2.ROUND = ad.Round AND ac_2.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 2
            ORDER BY ac2.ID DESC)
			
            LEFT JOIN api_meta_extractor ame_3 ON ame_3.METADATA_ID = ad.METADATA_ID AND ame_3.ROUND = ad.Round  AND ame_3.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_meta_extractor ame2
            WHERE ame2.METADATA_ID = ame.METADATA_ID AND ame2.ROUND = ame.ROUND and ame2.PROCESS_TYPE = 5
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_file_upload afu_3 ON afu_3.METADATA_ID = ad.METADATA_ID AND afu_3.ROUND = ad.Round AND afu_3.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_file_upload afu2
            WHERE afu2.METADATA_ID = afu.METADATA_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 6
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac_3 ON ac_3.METADATA_ID = ad.METADATA_ID AND ac_3.ROUND = ad.Round AND ac_3.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.METADATA_ID = ac.METADATA_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 6
            ORDER BY ac2.ID DESC)
            
            left join api_production_file_transfer apft on apft.ROUND = ad.Round and apft.METADATA_ID = ad.METADATA_ID and apft.ID IN ( 
            select max(apft2.ID) from api_production_file_transfer apft2 where apft2.ROUND = apft.ROUND AND apft2.METADATA_ID = ad.METADATA_ID order by apft2.ID desc )
			
            WHERE ad.ROUND = $roundid AND ad.IS_COMPLETED = 1 AND ad.IS_ACTIVE = 1 and metainfo.FM_ARTICLE_BM = 2
            GROUP BY ad.METADATA_ID,ad.Round, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM, ji.AM, ji.AM_NAME "
                 . " ORDER BY ad.CREATED_DATE DESC ";
          
            $jobDetails         =       DB::select( $query_stmt );  
            
        return $jobDetails;   
    } 
    
    public static function getBooklevelassignedForEproof( $roundid = 120 ){
            
        $query_stmt     =   " SELECT j.JOB_ID,ad.BOOK_ID,ad.METADATA_ID, ad.ROUND AS ROUND_ID, 
            CASE ad.ROUND 
            WHEN 116 THEN 'S200' 
            WHEN 118 THEN 'S300' 
            WHEN 119 THEN 'S600' 
            WHEN 120 THEN 'S650' 
            ELSE 'S200' END AS ROUND_NAME,ad.is_active AS ACTIVE,
            j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ad.CREATED_DATE AS receivedDate, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname, IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME,j.BOOK_ID as CHAPTER_NO,j.JOB_TITLE AS CHAPTER_TITLE,
            IF( acd.STATUS >= 0 , 2 , 0 ) as CD_STATUS,
			ame.`STATUS` AS JOB_SHEET_UPDATE, replace(replace(replace(ame.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS,ame.START_TIME AS META_START_TIME, TIMESTAMPDIFF(MINUTE, ame.START_TIME, NOW()) AS metaMinutes,
            afu.`STATUS` AS JOB_SHEET_UPLOAD,replace(replace(replace( afu.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPLOAD_REMARKS,afu.START_TIME AS UPLOAD_START_TIME, TIMESTAMPDIFF(MINUTE, afu.START_TIME, NOW()) AS uploadMinutes,
            ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID,replace(replace(replace(  ac.`REMARKS` ,'\\r','<br>'),'\\n','<br>'),'<br><br>','<br>') AS SR_REMARKS,ac.START_TIME AS CLIENT_START_TIME, TIMESTAMPDIFF(MINUTE, ac.START_TIME, NOW()) AS clientMinutes,
            
			ame_2.`STATUS` AS JOB_SHEET_UPDATE2,replace(replace(replace(ame_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPDATE_REMARKS2 ,ame_2.START_TIME AS META_START_TIME2, TIMESTAMPDIFF(MINUTE, ame_2.START_TIME, NOW()) AS metaMinutes2,
            afu_2.`STATUS` AS JOB_SHEET_UPLOAD2,replace(replace(replace( afu_2.`REMARKS` ,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS2,afu_2.START_TIME AS UPLOAD_START_TIME2, TIMESTAMPDIFF(MINUTE, afu_2.START_TIME, NOW()) AS uploadMinutes2,
            ac_2.`STATUS` AS SUCCESS_REDO2,ac_2.ID as CLIACKID2,replace(replace(replace( ac_2.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS2,ac_2.START_TIME AS CLIENT_START_TIME2, TIMESTAMPDIFF(MINUTE, ac_2.START_TIME, NOW()) AS clientMinutes2,
            
			ame_3.`STATUS` AS JOB_SHEET_UPDATE3, replace(replace(replace( ame_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>') AS UPDATE_REMARKS3,ame_3.START_TIME AS META_START_TIME3, TIMESTAMPDIFF(MINUTE, ame_3.START_TIME, NOW()) AS metaMinutes3,
            afu_3.`STATUS` AS JOB_SHEET_UPLOAD3,replace(replace(replace(afu_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS UPLOAD_REMARKS3,afu_3.START_TIME AS UPLOAD_START_TIME3, TIMESTAMPDIFF(MINUTE, afu_3.START_TIME, NOW()) AS uploadMinutes3,
            ac_3.`STATUS` AS SUCCESS_REDO3,ac_3.ID as CLIACKID3, replace(replace(replace(ac_3.`REMARKS`,'\\\\r','<br>'),'\\\\n','<br>'),'<br><br>','<br>')  AS SR_REMARKS3,ac_3.START_TIME AS CLIENT_START_TIME3, TIMESTAMPDIFF(MINUTE, ac_3.START_TIME, NOW()) AS clientMinutes3,
            1 AS SHEET_FLAG,j.JOB_TYPE
            FROM api_download ad
            INNER JOIN job j ON j.BOOK_ID = ad.BOOK_ID and j.JOB_ID =   ad.JOB_ID
            #INNER JOIN task_level_metadata tlmd ON ad.METADATA_ID = tlmd.METADATA_ID
            #INNER JOIN metadata_info metainfo ON metainfo.METADATA_ID = tlmd.METADATA_ID
            LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
            LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID`		
            
            LEFT JOIN api_correction_download_mono acd ON acd.JOB_ID = ad.JOB_ID AND acd.ROUND_ID = ad.ROUND AND acd.ID IN ( 
            SELECT MAX( acd2.ID) FROM api_correction_download_mono acd2 WHERE acd.JOB_ID = acd2.JOB_ID AND acd2.ROUND_ID = acd.ROUND_ID ORDER BY acd2.ID ) 
            
            LEFT JOIN api_eproof_packaging ame ON ame.JOB_ID = ad.JOB_ID AND ame.ROUND = ad.ROUND  AND ame.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_eproof_packaging ame2
            WHERE ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND AND ame2.IS_ACTIVE = 1
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_ftp_upload afu ON afu.JOB_ID = ad.JOB_ID AND afu.ROUND = ad.Round AND afu.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_ftp_upload afu2
            WHERE afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 2 AND afu2.IS_ACTIVE = 1
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac ON ac.JOB_ID = ad.JOB_ID AND ac.ROUND = ad.Round AND ac.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 8 AND ac2.IS_ACTIVE = 1
            ORDER BY ac2.ID DESC)
			
            LEFT JOIN api_meta_extractor ame_2 ON ame_2.JOB_ID = ad.JOB_ID AND ame_2.ROUND = ad.Round  AND ame_2.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_meta_extractor ame2
            WHERE ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND and ame2.PROCESS_TYPE = 2
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_file_upload afu_2 ON afu_2.JOB_ID = ad.JOB_ID AND afu_2.ROUND = ad.Round AND afu_2.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_file_upload afu2
            WHERE afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 2
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac_2 ON ac_2.JOB_ID = ad.JOB_ID AND ac_2.ROUND = ad.Round AND ac_2.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 2
            ORDER BY ac2.ID DESC)
			
            LEFT JOIN api_meta_extractor ame_3 ON ame_3.JOB_ID = ad.JOB_ID AND ame_3.ROUND = ad.Round  AND ame_3.ID IN (
            SELECT MAX(ame2.ID)
            FROM api_meta_extractor ame2
            WHERE ame2.JOB_ID = ame.JOB_ID AND ame2.ROUND = ame.ROUND and ame2.PROCESS_TYPE = 5
            ORDER BY ame2.ID DESC)
            LEFT JOIN api_file_upload afu_3 ON afu_3.JOB_ID = ad.JOB_ID AND afu_3.ROUND = ad.Round AND afu_3.ID IN (
            SELECT MAX(afu2.ID)
            FROM api_file_upload afu2
            WHERE afu2.JOB_ID = afu.JOB_ID AND afu2.ROUND = afu.ROUND AND afu2.PROCESS_TYPE = 6
            ORDER BY afu2.ID DESC)
            LEFT JOIN api_client_acknowledgement ac_3 ON ac_3.JOB_ID = ad.JOB_ID AND ac_3.ROUND = ad.Round AND ac_3.ID IN (
            SELECT MAX(ac2.ID)
            FROM api_client_acknowledgement ac2
            WHERE ac2.JOB_ID = ac.JOB_ID AND ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 6
            ORDER BY ac2.ID DESC)
			
            WHERE ad.ROUND = $roundid AND ad.IS_COMPLETED = 1 AND ad.IS_ACTIVE = 1 
            GROUP BY ad.METADATA_ID,ad.JOB_ID,ad.Round, j.JOB_TITLE,ji.LOCATION,ji.JOB_ASSIGNED_DATE,ji.ISSN_PRINT,j.PM, ji.AM, ji.AM_NAME "
                 . " ORDER BY ad.CREATED_DATE DESC ";
           
            $jobDetails         =       DB::select( $query_stmt );  
            
        return $jobDetails;   
    }
    
    public static function getJobreviseddetails($bookID =   null,$chapterID =   null,$roundID = null){
                        if(empty($bookID) && empty($roundID) && empty($chapterID)){            
                            $query_stmt     =   "SELECT count(jrm.ROUND_ID) as revisedcount,j.JOB_ID,ad.BOOK_ID,ad.METADATA_ID, ad.ROUND AS ROUND_ID, 
                                    CASE ad.ROUND 
                                    WHEN 104 THEN 'S5' 
                                    WHEN 114 THEN 'S50' 
                                    WHEN 116 THEN 'S200' 
                                    WHEN 118 THEN 'S300' 
                                    WHEN 119 THEN 'S600' 
                                    WHEN 120 THEN 'S650' 
                                    ELSE 'S5' END AS ROUND_NAME,ad.is_active AS ACTIVE,
                                    j.JOB_TITLE,pal.LOCATION_NAME AS LOCATION,ji.JOB_ASSIGNED_DATE,IF(jrm.RECEIVED_DATE is not null,jrm.RECEIVED_DATE,j.CREATED_DATE) as receivedDate, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname, IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME ,
                                    '--' as CHAPTER_NO, 
                                    ame.`STATUS` AS JOB_SHEET_UPDATE, ame.`REMARKS` AS UPDATE_REMARKS,
                                    afu.`STATUS` AS JOB_SHEET_UPLOAD, afu.`REMARKS` AS UPLOAD_REMARKS,
                                    ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID, ac.`REMARKS` AS SR_REMARKS,
                                    j.JOB_TYPE
                                    FROM api_download ad
                                    INNER JOIN job j ON j.BOOK_ID = ad.BOOK_ID 
                                    LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
                                    INNER JOIN job_round_milestone as jrm on jrm.JOB_ID = j.JOB_ID and jrm.ROUND_ID IN (".Config::get('constants.ROUND_ID.S5').",".Config::get('constants.ROUND_ID.S50').",".Config::get('constants.ROUND_ID.S650').")
                                    LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID`
                                    LEFT JOIN `production_area_location` AS `pal` ON pal.ID = ji.LOCATION
                                    LEFT JOIN api_meta_extractor ame ON ame.ROUND = ad.Round AND ame.ID IN (
                                    SELECT MAX(ame2.ID)
                                    FROM api_meta_extractor ame2
                                    WHERE ame2.ROUND = ame.ROUND AND process_type = 6
                                    ORDER BY ame2.ID DESC)
                                    LEFT JOIN api_file_upload afu ON afu.ROUND = ad.Round AND afu.ID IN (
                                    SELECT MAX(afu2.ID)
                                    FROM api_file_upload afu2
                                    WHERE afu2.ROUND = afu.ROUND AND process_type = 7
                                    ORDER BY afu2.ID DESC)
                                    LEFT JOIN api_client_acknowledgement ac ON ac.ROUND = ad.Round AND ac.ID IN (
                                    SELECT MAX(ac2.ID)
                                    FROM api_client_acknowledgement ac2
                                    WHERE ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 7
                                    ORDER BY ac2.ID DESC)
                                    WHERE ad.is_completed = 1 AND ad.is_active = 1  and ad.ROUND IN (".Config::get('constants.ROUND_ID.S5').",".Config::get('constants.ROUND_ID.S50').",".Config::get('constants.ROUND_ID.S650').") GROUP BY ad.ROUND,ad.BOOK_ID having revisedcount >= 2 ";
									
                        }else{
							
                            $query_stmt     =   "SELECT count(jrm.ROUND_ID) as revisedcount,j.JOB_ID,ad.BOOK_ID,ad.METADATA_ID, ad.ROUND AS ROUND_ID, 
                                    CASE ad.ROUND 
                                    WHEN 104 THEN 'S5' 
                                    WHEN 114 THEN 'S50' 
                                    WHEN 116 THEN 'S200' 
                                    WHEN 118 THEN 'S300' 
                                    WHEN 119 THEN 'S600' 
                                    WHEN 120 THEN 'S650' 
                                    ELSE 'S5' END AS ROUND_NAME,ad.is_active AS ACTIVE,
                                    j.JOB_TITLE,pal.LOCATION_NAME AS LOCATION,ji.JOB_ASSIGNED_DATE,IF(jrm.RECEIVED_DATE is not null,jrm.RECEIVED_DATE,j.CREATED_DATE) as receivedDate, ji.ISSN_PRINT, IFNULL(CONCAT(u.FIRST_NAME,'',u.LAST_NAME),'') AS PMname, IFNULL(j.PM,'') AS PM, CASE ji.AM WHEN 0 THEN '' ELSE IFNULL(ji.AM,'') END AS AM, IFNULL(ji.AM_NAME,'') AS AM_NAME ,";
                                    
									if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt     .=  "tlmd.CHAPTER_NO,";
                                    }
                                    else if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S5') && $roundID <=   Config::get('constants.ROUND_ID.S50') || $roundID   ==  Config::get('constants.ROUND_ID.S650'))){ 
                                        $query_stmt     .=  " '--' as CHAPTER_NO ,";
                                    }else{
                                        $query_stmt     .=  " '--' as CHAPTER_NO ,";
                                    }
                                        
                                    $query_stmt     .=  " 
                                    ame.`STATUS` AS JOB_SHEET_UPDATE, ame.`REMARKS` AS UPDATE_REMARKS,
                                    afu.`STATUS` AS JOB_SHEET_UPLOAD, afu.`REMARKS` AS UPLOAD_REMARKS,
                                    ac.`STATUS` AS SUCCESS_REDO,ac.ID as CLIACKID, ac.`REMARKS` AS SR_REMARKS,
                                    j.JOB_TYPE
                                    FROM api_download ad
                                    INNER JOIN job j ON j.BOOK_ID = ad.BOOK_ID ";
                                    
                                    if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt     .=  " INNER JOIN task_level_metadata tlmd ON ad.METADATA_ID = tlmd.METADATA_ID
                                        INNER JOIN metadata_info metainfo ON metainfo.METADATA_ID = tlmd.METADATA_ID ";
                                    }
									
                                    if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt         .=  " INNER JOIN job_round_milestone as jrm on jrm.METADATA_ID = ad.METADATA_ID and j.JOB_ID = jrm.JOB_ID and jrm.ROUND_ID = '".$roundID."' ";
                                    }else{
                                        $query_stmt         .=  " INNER JOIN job_round_milestone as jrm on jrm.JOB_ID = j.JOB_ID and jrm.ROUND_ID IN (".Config::get('constants.ROUND_ID.S5').",".Config::get('constants.ROUND_ID.S50').",".Config::get('constants.ROUND_ID.S650').") ";
                                    }
                                    
                                    $query_stmt         .=  " LEFT JOIN `job_info` AS `ji` ON `ji`.`JOB_ID` = `j`.`JOB_ID`
                                    LEFT JOIN `user` AS `u` ON `j`.`PM` = `u`.`USER_ID`
                                    LEFT JOIN `production_area_location` AS `pal` ON pal.ID = ji.LOCATION ";
                                    
                                    if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt     .=  " inner JOIN api_meta_extractor ame ON ame.METADATA_ID = ad.METADATA_ID 
                                                                inner join (select max(ame2.ID) as maxameid from api_meta_extractor ame2 where ame2.process_type = 6 and ame2.ROUND = '".$roundID."' GROUP BY ame2.METADATA_ID
                                                                ) as ametab on ame.ID = ametab.maxameid
                                                ";
                                    }else{
                                        $query_stmt     .=  " LEFT JOIN api_meta_extractor ame ON ame.ROUND = ad.Round AND ame.ID IN (
                                                SELECT MAX(ame2.ID)
                                                FROM api_meta_extractor ame2
                                                WHERE ame2.ROUND = ame.ROUND AND process_type = 6
                                                ORDER BY ame2.ID DESC)
                                                ";
                                    }
                                    
                                    if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt     .=  " INNER JOIN api_file_upload afu ON afu.METADATA_ID = ad.METADATA_ID 
                                            inner join (select max(afu2.ID) as maxafuid from api_file_upload afu2 where afu2.process_type = 7 and afu2.ROUND = '".$roundID."' GROUP BY afu2.METADATA_ID
                                                                ) as afutab on afu.ID = afutab.maxafuid ";
                                    }
                                    else{
                                        $query_stmt     .=  " LEFT JOIN api_file_upload afu ON afu.ROUND = ad.Round AND afu.ID IN (
                                            SELECT MAX(afu2.ID)
                                            FROM api_file_upload afu2 WHERE afu2.ROUND = afu.ROUND AND process_type = 7 ORDER BY afu2.ID DESC) ";
                                    }
                                    
                                    if(!empty($roundID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){ 
                                        $query_stmt     .=  " INNER JOIN api_client_acknowledgement ac ON ac.METADATA_ID = ad.METADATA_ID 
                                            inner join (select max(ack2.ID) as maxackid from api_client_acknowledgement ack2 where ack2.PROCESS_TYPE_DIFF = 7 and ack2.ROUND = '".$roundID."' GROUP BY ack2.METADATA_ID
                                                                ) as acktab on ac.ID = acktab.maxackid ";
                                    }else{
                                        $query_stmt     .=  " LEFT JOIN api_client_acknowledgement ac ON ac.ROUND = ad.Round AND ac.ID IN (
                                                SELECT MAX(ac2.ID) FROM api_client_acknowledgement ac2 WHERE ac2.ROUND = ac.ROUND AND ac2.PROCESS_TYPE_DIFF = 7 ORDER BY ac2.ID DESC) ";
                                    }
                                    
                                    $query_stmt     .=      " WHERE ad.is_completed = 1 AND ad.is_active = 1 ";
                                    
                                    if(!empty($bookID) && empty($roundID) && empty($chapterID)){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.BOOK_ID = '".$bookID."' and ad.ROUND IN (".Config::get('constants.ROUND_ID.S5').",".Config::get('constants.ROUND_ID.S50').",".Config::get('constants.ROUND_ID.S650').") GROUP BY ad.ROUND,ad.BOOK_ID having revisedcount >= 2 ";
                                    }
                                    
                                    if(empty($bookID) && !empty($roundID) && empty($chapterID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.ROUND = '".$roundID."' GROUP BY ad.BOOK_ID ,ad.ROUND,ad.METADATA_ID ";
                                    }
                                    
                                    if(empty($bookID) && !empty($roundID) && empty($chapterID) && ($roundID >=   Config::get('constants.ROUND_ID.S5') && $roundID <=   Config::get('constants.ROUND_ID.S50') || $roundID ==   Config::get('constants.ROUND_ID.S650'))){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.ROUND = '".$roundID."' GROUP BY ad.BOOK_ID ,ad.ROUND ";
                                    }
                                    
                                    if(!empty($bookID) && !empty($roundID) && empty($chapterID) && ($roundID >=   Config::get('constants.ROUND_ID.S200') && $roundID <=   Config::get('constants.ROUND_ID.S600'))){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.BOOK_ID = '".$bookID."' AND ad.ROUND = '".$roundID."' GROUP BY ad.BOOK_ID ,ad.ROUND,ad.METADATA_ID";
                                    }
                                    
                                    if(!empty($bookID) && !empty($roundID) && empty($chapterID) && ($roundID >=   Config::get('constants.ROUND_ID.S5') && $roundID <=   Config::get('constants.ROUND_ID.S50') || $roundID ==   Config::get('constants.ROUND_ID.S650'))){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.BOOK_ID = '".$bookID."' AND ad.ROUND = '".$roundID."' GROUP BY ad.BOOK_ID ,ad.ROUND ";
                                    }
                                    
                                    if(!empty($bookID) && !empty($roundID) && !empty($chapterID)){
                                        $wheredata  =   ['JOB_ID'=>$bookID,'IS_ACTIVE'=>true];
                                        $getbook    =   jobModel::where($wheredata)->first();
                                        $bookID     =   (count($getbook)>=1?$getbook->BOOK_ID:'');
                                        $query_stmt     .=  " AND ad.BOOK_ID = '".$bookID."' AND ad.ROUND = '".$roundID."' AND ad.METADATA_ID = '".$chapterID."' GROUP BY ad.BOOK_ID ,ad.ROUND,ad.METADATA_ID";
                                    }
                        }
            $jobDetails         =   DB::select( $query_stmt );  
            
        return $jobDetails;   
		
    }
    
    public static function getRedoview($id = null){
        try{
            
            $redoinfo       =       DB::table('api_client_acknowledgement')
                                        ->where('ID', $id)
                                        ->first();
				
        }catch( \Exception $e ){
            
            logger($e->getMessage());
            return false;
            
        }
            
        return $redoinfo;
        
    }
	
    public static function getJobXMLInfo($jobId = 0){
        
        try {
            
            $jobXMLInfo         =           DB::table('job AS j')
                                                ->join('job_info  as ji', 'ji.JOB_ID', '=', 'j.JOB_ID')
                                                ->leftJoin('production_location_ftp AS pl', 'pl.PRODUCTION_LOCATION', '=', 'ji.LOCATION' )
                                                ->select(DB::raw('j.BOOK_ID,j.JOB_TITLE,ji.AM_NAME,ji.LOCATION,j.CREATED_DATE as receivedDate, pl.*'))
                                                ->where('j.JOB_ID', $jobId)
                                                ->first();
				
        }catch( \Exception $e ){
            logger($e->getMessage());
            return false;
        }
            
        return $jobXMLInfo;
        
    }
    
    public static function getUserListByRole($roleId){
        if(empty($roleId ))
            return false;
        try{
            
         $UserDetails = DB::table('user as u')
                ->where ('u.ROLE','=',$roleId)
                ->select(DB::raw('concat (u.FIRST_NAME," ", u.LAST_NAME) as userName,u.USER_ID as userId'))
                ->get();
                        
        
       }catch( \Exception $e ){
            return false;
        }
            
        return $UserDetails;
    }
        
    public static function JobAssignedToAmUserMod($data,$jobId){
       
        if( empty( $data ) )
            return false;
        
        try{
         
         $updateQry = DB::table('job_info')
		->where('JOB_ID','=',$jobId)
		->update(array('AM' => $data['user_id'],'AM_MAIL' => $data['AM_Mail'],'AM_NAME' => $data['AM_name']));
       
        return array('success');   
         
         
        
       }catch( \Exception $e ){
            return false;
        }
        
        return array('failed');   
            
      }
      
    public static function getUserDetails($userID){
          
           if(empty( $userID ))
            return false;
        try{
            
         $UserDetails = DB::table('user as u')
                ->where ('u.USER_ID','=',$userID)
                ->select(DB::raw('concat (u.FIRST_NAME," ", u.LAST_NAME) as userName,u.EMAIL,u.USER_ID as userId'))
                ->first();
                        
        
       }catch( \Exception $e ){
            return false;
        }
            
        return $UserDetails;
      }
          
    public static function getBookDetails($bookID){
          
           if(empty( $bookID ))
            return false;
        try{
            
         $bookDetails = DB::table('job as j')
                ->Leftjoin('job_info as ji','ji.JOB_ID','=','j.JOB_ID')
                ->where ('j.BOOK_ID','=',$bookID)
                ->select(DB::raw('*'))
                ->first();
                        
        
       }catch( \Exception $e ){
            return false;
        }
            
        return $bookDetails;
    }

    // Par Report download
    public static function getParreportDownload($jobId = null){
	$bookinfo 		=	array();
        try{
            $bookinfo   =   DB::table('task_level_metadata')
                                ->select(DB::raw('task_level_metadata.METADATA_ID as taskmetaid,metadata_info.METADATA_ID as metainfoid,task_level_metadata.*,metadata_info.*'))
                                ->join( 'metadata_info' , 'task_level_metadata.METADATA_ID', '=', 'metadata_info.METADATA_ID')
                                ->where('task_level_metadata.JOB_ID',$jobId)
                                ->where('task_level_metadata.IS_ACTIVE',true)
                                 ->where('task_level_metadata.UNIT_OF_MEASURE','!=','556')
                                ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
	return $bookinfo;
    }
 
    
}

