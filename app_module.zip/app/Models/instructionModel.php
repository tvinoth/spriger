<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use DB;

class instructionModel extends Model 
{
    protected $table        =   'instruction';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "LAST_MOD_DATE";
    
    public function scopeActive( $query ){
        
        return $query->where('IS_ACTIVE',true);
        
    }
    
    public static function getInsructionitem(){
        
        return instructionModel::leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->skip(10)->take(10)
                ->get();
        
    }
    
    public static function getInsructionroundstage($roundid,$stageid,$copylevel){
        
//        DB::enableQueryLog();
        $dbQuery    =    instructionModel::select( DB::raw('instruction.INSTRUCTION_ID,instruction.INSTRUCTION_TITLE,stage.STAGE_NAME,instruction_level.ID,instruction_level.INSTRUCTION_TYPE_ENUM_ID,'
                . 'round_enum.NAME AS ROUND_NAME,stage.STAGE_ID,stage.STAGE_NAME,round_enum.ID as ROUND_ID,instruction_type_enum.NAME AS LEVEL_NAME,instruction_level.INSTRUCTION,'
                . 'instruction_level.MANDATORY_TYPE as MANDATORY,ias.ID as ACCEPT_ID,case instruction_level.MANDATORY_TYPE when 1 then "YES" when 0 then "NO" '
                . 'else "--" end as MANDATORY_TYPE,ias.INSTRUCTION_LEVEL_ID,case ias.INSTRUCTION_LEVEL_ID '
                . 'when null then "" else ias.INSTRUCTION_LEVEL_ID end as INSTRUCTION_ACCEPT_LEVEL_ID , ias.IF_CORRECT ,  concat(user.FIRST_NAME," ",user.LAST_NAME) AS CREATED_USER  , ias.created_at ,instruction_level.SELECT,instruction_level.TEXTBOX1,instruction_level.TEXTBOX2'))
                        ->leftjoin('instruction_level' , function( $join1 ) use ( $stageid , $roundid , $copylevel ){                     
                        $join1->on( 'instruction.INSTRUCTION_ID' , '=' , 'instruction_level.INSTRUCTION_ID' );
                        $join1->where( 'instruction.ROUND_ENUM_ID' , '=' , $roundid );
                        $join1->where( 'instruction.STAGE_ID' , '=' , $stageid );
//                        $join1->where( 'instruction.INSTRUCTION_TYPE_ENUM_ID' , '=' , $copylevel );                            
                })
                ->leftjoin('instruction_type_enum','instruction_type_enum.ID','=','instruction_level.INSTRUCTION_TYPE_ENUM_ID')
                ->leftjoin('instruction_accept_statement as ias',function($join) use($stageid,$roundid,$copylevel)
                {
                    $join->on('instruction_level.ID', '=', 'ias.INSTRUCTION_LEVEL_ID');
                    $join->where('ias.ROUND_ID', '=',$roundid);
                    $join->where('ias.STAGE_ID', '=',$stageid);
                    //  $join->where('ias.INSTRUCTION_LEVEL_ID', '=',$copylevel);
                    $join->where('ias.IS_ACTIVE',true);
                    
                })
                ->leftjoin('stage','stage.STAGE_ID','=','instruction.STAGE_ID')
                ->leftjoin('round_enum','round_enum.ID','=','instruction.ROUND_ENUM_ID')
                ->leftjoin( 'user' , 'user.USER_ID' , '=' , 'ias.CREATED_BY'  )
                ->where('instruction_level.INSTRUCTION_TYPE_ENUM_ID','=',$copylevel)
                ->where('instruction.ROUND_ENUM_ID','=',$roundid)
                ->where('instruction.STAGE_ID','=',$stageid)
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=', '1' )
                ->groupBy('instruction_level.ID')
                ->get();
                
//$pr      =   DB::getQueryLog();
       
//       print_r( $pr );exit;
       
        return $dbQuery;
        
    }
    
    public function getInsructionIdAndTitle( $roundid, $stageid , $copylevel ){
        
        $recArr     =       $this->getInsructionroundstage( $roundid , $stageid , $copylevel );
        $resultArr  =       array();
       
        if( count( $recArr ) ){
            
            foreach( $recArr as $index => $value ){
                $resultArr["$value->INSTRUCTION_ID"]    =       $value;
            }
            
        
        }
        
        return $resultArr;
    }
    
    
    public function getInstructionLevelInputs( $roundid, $stageid , $copylevel ){
        
        $recArr     =       $this->getInsructionroundstage( $roundid , $stageid , $copylevel );
        $resultArr  =       array();
       
        if( count( $recArr ) ){
            
            $onlyLevelId        =       (array)( $recArr->pluck( 'ID' ) );
            $onlyLevelId        =       ( array_values( $onlyLevelId ) );
            $resultArr           =       $this->getInstructionLevelElements( $onlyLevelId );
        
        }
        
        return $resultArr;
        
    }
    
    public function getInstructionLevelElements( $input_arr ){
       
        $records        =        array();
        
        if( !empty( $input_arr ) ){

            $input_arr          =           array_values( $input_arr[0] );
            
            $records            =           DB::table('instruction_level as il')
                                                ->select(DB::RAW( 'il.INSTRUCTION_ID , ii.* , il.ID as ILID' ))
                                                ->leftJoin( 'instruction_inputs as ii' , 'il.ID' , '=' , 'ii.INSTRUCTION_LEVEL_ID' )
                                                ->whereRaw( 'ii.INSTRUCTION_LEVEL_ID in ( '. implode( ',' , $input_arr ) .')' )
                                                ->where('ii.STATUS' , 1 )->get();
           
        }
        
        return $records;
    }
    
    
    public static function getreadInsructionroundstage($roundid,$stageid,$leveltype,$instru){
        
        return instructionModel::leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->where('instruction_level.INSTRUCTION','=',$instru)
                ->where('instruction_level.INSTRUCTION_TYPE_ENUM_ID','=',$leveltype)
                ->where('instruction.ROUND_ENUM_ID','=',$roundid)
                ->where('instruction.STAGE_ID','=',$stageid)
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->get();
        
    }
    
    public static function getnotreadInsructionroundstage($roundid,$stageid,$leveltype,$instru,$Id)
    {
        return instructionModel::leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->where('instruction_level.INSTRUCTION','=',$instru)
                ->where('instruction_level.INSTRUCTION_TYPE_ENUM_ID','=',$leveltype)
                ->where('instruction_level.ID','<>',$Id)
                ->where('instruction.ROUND_ENUM_ID','=',$roundid)
                ->where('instruction.STAGE_ID','=',$stageid)
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->get();
    }
    
    public static function getMandatoryInsructionroundstage($roundid,$stageid,$enumlevel_id)
    {
        return instructionModel::select(DB::raw('instruction_type_enum.NAME AS LEVEL_NAME,instruction_level.INSTRUCTION'))
                ->leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->leftjoin('instruction_type_enum','instruction_type_enum.ID','=','instruction_level.INSTRUCTION_TYPE_ENUM_ID')
                ->where('instruction.ROUND_ENUM_ID','=',$roundid)
                ->where('instruction.STAGE_ID','=',$stageid)
                ->where('instruction_level.INSTRUCTION_TYPE_ENUM_ID','=',$enumlevel_id)
                ->where('instruction_level.MANDATORY_TYPE','=',true)
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->get();
    }
    
    public static function getInsructionIndividualItem($itemid)
    {
        return instructionModel::join('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->where('instruction_level.ID','=',$itemid)
                ->first();
    }
    
    public static function getdownloadInsructionitem()
    {
        return instructionModel::select(DB::raw('stage.STAGE_NAME,round_enum.NAME AS ROUND_NAME,instruction_type_enum.NAME AS LEVEL_NAME,instruction_level.INSTRUCTION,case instruction_level.MANDATORY_TYPE when 1 then "YES" when 0 then "NO" else "--" end as MANDATORY_TYPE'))
                ->leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                ->leftjoin('instruction_type_enum','instruction_type_enum.ID','=','instruction_level.INSTRUCTION_TYPE_ENUM_ID')
                ->join('stage','stage.STAGE_ID','=','instruction.STAGE_ID')
                ->join('round_enum','round_enum.ID','=','instruction.ROUND_ENUM_ID')
                ->where('instruction.IS_ACTIVE','=',true)
                ->where('instruction_level.IS_ACTIVE','=',true)
                ->get();
    }
    
    
    public static function showAllCheckListInstructions( $start , $length , $searchStr , $orderColumn , $sorting ){
        
        $data 		=	array();
        
        try{
            
            $columnArray    =   [];
            
            $columnArray[]      =       'stage.STAGE_NAME';
            $columnArray[]      =       'round_enum.NAME';
            $columnArray[]      =       DB::raw( 'instruction_type_enum.NAME' );
            $columnArray[]      =       'instruction_level.MANDATORY_TYPE';
            
            $data['checklistCount']  =   instructionModel::select( DB::raw( 'stage.STAGE_NAME ,round_enum.NAME AS ROUND_NAME , instruction_type_enum.NAME AS LEVEL_NAME , instruction_level.INSTRUCTION , case instruction_level.MANDATORY_TYPE when 1 then "YES" when 0 then "NO" else "--" end as MANDATORY_TYPE , instruction_level.INSTRUCTION_ID , instruction_level.ID As INSTRUCTIONLEVEL_ID'))
                                                ->leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                                                ->leftjoin('instruction_type_enum','instruction_type_enum.ID','=','instruction_level.INSTRUCTION_TYPE_ENUM_ID')
                                                ->join('stage','stage.STAGE_ID','=','instruction.STAGE_ID')
                                                ->join('round_enum','round_enum.ID','=','instruction.ROUND_ENUM_ID')
                                                ->where('instruction.IS_ACTIVE' , '=' , true)
                                                ->where('instruction_level.IS_ACTIVE' , '=' ,true)
                                                ->orderBy( $columnArray[$orderColumn], $sorting )
                                                ->when( $searchStr , function ($query) use ($searchStr) {
                                                    return $query->where( 'instruction_level.INSTRUCTION' , 'like', '%' . $searchStr . '%')
                                                        ->orwhere( 'stage.STAGE_NAME' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'round_enum.NAME' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'instruction_level.MANDATORY_TYPE' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'instruction_type_enum.NAME' , 'like', '%' . $searchStr . '%');
                                                })->count();
            
            
            $data['checklistDetails']    =   instructionModel::select(DB::raw('stage.STAGE_NAME , round_enum.NAME AS ROUND_NAME , instruction_type_enum.NAME AS LEVEL_NAME , '
                    . 'instruction_level.INSTRUCTION , case instruction_level.MANDATORY_TYPE when 1 then "YES" when 0 then "NO" else "--" end as MANDATORY_TYPE ,'
                    . ' instruction_level.INSTRUCTION_ID , instruction_level.ID As INSTRUCTIONLEVEL_ID , instruction.ROUND_ENUM_ID AS ROUND_ID , instruction.STAGE_ID'))
                                                ->leftjoin('instruction_level','instruction_level.INSTRUCTION_ID','=','instruction.INSTRUCTION_ID')
                                                ->leftjoin('instruction_type_enum','instruction_type_enum.ID','=','instruction_level.INSTRUCTION_TYPE_ENUM_ID')
                                                ->join('stage','stage.STAGE_ID','=','instruction.STAGE_ID')
                                                ->join('round_enum','round_enum.ID','=','instruction.ROUND_ENUM_ID')
                                                ->where('instruction.IS_ACTIVE' , '=' , true)
                                                ->where('instruction_level.IS_ACTIVE' , '=' ,true)
                                                ->orderBy( $columnArray[$orderColumn], $sorting )
                                                ->when( $searchStr , function ($query) use ($searchStr) {
                                                    return $query->where( 'instruction_level.INSTRUCTION' , 'like', '%' . $searchStr . '%')
                                                        ->orwhere( 'stage.STAGE_NAME' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'round_enum.NAME' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'instruction_level.MANDATORY_TYPE' , 'like', '%' . $searchStr . '%')
                                                        ->orWhere( 'instruction_type_enum.NAME' , 'like', '%' . $searchStr . '%');
                                                })
                                                ->skip( $start )->take( $length )
                                                ->get();
            
                                
        }catch( \Exception $e ){ 
            
            echo $e->getMessage();
            return false;
            
        }
	
        return $data;
        
        
    }
    
    
}

