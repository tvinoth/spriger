<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;

class packageModel extends Model {
    
    //protected $table    =   'round_enum';
   
    
    public function getPackageList(){
        
         // $qry = "SELECT transaction_package_id id, code, name, description FROM transaction_package WHERE is_active = 1";
        
         $package 		=	array();
        
        try{
            $package   =   packageModel::select(DB::raw('transaction_package'))
                        		->where('is_active',true)
                                        ->get();            
            
        }catch( \Exception $e ){           
            return false;
        }
	
        return $package;
        
    }
    
}

