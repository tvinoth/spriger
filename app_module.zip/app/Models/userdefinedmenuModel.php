<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;
use Session;

class userdefinedmenuModel extends Model 
{
    protected $table        =   'user_defined_menu';
    public  $primaryKey     =   'ID';
    const UPDATED_AT        =   "LAST_MOD_DATE";
     //update tool response
    public static function getmenutransaction($userid   =   null)
    {
        $update     =	false;
        try
        {
            $update     =   DB::table('user_defined_menu AS udm')->select(DB::raw('udm.MENU_ID,trm.TRANSACTION_NAME,trm.CODE,tpi.TRANSACTION_MENU_ID,tpi.TRANSACTION_PACKAGE_ID,tp.NAME,tp.DESCRIPTION,tp.IS_CHECK_ACTIVE_NAME AS CHILD_NAME,tp.PACKAGE_DISPLAY_ORDER'))
                            ->join( 'transaction_menu as trm', 'trm.TRANSACTION_MENU_ID', '=', 'udm.MENU_ID')
                            ->join( 'transaction_package_item as tpi', 'tpi.TRANSACTION_MENU_ID', '=', 'trm.TRANSACTION_MENU_ID')
                            ->join( 'transaction_package as tp', 'tp.TRANSACTION_PACKAGE_ID', '=', 'tpi.TRANSACTION_PACKAGE_ID')
                            ->where('udm.USER_ID',$userid)
                            ->where('trm.IS_ACTIVE',true)
                            ->where('tp.IS_ACTIVE',true)
                            ->get();  
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
    public static function getmainmenutransaction($userid   =   null)
    {
        $update     =	false;
        try
        {
            $update   =   userdefinedmenuModel::select(DB::raw('user_defined_menu.MENU_ID,trm.TRANSACTION_NAME,trm.CODE'))
                                                        ->join( 'transaction_menu as trm' , 'trm.TRANSACTION_MENU_ID', '=', 'user_defined_menu.MENU_ID')
                                                        ->where('user_defined_menu.USER_ID',$userid)
                                                        ->where('trm.IS_ACTIVE',true)
                                                        ->get();   
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
    public static function getmainmenu($roleid   =   null)
    {
        $update     =	false;
        try
        {
         
            $update =   DB::table('transaction_package_item as tp')->select(DB::raw('tm.TRANSACTION_NAME,tm.MENU_ICON,tm.TRANSACTION_TYPE,tm.URL,tm.IS_CHECK_ACTIVE_NAME,tm.MENU_DISPLAY_ORDER'))
                                                        ->join( 'transaction_menu as tm' , 'tm.TRANSACTION_MENU_ID', '=', 'tp.TRANSACTION_MENU_ID')
                                                        ->join( 'role_package as rp' , 'rp.TRANSACTION_PACKAGE_ID', '=', 'tp.TRANSACTION_PACKAGE_ID')
                                                        ->where('rp.ROLE_ID',$roleid)
                                                        ->where('tm.IS_ACTIVE',1)
                                                        ->where('tm.TRANSACTION_TYPE',true)
                                                        ->orderBy('tm.MENU_DISPLAY_ORDER')
                                                        ->get();   
         
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }
    
    public static function getmainmenuchild($roleid   =   null)
    {
        $update     =	false;
        try
        {
            $update =   DB::table('transaction_package_item as tp')->select(DB::raw('tm.TRANSACTION_NAME,tm.TRANSACTION_TYPE,tm.URL,tm.IS_CHECK_ACTIVE_NAME,tm.PACKAGE_DISPLAY_ORDER,tm.CODE'))
                                                        ->join( 'transaction_menu as tm' , 'tm.TRANSACTION_MENU_ID', '=', 'tp.TRANSACTION_MENU_ID')
                                                        ->join( 'role_package as rp' , 'rp.TRANSACTION_PACKAGE_ID', '=', 'tp.TRANSACTION_PACKAGE_ID')
                                                        ->where('rp.ROLE_ID',$roleid)
                                                        ->where('tm.IS_ACTIVE',1)
                                                        ->where('tm.TRANSACTION_TYPE',2)
                                                        ->get();            
        }
        catch( \Exception $e )
        {           
            return false;
        }
        return $update;
    }

    public static function getmainmenusubchild($childName = null, $roleid = null,$childtype = null) {
        try {
            $query = DB::table('transaction_package_item as tp')->select(DB::raw('tm.TRANSACTION_NAME,tm.MENU_ICON,tm.TRANSACTION_TYPE,tm.URL,tm.IS_CHECK_ACTIVE_NAME,tm.PACKAGE_DISPLAY_ORDER,tm.CODE'))
                    ->join('transaction_menu as tm', 'tm.TRANSACTION_MENU_ID', '=', 'tp.TRANSACTION_MENU_ID')
                    ->join('role_package as rp', 'rp.TRANSACTION_PACKAGE_ID', '=', 'tp.TRANSACTION_PACKAGE_ID')
                    ->where('rp.ROLE_ID', $roleid)
                    ->where('tm.TRANSACTION_NAME', 'like', $childName . '%')
                    ->where('tm.IS_ACTIVE', 1)
                    ->where('tm.TRANSACTION_TYPE', $childtype)
                    ->orderBy('tm.PACKAGE_DISPLAY_ORDER','asc')
                    ->get();
           
            
        } catch (\Exception $e) {
            return false;
}
        return $query;
    }
    
}

