<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Models\jobInfoModel;
use Carbon\Carbon;
use Session;

class jobRevisedModel extends Model 
{
    protected $table        =   'job_revised';
    public  $primaryKey     =   'ID';
    const CREATED_AT        =   "CREATED_DATE";
    const UPDATED_AT        =   "LAST_MOD_DATE";
    
    public static function store($data)
    {
        $spicastadd         =   [];   
        try
        {
            $spicastadd     =   jobRevisedModel::insertGetId($data);
            return $spicastadd;
        }
        catch( \Exception $e )
        {               
            return $spicastadd;
        }
        return $spicastadd;
    }
}

