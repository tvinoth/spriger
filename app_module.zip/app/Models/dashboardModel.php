<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;

class dashboardModel extends Model {

    /**
     * 
     * @param type $userID = USER_ID - user table
     * @return type
     */
    public static function getAssignedList($arrData)
    {
       $query           =   "CALL jour_assignedtome('".$arrData['user_id']."')";  
       $assignedList    =   DB::select($query);
       return $assignedList;  
    }
    public static function getFilesCountList($arrData){
       
        //$query = "CALL Proc_FilesCount('".$arrData['user_id']."','".$arrData['manager']."','".$arrData['circle_id']."','".$arrData['team_id']."')";  
        // $filesList = DB::select($query);
        //return $filesList;        
        return '-';
        
    }
    
    public static function getJobStageInfo($batchId) {
        $jobInfo = DB::table('job_resource')
                ->where('BATCH_ID', $batchId)
                ->select(DB::raw('JOB_ID, JOB_STAGE_ID '))
                ->get();
        return $jobInfo;	
    }
	
	public static function saveLoungeHours($arrData) {
       $query = "CALL Proc_SaveLoungeHours('".$arrData['userId']."','".$arrData['remark']."','".$arrData['reason']."')";  
       $res = DB::select($query);
       return $res;  
	}
	public static function getLoungeHours($arrData) {
		$jobInfo = DB::table('lounge_hours')
			->where('user_id', $arrData['userId'])
			->whereNull('lounge_out')
			->select(DB::raw(' * '))
			->get();
        return $jobInfo;	
	}
	public static function changePassword($arrData) {
       $query = "CALL Proc_ChangePassword('".$arrData['userId']."','".$arrData['pwd']."','".$arrData['newPwd']."')";  
       $res = DB::select($query);
       return $res;  
	}
	
	
	
/*
    // get file count list
    public static function getFileList($arrData){
       // print_r($arrData);
        $query =  DB::table('task_level_metadata as m')  
        ->select(DB::raw('j.JOB_ID as job_id, j.JOB_TITLE as job_title, count(m.METADATA_ID) as chapter_count,(select count(art_metadata_id) from task_level_art_metadata a where a.JOB_ID = m.JOB_ID) as art_count'))
        ->join('job as j', 'j.JOB_ID', '=', 'm.JOB_ID')
        ->where('j.PM',$arrData['user_id'])
        ->groupBy('m.JOB_ID'); 
        
        $searchStr = $arrData['searchStr'];
        $query->where(function ($query) use ($searchStr) {
            if ($searchStr != '') {
                $query->where('j.JOB_TITLE', 'like', '%' . $searchStr . '%');     
            }
        });
        
        if($arrData['recordsTotal'] == 'true') {
           $response =  $query->get();
           //$response =  $query->toSql();
	} else {
            
            $query->orderBy('j.JOB_TITLE','asc');
            if($arrData['useLimit'] == 'true'){
                $query->skip($arrData['start'])->take($arrData['length']);    
            }   
            $response = $query->get();
            //$response = $query->toSql();
            //print_r($response);
           // exit;
        }
       //  $response = $query->toSql();
         //   print_r($response);
        return $response;

    }
*/   
    
   
}
