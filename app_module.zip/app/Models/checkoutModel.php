<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use DB;
use Illuminate\Support\Facades\Config;
use App\Http\Controllers\CommonMethodsController;
use App\Models\stageModel;
use Session;
use Log;

class checkoutModel extends Model {
    
   
    public static function getStageInfo( $jobStageId){

        $sql = 'SELECT jr.IS_ART,ji.ISSN_PRINT,mi.FM_ARTICLE_BM,j.BOOK_ID,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.STATUS as CURRENTSTATUS,js.Rollback_Remarks,js.CHECK_OUT,js.CHECK_IN,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID,js.Rollback_Remarks as REMARKS
                FROM job_stage js
                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                JOIN job j ON j.JOB_ID = jr.JOB_ID
                JOIN job_info ji ON ji.JOB_ID = j.JOB_ID
                JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
				JOIN metadata_info mi ON mi.METADATA_ID = tlm.METADATA_ID
                LEFT OUTER
                JOIN round_enum r ON r.ID = jr.ROUND_ID
                LEFT OUTER
                JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                WHERE js.JOB_STAGE_ID IN ('.$jobStageId.')';
      
        $getRec        =   DB::select( $sql );
        
        return $getRec;
      
    }
    
    public static function getArtStageInfo_old( $jobStageId){

        $sql = 'SELECT j.BOOK_ID,tlam.ID as ART_METADATA_ID,tlam.ID as METADATA_STATUS_ID, CASE WHEN tlam.CURRENT_ITERATION > 1 THEN tlam.REMARKS ELSE "" END AS REMARKS,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID,js.STATUS as CURRENTSTATUS
                FROM job_stage js
                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                JOIN job j ON j.JOB_ID = jr.JOB_ID
                JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                JOIN metadata_status as  tlam ON tlam.ID = jr.METADATA_STATUS_ID
                LEFT OUTER
                JOIN round_enum r ON r.ID = jr.ROUND_ID
                LEFT OUTER
                JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                WHERE js.JOB_STAGE_ID IN ('.$jobStageId.')';
      
        $getRec        =   DB::select( $sql );
        
        return $getRec;
      
    }
    
     public static function getArtStageInfo( $jobStageId){

        $sql = 'SELECT tam.FIGURE_NO,tam.FILE_NAME,j.BOOK_ID,tlam.ID AS METADATA_STATUS_ID,tam.ART_METADATA_ID, tam.REMARKS,js.JOB_STAGE_ID,jr.METADATA_ID,tlm.CHAPTER_NO,tlm.CHAPTER_NAME,s.STAGE_NAME,r.NAME AS ROUND_NAME,s.STAGE_ID,jr.JOB_ID,js.INPUT_QUANTITY,js.OUTPUT_QUANTITY,js.IS_PARTIAL,js.ITERATION_ID,js.STAGE_SEQ,jr.ROUND_ID,jr.JOB_ROUND_ID,js.WORKFLOW_ID,js.WORKFLOW_MASTER_ID,js.STATUS as CURRENTSTATUS
                FROM job_stage js
                JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                JOIN job j ON j.JOB_ID = jr.JOB_ID
                JOIN task_level_metadata tlm ON tlm.METADATA_ID = jr.METADATA_ID
                JOIN metadata_status AS tlam ON tlam.ID = jr.METADATA_STATUS_ID and jr.CURRENT_ITERATION_ID = tlam.CURRENT_ITERATION
                JOIN task_level_art_metadata AS tam ON tam.METADATA_STATUS_ID = tlam.ID and tam.CURRENT_ITERATION = tlam.CURRENT_ITERATION
                LEFT OUTER
                JOIN round_enum r ON r.ID = jr.ROUND_ID
                LEFT OUTER
                JOIN stage s ON s.STAGE_ID = js.STAGE_ID
                WHERE js.JOB_STAGE_ID IN ('.$jobStageId.')';
     
        $getRec        =   DB::select( $sql );
        
        return $getRec;
      
    }
    
    public static function getNextStageDetails($roundId, $stageSequence, $iterationid, $workflowId ){
        
        $sql = "select js.ITERATION_ID, js.OUTPUT_QUANTITY,js.JOB_ROUND_ID,js.JOB_STAGE_ID,js.STAGE_ID, s.STAGE_NAME from job_stage js 
                                left outer join stage s on s.STAGE_ID=js.STAGE_ID 
                                where js.JOB_ROUND_ID='".$roundId."' and js.ITERATION_ID='".$iterationid."' and js.STAGE_SEQ='".$stageSequence."' and js.WORKFLOW_ID='".$workflowId."'" ;
       
        $getRec             =   DB::select( $sql );
        
        if(count($getRec)>=1){
            return $getRec['0'];
        }
        
        return $getRec;
    }
    
    public static function getNextStageDetailsByStageid($roundId, $stageSequence, $iterationid, $workflowId ){
        
        $sql = "select js.ITERATION_ID, js.OUTPUT_QUANTITY,js.JOB_ROUND_ID,js.JOB_STAGE_ID,js.STAGE_ID, s.STAGE_NAME from job_stage js 
                                left outer join stage s on s.STAGE_ID=js.STAGE_ID 
                                where js.JOB_ROUND_ID='".$roundId."' and js.ITERATION_ID='".$iterationid."' and js.STAGE_SEQ='".$stageSequence."' and js.WORKFLOW_ID='".$workflowId."'" ;
       
        $getRec             =   DB::select( $sql );
        
        if(count($getRec)>=1){
            return $getRec['0'];
        }
        
        return $getRec;
    }
    
    public static function getWrokflowServerMapPath($stageId,$artflag=0,$artGroup=0){
        
        $checkoutStage   =      "SELECT j.JOB_ID,j.BOOK_ID,tm.CHAPTER_NO,js.WORKFLOW_ID,js.IS_PARTIAL,js.STAGE_ID,jr.ROUND_ID,re.NAME as ROUND_NAME FROM job_stage js
                                        LEFT OUTER JOIN job_round jr ON jr.JOB_ROUND_ID = js.JOB_ROUND_ID
                                        JOIN round_enum as re ON jr.ROUND_ID = re.ID
                                        JOIN task_level_metadata tm ON tm.METADATA_ID = jr.METADATA_ID
                                        LEFT OUTER JOIN job j ON j.JOB_ID=jr.JOB_ID
                                        WHERE js.JOB_STAGE_ID IN('" . $stageId . "')";
        

        $sql_checkout_worpath =  DB::select( $checkoutStage );
       
       
        $jobId      = $sql_checkout_worpath['0']->JOB_ID;
        $chatperId  = $sql_checkout_worpath['0']->CHAPTER_NO;
        $sessionEmpId   =   Session::get('users')['emp_id'];
        
        $bookId         =   $sql_checkout_worpath['0']->BOOK_ID;
        $roundname      =   $sql_checkout_worpath['0']->ROUND_NAME;
        $chaptername    =   $sql_checkout_worpath['0']->CHAPTER_NO;
        
        
        $inp_rep_arr            =   array('{BID}' => $bookId , '{RID}' => $roundname,'{CID}' => $chaptername );
        $cmn_obj                =   new CommonMethodsController();
        
        
        
        $sql2                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID. "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $sql_checkout_worpath['0']->STAGE_ID . "' AND `FOLDER_TYPE` = 6 ";
        $sql_checkout_sourcepath = DB::select($sql2);
        
        $sql3                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $sql_checkout_worpath['0']->STAGE_ID . "' AND `FOLDER_TYPE` = 7 ";
        $sql_checkout_workingpath = DB::select($sql3);
       
        $sql4                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` = '" . $sql_checkout_worpath['0']->STAGE_ID . "' AND `FOLDER_TYPE` = 9 ";
        $sql_checkout_destinationpath = DB::select($sql4);

        $sql5                   =   "SELECT * FROM `workflow_server_map` WHERE `WORKFLOW_ID` = '" . $sql_checkout_worpath['0']->WORKFLOW_ID . "' AND `ROUND_ID` = '" . $sql_checkout_worpath['0']->ROUND_ID . "' AND `JOB_ID` = '" . $jobId . "' AND `STAGE_ID` ='" . $sql_checkout_worpath['0']->STAGE_ID. "' AND `FOLDER_TYPE` IN (6,7,9) ";
        
        $checkingpath_is_exist  = count(DB::select($sql5));
        
        $filemovement = false;
        //echo "<pre>"; print_r($sql_checkout_workingpath);exit;
        if ($checkingpath_is_exist > 1) {

            if ($sql_checkout_sourcepath['0']->FILE_MOVEMENT != 1 || !empty($sql_checkout_workingpath)) {
                $filemovement = true;
                
                $sql6   =   "select CHECK_OUT,IS_PARTIAL from job_stage where JOB_STAGE_ID='" . $stageId . "'";
                $sql_checkout_check = DB::select($sql6);
                
                $sql7   =  "select wl.JOB_WORK_LOG_ID, wl.CHECK_IN from job_work_log wl where wl.JOB_STAGE_ID='" . $stageId . "' order by wl.JOB_WORK_LOG_ID desc limit 1";
                $sql_worklog_checkin =  DB::select($sql7);
                
                $clientDetails = '';
                
                $jobClientId = $clientDetails;
                //	echo "<pre>"; print_r($sql_checkout_sourcepath);exit;
                $source_serverpath  = $sql_checkout_sourcepath['0']->SERVER_PATH;
                $source_folderpath  = $sql_checkout_sourcepath['0']->FOLDER_PATH;
                $source_username    = $sql_checkout_sourcepath['0']->USER_NAME;
                $source_password     = $sql_checkout_sourcepath['0']->PASSWORD;
                $source_filestring  = $sql_checkout_sourcepath['0']->FILE_STRING;
                $source_extension   = $sql_checkout_sourcepath['0']->FILE_EXTENSION;
                $source_movement    = $sql_checkout_sourcepath['0']->FILE_MOVEMENT;

                $user_directory = '/' . $sessionEmpId;

                $working_serverpath = $sql_checkout_workingpath['0']->SERVER_PATH;
                //$working_folderpath = $sql_checkout_workingpath['0']->FOLDER_PATH.$user_directory;
                $working_folderpath = $sql_checkout_workingpath['0']->FOLDER_PATH.$user_directory . '/';
                $working_username = $sql_checkout_workingpath['0']->USER_NAME;
                $working_password = $sql_checkout_workingpath['0']->PASSWORD;
                $working_filestring = $sql_checkout_workingpath['0']->FILE_STRING;
                $working_extension = $sql_checkout_workingpath['0']->FILE_EXTENSION;
                $working_movement = $sql_checkout_workingpath['0']->FILE_MOVEMENT;



                $destination_serverpath = $sql_checkout_destinationpath['0']->SERVER_PATH;
                $destination_folderpath = $sql_checkout_destinationpath['0']->FOLDER_PATH;
                $destination_username = $sql_checkout_destinationpath['0']->USER_NAME;
                $destination_password = $sql_checkout_destinationpath['0']->PASSWORD;
                $destination_filestring = $sql_checkout_destinationpath['0']->FILE_STRING;
                $destination_extension = $sql_checkout_destinationpath['0']->FILE_EXTENSION;
                $destination_movement = $sql_checkout_destinationpath['0']->FILE_MOVEMENT;
                
                
               
                $sourcepath = $source_serverpath . $source_folderpath;
                if (!empty($source_filestring) && $source_filestring != "NA") {
                    $sourcepath .= $cmn_obj->arr_key_value_replace( $inp_rep_arr , $source_filestring );
                }
                
                $sourcepath =   $cmn_obj->arr_key_value_replace( $inp_rep_arr , $sourcepath );
                $sourcepath .= "<>" . $working_username . "<>" . $working_password;

                //echo $sourcepath;exit;
                $workingpath = $working_serverpath . $working_folderpath;

                if (!empty($working_filestring) && $working_filestring != "NA") {
                    $workingpath .= $working_filestring;
                }
             
                $workingpathwithoutcredentials = $workingpath = $cmn_obj->arr_key_value_replace( $inp_rep_arr , $workingpath );
                $workingpath .= "<>" . $working_username . "<>" . $working_password;

                $destinationpath = $destination_serverpath . $destination_folderpath;
                
                if (!empty($destination_filestring) && $destination_filestring != "NA") {
                    $destinationpath .= $cmn_obj->arr_key_value_replace( $inp_rep_arr , $destination_filestring );
                }

                $destinationpath = $cmn_obj->arr_key_value_replace( $inp_rep_arr , $destinationpath );
                $destinationpath .= "<>" . $working_username . "<>" . $working_password;

                $isdeletesrc = '0';
                $temppath = '';
                
               
                
                if ($sql_checkout_worpath['0']->IS_PARTIAL == 1) {
                    if ($artflag == 1) {
                        $temppath2 = Config::get('serverconstants.ART_TEMP_FILE_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        $temppath .= "<>" . $working_username . "<>" . $working_password;
                        $isdeletesrc = '1';
                    } else {

                        $temppath2 = Config::get('serverconstants.TEMP_FILE_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        $temppath .= "<>" . $working_username . "<>" . $working_password;
                        $isdeletesrc = '1';
                    }
                } else {

                    if ($artflag == 1) {
                        $temppath2 = Config::get('serverconstants.ART_TEMP_FILE_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        $temppath .= "<>" . $working_username . "<>" . $working_password;
                        $isdeletesrc = '1';
                    } else {

                        $temppath2 = Config::get('serverconstants.TEMP_FILE_SERVER_PATH');
                        $temppath = $temppath2 . $jobId . '_' . $chatperId . '_' . $stageId;
                        $temppath .= "<>" . $working_username . "<>" . $working_password;
                        $isdeletesrc = '1';
                    }
                }
                $fileCheckout = 0;
                //echo "<pre>"; print_r($temppath);exit;

                $path['status'] = '1';
                $path['detail']['src'] = $sourcepath;
                $path['detail']['work'] = $workingpath;
                $path['detail']['dest'] = $destinationpath;
                $path['detail']['temp'] = $temppath;
                $path['detail']['filecheout'] = $fileCheckout;
              
            }
        } else {
            return $path['status'] = 0;
        }

        return $path;
    }
    
    public function getWorklogInsertExist($jobStageId){
        
        $data   = array();
        
        if(empty($jobStageId)){
            return $data;
        }
        
        $data       =   DB::table('job_work_log')->select()->whereIn( 'JOB_STAGE_ID' , $jobStageId )
                                                                       ->whereNull('CHECK_IN')
                                                                       ->get();
        
        return $data;
        
    }
    
    public function getWorklogLatestRecord($jobStageId){
         
        $data   = array();
        if(empty($jobStageId)){
            return $data;
        }
        
        $data       =   DB::table('job_work_log')->select()->where( 'JOB_STAGE_ID' , $jobStageId )
                                                                       ->orderBy('JOB_WORK_LOG_ID','DESC')
                                                                       ->first();
        
        return $data;
        
    }
    
    public function getJobStageIdByBatch($batchId){
        
        $data       =   DB::table('job_resource')->select()->where( 'BATCH_ID' , $batchId )
                                                                      ->get();
        return $data; 
    }
    
    /** iteration roll back **/
    public function artStageRollBack_old(  $artMetaId , $jobRoundID  , $workflowID , $roundId , $iterationCount ,$stageDetails='' ){ 
       
         
        $obj_pfl = new \App\Http\Controllers\workflow\workflowRuleController();
        $sequence  = 1;
        if(!empty($stageDetails)){
           $stageId     =  $stageDetails->STAGE_ID;
           $jobId       =  $stageDetails->JOB_ID;
           $roundId     =  $stageDetails->ROUND_ID;
           $wfId        =  $workflowID;
           $ruleDetail  =  $obj_pfl->getRuleForGivenStage($stageId, $roundId, $jobId, $wfId, $wfMid='');
           
           if(isset($ruleDetail['1']) && !empty($ruleDetail['1'])) {
               $sequence  = $ruleDetail['1'];
           }
        }
         
        $nextiterationCount	=	$iterationCount +1;
        
        $sql_insert = "insert into job_stage (JOB_ROUND_ID,WORKFLOW_MASTER_ID,WORKFLOW_TYPE,WORKFLOW_ID,STAGE_ID,STATUS,STAGE_SEQ,START_STAGE_ID,END_STAGE_ID,ITERATION_ID)
                                                                            select js.JOB_ROUND_ID,js.WORKFLOW_MASTER_ID,js.WORKFLOW_TYPE,js.WORKFLOW_ID, js.STAGE_ID, 25,js.STAGE_SEQ,START_STAGE_ID,END_STAGE_ID,".$nextiterationCount." from task_level_art_metadata t 
                                                                            JOIN job_round jr ON t.ART_METADATA_ID=jr.ART_METADATA_ID
                                                                            join job_stage js on jr.JOB_ROUND_ID=js.JOB_ROUND_ID 
                                                                            where t.ART_METADATA_ID = ".$artMetaId."  and jr.CURRENT_ITERATION_ID = ".$iterationCount." and js.ITERATION_ID = ".$iterationCount." and js.STAGE_SEQ >= '$sequence' ";

        $sql_checkout_worpath =  DB::insert( $sql_insert );
		 
        $iterationCount	=	$nextiterationCount;

        $sql2  =     "select js.STAGE_ID,js.JOB_STAGE_ID,js.INPUT_QUANTITY from job_stage js where js.JOB_ROUND_ID='".$jobRoundID."' and js.WORKFLOW_ID='".$workflowID."' and js.STAGE_SEQ= '1' and ITERATION_ID= '".$iterationCount."'";

        $sql_task_level_metadata_update2 = DB::select( $sql2 );


        $sql3  =     "update job_stage set STATUS='27' where JOB_STAGE_ID='".$sql_task_level_metadata_update2['0']->JOB_STAGE_ID."' ";
        $updateTable2 = DB::update( $sql3 );

        $sql4 = "update job_round set CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',CURRENT_ITERATION_ID='".$iterationCount."',STATUS='27' where JOB_ROUND_ID='".$jobRoundID."'";
        $updateTable4 = DB::update( $sql4 );

        $sql5  = "update task_level_art_metadata set CURRENT_ROUND='".$roundId."',CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',STATUS_ENUM_ID=46,CURRENT_ITERATION='".$iterationCount."' where ART_METADATA_ID='".$artMetaId."' ";
        $updateTable5 = DB::update( $sql5 );
        
        return true;
   
    }
     
     
     /** iteration roll back **/
     public function artStageRollBack(  $artMetaId ,$metaStatusId, $jobRoundID  , $workflowID , $roundId , $iterationCount ,$stageDetails='' ){ 
       
         
        $obj_pfl = new \App\Http\Controllers\workflow\workflowRuleController();
        $sequence  = 1;
        if(!empty($stageDetails)){
           $stageId     =  $stageDetails->STAGE_ID;
           $jobId       =  $stageDetails->JOB_ID;
           $roundId     =  $stageDetails->ROUND_ID;
           $wfId        =  $workflowID;
           $ruleDetail  =  $obj_pfl->getRuleForGivenStage($stageId, $roundId, $jobId, $wfId, $wfMid='');
           
           if(isset($ruleDetail['1']) && !empty($ruleDetail['1'])) {
               $sequence  = $ruleDetail['1'];
           }
        }
         
        $nextiterationCount	=	$iterationCount +1;
        
        $sql_insert = "insert into job_stage (JOB_ROUND_ID,WORKFLOW_MASTER_ID,WORKFLOW_TYPE,WORKFLOW_ID,STAGE_ID,STATUS,STAGE_SEQ,SKIP_ENABLED,ITERATION_ID,START_STAGE_ID,END_STAGE_ID)
                                                                        SELECT js.JOB_ROUND_ID,js1.WORKFLOW_MASTER_ID,js1.WORKFLOW_TYPE,js1.WORKFLOW_ID, js1.STAGE_ID, 25,js1.STAGE_SEQ,js1.SKIP_ENABLED, ".$nextiterationCount.",js1.START_STAGE_ID,js1.END_STAGE_ID
                                                                        FROM job_stage js
                                                                        JOIN job_stage js1 ON js1.JOB_ROUND_ID = js.JOB_ROUND_ID AND js1.ITERATION_ID = js.ITERATION_ID
                                                                        JOIN stage s ON s.STAGE_ID = js1.STAGE_ID
                                                                        WHERE js.JOB_STAGE_ID = '".$stageDetails->JOB_STAGE_ID."' AND js1.STAGE_SEQ >= '".$sequence."'";
             
        $sql_checkout_worpath =  DB::insert( $sql_insert );
		 
        $iterationCount	=	$nextiterationCount;

        $sql2  =     "select js.STAGE_ID,js.JOB_STAGE_ID,js.INPUT_QUANTITY from job_stage js where js.JOB_ROUND_ID='".$jobRoundID."' and js.WORKFLOW_ID='".$workflowID."' and js.STAGE_SEQ= '1' and ITERATION_ID= '".$iterationCount."'";
       
        $sql_task_level_metadata_update2 = DB::select( $sql2 );
       

        $sql3  =     "update job_stage set STATUS='27' where JOB_STAGE_ID='".$sql_task_level_metadata_update2['0']->JOB_STAGE_ID."' ";
        $updateTable2 = DB::update( $sql3 );

        $sql4 = "update job_round set CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',CURRENT_ITERATION_ID='".$iterationCount."',STATUS='27' where JOB_ROUND_ID='".$jobRoundID."'";
        $updateTable4 = DB::update( $sql4 );
        
        $sql6 = "update metadata_status set CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',CURRENT_ITERATION='".$iterationCount."',CURRENT_STATUS='46' where ID='".$metaStatusId."'";
        $updateTable6 = DB::update( $sql6 );
        
        $sql5  = "update task_level_art_metadata set CURRENT_ROUND='".$roundId."',CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',STATUS_ENUM_ID=46,FIGURE_STATUS=0,CURRENT_ITERATION='".$iterationCount."' where ART_METADATA_ID IN(".$artMetaId.") ";
        //echo $sql5;exit;
        
        $updateTable5 = DB::update( $sql5 );
        Log::useDailyFiles(storage_path().'/Api/artroleback.log');
        Log::info($sql5 );
        return true;
   
     }
     
     public function getWorkflowRuleDetails($jsStageId){
       $stageData   =     $this->getStageInfo($jsStageId);
       return $stageData;
     }
     
     
     public function getPrcErrorExist($metaId, $roundId){
       $sql2            =     "select *from pr_qc_error_log as pc where pc.ROUND_ID = '".$roundId."' and pc.TASK_LEVEL_METADATA_ID = '".$metaId."'";
       
        $errorDetails = DB::select( $sql2 );
       return $errorDetails;
     }
     
     /** iteration roll back **/
     public function StageRollBack( $jobRoundID  , $workflowID , $roundId , $iterationCount , $gotoStage, $stageDetails='' ){ 
       
         
        $obj_pfl = new \App\Http\Controllers\workflow\workflowRuleController();
        $sequence    =   1;
        
        if(!empty($stageDetails)){
           $stageId     =  $stageDetails->STAGE_ID;
           $jobId       =  $stageDetails->JOB_ID;
           $roundId     =  $stageDetails->ROUND_ID;
           $wfId        =  $workflowID;
           
           $sequence  =   $this->getStageSequence($gotoStage,$roundId,$jobId,$wfId);
         
        }
        
        $sql_sq_d               = "select sum(jw.OUTPUT_QUANTITY) as sumval from job_work_log jw where jw.JOB_STAGE_ID = '".$stageDetails->JOB_STAGE_ID."'";
        $outputQuantiy          =  DB::select( $sql_sq_d ); 
        if(!empty($outputQuantiy)){
            $outputQn  = $outputQuantiy['0']->sumval;
        }
       
        $nextiterationCount	=	$iterationCount +1;
        $jobstageid             =       $stageDetails->JOB_STAGE_ID;
        $cur_iteration          =       $iterationCount;
        $sql_insert = "insert into job_stage (JOB_ROUND_ID,WORKFLOW_MASTER_ID,WORKFLOW_TYPE,WORKFLOW_ID,STAGE_ID,STATUS,STAGE_SEQ,SKIP_ENABLED,ITERATION_ID)
                                                                        SELECT js.JOB_ROUND_ID,js1.WORKFLOW_MASTER_ID,js1.WORKFLOW_TYPE,js1.WORKFLOW_ID, js1.STAGE_ID, 25,js1.STAGE_SEQ,js1.SKIP_ENABLED, ".$nextiterationCount."
                                                                        FROM job_stage js
                                                                        JOIN job_stage js1 ON js1.JOB_ROUND_ID = js.JOB_ROUND_ID AND js1.ITERATION_ID = js.ITERATION_ID
                                                                        JOIN stage s ON s.STAGE_ID = js1.STAGE_ID
                                                                        WHERE js.JOB_STAGE_ID = '".$stageDetails->JOB_STAGE_ID."' AND js1.STAGE_SEQ >= '".$sequence."'";
      
        $sql_checkout_worpath =  DB::insert( $sql_insert );
		 
        $iterationCount	=	$nextiterationCount;

        $sql2  =     "select js.STAGE_ID,js.JOB_STAGE_ID,js.INPUT_QUANTITY from job_stage js where js.JOB_ROUND_ID='".$jobRoundID."' and js.WORKFLOW_ID='".$workflowID."' and js.STAGE_SEQ= '$sequence' and ITERATION_ID= '".$iterationCount."'";
        $sql_task_level_metadata_update2 = DB::select( $sql2 );

        $active_jb_stg     =   $sql_task_level_metadata_update2['0']->JOB_STAGE_ID;
        
        $stageDetails       =       $this->getStageInfo( $active_jb_stg );
        $stg_obj            =       new stageModel();
        $stg_info           =       $stg_obj->getStageInfoByStageId( $stageDetails[0]->STAGE_ID );
        $status_code        =       27;
        
        if( $stg_info->IS_AUTO ){
            $status_code=   23;
        }
        $bookReview = Config::get('constants.STAGE_COLLEECTION.BOOK_BUILDING_REVIEW');
        
        if($roundId == '119' && $stageId == $bookReview){
             $status_code=   24;
        }
        
        $sql3               =       "update job_stage set STATUS='$status_code',INPUT_QUANTITY='".$outputQn."' where JOB_STAGE_ID='".$active_jb_stg."' ";
        $updateTable2 = DB::update( $sql3 );

        $sql4 = "update job_round set CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',CURRENT_ITERATION_ID='".$iterationCount."',STATUS='$status_code' where JOB_ROUND_ID='".$jobRoundID."'";
        $updateTable4 = DB::update( $sql4 );

        //$sql5  = "update task_level_art_metadata set CURRENT_ROUND='".$roundId."',CURRENT_STAGE='".$sql_task_level_metadata_update2['0']->STAGE_ID."',STATUS_ENUM_ID=42,CURRENT_ITERATION='".$iterationCount."' where ART_METADATA_ID='".$artMetaId."' ";
        $sql5  = "UPDATE task_level_metadata m, job_round jr SET m.CURRENT_STAGE = ".$sql_task_level_metadata_update2['0']->STAGE_ID.", m.CURRENT_ITERATION = ".$iterationCount." WHERE jr.JOB_ROUND_ID = ".$jobRoundID." AND m.METADATA_ID = jr.METADATA_ID AND jr.IS_ART IS NULL";
        
        $updateTable5 = DB::update( $sql5 );
        
        //update completed previous stages
        $update_deactive_qurey        =       " update job_stage set status = 24 where status = 23 and ITERATION_ID = $cur_iteration AND STAGE_SEQ >= $sequence AND JOB_ROUND_ID = $jobRoundID limit 1";
        DB::update( $update_deactive_qurey );
        
        return $active_jb_stg;
        
        return true;
   
     }
     
     public function getStageDetailByUserdefined($userDefinedId){
         
         $sql   = "select *from job_stage as js 
                                JOIN task_level_userdefined_workflow as uw ON uw.STAGE = js.STAGE_ID
                                where uw.TASK_LEVEL_USERDEFINED_WORKFLOW_ID = '$userDefinedId' order by js.ITERATION_ID desc limit 0,1 ";
         
        $response = DB::select( $sql );
        return $response;
      
     }
     
     public function getStageSequence($stageId,$roundId,$jobId,$wfId){
        
        $sql  = " SELECT uw.STAGE,uw.STAGE_SEQ
                    FROM task_level_userdefined_workflow AS uw
                    WHERE uw.JOB_ID = '$jobId' AND uw.WORKFLOW = '$wfId' AND uw.ROUND = '$roundId' AND stage = '$stageId'";
        
         $getRec        =   DB::select( $sql );
         
         if(!empty($getRec)){
             return $getRec['0']->STAGE_SEQ;
         }
         else {
             return 1;
         }
    }
    
    public function getCurrentStageDetais($metaStatusId){
        
        $sql = "select js.INPUT_QUANTITY, js.INPUT_QUANTITY as OUTPUT_QUANTITY,jr.ROUND_ID,js.STAGE_SEQ, js.ITERATION_ID,js.WORKFLOW_ID,ms.JOB_ID,js.JOB_STAGE_ID,js.STAGE_ID,jr.JOB_ROUND_ID,jr.METADATA_ID,jr.METADATA_STATUS_ID from metadata_status as ms  
                join job_round as jr on jr.METADATA_STATUS_ID = ms.ID and jr.ROUND_ID = ms.CURRENT_ROUND and jr.CURRENT_ITERATION_ID = ms.CURRENT_ITERATION
                join job_stage as js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and js.ITERATION_ID = jr.CURRENT_ITERATION_ID and jr.CURRENT_STAGE = js.STAGE_ID
                where  ms.ID = $metaStatusId ";
        
        $getRec        =   DB::select( $sql );
         
         if(!empty($getRec)){
             return $getRec['0'];
         }
         else {
             return array();
         }
    }
    
     public function getCurrentStageDetaisByMetadataId($metadataId,$roundId){
        
        $sql = "select js.INPUT_QUANTITY, js.INPUT_QUANTITY as OUTPUT_QUANTITY,jr.ROUND_ID,js.STAGE_SEQ, js.ITERATION_ID,js.WORKFLOW_ID,ms.JOB_ID,js.JOB_STAGE_ID,js.STAGE_ID,jr.JOB_ROUND_ID,jr.METADATA_ID,jr.METADATA_STATUS_ID from metadata_status as ms  
                join job_round as jr on jr.METADATA_STATUS_ID = ms.ID and jr.ROUND_ID = ms.CURRENT_ROUND and jr.CURRENT_ITERATION_ID = ms.CURRENT_ITERATION
                join job_stage as js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and js.ITERATION_ID = jr.CURRENT_ITERATION_ID and jr.CURRENT_STAGE = js.STAGE_ID
                where  ms.METADATA_ID = $metadataId and ms.CURRENT_ROUND= $roundId ";
        
        $getRec        =   DB::select( $sql );
         
         if(!empty($getRec)){
             return $getRec['0'];
         }
         else {
             return array();
         }
    }
    
    public function getJobRoundStatus($jobId, $roundId ){
        
      $sql = "  select mi.FM_ARTICLE_BM, jr.ROUND_ID, jr.`STATUS`, jr.CURRENT_STAGE, tm.METADATA_ID  from task_level_metadata as tm
                    join metadata_info as mi on mi.METADATA_ID = tm.METADATA_ID
                    left join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = $roundId and jr.IS_ART is null
                    where tm.JOB_ID = $jobId and tm.UNIT_OF_MEASURE != 556";
        
        $getRec        =   DB::select( $sql );
        
         if(!empty($getRec)){
             return $getRec['0'];
         }
         else {
             return array();
         }
    }
    
     public function getJobRoundCompleted($jobId, $roundId ){
        
      $sql = "  select mi.FM_ARTICLE_BM, jr.ROUND_ID, jr.`STATUS`, jr.CURRENT_STAGE, tm.METADATA_ID  from task_level_metadata as tm
                    join metadata_info as mi on mi.METADATA_ID = tm.METADATA_ID
                    join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = $roundId and jr.IS_ART is null and jr.`STATUS` = 24
                    where tm.JOB_ID = $jobId and tm.UNIT_OF_MEASURE != 556";
        
        $getRec        =   DB::select( $sql );
        
         if(!empty($getRec)){
             return $getRec['0'];
         }
         else {
             return array();
         }
    }
    
    public function getStageCompletedForJob($jobId, $roundId, $stageId){
        
        $sql = "select mi.FM_ARTICLE_BM, jr.ROUND_ID, jr.JOB_ROUND_ID, js.`STATUS`, js.STAGE_ID, tm.METADATA_ID  from task_level_metadata as tm
                    join metadata_info as mi on mi.METADATA_ID = tm.METADATA_ID
                    join job_round as jr on jr.METADATA_ID = tm.METADATA_ID and jr.ROUND_ID = $roundId and jr.IS_ART is null 
                    join job_stage as js on js.JOB_ROUND_ID = jr.JOB_ROUND_ID and js.ITERATION_ID = jr.CURRENT_ITERATION_ID and js.STAGE_ID = $stageId
                    where tm.JOB_ID = $jobId and tm.UNIT_OF_MEASURE != 556";
        
        $getRec        =   DB::select( $sql );
        
         if(!empty($getRec)){
             return $getRec;
         }
         else {
             return array();
         }
    }
    
    
}

