<?php 

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use App\Models\chapterPartMapModel;
use DB;
use Carbon\Carbon;
use Session;
use Config;

class metadataInfoModel extends Model 
{    
    protected $table    =   'metadata_info';
    const CREATED_AT    =   'LAST_MOD_DATE';
    const UPDATED_AT    =   'LAST_MOD_DATE';
}

