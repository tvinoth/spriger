<?php

namespace App\Jobs;
use App\Models\Ost as Ost;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Session;
use Carbon\Carbon;
use Validator;
use File;
use Log;
use Mail;

class ostEmailAlert implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $maildata;
    
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($maildata)
    {
        $this->maildata    =   $maildata;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    
    public function handle(){
        try {
            if (is_array($this->maildata)) {			
			$mailArray  =   $this->maildata;
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
					
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '3';
                        Ost\ostTrackingEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                    
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                    if(isset($mailArray['EMAIL_LOG_ID']))
                    {
                        $wheredatamail          =   ['ID'=>$mailArray['EMAIL_LOG_ID']];
                        $updatedata['STATUS']   =   '2';
                        Ost\ostTrackingEmailLogModel::where($wheredatamail)->update($updatedata);
                    }
                }
                return $Response;
            }
        } 
        catch(Exception $exception) {
            Log::useDailyFiles(storage_path().'/Api/ostmail.log');
            Log::info( json_encode( $exception->getLine() ) );
        } 
    }
    
}
