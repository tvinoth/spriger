<?php

namespace App\Jobs;
use App\Models\jobModel;
use App\Models\stageModel;
use App\Models\roundModel;
use App\Models\emailSetupStagewiseModel;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Session;
use Carbon\Carbon;
use Validator;
use File;
use Log;
use Mail;

class StageemailAlert implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    protected $maildata;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($maildata)
    {
        $this->maildata    =   $maildata;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try{
            if (is_array($this->maildata)) {
                $mailArray  =   $this->maildata;
                Mail::send($mailArray['TemplateName'], $mailArray['Data'], function ($message) use ($mailArray) {
                    $message->subject($mailArray['Subject']);
                    $message->from($mailArray['FromMail'], $mailArray['FromName']);
                    $message->to($mailArray['ToMail']);

                    if (array_key_exists('CcMail', $mailArray)) {
                        $message->cc($mailArray['CcMail']);
                    }
                    if (array_key_exists('file', $mailArray)) {
                        $message->attach($mailArray['file'],$mailArray['attachfile']);
                    }                
                    $message->getSwiftMessage();
                });

                if (Mail::failures()) {
                    $Response['Status']     =   2;
                    $Response['Msg']        =   'Failure';
                    $Response['MsgText']    =   Mail::failures();
                } else {
                    $Response['Status']     =   1;
                    $Response['Msg']        =   'Success';
                }
//                return $Response;
            }
        }
        catch( \Exception $e )
        {           
            $result         =   array('result'=>500,'errMsg'=>$e->getMessage());   
            return response()->json($result);
        }
    }
}
