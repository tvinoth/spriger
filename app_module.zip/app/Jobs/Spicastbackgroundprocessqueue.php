<?php

namespace App\Jobs;
use App\Models\productionLocationModel;
use Illuminate\Bus\Queueable;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Exception;
use App\Http\Controllers\fileHandler\ftpFileHandlerController;
use App\Models\jobModel;
use App\Models\apiSpicastModel;
use App\Models\jobInfoModel;
use App\Models\spicastProfileModel;
use Storage;
use Log;
use Session;
use Config;
use Carbon\Carbon;
use Illuminate\Support\Facades\Mail;

class Spicastbackgroundprocessqueue implements ShouldQueue
{
    use InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    protected $maildata;
    public function __construct($maildata)
    {
        //
        $this->maildata		= 	$maildata;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        
         Log::useFiles(storage_path().'/queuetest.log');
        $jobId              =   $this->maildata;
        $getlocationftp     =   productionLocationModel::doGetLocationname($jobId);
        $response           =   array('result'=>404,'status'=>0,'msg'=> 'Production file is not connecting...');
        if(count($getlocationftp)>=1)
        {
            $hostserver     =   $getlocationftp->FTP_HOST;
            $hostusername   =   $getlocationftp->FTP_USER_NAME;
            $hostpassword   =   Crypt::decryptString($getlocationftp->FTP_PASSWORD);
            $hostpath       =   $getlocationftp->FTP_PATH;
            $getbook            =   jobModel::getJobdetails($jobId);
            $getchapterfiles    =   [];
            $bookid             =   (count($getbook)>=1?$getbook->BOOK_ID:'');
            //check file exist or not
            $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
            $getdirpath         =   $crd.$hostserver.$getlocationftp->FTP_PATH.Config::get('constants.ART_DESTINATION_PATH').$bookid.'/'.Config::get('constants.ART_SOURCE_PATHS');
            $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
            $serverDirFiles     =   $ftpObj->getDirectoryFiles($getdirpath);
            $spicastfilestatus  =   (count($getbook)>=1?$getbook->SPICAST_FILE_STATUS:'');
            if($spicastfilestatus != 1)
            {
                if(count($serverDirFiles)>=1)
                {
                    $splitname          =   "";
                    $chapterfiles       =   [];
                    $chaptercount       =   [];
                    $partfiles          =   [];
                    $chapterfilesonly   =   [];
                    $fmfilesonly        =   [];
                    $bmfilesonly        =   [];
                    $partfilesonly      =   [];
                    $chapterfilesextention      =   [];
                    $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
                    $readfmfile         =   Config::get('constants.FRONT_MATTER');
                    $readbmfile         =   Config::get('constants.BACK_MATTER');
                    $readparts          =   Config::get('constants.READ_TYPEOF_PART');
                    $readchapterfile    =   Config::get('constants.READ_CHAPTER_EXTENSTION');
                    $spicastbackgroundfile  =   Config::get('constants.SPICAST_BACKGROUND_FILE');
                    $spicastbackexcelfile   =   Config::get('constants.SPICAST_EXCEL_FILE');
                    $spicastbackprofilefile =   Config::get('constants.SPICAST_PROFILE_FILE');
                    //excel file creation
                    $ftpObj->make_directory($spicastbackexcelfile);
                    //profile file creation
                    $ftpObj->make_directory($spicastbackprofilefile);
                    foreach($serverDirFiles as $key=>$jsonvalue)
                    {
                        if(strpos($jsonvalue,'/') !== 	false)
                        {
                            $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                            //read chapter
                            if(in_array(substr(strtolower($spiltchapter),0,2),$readchapterfile))
                            {
                                $chapterfilesonly[]     =   $spiltchapter;
                            }
                            //read fm
                            if(in_array(substr(strtolower($spiltchapter),0,2),$readfmfile))
                            {
                                $fmfilesonly[]          =   $spiltchapter;
                            }
                            //read bm
                            if(in_array(substr(strtolower($spiltchapter),0,2),$readbmfile))
                            {
                                $bmfilesonly[]          =   $spiltchapter;
                            }
                            //read part
                            if(in_array(substr(strtolower($spiltchapter),0,2),$readparts))
                            {
                                $partfilesonly[]        =   $spiltchapter;
                            }
                        }
                    }
                    if(count($fmfilesonly)>=1)
                    {
                        $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$fmfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                    }
                    if(count($chapterfilesonly)>=1)
                    {
                        $getchapterfiles    =   $this->doChapterfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                    }
                    if(count($bmfilesonly)>=1)
                    {
                        $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$bmfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                    }
                    if(count($partfilesonly)>=1)
                    {
                        $getchapterfiles    =   $this->dofrontbackfileCreation($bookid,$partfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword );
                    }
                    if(count($getchapterfiles)>=1)
                    {
                        $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>0);
                        $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                    }
                    if(count($getchapterfiles)== 0)
                    {
                        $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>1);
                        $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                    }
                }
                else
                {
                    $updatespicastdata  =   array('SPICAST_FILE_STATUS'=>0);
                    $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
                }
            }
            $getbook            =   jobModel::getJobdetails($jobId);
            $spicastxmlstatus   =   (count($getbook)>=1?$getbook->SPICAST_XML_STATUS:'');
            $getprofilelayout   =   (count($getbook)>=1?$getbook->LAYOUT_PROFILE:'');
            $spicastfilestatus  =   (count($getbook)>=1?$getbook->SPICAST_FILE_STATUS:'');
            $wheredata          =   array('JOB_ID'=>$jobId,'ROUND'=>Config::get('constants.ROUND_ID.S5'));
            $getspicastlastest  =   apiSpicastModel::where($wheredata)->latest()->first();
            if(empty($getprofilelayout))
            {
                $updatedata     =   array('STATUS'=>'3','REMARKS'=>'Layout not added for this book');
                if(count($getspicastlastest)>=1)
                $updatespicast  =   apiSpicastModel::where('ID',$getspicastlastest->ID)->update($updatedata);
            }
            //xml creation
            if($spicastxmlstatus !=     1 && $getprofilelayout  != '' && $spicastfilestatus  ==  1)
            {
                $xmlcreation    =   $this->doXmlcreation($jobId,$hostpath,$hostserver, $hostusername , $hostpassword );
            }
            $response           =   array('result'=>200,'status'=>1,'msg'=> 'success');
//            return $response;
        }
//        return $response;
    }
    public function failed(Exception $exception)
    {
        // Send user notification of failure, etc...
    }
    
    public function doXmlcreation($jobId,$hostpath,$hostserver, $hostusername , $hostpassword )
    {
        // Do the FTP connection
        $ftpObjlaravel      =   Storage::createFtpDriver([
                                                                                'host'     => $hostserver, 
                                                                                'username' => $hostusername,
                                                                                'password' => $hostpassword, // 
                                                                                'port'     => '21',
                                                                                'timeout'  => '30',
                                                                ]);
        $root               =   Config::get('constants.BACKSLAH_FILE_SERVER_ROOT_DIR')."\\";
        $ceroot             =   Config::get('constants.BACKSLSH_CEFILE_SERVER_ROOT_DIR');
        $castofffile        =   Config::get("constants.BACKSLAH_SPICAST_BACKGROUND_FILE")."\\";
        $castoffexcel       =   Config::get("constants.BACKSLAH_SPICAST_EXCEL_FILE");
        $castoffprofile     =   Config::get("constants.BACKSLAH_SPICAST_PROFILE_FILE");
        $baseurl            =   url('/').'/api/apiSpicastToolresponse';
        $getbook            =   jobModel::getJobdetails($jobId);
        $getchapterfiles    =   [];
        $bookid             =   (count($getbook)>=1?$getbook->BOOK_ID:'');
        $joblayout          =   (count($getbook)>=1?$getbook->LAYOUT_PROFILE:'');
        $getlayout          =   spicastProfileModel::where('SPICAST_ID',$joblayout)->first();
        $profilename        =   (count($getlayout)>=1?$getlayout->PROFILE_NAME:'');
        $clientname         =   (count($getlayout)>=1?$getlayout->CLIENT_NAME:'');
        $peemilid           =   (count($getbook)>=1?$getbook->PE_MAIL:'');
        $peemilid           =   'mohan.m@spi-global.com';
        $titlename          =   (count($getbook)>=1?$getbook->JOB_TITLE:'');
        $isbnname           =   (count($getbook)>=1?$getbook->ISSN_ONLINE:'');
        $ftp_path_          =   Config::get('serverconstants.PRE_PROCESSING_PATH');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $stagename          =   Config::get('constants.STAGE_NAME.CUC');
        $spicastemailid     =   Config::get('constants.SPICASTOFF_EMAILID');
        $spicastxmlfilename =   Config::get('constants.SPICAST_XML_FILE');
        $bccemailid         =   'mohan.m@spi-global.com';
        $chapter_path       =   $crd.$hostserver.$hostpath.$ftp_path_.$bookid.'/'.$stagename;
        $sourcepthurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castofffile.$bookid.'\\';    
        $excelpathurl       =   "\\"."\\".$hostserver.$ceroot.$root.$castoffexcel.'\\';    
        $profilepathurl     =   "\\"."\\".$hostserver.$ceroot.$root.$castoffprofile.'\\'.$spicastxmlfilename;    
        $temppathurl        =   "C:\WATCH_FOLDERS_MAGNUS\SPiCast\Temp";    
        $ftpserver          =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $serverDirallFiles  =   $ftpserver->getDirectoryFiles( $chapter_path );    
        $result             =   array('message'=>'failed');
        if(count($serverDirallFiles)>=1)
        {
            $spicast                        =   [];
            $spicast['JOB_ID']              =   $jobId;
            $spicast['SPICAST_PROFILE_ID']  =   $joblayout;
            $spicast['CLIENT_NAME']         =   $clientname;
            $spicast['SPICAST_TITLE']       =   $titlename;
            $spicast['SPICAST_ISBN']        =   $isbnname;
            $spicast['SPICAST_EMAIL']       =   $peemilid;
            $spicast['SPICAST_PATH']        =   '';
            $spicast['ROUND']               =   Config::get('constants.ROUND_ID.S5');
            $spicast['START_TIME']          =   Carbon::now();
            $spicast['created_at']          =   Carbon::now();
            $spicast['CREATED_BY']          =   Session::get('users')['user_id'];
            $storespicast                   =   apiSpicastModel::store($spicast);
            // check layout is have or not for current book
            $getlayoutprofile               =   jobInfoModel::where('JOB_ID',$jobId)->first();
            $layoutprofile                  =   (count($getlayoutprofile)>=1?$getlayoutprofile->LAYOUT_PROFILE:'');
            if(empty($layoutprofile))
            {
                $updatedata                 =   array('STATUS'=>'3','REMARKS'=>'Layout not added for this book');
                $updatespicast              =   apiSpicastModel::where('ID',$storespicast->ID)->update($updatedata);
            }
            $serverDirFiles =   taskLevelMetadataModel::getSpicastInfo($jobId);
            $xml            = 	new \XMLWriter();
            $xml->openMemory();
            $xml->startDocument();
            $xml->startElement('SPiCast');
            $xml->setIndent(true);
            //client tag
            $xml->startElement('client');
            $xml->text($clientname);
            $xml->endElement();
            //profile tag
            $xml->startElement('profile');
            $xml->text($profilename);
            $xml->endElement();
            //input tag
            $xml->startElement('input');
                $xml->startElement("sourcepath"); 
                $xml->text($sourcepthurl);
                $xml->endElement();  
                $xml->startElement("excelpath"); 
                $xml->text($sourcepthurl);
                $xml->endElement();  
                $xml->startElement("profilepath"); 
                $xml->text($profilepathurl);
                $xml->endElement();  
            $xml->endElement();
            $xml->startElement('temppath');
                $xml->text($temppathurl);
            $xml->endElement();
            //mail tag
            $xml->startElement('mail');
            $xml->writeAttribute("titleid", $jobId); 
            $xml->writeAttribute("logid", $storespicast->ID); 

                $xml->startElement("from"); 
                $xml->text($spicastemailid);
                $xml->endElement();  

                $xml->startElement("to"); 
                $xml->text($peemilid);
                $xml->endElement();  

                $xml->startElement("bcc"); 
                $xml->text($bccemailid);
                $xml->endElement();  

                $xml->startElement("subject"); 
                $xml->text($bookid);
                $xml->endElement();  

            $xml->endElement();
            
            //chapter create 
            $xml->startElement('Spicastdetails');
            foreach($serverDirFiles as $key=>$files) 
            {
                $xml->startElement("Spicast"); 
                $xml->writeAttribute("spicast_id", $files->METADATA_ID); 
                $xml->text($files->CHAPTER_NO);
                $xml->endElement();  
            }
            $xml->endElement();
            //url parameter
            $xml->startElement('Url');
            $xml->writeAttribute('value', $baseurl);
            $xml->writeAttribute('method', "post");
            $xml->endElement();

            //id parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "token");
            $xml->writeAttribute('type', "fixed");
            $xml->writeAttribute('value', $storespicast->TOKEN);
            $xml->endElement();

            //status parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "status");
            $xml->endElement();

            //end time parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "end_time");
            $xml->writeAttribute('value', "Y-m-d H:m:i");
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //jobid parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "job_id");
            $xml->writeAttribute('value', $storespicast->JOB_ID);
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //round parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "round");
            $xml->writeAttribute('value', $storespicast->ROUND);
            $xml->writeAttribute('type', "fixed");
            $xml->endElement();

            //remarks parameter
            $xml->startElement('parameter');
            $xml->writeAttribute('key', "remarks");
            $xml->writeAttribute('value', '');
            $xml->endElement();

            $xml->endElement();
            $xml->endElement();
            $xml->endDocument();

            $content 	= 	$xml->outputMemory();
            $filename 	=	$bookid.'_SPICAST.xml';
            $successfileresponse 	=	$ftpObjlaravel->put(Config::get('constants.SPICAST_WATCH_FILE').'/'.$filename, $content);
            if($successfileresponse ==     true)
            {
                $result             =   array('message'=>'success');
                $updatespicastdata  =   array('SPICAST_XML_STATUS'=>'1');
                $xmlstatusupdate    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
            }
            else
            {
                $result             =   array('message'=>'failed');
                $updatespicastdata  =   array('SPICAST_XML_STATUS'=>'0');
                $xmlstatusupdate    =   $this->doUpdatefiledfilemove($jobId,$updatespicastdata);
            }
            return $result;
        }
        return $result;
    }
    // fm and bm creation
    public function dofrontbackfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword )
    {
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
        $spicastbackgroundfile    =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $filedocxnotfound   =   []; 
        $chapterfiles       =   [];
        $result             =   [];
        foreach($chapterfilesonly as $key=>$valueoffiles)
        {
            $serverDirFiles     =   $ftpObj->getDirectoryFiles($getdirpath.$valueoffiles);
            if(count($serverDirFiles)>=1)
            {
                foreach($serverDirFiles as $key=>$jsonvalue)
                {
                    if(strpos($jsonvalue,'/') !== 	false)
                    {
                        $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                        if(strpos($spiltchapter,'.') !== false)
                        {
                            $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                            $chapterfilesextention[]=   $originalchapter;
                            if(in_array(strtolower($originalchapter),$readfileextenstion))
                            {
                                $splitname          =   explode('.',$spiltchapter);
                                if($valueoffiles    ==  trim($splitname[0]))
                                {
                                    $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                    $replacecrd     =   str_replace($crd,'',$replacecrd);
                                    $sourcefile     =   $replacecrd.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid);
                                    $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                    if($getsuccessorfile !==     true)
                                    {
                                        $result[]   =    'failed'; 
                                    }
                                }
                            }else{ $filedocxnotfound[]     =   $spiltchapter;}
                        }
                    }
                }
            }
            if(count($filedocxnotfound)>=1)
            {
                $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles);
            }
        }
        return $result;
    }
    
    //chapter cretion 
    public function doChapterfileCreation($bookid,$chapterfilesonly,$getdirpath,$hostserver, $hostusername , $hostpassword )
    {
        $ftpObj             =   new ftpFileHandlerController($hostserver, $hostusername , $hostpassword );
        $readfileextenstion =   Config::get('constants.CHAPTER_PART_READ_EXTENSTION');
        $spicastbackgroundfile    =   Config::get('constants.SPICAST_BACKGROUND_FILE');
        $crd                =   Config::get('constants.FILE_SERVER_CREDENTIALS'); 
        $spicastimgextn     =   Config::get('constants.SPICAST_IMAGE_FILEXTN'); 
        $spicastimgfilename =   Config::get('constants.SPICAST_IMAGES_FILE'); 
        $chapterfiles       =   [];
        $result             =   [];
        foreach($chapterfilesonly as $key=>$valueoffiles)
        {
            $serverDirFiles     =   $ftpObj->getDirectoryFiles($getdirpath.$valueoffiles);
            if(count($serverDirFiles)>=1)
            {
                foreach($serverDirFiles as $key=>$jsonvalue)
                {
                    if(strpos($jsonvalue,'/') !== 	false)
                    {
                        $spiltchapter           =   substr(strrchr($jsonvalue, "/"), 1);
                        if(strpos($spiltchapter,'.') !== false)
                        {
                            $originalchapter        =   substr(strrchr($spiltchapter, "."), 0);
                            $chapterfilesextention[]=   $originalchapter;
                            if(in_array(strtolower($originalchapter),$readfileextenstion))
                            {
                                $splitname          =   explode('.',$spiltchapter);
                                if($valueoffiles    ==  trim($splitname[0]))
                                {
                                    $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                    $replacecrd     =   str_replace($crd,'',$replacecrd);
                                    $sourcefile     =   $replacecrd.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.'/'.$valueoffiles.'.'.$splitname[1];
                                    $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid);
                                    $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                    if($getsuccessorfile !==     true)
                                    {
                                        $result[]   =    'failed'; 
                                    }
                                }
                            }
                            if(in_array(strtoupper($originalchapter),$spicastimgextn))
                            {
                                $splitname          =   explode('.',$spiltchapter);
                                $replacecrd     =   str_replace($hostserver.'/','',$getdirpath);
                                $replacecrd     =   str_replace($crd,'',$replacecrd);
                                $sourcefile     =   $replacecrd.$valueoffiles.'/'.$splitname[0].'.'.$splitname[1];
                                $desfile        =   $spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.$spicastimgfilename.$splitname[0].'.'.$splitname[1];
                                $ftpObj->make_directory($spicastbackgroundfile.'/'.$bookid.'/'.$valueoffiles.$spicastimgfilename);
                                $getsuccessorfile   =   $this->dofilecopyprocess($hostserver, $hostusername , $hostpassword,$sourcefile,$desfile);
                                if($getsuccessorfile !==     true)
                                {
                                    $result[]   =    'failed'; 
                                }
                                $chapterfiles[]     =   trim($splitname[0]);
                            }
                        }
                    }
                }
            }
        }
        return $result;
    }
    
    public function dofilecopyprocess($hostserver, $hostusername , $hostpassword ,$sourcefile,$desfile)
    {
        $ftplarvelObj       =   Storage::createFtpDriver([
                                                    'host'     => $hostserver, 
                                                    'username' => $hostusername,
                                                    'password' => $hostpassword, // 
                                                    'port'     => '21',
                                                    'timeout'  => '30',
                                            ]);
        if($ftplarvelObj->has($desfile))
        {
            $ftplarvelObj->delete($desfile);
            $putfile    =	$ftplarvelObj->copy($sourcefile,$desfile,0777);
        }
        else
        {
            $putfile    =	$ftplarvelObj->copy($sourcefile,$desfile,0777);
        }
        return $putfile;
    }
    public function doUpdatefiledfilemove($jobId,$updatedata    =   [])
    {
        $updatejobinfo  =   jobInfoModel::where('JOB_ID',$jobId)->update($updatedata);
        return $updatejobinfo;
    }
	
}

