/* CSRF Token set ajax header */
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

/* Alert Message */
function customerAlertMessage(title, content, type) {
    showMessage(title, content, type);
    setInterval(function () {
        hideMessage();
    }, 3000);
}

function customerAlertMessageBootbox(title, content, type) {
    if (type == "success") {
        bootbox.dialog({
            message: "<span class='bigger-110'>" + content + "</span>",
            //timeOut : 3000,
            buttons:
                    {
                        "success":
                                {
                                    "label": "Ok", //"<i class='ace-icon fa fa-check'></i> Success!",
                                    "className": "btn-sm btn-success",
                                    "callback": function () {
                                        //Example.show("great success");
                                        scrollMoveToTopFn();
                                    }
                                }
                    }

        });
    } else if (type == "error") {
        bootbox.dialog({
            message: "<span class='bigger-110'>" + content + "</span>",
            //timeOut : 3000,
            buttons:
                    {
                        "danger":
                                {
                                    "label": "Ok", //"Danger!",
                                    "className": "btn-sm btn-danger",
                                    "callback": function () {
                                        //Example.show("great success");
                                        scrollMoveToTopFn();
                                    }
                                }
                    }

        });
    } else if (type == "click") {
        bootbox.dialog({
            message: "<span class='bigger-110'>" + content + "</span>",
            //timeOut : 3000,
            buttons:
                    {
                        "click":
                                {
                                    "label": "Ok", //"Click ME!",
                                    "className": "btn-sm btn-primary",
                                    "callback": function () {
                                        //Example.show("Primary button");
                                        scrollMoveToTopFn();
                                    }
                                },
                    }
        });
    } else if (type == "button") {
        bootbox.dialog({
            message: "<span class='bigger-110'>" + content + "</span>",
            //timeOut : 3000,
            buttons:
                    {
                        "button":
                                {
                                    "label": "Ok", //"Just a button...",
                                    "className": "btn-sm"
                                }
                    }
        });
    }
    window.setTimeout(function () {
        bootbox.hideAll();
    }, 3000); // 3 seconds expressed in milliseconds
}

/* Tooltip 
 e.g., data-rel="tooltip" data-original-title="Delete All"
 */
$('[data-rel=tooltip]').tooltip();
$('[data-rel=popover]').popover({html: true});

function scrollMoveToTopFn() {
    //$(window).scrollTop(0);
    $('html, body').animate({scrollTop: 0}, 0);
    //nice and slow :)
    //$('html, body').animate({ scrollTop: 0 }, 'slow');
    $('#reasonForChange').val('');
    $('#floatUpdateBtn2').fadeOut();
    $('#floatUpdateBtn1').fadeIn();
}
