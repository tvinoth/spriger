Mockery
=======

.. toctree::
    :maxdepth: 2

    configuration
    exceptions
    reserved_method_names
    gotchas
