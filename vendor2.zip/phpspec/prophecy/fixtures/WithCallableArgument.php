<?php

namespace Fixtures\Prophecy;

class WithCallableArgument
{
    public function methodWithArgs(callable $arg_1, callable $arg_2 = null)
    {
    }
}
