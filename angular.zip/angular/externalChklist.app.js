/*
 *  Dashboard Controller
 *  This controller contains all the methods related to dashboard screen.
 */


ngApp.service('fileUpload', ['$http' , "$rootScope" , function ($http , $rootScope) {
    
        this.uploadFileToUrl = function( file, uploadUrl , data ){
        var fd = new FormData();
        fd.append('file', file);
        fd.append( 'data' , JSON.stringify( data ) );
        
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function( response ){
            $rootScope.error        =   response;
                    //deffered.resolve(response);
        })
        .error(function( response ){
            $rootScope.error        =   response;
           //deffered.reject(response);
        });
        //return deffered.promise;
    }
}]);

ngApp.directive( 'fileModel' , ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

ngApp.controller('ngController', function ( $scope  , $http , fileUpload , $timeout , $window, DTOptionsBuilder , DTColumnBuilder ) {
	
        $scope.userId = 0;
	$scope.booksCollect     =       [];
	$scope.menuChild    =   'metaExtractorUpdate';
	$scope.menuParent   =   'Pre-Production';
	$scope.customParam  =   "";
        $scope.selected_book    =   '';
        
        $scope.jobsheetStatus      =        {};
        $scope.spiContactempid      =       '';
        $scope.spiContactname       =       '' ;       
        $scope.spiEmail             =       '';
        $scope.titleName            =       '';
        $scope.metaext              =       {};
        $scope.extchklist              =       {};
        $scope.checklistquerydata   =   {};
        
        $scope.editor_fm_dates      =       false;
        $scope.author_caption       =       false;
        $scope.editor_caption       =       false;
        $scope.default_caption      =       true;
        $scope.metaext.node         =       "Remarks";
        $scope.options=1;
        $scope.bookinfo             =       {};
        $scope.metaext.metaid       =       '';
        
        $scope.errors               =       null;
        
        $scope.showXMLInModal       =       function( jobId , round, Cid  ){   

            var inp = { jobId: jobId };

            $('#show-edit').trigger('click');
            $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
            if(Cid == ''){
                urlpost     =   API_URL + "getJobXMLInfo/"+jobId+'/'+round;
            }else{
                 urlpost     =   API_URL + "getJobXMLInfo/"+jobId+'/'+round+'/'+Cid;
            }
            $http({
                    url: urlpost,
                    method: 'GET',
                 })
                .success(function(response) {
                     var size = {width: $(window).width() , height: $(window).height() };

                    /*CALCULATE SIZE*/
                    var offset = 20;
                    var offsetBody = 150;
                    $('#modal-preview').css('height', size.height - offset );
                    $('.modal-body,#xmlContent').css('height', size.height - (offset + offsetBody));
                    $('#modal-preview').css('top', 0);
                    $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                    $('#xmlContent').html(response);

                })
                .error(function(response) {
                    console.log(response);
                });

        };
        
        $scope.showFormErrors       =       function( errors ){
            for (var property1 in errors) {
                $( '.'+property1+'_help' ).text( errors[property1] );
                $( '.'+property1+'_help' ).parents('.form-group').addClass('has-error');
            }
        };    
        
        $scope.resetForm            =       function( formobj ){
            $scope.metaext = {};

            $('.chosen-select')
            .find('option:first-child').prop('selected', true)
            .end().trigger('chosen:updated');
            
            $('#selectNode').removeAttr('disabled');
            $('#instruction').removeAttr('disabled');
             $("#metaupdatebutton").removeAttr('disabled');
            $('#metaidselect > option').remove();
            $('.chosen-select').chosen({});  
             
        };
        
        $scope.bookidwrng   =   "";
        
        $scope.contentloadtimer             =   1;
        
        $scope.getChecklistData =   function( jbid ){
            
            hideLoader();
            
            $http.get( API_URL+"getJobLevelExterchecklist/"+jbid ).then(function mySuccess(response) {    
               
               if(response.data.status == 1){
                   
                   $scope.checklistquerydata =   response.data.data;
                   console.log( $scope.checklistquerydata );
                   
               }else{
                   
                   showNotify( 'Invalid try' );
                   
               }
              
               console.log( $scope.checklistquerydata );
               return false;
               
            },function myError(response) {
                
                showNotify( 'Kindly reload the page' );
               
            });  
            
        };    
        
        $(document).ready(function () {
        
            $( "input,select" ).focus(function() {
                $('.help-block').text('');
                $('.help-block').parents('.form-group').removeClass('has-error');
            });
		
            $("#bookidselect").chosen().change(function() {
                
                var jbid    =   $(this).val();
                showLoader();
                showNotify( 'Please wait for a while' );
                if( jbid != '' ){
                    
                    $http.get( API_URL+"getBookInfoByJoid/"+jbid ).then(function mySuccess(response) {    

                       var bookinfo       =       response.data.bookinfo;
                       bookinfo           =       bookinfo[0];
                       $scope.bookinfo    =       bookinfo;
					   
                       $scope.extchklist.jobId          =       jbid;
                       $scope.extchklist.bookId         =       bookinfo.bookId;
                       $scope.extchklist.bookTitle      =       bookinfo.bookTitle;
                       $scope.extchklist.printIssn      =       bookinfo.printIssn;
                       
                        $scope.getChecklistData( jbid );
                       
                    },function myError(response) {
                         
                    });   
                    
                }
                
            });
       
       
        });
        
        $scope.showMeataextratorremarksview = 	function(params){   

             var printMsg    =   ( params.UPDATE_REMARKS == null ) ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
                
        //show meta extrator remarks commands
        
        $scope.showUploadRemarksview = 	function(params){   
             var printMsg    =   ( params.UPLOAD_REMARKS == null ) ? 'remarks not found..' : params.UPLOAD_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Uploade";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	

       $scope.queryChecklistInsert = function( forms ){
          
            showLoader( 'Please wait update is in progress' );
		
            var chckOpt     =   $('input[name="queryMandatory[]"]').map(function(){return ( $(this).is(':checked') > 0 ) ? 1:0;}).get();
            var chkqryid    =   $('input[name="queryId[]"]').map(function(){return $(this).val();}).get();
            var corrctn     =   $('select[name="correction_yn[]"]').map(function(){return $(this).val();}).get();
            var coments     =   $('input[name="comments[]"]').map(function(){return $(this).val();}).get();
                
            var chkoptfilled   =   $('input[name="queryMandatory[]:checked"]').map(function(){return $(this).val();}).get();
            var chkoptvalue    =   $('input[name="queryMandatory[]"]').map(function(){return ( $(this).attr('data-chk') == 'Y' ) ? 1: 0;}).get();
            var chkoptmanda    =   $('input[data-chk="data-chk"]').map(function(){return $(this).val();}).get();
            
            console.log( chkoptfilled );
            console.log( chkoptmanda );
            console.log( chkoptvalue );
			 
           forms['chckOpt']     	=   chckOpt;       
           forms['chkqryid']    	=   chkqryid;       
           forms['corrctn']     	=   corrctn;       
           forms['coments']     	=   coments;       
           forms['chkoptmanda']     =   chkoptvalue;       
           
            $http.post( BASE_URL+"storeExternalChecklist" , forms ) .then( function mySuccess( response ){
                
                if( response.data.status == 1 ){
                    $scope.resetForm( forms );
                    showNotify( response.data.errMsg  , 'success' );
                }
                
                if( response.data.status == 0 ){
                    showNotify( response.data.errMsg  , 'danger' );
                }
                
                setTimeout( function(){   hideLoader();  } , 3000 );
                
               
            },function myError( response ){
                
                hideLoader();
                
                if( response.data.status == 0 ){

                    $scope.errors           =           response.data.validationerror;
                    var errors      =   $scope.errors;
                    $scope.showFormErrors( errors );                    
                    return false;
                    
                }
                
            });
           
       };
       
       $scope.previewChecklist = function( inpobj ){
           
           showLoader('Initiate preview');
           
           $http.post( API_URL+"previewChecklistpdf" , inpobj ) .then( function mySuccess( response ){
                
                if( response.data.status == 1 ){
                    $scope.resetForm( inpobj );
                    showNotify( response.data.errMsg  , 'success' );
                }
                
                if( response.data.status == 0 ){
                    showNotify( response.data.errMsg  , 'danger' );
                }
                
                setTimeout( function(){   hideLoader();  } , 3000 );
                
               
            },function myError(response){
                
                hideLoader();
                
                if( response.data.status == 0 ){

                    $scope.errors           =           response.data.validationerror;
                    var errors      =   $scope.errors;
                    $scope.showFormErrors( errors );                    
                    return false;
                    
                }
                
            });
       };
       
});