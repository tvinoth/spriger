/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$filter, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder, $timeout,fileUploadService) 
{
	$scope.userId 		= 	0;	
 	$scope.menuParent 	= 	'Pre-Production';
	$scope.menuChild 	= 	'Castoff';
	$scope.errorMsg 	= 	"";
        if(isNaN(getUrlParameter(1))) 
        {
                $scope.JobID 	= 	"";
        } 
        else 
        {
                $scope.JobID 	= 	getUrlParameter(1);
        }
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
	$scope.getspicastinfoList 	=   function() 
	{
            $scope.spicastList         =   [];
            $http.get(BASE_URL+"spicast-joblist") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify( 'Kindly reload page error ocured.'  , 'danger' );
                }
                $scope.spicastList 	=   response.data.spicast;	
            }, 
            function myError(response) 
            {
                //showMessage('Message', 'Kindly reload page error ocured.', 'error' );
            });			
	};
        $scope.getspicastinfoList();
        
        $scope.spicastdetail 	= 	function() 
        {
            $scope.castoffprofile 	= 	[];
            var inp             =       {   jodId:$scope.JobID  }
            $http.post(BASE_URL+"spicast_profile",inp) .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify( 'Kindly reload page error ocured.'  , 'danger' );
                }
                $scope.clientname       =   "Springer";
                $scope.castoffprofile   =   response.data.profiles;
                $scope.isbnname         =   response.data.ISSN_ONLINE;
                $scope.titlename        =   response.data.book_title;
                $scope.authoremailid    =   response.data.AUTHOR_EMAIL;
            }, 
            function myError(response) {
//                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
            });			
        };
        $scope.spicastdetail();
        
        $scope.addCastoff               =   function()
        {
            var exelFile                =   $scope.myFile;
            showLoader('Please wait while send File...'); 
            var uploadUrl               =   BASE_URL+"spicast-joblist/"+$scope.JobID;
            promise                     =   fileUploadService.uploadFileToUrl(exelFile,$scope.clientname,$scope.titlename,$scope.isbnname,$scope.authoremailid,$scope.profilename, uploadUrl);
            promise.then(function (response) 
            {
                if(response.data.result     ==  400)
                {
                    hideLoader();
//                    angular.forEach(response.data.validation, function(value, key) {
//                        console.log(key + ': ' + value);
//                    });
                    showNotify( response.data.errMsg, 'danger' );
//                    $scope.showvalidationerror   =   response.data.validation;
                }
                if(response.data.result  ==  200)
                {
                    $scope.submitbutton         =   true;
                    $timeout( function()
                    {
                        window.location.href    =    BASE_URL+'spicast';
                    } , 3000 );
                    showNotify(response.data.errMsg  , 'success' );
                }
                hideLoader();
            }, function (errorresponse) 
            {
                hideLoader();
                if(errorresponse.data.errMsg)
                {
                    showNotify(errorresponse.data.errMsg  , 'danger' );
                }
            });		
        }
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
	$scope.spicastdetails       = 	function(book) 
	{
            $window.location.href   = 	BASE_URL+"spicast-joblist/"+book.JOB_ID;
	};	
});
    
ngApp.directive('demoFileModel', function ($parse) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) 
        {
            var model 	= 	$parse(attrs.demoFileModel),
            modelSetter     = 	model.assign; //define a setter for demoFileModel
            //Bind change event on the element
            element.bind('change', function ($scope) 
                            {
                //Call apply on scope, it checks for value changes and reflect them on UI
                scope.$apply(function () {
//                        if (element[0].files[0].size > 5240) 
//                        {
//                            alert("File size is larze; maximum file size 5240 KB");
//                            return false;
//                        }
                    //set the model value
                    modelSetter(scope, element[0].files[0]);
                    $scope.bookmapUploadMsg 	=	'';
                });
            });
        }
    };
});

ngApp.service('fileUploadService', function ($http, $q) 
{
        this.uploadFileToUrl 	= 	function (file,clientname,titile,isbnname,authoremailid,profilenme, uploadUrl) 
        {
            var fileFormData 	= 	new FormData();
            fileFormData.append('spicastfile', file);
            fileFormData.append('clientname', clientname);
            fileFormData.append('profilename', profilenme);
            fileFormData.append('titlename', titile);
            fileFormData.append('isbnname', isbnname);
            fileFormData.append('authoremailid', authoremailid);

            var deffered 		= 	$q.defer();
            $http.post(uploadUrl, fileFormData, 
            {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}

            }).then(function mySuccess(response) 
            {
                deffered.resolve(response);

            },
            function myError(response) 
            {
                deffered.reject(response);
            });
            return deffered.promise;
        }
    });