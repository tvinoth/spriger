/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('searchround', function ($scope, $rootScope, $q, $http, $timeout, $window, $compile ,DTOptionsBuilder, DTColumnBuilder)
{
    $scope.searchroundchangedetails = function (){
        
        if (($scope.searchrounddownload == '' || $scope.searchrounddownload == undefined)) {
            return false;
        }
        
        if ($scope.searchrounddownload == 104 || $scope.searchrounddownload == 114) {
            //$window.location.href = BASE_URL + 'download-list_demo';
            $window.location.href = BASE_URL + 'download-list';
        }else if ( $scope.searchrounddownload == 119 ) {
            $window.location.href = BASE_URL + 'download-list/119';
        }else if ($scope.searchrounddownload == 116) {
            $window.location.href = BASE_URL + 'chapter_download_list/116';
        }else if ($scope.searchrounddownload == 118) {
            $window.location.href = BASE_URL + 'chapter_download_list_eproof/118';
        }else if ($scope.searchrounddownload == 120 ) {
            $window.location.href = BASE_URL + 'download-list/120';
        }else{
            $window.location.href = BASE_URL + 'download-index';
        }
        
    };
    
    function formatDate() {
        date = new Date();
        var year = date.getFullYear(),
        month = date.getMonth() + 1, // months are zero indexed
        day = date.getDate(),
        hour = date.getHours(),
        minute = date.getMinutes(),
        second = 48;date.getSeconds(),
        hourFormatted = hour % 12 || 12, // hour returned in 24 hour format
        minuteFormatted = minute < 10 ? "0" + minute : minute,
        morning = hour < 12 ? "am" : "pm";
        hourFormatted = hourFormatted < 10 ? "0" + hourFormatted : hourFormatted;
        return  year+"-0"+month+"-" +day+" "+hourFormatted+":"+minuteFormatted+":"+(second);
}

function formatDate2() {
        date = new Date();
        var year = date.getFullYear(),
        month = date.getMonth() + 1, // months are zero indexed
        day = date.getDate(),
        hour = date.getHours(),
        minute = date.getMinutes(),
        second = 23;date.getSeconds(),
        hourFormatted = hour % 12 || 12, // hour returned in 24 hour format
        minuteFormatted = minute < 10 ? "0" + minute : minute,
        morning = hour < 12 ? "am" : "pm";
        hourFormatted = hourFormatted < 10 ? "0" + hourFormatted : hourFormatted;
        return  year+"-0"+month+"-" +day+" "+hourFormatted+":"+minuteFormatted+":"+(second);
}

    $(document).ready(function () {
        
        console.log(location.pathname)
        if( location.pathname == '/Magnus/download-list_demo' )
            setTimeout(function(){ demoUpdateChange( 1 ); }, 3000);
        
        var objectre             =     'BookTitleID=345913_EditionNumber=1_Language=En_2018-12-14_13-16-16.zip:Failure: failed to upload the file at 9 attempt';
        var upload_suc            =    '<span><span><i class="fa fa-check green" aria-hidden="true"></i><code class="green"> - JS Update</code></span>&nbsp;&nbsp;<span><i class="fa fa-check green" aria-hidden="true"></i><code class="green"> - JS Upload</code></span></span>';
        var inprogrUpdate         =    '<span class="update_in"  style="display:none"><i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - JS Update </code></span>&nbsp;&nbsp;';
        var inprogrUpload         =    '<span><i class="fa fa-check green" aria-hidden="true"></i><code class="green"> - JS Update</code></span>&nbsp;&nbsp;<span class="upload_in" style="display:none"><i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - JS Upload </code></span>';
        var failedUpload         =   '<span><i class="fa fa-check green" aria-hidden="true"></i><code class="green"> - JS Update</code></span><br><i class="fa fa-close red" style="font-size:20px"></i> &nbsp;&nbsp;<i class="fa fa-info bigger-120 blue fa-1x pointer" ng-click="showMeataextratorremarksview(&quot;'+objectre+'&quot;)"></i>&nbsp; &nbsp; <i class="fa fa-repeat bigger-100 blue fa-1x pointer" ng-click="retryJobsheetUpload(item)" aria-hidden="true"></i><code> - JS Upload</code></span>';
        var inprogrcliAck         =    '<span style="display:none" class="cliack_in"><i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code></span>';
        var cliSuc                =    '<span class="cliack_suc" style="display:none"><i class="fa fa-check green" aria-hidden="true"></i><i class="fa fa-eye bigger-120 blue pointer" class="client_ack_view" ng-click="showSuccessredologviewdemo(&quot;success&quot;,item , &quot;demo&quot; )"></i></span>';
        var prdloc                 =    '<select name="location_id" class="form-control pointer prd_suc" ng-model="location_id" style="displa:none" ng-change="chgPrdLoc(2 , '+[]+' )">'+
                                            '<option disabled="" selected="" value="">-- select --</option>'
                                            +'<option value="1"> CHENNAI_ADYAR</option>'
                                           +'<option value="2"> CHENNAI_DLF</option>'
                                            +'<option value="3"> PONDY</option>'
                                            +'</select>';
        
        var secondPro       =   '<tr style="display:none" class="secodpro"><td >345913_1_En&nbsp;  <br><span class="label label-sm label-success arrowed-in pull-left ng-binding">&nbsp;S5&nbsp;- Regular</td>'                                                
                                    +'<td class="ng-binding">Ethnic Diversities, Hypertension and Global Cardiovascular Risk</td>'
                                    +'<td class="ng-binding">978-1-5939-7638-8</td>'
                                    +'<td>MOHAN M</td>'
                                    +'<td class="ng-scope">'
                                    +'<span class="ng-binding ng-scope">Ananth B</span></td>'
                                    +'<td>'+'<i class="fa fa-check green" aria-hidden="true"></i><code class="green"> - JS Upload</code></span></span></td><td></td><td><span></span></td>'
                                    +'<td class="ng-binding ng-scope">'+formatDate2()+'</td>' 
                                     +'<td class="ng-scope"><span> 2019-03-15 09:12:46 </span></td><td><span ng-if="item.JOB_SHEET_UPDATE == null" class="ng-scope">--</span></td></tr>';
                                        
        var tableidselect        =   '#DataTables_Table_0';
        
        function demoUpdateChange( row ){
            
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")" );
            $(firstrow).children('td:nth-child(9)').html( formatDate() );
            $(firstrow).children('td:nth-child(6)').html( inprogrUpdate );
            $(firstrow).children('td:nth-child(7)').html( '--' );
            $('.update_in').show(800);
           
            setTimeout(function(){ demoUploadChange( row  ); }, 10000);
        }
        
        function demoUploadChange( row ){
            
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            var appendElem      =   $(firstrow).children('td:nth-child(6)').html( inprogrUpload );
            $('.upload_in').show(300);
            initiatesecondprcs();
            setTimeout(function(){  clientAckChange( row ); }, 10000);            
        }
        
        function clientAckChange( row ){
            row =   2;
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            var appendElem      =   $(firstrow).children('td:nth-child(6)').html( upload_suc );
            var appendElem2      =   $(firstrow).children('td:nth-child(7)').html( inprogrcliAck );
            $('.cliack_in').show(500);
            setTimeout(function(){  productionChange(row); }, 8000);
        }
        
        function productionChange(row){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            cliSuc      =  $compile(cliSuc)($scope);
            prdloc      =  $compile(prdloc)($scope);
            var appendElem      =   $(firstrow).children('td:nth-child(7)').html('').append( cliSuc );
            var appendElem3      =   $(firstrow).children('td:nth-child(8)').html( prdloc );
            $('.cliack_suc').show(500);
            $('.prd_suc').show(700);
            
        }
        
        
        function initiatesecondprcs(){            
            var tbodyelm = $(tableidselect).children('tbody');
            $( tbodyelm ).prepend( secondPro );
            $('.secodpro').slideDown(800);
            demoUpdateChange2(1);
        }
        
        function demoUpdateChange2( row ){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")" );
            $(firstrow).children('td:nth-child(6)').html( inprogrUpdate );
            $(firstrow).children('td:nth-child(7)').html( '--' );
            $('.update_in').show(800);
            setTimeout(function(){ demoUploadChange2( row  ); }, 10000);
        }
        
        function demoUploadChange2( row ){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            var appendElem      =   $(firstrow).children('td:nth-child(6)').html( inprogrUpload );
            $('.upload_in').show(300);
            
            setTimeout(function(){  uploadFailed( row ); }, 5000);            
        }
        
        function uploadFailed( row ){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            failedUpload         =  $compile(failedUpload)($scope);
            var appendElem      =   $(firstrow).children('td:nth-child(6)').html( failedUpload );
            //$('.failed_in').show(500);
            
        }
        
        function clientAckChange2( row ){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            var appendElem      =   $(firstrow).children('td:nth-child(6)').html( upload_suc );
            var appendElem2      =   $(firstrow).children('td:nth-child(7)').html( inprogrcliAck );
            $('.cliack_in').show(500);
            setTimeout(function(){  productionChange2(row); }, 8000);
        }
        
        function productionChange2(row){
            var firstrow    =       $(tableidselect).children('tbody').children("tr:nth-child("+row+")");
            cliSuc      =  $compile(cliSuc)($scope);
            var appendElem      =   $(firstrow).children('td:nth-child(7)').html('').append( cliSuc );
            var appendElem3      =   $(firstrow).children('td:nth-child(8)').html( prdloc );
            $('.cliack_suc').show(500);
            $('.prd_suc').show(700);
            
        }
        
        
    });



});
    