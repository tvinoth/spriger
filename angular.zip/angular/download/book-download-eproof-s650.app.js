/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
/*var iss         =   angular.element("#taps_"+item).val();
                                var fruitName   =   $.grep(PROCESS_TYPE, function (fruit) {
                                    return fruit.id == iss;
                                })[0].name;*/
ngApp.controller('ngController', function ( $scope , $http ,$q, $rootScope ,$filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
    
    $scope.projectList 	=   [];
    $scope.showProject 	=   false;
    $scope.menuParent 	=   'Download';
    $scope.menuChild  	=   'Chapter Eproof Download';
	
    $scope.noOfAttemptsToCheckIndesign  =   10;
    
    if(isNaN(getUrlParameter(1))){
        $scope.searchrounddownload  =   "";
    }else{
        $scope.searchrounddownload  =   getUrlParameter(1);
    }
    
    showLoader();   
    
    $scope.contentloadtimer     =   1;
    
    $scope.getDownloadFailedList    =   function( ){
        
        var input   =   { id : '' };
        $scope.downloadFailed  =   null;
        $http.get(  BASE_URL+"getChapterdownloadFailedList/120" , input ) .then(
             
             function mySuccess( response ){  
                   $scope.downloadFailed    =   response.data.downloadfailed; 
                   $scope.processtypes      =   PROCESS_TYPE; 
             } ,              
             function myError( response ){ 
                 if($scope.contentloadtimer    <  10){
                    $scope.getDownloadFailedList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                $scope.contentloadtimer++;
             }
        );

    }
  
    $scope.triggerEproof        =       function( jobid , metaid , round, EPROOFING_SYSTEM ){
       
        $scope.proofingStatus   =   $("#proofingStatus_"+metaid+'_'+round).val();
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {     
            
            //if( result && ($scope.proofingStatus     !=  '' && $scope.proofingStatus     !=  '0')){ 
                
                showLoader();
                var input   =   { id : '' };
                $scope.downloadFailed  =   null;
                
                $http.get(  BASE_URL+"doeproofpackagecreateBook/"+jobid+"/"+round ) .then(
                     function mySuccess( response ){
                         
                        if( response.data.status == 1 ){
                            
                            hideLoader();        
                            var appenddata  =   '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - packaging</code>';
                            //angular.element(".eproferrorres_"+metaid).remove();
                            //angular.element("#eproofresponse_"+metaid).append(appenddata);
                            showNotify( response.data.errMsg , 'success' );
                            //$scope.timeChangesUpdate();
                            
                        }else if( response.data.status == 401 ){    
                            
                            $scope.errorshow    =   true;
                            $scope.shownotavaiablechapter   =   response.data.errMsg;
                            
                        }else if( response.data.status == 0 ){ 
                            
                            showNotify( response.data.errMsg , 'danger' );
                            
                        }else{
                            
                            showNotify(  'Eproof packgae creation request got failed.' , 'danger' );
                            console.log( response.data );
                            $scope.timeChangesUpdate();
                            
                        }
                        
                        hideLoader(); 
                        
                     } , 
                     function myError( response ){
                         
                        hideLoader(); 
                        
                     });
                

            //}else{
            //    $("#proofingStatus_"+metaid+'_'+round).val(EPROOFING_SYSTEM);
            //}
        
        });
        
    }
    
    $scope.retryMetaExtractor = function( item ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
           
           if(result){
               
               var inp      =      {  book_id : item.BOOK_ID  };
               
               $http.post( BASE_URL+'' , inp ).then( function mySuccess( response ){
                   
                   
                   
               }, 
               function myError(response) {
                    console.log(response);
                   // showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
           }
            
        });
    
    }

    $scope.contentloadtimer     =   1;
    
    $scope.jobassigned     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('processing', true).withOption('order', []);
        
        var input   		= 	{ round : '120' };
        
        $http.get(  BASE_URL+"s650ChapterlevelCorrectionDownload/120" , input ) .then(function mySuccess( response ){  
            
            $scope.jobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
            $scope.pmuserlist    =   response.data.pmUserList;
            
        } , function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;
        });
        
    }   
    
    $scope.s650download     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('processing', true).withOption('order', []);
        
        var input   		= 	{ round : '120' };
        
        $http.get(  BASE_URL+"gets650DownloadList/120" , input ) .then(function mySuccess( response ){  
            
            $scope.s650downloadlist   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
            $scope.pmuserlist    =   response.data.pmUserList;
            
        } , function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;
        });
        
    }   

    $scope.s650download();
        
    $scope.packagefileUploadEproof    =   function(params){
        
        console.log( params );
        params.type=	'eproof';
 
		showLoader('Please wait while opening...');  
		showNotify( 'File Transfer Initialized...' , 'success' );

        $http.post( BASE_URL+"packageFileTransferS650Eproof" , params ).then(function mySuccess(response) {

			if( response.data.status == 1 ){
				showNotify('am ok to proceed');
				$scope.retryEproofS650(params);				
			}

			if( response.data.status == 0 ){   
				showNotify( response.data.errMsg , 'danger' );
			}
			if( response.data.status == 500 ){   
				hideLoader();
				showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );
			}

        }, 
        function myError(response) {
		
			hideLoader();
			console.log(response);
			showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );
			
        });  

			
    };
    
    var dummyrec;
    $scope.contentloadtimer     =   1;
    $scope.jobassigned2     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('processing', true).withOption('order', []);
        var input   		= 	{ round : '118' };
        $scope.jobassigned  =   dummyrec;    
        //showLoader();
        $http.get(  BASE_URL+"chapterlevelassignedlisteproof/118" , input ) .then(function mySuccess( response ){  
            dummyrec    =   $scope.jobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
            $scope.pmuserlist    =   response.data.pmUserList;
            //hideLoader();
        } ,
        function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned2();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;
            $('.reducing_time').val(-1);
        });
        
    }
    
    $scope.jobassignedPagination     	=   function(){
        
       /* $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
        
        var input   		= 	{ round : '118' };
        
        $scope.jobassigned  =   null;     
        
        $http.get(  BASE_URL+"chapterlevelassignedlisteproofPagination/118" , input ) .then(function mySuccess( response ){  
            $scope.jobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
            $scope.pmuserlist    =   response.data.pmUserList;
        } ,
        function myError( response ){ 
            //showMessage('Message', 'Oops , something went wrong try again after sometimes.'   ); 
        });
        
        */
       
         $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url:    API_URL + "chapterlevelassignedlisteproofPagination",
                            type: 'POST'
                        })
                        //.withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('SECTION_NAME').withTitle('Service Group'),
                     DTColumnBuilder.newColumn('ITEM_NAME').withTitle('Line Item'),
                     DTColumnBuilder.newColumn('ROUND_NAME').withTitle('Stage'),
                    DTColumnBuilder.newColumn('STAGE_NAME').withTitle('Process'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                
                $scope.dtInstance = {};
                
                
                
    }
    
    $scope.assignAm = function(pmselect,item)
    {   
       
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {        
            if( result ){                
                showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect  , book_id : item.BOOK_ID };
                    
                    $http.post( API_URL+"jobassignAm" , inp ).then(function mySuccess(response) {
                        hideLoader();
                          
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                              
                            //$scope.showProjectList();
                        //showMessage('Message', response.data , response.data );
                        
                    },function myError(response) {
                        console.log(response);
                        //showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
            }
        });
    }
    //TAPS SIGNALING
    $scope.tapsType     =   function(item)
    {   
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {     
            if( result )
            {                
                showLoader( 'please wait for a while...' );
                var inp     =   {	
                                    jobId : item.JOB_ID, 
                                    metadataId : item.METADATA_ID,
                                    tapsstype:angular.element("#taps_"+item.METADATA_ID).val(),
                                    ChapterNo : item.CHAPTER_NO ,
                                    ChapterTitle : item.CHAPTER_TITLE,
                                    roundid :item.ROUND_ID
                                };  
                                
                    $http.post(API_URL+"domovenonTaps", inp ).then(function mySuccess(response) 
                    {
                        hideLoader();
                        if( response.data.status == 1 ){
                            
                            var appenddata  =   '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for womat response</code>';
                            angular.element(".tapserrorres_"+item.METADATA_ID).remove();
                            angular.element("#tapsresponse_"+item.METADATA_ID).append(appenddata);
                            showNotify( response.data.errMsg , 'success' );
                        }
                        if( response.data.status == 401 ){    
                            $scope.errorshow    =   true;
                            $scope.shownotavaiablechapter   =   response.data.errMsg;
                        }

                        if( response.data.status == 0 ){                                 
                            showNotify( response.data.errMsg , 'danger' );
                        }
                    },function myError(response) {
                        hideLoader();
                        showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
                });
            }
            
        });
    }
        
		
    $scope.retryEproofS650 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "doeproofpackagecreateBook/"+jobid+'/'+params.ROUND_ID+'/package';
       	
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {
              
               $timeout( function(){
                    
                  hideLoader();                    
                  showNotify( response.data.errMsg , 'success' );
                  $timeout( function(){  
						$window.location.reload();
                  }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
	
    $scope.showXMLInModal   =   function(item) 
    {     
        var inp             = 	{
                                        jobId       :   item.JOB_ID,
                                        metadataid  :   item.METADATA_ID,
                                        Chapter     :   item.CHAPTER_NO,
                                        bookid      :   item.BOOK_ID,
                                        roundid     :   item.ROUND_ID
                                    };
        $scope.htmlcon      =   "S650 Jobsheet XML Information";
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http.get( API_URL + "getJobXMLInfo/"+item.JOB_ID+"/"+item.ROUND_ID)
        .success(function(response) 
        {
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('#xmlContent2').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('#xmlContent2').html(response);
            }
            else
            {
                $('#xmlContent2').html('<p class="text-center">'+response+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent2').html(response.errMsg);
        });
    }
    
        
    $scope.showXMLInModal2   =   function(item) 
    {     
        var inp             = 	{
                                        jobId       :   item.JOB_ID,
                                        metadataid  :   item.METADATA_ID,
                                        Chapter     :   item.CHAPTER_NO,
                                        bookid      :   item.BOOK_ID,
                                        roundid     :   item.ROUND_ID
                                    };
        $scope.htmlcon      =   "Correction Jobsheet Information";
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
                url         :   API_URL + "getChapterjobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('#xmlContent').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $('#xmlContent').html('<p class="text-center">'+response.errMsg+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    
    $scope.showMeataextratorremarksview = 	function(params , levels){   
       console.log(params);
       var index_pre    =   'UPDATE_REMARKS'+levels;
       index_pre = index_pre.trim();
       var printMsg    =   ( params[index_pre] == null || params[index_pre] == '') ? 'remarks not found..' :  params[index_pre];
       var msg= "";
        
          // printMsg = printMsg.replace(/\r\n/g, '<br />').replace(/[\r\n]/g, '<br />');
        // if(printMsg.search('/\r\n/')){
  // var n = printMsg.indexOf("\r\n");
            // var s = printMsg.substring(1,10);
            // console.log(s);
            // console.log(n);
        // }
       $('#show-redo').trigger('click');
       if(levels    ==  ""){
           
       }
       $scope.Msgbox 	=	"Message";
       $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
       
    };
            
    //show meta extrator remarks commands
    $scope.showUploadRemarksview = 	function(params , levels ){   
         var index_pre    =   'UPLOAD_REMARKS'+levels;
       index_pre = index_pre.trim();
         var printMsg    =   ( params[index_pre] == null || params[index_pre] == '' ) ? 'remarks not found..' : params[index_pre];
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Message";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };	
   
    $scope.sendRedoExtration 			= 	function(params){   
            
           console.log( params );
           var printMsg    =   ( params.REMARKS == null || params.REMARKS == '' ) ? 'remarks not found..' : params.REMARKS;
           $('#show-redo').trigger('click');
           $scope.Msgbox 	=	"Success Redo";
           $('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
    
    $scope.showRedoview =   function(params){
             var printMsg    =   ( params.SR_REMARKS == null || params.SR_REMARKS == '' ) ? 'remarks not found..' : params.SR_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Client Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
    
    $scope.showTapsremarks =   function(params){
        var printMsg    =   ( params.TAPS_REMARKS == null || params.TAPS_REMARKS == '' ) ? 'remarks not found..' : params.TAPS_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Taps Acknowledgement";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    }
    
    $scope.showSuccessredologview   =   function(typeoflog,item , clientackKey ){
        var index_pre    =   clientackKey;
        index_pre = clientackKey.trim();
        console.log( item );
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:       item[index_pre],
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID
                        };
           
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1){      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            }else{
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    $scope.retryEproof 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "doeproofpackagecreate/"+jobid+'/'+params.METADATA_ID+'/'+params.ROUND_ID+'/package';
       	
       $http.get(API_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {
              
               $timeout( function(){
                   
                  hideLoader();                    
                  showNotify( response.data.errMsg , 'success' );
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
      
    $scope.retryJobsheetUpdate 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/NOTIFICATION';   

       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {      

              $timeout( function(){  
                hideLoader();
                showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.REMARKS , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };

    $scope.retryJobsheetCorrectionUpdate 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/CORRECTION';   
       
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {      

              $timeout( function(){  
                hideLoader();
                if( response.data.REMARKS == 'Failure' ){
                    showNotify( 'Jobsheet update response is :'+response.data.REMARKS , 'danger' );
                }
                else{
                   showNotify( 'Jobsheet update response is :'+response.data.REMARKS , 'success' );
                }
                
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.REMARKS , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
    $scope.retryEproofUpload        =   function( params ){
      
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();
       
        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "eproofpackaginguploadS650/"+params.JOB_ID+'/'+params.ROUND_ID;      

        $http.get(API_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             console.log(response);
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

    };
    
    $scope.retryJobsheetUpload 			= 	function(params){   
          
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();
       
        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/NOTIFICATION';      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             console.log(response);
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

    };
    
    $scope.retryJobsheetCorrectionUpload 			= 	function(params){   
          
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();
       
        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/CORRECTION';      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             console.log(response);
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

    };
    
    $scope.sendRedo = function(params){   
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {
            if(result) 
            {
                var inp 	= 	{ jobID: params.JOB_ID};
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success Redo";
                $('#redofailed').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $http({
                                url: BASE_URL + "retrySuccessRedo",
                                method: 'post',
                                data:inp
                         })
                        .success(function(response) {
                                $('#redofailed').html(response);
                        })
                        .error(function(response) {

                        });
            }
        });
    }

    $scope.getDownloadFailedList();
    
    $scope.jobassigned();
    
    $scope.contentloadtimer     =   1;
    
    $scope.getAllPrdLocations     =       function(){
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){   
                if($scope.contentloadtimer    <  10){
                    $scope.getAllPrdLocations();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                $scope.contentloadtimer++;
        });
    }
    
    $scope.getAllPrdLocations();
    
    $scope.chgPrdLoc    =       function( drpdwn , row_info ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
         $('#xmlContent1').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	    
            if( result ){
                
                var inp = {	location_id : drpdwn  , book_id : row_info.BOOK_ID ,  job_id : row_info.JOB_ID  };

                    $http.post( API_URL+"changePrdLocation" , inp ).then(function mySuccess(response) {
                        
                        $('#xmlContent1').html('');
                        showMessage('Message', response.data.errMsg , response.data.msg );               
                        
                    }, 
                    function myError(response) {
                        console.log(response);
                    });
                    
            }
             $('#xmlContent1').html('');
            
        });
        
    }
    
    $scope.contentloadtimer     =   1;
    $scope.getPmList          =       function(){     
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){  
                if($scope.contentloadtimer    <  10){
                    $scope.getPmList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
        });
        
    }
        
    $scope.assignAm = function(pmselect,item){
       
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
             
            if( result ){                
                showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect  , book_id : item.BOOK_ID };
                    
                    $http.post( API_URL+"jobassignAm" , inp ).then(function mySuccess(response) {
                        hideLoader();
                          
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                              
                            //$scope.showProjectList();
                        //showMessage('Message', response.data , response.data );
                        
                    },function myError(response) {
                        console.log(response);
                        showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
            }
            
        });
        
    }
    
    $scope.assignPm = function( pmselect,item ){
           
           bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
               if( result ){
                   showLoader( 'please wait for a while...' ); 
                   
                   
                   
                    var inp = {	user_id : pmselect, book_id : item.BOOK_ID};
                    $http.post(API_URL+"jobassignPm",inp) .then(function mySuccess(response) {
                        
                        hideLoader();                        
                        if( response.data.status == 1 ){                                 
                            showNotify( response.data.msg , 'success' );
                            $scope.retryJobsheetUpdate( item );
                        }
                        if( response.data.status == 0 ){                                 
                            showNotify( response.data.msg , 'danger' );
                        }
                        
                        /*
                         * 
                         setTimeout( function(){ 
                            $window.location.reload();
                        } , 5000 );
                        
                        */
                    }, 
                    function myError(response) {
                        hideLoader();                        
                         showNotify( 'Oops, Kindly reload the page...' , 'danger');
                    });	
                    
                }    

            });
        }
   
    hideLoader();
    
    $scope.downloadPackageZip  = function( params , type  ){
        
		if( params.METADATA_ID == null || typeof params.METADATA_ID == undefined ){
			
			var inp     =       {  job_id : params.JOB_ID , round : params.ROUND_ID , type : type };
			var apiurl		=	API_URL+"downloadPackageZipS650";
		
		}else{
			
			var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID , type : type };
			var apiurl		=	API_URL+"downloadPackageZip";
			
		}
		
        showLoader();
        $http.post( apiurl , inp ).then(function mySuccess(response) {
            if( response.data.status == 1 ){
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 ){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });
            
        
    };
    
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    };    
    
	$scope.correctionBookId = '';
	$scope.correctionMetadataId = '';
	$scope.correctionChapterNo = '';
	$scope.correctionJobId = '';
	$scope.correctionRoundName = '';
	$scope.correctionRoundId = '';
	$scope.correctionChapterTitle = '';	
	$scope.correctionDefaultChapterList = '';
	$scope.correctionDefaultChapterNo = '';
	$scope.isDisableCorrectionStageId = false;
	$scope.IsVisibleTitleWiseTable = false;
	$scope.IsVisibleChapterWiseTable = false;
	
	$scope.titleOrChapterWiseSelectedChapter = [];
		
        $scope.showManualUploadModal   =   function(item) 
    {  
	
        $scope.correctionBookId = '';
        $scope.correctionMetadataId = '';
        $scope.correctionChapterNo = '';
        $scope.correctionJobId = '';
        $scope.correctionRoundName = '';
        $scope.correctionRoundId = '';
        $scope.correctionChapterTitle = '';

        $scope.isDisableCorrectionStageId = false;
        $scope.IsVisibleTitleWiseTable = false;
        $scope.IsVisibleTitleWiseUploadBtn = false;
        $scope.IsVisibleChapterWiseUploadBtn = false;
        $scope.correctionStageId  = '';
        $scope.correctionProcessList = '';
        $scope.correctionProcessId = '';
        $scope.correctionfolderpath = '';
        $scope.mappingList = '';
        $scope.correctionChapterList = '';
        $scope.correctionChapterNo = '';
        $scope.correctionDefaultChapterList = '';
        $scope.correctionDefaultChapterNo = '';
        $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false;	
        $scope.titleOrChapterWiseSelectedChapter = [];

        $scope.chapterWise = true;
        $scope.titleWise = false;
        if($scope.titleWise){	
                $scope.htmlcon      =   "Correction File Link";	
        }else if($scope.chapterWise){
                $scope.htmlcon      =   "Correction File Link - "+item.CHAPTER_NO+"";	
        }

        $scope.submitBtnShow = false;

        var inp = {
                jobId       :   item.JOB_ID,
                /* metadataid  :   item.METADATA_ID,
                chapterno     :   item.CHAPTER_NO,
                bookid      :   item.BOOK_ID, */
                roundid     :   item.ROUND_ID/* ,
                roundname   :   item.ROUND_NAME,
                chaptertitle   :   item.CHAPTER_TITLE,
                chapterWise   :   $scope.chapterWise,
                titleWise   :   $scope.titleWise */
        };		

        $scope.correctionBookId = item.BOOK_ID;
        $scope.correctionMetadataId = item.METADATA_ID;			
        $scope.correctionJobId = item.JOB_ID;
        $scope.correctionRoundName = item.ROUND_NAME;
        $scope.correctionRoundId = item.ROUND_ID;
        $scope.correctionChapterTitle = item.CHAPTER_TITLE;
        $scope.correctionChapterNo = item.CHAPTER_NO;
        $scope.correctionDefaultChapterList = '';
        $scope.correctionDefaultChapterNo = item.CHAPTER_NO;
        $('#manualCorrectionFileUploadModal1').trigger('click');
        $http({
                url         :   API_URL + "qms/GetListStages",
                method      :   'POST',
                data        :   inp
        })
        .success(function(data, status, headers, config) 
        {
            if( status == 200 ){  
                if(data.length > 0){
                    $scope.correctionStageList = data;				

                    for (var key in $scope.correctionStageList) {
                        if($scope.correctionRoundId === $scope.correctionStageList[key].StageId){
                            $scope.correctionStageId = $scope.correctionStageList[key].StageId;
                            $scope.isDisableCorrectionStageId = true;
                        }
                    }

                    $http({
                        url         :   BASE_URL + "getProcessList",
                        method      :   'POST',
                        data        :   inp
                    })
                    .success(function(response, status, headers, config) 
                    {
                        if( status == 200 ){
                            
                            if(response.status == 1){

                                $scope.correctionProcessList = response.data;
                                $scope.correctionProcessId = '';
                                $scope.correctionfolderOrgPath = response.path;
                                $scope.loginUserId = response.userid;
                                $scope.credential = response.credential;
                                $scope.ftpfilepath = response.ftpfilePath;
                                $scope.jobId       = response.jobId;

                                $scope.mappingList = { 
                                    "0": {"id":"ProcessMapping", "desc":"Process"},
                                    "1": {"id":"BookReference", "desc":"Book Reference"},
                                    "2": {"id":"ChapterReference", "desc":"Chapter Reference"},
                                    "3": {"id":"SetProcess", "desc":"Set Process"}
                                };
                            }else{
                                hideLoader();
                                showMessage('Status', response.errMsg, 'error');
                            }
                            
                        }

                    })
                    .error(function(response) 
                    {
                            hideLoader();
                            showMessage('Status', "Please try again later.", 'error');
                    });
                }                
            }

        })
        .error(function(response) 
        {
                hideLoader();
                showMessage('Status', "Please try again later.", 'error');
        });		

    }
	
	$scope.CheckUncheckAll = function (event) {		
        for (var i = 0; i < $scope.correctionChapterList.length; i++) {			
            $scope.correctionChapterList[i].Selected = $scope.IsAllChecked;
        }
    };
	
	$scope.CheckUncheckHeader = function (event) {
        $scope.IsAllChecked = true;		
        for (var i = 0; i < $scope.correctionChapterList.length; i++) {			
            if (!$scope.correctionChapterList[i].Selected) {
                $scope.IsAllChecked = false;
                break;
            }
        };		
    };    
	
    $scope.changeCorrectionProcess = function (itm){
            if(itm && $scope.correctionProcessList.length > 0){
                    for (var i = 0; i < $scope.correctionProcessList.length; i++) {
                            if($scope.correctionProcessList[i].StageId == $scope.correctionProcessId){
                                    $scope.correctionProcessName = $scope.correctionProcessList[i].StageDescription;
                                    $scope.correctionWorkflowId = $scope.correctionProcessList[i].WORKFLOW_ID;
                                    $scope.correctionWorkflowType = $scope.correctionProcessList[i].WORKFLOW_TYPE;
                                    $scope.correctionWorkflowMasterId = $scope.correctionProcessList[i].WORKFLOW_MASTER_ID;

                                    /* $scope.correctionSrcPath = $scope.correctionProcessList[i].srcPath;
                                    $scope.correctionWrkPath = $scope.correctionProcessList[i].wrkPath;
                                    $scope.correctionDestPath = $scope.correctionProcessList[i].destPath; */

                            }
                    }
            }else{
                    $scope.correctionMappingID = '';
                    $scope.correctionProcessName = '';
                    $scope.correctionWorkflowId = '';
                    $scope.correctionWorkflowType = '';
                    $scope.correctionWorkflowMasterId = '';

                    $scope.enableOrDisableUploadBtn(false, '', '', false, false, false);
                    /* $scope.IsVisibleChapterWiseUploadBtn = false;				
                    $scope.correctionChapterList = '';
                    $scope.correctionChapterNo = '';

                    $scope.IsVisibleTitleWiseTable = false;
                    $scope.IsVisibleTitleWiseUploadBtn = false;
                    $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
            }
    }
	
    $scope.listAllChapters = function (){
            if($scope.titleWise){

                    var inp = {
                            jobId       :   $scope.correctionJobId,
                            /* metadataid  :   $scope.correctionMetadataId,
                            chapterno     :   $scope.correctionChapterNo,
                            bookid      :   $scope.correctionBookId, */
                            roundid     :   $scope.correctionRoundId,
                            /* roundname   :   $scope.correctionRoundName,
                            chaptertitle   :   $scope.correctionChapterTitle,
                            chapterWise   :   $scope.chapterWise,
                            titleWise   :   $scope.titleWise */
                    };

                    $http({
                            url         :   BASE_URL + "getAllChapters",
                            method      :   'POST',
                            data        :   inp
                    })
                    .success(function(response, status, headers, config) 
                    {
                            if( status == 200 ){  
                                    if(response.status == 1){
                                            $scope.enableOrDisableUploadBtn(false, response.data, '', true, true, false);
                                            /* $scope.IsVisibleChapterWiseUploadBtn = false;
                                            $scope.correctionChapterList = response.data;
                                            $scope.correctionChapterNo = '';
                                            $scope.IsVisibleTitleWiseTable = true;
                                            $scope.IsVisibleTitleWiseUploadBtn = true;
                                            $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
                                            /* $scope.CheckUncheckHeader(); */
                                    }else{
                                            hideLoader();
                                            showMessage('Status', response.errMsg, 'error');
                                    }              
                            }

                    })
                    .error(function(response) 
                    {
                            hideLoader();
                            showMessage('Status', "Please try again later.", 'error');
                    });
            }
    }
	
    $scope.changeCorrectionMapping = function (itm){
            if(itm){	


                    if($scope.titleWise){
                            if(itm == "BookReference"){
                                    $scope.enableOrDisableUploadBtn(false, '', '', false, false, true);
                                    /* $scope.IsVisibleChapterWiseUploadBtn = false;	
                                    $scope.correctionChapterList = '';
                                    $scope.correctionChapterNo = '';

                                    $scope.IsVisibleTitleWiseTable = false;
                                    $scope.IsVisibleTitleWiseUploadBtn = false;
                                    $scope.IsVisibleTitleWiseBookReferenceUploadBtn = true;	 */				

                            }else if(itm == "ProcessMapping" || itm == "ChapterReference"){
                                    $scope.enableOrDisableUploadBtn(false, '', '', true, true, false);
                                    /* $scope.IsVisibleChapterWiseUploadBtn = false;
                                    $scope.correctionChapterList = '';
                                    $scope.correctionChapterNo = '';						

                                    $scope.IsVisibleTitleWiseTable = true;
                                    $scope.IsVisibleTitleWiseUploadBtn = true;
                                    $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */	
                                    $scope.listAllChapters();
                            }else if(itm == "SetProcess"){

                                    $scope.IsVisibleTitleWiseUploadBtn = false;
                                    $scope.submitBtnShow = true;	
                            }
                    }else if($scope.chapterWise){

                             if(itm == "SetProcess"){
                                    $scope.IsVisibleTitleWiseUploadBtn = false;
                                    $scope.submitBtnShow = true;	
                            }else{
                            $scope.enableOrDisableUploadBtn(true, $scope.correctionDefaultChapterList, $scope.correctionDefaultChapterNo, false, false, false);
                            }
                            /* $scope.IsVisibleChapterWiseUploadBtn = true;				
                            $scope.correctionChapterList = '';
                            $scope.correctionChapterNo = '';

                            $scope.IsVisibleTitleWiseTable = false;
                            $scope.IsVisibleTitleWiseUploadBtn = false;
                            $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */	
                    }
            }else{
                    $scope.enableOrDisableUploadBtn(false, '', '', false, false, false);
                    /* $scope.IsVisibleChapterWiseUploadBtn = false;				
                    $scope.correctionChapterList = '';
                    $scope.correctionChapterNo = '';

                    $scope.IsVisibleTitleWiseTable = false;
                    $scope.IsVisibleTitleWiseUploadBtn = false;
                    $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
            }
    }

    $scope.enableOrDisableUploadBtn = function (a, b, c, d, e, f){
            $scope.IsVisibleChapterWiseUploadBtn = a;				
            $scope.correctionChapterList = b;
            $scope.correctionChapterNo = c;

            $scope.IsVisibleTitleWiseTable = d;
            $scope.IsVisibleTitleWiseUploadBtn = e;
            $scope.IsVisibleTitleWiseBookReferenceUploadBtn = f;
    }

	$scope.uploadCorrectionFile = function (currentBtn){
          //  console.log($scope.ftpfilepath);
		var result = true;
        showLoader('Please wait open folder inprogress..');
        if( result ){
			if(isEmpty($scope.correctionStageId)){
				hideLoader();
				showNotify('Please choose any one stage.', 'danger');	
			}else if (isEmpty($scope.correctionProcessId)) {
				hideLoader();
				showNotify('Please choose any one process.', 'danger');
			} else if (isEmpty($scope.correctionMappingID)) {
				hideLoader();
				showNotify('Please choose any one mapping.', 'danger');
			}else{  
				
				//var method = "doOpenDriveServer";/* "openLocalDrive";//183.140 */
				var method = "doOpenDriveServer";/* "openLocalDrive";//183.140 */
				var getPath = $scope.correctionfolderOrgPath;
                                
				if($scope.titleWise){					
					if($scope.correctionMappingID === "ProcessMapping"){
						var currentChapterNo = currentBtn.corChapter.CHAPTER_NO;
						var currentMetaDataId = currentBtn.corChapter.METADATA_ID;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+currentChapterNo);
					}else if($scope.correctionMappingID === "BookReference"){
						var currentChapterNo = $scope.correctionBookId;
						var currentMetaDataId = $scope.correctionJobId;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/REFERENCE");
					}else if($scope.correctionMappingID === "ChapterReference"){
						var currentChapterNo = currentBtn.corChapter.CHAPTER_NO;
						var currentMetaDataId = currentBtn.corChapter.METADATA_ID;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+currentChapterNo+"/REFERENCE");
					}	
					$scope.titleOrChapterWiseSelectedChapter[currentMetaDataId] = currentChapterNo;
					
				}else if($scope.chapterWise){
					var currentChapterNo = $scope.correctionChapterNo;
					var currentMetaDataId = $scope.correctionMetadataId;
					if($scope.correctionMappingID === "ProcessMapping"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+$scope.correctionChapterNo);
					}else if($scope.correctionMappingID === "BookReference"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/REFERENCE");
					}else if($scope.correctionMappingID === "ChapterReference"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+$scope.correctionChapterNo+"/REFERENCE");
					}
					$scope.titleOrChapterWiseSelectedChapter[currentMetaDataId] = currentChapterNo;
				}
				
                                var openPath = openFolderPath;
				$scope.correctionOpenFolderPath = openFolderPath+'/<>'+$scope.credential;

				var inp = {
					/* currentMachineIP : '172.24.135.211', */
					filePath : $scope.correctionOpenFolderPath,
					methodName : method  ,
					processname  :   'checkout',
					replacePathSlash  :   'true'
				};
                                
                               var workresponse =  $scope.createWorkDirectory($scope.ftpfilepath,openPath,$scope.jobId);
                                workresponse.then(function(rest) 
                                {    
                                    $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                                            if(response.data[0].rmiId > 0) {
                                                    var attempt = 5;
                                                    $scope.checkFileHandlerStatus(response.data[0].rmiId, attempt);						
                                            } else {
                                                    hideLoader();
                                                    showNotify( 'Having problem in insert data.', 'danger');
                                            }                    
                                    },function myError(response) {
                                        showLoader( 'Oops! Try again after sometimes.' );
                                    }); 
                                })
                                .catch(function(fallback) {

                                }); 
            }       
        }
		
	}
        
        $scope.createWorkDirectory = function(ftpPath, openPath, jobId){
            var inp = {ftppath : ftpPath,openpath : openPath,jobID : jobId};//currentMachineIP : '172.24.183.140',
           var deferred    =   $q.defer();
            $http.post(BASE_URL+"correctionworkPath", inp).then(function mySuccess(response) {
                    if(response.data.status == 1){
                        deferred.resolve(response);
                        
                    }else{
                          deferred.reject(response);
                      
                    }
                 },
		function myError(response) {
			deferred.reject(response);					
		});
                
                 return deferred.promise;
        }
	
	$scope.checkFileHandlerStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};//currentMachineIP : '172.24.183.140',
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
			$scope.IsRunning = response.data[0].is_running;   // status, remarks
			if(response.data[0].status == 1) {
				if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
					if(opt == "Fonts") {
						hideLoader();
						showNotify('Font Downloaded successfully.'  , 'success' );
					} else if(opt == "InDesign") {
						hideLoader();
						$scope.checkoutBtn = "Open File";
						showNotify('Page(s) checked out successfully.'  , 'success' );
						//$scope.checkFileStatus();
						//$scope.checkoutProcess();
					} else {
						hideLoader();
						showNotify('Folder Opened Successfully.'  , 'success' );
						$scope.submitBtnShow = true;						
					}
				} else {    
					hideLoader();
					showNotify(response.data[0].remarks  , 'danger' );
				}
			} else {
				attempt++;
				if(attempt < $scope.noOfAttemptsToCheckIndesign) {
					$timeout( function(){ $scope.checkFileHandlerStatus(rmiId, attempt, opt); }, 7000 );
				} else {
					hideLoader();
					showNotify("File handler is not running. Please check."  , 'danger' );
				}
			}
		},
		function myError(response) {
			showLoader( 'Oops! Try again after sometimes.' );						
		});		
        
    };  
	
	function isEmpty(value) {
		/*for(var key in obj) {
			if(obj.hasOwnProperty(key))
				return false;
		}
		return true;*/
		return (value == null || value.length === 0  || value === '');
	}
	
	$scope.submitCorrectionFile = function(btnType) {
		showLoader();
		if(isEmpty($scope.correctionStageId)){
			hideLoader();
			showNotify('Please choose any one stage.', 'danger');	
		}else if (isEmpty($scope.correctionProcessId)) {
            hideLoader();
			showNotify('Please choose any one process.', 'danger');
        } else if (isEmpty($scope.correctionMappingID)) {
			hideLoader();
			showNotify('Please choose any one mapping.', 'danger');
		}else{
			var formData = new FormData();
			if($scope.chapterWise){
				//option field only for chapter wise
				formData.append('correctionMetadataId', $scope.correctionMetadataId);
				formData.append('correctionChapterNo', $scope.correctionChapterNo);	
				formData.append('correctionChapterTitle', $scope.correctionChapterTitle);				
			}

			formData.append('correctionRoundId', $scope.correctionStageId);
			//formData.append('correctionRoundId', $scope.correctionRoundId);
			formData.append('correctionRoundName', $scope.correctionRoundName);

			formData.append('correctionStageId', $scope.correctionProcessId);	
			formData.append('correctionStageName', $scope.correctionProcessName);
			formData.append('correctionBookId', $scope.correctionBookId);
			formData.append('correctionJobId', $scope.correctionJobId);

			formData.append('correctionWorkflowId', $scope.correctionWorkflowId);
			formData.append('correctionWorkflowMasterId', $scope.correctionWorkflowMasterId);
			formData.append('correctionWorkflowType', $scope.correctionWorkflowType);		
						
			formData.append('correctionMappingID', $scope.correctionMappingID);			
			formData.append('titleWise', $scope.titleWise);
			formData.append('chapterWise', $scope.chapterWise);								
								
			/* formData.append('correctionSrcPath', $scope.correctionSrcPath);
			formData.append('correctionWrkPath', $scope.correctionWrkPath);
			formData.append('correctionDestPath', $scope.correctionDestPath); */
			
			var conArr = '';
			for (var key in $scope.titleOrChapterWiseSelectedChapter) {
				conArr = conArr+key+"<#>"+$scope.titleOrChapterWiseSelectedChapter[key]+"<##>";
			}
			formData.append('correctionSourceFolderPath', conArr);
			
			var request = {
                method: 'POST',
                url: BASE_URL + 'correctionFileUpload',
				fileFormDataName: $scope.filenames,
				file: $scope.files,
                data: formData,
                headers: {
                    'Content-Type': undefined
                }
            };

            $http(request).then(function success(e) {					
                if (e.data.status == 0) {
                    hideLoader();
					showNotify(e.data.errMsg , 'danger' );
                } else {
					hideLoader();
					showNotify(e.data.errMsg , 'success' );
					$('#editCheckItem-close').trigger('click');
                }                              
			}, function error(e) {
				hideLoader();
				showNotify(e.data.errMsg , 'danger' );
            });
		}
	}
        
         var focused = true;

        var onFocus = function () {
            focused = true;
            //$scope.jobassigned2();
        };

        var onBlur = function () {
            focused = false;
        };

        var win = angular.element($window);

        win.on("focus", onFocus);
        win.on("blur", onBlur);

        $scope.$on("$destroy", function handler() {
            win.off("focus", onFocus);
            win.off("blur", onBlur);
        });
    
	$window.onblur = function() {
            focused = false;
    };
        
	$window.onmouseover  = function(){
            focused = true;
	}
        
	var totalTime   =   5;
        
	$scope.autoRefreshBackprocessScreen = function(){	
            return false;
            if( focused ){
                $scope.jobassigned2();	
            }else{
                
            }	
            
            $('.reducing_time').val( totalTime );		
            setTimeout( function(){ $scope.timeChangesUpdate(); } , 3000 );		
            
	}

	$scope.timeChangesUpdate = function(){		
            var currenttime = $('.reducing_time').val();
            var showTime	=	parseInt( currenttime )	-	1;
            $('.reducing_time').val( showTime );		
            if( parseInt( showTime ) !== 0 ){
                setTimeout( function(){ $scope.timeChangesUpdate(); } , 2000 );
            }else if( parseInt( showTime ) == 0 ){
                setTimeout( function(){ $scope.autoRefreshBackprocessScreen(); } , 2000 );
            }		
	}
	
	var time	 = 	setTimeout( function(){ 		
        $scope.timeChangesUpdate(); } ,	1000 );
	
	
	   
});