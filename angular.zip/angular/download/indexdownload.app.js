/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */

ngApp.controller('ngController', function ( $scope , $http , $filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
    
    $scope.userId       = 	0;
    $scope.projectList 	= 	[];
    $scope.showProject 	= 	false;
	
    $scope.menuParent 	= 	'Download';
    $scope.menuChild  	= 	'';

    
});