/*
 *  Stage Master Controller
 *  This controller contains all the methods related to customization > stage screen.
 */
ngApp.controller('ngController', function ($scope, $http,DTOptionsBuilder, DTColumnBuilder) {
	$scope.userId = 0;	
	$scope.menuParent = 'Customization';
	$scope.menuChild = 'StageList';
	
	/*
	 *  Get Stage List
	 *  This method get all the active stage list from DB
	 */
	$scope.showStageList = function() {
		$scope.stageList = [];
		var inp = {	stageId : 0, opt : 'All'};
		$http.post(API_URL+"getStageDetail", inp) .then(function mySuccess(response) {
			$scope.stageList = response.data.stage;	
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        $scope.showStageList();
	/*
	 *  Get Stage Details
	 *	Stage Id is the input.
	 *  This method get the stage details for the given stage.
	 */
	$scope.showStageDetails = function(stageID) {
		console.log(stageID);
		var roles = '', title = 'Stage Details', content = '';	
				
		$scope.remarks = [];
		var inp = {	stageId : stageID, opt : ''};
		
		$http.post(API_URL+"getStageDetail", inp) .then(function mySuccess(response) {
			$scope.data = response.data.stage;	
			$scope.role = response.data.role;	
			for(var i=0; i<$scope.role.length; i++) {
				roles += $scope.role[i].Name +'<br/>';
				
			}
			content += '<table class="table table-bordered">'+
						'<tr><th>Stage Code </th><td>'+$scope.data[0]['CODE'] +'</td></tr>'+
						'<tr><th>Stage Name </th><td>'+$scope.data[0]['STAGE_NAME'] +'</td></tr>'+
						'<tr><th>Description </th><td>'+$scope.data[0]['DESCRIPTION'] +'</td></tr>'+
						'<tr><th>Role </th><td>'+roles +'</td></tr>'+
						'</table>';
			showInfo(title, content);
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};	

});