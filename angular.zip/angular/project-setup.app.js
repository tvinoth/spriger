/*
 *  Project Setup Controller
 *  This controller contains all the methods related to project set up screen.
 */
ngApp.controller('ngController', function ($scope, $http, $filter,$timeout,$interval,DTOptionsBuilder, DTColumnBuilder) {
	$scope.projectList = false;
	$scope.vm = {};
	$scope.vm.dtOptions = DTOptionsBuilder.newOptions()
										  .withOption('order', [1, 'asc']);
	
	if(isNaN(getUrlParameter(1))) {
		$scope.JobID = "";$scope.customParam = "";
		$scope.TabName = getUrlParameter(1);
	} else {
		$scope.JobID = getUrlParameter(1);
		$scope.TabName = getUrlParameter(2);
		$scope.customParam = "/"+$scope.JobID;
	}		
	
	$scope.menuParent = 'Pre-Production';
	$scope.menuChild = 'Project List';
	$scope.sectionName = " - Project List";
	
	/*
	 *  Check Job selected
	 *  This method check job is selected, redirect the user to the selected tab page.
	 */
	$scope.checkJobId = function(tab) {
		if(isNaN($scope.JobID) || $scope.JobID == "") {
			window.location.href= BASE_URL+"pre-production/"+tab;
		} 	
	};
	/*
	 *  Go to selected tab
	 *  This method check job is selected, if not navigate the user to the project list page
	 */
	$scope.goToSelectedTab = function() {
		if(isNaN($scope.JobID) || $scope.JobID == "") {			
			window.location.href= BASE_URL+"project-list";
		} else {
			if($scope.TabName == 'tps-setup')  $scope.showTPSTab();
			else if($scope.TabName == 'assign-workflow')  $scope.showWorkflowTab();
			else if($scope.TabName == 'project-setup')  $scope.showSetupTab();
			else if($scope.TabName == 'meta-data')  $scope.showMetaTab();
			else if($scope.TabName == 'bookmap')  $scope.showBookmapTab();
			else if($scope.TabName == 'instruction')  $scope.showInstructionTab();
			else if($scope.TabName == 'move-to-production')  $scope.showMoveToPrdTab();
			else if($scope.TabName == 'project-bin')  $scope.showProjectBinTab();
		}		
	};

/*
 *  This section contains Assign Workflow Related methods.
 */	
 
	/*
	 *  Get Assigned workflow
	 *  This method get the assigned workflow for the selected job id
	 */
	$scope.getAssignedWF = function(inp) {
		$http.post(API_URL+"getAssignedWF", inp) .then(function mySuccess(response) {
			console.log(response.data); 
			var res = response.data;
			$scope.assn_workflowAssn = res.workflow;
			$scope.assignWF = [];			
			
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  This setup menu name and other workflow tab related parameters
	 *  Get round, workflow names and assigned workflows.
	 */
	$scope.showWorkflowTab = function() {
		
		$scope.menuChild = 'AssignWorkflow';
		$scope.sectionName = " - Assign Workflow";
		$("#asn_tab").tab('show');
		$scope.projectList = false;
		$scope.checkJobId('assign-workflow');
		
		var inp = {	jobId : $scope.JobID, circleId : null, subCircle: null};
		
		$http.post(API_URL+"getAssignWFTabInfo", inp) .then(function mySuccess(response) {
			console.log(response);
			var res = response.data;
			$scope.assn_roundInfo = res.roundInfo;
			$scope.assn_workflowInfo = res.workflowInfo;	
			$scope.getAssignedWF(inp);	
		}, 
		function myError(response) {
			// console.log(response);
		});
	};
	/*
	 *  This method save workflow for the selected job.
	 */
	$scope.assignWorkflow = function() {
		var savInp = {	jobId       :   $scope.JobID,
                    		userId      :   '',
				WFInfo      :   $scope.assignWF
                             };
		var inp = {	jobId : $scope.JobID, circleId : null, subCircle: null};
		
		$http.post(API_URL+"saveAssignWF", savInp) .then(function mySuccess(response) {
			showMessage('Message', response.data.msg, 'success');
			$scope.getAssignedWF(inp);
		}, 
		function myError(response) {
			 console.log(response);
		});	
			
	};
	$scope.assignWF = [];

	/*
	 *  This method used to add another row to assign workflow
	 */
	$scope.addWorkflow = function() {
		$scope.assignWF.push({'ROUND': '', 'WORKFLOW_MASTER_ID':'', 'totalWF':'', 'action':'','newWF': 1});
	};
	/*
	 *  This method removes the row from the list
	 */
	$scope.removeWorkflow = function(idx, opt) {
		if(opt == 'new') {
			var newArr = $scope.assignWF.slice(idx, idx+1)[0];
			$scope.assignWF.splice(idx,1);
		} else {
			 var newArr = $scope.assn_workflowAssn.slice(idx, idx+1)[0];
			
			var inp = {	jobId : $scope.JobID, workflowMasterId : newArr['WORKFLOW_MASTER_ID'], roundId: newArr['ROUND'], circleId : null, subCircle: null};
			// console.log(inp);
			
			$http.post(API_URL+"deleteAssignWF", inp) .then(function mySuccess(response) {
				showMessage('Message', response.data[0].msg, 'success');
				$scope.getAssignedWF(inp);
			}, 
			function myError(response) {
				 console.log(response);
			});	
		}
	};
	/*
	 *  This method used to remove / add stages to the assigned workflow
	 */
	$scope.addRemoveStages = function() {
		var myOpts = new Array();	
		myOpts  = document.getElementById('sbox4').options;
		var select_box_length = myOpts.length;
		
		var  str_val = "";
		
		for(var i=0; i<myOpts.length; i++) {
			if(i > 0)	str_val += ",";		
			str_val += myOpts[i].value;
		}
		
		var inp = { jobId : $scope.JobID, 
					userId: '', 
					roundId : $scope.HidRoundId,
					workflowMasterId : $scope.HidWorkflowMasterId,
					workflowId : $scope.HidWorkflowId,
					stageInfo : str_val
					};
			
		$http.post(API_URL+"addRemoveWorkfowStages", inp) .then(function mySuccess(response) {
			showMessage('Message', response.data[0].msg, 'success');
			$("#stageCancel").click();	
		}, 
		function myError(response) {
			 console.log(response);
		});	

	};
	/*
	 *  This method used to list the assigned workflow stages
	 */
	$scope.showAddRemoveWFStage = function(aswf) {
		var inp = {	jobId : $scope.JobID,  roundId: aswf.ROUND, workflowMasterId : aswf.WORKFLOW_MASTER_ID, workflowType : 0};
		var cont = '';
		$scope.HidRoundId = aswf.ROUND;
		$scope.HidWorkflowMasterId = aswf.WORKFLOW_MASTER_ID;
			
		$http.post(API_URL+"getJobRoundWorkflow", inp) .then(function mySuccess(response) {
			var res = response.data.data;
			$scope.wfDetail = res.workflowStages;
			$scope.wfInfo = res.workflow;
			$scope.wfStages = res.stages;	
			$scope.mainWorkflowName = $scope.wfInfo[0].WORKFLOW_NAME;
			
			$scope.HidWorkflowId = $scope.wfInfo[0].WORKFLOW_ID;
			
			$("#showStagesModal").click();
		}, 
		function myError(response) {
			 console.log(response);
		});	
	};
	/*
	 *  This method shows the assigned workflow view
	 */
	$scope.viewAssignedWF = function(aswf) {
		var inp = {	jobId : $scope.JobID,  roundId: aswf.ROUND};
	
		var title = 'View Workflow';	
	    $scope.wkInfo = '';	
		$scope.workflow = []; $scope.stageInfo = []; $scope.roundInfo = [];
						
		$http.post(API_URL+"getWorkflowView", inp) .then(function mySuccess(response) {
			console.log(response);	
			$scope.workflow = response.data.data.workflow;	
			$scope.stageInfo = response.data.data.stageInfo;
			
			$scope.wkInfo +='<div class="dd" id="nestable"><ol class="dd-list">';
			for(var k=0; k<$scope.workflow.length; k++) {
				$scope.wkInfo +='<li class="dd-item" data-id="'+k+'"><div class="dd-handle orange">';
				if($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
					$scope.wkInfo += "Main Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
					$scope.wkInfo += "Parallel Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
					$scope.wkInfo += "Art Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
					$scope.wkInfo += "Art Correction Workflow - ";
				}
				$scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

				if($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
					$scope.wkInfo += " (";
					if($scope.workflow[k]['START_STAGE'] != '') {
						$scope.wkInfo += " Start Stage: " + $scope.workflow[k]['START_STAGE'];
						$scope.wkInfo += " End Stage: " + $scope.workflow[k]['END_STAGE'];
					} else {
						$scope.wkInfo += " No Start and End stage is defined";
					}
					$scope.wkInfo += ") ";
				} 
				$scope.wkInfo += '</div><ol class="dd-list">';
				for(var i=0; i<$scope.stageInfo.length; i++) {
					$scope.wkInfo += '<div class="dd-handle"><li class="dd-item" data-id="'+i+'">';
					$scope.wkInfo += $scope.stageInfo[i]['STAGE_NAME'];
				
					$scope.wkInfo += '</div></li>';			
				}
				$scope.wkInfo += '</ol></li>';
			}
			$scope.wkInfo +='</ol></div>';
			showInfo(title, $scope.wkInfo);
			$('.dd').nestable();
			}, 
			function myError(response) {
				 console.log(response);
			});	
	};
	/*
	 *  This method used to move the workflow stages up, down, left, right.
	 */
	$scope.WorkflowStageMovement = function(listID, direction) {
		var listbox = document.getElementById(listID);
		var selIndex = listbox.selectedIndex;

		if(-1 == selIndex) {
			alert("Please select an option to move.");
			return;
		}

		var increment = -1;
		if(direction == 'up') 	increment = -1;
		else					increment = 1;

		if((selIndex + increment) < 0 || (selIndex + increment) > (listbox.options.length-1)) return;

		var selValue = listbox.options[selIndex].value;
		var selText = listbox.options[selIndex].text;
		listbox.options[selIndex].value = listbox.options[selIndex + increment].value
		listbox.options[selIndex].text = listbox.options[selIndex + increment].text

		listbox.options[selIndex + increment].value = selValue;
		listbox.options[selIndex + increment].text = selText;

		listbox.selectedIndex = selIndex + increment;
	};
	jQuery("#right2,#left2").click(function(event) {
        var id = jQuery(event.target).attr("id");
		var selectFrom = id == "right2" ? "#sbox3" : "#sbox4";
        var moveTo = id == "right2" ? "#sbox4" : "#sbox3";
 
        var selectedItems = jQuery(selectFrom + " :selected").toArray(); 
		jQuery(moveTo).append(selectedItems); 
		selectedItems.remove;
    });

/*
 *  This section contains Bookmap Related methods.
 */	
 
	/*
	 *  Show Bookmap tab
	 *  This method set up bookmap tab realted parameters.
	 */
	$scope.showBookmapTab = function() {
		$scope.menuChild = 'Bookmap';		
		$scope.sectionName = " - Manage Bookmap";
		$("#bmp_tab").tab('show');
		$scope.projectList = false;
		$scope.checkJobId('bookmap');
		
		$scope.downloadBookmapLink = BASE_URL+"bookmapDownload/"+$scope.JobID;
		
		$scope.folioHeader = "Add / Update Folio";
		$scope.map_selectedFolio = "";
		$scope.folioUpdateBtn = "SAVE";
		$scope.currentFolioDtl = {};
		$scope.saveFolioOpt = true;
	};
	/*
	 *  Open popup to import bookmap details
	 */
	$scope.openBookmapImport = function() {
		$("#show-bookmapimport").click();
		$scope.bookmapUploadMsg = "";
	};
	/*
	 *  Save the bookmap details from uploaded excel.
	 */
	$scope.importBookmapSetupDB = function(fileName) {
		var inp = {	jobId : $scope.JobID,
					userId : '', 
					myFile: fileName};
			
		$http.post(API_URL+"bookmapImportDB", inp) .then(function mySuccess(response) {
			console.log(response);
			
			if(response.data.rowCnt > 0)	{
				$scope.bookmapUploadMsg = response.data.errMsg;
			} else {
				showMessage('Message', response.data.errMsg, 'success');
				$scope.bookmapUploadMsg = "";
				angular.element("input[type='file']").val(null);
				$scope.myFile = "";
				$("#bookmapimport-close").click();	
				$scope.getBookmapDetails();				
			}
		}, 
		function myError(response) {
			 console.log(response);
		});	
	}
	/*
	 *  Validate excel and Save the uploaded bookmap excel in a temp folder.
	 */
	$scope.importBookmapSetup = function() {
		var file = $scope.myFile;
		if(file == "") {
			$scope.bookmapUploadMsg = 'Please select a file to upload.';
		} else {
			var fileName = file.name;
			var extn = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
			
			if (extn == "xls" || extn == "xlsx"  ) {	
				$http.post(API_URL+"bookmapImport", file) .then(function mySuccess(response) {
					$scope.importBookmapSetupDB(response.data.fileName);	
				}, 
				function myError(response) {
					 console.log(response);
				});	
			} else {
				$scope.bookmapUploadMsg = 'Please upload only excel file.';
			}
		}
	};
	
	/*
	 *  Get the folio details for the selected job.
	 */
	$scope.getBookmapDetails = function() {	
		$scope.bookmapInfo = [];
		var inp = {	job_id : $scope.JobID};
		
		$http.post(API_URL+"getBookmapDetails", inp) .then(function mySuccess(response) {
		//	console.log(response.data.data);	
			$scope.bookmapInfo = response.data.data;	
			angular.forEach($scope.bookmapInfo, function (pg) {
				if(pg.is_touched) pg.is_touched = true;
				else pg.is_touched = false;
			});
		}, 
		function myError(response) {
			// console.log(response);
		});			
	};
	/*
	 *  Show popup to add folio details.
	 */
	$scope.showBookmapAdd = function(selData) {
		$scope.currentFolioDtl  = selData;
		$("#showBookmapEdit").click();
		$scope.getInDesignVersion ();
		$scope.map_selectedFolio = "("+selData.order_seq+")";	
		$scope.folioHeader = "Create Folio";
		$scope.folioUpdateBtn = "Save";
		$scope.saveFolioOpt = true;
		$scope.clearFolioEntry();
	};
	/*
	 *  Show popup to edit folio details.
	 */
	$scope.showBookmapEdit = function(selData) {	
		$scope.currentFolioDtl  = selData;
		$("#showBookmapEdit").click();
		$scope.getInDesignVersion ();
		$scope.folioHeader = "Update Folio";
		$scope.folioUpdateBtn = "Update";		
		$scope.saveFolioOpt = false;
		$scope.clearFolioEntry();
		var ordSeq = "";
		$scope.getBookmapInfoById(ordSeq, 'crnt');
	};
	/*
	 *  This is used to view prev / next records.
	 */
	$scope.showNextPrevRecord = function(ordSeq) {
		$scope.getBookmapInfoById(ordSeq, 'next');
	};
	/*
	 *  This method is used to get the list of Indesign versions
	 */
	$scope.getInDesignVersion = function() {
		$http.post(API_URL+"getInDesignVersion", "") .then(function mySuccess(response) {
			$scope.indesignVersionList = response.data; 
		}, 
		function myError(response) {
		});
	};
	/*
	 *  This method get the folio details for the given folio.
	 */
	$scope.getBookmapInfoById = function(ordSeq, opt) {
		var pg = '';
		if(opt == 'crnt') pg = $scope.currentFolioDtl.page_id;
		var inp = {jobId: $scope.JobID, pageId:pg, seq:ordSeq, seqId:$scope.currentFolioDtl.order_seq};
		$http.post(API_URL+"getBookmapInfoById", inp) .then(function mySuccess(response) {
		//	console.log(response); 
			if(response.data.length > 0) {
				$scope.currentFolioDtl = response.data[0];
				$scope.fillFolioForEdit($scope.currentFolioDtl);
			} else {
				alert("There is no Prev / Next folio.");
			}
		}, 
		function myError(response) {
		});
	};
	/*
	 *  This method fill the folio details for edit.
	 */
	$scope.fillFolioForEdit = function(crntData) {
		$scope.map_folio = crntData.order_seq;
		$scope.map_idddFolio = crntData.indd_folio_number;
		$scope.map_inddVersion = crntData.indd_version;
		$scope.map_title = crntData.title;
		$scope.map_pageType = crntData.page_type;
		$scope.map_numberType = crntData.number_type.toString();
		$scope.map_prefix = crntData.prefix;
		$scope.map_suffix = crntData.suffix;
		$scope.map_batchNo = crntData.batch_no;
		$scope.map_pdfFileName = crntData.pdf_file_name;
		$scope.map_inddFilePath = crntData.indd_file_path;	
		$scope.map_inddFileName = crntData.indd_file_name;		
	};
	/*
	 *  This method clear the folio entry after save / update / cancel
	 */
	$scope.clearFolioEntry = function() {
		$scope.map_folio = "";
		$scope.map_idddFolio = "";
		$scope.map_inddVersion = "";
		$scope.map_title = "";
		$scope.map_pageType = "";
		$scope.map_numberType = "";
		$scope.map_prefix = "";
		$scope.map_suffix = "";
		$scope.map_batchNo = "";
		$scope.map_pdfFileName = "";
		$scope.map_inddFilePath = "";
		$scope.map_inddFileName = "";
	};
	/*
	 *  This method update the folio with selected touched / untouched 
	 */
	$scope.updateTouched = function(selData) {
		var inp = { jobId   : $scope.JobID,
					pageId  : selData.page_id,
					userId  : '',
					touched : selData.is_touched
				  };
		$http.post(API_URL+"updateTouched",inp) .then(function mySuccess(response) {
			showMessage('Manage Bookmap', 'Successfuly updated.', 'success');
		}, 
		function myError(response) {
		});
	};
	
	/*
	 *  This method save the folio details 
	 */
	$scope.saveFolio = function() {
		var inp = {	jobId : $scope.JobID,
					pageId : $scope.currentFolioDtl.page_id,
					userId : '',
					pageNo : $scope.map_folio,
					inddFolioNo : $scope.map_idddFolio,
					pgTitle : $scope.map_title,
					pageType : $scope.map_pageType,
					numberType : $scope.map_numberType,
					pref : $scope.map_prefix,
					suff : $scope.map_suffix,
					batchNo : $scope.map_batchNo,
					inddVersion : $scope.map_inddVersion,
					pdfFileName : $scope.map_pdfFileName,
					inddFileName: $scope.map_inddFileName,
					inddFilePath : $scope.map_inddFilePath,
					saveOpt		:$scope.folioUpdateBtn,
					savePos		:$scope.map_folio_add_check
				  };

		$http.post(API_URL+"saveBookmapFolio", inp) .then(function mySuccess(response) {
			//console.log(response);
			$("#bookmap_editCancel").click();
			showMessage('Manage Bookmap', response.data[0]['msg'], 'success');
			$scope.clearFolioEntry();
			$scope.getBookmapDetails();
		}, 
		function myError(response) {
			console.log(response);
		});
		
	};
	/*
	 *  This method check all the folios
	 */
	$scope.checkAllBookmap = function() {
       if ($scope.map_checkAll) {
            $scope.map_checkAll = true;
        } else {
            $scope.map_checkAll = false;
        }
        angular.forEach($scope.bookmapInfo, function (pg) {
            pg.map_check = $scope.map_checkAll;
        });
	};
	
	/*
	 *  This method used to delete the selected folios
	 */
	$scope.deleteBookmapFolio = function() {
		
		$scope.mapInfo = [];
		if ($scope.map_checkAll) {
			angular.forEach($scope.bookmapInfo, function (pg) {
				if(pg.map_check) {
					$scope.mapInfo.push({pageId: pg.page_id});
				}
			});
		} else {
			$("table#bookmapDtl").find("input[name^=map_check]:checked").each(function(){
				$scope.mapInfo.push({pageId: $(this).val()});	
			});				
		}
		console.log($scope.mapInfo);
		if($scope.mapInfo.length > 0) {
			bootbox.confirm("Are you sure you want to remove the selected pages", function(result) {
				if(result) {
					
					if($scope.mapInfo.length > 0) {
						var mapInp = {	jobId : $scope.JobID,
										userId: '',
										bookmapInfo : $scope.mapInfo
									};
						console.log(mapInp);
						$http.post(API_URL+"deleteBookmapPages", mapInp) .then(function mySuccess(response) {
							console.log(response.data); 
							var res = response.data;
							
							showMessage('Manage Bookmap', res[0]['msg'], 'success');
							$scope.getBookmapDetails();
						}, 
						function myError(response) {
							// console.log(response);
						});
					}
				}
			});	
		} else {
			showMessage("Warning", "No pages selected. Please select pages to remove", 'warning');
		}
	};
	$scope.getBookmapDetails();
	
/*
 *  This section contains Project Set up Related methods.
 */	
 
	/*
	 *  Open a popup to upload project set up excel 
	 */
	$scope.openSetupImport = function() {
		$("#show-import").click();
		$scope.fileUploadMsg = "";
	};
	/*
	 *  Save uploaded project set up details 
	 */
	$scope.importSetupDB = function(fileName) {
		var inp = {	jobId : $scope.JobID,
					userId : '', 
					lesson : '',
					grade : '',
					myFile: fileName};
		$http.post(API_URL+"projectSetupImportDB", inp) .then(function mySuccess(response) {
			
			if(response.data.rowCnt > 0)	{
				$scope.fileUploadMsg = response.data.errMsg;
			} else {
				showMessage('Message', response.data.errMsg, 'success');
				$scope.fileUploadMsg = "";
				angular.element("input[type='file']").val(null);
				$scope.myFile = "";
				$("#import-close").click();	
				$scope.getRoundDetails();				
			}
		}, 
		function myError(response) {
			 console.log(response);
		});	
	}
	/*
	 *  Validate excel file and save it in temp folder
	 */
	$scope.importSetup = function() {
		var file = $scope.myFile;
		if(file == "") {
			$scope.fileUploadMsg = 'Please select a file to upload.';
		} else {
			console.log(file);
			var fileName = file.name;
			var extn = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
			
			if (extn == "xls" || extn == "xlsx"  ) {	
				$http.post(API_URL+"projectSetupImport", file) .then(function mySuccess(response) {
					$scope.importSetupDB(response.data.fileName);	
				}, 
				function myError(response) {
					 console.log(response);
				});	
			} else {
				$scope.fileUploadMsg = 'Please upload only excel file.';
			}
		}
	};
	
	/*
	 *  This method get round details for the selected job
	 */
	$scope.getRoundDetails = function() {	
		$scope.roundList = [];
		var inp = {	job_id : $scope.JobID};
		
		$http.post(API_URL+"getRoundDetails", inp) .then(function mySuccess(response) {
			$scope.roundList = response.data.data;	
			console.log($scope.roundList);
		}, 
		function myError(response) {
			 //console.log(response);
		});	
	};
	/*
	 *  This method delete the given round details
	 */
	$scope.deleteRoundInfo = function(selData) {
		var inp = {	gradeId : selData.GradeId, projectId: $scope.JobID};	
		
		$http.post(API_URL+"deleteRoundInfo", inp) .then(function mySuccess(response) {
			showMessage('Message', response.data[0].msg, 'success');
			$scope.getRoundDetails();
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  This method open a popup and allow the user to edit target page count.
	 */
	$scope.editRoundInfo = function(selData) {
		$("#setup-edit").click();
		$("#st_target_change").val(selData.tragetPageCount);
		$("#change_gradeId").val(selData.GradeId);
	};
	
	/*
	 *  This method save the edited target page count
	 */
	$scope.saveEditedRoundInfo = function() {
		var inp = {jobId : $scope.JobID, gradeId : $("#change_gradeId").val(), target:$("#st_target_change").val(), user:''};
		
		$http.post(API_URL+"updateRoundTarget", inp) .then(function mySuccess(response) {
			$("#setup-edit-close").click();
			showMessage('Message', "Successfully updated.", 'success');
			$scope.getRoundDetails();
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  This method open a popup and show the profit percentage for the selected job
	 */
	$scope.showProfitPercentage = function() {		
		$("#show-profiltability").click();
		var inp = {jobId : $scope.JobID};
		$http.post(API_URL+"getProfitabilityPercentage", inp) .then(function mySuccess(response) {
			console.log(response);
			$scope.profitPercent = response.data;
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  This method save the profit percentage information
	 */
	$scope.saveProfitPercent = function() {
		var totPercent = 0;
		angular.forEach($scope.profitPercent, function(val) {
			totPercent = parseFloat(totPercent) + parseFloat(val.PERCENTAGE);
		});
		if (totPercent != 100) {
			showMessage('Message', "Profitability percentage should be 100 %", 'success');
		} else {		
			var inp = {jobId : $scope.JobID, roundInfo : $scope.profitPercent, userId:''};
			
			$http.post(API_URL+"saveProfitabilityPercentage", inp) .then(function mySuccess(response) {
				$("#profiltability-close").click();
				showMessage('Message', response.data[0].msg, 'success');
			}, 
			function myError(response) {
				 console.log(response);
			});
		}
	};
	/*
	 *  This method change the stage type like book level / page level
	 */
	$scope.changeStageType = function(opt) {
		$scope.stageType = opt;
	};
	/*
	 *  This method get the fill the setup workflow stages.
	 */
	$scope.fillWorkflow = function(op) {
		if(op =="boo") $scope.st_Round = $("#st_Round_boo").val();
		else $scope.st_Round = $("#st_Round").val();
		
		var inp = {	roundId : $scope.st_Round, jobId : $scope.JobID};	
		$http.post(API_URL+"getSetupWorkflowStages", inp) .then(function mySuccess(response) {
			$scope.stWorkflow = response.data.wfInfo;
			$scope.stStages = response.data.stageInfo;
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  This method save the set up round details.
	 */
	$scope.saveSetupRound = function() {
		$scope.st_unit = $("#unit").val();
		$scope.st_stage = $("#st_stage").val();
		if($scope.st_stage == "" || $scope.st_stage == undefined) $scope.st_stage = $("#st_stagedd").val(); 
		var inp = {	jobId : $scope.JobID,
					userId : '', 
					lesson : '',
					grade : '',
					stageId : $scope.st_stage,
					roundId : $scope.st_Round,
					unitId : $scope.st_unit,
					tolerance : $scope.st_tolerance,
					target : $scope.st_target,
					};	
				//	console.log(inp);

		$http.post(API_URL+"saveSetupRound", inp) .then(function mySuccess(response) {
			showMessage('Message', response.data[0].msg, 'success');
			$scope.getRoundDetails();
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
	/*
	 *  Show Setup tab
	 *  This method project set up realted parameters.
	 */
	$scope.showSetupTab = function() {
		$scope.menuChild = 'ProjectSetup';
		$scope.sectionName = " - Project Setup";
		$("#stp_tab").tab('show');
		$scope.projectList = false;	
		$scope.checkJobId('project-setup');
	    $scope.downloadLink = BASE_URL+"projectSetupDownload/"+$scope.JobID;

		$scope.stageType = "pro";
		$scope.getRoundDetails();	
	};
/*
 *  This section contains TPS Set up Related methods.
 */	
 
	/*
	 *  Get TPS details for the selected Job
	 */
	$scope.getTPSDetails = function(inp) {
		$http.post(API_URL+"getTPS", inp) .then(function mySuccess(response) {
			if(response.data.length > 0) {
				var res = response.data[0];
				$scope.components = res.components;
				
				$scope.tpsContact = res.tps_contact_id.toString();
				$scope.workflowType = res.workflowtype_id.toString();
				$scope.percentage = res.percentage_completion;
				$scope.target = res.production_target;
				$scope.components = res.components;
				$scope.grade = res.grade;
				$scope.pageCnt = res.page_count;
				$scope.batchInfo = res.batch_info;
				$scope.productionDate = res.production_date;
				$scope.lwProjMgr = res.lw_project_manager;
				$scope.projDtl = res.project_details;
				$scope.pendDtl = res.pending_details;
				$scope.ProjectId = res.project_id;
				
				$scope.startDate = res.START_DATE;
				$scope.endDate = res.END_DATE;
				if (res.customer_name == "") $scope.clientName = " - ";
				else $scope.clientName = res.customer_name +" "+ res.divison_name;
			}			
		}, 
		function myError(response) {
			 console.log(response);
		});	
	};
	/*
	 *  This method used to set up TPS tab related parameters 
	 *  Also Get TPS contact details for dropdown fill up.
	 */
	$scope.showTPSTab = function() {
		$scope.menuChild = 'TPSSetup';
		$scope.sectionName = " - TPS Setup";
		$("#tps_tab").tab('show');
		$scope.projectList = false;		
		$scope.checkJobId('tps-setup');		
		
		$scope.ProjectId = 0;
		var inp = {	jobId : $scope.JobID };
		
		$http.post(API_URL+"getTPSContact", inp) .then(function mySuccess(response) {
			$scope.tpsContactArray = response.data;
			$scope.getTPSDetails(inp);
		}, 
		function myError(response) {
			 console.log(response);
		});	
	};
	/*
	 *  Save TPS details in to the DB
	 */
	$scope.saveTPSDetails = function() {
		
		var saveInp = {jobId : $scope.JobID, projectId: $scope.ProjectId, tpsContact: $scope.tpsContact,workflowType:$scope.workflowType,
		percentage: $scope.percentage, target:$scope.target, components:$scope.components, grade:$scope.grade, pageCnt:$scope.pageCnt, batchInfo:$scope.batchInfo, productionDate:$scope.productionDate, lwProjMgr:$scope.lwProjMgr, projDtl:$scope.projDtl, pendDtl:$scope.pendDtl};
		//console.log(saveInp);
	
		$http.post(API_URL+"saveTPS", saveInp) .then(function mySuccess(response) {
		//	console.log(response);
			showMessage('Message', response.data[0].msg, 'success');
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
/*
 *  This section contains Metadata Info Related methods.
 */	

	/*
	 *  This method used to setup Metadata info tab related parameters
	 */
	$scope.showMetaTab = function() {
		$scope.menuChild = 'MetaDataInfo';
		$scope.sectionName = " - Meta Data Info";
		$("#pth_tab").tab('show');
		$scope.projectList = false;
		$scope.checkJobId('meta-data');
		
		$scope.FTPGrid = [];
		$scope.FTPGrid.push({'source_path': '', 'dest_path':'', 'user_name':'', 'password':''});

		$scope.WFPath = [];
		$scope.WFPath.push({'destination_ps_path': '', 'destination_path':'', 'missing_link':'', 'missing_font':'', 'overset':'', 'folio_digits':'', 'folio_digits_1':'', 'folio_digits_2':'', 'folio_digits_3':'', 'folio_digits_4':'', 'pdf_preset':'', 'is_pitstop_required':''});

		var inp = {	jobId : $scope.JobID };
		$http.post(API_URL+"getProcessPath", inp).then(function mySuccess(response) {
			console.log(response); 
			var path = response.data.path[0];
			var ftp = response.data.ftp;
			var wfpath = response.data.wfpath;
			var preset = response.data.preset;
			
			$scope.pr_pdf_path = path.pr_pdf_path;
			$scope.pr_dest_path = path.pr_dest_path;
			$scope.pit_log_path = path.pit_log_path;
			
			$scope.pit_fail_path = path.pit_fail_path;
			$scope.sample_indd_path = path.sample_indd_path;
			$scope.fonts = path.fonts;
			
			$scope.pdf_output_path = path.pdf_output_path;
			$scope.workflow_type_ps_disp = 0;
			$scope.workflow_type = path.workflow_type;
			
			if(path.workflow_type == 1) {
				$scope.workflow_type_pdf =  path.workflow_type;
			}
			else if(path.workflow_type == 2) {
				$scope.workflow_type_ps =  path.workflow_type;
				$scope.workflow_type_ps_disp = 1;
			}			
					
			angular.forEach(wfpath, function (wfp) {
				if(wfp.missing_link) {
					wfp.missing_link = true;
				} else {
					wfp.missing_link = false;
				}
				if(wfp.missing_font) {
					wfp.missing_font = true;
				} else {
					wfp.missing_font = false;
				}
				if(wfp.overset) {
					wfp.overset = true;
				} else {
					wfp.overset = false;
				}
				if(wfp.is_pitstop_required) {
					wfp.is_pitstop_required = true;
				} else {
					wfp.is_pitstop_required = false;
				}
			});
			$scope.preset = preset;
			$scope.FTPGrid = ftp;
			$scope.WFPath = wfpath;			
		}, 
		function myError(response) {
			// console.log(response);
		});		
	};
	/*
	 *  Set workflow type and get the preset list
	 */
	$scope.setWorkflowType = function(opt) {
		$scope.workflow_type = opt;
		$scope.workflow_type_ps_disp = 0;
		if($scope.workflow_type == 1) {
			$scope.workflow_type_pdf =  $scope.workflow_type;				
		}
		else if($scope.workflow_type == 2) {
			$scope.workflow_type_ps =  $scope.workflow_type;
			$scope.workflow_type_ps_disp = 1;
		}
		var inp = {workflowType : $scope.workflow_type}
		$http.post(API_URL+"getPresetList", inp) .then(function mySuccess(response) {
			$scope.preset = response.data.preset;
		}, 
		function myError(response) {
			 console.log(response);
		});		
	};
	/*
	 *  Add another FTP row
	 */
	$scope.addFTPInfo = function() {
		$scope.FTPGrid.push({'source_path': '', 'dest_path':'', 'user_name':'', 'password':''});
	};
	/*
	 *  Remove selected FTP row
	 */
	$scope.removeFTPInfo = function(idx) {
		$scope.FTPGrid.splice(idx,1);
	}
	
	/*
	 *  Add another FTP Path row
	 */
	$scope.addWFPath = function() {
		$scope.WFPath.push({'destination_ps_path': '', 'destination_path':'', 'missing_link':'', 'missing_font':'', 'overset':'', 'folio_digits':'', 'folio_digits_1':'', 'folio_digits_2':'', 'folio_digits_3':'', 'folio_digits_4':'', 'pdf_preset':'', 'is_pitstop_required':''});
	};
	/*
	 *  Remove selected FTP Path row
	 */
	$scope.removeWFPath = function(idx) {
		$scope.WFPath.splice(idx,1);
	};
	/*
	 *  Save the entered meta data info to DB
	 */
	$scope.saveMetadataInfo = function() {
		var fPath = [];
		angular.forEach($scope.WFPath, function (wfp) {
			if(wfp.missing_link === true) {
				wfp.missing_link = 1;
			} else {
				wfp.missing_link = 0;
			}	
			if(wfp.missing_font === true) {
				wfp.missing_font = 1;
			} else {
				wfp.missing_font = 0;
			}
			if(wfp.overset === true) {
				wfp.overset = 1;
			} else {
				wfp.overset = 0;
			}
			if(wfp.is_pitstop_required === true) {
				wfp.is_pitstop_required = 1;
			} else {
				wfp.is_pitstop_required = 0;
			}
			fPath.push(wfp);				
		});
		var metInp = {	jobId 					: $scope.JobID, 
						workflow_type			: $scope.workflow_type,
						pr_pdf_path				: $scope.pr_pdf_path, 
						pr_dest_path 			: $scope.pr_dest_path,
						pit_log_path 			: $scope.pit_log_path,
						pit_fail_path			: $scope.pit_fail_path,
						sample_indd_path  	 	: $scope.sample_indd_path,
						fonts 				 	: $scope.fonts,
						pdf_output_path 	 	: $scope.pdf_output_path,
						userId					: '',
						ftp 					: $scope.FTPGrid,
						path 					: fPath,
					};
		$http.post(API_URL+"saveMetadata", metInp) .then(function mySuccess(response) {
			console.log(response); 			
			showMessage('Message', response.data.msg, 'success');
		}, 
		function myError(response) {
			 console.log(response);
		});		
	};	
		
/*
 *  This section contains Instruction tab Related methods.
 */	

	/*
	 *  Get all the active instruction for the selected job
	 */
	$scope.getInstruction = function(inp) {
		$http.post(API_URL+"getInstruction", inp) .then(function mySuccess(response) {
			var res = response.data;
			$scope.instructions = res.instructions;
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	
	/*
	 *  This method used to setup Instruction tab related parameters
	 */
	$scope.showInstructionTab = function() {
		$scope.ins_roundID  = '0'; $scope.ins_fromPg = '';$scope.ins_toPg = '';
		$scope.menuChild = 'Instruction';
		$scope.sectionName = " - Instruction";
		$("#ins_tab").tab('show');
		$scope.projectList = false;
		$scope.checkJobId('instruction');
		
		$scope.downloadInstructionLink = BASE_URL+"instructionDownload/"+$scope.JobID+"/"+$scope.ins_roundID;
	
		$scope.ins_save = "Save";
		var inp = {	jobId : $scope.JobID, roundId: $scope.ins_roundID, fromPg : $scope.ins_fromPg, toPg: $scope.ins_toPg};

		$http.post(API_URL+"getSchoolRounds", inp) .then(function mySuccess(response) {
			$scope.ins_roundInfo = response.data.data;
		}, 
		function myError(response) {
			// console.log(response);
		});
		
		$scope.getInstruction(inp);
	};
	/*
	 *  This method used to save the entered instructions
	 */
	$scope.saveInstruction = function() {
		var createdDate = ''; 
		var inp = {	jobId : $scope.JobID, roundId: $scope.ins_roundID, fromRange : $scope.ins_fromPg, toRange: $scope.ins_toPg, instruction: $scope.ins_instruction, instructionId: $scope.ins_instructionId, createdDate: createdDate, createdBy : ''};
		
		$http.post(API_URL+"saveInstruction", inp) .then(function mySuccess(response) {
			console.log(response); 
			var res = response.data;
			
			showMessage('Message', response.data[0].msg, 'success');
			$scope.ins_instructionId = '';
			$scope.ins_instruction = '';
			$scope.ins_save = "Save";
			$scope.showAllInstruction();
		}, 
		function myError(response) {
			 console.log(response);
		});		
	};
	/*
	 *  This method used to edit the instruction. 
	 *  Fill the edited instruction details in the form to edit.
	 */
	$scope.editInstruction = function(ins) {
		$scope.ins_instructionId = ins.BOOKMAP_INSTRUCTION_ID;
		$scope.ins_fromPg = ins.FROM_RANGE;
		$scope.ins_toPg = ins.TO_RANGE;
		$scope.ins_roundID = ins.ROUND_ID.toString();
		$scope.ins_instruction = ins.INSTRUCTION;
		$scope.ins_save = "Update";		
	};
	/*
	 *  This method used to search the instruction
	 *  Search based on Job, Round, Pagination
	 */
	$scope.searchInstruction = function() {
		var inp = {	jobId : $scope.JobID, roundId: $scope.ins_roundID, fromPg : $scope.ins_fromPg, toPg: $scope.ins_toPg};
		$scope.getInstruction(inp);		
	};
	/*
	 *  This method used to list all the active instructions
	 *  For the selected Job
	 */
	$scope.showAllInstruction = function() {
		$scope.ins_fromPg = '';$scope.ins_toPg = '';$scope.ins_roundID = '';
		var inp = {	jobId : $scope.JobID, roundId: $scope.ins_roundID, fromPg : $scope.ins_fromPg, toPg: $scope.ins_toPg};
		$scope.getInstruction(inp);
	};
	/*
	 *  This method used to delete the selected instruction after getting confirmation from the user
	 */
	$scope.deleteInstruction = function(insId) {
		bootbox.confirm("Are you sure you want to delete?", function(result) {
			if(result) {					
				
				var delInp = {	jobId : $scope.JobID, 
								instructionId: insId, 
							};
				$http.post(API_URL+"deleteInstruction", delInp) .then(function mySuccess(response) {
					var res = response.data;
					
					showMessage('Message', "Instruction deleted successfully.",'success');
					$scope.showAllInstruction();
				}, 
				function myError(response) {
					// console.log(response);
				});				
			}
		});	
	};
		
/*
 *  This section contains Move to Production tab Related methods.
 */	

	$scope.prd_roundID  = ''; $scope.prd_workflowID = '';$scope.prd_fromPg = '';$scope.prd_toPg = ''; $scope.prd_chkAllPg = true;
	
	/*
	 *  Get the folios that are not moved to production
	 *  Based on selected job, round and pagination
	 */
	$scope.getPrdPages = function(inp) {
		$http.post(API_URL+"getPrdPages", inp) .then(function mySuccess(response) {
			var res = response.data;
			$scope.prd_pages = res.pages;			
			$scope.prd_selectedAllPg = false;
			$scope.checkAllPg();
		}, 
		function myError(response) {
			// console.log(response);
		});
	};
	/*
	 *  This method used to select all the folios.
	 */
	$scope.checkAllPg = function () {
        if ($scope.prd_selectedAllPg) {
            $scope.prd_selectedAllPg = false;
        } else {
            $scope.prd_selectedAllPg = true;
        }
        angular.forEach($scope.prd_pages, function (pg) {
			pg.prd_SelectedPg = $scope.prd_selectedAllPg;
        });
    };
	
	/*
	 *  This method used to set up moved to production tab related information
	 */
	$scope.showMoveToPrdTab = function() {	
		$scope.menuChild = 'MoveToProduction';		
		$scope.sectionName = " - Move To Production";
		$("#prd_tab").tab('show');
		$scope.projectList = false;
		$scope.checkJobId('move-to-production');
		
		var inp = {	jobId : $scope.JobID, roundId: $scope.prd_roundID, fromPg : $scope.prd_fromPg, toPg: $scope.prd_toPg};
		
		$http.post(API_URL+"getPrdTabInfo", inp) .then(function mySuccess(response) {
		//	console.log(response.data); 
			var res = response.data;
			$scope.prd_roundInfo = res.roundInfo;
			$scope.prd_workflowInfo = res.workflowInfo;	
					
			if($scope.prd_roundInfo.length> 0 && $scope.prd_roundID == 0) $scope.prd_roundID = $scope.prd_roundInfo[0].ROUND+"";		
			if($scope.prd_workflowInfo.length > 0 && $scope.prd_workflowID == 0) $scope.prd_workflowID = $scope.prd_workflowInfo[0].WORKFLOW+"";
			$scope.getPrdPages(inp);
		}, 
		function myError(response) {
			// console.log(response);
		});
	};
	
	/*
	 *  This method set up input for get production pages method ** getPrdPages **
	 *  Based on selected Job, round and pagination
	 */
	$scope.findPageMoveToPro = function() {
		 var inp = { jobId : $scope.JobID, roundId: $scope.prd_roundID, fromPg : $scope.prd_fromPg, toPg: $scope.prd_toPg};
		 $scope.getPrdPages(inp);
	};
	/*
	 *  This method set up input for get production pages method ** getPrdPages **
	 *  It will pass job and round details 
	 */
	$scope.showAllPages = function() {
		$scope.prd_fromPg = '';$scope.prd_toPg = '';
		var inp = {	jobId : $scope.JobID, roundId: $scope.prd_roundID, fromPg : $scope.prd_fromPg, toPg: $scope.prd_toPg}; 
		$scope.getPrdPages(inp);
	};
	/*
	 *  This method move the selected folios to production after getting the confirmation from the user
	 */
	$scope.showConfirm = function() {
		
		$scope.metaInfo = [];
		$scope.quantity = 1;
		angular.forEach($scope.prd_pages, function (pg) {
			if(pg.prd_SelectedPg) {
				var mId = pg.metadata_id.split(",");
				for(var k=0; k<mId.length; k++) {
					$scope.metaInfo.push({metaId: mId[k], quantity: $scope.quantity});
				}
			}
		});
		
		if($scope.metaInfo.length > 0) {
			bootbox.confirm("Are you sure you want to move the selected pages to production?", function(result) {
				if(result) {
					
					if($scope.metaInfo.length > 0) {
						var prdInp = {	jobId : $scope.JobID, 
										roundId: $scope.prd_roundID, 
										workflowId : $scope.prd_workflowID, 
										userId: '',
										metadata : $scope.metaInfo
									};
						$http.post(API_URL+"moveToPrd", prdInp) .then(function mySuccess(response) {
							var res = response.data;
							var msg = '';
							for(var k=0; k<res.length; k++) {
								msg = msg + res[k][0]['errmsg'] +"<br/>";
							}
							showMessage('Move To Production', msg, 'success');
							$scope.showAllPages();
						}, 
						function myError(response) {
							// console.log(response);
						});
					}
				}
			});	
		} else {
			showMessage("Warning", "No folios selected. Please select folios to move to production.", 'warning');
		}
	};
        $scope.goToSelectedTab();
});	