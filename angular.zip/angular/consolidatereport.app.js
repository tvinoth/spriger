/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope, $http,$compile,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{
	$scope.userId 		= 	0;	
	$scope.JobID 		=	"";
	if(isNaN(getUrlParameter(1))){
		$scope.JobID 	= 	"";
	}else{
		$scope.JobID 	= 	getUrlParameter(1);
	}
        
        
 	$scope.menuParent 	= 	'Pre-Production';
	$scope.menuChild 	= 	'ConsolidateReport';
        $scope.roleId           =   '';
	
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
        $scope.contentloadtimer         =   1;
	$scope.consolidateallList 	= 	function() 
	{
            $scope.consolidate 	= 	[];
            $http.get(BASE_URL+"getConsolidateList") .then(function mySuccess(response) 
            {
                    $scope.consolidate 	= 	response.data.consolidate;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.consolidateallList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });		
            $scope.contentloadtimer++;
	};
        
        if($scope.JobID     ==  ''){
            $scope.consolidateallList();
        }
        
        $scope.consalidateinfodetails   =   function(book)
        {
            $window.location.href 	=   BASE_URL+"consolidateList-job/"+book.JOB_ID;
        }
        
        $scope.typeofcontainesm         =   ['YES','NO'];
        $scope.typeofchapter            =   [];
        $scope.consolidateArray         =   [];
        $scope.dataArray                =   [];
        $scope.dispatchbutton           =   0;
        $scope.jobupdatebutton          =   '';
        $scope.contentloadtimer         =   1;
        $scope.consolidateofjob 	=   function() 
	{
            $scope.consolidateList 	=   [];
            $scope.jobcountList 	=   [];
            var inp                     =   {'jodId' : $scope.JobID};
            $http.post(BASE_URL+"consolidate_reportofjob",inp) .then(function mySuccess(response) 
            {
                $scope.consolidateList 	=   response.data.parreport;
                $scope.dispatchbutton 	=   response.data.jobsheetdisptchfile;
                $scope.savebutton 	=   response.data.savebutton;
                
//                if($scope.dispatchfile  ==  3 || $scope.dispatchfile  ==  "1.5")
//                {
//                    $scope.dispatchbutton   =   1;
//                }
                
                $scope.jobupdatebutton 	=   response.data.jobupdatebutton;
               
//                if( $scope.dispatchbutton == 0 && $scope.dispatchfile == 0 && $scope.jobupdatebutton == 0 )
//                    $scope.dispatchbutton   =   0;
//                if($scope.jobupdatebutton == 1)
//                    $scope.dispatchbutton   =   1;
                
                $scope.NO_ROMAN_PAGES   =   response.data.romanpagecount;
                $scope.NO_ARABIC_PAGES  =   response.data.arbicpagecount;
                $scope.totalpagecount 	=   response.data.totalpagecount;
                $scope.typeofchapter    =   response.data.partlistofchpter;
                $scope.jsmspage         =   response.data.jsmspage;
                $scope.apageobjectcount =   response.data.apagecount;
                $scope.partcount        =   response.data.partcount;
                $scope.chaptercount 	=   response.data.chaptercount;		
                $scope.finaljsmspages 	=   response.data.jsmspcount;		
                $scope.finalmspages 	=   response.data.mspcount;		
                $scope.finalnotable 	=   response.data.notablecount;		
                $scope.finalnounnumtable=   response.data.nounnumtablecount;		
                $scope.finalnoequation 	=   response.data.noequatincount;		
                $scope.finalnounnumequation 	=   response.data.nounnumequatincount;		
                $scope.finalnofigure            =   response.data.nofigurcount;		
                $scope.finalnonumfigure 	=   response.data.nonumfigurcount;		
                $scope.finalnounnumfigure 	=   response.data.nounnumfigurcount;		
                $scope.finalnoartfigure 	=   response.data.noartfigurecount;		
                $scope.finalnounnumartfigure 	=   response.data.noartunnumfigurecount;		
                $scope.finalnoschemes           =   response.data.noschemescount;		
                $scope.finalnounnumschemes 	=   response.data.nounnumschemescount;		
                $scope.finalnoartstructure 	=   response.data.noartstructurecount;		
                $scope.finalnounnumartstructure =   response.data.noartunstructurecount;		
                $scope.finalnoartequation 	=   response.data.noartequtioncount;		
                $scope.finalnounnumartequation 	=   response.data.nounnumartequtioncount;		
                $scope.finalcountbychar 	=   response.data.pagebycharcount;		
                $scope.finalcountbyword 	=   response.data.pagebywordcount;		
                $scope.finalnoofspicastpages 	=   response.data.spicastpagecount;		
                $scope.finalnoofspicastartpages     =   response.data.spicastartpagecount;		
                $scope.finalnoofspicastblankpages   =   response.data.spicastblankpagecount;		
                $scope.finalnoofspicasttotalpage    =   response.data.spicasttotalpagecount;		
                $scope.finalcucreport           =   response.data.spicastcucrportcount;	
                $scope.totalillustra            =   response.data.totalillustration;	
                $scope.totalbwcolor             =   response.data.bwcolor;	
                $scope.totalcolor               =   response.data.colorillustration;	
                
                $scope.dataArray                =   Object.keys($scope.typeofchapter)
                .map(function (key) {
                    return $scope.typeofchapter[key];
                });
                
                $scope.consolidateArray         =   Object.keys($scope.consolidateList)
                .map(function (key) {
                    return $scope.consolidateList[key];
                });
                
                
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.consolidateofjob();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });			
            $scope.contentloadtimer++;
	};
        
        if($scope.JobID     !=  ''){
            $scope.consolidateofjob();
        }
        
        $scope.updatejobSheet 	= 	function(JobID)
        {    
            var chaptersequence         =   $('input[name="chapterseq[]"]').map(function(){return $(this).val();}).get();
            var titleofchpter           =   $('input[name="titleofchpter[]"]').map(function(){return $(this).val();}).get();
            var containesm              =   $('select[name="containesm[]"]').map(function(){return $(this).val();}).get();
            var partcategory            =   $(".partcategory").is(':visible');
//            var romancount      =   0;
//            for (var i = 0; i < totalromanpages.length; i++) {
//                romancount += totalromanpages[i] << 0;
//            }
//            if($scope.partcount     >= 1){
//                var partnamevalidation  =   $(".partvalidation").map(function(){return $(this).val();}).get();
//                var emptypartname       =   partnamevalidation.filter(consmval => consmval.length == 0);
//                if(emptypartname.length   >=  1){
//                    showNotify('Part filed is required', 'danger' );
//                    hideLoader();
//                    return false;
//                }
//            }
            
//          //sequence validation
            var emptychptersequnce      =   chaptersequence.filter(function (val){
                                                return val ==   "" || val ==   0;
                                            });
                                            
            if(emptychptersequnce.length   >=  1){
                showNotify('Chapter Sequnce field is required', 'danger' );
                hideLoader();
                return false;
            }
            
            if(partcategory     ==  true){
                var partcategoriesvalidation    =   $('.availablepart').map(function(){
                    if($(this).data('exceptpartvalidation') !=  ''){
                        return $(this).val();
                    }
                }).get();
                
                var partcategoriesvalidation      =   partcategoriesvalidation.filter(val => val.length == 0);                       
                if(partcategoriesvalidation.length   >=  1){
                    showNotify('All part field is required', 'danger' );
                    hideLoader();
                    return false;
                }
            }
            //Chapter Title validation
            var emptytitleofchpter      =   titleofchpter.filter(function(val){
                return val == "" || val == 0;
            });
            if(emptytitleofchpter.length   >=  1)
            {
                showNotify('Chapter Title field is required', 'danger' );
                hideLoader();
                return false;
            }
            //containsm validation
            var emptycontainsmvalue     =   containesm.filter(consmval => consmval.length == 0);
            if(emptycontainsmvalue.length   >=  1)
            {
                showNotify('ContainsESM field is required', 'danger' );
                hideLoader();
                return false;
            }
            
            showLoader('Please wait update is in progress');
            var jobId = {'jobId' : JobID};
                $http.post( BASE_URL+"updateJobSheet" , jobId ) .then( function mySuccess(response){
                    hideLoader();
                    
                    if(response.data.REMARKS == 'Failure' || response.data.REMARKS == '' ){
                        
                        if(response.data.errMsg !=''){
                           showNotify(response.data.errMsg , 'danger' );
                        }else{
                            showNotify('Jobsheet not updated'  , 'danger' );
                        }
                    }
                    if(response.data.status == '0'){
                        
                        if(response.data.errMsg !=''){
                           showNotify(response.data.errMsg , 'danger' );
                        }else{
                            showNotify('Jobsheet not updated'  , 'danger' );
                        }
                    }
                    if(response.data.REMARKS == 'Success'){
                        $scope.dispatchbutton  =   0;
                        $scope.savebutton   =   0;
                        angular.element(document.getElementById("jobupdtedispatchID_"+JobID)).attr('disabled','disabled');
                        showNotify('Jobsheet updated successfully'  , 'success' );
                    }
                    
                },function myError(response){
                    hideLoader();
                });	
                
        };

        
        //calculate jsmsg pages
        $scope.jsmspagesChanged     =   function(row) 
        {
            $scope.getalljsmsp      =   $('input[name="noofjsmsp[]"]').map(function(){return $(this).val();}).get();
            $scope.finaljsmspages   =   Math.round($scope.calculate($scope.getalljsmsp));
        }   
        //calculate ms pages
        $scope.mspagesChanged       =   function(row) 
        {
            $scope.getallmsp        =   $('input[name="noofmsp[]"]').map(function(){return $(this).val();}).get();
            $scope.finalmspages     =   Math.round($scope.calculate($scope.getallmsp));
        }
        //calculate notable
        $scope.notableChanged       =   function(row) 
        {
            $scope.getallnotable    =   $('input[name="nooftables[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnotable     =   Math.round($scope.calculate($scope.getallnotable));
        }
        
        //calculate nounnumtableChanged
        $scope.nounnumtableChanged  =   function(row) 
        {
            $scope.getallnounnumtable   =   $('input[name="noofunnumberedtables[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumtable    =   Math.round($scope.calculate($scope.getallnounnumtable));
        }
        //calculate noequationChanged
        $scope.noequationChanged    =   function(row) 
        {
            $scope.getallnoofeq     =   $('input[name="noofequations[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoequation  =   Math.round($scope.calculate($scope.getallnoofeq));
        }
        //calculate noequationunnumChanged
        $scope.noequationunnumChanged   =   function(row) 
        {
            $scope.getallnounnumeq      =   $('input[name="noofunnumberedequations[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumequation =   Math.round($scope.calculate($scope.getallnounnumeq));
        }
        //calculate nofigureChanged
        $scope.nofigureChanged          =   function(row) 
        {
            $scope.getallnofigure       =   $('input[name="nooffigure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnofigure        =   Math.round($scope.calculate($scope.getallnofigure));
        }
        //calculate nounnumfigureChanged
        $scope.nonumfigureChanged       =   function(row) 
        {
            $scope.getallnonumfigure    =   $('input[name="noofnumberedfigure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnonumfigure     =   Math.round($scope.calculate($scope.getallnonumfigure));
        }
        
        //calculate nounnumfigureChanged
        $scope.nounnumfigureChanged     =   function(row) 
        {
            $scope.getallnounnumfigure  =   $('input[name="noofunnumberedfigure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumfigure   =   Math.round($scope.calculate($scope.getallnounnumfigure));
        }
        //calculate noarttableChanged
//        $scope.noarttableChanged        =   function(row) 
//        {
//            $scope.getallnoarttable     =   $('input[name="noofartables[]"]').map(function(){return $(this).val();}).get();
//            $scope.finalnoarttable      =   $scope.calculate($scope.getallnoarttable);
//        }
//        //calculate nounnumarttableChanged
//        $scope.nounnumarttableChanged   =   function(row) 
//        {
//            $scope.getallnounnumarttable     =   $('input[name="noofartunnumberedtables[]"]').map(function(){return $(this).val();}).get();
//            $scope.finalnounnumarttable      =   $scope.calculate($scope.getallnounnumarttable);
//        }
        //calculate noartfigureChanged
        $scope.noartfigureChanged           =   function(row) 
        {
            $scope.getallnoartfigure        =   $('input[name="noofartfigure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoartfigure         =   Math.round($scope.calculate($scope.getallnoartfigure));
        }
        //calculate nounnumartfigureChanged
        $scope.nounnumartfigureChanged      =   function(row) 
        {
            $scope.getallnounnumartfigure   =   $('input[name="noofartunnumberedfigure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumartfigure    =   Math.round($scope.calculate($scope.getallnounnumartfigure));
        }
        //calculate noschemesChanged
        $scope.noschemesChanged         =   function(row) 
        {
            $scope.getallnoschemes      =   $('input[name="noofschemes[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoschemes       =   Math.round($scope.calculate($scope.getallnoschemes));
        }
        //calculate nounnumschemesChanged
        $scope.nounnumschemesChanged    =   function(row) 
        {
            $scope.getallnounnumschemes =   $('input[name="noofnumberedschemes[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumschemes  =   Math.round($scope.calculate($scope.getallnounnumschemes));
        }
        //calculate noartstructureChanged
        $scope.noartstructureChanged    =   function(row) 
        {
            $scope.getallnoartstructure =   $('input[name="noofartstructure[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoartstructure  =   Math.round($scope.calculate($scope.getallnoartstructure));
        }
        //calculate nounnumartstructureChanged
        $scope.nounnumartstructureChanged    =   function(row) 
        {
            $scope.getallnounnumartstructure =   $('input[name="noofartstructureunnumbered[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumartstructure  =   Math.round($scope.calculate($scope.getallnounnumartstructure));
        }
        //calculate noartequationChanged
        $scope.noartequationChanged    =   function(row) 
        {
            $scope.getallnoartequation =   $('input[name="noofartequations[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoartequation  =   Math.round($scope.calculate($scope.getallnoartequation));
        }
        //calculate nounnumartequationChanged
        $scope.nounnumartequationChanged    =   function(row) 
        {
            $scope.getallnounnumartequation =   $('input[name="noofartunnumberedequations[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnounnumartequation  =   Math.round($scope.calculate($scope.getallnounnumartequation));
        }
        
        //calculate nocountbycharChanged
        $scope.nocountbycharChanged     =   function(row) 
        {
            $scope.getallcountbychar    =   $('input[name="pagecountbychar[]"]').map(function(){return $(this).val();}).get();
            $scope.finalcountbychar     =   Math.round($scope.calculate($scope.getallcountbychar));
        }
        //calculate nocountbywordChanged
        $scope.nocountbywordChanged     =   function(row) 
        {
            $scope.getallcountbyword    =   $('input[name="pagecountbyword[]"]').map(function(){return $(this).val();}).get();
            $scope.finalcountbyword     =   Math.round($scope.calculate($scope.getallcountbyword));
        }
        //calculate nospicastpageChanged
        $scope.nospicastpageChanged     =   function(row) 
        {
            $scope.getallnoofspicastpages   =   $('input[name="noofspicastpages[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoofspicastpages    =   Math.round($scope.calculate($scope.getallnoofspicastpages));
        }
        
        //calculate nospicastartpageChanged
        $scope.nospicastartpageChanged          =   function(row) 
        {
            $scope.getallnoofspicastartpages    =   $('input[name="noofspicastartpages[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoofspicastartpages     =   Math.round($scope.calculate($scope.getallnoofspicastartpages));
        }
        //calculate nospicastblankpageChanged
        $scope.nospicastblankpageChanged        =   function(row) 
        {
            $scope.getallnoofspicastblankpages  =   $('input[name="noofspicastblankpages[]"]').map(function(){return $(this).val();}).get();
            $scope.finalnoofspicastblankpages   =   Math.round($scope.calculate($scope.getallnoofspicastblankpages));
        }
        //calculate nospicasttotalpageChanged
        $scope.nospicasttotalpageChanged        =   function(row) 
        {
            $scope.getallromanpagecount         =   $('.frontmatter').map(function(){return $(this).val();}).get();
            $scope.getallarabicpagecount        =   $('.exceptfrontmatter').map(function(){return $(this).val();}).get();
            $scope.finalnoofromanpage           =   Math.round($scope.calculate($scope.getallromanpagecount));
            $scope.finalnoofarabicpage          =   Math.round($scope.calculate($scope.getallarabicpagecount));
            $scope.arabiccount                  =   $scope.finalnoofarabicpage;
            $scope.romancount                   =   $scope.finalnoofromanpage+parseFloat(4);
            $scope.totalpagecount               =   Math.round(parseFloat($scope.arabiccount))+Math.round(parseFloat($scope.romancount));
            $scope.finalnoofspicasttotalpage    =   Math.round(parseFloat($scope.finalnoofromanpage))+Math.round(parseFloat($scope.finalnoofarabicpage));
        }
        
        $scope.calculate        =   function(values)
        {
            var countall        =   0;
            for (var i = 0; i < values.length; i++) {
            if(values[i] !=     ""){  
                countall += parseFloat(values[i]);
                }
            }
            return parseFloat(countall);
        }
   
        $scope.$watch('romancount', function(newValue, oldValue)
        {
            $scope.totalpagecount       =   Math.round(parseFloat(newValue))+Math.round(parseFloat($scope.arabiccount));
        });
        
        $scope.$watch('arabiccount', function(newValue, oldValue)
        {
            $scope.totalpagecount       =   Math.round(parseFloat(newValue))+Math.round(parseFloat($scope.romancount));
        });

        $scope.showSuccessredologview   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.acaID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.afuROUND
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
        
	$scope.updateconsolidateitemsall    = 	function(paritem) 
	{
            var     totalcount          =   $scope.romancount+$scope.arabiccount;
//            console.log(totalcount);
//            if(totalcount   !=  $scope.totalpagecount)
//            {
//                $scope.color            =       "red";
//                $scope.successmsg 	=	"Arabic and Roman pages is not equal to total pages";
//                return false;
//            }
            showLoader('Please wait while adding Data...');
            
            var chaptertypesselect      =   $('select[name="chaptertypesselect[]"]').map(function(){return $(this).val();}).get();
            var chaptersequence         =   $('input[name="chapterseq[]"]').map(function(){return $(this).val();}).get();
            var chapters                =   $('[name="chapters[]"]').map(function(){return $(this).val();}).get();
            var titleofchpter           =   $('input[name="titleofchpter[]"]').map(function(){return $(this).val();}).get();
            var containesm              =   $('select[name="containesm[]"]').map(function(){return $(this).val();}).get();
            var numbers                 =   $('input[name="numbers[]"]').map(function(){return $(this).val();}).get();
            var noofmsp                 =   $('input[name="noofmsp[]"]').map(function(){return $(this).val();}).get();
//            var noofjsmsp               =   $('input[name="noofjsmsp[]"]').map(function(){return $(this).val();}).get();
            var nooftables              =   $('input[name="nooftables[]"]').map(function(){return $(this).val();}).get();
            var noofunnumberedtables    =   $('input[name="noofunnumberedtables[]"]').map(function(){return $(this).val();}).get();
            var noofequations           =   $('input[name="noofequations[]"]').map(function(){return $(this).val();}).get();
            var noofequations           =   $('input[name="noofequations[]"]').map(function(){return $(this).val();}).get();
            var metaids                 =   $('input[name="metaids[]"]').map(function(){return $(this).val();}).get();
            var noofunnumberedequations =   $('input[name="noofunnumberedequations[]"]').map(function(){return $(this).val();}).get();
            var nooffigure              =   $('input[name="nooffigure[]"]').map(function(){return $(this).val();}).get();
            var noofnumberedfigure      =   $('input[name="noofnumberedfigure[]"]').map(function(){return $(this).val();}).get();
            var noofunnumberedfigure    =   $('input[name="noofunnumberedfigure[]"]').map(function(){return $(this).val();}).get();
//            var noofartables            =   $('input[name="noofartables[]"]').map(function(){return $(this).val();}).get();
//            var noofartunnumberedtables =   $('input[name="noofartunnumberedtables[]"]').map(function(){return $(this).val();}).get();
            var noofartfigure           =   $('input[name="noofartfigure[]"]').map(function(){return $(this).val();}).get();
            var noofartunnumberedfigure =   $('input[name="noofartunnumberedfigure[]"]').map(function(){return $(this).val();}).get();
            var noofschemes             =   $('input[name="noofschemes[]"]').map(function(){return $(this).val();}).get();
            var noofnumberedschemes     =   $('input[name="noofnumberedschemes[]"]').map(function(){return $(this).val();}).get();
            var noofartstructure        =   $('input[name="noofartstructure[]"]').map(function(){return $(this).val();}).get();
            var noofartstructureunnumbered  =   $('input[name="noofartstructureunnumbered[]"]').map(function(){return $(this).val();}).get();
            var noofartequations        =   $('input[name="noofartequations[]"]').map(function(){return $(this).val();}).get();
            var noofartunnumberedequations      =   $('input[name="noofartunnumberedequations[]"]').map(function(){return $(this).val();}).get();
            var pagecountbychar         =   $('input[name="pagecountbychar[]"]').map(function(){return $(this).val();}).get();
            var pagecountbyword         =   $('input[name="pagecountbyword[]"]').map(function(){return $(this).val();}).get();
            var noofspicastpages        =   $('input[name="noofspicastpages[]"]').map(function(){return $(this).val();}).get();
            var totalromanpages         =   $('.frontmatter').map(function(){return $(this).val();}).get();
            var totalarabicpages        =   $('.exceptfrontmatter').map(function(){return $(this).val();}).get();
            var noofspicastartpages     =   $('input[name="noofspicastartpages[]"]').map(function(){return $(this).val();}).get();
            var noofspicastblankpages   =   $('input[name="noofspicastblankpages[]"]').map(function(){return $(this).val();}).get();
            var noofspicasttotalpages   =   $('input[name="noofspicasttotalpages[]"]').map(function(){return $(this).val();}).get();
            var partcategory            =   $(".partcategory").is(':visible');
//            var romancount      =   0;
//            for (var i = 0; i < totalromanpages.length; i++) {
//                romancount += totalromanpages[i] << 0;
//            }
//            if($scope.partcount     >= 1){
//                var partnamevalidation  =   $(".partvalidation").map(function(){return $(this).val();}).get();
//                var emptypartname       =   partnamevalidation.filter(consmval => consmval.length == 0);
//                if(emptypartname.length   >=  1){
//                    showNotify('Part filed is required', 'danger' );
//                    hideLoader();
//                    return false;
//                }
//            }
            
//          //sequence validation
            /*var emptychptersequnce      =   chaptersequence.filter(function (val){
                                                return val ==   "" || val ==   0;
                                            });
                                            
            if(emptychptersequnce.length   >=  1){
                showNotify('Chapter Sequnce field is required', 'danger' );
                hideLoader();
                return false;
            }
            
            if(partcategory     ==  true){
                var partcategoriesvalidation    =   $('.availablepart').map(function(){return $(this).val();}).get();
                var partcategoriesvalidation      =   partcategoriesvalidation.filter(val => val.length == 0);                       
                if(partcategoriesvalidation.length   >=  1){
                    showNotify('All part field is required', 'danger' );
                    hideLoader();
                    return false;
                }
            }
            
            //containsm validation
            var emptycontainsmvalue     =   containesm.filter(consmval => consmval.length == 0);
            if(emptycontainsmvalue.length   >=  1)
            {
                showNotify('ContainsESM field is required', 'danger' );
                hideLoader();
                return false;
            }*/
            
            //Chapter Title validation
            var emptytitleofchpter      =   titleofchpter.filter(function(val){
                return val == "" || val == 0;
            });
            if(emptytitleofchpter.length   >=  1)
            {
                showNotify('Chapter Title field is required', 'danger' );
                hideLoader();
                return false;
            }
            
            var romancount        =   0;
            for (var i = 0; i < totalromanpages.length; i++) {
            if(totalromanpages[i] !=     ""){  
                romancount += parseFloat(totalromanpages[i]);
                }
            }
            
            if(parseInt(romancount)     !=  0)
            {
                romancount  =   parseFloat(romancount)+parseFloat(4);
            }else{
                romancount  =   parseFloat(romancount);
            }
            
//            var arabiccount      =   0;
//            for (var i = 0; i < totalarabicpages.length; i++) {
//                arabiccount += totalarabicpages[i] << 0;
//            }
            var arabiccount        =   0;
            for (var i = 0; i < totalarabicpages.length; i++) {
            if(totalarabicpages[i] !=     ""){  
                arabiccount += Math.round(parseFloat(totalarabicpages[i]));
                }
            }
            var inp    =    {
                        job_id          :   $scope.JobID,
                        chapters        :   chapters,
                        partcategory    :   partcategory,
                        chaptercount    :   $scope.chaptercount,
                        partcount       :   $scope.partcount,
                        apageobjectcount:   Math.round($scope.apageobjectcount),
                        romancount      :   Math.round(romancount),
                        arabiccount     :   Math.round(arabiccount),
                        chaptersequence :   chaptersequence,
                        metaids         :   metaids,
                        chaptertypesselect    :   chaptertypesselect ,
                        numbers         :   numbers,
                        titleofchpter   :   titleofchpter,
                        containesm      :   containesm,
                        noofmsp         :   noofmsp,
//                        noofjsmsp       :   noofjsmsp,
                        nooftables      :   nooftables,
                        noofunnumberedtables    :   noofunnumberedtables,
                        noofequations           :   noofequations,
                        noofunnumberedequations :   noofunnumberedequations,
                        nooffigure              :   nooffigure,
                        noofunnumberedfigure    :   noofunnumberedfigure,
//                        noofartables            :   noofartables,
//                        noofartunnumberedtables   :   noofartunnumberedtables,
                        noofartfigure           :   noofartfigure,
                        noofnumberedfigure      :   noofnumberedfigure,
                        noofartunnumberedfigure :   noofartunnumberedfigure,
                        noofschemes             :   noofschemes,
                        noofnumberedschemes     :   noofnumberedschemes,
                        noofartstructure        :   noofartstructure,
                        noofartstructureunnumbered   :   noofartstructureunnumbered,
                        noofartequations        :   noofartequations,
                        noofartunnumberedequations   :   noofartunnumberedequations,
                        pagecountbychar         :   pagecountbychar,
                        pagecountbyword         :   pagecountbyword,
                        noofspicastpages        :   noofspicastpages,
                        noofspicastartpages     :   noofspicastartpages,
                        noofspicastblankpages   :   noofspicastblankpages,
                        noofspicasttotalpages   :   noofspicasttotalpages
                    }; 
                
		$http.post(BASE_URL+'consolidate_updateall',inp).then(function mySuccess(response)
		{
                    $scope.consolidateofjob();
                    hideLoader();
                        showNotify(response.data.errMsg  , 'success' );
		},
		function myError(response)
		{
                    hideLoader();
                        showNotify(response.data.errMsg  , 'danger' );
		});
	};
	
	$scope.jobandcucview    =   '';
        $scope.doCucReportview  =   function(cucinfo) 
        {     
            var currentChapter  =   angular.element(document.getElementById("chaptercucview_"+cucinfo.taskmetaid));
            var inp             =   {
                                        jobId       :   cucinfo.JOB_ID,
                                        metadataid  :   cucinfo.METADATA_ID,
                                        Chapter     :   cucinfo.CHAPTER_NO
                                    };
            $(currentChapter).attr('disabled','true');
            $scope.jobandcucview    =   "Cuc Report View";
            var window_dimensions   =   "directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=0,resizable=0, width=1200,height=850";
//            $('#show-cucview').trigger('click');
//            $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
            $http({
                    url         :   BASE_URL + "getCucView",
                    method      :   'POST',
                    data        :   inp
                 })
            .success(function(response) 
            {
                if(response.xmlcount >= 1)
                {
//                    $('#show-cucview').trigger('click');
//                    var window_dimensions   =   "directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=0,resizable=0, width=1200,height=850";
//                    window.open(response.errMsg, "CUC Log View", window_dimensions);
//                    $scope.heightofmodal        =   600;
                    $(currentChapter).removeAttr('disabled','true');
                    window.open(response.errMsg, "CUC Log View", window_dimensions);
                }
                else
                {
                    $(currentChapter).removeAttr('disabled','true');
//                    $scope.heightofmodal        =   100;
//                    $('#xmlContent').html(response.errMsg);
                    var myWindow    =   $window.open("", "CUC Log View",  window_dimensions);
                    myWindow.document.write(response.errMsg);
                }
            })
            .error(function(response) 
            {
                $(currentChapter).removeAttr('disabled','true');
                var myWindow    =   $window.open("", "CUC Log View",  window_dimensions);
                myWindow.document.write(response.errMsg);
            });
        }
        
        $scope.doOpenLogFolder  =   function(cucinfo) 
        {
            showLoader('Please wait while checkout...');
            var inp             =   {
                                        jobId       :   cucinfo.JOB_ID,
                                        metadataid  :   cucinfo.METADATA_ID,
                                        Chapter     :   cucinfo.CHAPTER_NO
                                    };  
                                    
            var taskmetaid      =   cucinfo.taskmetaid;
            var currentChapter  =   angular.element(document.getElementById("chaptercucview_"+cucinfo.taskmetaid));
            $(currentChapter).attr('disabled','true');
            $http.post(BASE_URL + 'cucOpendrive', inp)
            .then(function mySuccess(response) 
            {
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    $(currentChapter).removeAttr('disabled','true');
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    $(currentChapter).removeAttr('disabled','true');
                    hideLoader();
                }

                if(response.data.result     ==  500)
                {
                    showNotify( response.data.errMsg  , 'warning' );
                    $(currentChapter).removeAttr('disabled','true');
                    hideLoader();
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
                    $scope.checkfilestatusopenornot(taskmetaid,cucinfo.jobid,cucinfo.CHAPTER_NO,attempt,filehandlerid);
                }
            }, 
            function myError(response) 
            {
                $(currentChapter).removeAttr('disabled','true');
            });
        };
        
        $scope.checkfilestatusopenornot     =   function(taskmetaid,jobId,CHAPTER_NO,attempt,filehandlerid) 
        {           
            var currentChapter  =   angular.element(document.getElementById("chaptercucview_"+taskmetaid));
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Checkout'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                $(currentChapter).removeAttr('disabled','true');
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(taskmetaid,jobId,CHAPTER_NO,attempt,filehandlerid); }, 2000 );
                    } else {
                        hideLoader();
                        showNotify("File handler is not running. Please check.", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    hideLoader();
                    showNotify( "CUC Log folder opened successfully", 'success' );
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                $(currentChapter).removeAttr('disabled','true');
            });
        };
    
        $scope.jobandcucview    =   '';
        $scope.viewjobSheet     =   function() 
        {     
            var jobid           =   $(".jobsheetviewdata").data('getjobid');
            var inp             =   {
                                        jobId       :   jobid,
                                        stagename   :   $scope.viewjobsheet
                                    };
            if($scope.viewjobsheet  ==  "" || $scope.viewjobsheet   ==  undefined)
            {
                return false;
            }
//            e.target.name
            $scope.jobandcucview    =   $scope.viewjobsheet+" Jobsheet View";
            $('#show-cucview').trigger('click');
            $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
            $http({
                    url         :   BASE_URL + "consolidate_jobsheetview",
                    method      :   'POST',
                    data        :   inp
                 })
            .success(function(response) 
            {
                if(response.xmlcount >= 1)
                {
                    $scope.heightofmodal        =   700;
                    $('#xmlContent').html(response.errMsg);
                }
                else
                {
                    $scope.heightofmodal        =   100;
                    $('#xmlContent').html(response.errMsg);
                }
            })
            .error(function(response) 
            {
                hideLoader();
                $('#xmlContent').html(response.errMsg);
            });
        }
        
        //dispatch job sheet
        $scope.dispatchjobSheet     =   function(jobID)
        {
            showLoader('Please wait while dispatching jobsheet...');
            $http.get(BASE_URL+'sendRequestS50JobSheetUpload/'+jobID+"/"+'S50'+"/NOTIFICATION").then(function mySuccess(response) 
            {
                if(response.data.status  == 1)
                {
                    angular.element(document.getElementById("dispatchID_"+jobID)).attr('disabled','disabled');
                    showNotify( 'Jobsheet dispatch sent successfully.!' , 'success' );
                }
                else
                {
                    showNotify( response.data.errMsg , 'danger' );
                }
                hideLoader();
            },
            function myError(response) 
            {
                hideLoader();
            });
        }
        
        //show job dispatch remarks commands
        $scope.showdisptchlog   =   function(afuREMARKS){   
            var printMsg        =   ( afuREMARKS == null || afuREMARKS == "" ) ? 'Remarks not found..' : afuREMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=   "Jobsheet Dispatch Error Log Files";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
        
        //show client ack remarks commands
        $scope.showClientack   =   function(acaREMARKS){   
            var printMsg        =   (acaREMARKS == null || acaREMARKS == "" ) ? 'Remarks not found..' : acaREMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=   "Client Error Log Files";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
        
            
        $scope.retryJobsheetUpload  = 	function(JOB_ID,ROUND_ID)
        {   
            var jobid       =   JOB_ID;           
            showLoader();
            showNotify( 'please wait for a while posting data...' , 'success');
            var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+ROUND_ID+'/NOTIFICATION';      
            $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.status == 1) 
                {                    
                    if( response.data.msg == 'Success' )
                    { 
                        var errorremrks =   response.data.msgstatus.REMARKS;
                        var roundid     =   response.data.msgstatus.ROUND;
                        if(response.data.msgstatus.STATUS   ==  1.5)
                        {
                            var temp    =   '<span><i class="fa fa-spinner fa-spin red"></i> In-Progress </span>';
                            temp        =   $compile(temp)($scope);
                            angular.element(document.getElementById("removejobsheet_"+jobid)).remove();
                            var elem    =   angular.element(document.getElementById("jobsheetupload_"+jobid)).append(temp);
                        }
                        if(response.data.msgstatus.STATUS   ==  2)
                        {
                            var temp    =   '<span><i class="fa fa-check green"  aria-hidden="true"></i></span>';
                            temp        =   $compile(temp)($scope);
                            angular.element(document.getElementById("removejobsheet_"+jobid)).remove();
                            var elem    =   angular.element(document.getElementById("jobsheetupload_"+jobid)).append(temp);
                        }
                        if(response.data.msgstatus.STATUS   ==  3)
                        {
                            var temp    =   '<span id="removejobsheet_'+jobid+'"><i class="fa fa-info bigger-120 blue fa-1x pointer" ng-click="showdisptchlog('+"'"+errorremrks+"'"+')"></i>&nbsp;&nbsp;&nbsp; &nbsp;<i class="fa fa-repeat bigger-100 blue fa-1x pointer" ng-click="retryJobsheetUpload('+"'"+errorremrks+"'"+','+"'"+roundid+"'"+')" aria-hidden="true"></i></span>';
                            temp        =   $compile(temp)($scope);
                            angular.element(document.getElementById("removejobsheet_"+jobid)).remove();
                            var elem    =   angular.element(document.getElementById("jobsheetupload_"+jobid)).append(temp);
                        }
                        showNotify( response.data.errMsg , 'success' );
                    }
                    else{
                        showNotify( response.data.errMsg , 'danger' );
                    }
                } 
                else 
                {
                    showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
                }
             },
         function myError(response) {
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });
         
        //$('#show-redo').trigger('click');
        //$scope.Msgbox 	=	"Success Redo";
        //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');

        };
        
        $scope.retryJobsheetUpdate     =   function(jobid,ROUND_ID)
        {     
            showLoader();
            showNotify( 'please wait for a while...' , 'success');
            var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+ROUND_ID+'/NOTIFICATION';  
            $http.get(BASE_URL+dynamic_url) .then(function mySuccess(response) 
            {
                 hideLoader();
                 
                if(response.data.status == 1) 
                {      
                   
                    if( response.data.REMARKS == 'Failure' ){                        
                        showNotify( 'Jobsheet update response is :'+response.data.REMARKS , 'danger' );
                    }
                    else{
                        if(response.data.status   ==  1)
                        {
                            var temp    =   '<span> -- </span>';
                            temp        =   $compile(temp)($scope);
                            angular.element(document.getElementById("retryjobsheet_"+jobid)).remove();
                            var elem    =   angular.element(document.getElementById("jobsheetsuccess_"+jobid)).append(temp);
                        }
                       showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                    }
                }else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                }  else {
                   showNotify( 'Request got failed..' , 'danger');
		}
                
            },function myError(response) {
                console.log(response);
                showNotify( 'Oops, Kindly reload the page...' , 'danger' );
            });
        };
        
        $scope.figurecountShow  = 	function(MetadataID,chaptername,typeoffigure) 
        {
            showLoader('Please wait art figure open in progress');
            $scope.heightofmodal=   700;
            var inp             =   {MetadataID : MetadataID,typeoffigure:typeoffigure};
            $scope.chaptername  =   chaptername;
            $http.post(BASE_URL+"consolidate_figureview",inp) .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                //open chapter wise
                if(response.data.result == 200 && response.data.chapterfigure == 1)
                {
                    $scope.chapterlist  =   response.data.figuredata;
                    /*if(response.data.figuredata.length >= 1)
                    {
                        $scope.heightofmodal    =   700;
                    }*/
                    angular.element('#show-doopenfiles').trigger('click');
                }
                //open book wise
                if(response.data.result == 200 && response.data.bookfigure == 2)
                {
                    $scope.chapterlist  =   response.data.figuredata;
                    $scope.totalonline  =   response.data.totalonline;
                    $scope.coloronline  =   response.data.coloronline;
                    $scope.bwonline     =   response.data.bwonline;
                    $scope.totalprint   =   response.data.totalprint;
                    $scope.colorprint   =   response.data.colorprint;
                    $scope.bwprint      =   response.data.bwprint;
                    /*if(response.data.figuredata.length >= 1)
                    {
                        $scope.heightofmodal    =   700;
                    }*/
                    angular.element('#show-artdoopenfiles').trigger('click');
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                showNotify(response.data.msg  , 'danger' );
            });			
        };
        
        $scope.esmcountShow  = 	function(MetadataID,chaptername) 
        {
            showLoader();
            var inp             =   {metadataId : MetadataID,jodId:$scope.JobID};
            $scope.chaptername  =   chaptername;
            $scope.heightofmodal    =   600;
            $http.post(BASE_URL+"getesmViewInfo",inp) .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                    
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                //open chapter wise
                if(response.data.result == 200)
                {
                    $scope.esmchapterlist  =   response.data.esmchapterlist;
                    /*if(response.data.esmchapterlist.length >= 1)
                    {
                        $scope.heightofmodal    =   600;
                    }*/
                    angular.element('#show-openesm').trigger('click');
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                showNotify(response.data.msg  , 'danger' );
            });			
        };
        
        $scope.prrReportDwonload    = 	function(book) 
		{
            var inp                 =   {
                                            jobid   :   book.jobid,
                                            bookid  :   book.BOOK_ID,
                                            roundid :   book.cround
                                        }
            showLoader('Please wait while download file...'); 
            $http.post('prrreport-download',inp).then(function mySuccess(response)
            {
                if(response.data.result  ==  200)
                {
                    hideLoader();
                    var url             =   response.data.link;   
                    $scope.downloadUrl  =   response.data.link;
                    //$("#dwnl_local").attr('href',response.data.link);
                    showNotify('Successfully downloaded'  , 'success' );
                    $scope.fileopened   =   1;
                    window.open(url, '_blank');
                    $timeout( function()
                    { 
                        $scope.deletfiles();
                    }, 15000 );
                    
                }
            },
            function myError(response)
            {
                hideLoader();
                showNotify(response.data.errMsg  , 'danger' );
            });                         
	};
});

ngApp.directive('ngBlur', function($parse) {
  return function ( scope, element, attr ) {
    var fn = $parse(attr.ngBlur);
    element.bind( 'blur', function ( event, arg ) {
      scope.$apply( function(){
        fn(scope, {
          $event : event,
          arg: arg
        });
      });
    });
  };
});