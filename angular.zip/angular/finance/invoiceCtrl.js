/*
 *  invoice Master Controller
 */

ngApp.controller('invoiceMasterController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {
//load unit type
    $scope.unitTypes = [];
    $scope.getUnitType = function () {
        $scope.commonLoader = true;
        $http.get(BASE_URL + "fin/invoice/getUnitType").then(function mySuccess(response) {
            if (response.data.status == 1) {
                $scope.unitTypes = response.data.unitTypes;
                $scope.commonLoader = false;
            } else if (response.data.status == 2) {
                $scope.commonLoader = false;
            }

        }, function myError(response) {
            $scope.commonLoader = false;
        });

    }
    $scope.getUnitType();
    //
})
        .controller('invoiceAddController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

            $scope.commonLoader = true;

            $scope.commonLoaderEnable = $interval(function ()
            {
                $scope.commonLoader = false;
                $interval.cancel($scope.commonLoaderEnable);
            }, 500);




            //invoice type
            $scope.invoiceTypes = [{value: 3, name: "Final Invoice"}];
            $scope.workTypes = [{value: 0, name: "NA"}, {value: 1, name: "Standard Work"}, {value: 2, name: "Complex Work"}];
            $scope.trimTypes = [{value: 0, name: "NA"}, {value: 1, name: "Normal"}, {value: 2, name: "Large"}];
            $scope.compTypes = [{value: 0, name: "NA"}, {value: 2, name: "Category A. Pawn"}, {value: 3, name: "Category B. Bishop"}, {value: 4, name: "Category C. Knight"}, {value: 5, name: "Category D. Queen"}];
            $scope.ceTypes = [{value: 0, name: "NA"}, {value: 11, name: "Copy editing Level 1"}, {value: 12, name: "Copy editing Level 2 **"}, {value: 13, name: "Copy editing Level 3 **"}];




            $scope.invoice = {};
            $scope.invoice.projectName = '';
            $scope.invoice.projectId = '';

            // invoice default value
            $scope.loadDefaultValue = function () {

                $scope.invoice.projectWorkType = '';
                $scope.invoice.projectTrimType = '';
                $scope.invoice.projectComposition = '';
                $scope.invoice.projectCeLevel = '';

                $scope.lineItemTable = false;
                $scope.invoiceHeaderDetails = false;
                $scope.invoiceProjectDetails = false;
                $scope.invoice.isbn = '';
                $scope.invoice.orderNo = '';
                $scope.invoice.author = '';
                $scope.invoice.invoiceType = 3;
                $scope.invoice.pspElement = '';
                $scope.invoice.client = '';
                $scope.invoice.clientId = '';
                $scope.invoice.billingAddId = null;
                $scope.invoice.phone = '';
                $scope.invoice.kindAttn = '';
                $scope.invoice.currencyId = '';
                $scope.invoice.currencyName = '';
                $scope.invoice.subTotal = '0.00';
                $scope.invoice.igst = '0.00';
                $scope.invoice.finalTotal = '0.00';
                $scope.invoice.lineItem = [];
                $scope.invoice.accountCodeTotal = [];
                $scope.billingAddList = [];
            }

            // change client billing address
            $scope.changeBillAdd = function () {

                $scope.invoice.phone = '';
//                $scope.invoice.kindAttn = '';

                var val = $scope.invoice.billingAddId;
                angular.forEach($scope.billingAddList, function (value, key) {

                    if (value.CUSTOMER_ADDRESS_ID == val) {
                        //$scope.invoice.kindAttn = value.CONTACT_NAME;
                        $scope.invoice.phone = value.PHONE;
                    }
                });

            };

            $scope.loadDefaultValue();

            // get project information
            $scope.changeProject = function () {

                var jobId = $scope.invoice.projectId;
                var projectWorkType = $scope.invoice.projectWorkType;
                var projectTrimType = $scope.invoice.projectTrimType;
                var projectComposition = $scope.invoice.projectComposition;
                var projectCeLevel = $scope.invoice.projectCeLevel;
                $scope.loadDefaultValue();

                $scope.lineItemTable = false;
                $scope.invoiceHeaderDetails = false;
                $scope.invoiceProjectDetails = false;


                var jobId = $scope.invoice.projectId;

                if (jobId > 0 && jobId != '') {
                    var postData = {
                        jobId: jobId,
                        projectWorkType: projectWorkType,
                        projectTrimType: projectTrimType,
                        projectComposition: projectComposition,
                        projectCeLevel: projectCeLevel,
                        postType: 'ALL_MAPPED_LINE_ITEM',
                    };
                    $scope.commonLoader = true;
                    $http.post(BASE_URL + "fin/invoice/getInvoiceEstdQty", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            var lineItem = response.data.lineItem;
                            var lineItemQuantity = response.data.lineItemQuantity;
                            var projectDetails = response.data.project;
                            var projectType = response.data.projectType;

                            var lineItemQuantitykeys = Object.keys(lineItemQuantity);
                            var projectTypekeys = Object.keys(projectType);

                            $scope.invoice.projectName = projectDetails.JOB_TITLE;

                            if (projectTypekeys.length > 0) {
                                $scope.invoice.projectWorkType = projectType.WORK_TYPE_ID;
                                $scope.invoice.projectTrimType = projectType.TRIM_TYPE_ID;
                                $scope.invoice.projectComposition = projectType.COMPOSITION_TYPE;
                                $scope.invoice.projectCeLevel = projectType.CE_TYPE;
                            }

                            $scope.invoice.clientId = projectDetails.customer.CUSTOMER_ID;
                            $scope.invoice.client = projectDetails.customer.CUSTOMER_NAME;

                            $scope.invoice.isbn = projectDetails.ISSN_PRINT;
                            $scope.invoice.orderNo = projectDetails.PURCHASE_ORDER_NUMBER;



                            if (projectDetails.AUTHOR_NAME != null && projectDetails.AUTHOR_NAME != '') {
                                $scope.invoice.author = projectDetails.AUTHOR_NAME;
                            } else {
                                $scope.invoice.author = projectDetails.PRODUCTION_EDITOR;
                            }

                            $scope.invoice.pspElement = 'Test Data';

                            $scope.invoice.currencyId = projectDetails.customer_division.CURRENCY_ID;
                            $scope.invoice.currencyName = projectDetails.customer_division.CURRENCY_NAME;

                            $scope.billingAddList = projectDetails.customer_billing_address;

                            if ($scope.billingAddList.length == 1) {
                                var singleBillAdd = $scope.billingAddList[0];
                                $scope.invoice.billingAddId = singleBillAdd.CUSTOMER_ADDRESS_ID;
                                $scope.changeBillAdd();
                            }
                            $scope.invoice.kindAttn = 'Test Data';

                            /*angular.forEach(lineItem, function (value, key) {

                                if (lineItemQuantity[value.SERVICE_ITEM_ID] >= 0) {
                                    $scope.tempLineItem = {};
                                    $scope.tempLineItem.serviceGroupId = value.SERVICE_GROUP_ID;
                                    $scope.tempLineItem.serviceGroupName = value.SECTION_NAME;
                                    $scope.tempLineItem.itemCode = value.ITEM_CODE;
                                    $scope.tempLineItem.lineItemRemark = '';
                                    $scope.tempLineItem.lineItemId = value.SERVICE_ITEM_ID;
                                    $scope.tempLineItem.itemSrc = value.ITEM_SRC;

                                    $scope.tempLineItem.accountCode = value.ACCOUNT_CODE;
                                    $scope.tempLineItem.description = value.ITEM_NAME;

                                    $scope.tempLineItem.unitQty = 1;
                                    $scope.tempLineItem.rateField = value.RATE_FIELD;

                                    if (value.RATE_FIELD == 1) {
                                        $scope.tempLineItem.unitType = value.UNIT_ENUM_ID;
                                    } else {
                                        $scope.tempLineItem.unitType = 0;
                                    }

                                    if (lineItemQuantity[value.SERVICE_ITEM_ID]) {
                                        $scope.tempLineItem.qty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                        $scope.tempLineItem.autoQty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                        $scope.tempLineItem.enableRow = true;
                                        $scope.tempLineItem.enableCheckBox = true;
                                    } else {
                                        $scope.tempLineItem.qty = 1;
                                        $scope.tempLineItem.autoQty = 0;
                                        $scope.tempLineItem.enableRow = false;
                                        $scope.tempLineItem.enableCheckBox = false;
                                    }

//                                    if (lineItemQuantitykeys.length > 0) {
//                                        $scope.tempLineItem.price = value.RATE;
//                                    } else {
//                                        $scope.tempLineItem.price = 0;
//                                    }
                                    //$scope.tempLineItem.price = value.RATE;
                                    //$scope.tempLineItem.total = 0;
                                    $scope.tempLineItem.disablePriceEdit = 0;
                                    $scope.tempLineItem.price = 0;
                                    $scope.tempLineItem.total = 0;

                                    if (response.data.clientItemRate.client == "SPRINGER_INVOICE" || response.data.clientItemRate.client ==  "OUP_INVOICE") {

                                        if (response.data.clientItemRate.autoErrorMsg == "" && value.RATE_FIELD == 1) {
                                            $scope.tempLineItem.price = value.RATE;
                                            $scope.tempLineItem.disablePriceEdit = 1;
                                        }

                                        if (value.ITEM_SRC == 2 && value.RATE_FIELD == 0 && (value.RATE != '' && value.RATE != null)) {
                                            $scope.tempLineItem.price = value.RATE;
                                            $scope.tempLineItem.disablePriceEdit = 1;
                                        }

                                    } else if (value.ITEM_SRC == 2) {

                                        if (value.RATE_FIELD == 0 && (value.RATE != '' && value.RATE != null)) {
                                            $scope.tempLineItem.price = value.RATE;
                                            $scope.tempLineItem.disablePriceEdit = 1;
                                        }
                                    }

                                    $scope.invoice.lineItem.push($scope.tempLineItem);
                                }
                            });*/



                            $scope.lineItemCalc();

                            if (response.data.clientItemRate.client == "SPRINGER_INVOICE") {

                                if (response.data.clientItemRate.autoErrorMsg != "") {
                                    showMessage('Invoice', response.data.clientItemRate.autoErrorMsg, 'error');
                                }
                            }


                            $scope.commonLoader = false;
                            $scope.lineItemTable = true;
                            $scope.invoiceHeaderDetails = true;
                            $scope.invoiceProjectDetails = true;
                        } else if (response.data.status == 2) {
                            $scope.lineItemCalc();
                        }

                    }, function myError(response) {
                        $scope.loadDefaultValue();
                    });
                }
            }

            // amount calculation
            $scope.round = function (number, precision) {
                var pair = (number + 'e').split('e')
                var value = Math.round(pair[0] + 'e' + (+pair[1] + precision))
                pair = (value + 'e').split('e')
                return +(pair[0] + 'e' + (+pair[1] - precision))
            }


            // service line item calculation
            $scope.lineItemCalc = function () {

                for (var index = 0; index < $scope.invoice.lineItem.length; index++) {
                    var enableRow = $scope.invoice.lineItem[index].enableRow;

                    if (enableRow == true) {
                        var qty = $scope.invoice.lineItem[index].qty;
                        var unitQty = $scope.invoice.lineItem[index].unitQty;
                        var price = $scope.invoice.lineItem[index].price;

                        var total = (parseFloat(qty) * parseFloat(price)) / parseFloat(unitQty);
                        $scope.invoice.lineItem[index].total = $scope.round(total, 2);
                    }
                }
                $scope.AccountCodeTotalCalc();
                $scope.SubTotalCalc();
                $scope.FinalTotalCalc();
            }


            // qty change 
            $scope.changeQty = function (index) {
                var qty = $scope.invoice.lineItem[index].qty;
                var unitQty = $scope.invoice.lineItem[index].unitQty;
                var price = $scope.invoice.lineItem[index].price;

                var total = (parseFloat(qty) * parseFloat(price)) / parseFloat(unitQty);
                $scope.invoice.lineItem[index].total = $scope.round(total, 2);

                $scope.AccountCodeTotalCalc();
                $scope.SubTotalCalc();
                $scope.FinalTotalCalc();

            };

            // enable/disable service item row
            $scope.enableCheckBox = function (index) {
                var enableCheckBox = $scope.invoice.lineItem[index].enableCheckBox;

                if (enableCheckBox == false) {
                    $scope.invoice.lineItem[index].enableRow = false;
                    $scope.invoice.lineItem[index].total = 0;
                } else {
                    $scope.invoice.lineItem[index].enableRow = true;
                }
                $scope.lineItemCalc();

            };



            // delete a single service item row
            $scope.deleteRow = function (index) {
                $scope.invoice.lineItem.splice(index, 1);
                $scope.lineItemCalc();

            };

            // delete all service item row
            $scope.deleteAllLineItem = function () {
                $scope.invoice.lineItem = [];
                $scope.lineItemCalc();
            };

            // Sub total calcultion
            $scope.SubTotalCalc = function () {
                var subTotal = 0;
                for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                    var enableRow = $scope.invoice.lineItem[i].enableRow;

                    if (enableRow == true) {
                        subTotal += $scope.invoice.lineItem[i].total;
                    }
                }
                $scope.invoice.subTotal = $scope.round(subTotal, 2);
            }

            // lineitem group by account code calcultion
            $scope.AccountCodeTotalCalc = function () {
                $scope.invoice.accountCodeTotal = [];

                $scope.accountCodeGroup = [];
                for (var i = 0; i < $scope.invoice.lineItem.length; i++) {
                    var enableRow = $scope.invoice.lineItem[i].enableRow;

                    if (enableRow == true) {
                        if ($scope.accountCodeGroup.indexOf($scope.invoice.lineItem[i].accountCode) == -1) {
                            $scope.accountCodeGroup.push($scope.invoice.lineItem[i].accountCode);
                        }
                    }
                }

                for (var j = 0; j < $scope.accountCodeGroup.length; j++) {
                    $scope.tempaccountCodeTotal = {};
                    var accountTotal = 0;
                    for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                        var enableRow = $scope.invoice.lineItem[i].enableRow;

                        if (enableRow == true) {
                            if ($scope.accountCodeGroup[j] == $scope.invoice.lineItem[i].accountCode) {
                                accountTotal += $scope.invoice.lineItem[i].total;
                            }
                        }
                    }
                    $scope.tempaccountCodeTotal.accountCode = $scope.accountCodeGroup[j];
                    $scope.tempaccountCodeTotal.accountTotal = $scope.round(accountTotal, 2);
                    $scope.invoice.accountCodeTotal.push($scope.tempaccountCodeTotal);
                }


            }

            // Final total calcultion
            $scope.FinalTotalCalc = function () {
                var finalTotal = 0;
                finalTotal = parseFloat($scope.invoice.subTotal) + parseFloat($scope.invoice.igst);
                $scope.invoice.finalTotal = $scope.round(finalTotal, 2);
            }

            $scope.lineItemCalc();

            // Create a new invoice
            $scope.createInvoice = function () {

                if ($scope.invoiceForm.$invalid == false && $scope.invoice.finalTotal > 0) {


                    $scope.invoice.invoiceLineItem = [];
					$scope.invoice.appName	=	$("#appName").val();
                    for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                        var enableRow = $scope.invoice.lineItem[i].enableRow;

                        if (enableRow == true) {

                            $scope.invoice.invoiceLineItem.push($scope.invoice.lineItem[i]);
                        }
                    }

                    $scope.commonLoader = true;
                    var postData = {};
                    angular.extend(postData, $scope.invoice);

                    $http.post(BASE_URL + "fin/invoice/ajaxAddInvoice", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Invoice successfuly generated.', 'success');
                            $timeout(function () {
                                hideMessage();
								var urlappName 	=	"";
								if($scope.invoice.appName == "oup"){
									urlappName 	=	"/oup";	
								}
                                $window.location.href = BASE_URL + 'fin/invoice/' + response.data.invoiceId + '/edit'+urlappName;
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }
                        $scope.invoice.invoiceLineItem = [];
                    }, function myError(response) {
                        $scope.commonLoader = false;
                        $scope.invoice.invoiceLineItem = [];
                    });
                } else {
                    showMessage('Invoice', 'Please fill the required fields.', 'error');
                }
            }



            // show Additional LineItem
            $scope.getServiceItems = function ()
            {
                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/invoice/getServiceItems",
                            type: 'POST'
                        })
                        .withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('SECTION_NAME').withTitle('Service Group'),
                    DTColumnBuilder.newColumn('ITEM_NAME').withTitle('Line Item'),
                    DTColumnBuilder.newColumn('ACCOUNT_CODE').withTitle('Account Code'),
                    DTColumnBuilder.newColumn('RATE_FIELD').withTitle('Item type'),
                    DTColumnBuilder.newColumn('ITEM_SRC_TYPE').withTitle('Item Source'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };
            function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                $('td .insertNewLineItem', nRow).unbind('click');
                $('td .insertNewLineItem', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.insertNewLineItem(aData.SERVICE_ITEM_ID, aData.ITEM_SRC);
                    });
                });
                return nRow;
            }

            $scope.showAddLineItem = function () {
                $('#addLineItemModal').modal('show');
                $scope.getServiceItems();
            };

            $scope.insertNewLineItem = function (SERVICE_ITEM_ID, ITEM_SRC) {

                var jobId = $scope.invoice.projectId;
                var projectWorkType = $scope.invoice.projectWorkType;
                var projectTrimType = $scope.invoice.projectTrimType;
                var projectComposition = $scope.invoice.projectComposition;
                var projectCeLevel = $scope.invoice.projectCeLevel;

                var itemExists = true;
                angular.forEach($scope.invoice.lineItem, function (value, key) {
                    if (value.lineItemId == SERVICE_ITEM_ID) {
                        itemExists = false;
                    }
                });

                if (itemExists == false) {
                    alert('Line-item already added');
                    return false;
                } else if (jobId > 0 && jobId != '' && itemExists == true) {
                    var postData = {
                        jobId: jobId,
                        projectWorkType: projectWorkType,
                        projectTrimType: projectTrimType,
                        projectComposition: projectComposition,
                        projectCeLevel: projectCeLevel,
                        serviceItemId: SERVICE_ITEM_ID,
                        serviceItemSrc: ITEM_SRC,
                        postType: 'ADDITIONAL_LINE_ITEM',
                    };
                    $scope.commonLoader = true;
                    $http.post(BASE_URL + "fin/invoice/getInvoiceEstdQty", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            var lineItem = response.data.lineItem;
                            var lineItemQuantity = response.data.lineItemQuantity;

                            var lineItemQuantitykeys = Object.keys(lineItemQuantity);

                            angular.forEach(lineItem, function (value, key) {

                                $scope.tempLineItem = {};
                                $scope.tempLineItem.serviceGroupId = value.SERVICE_GROUP_ID;
                                $scope.tempLineItem.serviceGroupName = value.SECTION_NAME;
                                $scope.tempLineItem.itemCode = value.ITEM_CODE;
                                $scope.tempLineItem.lineItemRemark = '';
                                $scope.tempLineItem.lineItemId = value.SERVICE_ITEM_ID;
                                $scope.tempLineItem.itemSrc = value.ITEM_SRC;

                                $scope.tempLineItem.accountCode = value.ACCOUNT_CODE;
                                $scope.tempLineItem.description = value.ITEM_NAME;
                                $scope.tempLineItem.unitQty = 1;


                                $scope.tempLineItem.rateField = value.RATE_FIELD;



                                if (value.RATE_FIELD == 1) {
                                    $scope.tempLineItem.unitType = value.UNIT_ENUM_ID;
                                } else {
                                    $scope.tempLineItem.unitType = 0;
                                }

                                if (lineItemQuantity[value.SERVICE_ITEM_ID]) {
                                    $scope.tempLineItem.qty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                    $scope.tempLineItem.autoQty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                } else {
                                    $scope.tempLineItem.qty = 1;
                                    $scope.tempLineItem.autoQty = 0;
                                }

                                $scope.tempLineItem.enableRow = true;
                                $scope.tempLineItem.enableCheckBox = true;



//                                if (lineItemQuantitykeys.length > 0) {
//                                    $scope.tempLineItem.price = value.RATE;
//                                } else {
//                                    $scope.tempLineItem.price = 0;
//                                }
                                $scope.tempLineItem.disablePriceEdit = 0;
                                $scope.tempLineItem.price = 0;
                                $scope.tempLineItem.total = 0;
                                if (response.data.clientItemRate.client == "SPRINGER_INVOICE" || response.data.clientItemRate.client ==  "OUP_INVOICE") {

                                    if (response.data.clientItemRate.autoErrorMsg == "" && value.RATE_FIELD == 1) {
                                        $scope.tempLineItem.price = value.RATE;
                                        $scope.tempLineItem.disablePriceEdit = 1;
                                    }

                                    if (value.ITEM_SRC == 2 && value.RATE_FIELD == 0 && (value.RATE != '' && value.RATE != null)) {
                                        $scope.tempLineItem.price = value.RATE;
                                        $scope.tempLineItem.disablePriceEdit = 1;
                                    }

                                } else if (value.ITEM_SRC == 2) {

                                    if (value.RATE_FIELD == 0 && (value.RATE != '' && value.RATE != null)) {
                                        $scope.tempLineItem.price = value.RATE;
                                        $scope.tempLineItem.disablePriceEdit = 1;
                                    }
                                }

//                                if (response.data.clientItemRate.client == "SPRINGER_INVOICE") {
//
//                                    if (response.data.clientItemRate.autoErrorMsg == "") {
//                                        $scope.tempLineItem.price = value.RATE;
//                                        $scope.tempLineItem.disablePriceEdit = 1;
//                                    }
//                                } else if (value.ITEM_SRC == 2) {
//                                    $scope.tempLineItem.price = value.RATE;
//                                    $scope.tempLineItem.disablePriceEdit = 1;
//                                }

                                $scope.invoice.lineItem.push($scope.tempLineItem);
                            });




                            showNotify('Line-item added successfully', 'success');


                            $scope.lineItemCalc();
                        } else if (response.data.status == 2) {
                            alert('Try Again');
                            $scope.lineItemCalc();
                        }

                    }, function myError(response) {
                        alert('Try Again');
                        $scope.lineItemCalc();
                    });
                    $scope.commonLoader = false;
                }


            };

            // line item row move up function
            $scope.upitem = function (item, position) {
                if (position > -1 && position < $scope.invoice.lineItem.length)
                {
                    if (position == 0)
                    {
                        return false;
                    } else
                    {
                        var nextposition = $scope.invoice.lineItem[position - 1];
                        $scope.invoice.lineItem[position - 1] = $scope.invoice.lineItem[position];
                        $scope.invoice.lineItem[position] = nextposition;
                    }
                }
            };
            // line item row move down function
            $scope.downitem = function (item, position) {
                if (position > -1 && position < $scope.invoice.lineItem.length)
                {
                    if (position == $scope.invoice.lineItem.length - 1)
                    {
                        return false;
                    } else
                    {
                        var nextposition = $scope.invoice.lineItem[position + 1];
                        $scope.invoice.lineItem[position + 1] = $scope.invoice.lineItem[position];
                        $scope.invoice.lineItem[position] = nextposition;
                    }
                }
            };



        })
        .controller('invoiceEditController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

            $scope.invoiceStatusDetails = false;
            $scope.invoiceHeaderDetails = false;
            $scope.lineItemTable = false;

            //invoice type
            $scope.invoiceTypes = [{value: 3, name: "Final Invoice"}];
            $scope.workTypes = [{value: 0, name: "NA"}, {value: 1, name: "Standard Work"}, {value: 2, name: "Complex Work"}];
            $scope.trimTypes = [{value: 0, name: "NA"}, {value: 1, name: "Normal"}, {value: 2, name: "Large"}];
            $scope.compTypes = [{value: 0, name: "NA"}, {value: 2, name: "Category A. Pawn"}, {value: 3, name: "Category B. Bishop"}, {value: 4, name: "Category C. Knight"}, {value: 5, name: "Category D. Queen"}];
            $scope.ceTypes = [{value: 0, name: "NA"}, {value: 11, name: "Copy editing Level 1"}, {value: 12, name: "Copy editing Level 2 **"}, {value: 13, name: "Copy editing Level 3 **"}];



            $scope.invoice = {};
            $scope.invoice.invoiceId = invoiceId;
            $scope.invoice.projectName = '';
            $scope.invoice.projectId = '';

            // invoice default value
            $scope.loadDefaultValue = function () {
                $scope.lineItemTable = false;
                $scope.invoiceHeaderDetails = false;
                $scope.invoiceStatusDetails = false;
                $scope.invoice.isbn = '';
                $scope.invoice.orderNo = '';
                $scope.invoice.author = '';
                $scope.invoice.invoiceType = 3;
                $scope.invoice.pspElement = '';
                $scope.invoice.client = '';
                $scope.invoice.clientId = '';
                $scope.invoice.billingAddId = null;
                $scope.invoice.phone = '';
                $scope.invoice.kindAttn = '';
                $scope.invoice.currencyId = '';
                $scope.invoice.currencyName = '';
                $scope.invoice.subTotal = '0.00';
                $scope.invoice.igst = '0.00';
                $scope.invoice.finalTotal = '0.00';
                $scope.invoice.isCancelled = 0;

                $scope.invoice.lineItem = [];
                $scope.invoice.accountCodeTotal = [];
                $scope.billingAddList = [];

                $scope.invoice.approvalLog = [];
                $scope.invoice.currentStatus = '';
                $scope.invoice.isRejectLevel = '';
                $scope.invoice.createdBy = '';
                $scope.invoice.createdDate = '';
                $scope.invoice.cancelledBy = '';
                $scope.invoice.cancelledDate = '';
                $scope.invoice.cancelledReason = '';
                $scope.invoice.changeStatus = '';
                $scope.invoice.isStatusChange = '';
                $scope.invoice.enableStatusChange = false;

                $scope.invoice.invoiceStatusName = '';
                $scope.invoice.invoiceStatusLabel = '';

                $scope.enbleRejectRemark = false;
            }
            $scope.loadDefaultValue();

            if (invoiceId > 0) {
                $scope.commonLoader = true;
                var postData = {"invoiceId": invoiceId};

                $http.post(BASE_URL + "fin/invoice/getInvoiceDetails", postData).then(function mySuccess(response) {
                    if (response.data.status == 1) {



                        var invoiceData = response.data.data;

                        $scope.invoice.projectId = invoiceData.JOB_ID;
                        $scope.invoice.bookId = invoiceData.project.BOOK_ID;
                        $scope.invoice.projectName = invoiceData.JOB_TITLE;

                        $scope.invoice.projectWorkType = invoiceData.invoice_ref.WORK_TYPE;
                        $scope.invoice.projectTrimType = invoiceData.invoice_ref.TRIM_TYPE;
                        $scope.invoice.projectComposition = invoiceData.invoice_ref.COMPOSITION_TYPE;
                        $scope.invoice.projectCeLevel = invoiceData.invoice_ref.CE_LEVEL;

                        $scope.invoice.author = invoiceData.invoice_ref.AUTHOR;
                        $scope.invoice.pspElement = invoiceData.invoice_ref.PSP_ELEMENT;
                        $scope.invoice.isbn = invoiceData.invoice_ref.ISBN;
                        $scope.invoice.orderNo = invoiceData.invoice_ref.ORDER_NO;
                        $scope.invoice.clientId = invoiceData.customer.CUSTOMER_ID;
                        $scope.invoice.client = invoiceData.customer.CUSTOMER_NAME;
                        $scope.invoice.currencyId = invoiceData.CURRENCY_ID;
                        $scope.invoice.currencyName = invoiceData.CURRENCY_NAME + ' ' + invoiceData.CURRENCY_SYMBOL;
                        $scope.invoice.subTotal = invoiceData.SUB_TOTAL;
                        $scope.invoice.finalTotal = invoiceData.FINAL_TOTAL;
                        $scope.invoice.isCancelled = invoiceData.IS_CANCELLED;
                        $scope.invoice.currentStatus = invoiceData.CURRENT_STATUS;
                        $scope.invoice.isRejectLevel = invoiceData.IS_REQUEST_LEVEL_REJECT;

                        $scope.invoice.disableItemfields = invoiceData.disableItemfields;

                        angular.forEach(invoiceData.invoice_items, function (value, key) {

                            $scope.tempLineItem = {};
                            $scope.tempLineItem.serviceGroupId = value.SERVICE_GROUP_ID;
                            $scope.tempLineItem.serviceGroupName = value.SERVICE_GROUP_NAME;
                            $scope.tempLineItem.itemCode = value.ITEM_CODE;

                            if ($scope.invoice.isRejectLevel == 1 && value.ITEM_REMARK != '' && value.ITEM_REMARK != null) {
                                $scope.tempLineItem.lineItemRemark = value.ITEM_REMARK;
                                $scope.tempLineItem.lineItemRemarkEnable = 1;
                                $scope.enbleRejectRemark = true;
                            } else {
                                $scope.tempLineItem.lineItemRemark = value.ITEM_REMARK;
                                $scope.tempLineItem.lineItemRemarkEnable = 0;
                            }

                            $scope.tempLineItem.lineItemId = value.SERVICE_ITEM_ID;

                            $scope.tempLineItem.accountCode = value.ACCOUNT_CODE;
                            $scope.tempLineItem.description = value.ITEM_DESCRIPTION;

                            $scope.tempLineItem.rateField = value.RATE_FIELD;

                            if (value.RATE_FIELD == 1) {
                                $scope.tempLineItem.unitType = value.UNIT_ENUM_ID;
                                $scope.tempLineItem.unitQty = value.UNIT_QTY;
                                $scope.tempLineItem.qty = value.QTY;
                            } else {
                                $scope.tempLineItem.unitType = 0;
                                $scope.tempLineItem.unitQty = 1;
                                $scope.tempLineItem.qty = 1;
                            }


                            $scope.tempLineItem.enableRow = true;
                            $scope.tempLineItem.enableCheckBox = true;

                            $scope.tempLineItem.price = value.RATE;

                            $scope.tempLineItem.total = value.AMOUNT;

                            if (value.IS_EDITABLE == 1) {
                                $scope.tempLineItem.disablePriceEdit = false;
                            } else {
                                $scope.tempLineItem.disablePriceEdit = true;
                            }


//                            if(invoiceData.CURRENT_STATUS == 0 ){
//                            $scope.tempLineItem.disableItemfields = true;    
//                            }else{
//                            $scope.tempLineItem.disableItemfields = false;
//                            }

                            $scope.invoice.lineItem.push($scope.tempLineItem);
                        });


                        $scope.invoice.createdBy = invoiceData.created_by.NAME;
                        $scope.invoice.createdDate = invoiceData.CREATED_DATE;

                        if (invoiceData.cancelled_by) {
                            $scope.invoice.cancelledBy = invoiceData.cancelled_by.NAME;
                            $scope.invoice.cancelledDate = invoiceData.CANCELLED_DATE;
                            $scope.invoice.cancelledReason = invoiceData.CANCELLED_REASON;
                        }

                        if (invoiceData.invoice_status_name) {
                            $scope.invoice.invoiceStatusName = invoiceData.invoice_status_name.LEVEL_NAME;
                        }
                        $scope.invoice.invoiceStatusLabel = invoiceData.invoice_status_label;

                        if (invoiceData.invoice_next_status) {
                            $scope.invoice.isStatusChange = invoiceData.invoice_next_status.REQUEST_LEVEL_ID;

                            // disable reject option in change status dropdown after invoice approval
                            if (invoiceData.REF_PREFIX != null && invoiceData.REF_PREFIX != '') {
                                $scope.changeStatusList = [{value: invoiceData.invoice_next_status.REQUEST_LEVEL_ID, name: invoiceData.invoice_next_status.LEVEL_NAME}];
                                $scope.invoice.enableStatusChange = true; // auto check for approval
                            } else {
                                $scope.changeStatusList = [{value: invoiceData.invoice_next_status.REQUEST_LEVEL_ID, name: invoiceData.invoice_next_status.LEVEL_NAME}, {value: 0, name: "Reject"}];
                                $scope.invoice.enableStatusChange = true; // auto check for approval
                            }

                            $scope.invoice.changeStatus = invoiceData.invoice_next_status.REQUEST_LEVEL_ID;

                        }

                        $scope.billingAddList = invoiceData.customer_billing_address;
                        $scope.invoice.billingAddId = invoiceData.CLIENT_ADDRESS_ID;
                        $scope.invoice.kindAttn = invoiceData.invoice_billing_address.CONTACT_NAME;
                        $scope.invoice.phone = invoiceData.invoice_billing_address.PHONE;
                        //$scope.changeBillAdd();


                        $scope.lineItemCalc();

                        // approval tracking
                        $('#LevelTracking').html(invoiceData.approval_tracking.LevelTracking);
                        $scope.invoice.approvalLog = invoiceData.approval_tracking.StatusList;

                        $scope.commonLoader = false;
                        $scope.lineItemTable = true;
                        $scope.invoiceHeaderDetails = true;
                        $scope.invoiceStatusDetails = true;



                    } else if (response.data.status == 2) {
                        $scope.commonLoader = false;
                    }

                    $scope.commonLoader = false;
                    $scope.lineItemTable = true;
                    $scope.invoiceHeaderDetails = true;
                    $scope.invoiceStatusDetails = true;

                }, function myError(response) {
                    $scope.commonLoader = false;
                });
            }


            $scope.rejectLineItem = function (index) {
                var enbleRemark = $scope.invoice.lineItem[index].lineItemRemarkEnable;

                if (enbleRemark == 0) {
                    $scope.invoice.lineItem[index].lineItemRemarkEnable = 1;
                } else if (enbleRemark == 1) {
                    $scope.invoice.lineItem[index].lineItemRemarkEnable = 0;
                }
                $scope.invoice.lineItem[index].lineItemRemark = '';

                $scope.enbleRejectRemark = false;
                var enbleRejectRemarkRow = false;
                for (var i = 0; i < $scope.invoice.lineItem.length; i++) {
                    var enableRow = $scope.invoice.lineItem[i].lineItemRemarkEnable;
                    if (enableRow == 1) {
                        enbleRejectRemarkRow = true;
                    }
                }

                if (enbleRejectRemarkRow == true) {
                    $scope.enbleRejectRemark = true;
                    $scope.invoice.enableStatusChange = true;
                    $scope.invoice.changeStatus = 0;
                }


            }

            // change client billing address
            $scope.changeBillAdd = function () {
                $scope.invoice.phone = '';
                //$scope.invoice.kindAttn = '';

                var val = $scope.invoice.billingAddId;
                angular.forEach($scope.billingAddList, function (value, key) {

                    if (value.CUSTOMER_ADDRESS_ID == val) {
                        //$scope.invoice.kindAttn = value.CONTACT_NAME;
                        $scope.invoice.phone = value.PHONE;
                    }
                });
            };

            // amount calculation
            $scope.round = function (number, precision) {
                var pair = (number + 'e').split('e')
                var value = Math.round(pair[0] + 'e' + (+pair[1] + precision))
                pair = (value + 'e').split('e')
                return +(pair[0] + 'e' + (+pair[1] - precision))
            }


            // service line item calculation
            $scope.lineItemCalc = function () {

                for (var index = 0; index < $scope.invoice.lineItem.length; index++) {
                    var enableRow = $scope.invoice.lineItem[index].enableRow;

                    if (enableRow == true) {
                        var qty = $scope.invoice.lineItem[index].qty;
                        var unitQty = $scope.invoice.lineItem[index].unitQty;
                        var price = $scope.invoice.lineItem[index].price;

                        var total = (parseFloat(qty) * parseFloat(price)) / parseFloat(unitQty);
                        $scope.invoice.lineItem[index].total = $scope.round(total, 2);
                    }
                }
                $scope.AccountCodeTotalCalc();
                $scope.SubTotalCalc();
                $scope.FinalTotalCalc();
            }


            // qty change 
            $scope.changeQty = function (index) {
                var qty = $scope.invoice.lineItem[index].qty;
                var unitQty = $scope.invoice.lineItem[index].unitQty;
                var price = $scope.invoice.lineItem[index].price;

                var total = (parseFloat(qty) * parseFloat(price)) / parseFloat(unitQty);
                $scope.invoice.lineItem[index].total = $scope.round(total, 2);

                $scope.AccountCodeTotalCalc();
                $scope.SubTotalCalc();
                $scope.FinalTotalCalc();

            };

            // enable/disable service item row
            $scope.enableCheckBox = function (index) {
                var enableCheckBox = $scope.invoice.lineItem[index].enableCheckBox;

                if (enableCheckBox == false) {
                    $scope.invoice.lineItem[index].enableRow = false;
                    $scope.invoice.lineItem[index].total = 0;
                } else {
                    $scope.invoice.lineItem[index].enableRow = true;
                }
                $scope.lineItemCalc();

            };



            // delete a single service item row
            $scope.deleteRow = function (index) {
                $scope.invoice.lineItem.splice(index, 1);
                $scope.lineItemCalc();

            };

            // delete all service item row
            $scope.deleteAllLineItem = function () {
                $scope.invoice.lineItem = [];
                $scope.lineItemCalc();
            };

            // Sub total calcultion
            $scope.SubTotalCalc = function () {
                var subTotal = 0;
                for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                    var enableRow = $scope.invoice.lineItem[i].enableRow;

                    if (enableRow == true) {
                        subTotal += $scope.invoice.lineItem[i].total;
                    }
                }
                $scope.invoice.subTotal = $scope.round(subTotal, 2);
            }

            // lineitem group by account code calcultion
            $scope.AccountCodeTotalCalc = function () {
                $scope.invoice.accountCodeTotal = [];

                $scope.accountCodeGroup = [];
                for (var i = 0; i < $scope.invoice.lineItem.length; i++) {
                    var enableRow = $scope.invoice.lineItem[i].enableRow;

                    if (enableRow == true) {
                        if ($scope.accountCodeGroup.indexOf($scope.invoice.lineItem[i].accountCode) == -1) {
                            $scope.accountCodeGroup.push($scope.invoice.lineItem[i].accountCode);
                        }
                    }
                }

                for (var j = 0; j < $scope.accountCodeGroup.length; j++) {
                    $scope.tempaccountCodeTotal = {};
                    var accountTotal = 0;
                    for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                        var enableRow = $scope.invoice.lineItem[i].enableRow;

                        if (enableRow == true) {
                            if ($scope.accountCodeGroup[j] == $scope.invoice.lineItem[i].accountCode) {
                                accountTotal += $scope.invoice.lineItem[i].total;
                            }
                        }
                    }
                    $scope.tempaccountCodeTotal.accountCode = $scope.accountCodeGroup[j];
                    $scope.tempaccountCodeTotal.accountTotal = $scope.round(accountTotal, 2);
                    $scope.invoice.accountCodeTotal.push($scope.tempaccountCodeTotal);
                }


            }

            // Final total calcultion
            $scope.FinalTotalCalc = function () {
                var finalTotal = 0;
                finalTotal = parseFloat($scope.invoice.subTotal) + parseFloat($scope.invoice.igst);
                $scope.invoice.finalTotal = $scope.round(finalTotal, 2);


                if ($scope.invoice.isCancelled == 1) {
                    $('.form-control, input[type=text], select, textarea').attr('disabled', 'disabled');
                    for (var index = 0; index < $scope.invoice.lineItem.length; index++) {
                        $scope.invoice.lineItem[index].enableRow = false;
                    }
                }

            }


            // Update invoice
            $scope.updateInvoice = function () {

                if ($scope.invoiceForm.$invalid == false && $scope.invoice.finalTotal > 0 && $scope.invoice.isCancelled == 0) {


                    $scope.invoice.invoiceLineItem = [];

                    for (var i = 0; i < $scope.invoice.lineItem.length; i++) {

                        var enableRow = $scope.invoice.lineItem[i].enableRow;

                        if (enableRow == true) {

                            $scope.invoice.invoiceLineItem.push($scope.invoice.lineItem[i]);
                        }
                    }

                    if ($scope.invoice.enableStatusChange == false) {
                        $scope.invoice.isStatusChange = '';
                    }
                    
                    if(enableApproval == false){
                        $scope.invoice.isStatusChange = '';
                    }

                    $scope.commonLoader = true;
                    var postData = {};
                    angular.extend(postData, $scope.invoice);

                    $http.post(BASE_URL + "fin/invoice/ajaxUpdateInvoice", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {
                            $scope.commonLoader = false;
                            showMessage('Invoice', 'Invoice updated successfuly.', 'success');
                            $timeout(function () {
                                location.reload();
                                hideMessage();
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }
                        $scope.invoice.invoiceLineItem = [];
                    }, function myError(response) {
                        $scope.commonLoader = false;
                        $scope.invoice.invoiceLineItem = [];
                    });
                } else {
                    showMessage('Invoice', 'Please fill the required fields.', 'error');
                }
            }



            // show Additional LineItem
            $scope.getServiceItems = function ()
            {
                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/invoice/getServiceItems",
                            type: 'POST'
                        })
                        .withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('SECTION_NAME').withTitle('Service Group'),
                    DTColumnBuilder.newColumn('ITEM_NAME').withTitle('Line Item'),
                    DTColumnBuilder.newColumn('ACCOUNT_CODE').withTitle('Account Code'),
                    DTColumnBuilder.newColumn('RATE_FIELD').withTitle('Item type'),
                    DTColumnBuilder.newColumn('ITEM_SRC_TYPE').withTitle('Item Source'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };


            // Invoice cancel
            $scope.cancelInvoice = [];
            $scope.showCancelInvoiceModal = function () {
                $('#cancelInvoiceModal').modal('show');
            }
            $scope.cancelInvoice = function () {
                if ($scope.cancelInvoiceForm.$invalid == false) {
                    $scope.cancelInvoice.cancelInvoiceID = invoiceId;

                    var postData = {};
                    angular.extend(postData, $scope.cancelInvoice);

                    $http.post(BASE_URL + "fin/invoice/ajaxCancelInvoice", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {
                            $scope.commonLoader = false;
                            showMessage('Invoice', 'Invoice cancelled successfuly.', 'success');
                            $timeout(function () {
                                location.reload();
                                hideMessage();
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }
                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });

                }
            }

            // Invoice Delete
            $scope.deleteInvoice = [];
            $scope.showDeleteInvoiceModal = function () {
                $('#deleteInvoiceModal').modal('show');
            }
            $scope.deleteInvoice = function () {
                if ($scope.deleteInvoiceForm.$invalid == false) {
                    $scope.deleteInvoice.deleteInvoiceID = invoiceId;

                    var postData = {};
                    angular.extend(postData, $scope.deleteInvoice);

                    $http.post(BASE_URL + "fin/invoice/ajaxDeleteInvoice", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {
                            $scope.commonLoader = false;
                            showMessage('Invoice', 'Invoice deleted successfuly.', 'success');
                            $timeout(function () {
                                $window.location.href = BASE_URL + 'fin/list/';
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }
                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });

                }
            }

            function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
                $('td .insertNewLineItem', nRow).unbind('click');
                $('td .insertNewLineItem', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.insertNewLineItem(aData.SERVICE_ITEM_ID, aData.ITEM_SRC);
                    });
                });
                return nRow;
            }
            $scope.showAddLineItem = function () {
                $('#addLineItemModal').modal('show');
                $scope.getServiceItems();
            };

            $scope.insertNewLineItem = function (SERVICE_ITEM_ID, ITEM_SRC) {
                var jobId = $scope.invoice.projectId;
                var itemExists = true;
                angular.forEach($scope.invoice.lineItem, function (value, key) {
                    if (value.lineItemId == SERVICE_ITEM_ID) {
                        itemExists = false;
                    }
                });

                if (itemExists == false) {
                    alert('Line-item already added');
                    return false;
                } else if (jobId > 0 && jobId != '') {
                    var postData = {
                        jobId: jobId,
                        serviceItemId: SERVICE_ITEM_ID,
                        serviceItemSrc: ITEM_SRC,
                    };
                    $scope.commonLoader = true;
                    $http.post(BASE_URL + "fin/invoice/getInvoiceEstdQty", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            var lineItem = response.data.lineItem;
                            var lineItemQuantity = response.data.lineItemQuantity;

                            var lineItemQuantitykeys = Object.keys(lineItemQuantity);

                            angular.forEach(lineItem, function (value, key) {

                                $scope.tempLineItem = {};
                                $scope.tempLineItem.serviceGroupId = value.SERVICE_GROUP_ID;
                                $scope.tempLineItem.serviceGroupName = value.SECTION_NAME;
                                $scope.tempLineItem.itemCode = value.ITEM_CODE;
                                $scope.tempLineItem.lineItemRemark = '';
                                $scope.tempLineItem.lineItemId = value.SERVICE_ITEM_ID;
                                $scope.tempLineItem.itemSrc = value.ITEM_SRC;

                                $scope.tempLineItem.accountCode = value.ACCOUNT_CODE;
                                $scope.tempLineItem.description = value.ITEM_NAME;
                                $scope.tempLineItem.unitQty = 1;
                                $scope.tempLineItem.rateField = value.RATE_FIELD;

                                if (value.RATE_FIELD == 1) {
                                    $scope.tempLineItem.unitType = value.UNIT_ENUM_ID;
                                } else {
                                    $scope.tempLineItem.unitType = 0;
                                }

                                if (lineItemQuantity[value.SERVICE_ITEM_ID]) {
                                    $scope.tempLineItem.qty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                    $scope.tempLineItem.autoQty = lineItemQuantity[value.SERVICE_ITEM_ID];
                                } else {
                                    $scope.tempLineItem.qty = 1;
                                    $scope.tempLineItem.autoQty = 0;
                                }
                                $scope.tempLineItem.enableRow = true;
                                $scope.tempLineItem.enableCheckBox = true;

//                                if (lineItemQuantitykeys.length > 0) {
//                                    $scope.tempLineItem.price = value.RATE;
//                                } else {
//                                    $scope.tempLineItem.price = 0;
//                                }

                                //$scope.tempLineItem.price = value.RATE;
                                //$scope.tempLineItem.total = 0;

                                $scope.tempLineItem.disablePriceEdit = 0;
                                $scope.tempLineItem.price = 0;
                                $scope.tempLineItem.total = 0;

                                if (response.data.clientItemRate.client == "SPRINGER_INVOICE" || response.data.clientItemRate.client ==  "OUP_INVOICE") {

                                    if (response.data.clientItemRate.autoErrorMsg == "") {
                                        $scope.tempLineItem.price = value.RATE;
                                        $scope.tempLineItem.disablePriceEdit = 1;
                                    }
                                } else if (value.ITEM_SRC == 2) {
                                    $scope.tempLineItem.price = value.RATE;
                                    $scope.tempLineItem.disablePriceEdit = 1;
                                }


                                $scope.invoice.lineItem.push($scope.tempLineItem);
                            });


                            showNotify('Line-item added successfully', 'success');
                            $scope.lineItemCalc();
                        } else if (response.data.status == 2) {
                            alert('Try Again');
                            $scope.lineItemCalc();
                        }

                    }, function myError(response) {
                        alert('Try Again');
                        $scope.lineItemCalc();
                    });
                    $scope.commonLoader = false;
                }


            };


            $scope.invoiceApprovalLogModal = function () {
                $('#invoiceApprovalLogModal').modal('show');
            };

            // line item row move up function
            $scope.upitem = function (item, position) {
                if (position > -1 && position < $scope.invoice.lineItem.length)
                {
                    if (position == 0)
                    {
                        return false;
                    } else
                    {
                        var nextposition = $scope.invoice.lineItem[position - 1];
                        $scope.invoice.lineItem[position - 1] = $scope.invoice.lineItem[position];
                        $scope.invoice.lineItem[position] = nextposition;
                    }
                }
            };
            // line item row move down function
            $scope.downitem = function (item, position) {
                if (position > -1 && position < $scope.invoice.lineItem.length)
                {
                    if (position == $scope.invoice.lineItem.length - 1)
                    {
                        return false;
                    } else
                    {
                        var nextposition = $scope.invoice.lineItem[position + 1];
                        $scope.invoice.lineItem[position + 1] = $scope.invoice.lineItem[position];
                        $scope.invoice.lineItem[position] = nextposition;
                    }
                }
            };



        })
        .controller('invoiceListController', function ($scope, $http, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder, Excel) {
			$scope.JobID	=	"";
			if(getUrlParameter(1) == "oup" || getUrlParameter(1) == "OUP"){
				$scope.JobID 	= 	"oup";
			} 
            $scope.listType = 'TABLE_VIEW';
            $scope.projectId = '';
            $scope.invoiceStatus = '';
            $scope.startDate = '';
            $scope.endDate = '';
            $scope.pMName = '';

            $scope.ajaxData = {
                'listType': $scope.listType,
                'projectId': $scope.projectId,
                'invoiceStatus': $scope.invoiceStatus,
                'startDate': $scope.startDate,
                'endDate': $scope.endDate,
                'pMName': $scope.pMName,
				'appJobId':$scope.JobID
            };

            $scope.getInvoiceList = function ()
            {

                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/invoice/getInvoiceList",
                            type: 'POST',
                            data: $scope.ajaxData
                        })
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [8, 'desc'])
                        .withOption('aLengthMenu', [[10, 50, 100, 1000], [10, 50, 100, 1000]]);
//                        .withOption('dom', 'Bfrtip')
//                        .withButtons([
//                            {
//                                extend: 'copy',
//                                text: '<i class="fa fa-files-o"></i> Copy',
//                                titleAttr: 'Copy'
//                            },
//                            {
//                                extend: 'excel',
//                                text: '<i class="fa fa-file-text-o"></i> Excel',
//                                titleAttr: 'Excel'
//                            },
//                            {
//                                extend: 'print',
//                                text: '<i class="fa fa-print" aria-hidden="true"></i> Print',
//                                titleAttr: 'Print'
//                            }
//                        ]);

//                        .withOption('dom', 'Bfrtip')
//                        .withOption('buttons', ['copy', 'csv', 'excel', 'pdf', 'print']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('INVOICE_NO').withTitle('Invoice No'),
                    DTColumnBuilder.newColumn('INVOICE_DATE').withTitle('Invoice Date'),
                    DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Project'),
                    DTColumnBuilder.newColumn('CUSTOMER_NAME').withTitle('Client'),
                    DTColumnBuilder.newColumn('FINAL_TOTAL').withTitle('Final Total'),
                    DTColumnBuilder.newColumn('CURRENT_STATUS').withTitle('Status'),
                    DTColumnBuilder.newColumn('CREATED_BY').withTitle('Created By'),
                    DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created At'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };

            $scope.getInvoiceList();


            // get project information
            $scope.listReload = function () {
                $scope.dtOptions.ajax.data = {
                    'listType': $scope.listType,
                    'projectId': $scope.projectId,
                    'invoiceStatus': $scope.invoiceStatus,
                    'startDate': $scope.startDate,
                    'endDate': $scope.endDate,
                    'pMName': $scope.pMName
                };
                $scope.dtInstance.reloadData();
                return false;
            }

            $scope.filterClear = function () {

                $scope.listType = 'TABLE_VIEW';
                $scope.projectId = '';
                $scope.invoiceStatus = '';
                $scope.startDate = '';
                $scope.endDate = '';
                $scope.pMName = '';

                $('.chosen-select')
                        .find('option:first-child').prop('selected', true)
                        .end().trigger('chosen:updated');
                $('.chosen-select').chosen({});

                $scope.listReload();
                return false;
            }


            $scope.exportToExcel = function (tableId) {



                /*
                 var exportHref = Excel.tableToExcel(tableId, 'sheet name');
                 $timeout(function () {
                 location.href = exportHref;
                 }, 100); // trigger download
                 */

            }

        });

//only-numbers
ngApp.directive('onlyNumbers', function () {
    return  {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                var $input = $(this);
                var value = $input.val();
                var RE = /^\d*\.?\d{0,2}$/;
                //var RE = /^[0-9]+\.?[0-9]*$/;
                //console.log(value);
                if (event.shiftKey) {
                    event.preventDefault();
                    return false;
                }
                //console.log(event.which);
                if ([8, 9, 13, 27, 37, 38, 39, 40, 190, 110, 46].indexOf(event.which) > -1) {
                    // backspace, tab, enter, escape, arrows, dot, dot, delete
                    return true;
                } else if (event.which >= 48 && event.which <= 57) {
                    // numbers 0 to 9
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // numpad number
                    return true;
                } else {
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});

ngApp.directive('droppable', [
    '$parse',
    function ($parse) {
        return {
            link: function (scope, element, attr) {
                function onDragOver(e) {
                    if (e.preventDefault) {
                        e.preventDefault();
                    }

                    if (e.stopPropagation) {
                        e.stopPropagation();
                    }
                    e.dataTransfer.dropEffect = 'move';
                    return false;
                }

                function onDrop(e) {
                    if (e.preventDefault) {
                        e.preventDefault();
                    }
                    if (e.stopPropagation) {
                        e.stopPropagation();
                    }
                    var data = e.dataTransfer.getData('Text');

                    data = angular.fromJson(data);

                    var dropfn = attr.drop;
                    var fn = $parse(attr.drop);

                    var rowDroppedAt = jQuery(e.target).parents('tr')[0].sectionRowIndex;
                    scope.$apply(function () {
                        scope[dropfn](data, rowDroppedAt);
                    });
                }

                element.bind('dragover', onDragOver);
                element.bind('drop', onDrop);
            },
        };
    },
]);
ngApp.directive('draggable', function () {
    return {
        link: function (scope, elem, attr) {
            elem.attr('draggable', true);
            var dragDataVal = '';
            var draggedGhostImgElemId = '';
            attr.$observe('dragdata', function (newVal) {
                dragDataVal = newVal;
            });

            attr.$observe('dragimage', function (newVal) {
                draggedGhostImgElemId = newVal;
            });

            elem.bind('dragstart', function (e) {
                var sendData = angular.toJson(dragDataVal);

                e.dataTransfer.setData('Text', sendData);

                if (attr.dragimage !== 'undefined') {
                    e.dataTransfer.setDragImage(
                            document.getElementById(draggedGhostImgElemId),
                            0,
                            0
                            );
                }

                var dragFn = attr.drag;
                if (dragFn !== 'undefined') {
                    scope.$apply(function () {
                        scope[dragFn](sendData);
                    });
                }
            });
        },
    };
});
ngApp.factory('Excel', function ($window) {
    var uri = 'data:application/vnd.ms-excel;base64,',
            template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
            base64 = function (s) {
                return $window.btoa(unescape(encodeURIComponent(s)));
            },
            format = function (s, c) {
                return s.replace(/{(\w+)}/g, function (m, p) {
                    return c[p];
                })
            };
    return {
        tableToExcel: function (tableId, worksheetName) {
            var table = $(tableId),
                    ctx = {worksheet: worksheetName, table: table.html()},
            href = uri + base64(format(template, ctx));
            return href;
        }
    };
});