/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */


ngApp.controller('ngController', function ($scope, $http, $filter, $timeout, $interval, DTOptionsBuilder, DTColumnBuilder, $window) {

    $scope.userId = 0;
    $scope.menuParent = 'Finance';
    $scope.menuChild = 'Pricing Grid';
    $scope.subMenuChild = 'Upload';
    $scope.BASEURL = BASE_URL;
});


ngApp.controller('FileUploadController', ['$scope', '$compile', '$http', '$window', 'DTOptionsBuilder', 'DTColumnBuilder', 'DTColumnDefBuilder', '$timeout', function ($scope, $compile, $http, $window, DTOptionsBuilder, DTColumnBuilder, DTColumnDefBuilder, $timeout) {

        var vm = this;
        vm.dtInstance = {};
        $scope.formField = {};
        $scope.errors = [];
        $scope.pricingGridUploadBtn = true;
        $scope.loading_status = false;

        /*$scope.customerIdSel = document.getElementById('customerIdSel').value;
        $scope.customerDivisionIdSel = document.getElementById('customerDivisionIdSel').value;*/
		$scope.customerId = '';
        $scope.customerDivisionId = '';
        $scope.startDate = '';
        $scope.endDate = '';	

		$scope.defaultCustomerList = document.getElementById('defaultCustomerList').value;
		$scope.defaultCustomerDivisionList = document.getElementById('defaultCustomerDivisionList').value;

        var formData = new FormData();

        $scope.setTheFiles = function (files) {
            if (files.length == 0) {
                $scope.progress_upload = 'Please select a file for upload.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else {
                angular.forEach(files, function (value, key) {
                    /*console.log(key + ' ' + value.name);*/
                    var fileName = value.name;
                    var extn = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
                    if (extn == "xls" || extn == "xlsx") {
                        formData.append('pricingGridExcelFile', value);
                    } else {
                        $scope.progress_upload = 'Please upload only excel file.';
                        //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                        customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
                    }
                });
            }
        };

        $scope.uploadFile = function () {

            var getFormFieldData = $scope.formField;
            var startDate = new Date($("#startDate").val()); //Year, Month, Date
            var endDate = new Date($("#endDate").val()); //Year, Month, Date

			if (!$scope.customerId) {
                $scope.progress_upload = 'Customer Id is empty.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (!$scope.customerDivisionId) {
                $scope.progress_upload = 'Customer Division Id is empty';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (!getFormFieldData.startDate && !getFormFieldData.endDate) {
                $scope.progress_upload = 'Please choose start date and end date.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (!getFormFieldData.startDate) {
                $scope.progress_upload = 'Please choose start date.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (!getFormFieldData.endDate) {
                $scope.progress_upload = 'Please choose end date.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (endDate < startDate) {
                $scope.progress_upload = 'End Date is lesser then start date.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (startDate > endDate) {
                $scope.progress_upload = 'Start Date is greater then end date.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            } else if (formData.has('pricingGridExcelFile')) {

                formData.append('startDate', getFormFieldData.startDate);
                formData.append('endDate', getFormFieldData.endDate);
                formData.append('customerId', $scope.customerId);
                formData.append('customerDivisionId', $scope.customerDivisionId);
                //angular.element('#loading_status').show();	
                $scope.commonLoader = true;
                var request = {
                    method: 'POST',
                    url: BASE_URL + 'fin/pricinggrid/upload/file',
                    data: formData,
                    headers: {
                        'Content-Type': undefined
                    }
                };

                $http(request).then(function success(e) {
                    //angular.element('#loading_status').hide();
                    $scope.commonLoader = false;
                    // clear uploaded file
                    var fileElement = angular.element('#pricingGridExcelFile');
                    fileElement.value = '';
                    if (e.data.Status == 1) {
                        $scope.progress_upload = e.data.ErrorMsg;
                        //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                        customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
                        angular.element("input[type='file']").val(null);
                    } else {
                        //$scope.files = e.data.files;
                        $scope.errors = [];
                        $scope.progress_upload = e.data.Msg;
                        //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-success").show(); 
                        customerAlertMessageBootbox('Success Message', $scope.progress_upload, 'success');
                        $scope.dtInstance.reloadData();
                        $scope.formField.startDate = null;
                        $scope.formField.endDate = null;
                    }
                    $("#pricingGridExcelFile").val('');
                    //setTimeout( function(){  angular.element('#upload-file-errors').hide(); } , 10000 );            

                }, function error(e) {
                    $scope.errors = e.data.errors;
                });
            } else {
                $scope.progress_upload = 'Please select a file for upload.';
                //angular.element('#upload-file-errors').removeClass("alert alert-danger").removeClass("alert alert-success").addClass("status_msg alert alert-danger").show();
                customerAlertMessageBootbox('Error Message', $scope.progress_upload, 'error');
            }
        };
		
		
			
        $scope.reloadDataTable = function () {
			$scope.ajaxData = {
				'customerId': $scope.customerId,
				'customerDivisionId': $scope.customerDivisionId,
				'startDate': $scope.startDate,
				'endDate': $scope.endDate
			};
			
			$scope.dtOptions = DTOptionsBuilder.newOptions()
					.withOption('ajax', {
						//dataSrc: "data",
						data: $scope.ajaxData,
						url: BASE_URL + 'fin/pricinggrid/getAllUploadFilesList',
						type: 'POST'
					})
					.withDataProp('data')// parameter name of list use in getLeads Fuction
					.withOption('rowCallback', rowCallback)
					.withOption('drawCallback', drawCallback)
					/*.withOption('columnDefs', { "visible": false, "targets": 1 })*/
					.withOption('stateSave', false)
					.withOption('processing', true) // required - for show progress bar
					.withOption('serverSide', true)// required - for server side processing
					.withOption('responsive', true)// required - for server side processing
					.withOption('paging', true)// required
					.withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
					.withDisplayLength(10) //// Page size
					.withOption('lengthMenu', [10, 25, 50, 100, 1000])
					.withOption('order', [[6, 'desc'], [7, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


			$scope.dtColumns = [
				//DTColumnBuilder.newColumn('UPLOADED_DOCUMENT_ID').withTitle('Id'),
				DTColumnBuilder.newColumn('ORG_FILENAME').withTitle('File Name').notSortable(),
				DTColumnBuilder.newColumn('CUSTOMER_NAME').withTitle('Customer / Customer Division Name').notSortable(),
				DTColumnBuilder.newColumn('CURRENCY').withTitle('Currency').notSortable(),
				DTColumnBuilder.newColumn('VENDOR_NAME').withTitle('Vendor Name').notSortable(),
				//DTColumnBuilder.newColumn('DATE').withTitle('Document Date'),
				DTColumnBuilder.newColumn('START_DATE').withTitle('Effective Start Date').notSortable(),
				DTColumnBuilder.newColumn('END_DATE').withTitle('Effective End Date').notSortable(),
				DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Upload Date').notSortable(),
				//DTColumnBuilder.newColumn('GROUP_KEY').withTitle('Group Key').notSortable().notVisible(),
				DTColumnBuilder.newColumn(null).withTitle('Actions').notSortable().renderWith(actionsHtml)
			];////DTColumnBuilder.newColumn('ACTION').withTitle('Action'),

			$scope.dtInstance = {};
		};

		$scope.reloadDataTable();
		 
        // get 
        $scope.listReload = function () {
			/* $scope.ajaxData.customerId = $scope.customerId;
			$scope.ajaxData.customerDivisionId = $scope.customerDivisionId;
			$scope.ajaxData.startDate = $scope.startDate;
			$scope.ajaxData.endDate = $scope.endDate; */
            $scope.dtOptions.ajax.data = {
				'customerId': $scope.customerId,
				'customerDivisionId': $scope.customerDivisionId,
				'startDate': $scope.startDate,
				'endDate': $scope.endDate
            };
            $scope.dtInstance.reloadData();
            return false;
        }
		
		$scope.changeCustomer = function(cid) {
			$scope.reloadDataTable();
			$http.get(BASE_URL+"fin/pricinggrid/getCustomerDivisionList/"+cid) .then(function mySuccess(response) 
			{
				if(response.status != 200)
				{
					//showNotify('Kindly reload page error ocured.'  , 'danger' );
					customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
				}
				
				$scope.customerDivisionList 	=   response.data.customerDivisionList;
				$scope.customerDivisionId = response.data.customerDivisionList[0];
				if($scope.defaultCustomerDivisionList.length > 0){
					if(typeof response.data.customerDivisionKey[$scope.defaultCustomerDivisionList] !== "undefined") {
						$scope.customerDivisionId = $scope.customerDivisionList[response.data.customerDivisionKey[$scope.defaultCustomerDivisionList]].CUSTOMER_DIVISION_ID;
						$scope.reloadDataTable();
					}				
				}
				//console.log($scope.customerDivisionList );
				//$scope.customerDivisionId = $scope.customerDivisionList[1];				
			}, 
			function myError(response) 
			{
				//showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
			});
			
		};
		
		if($scope.defaultCustomerList.length > 0){
			$scope.customerId = $scope.defaultCustomerList;
			$scope.changeCustomer($scope.defaultCustomerList);
		}
		
		
		$scope.changeCustomerDivision = function() {
			$scope.reloadDataTable();
		};

        function actionsHtml(data, type, full, meta) {
            //return '<button class="btn btn-xs btn-success pointer editUploadFile" ng-click="editUploadFile()" title="Edit" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i></button>&nbsp;&nbsp;<button class="btn btn-xs btn-info pointer downloadExcelFile" ng-click="edit()" title="Download" ><i class="ace-icon fa fa-download bigger-120"></i></button>';
            return '<button class="btn btn-xs btn-info pointer downloadExcelFile" ng-click="edit()" title="Download" ><i class="ace-icon fa fa-download bigger-120"></i></button>';
        }

        function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {
            // Unbind first in order to avoid any duplicate handler (see https://github.com/l-lin/angular-datatables/issues/87)
            $('td button.downloadExcelFile', nRow).unbind('click');
            $('td button.downloadExcelFile', nRow).bind('click', function ()
            {
                $scope.$apply(function () {
                    //console.log(nRow);console.log(aData);console.log(iDisplayIndex);console.log(iDisplayIndexFull);
                    //alert("You've clicked row," + aData.UPLOADED_DOCUMENT_ID);
                    //$window.location.href 	= 	BASE_URL+"fin/pricinggrid/files/edit/"+aData.UPLOADED_DOCUMENT_ID;
                    $http.get(BASE_URL + "fin/pricinggrid/file/download/" + aData.UPLOADED_DOCUMENT_ID).then(function mySuccess(response) {
                        if (response.data.Msg == "Success") {
                            //$window.location.href 	= 	response.data.DOCUMENT_PATH;
                            var win = window.open(BASE_URL + "" + response.data.DOCUMENT_PATH, '_blank');
                            //win.focus();
                            //var myRef = window.open(BASE_URL+""+response.data.DOCUMENT_PATH,'downloadExcel', 'left=20,top=20,width=500,height=500,toolbar=1,resizable=0');
                            //myRef.focus();
                            /*var id = (new Date()).getTime();
                             var myWindow = window.open(BASE_URL+""+response.data.DOCUMENT_PATH+'?printerFriendly=true', id, 'toolbar=1,scrollbars=1,location=0,statusbar=0,menubar=1,resizable=1,width=800,height=600,left = 240,top = 212');*/
                            /*var a = document.createElement("a");
                             a.setAttribute("href", url);
                             a.setAttribute("target", "_blank");
                             a.setAttribute("id", "openwin");
                             document.body.appendChild(a);
                             a.click();*/
                        }
                    },
                            function myError(response) {
                                console.log(response);
                            });
                });
            });
			
			$('td button.editUploadFile', nRow).unbind('click');
            $('td button.editUploadFile', nRow).bind('click', function ()
            {
                $scope.$apply(function () {
                    $window.location.href 	= 	BASE_URL+aData.editLink;
                });
            });
            return nRow;
        }
		
		function drawCallback(settings) {
			var groupColumn = 4;//7
			var api = this.api();
            var rows = api.rows( {page:'current'} ).nodes();
            var last=null;
            //var customerDivName=null;
           // var startDateGroup=null;
			
			//console.log(settings);
			//console.log(api.column(4, { page: 'current' }).data());
			//console.log( api.rows( {page:'current'} ) );
            api.column(groupColumn, {page:'current'} ).data().each( function ( group, i ) {
				//console.log(last+'!=='+group+'!=='+startDateGroup+'!=='+settings.aoData[i]._aData.START_DATE);
				
                if ( last !== group){
					//if(customerDivName === settings.aoData[i]._aData.CUSTOMER_NAME) {	
						/*var editTemp = $compile('<tr class="group"><td colspan="6">'+group+' - '+settings.aoData[i]._aData.END_DATE+'</td><td colspan="1"><button class="btn btn-xs btn-success pointer editUploadFile" ng-click="editUploadFile(\''+settings.aoData[i]._aData.editLink+'\')" title="Edit" ><i class="ace-icon fa fa-pencil-square-o bigger-120"></i></button></td></tr>')($scope);*/
						var editTemp = $compile('<tr class="group"><td colspan="7">'+settings.aoData[i]._aData.START_DATE+' - '+settings.aoData[i]._aData.END_DATE+'&nbsp;&nbsp;'+settings.aoData[i]._aData.pendingApprovedBtn+'</td><td colspan="7">'+settings.aoData[i]._aData.downloadBtn+'</td></tr>')($scope);
						$(rows).eq( i ).before(
							editTemp                       
						); 
						last = group;
						//customerDivName = settings.aoData[i]._aData.CUSTOMER_NAME;
						//startDateGroup = settings.aoData[i]._aData.START_DATE;
					//}
                }
            });
		}
		
		$scope.editUploadFile = function (rUrl) {
			$window.location.href 	= 	BASE_URL+rUrl;
		}
        //}

        $scope.reloadDatepicker = function () {
            //$('#endDate').datepicker('destroy');
        }
		
		$scope.downloadPricingList = function(dUrl) {
			var win = window.open(BASE_URL+dUrl, '_blank');
			win.focus();
		}


    }]);

ngApp.directive('ngFiles', ['$parse', function ($parse) {

        function file_links(scope, element, attrs) {
            var onChange = $parse(attrs.ngFiles);
            element.on('change', function (event) {
                onChange(scope, {files: event.target.files});
            });
        }

        return {
            link: file_links
        }
    }]);
