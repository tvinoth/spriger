/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{
	
	$scope.userId = 0;	
 	$scope.menuParent = 'Finance';
	$scope.menuChild  = 'Pricing Grid';
	$scope.subMenuChild  = 'Update/Download';
	$scope.BASEURL = BASE_URL;
        
	$scope.currentStartDate = '';
	$scope.currentEndDate = '';
	$scope.showCustomerDivisionDataLabel = false;
	$scope.showProcessTypeDataLabel = false;
	$scope.showDateRangeDataLabel = false;
	$scope.currentSelectedDateRangeValue = "";
	
	$scope.showDownloadLabel = false;
	$scope.showEditFileDetailsDiv = false;
	$scope.showUploadBtn = false;
	$scope.showDownloadBtn = false;
	$scope.showApprovalBtn = false;	
	$scope.showApprovalBtnName = '';	
	
	$scope.showFilterDiv = false;
			
	$scope.formField = {};
	
	
	$scope.isObjectEmpty = function(card, fieldName){
		if(fieldName == "processTypeIdSel"){
			if(card == "0"){
				return true;
			}
		}
		return Object.keys(card).length === 0;
	}
	
	$scope.processTypeNameSel = document.getElementById('processTypeNameSel').value;
	$scope.isFinalSel = document.getElementById('isFinalSel').value;
	
	$scope.customerIdSel = document.getElementById('customerIdSel').value;
	
	$scope.customerId 		=   "";
	if($scope.isObjectEmpty($scope.customerIdSel, 'customerIdSel')) 
	{
		$scope.customerId 	=   "";
		$scope.customerName = "";
		
	} 
	else 
	{
		$scope.customerId 	=   $scope.customerIdSel;
        $scope.customerName =   $scope.customerIdSel;
	}
	
	$scope.customerDivisionIdSel = document.getElementById('customerDivisionIdSel').value;
	
	$scope.customerDivisionId 		=   "";
	if($scope.isObjectEmpty($scope.customerDivisionIdSel, 'customerDivisionIdSel')) 
	{
		$scope.customerDivisionId 	=   "";
		$scope.customerDivisionName = "";
		
	} 
	else 
	{
		$scope.customerDivisionId 	=   $scope.customerDivisionIdSel;
        $scope.customerDivisionName =   $scope.customerDivisionIdSel;
	}
	
	$scope.processTypeIdSel = document.getElementById('processTypeIdSel').value;
	
	$scope.processTypeId 		=   "";
	if($scope.isObjectEmpty($scope.processTypeIdSel, 'processTypeIdSel')) 
	{
		$scope.processTypeId 	=   "";
		$scope.processTypeName = "";
		
	} 
	else 
	{
		if($scope.processTypeIdSel == "0"){
			$scope.processTypeId 	=   "0";
			$scope.processTypeName 	=   "0";
		}else{
			$scope.processTypeId 	=   $scope.processTypeIdSel;
			$scope.processTypeName =   $scope.processTypeIdSel;
		}
        
	}
	console.log("----"+$scope.processTypeId);
	$scope.dateRangeValSel = document.getElementById('dateRangeValSel').value;
	
	$scope.dateRangeVal 		=   "";
	if($scope.isObjectEmpty($scope.dateRangeValSel, 'dateRangeValSel')) 
	{
		$scope.dateRangeVal 	=   "";
		$scope.dateRangeDetails = "";
		
	} 
	else 
	{
		$scope.dateRangeVal 	=   $scope.dateRangeValSel;
        $scope.dateRangeDetails =   $scope.dateRangeValSel;
	}
	
	$scope.getCustomerList 	= 	function() 
	{
        $scope.srciframepath        =   null;
		$scope.customerList = 	[];
		$http.get(BASE_URL+"fin/pricinggrid/getCustomerList") .then(function mySuccess(response) 
		{
            if(response.status != 200)
            {
                //showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
            }
            $scope.customerList 	=   response.data.customerList;
			if($scope.customerName  !=  ''){
				//$('#customerDetails').val('number:'+$scope.customerName);	
				$scope.customerName = $scope.customerList[0].CUSTOMER_ID;				
				$scope.getCustomerDivisionList($scope.customerList[0].CUSTOMER_ID);				
			}else if($scope.customerName   ==  ''){
				//$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+$scope.customerList[0].CUSTOMER_ID;
			}
		}, 
		function myError(response) 
        {
            //showNotify('Kindly reload page error ocured.'  , 'danger' );
			customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
		});			
	};
	
	$scope.getCustomerList();
	
	$scope.customerListdetails 	= 	function(item) 
	{
		if(item){
			var customerId  =   item;//$scope.customerName;
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId;
		}else{
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing";
		}
        
	}; 
	
	$scope.getCustomerDivisionList 	= 	function(cid) 
	{
		//$scope.customerName = response.data.customerId;
        //$scope.srciframepath        =   null;
		//$scope.customerList = 	[];
		$http.get(BASE_URL+"fin/pricinggrid/getCustomerDivisionList/"+cid) .then(function mySuccess(response) 
		{
            if(response.status != 200)
            {
                //showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
            }
			
            $scope.customerDivisionList 	=   response.data.customerDivisionList;
			if($scope.customerDivisionName  !=  ''){
				$scope.showCustomerDivisionDataLabel = true;
				//$('#customerDetails').val('number:'+$scope.customerDivisionName);
				$scope.customerDivisionName = $scope.customerDivisionList[response.data.customerDivisionKey[$scope.customerDivisionName]].CUSTOMER_DIVISION_ID;
				//$scope.customerDivisionName = response.data.customerDivisionKey;
				//alert($scope.customerDivisionId);
				//$scope.getDateRange($scope.customerId, $scope.customerDivisionId);				
				$scope.getProcessTypeList();				
			}else if($scope.customerDivisionName   ==  ''){
				$scope.showCustomerDivisionDataLabel = true;
				//$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+$scope.customerList[0].CUSTOMER_ID;
			}
		}, 
		function myError(response) 
        {
            //showNotify('Kindly reload page error ocured.'  , 'danger' );
			customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
		});			
	};
	
	//$scope.getCustomerDivisionList();
	
	$scope.customerDivisionListdetails 	= 	function(cditem) 
	{
		var customerId  =   $scope.customerName;//$scope.customerName;
		if(cditem != null ){
			var customerDivisionId  =   cditem;//$scope.customerDivisionName;
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId;
		}else if(customerId !=  ''){
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId;
		}else{
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing";
		}
        
	};
	
	$scope.getProcessTypeList = function (){
		var cid  =   $scope.customerName;
		$http.get(BASE_URL+"fin/pricinggrid/getCurrentStatusList/"+cid) .then(function mySuccess(response) 
		{
            if(response.status != 200)
            {
                //showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
            }
			
            $scope.processTypeList 	=   response.data.currentStatusList;
			if($scope.processTypeName  !=  ''){
				$scope.showProcessTypeDataLabel = true;
				/*if($scope.processTypeName == "10"){
					$scope.processTypeName = $scope.processTypeList[0].value;
				}else{
					$scope.processTypeName = $scope.processTypeList[1].value;
					$scope.showApprovalBtnName = $scope.processTypeNameSel;
				}*/	
				if($scope.processTypeName == "1010"){
					$scope.processTypeName = $scope.processTypeList[0].value;
					$scope.showApprovalBtnName = $scope.processTypeNameSel;
				}else{
					$scope.processTypeName = $scope.processTypeList[1].value;
				}					
				
				$scope.getDateRange();				
			}else if($scope.processTypeName   ==  ''){
				$scope.showProcessTypeDataLabel = true;
			}
		}, 
		function myError(response) 
        {
            //showNotify('Kindly reload page error ocured.'  , 'danger' );
			customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
		});	
		/*$scope.processTypeList 	=   [{name: 'Approved', value: 'approved' },{ name: 'Pending', value: 'pending' }];
        var customerId  =   $scope.customerName;
        var customerDivisionId  =   $scope.customerDivisionName;
		if(customerId !=  '' && customerDivisionId !=  ''){			
			//$scope.proccessType = ["Update", "Approve"];	
			
			if($scope.processTypeName  !=  ''){
				$scope.showProcessTypeDataLabel = true;
				console.log($scope.processTypeList);
				if($scope.processTypeName == "approved"){
					$scope.processTypeName = $scope.processTypeList[0].value;
				}else{
					$scope.processTypeName = $scope.processTypeList[1].value;
				}		
				
				$scope.getDateRange();				
			}else if($scope.processTypeName   ==  ''){
				$scope.showProcessTypeDataLabel = true;
			}	
	    }*/
	
    };
	
	$scope.processTypeListdetails 	= 	function(ptitem) 
	{
		var customerId  =   $scope.customerName;
		var customerDivisionId  =   $scope.customerDivisionName;
		if(ptitem != null){
			var processTypeId  =   ptitem;
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId+"/"+processTypeId;
		}else if(customerId !=  '' && customerDivisionId !=  ''){
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId;
		}else{
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing";
		}
        
	};
	
	$scope.editFileDetails = {};	
	
	/*
	 *  Get Edit File Details
	 *  
	*/
    /*$scope.getEditFileDetail = function (){
        var customerId  =   $scope.customerName;
		if(customerId !=  ''){
			$scope.commonLoader = true;
			$scope.editFileDetails = 	[];
			$http.get(BASE_URL+"fin/pricinggrid/getEditFileData/"+$scope.customerId) .then(function mySuccess(response) 
			{
				//if(response.data.msg == "success") {
				if(response.status != 200)
				{
					//showNotify('Kindly reload page error ocured.'  , 'danger' );
					customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
				}
				$scope.commonLoader = false;
				$scope.editFileDetails 	=   response.data.data;
				//console.log($scope.editFileDetails.variousPricingList);
				//$scope.serviceItemRowData 	=   $scope.editFileDetails.serviceItemRowData;console.log($scope.serviceItemRowData);
			}, 
			function myError(response) 
			{
				//showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
			});		
	    }
	
    };
	
	$scope.getEditFileDetail();*/
	
	$scope.dateRangeData = {};	
	
	$scope.getDateRange = function (){
        var customerId  =   $scope.customerName;
        var customerDivisionId  =   $scope.customerDivisionName;
        var processTypeId  =   $scope.processTypeName;
        var isFinalSel  =   $scope.isFinalSel;
		if(customerId !=  '' && customerDivisionId !=  '' && processTypeId !=  ''){
			$scope.commonLoader = true;
			$scope.editFileDetails = 	[];
			$http.get(BASE_URL+"fin/pricinggrid/getDateRangeData/"+$scope.customerId+"/"+$scope.customerDivisionId+"/"+$scope.processTypeId+"/"+$scope.isFinalSel) .then(function mySuccess(response) 
			{
				//if(response.data.msg == "success") {
				if(response.status != 200)
				{
					//showNotify('Kindly reload page error ocured.'  , 'danger' );
					customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
				}
				$scope.commonLoader = false;
				if(response.data.data.variousPricingList != '' && response.data.data.variousPricingList != null){
					$scope.showDateRangeDataLabel = true;
					$scope.dateRangeData 	=   response.data.data;
				}else{
					$scope.showDateRangeDataLabel = false;
					/*if($scope.processTypeId == 10){
						customerAlertMessageBootbox('Error Message', 'No records found for this status(Approved).', 'error');
					}else{
						customerAlertMessageBootbox('Error Message', 'No records found for this status(Pending).', 'error');
					}*/
					if($scope.processTypeId == 1010){
						customerAlertMessageBootbox('Error Message', 'No records found for this status(Pending).', 'error');
					}else{
						customerAlertMessageBootbox('Error Message', 'No records found for this status(Approved).', 'error');						
					}
				}
				
			}, 
			function myError(response) 
			{
				//showNotify('Kindly reload page error ocured.'  , 'danger' );
				customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
			});		
	    }
	
    };
	//$scope.getDateRange();
	
	$scope.chooseDateRangeDetails 	= 	function(dritem) 
	{
		var customerId  =   $scope.customerName;
		var customerDivisionId  =   $scope.customerDivisionName;
		var processTypeId  =   $scope.processTypeName;
		if(dritem != null){
			var dateRangeVal  =   dritem;
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId+"/"+processTypeId+"/"+dateRangeVal;
		}else if(customerId !=  '' && customerDivisionId !=  '' && processTypeId !=  ''){
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId+"/"+processTypeId;
		}else{
			$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing";
		}
        
	};
	
	$scope.updatePricingGrid = function(btnType) {
		$scope.commonLoader = true;
        
		$scope.inputEmptyCnt = 0; 
		$("input").removeClass("valColorError");
		$scope.getEditableFieldDataOnly = [];
		angular.forEach($scope.editFileDetails.serviceItemRowData, function(value, key){	
			//document.getElementById("col4_"+value.col4Id).classList.remove("valColorError");
			//document.getElementById("col6_"+value.col6Id).classList.remove("valColorError");
			//document.getElementById("col8_"+value.col8Id).classList.remove("valColorError");
			//document.getElementById("col10_"+value.col10Id).classList.remove("valColorError");
			
			
			//for (var i = 0; i < $scope.invoice.lineItem.length; i++) {
				/*if($scope.processTypeName == "10"){
					var enableRow = value.enableRow;

					if (enableRow == true) {
						if ($scope.getEditableFieldDataOnly.indexOf(value) == -1) {
							$scope.getEditableFieldDataOnly.push(value);
						}
					}
				}else{
					$scope.getEditableFieldDataOnly.push(value);
				}*/
				
				if($scope.processTypeName == "1010"){
					$scope.getEditableFieldDataOnly.push(value);
				}else{	
					var enableRow = value.enableRow;

					if (enableRow == true) {
						if ($scope.getEditableFieldDataOnly.indexOf(value) == -1) {
							$scope.getEditableFieldDataOnly.push(value);
						}
					}					
				}
			//}
		
			
			if(value.validateCol == 4 && (value.col4 == '' || value.col6 == '' || value.col8 == '' || value.col10 == '')){
				if(value.col4 == ''){
					document.getElementById("col4_"+value.col4Id).classList.add("valColorError");
					document.getElementById("col4_"+value.col4Id).focus(); 
				}
				if(value.col6 == ''){
					document.getElementById("col6_"+value.col6Id).classList.add("valColorError");
					document.getElementById("col6_"+value.col6Id).focus(); 
				}
				if(value.col8 == ''){
					document.getElementById("col8_"+value.col8Id).classList.add("valColorError");
					document.getElementById("col8_"+value.col8Id).focus(); 
				}
				if(value.col10 == ''){
					document.getElementById("col10_"+value.col10Id).classList.add("valColorError");
					document.getElementById("col10_"+value.col10Id).focus(); 
				}
				
				$scope.inputEmptyCnt++;
			} else if(value.validateCol == 2 && (value.col4 == '' || value.col8 == '')) {
				if(value.col4 == ''){
					document.getElementById("col4_"+value.col4Id).classList.add("valColorError");
					document.getElementById("col4_"+value.col4Id).focus(); 
				}
				if(value.col8 == ''){
					document.getElementById("col8_"+value.col8Id).classList.add("valColorError");
					document.getElementById("col8_"+value.col8Id).focus(); 
				}
				$scope.inputEmptyCnt++;
			}
        });

		var getFormFieldData = $scope.formField;
		var effectiveStartDate = new Date($("#effectiveStartDate").val()); //Year, Month, Date
        var effectiveEndDate = new Date($("#effectiveEndDate").val()); //Year, Month, Date
		
		if($scope.inputEmptyCnt > 0){
			$scope.commonLoader = false;
			customerAlertMessageBootbox('Error Message', 'Please filled in all highlighted fields.', 'error');	
		}else if($scope.getEditableFieldDataOnly === undefined || $scope.getEditableFieldDataOnly.length == 0){
			$scope.commonLoader = false;
			customerAlertMessageBootbox('Error Message', 'Please change any item price then click update button.', 'error');	
		}else if (!$scope.customerName) {
            $scope.commonLoader = false;
            customerAlertMessageBootbox('Error Message', 'Customer Id is empty.', 'error');
        }else if (!$scope.customerDivisionName) {
            $scope.commonLoader = false;
            customerAlertMessageBootbox('Error Message', 'Customer Division Id is empty', 'error');
        }else if (!$scope.processTypeName) {
            $scope.commonLoader = false;
            customerAlertMessageBootbox('Error Message', 'Status is empty', 'error');
        }else if (!getFormFieldData.startDate && !getFormFieldData.endDate) {
			$scope.commonLoader = false;
			document.getElementById("effectiveStartDate").classList.add("valColorError");
			//document.getElementById("effectiveStartDate").focus();
			document.getElementById("effectiveEndDate").classList.add("valColorError");
			//document.getElementById("effectiveEndDate").focus();
			customerAlertMessageBootbox('Error Message', 'Please choose start date and end date.', 'error');
		}else if (!getFormFieldData.startDate) {
			$scope.commonLoader = false;
			document.getElementById("effectiveStartDate").classList.add("valColorError");
			//document.getElementById("effectiveStartDate").focus();
			customerAlertMessageBootbox('Error Message', 'Please choose start date.', 'error');
		}else if (!getFormFieldData.endDate) {
			$scope.commonLoader = false;
			document.getElementById("effectiveEndDate").classList.add("valColorError");
			//document.getElementById("effectiveEndDate").focus();
			customerAlertMessageBootbox('Error Message', 'Please choose end date.', 'error');
		/*}else if (!getFormFieldData.reasonForChange) {
			$scope.commonLoader = false;
			document.getElementById("reasonForChange").classList.add("valColorError");
			document.getElementById("reasonForChange").focus();
		customerAlertMessageBootbox('Error Message', 'Please enter reason for change.', 'error');*/
		}else{
			//alert('success');
			//console.log($scope.editFileDetails.serviceItemRowData);
			var inp =	{
				startDate  		: 	getFormFieldData.startDate,
				endDate  		: 	getFormFieldData.endDate,
				customerDivisionId  		: 	$scope.customerDivisionName,
				processTypeId  		: 	$scope.processTypeName,
				isFinal  :   $scope.isFinalSel,
				reasonForChange : 	getFormFieldData.reasonForChange,
				pricingData  	: 	$scope.getEditableFieldDataOnly,
				updateServiceItemRate : 	"Update",
				Type: btnType
			};
			
			$scope.commonLoader = false;
			if($scope.processTypeName == "1010"){
				bootbox.confirm("Are you sure?", function(result) {
							if(result) {
								//console.log($scope.getEditableFieldDataOnly);
								$http.post(BASE_URL+'fin/pricinggrid/pricing/update/'+$scope.customerName,inp).then(function mySuccess(response)
								{	
									$scope.commonLoader = false;
									if(response.data.Status == 0 ){
										customerAlertMessageBootbox('Success Message', response.data.SuccessMsg, 'success');
										//$scope.getEditFileDetail();
										//$scope.getEditFileData($scope.currentStartDate, $scope.currentEndDate);
										var customerId  =   $scope.customerName;
										var customerDivisionId  =   $scope.customerDivisionName;
										var processTypeId  =   $scope.processTypeName;
										//$window.location.href 	= 	BASE_URL+"fin/pricinggrid/updatePricing/"+customerId+"/"+customerDivisionId+"/"+processTypeId;
										$window.location.href 	= 	BASE_URL+'fin/pricinggrid/upload';
									} else {
										customerAlertMessageBootbox('Error Message', response.data.ErrorMsg, 'error');
									}
								},
								function myError(response)
								{
									customerAlertMessageBootbox('Error Message', response.data.ErrorMsg, 'error');				
								});
							}
						});
				
			}else{
				bootbox.prompt("Please enter the reason?", function(result) {
					if (result === null) {
								
					} else {
						inp.reasonForChange = result;
						bootbox.confirm("Are you sure?", function(result) {
							if(result) {
								//console.log($scope.getEditableFieldDataOnly);
								$http.post(BASE_URL+'fin/pricinggrid/pricing/update/'+$scope.customerName,inp).then(function mySuccess(response)
								{	
									$scope.commonLoader = false;
									if(response.data.Status == 0 ){
										customerAlertMessageBootbox('Success Message', response.data.SuccessMsg, 'success');
										//$scope.getEditFileDetail();
										//$scope.getEditFileData($scope.currentStartDate, $scope.currentEndDate);
										/*if($scope.processTypeName == "10"){
											$scope.getEditFileData($scope.currentStartDate+"-"+$scope.currentEndDate);
										}*/
										$window.location.href 	= 	BASE_URL+'fin/pricinggrid/upload';
									} else {
										customerAlertMessageBootbox('Error Message', response.data.ErrorMsg, 'error');
									}
								},
								function myError(response)
								{
									customerAlertMessageBootbox('Error Message', response.data.ErrorMsg, 'error');				
								});
							}
						});		
					}
				});
			}
		}
    }
	
	//$scope.downloadPricingList = function(startdate, enddate) {
	$scope.downloadPricingList = function() {
		var customerId  =   $scope.customerName;
		var customerDivisionId  =   $scope.customerDivisionName;
		var currentSelectedDateRangeValue  =   $scope.currentSelectedDateRangeValue;
		var processTypeId  =   $scope.processTypeName;
		if(customerId !=  '' && customerDivisionId !=  '' && currentSelectedDateRangeValue != '' && processTypeId != ''){
			var splitDate = currentSelectedDateRangeValue.split("-");
			var startdate = splitDate[0];
			var enddate = splitDate[1];
			
			var win = window.open(BASE_URL+'fin/pricinggrid/pricing/download/'+$scope.customerId+"/"+$scope.customerDivisionId+"/"+$scope.processTypeName+"/"+startdate+"/"+enddate, '_blank');
			win.focus();
		}
	}
	
	$scope.approvalPricingList = function(btnType) {
		$scope.updatePricingGrid(btnType);
	}	
	
	$scope.enableCheckBox = function (index) {
        var enableCheckBox = $scope.editFileDetails.serviceItemRowData[index].checkBoxChecked;

        if (enableCheckBox == false) {
			//console.log($scope.editFileDetails.serviceItemRowData[index].enableRow);console.log(1);console.log($scope.	editFileDetails.serviceItemRowData[index].enableRow);
            $scope.editFileDetails.serviceItemRowData[index].enableRow = false;
        } else {
			//console.log($scope.editFileDetails.serviceItemRowData[index].enableRow);console.log(2);console.log($scope.editFileDetails.serviceItemRowData[index].enableRow);
            $scope.editFileDetails.serviceItemRowData[index].enableRow = true;
        }
        

    };
	
	$scope.hidemsg 			=	function()
	{
		$scope.Msgsuccess 	=	false;
	};
	
	//session msg auto hide
	$timeout(function() 
	{
		$scope.SessionMsg 		= 	false;
    }, 3000);
	
	//$scope.getEditFileData = function (startdate, enddate) {
	$scope.getEditFileData = function (startEntDate) {
		if(startEntDate){
			$scope.currentSelectedDateRangeValue = startEntDate;
			var splitDate = startEntDate.split("-");
			var startdate = splitDate[0];
			var enddate = splitDate[1];
			$scope.formField.startDate = timeConverter(startdate);
			$scope.formField.endDate = timeConverter(enddate);			
			//$('#effectiveStartDate').datepicker('setDate', new Date($scope.formField.startDate));
			//$('#effectiveEndDate').datepicker('setDate', new Date($scope.formField.endDate));
			
			$scope.currentStartDate = startdate;
			$scope.currentEndDate = enddate;
			$scope.showEditFileDetailsDiv = false;
			var customerId  =   $scope.customerName;
			var customerDivisionId  =   $scope.customerDivisionName;
			var processTypeId  =   $scope.processTypeName;
			if(customerId !=  '' && customerDivisionId !=  '' && processTypeId !=  ''){
				$scope.commonLoader = true;
				$scope.editFileDetails = 	[];
				$http.get(BASE_URL+"fin/pricinggrid/getEditFileData/"+$scope.customerId+"/"+$scope.customerDivisionId+"/"+$scope.processTypeName+"/"+startdate+"/"+enddate) .then(function mySuccess(response) 
				{
					//if(response.data.msg == "success") {
					if(response.status != 200)
					{
						$scope.commonLoader = false;
						//showNotify('Kindly reload page error ocured.'  , 'danger' );
						customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');
						$scope.showEditFileDetailsDiv = false;
						$scope.showUploadLabel = false;
						$scope.showDownloadLabel = false;
						$scope.showApprovalLabel = false;
					}else{
						$scope.commonLoader = false;
						$scope.editFileDetails 	=   response.data.data;
						
						$scope.showDownloadLabel = true;
						$scope.showEditFileDetailsDiv = true;
						/*if($scope.processTypeName == "10"){
							$scope.showUploadBtn = true;
							$scope.showDownloadBtn = true;
							$scope.showApprovalBtn = false;
						}else{
							$scope.showApprovalBtn = true;
							$scope.showUploadBtn = false;
							$scope.showDownloadBtn = false;
						}*/	
						if($scope.processTypeName == "1010"){
							$scope.showApprovalBtn = true;
							$scope.showUploadBtn = false;
							$scope.showDownloadBtn = false;							
						}else{
							$scope.showUploadBtn = true;
							$scope.showDownloadBtn = true;
							$scope.showApprovalBtn = false;
						}
					}
					//console.log($scope.editFileDetails.variousPricingList);
					//$scope.serviceItemRowData 	=   $scope.editFileDetails.serviceItemRowData;console.log($scope.serviceItemRowData);
					$scope.scrollMoveToTop();
				}, 
				function myError(response) 
				{
					$scope.showDownloadLabel = false;
					$scope.showEditFileDetailsDiv = false;
					$scope.showUploadBtn = false;
					$scope.showDownloadBtn = false;
					$scope.showApprovalBtn = false;				
					//showNotify('Kindly reload page error ocured.'  , 'danger' );
					customerAlertMessageBootbox('Error Message', 'Please try again later.', 'error');/*An error occurred, Please try again later.*/
					$scope.scrollMoveToTop();
				});		
			}
		}else{
			$scope.showDownloadLabel = false;
			$scope.showEditFileDetailsDiv = false;
			$scope.showUploadBtn = false;
			$scope.showDownloadBtn = false;
			$scope.showApprovalBtn = false;	
			$scope.scrollMoveToTop();
		}
	}
	
	if($scope.customerName !=  '' && $scope.customerDivisionName !=  '' && $scope.processTypeName !=  '' && $scope.dateRangeDetails !=  ''){
		$scope.commonLoader = true;
		$timeout(function() 
		{
			$scope.getEditFileData($scope.dateRangeDetails);
		}, 1000);
		
	}
	
	$scope.scrollMoveToTop = function () {
		  
	}
	
});

//only-numbers
	ngApp.directive('onlyNumbers', function () {
    return  {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
				var $input = $(this);  
                var value = $input.val();
				var RE = /^\d*\.?\d{0,2}$/;
				//var RE = /^[0-9]+\.?[0-9]*$/;
				//console.log(value);
                if(event.shiftKey){event.preventDefault(); return false;}
                //console.log(event.which);
                if ([8, 13, 27, 37, 38, 39, 40, 190, 110, 46].indexOf(event.which) > -1) {
                    // backspace, enter, escape, arrows, dot, dot, delete
					return true;
					// if (RE.test(value)){
						// return true;
					// }else{
						// return false;
					// }
                } else if (event.which >= 48 && event.which <= 57) {
                    // numbers 0 to 9
                    return true;
					// if (RE.test(value)){
						// return true;
					// }else{
						// return false;
					// }
                } else if (event.which >= 96 && event.which <= 105) {
                    // numpad number
                    return true;
					// if (RE.test(value)){
						// return true;
					// }else{
						// return false;
					// }
                } //else if (RE.test(value)){
					//return true;
				//}
                // else if ([110, 190].indexOf(event.which) > -1) {
                //     // dot and numpad dot
                //     return true;
                // }
                else {
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});