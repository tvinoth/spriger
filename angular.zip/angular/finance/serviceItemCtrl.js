/*
 *  invoice Master Controller
 */

ngApp.controller('serviceItemMasterController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

})
        .controller('serviceItemController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

            $scope.commonLoader = true;

            $scope.commonLoaderEnable = $interval(function ()
            {
                $scope.commonLoader = false;
                $interval.cancel($scope.commonLoaderEnable);
            }, 500);

            $scope.addLineItem = [];
            $scope.lineItemTypes = [{value: 0, name: "Flat Amount"}, {value: 1, name: "Rate Field"}];

            $scope.loadDefaultValues = function () {
                $scope.addLineItem.serviceItemId = ''; // using for update line item
                $scope.addLineItem.serviceGroup = '1';
                $scope.addLineItem.itemName = '';
                $scope.addLineItem.itemType = 0; // flat amount
                $scope.addLineItem.accountCode = '';

                $scope.addLineItem.client = '10885';
                $scope.addLineItem.unitType = '1';
                $scope.addLineItem.currency = '1';
                $scope.addLineItem.price = '';


                $("#serviceGroup").val('1').trigger("chosen:updated");
                $("#client").val('10885').trigger("chosen:updated");
                $("#unitType").val('1').trigger("chosen:updated");
                $("#currency").val('1').trigger("chosen:updated");

                $scope.enableUpdateBtn = false;

            }
            $scope.loadDefaultValues();

            $scope.createLineItem = function () {
                if ($scope.addLineItemForm.$invalid == false) {
                    $scope.commonLoader = true;
                    var postData = {};
                    angular.extend(postData, $scope.addLineItem);

                    $http.post(BASE_URL + "fin/lineitem/ajaxAddLineItem", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item successfuly created.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/additional';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }

            // show Additional LineItem
            $scope.getServiceItems = function ()
            {
                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/lineitem/getAdditionalServiceItems",
                            type: 'POST'
                        })
                        .withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('SECTION_NAME').withTitle('Service Group'),
                    DTColumnBuilder.newColumn('ITEM_NAME').withTitle('Line Item'),
                    DTColumnBuilder.newColumn('ACCOUNT_CODE').withTitle('Account Code'),
                    DTColumnBuilder.newColumn('RATE_FIELD').withTitle('Item type'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };
            function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                //edit
                $('td .editLineItem', nRow).unbind('click');
                $('td .editLineItem', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.editLineItem(aData.SERVICE_ITEM_ID);
                    });
                });

                //delete
                $('td .deleteLineItem', nRow).unbind('click');
                $('td .deleteLineItem', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.deleteLineItem(aData.SERVICE_ITEM_ID);
                    });
                });

                return nRow;
            }
            $scope.getServiceItems();
            //

            // Edit -  Additional LineItem
            $scope.editLineItem = function (SERVICE_ITEM_ID)
            {
                $scope.commonLoader = true;
                $http.get(BASE_URL + "fin/lineitem/getServiceItemDetails/" + SERVICE_ITEM_ID).then(function mySuccess(response) {
                    if (response.data.status == 1) {
                        $scope.enableUpdateBtn = true;
                        var itemData = response.data.data;

                        $scope.addLineItem.serviceItemId = itemData.SERVICE_ITEM_ID;
                        $scope.addLineItem.serviceGroup = itemData.SERVICE_GROUP_ID;
                        $scope.addLineItem.itemName = itemData.ITEM_NAME;
                        $scope.addLineItem.itemType = itemData.RATE_FIELD;
                        $scope.addLineItem.accountCode = itemData.ACCOUNT_CODE;

                        if (itemData.get_item_rate) {
                            $scope.addLineItem.price = itemData.get_item_rate.RATE;
                        } else {
                            $scope.addLineItem.price = '';
                        }
                        $("#serviceGroup").val(itemData.SERVICE_GROUP_ID).trigger("chosen:updated");



                        if (itemData.RATE_FIELD == 1) {

                            $scope.addLineItem.client = itemData.get_item_rate.CUSTOMER_ID;
                            $scope.addLineItem.unitType = itemData.get_item_rate.UNIT_ENUM_ID;
                            $scope.addLineItem.currency = itemData.get_item_rate.CURRENCY_ID;
//                            $scope.addLineItem.price = itemData.get_item_rate.RATE;

                            $("#client").val(itemData.get_item_rate.CUSTOMER_ID).trigger("chosen:updated");
                            $("#unitType").val(itemData.get_item_rate.UNIT_ENUM_ID).trigger("chosen:updated");
                            $("#currency").val(itemData.get_item_rate.CURRENCY_ID).trigger("chosen:updated");

                        } else {
                            $scope.addLineItem.client = '';
                            $scope.addLineItem.unitType = '';
                            $scope.addLineItem.currency = '';
//                            $scope.addLineItem.price = '';
                        }
                        $scope.commonLoader = false;

                    } else if (response.data.status == 2) {
                        $scope.loadDefaultValues();
                        $scope.commonLoader = false;
                    }

                }, function myError(response) {
                    $scope.loadDefaultValues();
                    $scope.commonLoader = false;
                });
            };

            $scope.updateCancel = function () {
                $scope.loadDefaultValues();
            }

            //update line item
            $scope.updateLineItem = function () {
                if ($scope.addLineItemForm.$invalid == false) {
                    $scope.commonLoader = true;
                    var postData = {};
                    angular.extend(postData, $scope.addLineItem);

                    $http.post(BASE_URL + "fin/lineitem/ajaxUpdateLineItem", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item updated successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/additional';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }

            //delete line item
            $scope.deleteLineItem = function (SERVICE_ITEM_ID) {
                if (SERVICE_ITEM_ID > 0) {
                    $scope.commonLoader = true;
                    var postData = {'serviceItemId': SERVICE_ITEM_ID};

                    $http.post(BASE_URL + "fin/lineitem/ajaxDeleteLineItem", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item Deleted successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/additional';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }



        })
        .controller('stageProcesMapController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

            $scope.commonLoader = true;

            $scope.commonLoaderEnable = $interval(function ()
            {
                $scope.commonLoader = false;
                $interval.cancel($scope.commonLoaderEnable);
            }, 500);

            $scope.itemMap = [];

            $scope.loadDefaultValues = function () {

                $scope.itemMap.stageMapId = '';
                $scope.itemMap.transType = '';

                $scope.itemMap.client = '10885';
                $scope.itemMap.serviceItem = '18';
                $scope.itemMap.round = '104';
                $scope.itemMap.stage = '99';

                $("#client").val('10885').trigger("chosen:updated");
                $("#serviceItem").val('18').trigger("chosen:updated");
                $("#round").val('104').trigger("chosen:updated");
                $("#stage").val('99').trigger("chosen:updated");
                $scope.enableUpdateBtn = false;

            }
            $scope.loadDefaultValues();

            $scope.createLineItemMap = function () {
                if ($scope.lineItemMapForm.$invalid == false) {
                    $scope.commonLoader = true;
                    $scope.itemMap.transType = 1;
                    var postData = {};
                    angular.extend(postData, $scope.itemMap);

                    $http.post(BASE_URL + "fin/lineitem/ajaxAddUpdateStageMap", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item successfuly created.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/stage-process/mapping';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }

            // show Additional LineItem
            $scope.getServiceItemMap = function ()
            {
                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/lineitem/getStageProcessMapping",
                            type: 'POST'
                        })
                        .withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('SECTION_NAME').withTitle('Service Group'),
                    DTColumnBuilder.newColumn('ITEM_NAME').withTitle('Line Item'),
                    DTColumnBuilder.newColumn('ROUND_NAME').withTitle('Stage'),
                    DTColumnBuilder.newColumn('STAGE_NAME').withTitle('Process'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };
            function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                //edit
                $('td .editMapping', nRow).unbind('click');
                $('td .editMapping', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.editMapping(aData);
                    });
                });

                //delete
                $('td .deleteMapping', nRow).unbind('click');
                $('td .deleteMapping', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.deleteLineItemMap(aData.STAGE_MAPPING_ID);
                    });
                });

                return nRow;
            }
            $scope.getServiceItemMap();
            //

            // Edit -  Additional LineItem
            $scope.editMapping = function (aData)
            {
                $scope.loadDefaultValues();

                $scope.commonLoader = true;
                $scope.enableUpdateBtn = true;

                $scope.itemMap.stageMapId = aData.STAGE_MAPPING_ID;
                $scope.itemMap.client = aData.CUSTOMER_ID;
                $scope.itemMap.serviceItem = aData.SERVICE_ITEM_ID;
                $scope.itemMap.round = aData.ROUND_ID;
                $scope.itemMap.stage = aData.STAGE_ID;
                $("#client").val(aData.CUSTOMER_ID).trigger("chosen:updated");
                $("#serviceItem").val(aData.SERVICE_ITEM_ID).trigger("chosen:updated");
                $("#round").val(aData.ROUND_ID).trigger("chosen:updated");
                $("#stage").val(aData.STAGE_ID).trigger("chosen:updated");
                $scope.commonLoader = false;

            };

            $scope.updateCancel = function () {
                $scope.loadDefaultValues();
            }

            //update line item
            $scope.updateLineItemMap = function () {
                if ($scope.lineItemMapForm.$invalid == false) {
                    $scope.commonLoader = true;
                    $scope.itemMap.transType = 2;

                    var postData = {};
                    angular.extend(postData, $scope.itemMap);

                    $http.post(BASE_URL + "fin/lineitem/ajaxAddUpdateStageMap", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item updated successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/stage-process/mapping';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }

            //delete line item
            $scope.deleteLineItemMap = function (STAGE_MAPPING_ID) {
                if (STAGE_MAPPING_ID > 0) {
                    $scope.commonLoader = true;

                    var postData = {'stageMapId': STAGE_MAPPING_ID, "transType": 3};

                    $http.post(BASE_URL + "fin/lineitem/ajaxAddUpdateStageMap", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item Deleted successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/stage-process/mapping';
                            }, 1500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Line Item', 'Please fill the required fields.', 'error');
                }
            }



        })
        .controller('serviceItemTemplateController', function ($scope, $http, $window, $interval, $timeout, DTOptionsBuilder, DTColumnBuilder) {

            $scope.commonLoader = true;

            $scope.commonLoaderEnable = $interval(function ()
            {
                $scope.commonLoader = false;
                $interval.cancel($scope.commonLoaderEnable);
            }, 500);

            $scope.temp = [];

            $scope.masterDetails = [];
            $scope.serviceItemList = [];

            $scope.loadDefaultValues = function () {
                $scope.temp.templateItem = [];
                $scope.temp.templateId = '';
                $scope.temp.templateName = '';
                $scope.teamList = [{'TEAM_ID': '', 'TEAM_NAME': 'Select'}];
                $scope.temp.team = '';
                $scope.temp.teamName = '';
                $scope.enableUpdateBtn = false;
            }
            $scope.loadDefaultValues();

            $scope.showCreateModal = function () {
                $scope.enableUpdateBtn = false;
                $scope.serviceItemList = $scope.masterDetails.lineItemList;
                $scope.temp.team = '';
                $scope.temp.templateItem = [];
                $('#templateModal').modal('show');
            }

            $scope.createTemplate = function () {
                if ($scope.templateForm.$invalid == false) {
                    $scope.commonLoader = true;

                    var postData = {};
                    angular.extend(postData, $scope.temp);

                    $http.post(BASE_URL + "fin/lineitem/template/ajaxAddTemplate", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Line Item successfuly created.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/template';
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Template', 'Please fill the required fields.', 'error');
                }
            }

            // show Additional LineItem
            $scope.getTemplate = function ()
            {
                $scope.dtOptions = DTOptionsBuilder.newOptions()
                        .withOption('ajax', {
                            url: BASE_URL + "fin/lineitem/getTemplate",
                            type: 'POST'
                        })
                        .withOption('rowCallback', rowCallback)
                        .withOption('stateSave', false) //???????????
                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                        .withOption('processing', true) // required
                        .withOption('serverSide', true)// required
                        .withOption('paging', true)// required
                        .withPaginationType('full_numbers')
                        .withDisplayLength(10)
                        .withOption('order', [1, 'asc']);
                $scope.dtColumns = [
                    DTColumnBuilder.newColumn('TEMPLATE_NAME').withTitle('Template Name'),
                    DTColumnBuilder.newColumn('TEAM_NAME').withTitle('Team Name'),
                    DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created At'),
                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                ];
                $scope.dtInstance = {};
            };
            function rowCallback(nRow, aData, iDisplayIndex, iDisplayIndexFull) {

                //edit
                $('td .editTemplate', nRow).unbind('click');
                $('td .editTemplate', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.editTemplate(aData);
                    });
                });

                //delete
                $('td .deleteTemplate', nRow).unbind('click');
                $('td .deleteTemplate', nRow).bind('click', function ()
                {
                    $scope.$apply(function () {
                        $scope.deleteTemplate(aData.QUOTE_TEMPLATE_ID);
                    });
                });

                return nRow;
            }
            $scope.getTemplate();
            //

            // Edit -  Additional LineItem
            $scope.editTemplate = function (aData)
            {
                $scope.commonLoader = true;
                $scope.loadDefaultValues();

                $scope.temp.templateId = aData.QUOTE_TEMPLATE_ID;
                $scope.temp.templateName = aData.TEMPLATE_NAME;
                $scope.temp.teamName = aData.TEAM_NAME;

                $scope.serviceItemList = $scope.masterDetails.lineItemList;

                angular.forEach($scope.masterDetails.teamList, function (value, key) {
                    $scope.teamList.push(value);
                });

                $scope.temp.templateItem = [];

                var existingItemID = [];
                var QUOTE_TEMPLATE_ITEM = aData.QUOTE_TEMPLATE_ITEM;
                angular.forEach(QUOTE_TEMPLATE_ITEM, function (value, key) {
                    $scope.temp.templateItem.push(value);
                    existingItemID.push(value.SERVICE_ITEM_ID);
                });
                
                $scope.loadNewItemList = [];
                $scope.loadNewItemList = $scope.serviceItemList;
                //remove selected items
                angular.forEach($scope.serviceItemList, function (value, key) {
                    if (existingItemID.indexOf(value.SERVICE_ITEM_ID) !== -1) {
                        var index = $scope.loadNewItemList.indexOf(value);
                        $scope.loadNewItemList.splice(index, 1);
                    }
                });
                $scope.serviceItemList = $scope.loadNewItemList;
                
                

                $('#templateModal').modal('show');


                $scope.enableUpdateBtn = true;


                $scope.commonLoader = false;

            };

            $scope.updateCancel = function () {
                $scope.enableUpdateBtn = false;
                $scope.loadDefaultValues();
            }

            //update line item
            $scope.updateTemplate = function () {
                if ($scope.temp.templateId > 0) {
                    $scope.commonLoader = true;

                    var postData = {};
                    angular.extend(postData, $scope.temp);

                    $http.post(BASE_URL + "fin/lineitem/template/ajaxUpdateTemplate", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Template updated successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/template';
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Template', 'Please fill the required fields.', 'error');
                }
            }

            //delete line item
            $scope.deleteTemplate = function (QUOTE_TEMPLATE_ID) {
                if (QUOTE_TEMPLATE_ID > 0) {
                    $scope.commonLoader = true;

                    var postData = {'templateID': QUOTE_TEMPLATE_ID};

                    $http.post(BASE_URL + "fin/lineitem/template/ajaxDeleteTemplate", postData).then(function mySuccess(response) {
                        if (response.data.status == 1) {

                            showMessage('Invoice', 'Template Deleted successfuly.', 'success');
                            $timeout(function () {
                                hideMessage();
                                $window.location.href = BASE_URL + 'fin/lineitem/template';
                            }, 500);

                        } else if (response.data.status == 2) {
                            $scope.commonLoader = false;
                        }

                    }, function myError(response) {
                        $scope.commonLoader = false;
                    });
                } else {
                    showMessage('Template', 'Please fill the required fields.', 'error');
                }
            }

            // get all service items
            $scope.getAllLineItems = function () {
                var postData = {};
                $http.post(BASE_URL + "fin/lineitem/template/getAllLineItems", postData).then(function mySuccess(response) {
                    if (response.data.status == 1) {

                        $scope.masterDetails = response.data.data;
                        $scope.serviceItemList = $scope.masterDetails.lineItemList;
                        angular.forEach($scope.masterDetails.teamList, function (value, key) {
                            $scope.teamList.push(value);
                        });

                    } else if (response.data.status == 2) {
                        alert('No result found');
                        $scope.commonLoader = false;
                    }

                }, function myError(response) {
                    alert('Please try again');
                    $scope.commonLoader = false;
                });

            }
            $scope.getAllLineItems();


            //
            $scope.addNewItem = function (item)
            {
                var index = $scope.serviceItemList.indexOf(item);
                $scope.serviceItemList.splice(index, 1);
                $scope.temp.templateItem.push(item);
            }

            $scope.removeAddedItem = function (item)
            {
                var index = $scope.temp.templateItem.indexOf(item);
                $scope.temp.templateItem.splice(index, 1);
                $scope.serviceItemList.push(item);
            }

        });
//only-numbers
ngApp.directive('onlyNumbers', function () {
    return  {
        restrict: 'A',
        link: function (scope, elm, attrs, ctrl) {
            elm.on('keydown', function (event) {
                var $input = $(this);
                var value = $input.val();
                var RE = /^\d*\.?\d{0,2}$/;
                //var RE = /^[0-9]+\.?[0-9]*$/;
                //console.log(value);
                if (event.shiftKey) {
                    event.preventDefault();
                    return false;
                }
                //console.log(event.which);
                if ([8, 9, 13, 27, 37, 38, 39, 40, 190, 110, 46].indexOf(event.which) > -1) {
                    // backspace, tab, enter, escape, arrows, dot, dot, delete
                    return true;
                } else if (event.which >= 48 && event.which <= 57) {
                    // numbers 0 to 9
                    return true;
                } else if (event.which >= 96 && event.which <= 105) {
                    // numpad number
                    return true;
                } else {
                    event.preventDefault();
                    return false;
                }
            });
        }
    }
});
