/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */

ngApp.controller('ngController', function ($scope, $filter, $http, $interval, $window, DTOptionsBuilder, DTColumnBuilder)
{
    $scope.userId = 0;
    //$scope.UserDetails = {};
    $scope.menuParent = 'Finance';
    $scope.menuChild = 'Invoice';
    $scope.errorMsg = "";

    $scope.UserDetails = JSON.parse(localStorage.getItem("UserDetails"));
//    $scope.userName = $scope.UserDetails.user_name;
//    $scope.roleName = $scope.UserDetails.role_name;
//    $scope.userId = $scope.UserDetails.user_id;

    /*
     *  Get User Details
     *  This method get the logged in user details from the session.
     */

//    $scope.getUserDetail = function ()
//    {
//        $scope.userName = "";
//        $http.get(BASE_URL + "getUserDetail").then(function mySuccess(response)
//        {
//            if (response.data.status == 1)
//            {
//                $scope.userName = response.data.user_name;
//                $scope.roleName = response.data.role_name;
//                $scope.UserDetails = response.data;
//                console.log($scope.UserDetails);
//            } else {
//                window.location.href = BASE_URL + "?expired";
//            }
//        },
//                function myError(response)
//                {
//                    console.log(response);
//                });
//    };
//    $scope.getUserDetail();


});