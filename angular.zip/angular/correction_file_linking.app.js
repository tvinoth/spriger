/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */

ngApp.controller('latecorrectiondownload', function ( $scope , $http ,$q, $rootScope ,$filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
    
    $scope.noOfAttemptsToCheckIndesign  =   10;
    
    if(isNaN(getUrlParameter(1))){
        $scope.searchrounddownload  =   "";
    }else{
        $scope.searchrounddownload  =   getUrlParameter(1);
    }
    
    $scope.showXMLInModal   =   function(item){     
        var inp             = 	{
                                    jobId       :   item.JOB_ID,
                                    metadataid  :   item.METADATA_ID,
                                    Chapter     :   item.CHAPTER_NO,
                                    bookid      :   item.BOOK_ID,
                                    roundid     :   item.ROUND_ID
                                };
                                    
        $scope.htmlcon      =   "Chapter XML Information";
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
                url         :   API_URL + "getChapterjobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('#xmlContent').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $('#xmlContent').html('<p class="text-center">'+response.errMsg+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    $scope.retryJobsheetCorrectionUpdate 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/CORRECTION/'+params.METADATA_ID;   

       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {      

              $timeout( function(){  
                hideLoader();
                if( response.data.REMARKS == 'Failure' ){
                    showNotify( 'Jobsheet update response is :'+response.data.REMARKS , 'danger' );
                }
                else{
                   showNotify( 'Jobsheet update response is :'+response.data.REMARKS , 'success' );
                }
                
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.REMARKS , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
    $scope.retryJobsheetCorrectionUpload 			= 	function(params){   
          
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();
       
        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/CORRECTION/'+params.METADATA_ID;      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             console.log(response);
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

    };
    
    $scope.showDownloadRemarksview = 	function(params){   
         var printMsg    =   ( params.APFT_REMARKS == null || params.APFT_REMARKS == '' ) ? 'remarks not found..' : params.APFT_REMARKS;
        $('#show-redolog').trigger('click');
        $scope.Msgbox 	=	"Jobsheet Download";
        $('#redofailedlog').html('<p class="text-center">'+printMsg+'</p>');
    };
    
    $scope.sendRedo = function(params){   
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {
            if(result) 
            {
                var inp 	= 	{ jobID: params.JOB_ID};
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success Redo";
                $('#redofailed').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $http({
                                url: BASE_URL + "retrySuccessRedo",
                                method: 'post',
                                data:inp
                         })
                        .success(function(response) {
                                $('#redofailed').html(response);
                        })
                        .error(function(response) {

                        });
            }
        });
    }
    
	$scope.correctionBookId = '';
	$scope.correctionMetadataId = '';
	$scope.correctionChapterNo = '';
	$scope.correctionJobId = '';
	$scope.correctionRoundName = '';
	$scope.correctionRoundId = '';
	$scope.correctionChapterTitle = '';	
	$scope.correctionDefaultChapterList = '';
	$scope.correctionDefaultChapterNo = '';
	$scope.isDisableCorrectionStageId = false;
	$scope.IsVisibleTitleWiseTable = false;
	$scope.IsVisibleChapterWiseTable = false;
	
	$scope.titleOrChapterWiseSelectedChapter = [];
		
    $scope.showManualUploadModal   =   function(item) 
    {  
	console.log( item );
        $scope.correctionBookId = '';
        $scope.correctionMetadataId = '';
        $scope.correctionChapterNo = '';
        $scope.correctionJobId = '';
        $scope.correctionRoundName = '';
        $scope.correctionRoundId = '';
        $scope.correctionChapterTitle = '';
        $scope.isDisableCorrectionStageId = false;
        $scope.IsVisibleTitleWiseTable = false;
        $scope.IsVisibleTitleWiseUploadBtn = false;
        $scope.IsVisibleChapterWiseUploadBtn = false;
        $scope.correctionStageId  = '';
        $scope.correctionProcessList = '';
        $scope.correctionProcessId = '';
        $scope.correctionfolderpath = '';
        $scope.mappingList = '';
        $scope.correctionChapterList = '';
        $scope.correctionChapterNo = '';
        $scope.correctionDefaultChapterList = '';
        $scope.correctionDefaultChapterNo = '';
        $scope.IsVisibleTitleWiseBookReferenceUploadBtn = false;	
        $scope.titleOrChapterWiseSelectedChapter = [];

        $scope.chapterWise = true;
        $scope.titleWise = false;
        if($scope.titleWise){	
            $scope.htmlcon2      =   "Correction File Link";	
        }else if($scope.chapterWise){
            $scope.htmlcon2      =   "Correction File Link - "+item.CHAPTER_NO+"";	
        }else{	
            $scope.htmlcon2      =   "Correction File Link";	
        }

        $scope.submitBtnShow = false;

                var inp = {
                    jobId       :   item.JOB_ID,
                    roundid     :   119 
                };		

                $scope.correctionBookId     = item.BOOK_ID;
                $scope.correctionMetadataId = item.METADATA_ID;			
                $scope.correctionJobId      = item.JOB_ID;
                $scope.correctionRoundName  = 'S600';
                $scope.correctionRoundId    = 119;
                $scope.correctionChapterTitle   =   item.CHAPTER_TITLE;
                $scope.correctionChapterNo      =   item.CHAPTER_NO;
                $scope.correctionDefaultChapterList =   '';
                $scope.correctionDefaultChapterNo   =   item.CHAPTER_NO;
                $('#manualCorrectionFileUploadModal1').trigger('click');

                $http({
                        url         :   API_URL + "qms/GetListStages",
                        method      :   'POST',
                        data        :   inp
                })
                .success(function(data, status, headers, config) 
                {
                    if( status == 200 ){  
                        if(data.length > 0){
                            $scope.correctionStageList2 = data;				

                            for (var key in $scope.correctionStageList2) {
                                if($scope.correctionRoundId === $scope.correctionStageList2[key].StageId){
                                    $scope.correctionStageId = $scope.correctionStageList2[key].StageId;
                                    $scope.isDisableCorrectionStageId = true;
                                }
                            }

                            $http({
                                            url         :   BASE_URL + "getProcessList",
                                            method      :   'POST',
                                            data        :   inp
                                     })
                            .success(function(response, status, headers, config) 
                            {
                                if( status == 200 ){  
                                    if(response.status == 1){

                                        $scope.correctionProcessList2 = response.data;
                                        $scope.correctionProcessId = '';
                                        $scope.correctionfolderOrgPath = response.path;
                                        $scope.loginUserId = response.userid;
                                        $scope.credential = response.credential;
                                        $scope.ftpfilepath = response.ftpfilePath;
                                        $scope.jobId       = response.jobId;

                                        $scope.mappingList = { 
                                                "0": {"id":"ProcessMapping", "desc":"Process"},
                                                "1": {"id":"BookReference", "desc":"Book Reference"},
                                                "2": {"id":"ChapterReference", "desc":"Chapter Reference"},
                                                "3": {"id":"SetProcess", "desc":"Set Process"}
                                        };

                                    }else{
                                        hideLoader();
                                        showMessage('Status', response.errMsg, 'error');
                                    }              
                                }

                            })
                            .error(function(response){
                                hideLoader();
                                showMessage('Status', "Please try again later.", 'error');
                            });
                        }                
                    }

                })
                .error(function(response) 
                {
                        hideLoader();
                        showMessage('Status', "Please try again later.", 'error');
                });		
		
    }
	
	$scope.CheckUncheckAll = function (event) {		
        for (var i = 0; i < $scope.correctionChapterList.length; i++) {			
            $scope.correctionChapterList[i].Selected = $scope.IsAllChecked;
        }
    };
	
	$scope.CheckUncheckHeader = function (event) {
        $scope.IsAllChecked = true;		
        for (var i = 0; i < $scope.correctionChapterList.length; i++) {			
            if (!$scope.correctionChapterList[i].Selected) {
                $scope.IsAllChecked = false;
                break;
            }
        };		
    };    
	
	$scope.changeCorrectionProcess = function (itm){
		if(itm && $scope.correctionProcessList.length > 0){
			for (var i = 0; i < $scope.correctionProcessList.length; i++) {
				if($scope.correctionProcessList[i].StageId == $scope.correctionProcessId){
					$scope.correctionProcessName = $scope.correctionProcessList[i].StageDescription;
					$scope.correctionWorkflowId = $scope.correctionProcessList[i].WORKFLOW_ID;
					$scope.correctionWorkflowType = $scope.correctionProcessList[i].WORKFLOW_TYPE;
					$scope.correctionWorkflowMasterId = $scope.correctionProcessList[i].WORKFLOW_MASTER_ID;
					
					/* $scope.correctionSrcPath = $scope.correctionProcessList[i].srcPath;
					$scope.correctionWrkPath = $scope.correctionProcessList[i].wrkPath;
					$scope.correctionDestPath = $scope.correctionProcessList[i].destPath; */
					
				}
			}
		}else{
			$scope.correctionMappingID = '';
			$scope.correctionProcessName = '';
			$scope.correctionWorkflowId = '';
			$scope.correctionWorkflowType = '';
			$scope.correctionWorkflowMasterId = '';
			
			$scope.enableOrDisableUploadBtn(false, '', '', false, false, false);
			/* $scope.IsVisibleChapterWiseUploadBtn = false;				
			$scope.correctionChapterList = '';
			$scope.correctionChapterNo = '';
					
			$scope.IsVisibleTitleWiseTable = false;
			$scope.IsVisibleTitleWiseUploadBtn = false;
			$scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
		}
	}
	
	$scope.listAllChapters = function (){
		if($scope.titleWise){
			
			var inp = {
				jobId       :   $scope.correctionJobId,
				/* metadataid  :   $scope.correctionMetadataId,
				chapterno     :   $scope.correctionChapterNo,
				bookid      :   $scope.correctionBookId, */
				roundid     :   $scope.correctionRoundId,
				/* roundname   :   $scope.correctionRoundName,
				chaptertitle   :   $scope.correctionChapterTitle,
				chapterWise   :   $scope.chapterWise,
				titleWise   :   $scope.titleWise */
			};
			
			$http({
				url         :   BASE_URL + "getAllChapters",
				method      :   'POST',
				data        :   inp
			})
			.success(function(response, status, headers, config) 
			{
				if( status == 200 ){  
					if(response.status == 1){
						$scope.enableOrDisableUploadBtn(false, response.data, '', true, true, false);
						/* $scope.IsVisibleChapterWiseUploadBtn = false;
						$scope.correctionChapterList = response.data;
						$scope.correctionChapterNo = '';
						$scope.IsVisibleTitleWiseTable = true;
						$scope.IsVisibleTitleWiseUploadBtn = true;
						$scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
						/* $scope.CheckUncheckHeader(); */
					}else{
						hideLoader();
						showMessage('Status', response.errMsg, 'error');
					}              
				}
								
			})
			.error(function(response) 
			{
				hideLoader();
				showMessage('Status', "Please try again later.", 'error');
			});
		}
	}
	
	$scope.changeCorrectionMapping = function (itm){
		if(itm){	

	
			if($scope.titleWise){
				if(itm == "BookReference"){
					$scope.enableOrDisableUploadBtn(false, '', '', false, false, true);
					/* $scope.IsVisibleChapterWiseUploadBtn = false;	
					$scope.correctionChapterList = '';
					$scope.correctionChapterNo = '';
					
					$scope.IsVisibleTitleWiseTable = false;
					$scope.IsVisibleTitleWiseUploadBtn = false;
					$scope.IsVisibleTitleWiseBookReferenceUploadBtn = true;	 */				
					
				}else if(itm == "ProcessMapping" || itm == "ChapterReference"){
					$scope.enableOrDisableUploadBtn(false, '', '', true, true, false);
					/* $scope.IsVisibleChapterWiseUploadBtn = false;
					$scope.correctionChapterList = '';
					$scope.correctionChapterNo = '';						
						
					$scope.IsVisibleTitleWiseTable = true;
					$scope.IsVisibleTitleWiseUploadBtn = true;
					$scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */	
					$scope.listAllChapters();
				}else if(itm == "SetProcess"){
					
					$scope.IsVisibleTitleWiseUploadBtn = false;
					scope.submitBtnShow = true;	
				}
			}else if($scope.chapterWise){

				 if(itm == "SetProcess"){
					$scope.IsVisibleTitleWiseUploadBtn = false;
					$scope.submitBtnShow = true;	
				}else{
				$scope.enableOrDisableUploadBtn(true, $scope.correctionDefaultChapterList, $scope.correctionDefaultChapterNo, false, false, false);
				}
				/* $scope.IsVisibleChapterWiseUploadBtn = true;				
				$scope.correctionChapterList = '';
				$scope.correctionChapterNo = '';
					
				$scope.IsVisibleTitleWiseTable = false;
				$scope.IsVisibleTitleWiseUploadBtn = false;
				$scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */	
			}
		}else{
			$scope.enableOrDisableUploadBtn(false, '', '', false, false, false);
			/* $scope.IsVisibleChapterWiseUploadBtn = false;				
			$scope.correctionChapterList = '';
			$scope.correctionChapterNo = '';
					
			$scope.IsVisibleTitleWiseTable = false;
			$scope.IsVisibleTitleWiseUploadBtn = false;
			$scope.IsVisibleTitleWiseBookReferenceUploadBtn = false; */
		}
	}

	$scope.enableOrDisableUploadBtn = function (a, b, c, d, e, f){
		$scope.IsVisibleChapterWiseUploadBtn = a;				
		$scope.correctionChapterList = b;
		$scope.correctionChapterNo = c;
					
		$scope.IsVisibleTitleWiseTable = d;
		$scope.IsVisibleTitleWiseUploadBtn = e;
		$scope.IsVisibleTitleWiseBookReferenceUploadBtn = f;
	}
	
	$scope.uploadCorrectionFile = function (currentBtn){
          //  console.log($scope.ftpfilepath);
            
		var result = true;
        showLoader('Please wait open folder inprogress..');
        if( result ){
			if(isEmpty($scope.correctionStageId)){
				hideLoader();
				showNotify('Please choose any one stage.', 'danger');	
			}else if (isEmpty($scope.correctionProcessId)) {
				hideLoader();
				showNotify('Please choose any one process.', 'danger');
			} else if (isEmpty($scope.correctionMappingID)) {
				hideLoader();
				showNotify('Please choose any one mapping.', 'danger');
			}else{  
				
				//var method = "doOpenDriveServer";/* "openLocalDrive";//183.140 */
				var method = "doOpenDriveServer";/* "openLocalDrive";//183.140 */
				var getPath = $scope.correctionfolderOrgPath;
                                
				if($scope.titleWise){					
					if($scope.correctionMappingID === "ProcessMapping"){
						var currentChapterNo = currentBtn.corChapter.CHAPTER_NO;
						var currentMetaDataId = currentBtn.corChapter.METADATA_ID;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+currentChapterNo);
					}else if($scope.correctionMappingID === "BookReference"){
						var currentChapterNo = $scope.correctionBookId;
						var currentMetaDataId = $scope.correctionJobId;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/REFERENCE");
					}else if($scope.correctionMappingID === "ChapterReference"){
						var currentChapterNo = currentBtn.corChapter.CHAPTER_NO;
						var currentMetaDataId = currentBtn.corChapter.METADATA_ID;
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+currentChapterNo+"/REFERENCE");
					}	
					$scope.titleOrChapterWiseSelectedChapter[currentMetaDataId] = currentChapterNo;
					
				}else if($scope.chapterWise){
					var currentChapterNo = $scope.correctionChapterNo;
					var currentMetaDataId = $scope.correctionMetadataId;
					if($scope.correctionMappingID === "ProcessMapping"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+$scope.correctionChapterNo);
					}else if($scope.correctionMappingID === "BookReference"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/REFERENCE");
					}else if($scope.correctionMappingID === "ChapterReference"){
						var openFolderPath = getPath.replace("<referenceTag>", $scope.loginUserId+"/"+$scope.correctionBookId+"/"+$scope.correctionChapterNo+"/REFERENCE");
					}
					$scope.titleOrChapterWiseSelectedChapter[currentMetaDataId] = currentChapterNo;
				}
			
                                var openPath = openFolderPath;
				$scope.correctionOpenFolderPath = openFolderPath+'/<>'+$scope.credential;

				var inp = {
					/* currentMachineIP : '172.24.135.211', */
					filePath : $scope.correctionOpenFolderPath,
					methodName : method  ,
					processname  :   'checkout',
					replacePathSlash  :   'true'
				};
                                
                               var workresponse =  $scope.createWorkDirectory($scope.ftpfilepath,openPath,$scope.jobId);
                                workresponse.then(function(rest) 
                                {    
                                    $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                                            if(response.data[0].rmiId > 0) {
                                                    var attempt = 5;
                                                    $scope.checkFileHandlerStatus(response.data[0].rmiId, attempt);						
                                            } else {
                                                    hideLoader();
                                                    showNotify( 'Having problem in insert data.', 'danger');
                                            }                    
                                    },function myError(response) {
                                        showLoader( 'Oops! Try again after sometimes.' );
                                    }); 
                                })
                                .catch(function(fallback) {

                                }); 
            }       
        }
		
	}
        
        $scope.createWorkDirectory = function(ftpPath, openPath, jobId){
            var inp = {ftppath : ftpPath,openpath : openPath,jobID : jobId};//currentMachineIP : '172.24.183.140',
           var deferred    =   $q.defer();
            $http.post(BASE_URL+"correctionworkPath", inp).then(function mySuccess(response) {
                    if(response.data.status == 1){
                        deferred.resolve(response);
                        
                    }else{
                          deferred.reject(response);
                      
                    }
                 },
		function myError(response) {
			deferred.reject(response);					
		});
                
                 return deferred.promise;
        }
	
	$scope.checkFileHandlerStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};//currentMachineIP : '172.24.183.140',
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
			$scope.IsRunning = response.data[0].is_running;   // status, remarks
			if(response.data[0].status == 1) {
				if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
					if(opt == "Fonts") {
						hideLoader();
						showNotify('Font Downloaded successfully.'  , 'success' );
					} else if(opt == "InDesign") {
						hideLoader();
						$scope.checkoutBtn = "Open File";
						showNotify('Page(s) checked out successfully.'  , 'success' );
						//$scope.checkFileStatus();
						//$scope.checkoutProcess();
					} else {
						hideLoader();
						showNotify('Folder Opened Successfully.'  , 'success' );
						$scope.submitBtnShow = true;						
					}
				} else {    
					hideLoader();
					showNotify(response.data[0].remarks  , 'danger' );
				}
			} else {
				attempt++;
				if(attempt < $scope.noOfAttemptsToCheckIndesign) {
					$timeout( function(){ $scope.checkFileHandlerStatus(rmiId, attempt, opt); }, 7000 );
				} else {
					hideLoader();
					showNotify("File handler is not running. Please check."  , 'danger' );
				}
			}
		},
		function myError(response) {
			showLoader( 'Oops! Try again after sometimes.' );						
		});		
        
    };  
	
	function isEmpty(value) {
		/*for(var key in obj) {
			if(obj.hasOwnProperty(key))
				return false;
		}
		return true;*/
		return (value == null || value.length === 0  || value === '');
	}
	
	$scope.submitCorrectionFile = function(btnType) {
		showLoader();
		if(isEmpty($scope.correctionStageId)){
			hideLoader();
			showNotify('Please choose any one stage.', 'danger');	
		}else if (isEmpty($scope.correctionProcessId)) {
            hideLoader();
			showNotify('Please choose any one process.', 'danger');
        } else if (isEmpty($scope.correctionMappingID)) {
			hideLoader();
			showNotify('Please choose any one mapping.', 'danger');
		}else{
			var formData = new FormData();
			if($scope.chapterWise){
				//option field only for chapter wise
				formData.append('correctionMetadataId', $scope.correctionMetadataId);
				formData.append('correctionChapterNo', $scope.correctionChapterNo);	
				formData.append('correctionChapterTitle', $scope.correctionChapterTitle);				
			}

			formData.append('correctionRoundId', $scope.correctionStageId);
			//formData.append('correctionRoundId', $scope.correctionRoundId);
			formData.append('correctionRoundName', $scope.correctionRoundName);

			formData.append('correctionStageId', $scope.correctionProcessId);	
			formData.append('correctionStageName', $scope.correctionProcessName);
			formData.append('correctionBookId', $scope.correctionBookId);
			formData.append('correctionJobId', $scope.correctionJobId);

			formData.append('correctionWorkflowId', $scope.correctionWorkflowId);
			formData.append('correctionWorkflowMasterId', $scope.correctionWorkflowMasterId);
			formData.append('correctionWorkflowType', $scope.correctionWorkflowType);		
						
			formData.append('correctionMappingID', $scope.correctionMappingID);			
			formData.append('titleWise', $scope.titleWise);
			formData.append('chapterWise', $scope.chapterWise);								
								
			/* formData.append('correctionSrcPath', $scope.correctionSrcPath);
			formData.append('correctionWrkPath', $scope.correctionWrkPath);
			formData.append('correctionDestPath', $scope.correctionDestPath); */
			
			var conArr = '';
			for (var key in $scope.titleOrChapterWiseSelectedChapter) {
				conArr = conArr+key+"<#>"+$scope.titleOrChapterWiseSelectedChapter[key]+"<##>";
			}
			formData.append('correctionSourceFolderPath', conArr);
				
			var request = {
                method: 'POST',
                url: BASE_URL + 'correctionFileUpload',
				fileFormDataName: $scope.filenames,
				file: $scope.files,
                data: formData,
                headers: {
                    'Content-Type': undefined
                }
            };

            $http(request).then(function success(e) {					
                if (e.data.status == 0) {
                    hideLoader();
					showNotify(e.data.errMsg , 'danger' );
                } else {
					hideLoader();
					showNotify(e.data.errMsg , 'success' );
					//$('#manualCorrectionFileUploadModal').modal('hide');
                }                              
			}, function error(e) {
				hideLoader();
				showNotify(e.data.errMsg , 'danger' );
            });
		}
	}
        
         var focused = true;

        var onFocus = function () {
            focused = true;
            //$scope.jobassigned2();
        };

        var onBlur = function () {
            focused = false;
        };

        var win = angular.element($window);

        win.on("focus", onFocus);
        win.on("blur", onBlur);

        $scope.$on("$destroy", function handler() {
            win.off("focus", onFocus);
            win.off("blur", onBlur);
        });
    
	$window.onblur = function() {
            focused = false;
    };
        
	$window.onmouseover  = function(){
            focused = true;
	}
        
	var totalTime   =   5;
        
	$scope.autoRefreshBackprocessScreen = function(){	
            return false;
            if( focused ){
                $scope.jobassigned2();	
            }else{
                
            }	
            
            $('.reducing_time').val( totalTime );		
            setTimeout( function(){ $scope.timeChangesUpdate(); } , 3000 );		
            
	}

	$scope.timeChangesUpdate = function(){		
            var currenttime = $('.reducing_time').val();
            var showTime	=	parseInt( currenttime )	-	1;
            $('.reducing_time').val( showTime );		
            if( parseInt( showTime ) !== 0 ){
                setTimeout( function(){ $scope.timeChangesUpdate(); } , 2000 );
            }else if( parseInt( showTime ) == 0 ){
                setTimeout( function(){ $scope.autoRefreshBackprocessScreen(); } , 2000 );
            }		
	}
	
	var time	 = 	setTimeout( function(){ 		
        $scope.timeChangesUpdate(); } ,	1000 );
	
	
	   
});