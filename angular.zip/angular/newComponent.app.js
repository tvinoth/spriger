/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('addcompocont', function ($scope,$rootScope,$q, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{	
	$scope.chapterdata      =   []; 
        $scope.compolist  =   [];
        $scope.addserviceBtn    =   false;
        $scope.statusenum   =   [{'STATUS_ID':1,'NAME':'ACTIVE'},{'STATUS_ID':0,'NAME':'IN ACTIVE'}];
        $scope.jobid        =   '';
        
        $scope.contentloadtimer         =   1;
        
        $scope.getCompodetails =   function() 
	{
            console.log( 'triggerd for component' );
            var deferred                =   $q.defer();
            
            $http.get(BASE_URL+"getCompoListByjobid/"+$scope.jobid ) .then(function mySuccess(response) 
            {
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  200)
                {
                    $scope.compolist  =   response.data.compoinfo;
                    deferred.resolve(response);
                }
            }, 
            function myError(response) 
            {
                //if($scope.contentloadtimer    <  10){
                    //$scope.consolidateallList();
                //}
                //if($scope.contentloadtimer    ==  10){
                //    showNotify('Kindly reload page error occured.'  , 'danger' );
                //    return false;
                //}
                deferred.reject(response);
            });	
            $scope.contentloadtimer++;
            return deferred.promise;
	};
        
        $scope.getCompodetails();
        
        $scope.emaillistselected        =   {};    
        
        $scope.getTemplate  =   function (contact) {
            if (contact.ID === $scope.emaillistselected.ID) return 'edit';
            else return 'display';
        };
        
        $scope.editStage    =   function (contact) {
            $scope.emaillistselected    =   angular.copy(contact);
        };
        
        $scope.undostage    =   function () {
            $scope.emaillistselected    =   {};
        };
        
        $scope.redochanges     =   function(){
            $scope.servicemanager_name  =   "";
            $("#servicemanager_name").removeClass('val-error');
        }
        
        $scope.addnewservice      =   function() 
        {   
            $("input[name='servicemanager_name']").removeClass('val-error');
            $("#servicemanager_name").removeClass('val-error');
            var validation  =   true;
            
            if($scope.servicemanager_name     ==  '' || $scope.servicemanager_name   ==  undefined){
                $("input[name='servicemanager_name']").addClass('val-error');
                validation  =   false;
            }
            
            if(validation   ==  false){
                showNotify('Service Name is required', 'danger' );
                return false;
            }
            
            if($scope.servicemanager_name.length <= 2){
                showNotify('Service Name is to short', 'danger' );
                return false;
            }
            $scope.addserviceBtn    =   true;
            var inp = 	{
                            servicename   :   $scope.servicemanager_name
                        };  
                     
            $http.post(BASE_URL + 'addservicemanager', inp)
            .then(function mySuccess(response) 
            {
                $scope.addserviceBtn    =   false;
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                
                if(response.data.result     ==  200)
                {
                    $scope.servicemanager_name  =   "";
                    showNotify( response.data.errMsg  , 'success' );
                    $scope.servicedetails();
                }
            }, 
            function myError(response) 
            {
                $scope.addserviceBtn    =   false;
                hideLoader();
            });
        };
        
        $scope.removeservice  =   function(position,item)
        {
            bootbox.confirm("Are you sure to delete on this ?", function( result ) {
                if(result){

                    var inp         =   {   
                                    serviceid:   item
                                };
                    $http.post(BASE_URL+'deleteservicemanager',inp).then(function mySuccess(response) {
                        if(response.data.result     ==  401)
                        {
                            if (typeof response.data.validation !== 'undefined') {
                                $.each(response.data.validation,function(key,val)
                                {
                                    $.each(val,function(key,errval)
                                    {
                                        $.notify(errval,'error');
                                    });
                                });
                            }
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                        
                        if(response.data.result     ==  200)
                        {
                            $scope.servicelist.splice(position, 1); 
                            showNotify(response.data.errMsg, 'success' );
                        }
                        
                        if(response.data.result     ==  404)
                        {
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                
                    },function myError(response) {
                        showNotify(response.data.errMsg,'danger' );
                    });
                }
            });
        }
        
        $scope.updateservice     =   function(position,item)
        {
            var validation  =   true;
            $(".required_"+position).each(function(key,val){
                var getid = $(this).attr('id');
                if($(this).val()    ==  '' || $(this).val() == undefined){
                    var validation  =   false;
                    $("#"+getid).addClass('val-error');
                }else{
                    $("#"+getid).removeClass('val-error');
                }
            });
            
            if(validation   ==  false){
                showNotify('Service Name is required', 'danger' );
                return false;
            }
            
            if($("#servicename_"+position).val().length <= 2){
                showNotify('Service Name is to short', 'danger' );
                return false;
            }
            
            var inp = 	{
                            servicename :   $("#servicename_"+position).val(),
                            serviceurl  :   $("#serviceurl_"+position).val(),
                            servicetype :   $("#servicetype_"+position).val(),
                            serviceparam:   $("#serviceparams_"+position).val(),
                            servicestatus   :   $("#servicestatus_"+position).val(),
                            updateexistidval    :   item.ID
                        };  
                     
            $http.post(BASE_URL + 'updateservicemanager', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                
                if(response.data.result     ==  200)
                {
                    $scope.undostage();
                    $scope.servicelist[position]   =   response.data.validation;
                    showNotify(response.data.errMsg  , 'success' );
                }
            }, 
            function myError(response) 
            {
                hideLoader();
            });
        }
        
        $scope.savechapterdisabled  =   false;
        
        $scope.submitchapterfiles      =   function() 
        {        
            $('.required_field').removeClass('val-error');
            $("input[name='chapter_promotion']").removeClass('val-error');
            $("#chapter_promotion").removeClass('val-error');
            var bookname        =   $("#viewsource_bookidselect").find('option:selected').val();
            var chaptercomp     =   $("#viewsource_componentselect").find('option:selected').val();
            var stage           =   $("#viewsource_stageSelect").find('option:selected').val();
//            console.log(stage); 
//            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (chaptercomp  ==  '' || chaptercomp   ==  undefined || chaptercomp ==  ' ' || chaptercomp.length ==  0) || ($scope.chapter_promotion  ==  '' || $scope.chapter_promotion  ==  undefined || $scope.chapter_promotion  ==  0)){
//                $("div[id^='viewsource_']").addClass('val-error');
//                if(($scope.chapter_promotion  ==  '' || $scope.chapter_promotion  ==  undefined || $scope.chapter_promotion  ==  0)){
//                    $("#chapter_promotion").addClass('val-error');
//                }else{
//                    $("#chapter_promotion").removeClass('val-error');
//                }
//                $.notify("All fields are required", "error");
//                return false;
//            }
            
             var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).find('option:selected').val();
                    var attrID   =   $(this).attr("id");
                    var attrClass   =   $(this).attr("class");
                    if(value    !=  undefined){
                        if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                        validation  =   false;
                        if(attrClass.indexOf('chosen-select') !=   '-1'){
                            $("div[id^='"+attrID+"']").addClass('val-error');
                        }else{
                            $(this).addClass('val-error');
                        }
                        }else{
                            $("div[id^='"+attrID+"']").removeClass('val-error');
                        }
                    }
            });
            
            if($scope.chapter_promotion     ==  '' || $scope.chapter_promotion   ==  undefined || $scope.chapter_promotion ==  ' ' || $scope.chapter_promotion.length ==  0 || $scope.chapter_promotion.indexOf('?') !=   '-1'){
                $("input[name='chapter_promotion']").addClass('val-error');
                validation  =   false;
            }
            
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).val();
                    value       =   value.trim();
                    if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                    validation  =   false;
                    $(this).addClass('val-error');
                }
            });
            
            if(validation   ==  false){
                showNotify('All fields are required', 'danger' );
                return false;
            }
            $scope.savechapterdisabled  =   true;
            var chapternames    =   $('input[name="chaptername[]"]').map(function(){return $(this).val();}).get();
            var chaptertitle    =   $('input[name="chaptertitle[]"]').map(function(){return $(this).val();}).get();
            var Quantity        =   $('input[name="Quantity[]"]').map(function(){return $(this).val();}).get();
            if(chapternames.length  ==  0){
                showNotify( 'Input Chapter is empty'  , 'danger' );
                return false;
            }
            $("div[id^='viewsource_']").removeClass('val-error');
            
            showLoader('Please wait while checkout...');
            var inp             = 	{
                                jobId               :   bookname,
                                inputChapter        :   $scope.chapter_promotion,
                                compenentCategory   :   chaptercomp,
                                chapterName         :   chapternames,
                                chapterTitle        :   chaptertitle,
                                stage       :   stage,
                                workflow    :   $scope.workflow,
                                currentStage     :   $scope.process,
                                msPages    :   Quantity,
                                workflowtype    :   $("#hiddendata_workflowtypeid").val(),
                                process    :   $scope.process
                        };  
            
            $("div[id^='viewsource_']").removeClass('val-error');

            $http.post(BASE_URL + 'submitPromotionChapter', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                    $scope.savechapterdisabled  =   false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    $scope.savechapterdisabled  =   false;
                    hideLoader();
                }

                if(response.data.result     ==  400)
                {
                    $scope.heightofmodal    =   400; 
                    $scope.savechapterdisabled  =   false;
                    $scope.errorvalidationmsg   =   response.data.validationerror;
//                    showNotify( response.data.errMsg  , 'danger' );
                    $scope.errordivShow     =   true;
                    $scope.shownotavaiablechapter  =   response.data.existchapter;
                }
                
                if(response.data.result     ==  200)
                {
                    $scope.redochanges();
                    showNotify( response.data.errMsg  , 'success' );
                    $("#show-doopenfiles").trigger('click');
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                $scope.savechapterdisabled  =   false;
            });
        };
        
        
});
    