/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ( $scope, $http ,$compile, $window ,  $timeout ) {
	
    $scope.projectList  =   []; 
    $scope.menuParent   =   'Pre-Production';
    $scope.menuChild    =   'Split Completed List';
    $scope.currentuserid    =   '';
    $scope.contentloadtimer =   1;
    $scope.showProjectList  =   function(){
	
        $scope.projectList = [];
	var inp = { 
                    user_id : '' , 
                    team_id : '',
                    status  : 1
                  };
	
        $http.post(API_URL+"getSplitProjectList", inp) .then(
            function mySuccess(response) {
                $scope.projectList  =   response.data.data;
                $scope.currentuserid= 	response.data.user_id;
                $scope.vm           =   {};
                $scope.vm.dtOptions =   {};
            },function myError(response) {
                 if($scope.contentloadtimer    <  10){
                    $scope.showProjectList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });	
        $scope.contentloadtimer++;
    };
    
    $scope.showProjectList();
    
    $scope.splitCheckout    =   function( job , cur ){
        
        var bt_ele_id       =   '#Checkout_'+job.JOB_ID;
        var checkxout_btn_ele   =   document.querySelector( bt_ele_id );
        angular.element(checkxout_btn_ele).addClass('disabled');
        
        var result      =   true;
        
            if(result) {
               
                var inp =   { 
                                user_id :   '' , 
                                job_id  :   job.JOB_ID 
                            };
                            
                $http.post( API_URL+"startSplitProcess", inp    ) .then(
                    function mySuccess(response) {
                        
                        var resObj  =   response.data;
                        if( resObj.status   ==  1 ){
                            
                            if( resObj.params.token_key != null ){                                
                               window.location.href        =       BASE_URL+"splitCheckout/"+job.JOB_ID+"/"+job.ROUND+"/resplit/"+resObj.params.token_key;                                        
                            }else{                                
                               window.location.href        =       BASE_URL+"splitCheckout/"+job.JOB_ID+"/"+job.ROUND+"/resplit";                                  
                            }
                            
                        }else{                            
                                showInfo( resObj.msg , resObj.errMsg );
                                angular.element(checkxout_btn_ele).removeClass('disabled');
                        }                        
                      
                    },function myError(response) {  
                            showNotify( response.data.errMsg  , 'danger' );
                    });
        
            }else{
               
                angular.element(checkxout_btn_ele).removeClass('disabled');
                
            }
        
        
    }
    
    $scope.showXMLInModal = function( jobId , round ){   
        
        var inp = { jobId: jobId };
        
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	
        $http({
                url: API_URL + "getJobXMLInfo/"+jobId+'/'+round,
                method: 'GET',
             })
            .success(function(response) {
		$('#xmlContent').html(response);
            })
            .error(function(response) {
		console.log(response);
            });
    }
    
});