/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{
	$scope.userId 		=   0;
	$scope.JobID 		=   "";
	$scope.Msgsuccess 	=   false;
	$scope.errorresponse 	=   "";
	$scope.msg 	 	=   "";
	$scope.SessionMsg 	=   true;
	if(isNaN(getUrlParameter(1))) 
	{
		$scope.JobID 	=   "";
	} 
	else 
	{
		$scope.JobID 	=   getUrlParameter(1);
                $scope.bookname =   getUrlParameter(1);
	}
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'Par-Report';
	//session msg auto hide
	$timeout(function() 
	{
            $scope.SessionMsg 		= 	false;
        }, 3000);
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
	$scope.parrepoartallList 	= 	function() 
	{
		$scope.parreportList 	= 	[];
		var inp 				=	{'jodId' : $scope.JobID};
		$http.post(BASE_URL+"getpar_report",inp) .then(function mySuccess(response) 
		{
			$scope.parreportList 	= 	response.data.parreport;
		}, 
		function myError(response) 
		{
			$scope.errorresponse 	=	"danger";
			$scope.msg              =	response.data.msg;
			$scope.Msgsuccess 	=	true;
		});			
	};
        $scope.parrepoartallList();
        
        $scope.bookinfodetails 	= 	function() 
	{
            var bookid  =   $scope.bookname;
            if(bookid   ==  '')
            return false;
            $window.location.href 	= 	BASE_URL+"par_report/"+bookid;
	};
	
        $scope.contentloadtimer =   1;
        $scope.getbookinfoList 	=   function() 
	{
            $scope.srciframepath        =   null;
            $scope.bookinfoList = 	[];
            $http.get(BASE_URL+"dogetparbooklist") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.bookinfoList 	=   response.data.book;
                $scope.userId           =   response.data.userId;
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getbookinfoList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;
	};
	
        $scope.getbookinfoList();
        
	$scope.updateparreprtSubmit 	= 	function(paritem) 
	{
		var startpageid 			=	'startpage_'+paritem.METADATA_ID.toString();
		var endpageid 				=	'endpage_'+paritem.METADATA_ID.toString();
		var totalpageid 			=	'totalpage_'+paritem.METADATA_ID.toString();
		var nooffiguresid 			=	'nooffigures_'+paritem.METADATA_ID.toString();
		var nooffigurelegendsid 	=	'nooffigurelegends_'+paritem.METADATA_ID.toString();
		var noofunnumberedfiguresid =	'noofunnumberedfigures_'+paritem.METADATA_ID.toString();
		var nooftablesid 			=	'nooftables_'+paritem.METADATA_ID.toString();
		var nooftablelegendsid 		=	'nooftablelegends_'+paritem.METADATA_ID.toString();
		var noofunnumberedtablesid 	=	'noofunnumberedtables_'+paritem.METADATA_ID.toString();
		var noofschemesid 			=	'noofschemes_'+paritem.METADATA_ID.toString();
		var noofequationsid 		=	'noofequations_'+paritem.METADATA_ID.toString();
		var noofunnumberedequationsid  	=	'noofunnumberedequations_'+paritem.METADATA_ID.toString();
		var noofboxid  				=	'noofbox_'+paritem.METADATA_ID.toString();
		var noofboxlegendsid  		=	'noofboxlegends_'+paritem.METADATA_ID.toString();
		var startpage  				=	document.getElementById(startpageid);
		var endpage  				=	document.getElementById(endpageid);
		var totalpage  				=	document.getElementById(totalpageid);
		var nooffigures  			=	document.getElementById(nooffiguresid);
		var nooffigurelegends  		=	document.getElementById(nooffigurelegendsid);
		var noofunnumberedfigures  	=	document.getElementById(noofunnumberedfiguresid);
		var nooftables  			=	document.getElementById(nooftablesid);
		var nooftablelegends  		=	document.getElementById(nooftablelegendsid);
		var noofunnumberedtables  	=	document.getElementById(noofunnumberedtablesid);
		var noofschemes 		  	=	document.getElementById(noofschemesid);
		var noofequations 		  	=	document.getElementById(noofequationsid);
		var noofunnumberedequations =	document.getElementById(noofunnumberedequationsid);
		var noofbox  				=	document.getElementById(noofboxid);
		var noofboxlegends  		=	document.getElementById(noofboxlegendsid);
		
		var inp =	{
						jodId  		: 	$scope.JobID,
						tasklevelid : 	paritem.taskmetaid,	
						metainfoid 	:	paritem.metainfoid,	
						STARTPAGE 	:	startpage.value,	
						ENDPAGE 	:	endpage.value,	
						NOMSP 		:	totalpage.value,	
						FIGURECOUNT :	nooffigures.value,	
						FIGURECOUNTLEGENDS 		:	nooffigurelegends.value,	
						FIGURECOUNTUNNUMBERED 	:	noofunnumberedfigures.value,	
						NOTABLES 				:	nooftables.value,	
						NOTABLESLEGENDS 		:	nooftablelegends.value,	
						NOTABLESUNNUMBERED 		:	noofunnumberedtables.value,	
						NOSCHEMES 				:	noofschemes.value,	
						NOEQUATION 				:	noofequations.value,	
						NOEQUATIONUNNUMBERED 	:	noofunnumberedequations.value,	
						NOBOX 					:	noofbox.value,	
						NOBOXLEGENDS 			:	noofboxlegends.value
					};
		$http.post(BASE_URL+'updateparreports',inp).then(function mySuccess(response)
		{			
			$scope.errorresponse 	=	"success";
			$scope.msg 	 			=	response.data.msg;
			$scope.Msgsuccess 		=	true;
			$scope.parrepoartallList();
		},
		function myError(response)
		{
			$scope.errorresponse 	=	"danger";
			$scope.msg 	 			=	response.data.msg;
			$scope.Msgsuccess 		=	true;
			$scope.parrepoartallList();
		});
	};
	
	$scope.hidemsg 			=	function()
	{
		$scope.Msgsuccess 	=	false;
	};
        
        $scope.buttonchangeprocess  =   function(type){
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            if(type     ==  1){
                $(currentChapter).val('Downloading');
                $(currentChapter).attr('disabled','true');   
            }else if(type ==    2){
                $(currentChapter).val('Opening');
                $(currentChapter).attr('disabled','true');   
            }
            else{
                $(currentChapter).val('Open Raw File');
                $(currentChapter).removeAttr('disabled');   
            }
        }
	
        //open openjobrawfile
        $scope.openjobrawfile   =   function(jobId)
        {
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            $scope.buttonchangeprocess(1);
            showLoader('Please wait while Open Drive ...');
            var inp             = 	{
                                        jobId       :   jobId
                                    };   
            $http.post(BASE_URL + 'cucOpenrawFile', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    $scope.buttonchangeprocess(0);
                    showNotify( response.data.errMsg  , 'danger' );
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    // check tool end response
                    if (typeof response.data.lastID !== 'undefined' && response.data.lastID !=  '') {
                        $scope.checkToolresponse(response.data.lastID,jobId,attempt);
                    }else{
                        showNotify( response.data.errMsg  , 'success' );
                        var attempt         =   1;
                        var filehandlerid   =   response.data.rmID;
                        $scope.buttonchangeprocess(2);
                        $scope.checkfilestatusopenornot(filehandlerid,attempt);
                    }
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            });
        }
        
        $scope.checkToolresponse     =   function(ID,jobId,attempt) 
        {           
            var inp             = 	{ID  :   ID };
            $http.post(API_URL + 'checkToolStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
//                    $.notify(response.data.errMsg,'error');
                    $timeout( function(){ $scope.checkToolresponse(ID,jobId,attempt); }, 4000 );
                }
                if(response.data.result     ==  404)
                {
                    $scope.buttonchangeprocess(0);
                    showNotify("File handler is not running. Please check....", 'danger');
                }
                if(response.data.result     ==  400)
                {
                    $scope.buttonchangeprocess(0);
                    showNotify( response.data.errMsg, 'danger' );
                }
                if(response.data.result     ==  200)
                {
//                    showNotify( response.data.errMsg, 'success' );
                    $scope.RawfileOpenrequestInsert(jobId);
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
            });
        };
        
        $scope.RawfileOpenrequestInsert =   function(jobId){
            var inp     =   {jobId        :   jobId}        
            showLoader('Please wait while Open Drive ...');
            $http.post(BASE_URL + 'rawfileOpenrequestInsert', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                    $scope.buttonchangeprocess(0);         
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
                    $scope.buttonchangeprocess(2);
                    $scope.checkfilestatusopenornot(filehandlerid,attempt);
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            });
		
	};
        
        $scope.checkfilestatusopenornot     =   function(filehandlerid,attempt) 
        {           
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Opendrive'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(filehandlerid,attempt); }, 2000 );
                    } else {
                        $scope.buttonchangeprocess(0);
                        hideLoader();
                        showNotify("File handler is not running. Please check.", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    $scope.buttonchangeprocess(0);
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    $scope.buttonchangeprocess(0);
                    hideLoader();
                    showNotify( response.data.errMsg, 'success' );
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
            });
        };
        
        if($scope.JobID     !=  ''){
            var getvalue    =   $("#txtDoopenrawfile").data('rawbutton');
            if(getvalue     !=  0 && getvalue   !=  undefined){
                var attempt     =   1;
                $scope.checkToolresponse(getvalue,$scope.JobID,attempt);
            }
        }
});
