/*
 *  Stage Master Controller
 *  This controller contains all the methods related to customization > stage screen.
 */
ngApp.controller('ngController', function ($scope, $http,DTOptionsBuilder, DTColumnBuilder,$location) {
	$scope.userId = 0;	
	$scope.UserDetails = {};
	
	$scope.menuParent   =   'Pre-Production';
	$scope.menuChild    =   'BookInfo';
	if(isNaN(getUrlParameter(1))) 
	{
            $scope.jobId 	=   "";
	} 
	else 
	{
            $scope.jobId 	=   getUrlParameter(1);
	}
	/*
	 *  Get User Details
	 *  This method get the logged in user details from the session.
	 */
    $scope.getUserDetail = function (){	
	    $scope.userName = "";
	    $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) {
				 if(response.data.msg == "success") {
					$scope.userName = response.data.user_name;
					$scope.roleName = response.data.role_name;
					$scope.UserDetails = response.data;
					$scope.showAssignWorkflow($scope.jobId);
                                        $scope.getAssignWorkflow($scope.jobId);
				 } else {
					window.location.href= BASE_URL+"?expired";
				 }
		}, 
		function myError(response) {
			 console.log(response);
		});	
    };
     $scope.servermappath = function(jobId){
       
            $("#show-edit").click();
            //$event.preventDefault();
	};

	/*
	 *  Get Stage List
	 *  This method get all the active stage list from DB
	 */
	$scope.showAssignWorkflow = function(jobId) {
		//$scope.workflowList = [];
		var inp = {	jobId : jobId};
		$http.post(API_URL+"getassignworkflow", inp) .then(function mySuccess(response) {
			$scope.roundList    = response.data.roundList;
                        $scope.workflowList = response.data.workflowList;
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        
        $scope.addWorkflowtoJob = function() {		$http.post(API_URL+"saveWorkflowtoJob", inp) .then(function mySuccess(response) {

              showLoader('Please wait while adding Data...');
		//$scope.workflowList = [];
                var wfMid           = $scope.workflowMaster;
                var roundId         = $scope.round;
                if($scope.jobId     ==  undefined || $scope.jobId     ==  "" || $scope.workflowMaster     ==  undefined || $scope.round     ==  undefined)
                {
                    showNotify('All Fields are required', 'danger');
                    hideLoader();
                    return false
                }
		var inp = {jobId :  $scope.jobId, roundId:roundId, wfMid: wfMid};
                
                    
                    hideLoader();
                    if( response.data.status == '2'){
                        $scope.workflowMaster   =   undefined;
                        $scope.round            =   undefined;
                        $scope.getAssignWorkflow($scope.jobId);
                        showNotify('Successfully added', 'success');
                    }
                    
                     if( response.data.status == '1'){
                        showNotify('Already exist', 'warning');
                    }
                    
                    if( response.data.status == '0'){
                        showNotify('Something Went wrong!! Try Again', 'danger');
                    }
                    
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        
        
        $scope.getAssignWorkflow = function(jobId) {
		//$scope.workflowList = [];
		var inp = {	jobId : jobId};
		$http.post(API_URL+"getAssignedWorkflowToJob", inp) .then(function mySuccess(response) {
			$scope.workflowDetails    = response.data.workflowDetails;
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        
        
       
        
	$scope.getUserDetail();

});