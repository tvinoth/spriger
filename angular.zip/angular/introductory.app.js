/*
 *  Dashboard Controller
 *  This controller contains all the methods related to dashboard screen.
 */


ngApp.service('fileUpload', ['$http' , "$rootScope" , function ($http , $rootScope) {
    
        this.uploadFileToUrl = function( file, uploadUrl , data ){
        var fd = new FormData();
        fd.append('file', file);
        fd.append( 'data' , JSON.stringify( data ) );
        
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function( response ){
            $rootScope.error        =   response;
                    //deffered.resolve(response);
        })
        .error(function( response ){
            $rootScope.error        =   response;
           //deffered.reject(response);
        });
        //return deffered.promise;
    }
}]);

ngApp.directive( 'fileModel' , ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

ngApp.controller('ngController', function ( $scope, $http , fileUpload , $timeout ) {
	
        $scope.userId = 0;
	$scope.booksCollect     =       [];
	$scope.menuChild = 'introductoryLetter';
	$scope.menuParent = 'Pre-Production';
	$scope.customParam = "";
        $scope.selected_book    =   '';
        
        $scope.spiContactempid      =       '';
        $scope.spiContactname       =       '' ;       
        $scope.spiEmail             =       '';
        $scope.titleName            =       '';
        $scope.introductory         =       {};
        
        $scope.editor_fm_dates      =       false;
        $scope.author_caption       =       false;
        $scope.editor_caption       =       false;
        $scope.default_caption      =      true;
        $scope.options=1;
        $scope.bookinfo =   {};
        
        
        $scope.errors       =       null;
        
        $scope.getBookInfomation                    =       function( stringparam ){
            
            var inp =   { searchinp :  stringparam };
            $http.get(BASE_URL+"getBookscollection").then(function mySuccess(response) {    
               
                if( response.status = 200 ){
                    $scope.booksCollect     =       ( response.data.book );
                }
                
            }, 
            function myError(response) {
                
            });
            
        };
        
        $scope.sendIntroductoryMail                 =       function(){
            
            showLoader('please wait for a while!');
            
            var attach_doc              =         $scope.myFile;
            var file                    =         $scope.myFile;
            var uploadUrl               =         BASE_URL+"/sendIntroductoryMail";
            $scope.error                =         null;
            
            var responseHandle          =         fileUpload.uploadFileToUrl( file , uploadUrl , $scope.introductory );
            
            $timeout( function(){
                hideLoader();
                console.log( $scope.error );
                
                if( $scope.error !== null ){

                  if( $scope.error.status == 0 ){
                    $scope.errors           =           $scope.error.validationerror;
                    var errors      =   $scope.errors;
                    
                    var prepared_elements   =   '<div class="border border-danger">';
                    var string1  =  '';
                    for (var property1 in errors) {
                      //string1 = string1 + errors[property1];
                      //prepared_elements+='<div class="col-md-12"><code>'+property1+' :</code>&nbsp;'+errors[property1]+'</div>';
                      prepared_elements+='<span class="text-danger">&nbsp;<br/> <b>*&nbsp;'+errors[property1]+'</b> </span>';
                    }  
                    prepared_elements+='</div>';
                    //document.getElementById("dispError").innerHTML = prepared_elements+'<br/></br>';
                    // document.body.scrollTop = 0; // For Safari
                    // document.documentElement.scrollTop = 0;
                    showNotify( prepared_elements , 'danger' );
                }
                    //$timeout( function(){ document.getElementById("dispError").innerHTML = ''; } , 5000 );
                }else{
                    
                    showNotify( 'Introductory Letter sent successfully!' , 'success' );
                    
                    var clear_btn_ele   =   document.querySelector( '#reset_intro' );
                    angular.element(clear_btn_ele).click();
                    
                    
                }
                $scope.error    =   null;
            }, 3000 );
            
        };
        $scope.showAuthorOption             =       function(){
            
            $scope.default_caption          =        false;
            $scope.editor_fm_dates          =        false;
            $scope.editor_caption           =        false;
            $scope.author_caption           =        true;
            console.log( $scope.bookinfo );
            $scope.introductory.ediAuthName = $scope.bookinfo.authorName;
            $scope.introductory.ediAuthEmail = $scope.bookinfo.authorEmail;
            
        };
        $scope.showEditorOption             =       function(){
            
             $scope.author_caption          =       false;
             $scope.default_caption         =       false;
             $scope.editor_fm_dates         =       true;
             $scope.editor_caption          =       true;
             $scope.introductory.ediAuthName =  $scope.bookinfo.editorName;
             $scope.introductory.ediAuthEmail = $scope.bookinfo.editorEmail;
             
        };
        $scope.showContributerOption        =       function(){
            
             $scope.author_caption          =      false;
             $scope.editor_caption          =      false;
             $scope.default_caption         =      true;
             $scope.introductory.ediAuthName =   '';//$scope.bookinfo.authorName;
             $scope.introductory.ediAuthEmail = '';//$scope.bookinfo.authorEmail;
            
        };
        $scope.showXMLInModal_ref = function(){
            var jobid = $('#selected_job').val();
            if( jobid.trim() !== '' ){
                $scope.showXMLInModal( jobid , 104 );
            }else{
                showNotify( 'Please select the BookId!'  , 'danger' );
            }
        };
        $scope.showXMLInModal   =       function( jobId , round ){   
        
        var inp = { jobId: jobId };
        
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	
        $http({
                url: API_URL + "getJobXMLInfo/"+jobId+'/'+round,
                method: 'GET',
             })
            .success(function(response) {
		$('#xmlContent').html(response);
            })
            .error(function(response) {
		console.log(response);
            });
        };
        $scope.formValidation  =  function(){
        };
        $scope.preview          =       function(){
            showLoader('please wait for a while!');
            var input           =   $scope.introductory;
            $http.post(API_URL + "previewIntroductory", input).then(
                    
            function mySuccess(response){
                console.log( response );
                hideLoader();
                $('#show-preview').trigger('click');
                
            },function myError(errresponse){
                
            $timeout( function(){
                hideLoader();
                console.log( errresponse.status );
                if( errresponse.data.status == 0 ){
                    
                    $scope.errors           =           errresponse.data.validationerror;
                    var errors              =           $scope.errors;
                    
                    var prepared_elements   =   '<div class="border border-danger">';
                    var string1  =  '';
                    for (var property1 in errors) {
                      //string1 = string1 + errors[property1];
                      //prepared_elements+='<div class="col-md-12"><code>'+property1+' :</code>&nbsp;'+errors[property1]+'</div>';
                      prepared_elements+='<span class="text-danger">&nbsp;<br/> <b>*&nbsp;'+errors[property1]+'</b> </span>';
                    }  
                    prepared_elements+='</div>';
                    //document.getElementById("dispError").innerHTML = prepared_elements+'<br/></br>';
                    // document.body.scrollTop = 0; // For Safari
                    // document.documentElement.scrollTop = 0;
                    showNotify( prepared_elements , 'danger' );
                    //$timeout( function(){ document.getElementById("dispError").innerHTML = ''; } , 5000 );
                }else{
                    showNotify( 'oops!, Something went wrong, please try again.' , 'danger' );
                }
            }, 2000 );
            
            }); 
                
        };
        $scope.resetForm          =       function( formobj ){
            $scope.introductory = {};
            $('.chosen-select')
            .find('option:first-child').prop('selected', true)
            .end().trigger('chosen:updated');
             $('.chosen-select').chosen({}); 
        };
        $scope.getBookInfomation( '' );
        $(document).ready(function () {

        $("#bookidselect").chosen().change(function() {
                
                var jbid    =   $(this).val();
                $('#selected_job').val( jbid );
                $scope.introductory     =      {};
                
                if( jbid != '' ){
                    
                     $http.get( API_URL+"getBookInfoByJoid/"+jbid ).then(function mySuccess(response) {    
                         
                         var bookinfo       =       response.data.bookinfo;
                         bookinfo           =       bookinfo[0];
                         $scope.bookinfo    =       bookinfo;
                         
                         console.log( bookinfo );
                         
                         $scope.introductory.spiContactEmpId    =        bookinfo.empId;
                         $scope.introductory.spiContactname     =        bookinfo.pmName;
                         $scope.introductory.spiEmail           =        bookinfo.pmEmail;
                         $scope.introductory.titleName          =        bookinfo.bookTitle;
                         $scope.introductory.mailFrom           =        bookinfo.proofRecipient;
                         $scope.introductory.mailCc             =        bookinfo.productionEditor;
                         $scope.introductory.mailFrom           =        'no-reply@spi-global.com';
                         
                         $scope.introductory.jobId              =       jbid;
                         
                         var threword   =   bookinfo.bookTitle.split(" ");
                         threword       =   'Your Book : '+threword[0]+' '+threword[1]+' '+threword[2];
                         
                         if( bookinfo.authorName == '' ){
						  var subPre     =   bookinfo.printIssn+', '+bookinfo.editorName+':'+threword; 
						 }
						 else {
                          var subPre     =   bookinfo.printIssn+', '+bookinfo.authorName+':'+threword;
						 }
                         $scope.introductory.ediAuthSubject              =       subPre;
                         
                     },function myError(response) {
                         
                    });   
                    
                }
                
            });
            
            
        $('#id-input-file-3').ace_file_input({
            style: 'well',
            btn_choose: 'Drop files here or click to choose',
            btn_change: null,
            no_icon: 'ace-icon fa fa-cloud-upload',
            droppable: true,
            thumbnail: 'small'
                ////large | fit
                //,icon_remove:null//set null, to hide remove/reset button
                /**,before_change:function(files, dropped) {
                        //Check an example below
                        //or examples/file-upload.html
                        return true;
                }*/
                /**,before_remove : function() {
                        return true;
                }*/
            ,
            preview_error : function(filename, error_code) {
                //name of the file that failed
                //error_code values
                //1 = 'FILE_LOAD_FAILED',
                //2 = 'IMAGE_LOAD_FAILED',
                //3 = 'THUMBNAIL_FAILED'
                //alert(error_code);
            }
            }).on('change', function(){
                //console.log($(this).data('ace_input_files'));
                //console.log($(this).data('ace_input_method'));
            });
				

            //$('#id-input-file-3')
            //.ace_file_input('show_file_list', [
                    //{type: 'image', name: 'name of image', path: 'http://path/to/image/for/preview'},
                    //{type: 'file', name: 'hello.txt'}
            //]);


        });

});