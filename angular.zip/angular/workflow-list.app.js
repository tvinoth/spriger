/*
 *  Workflow Master Controller
 *  This controller contains all the methods related to customization > workflow screen.
 */
ngApp.controller('ngController', function ($scope, $http, DTOptionsBuilder, DTColumnBuilder) {
    $scope.userId = 0;
    $scope.UserDetails = {};
    $scope.AllStages = [];
    $scope.Circle = [];
    $scope.menuParent = 'Customization';
    $scope.menuChild = 'WorkflowList';

    /*
     *  Get all the stages excluding already assigned stages
     *  Get all the assigned stages for the given workflow
     */
    $scope.getAssignedStages = function (workflowMId,workflowId) {
        $scope.workflowMId           = workflowMId;
        $scope.workflowId           = workflowId;
        var inp = {workflowId: workflowMId};
        $http.post(API_URL + "getAssignedStages", inp).then(function mySuccess(response) {
            console.log(response);
            $scope.wfStages         = response.data.assignedStages.stage;
            $scope.newworkflowlist  = response.data.assignedStages.assignedStage;
            $scope.packageCode      = response.data.wfMasterDetails['0'].CODE; 
            $scope.wfName           = response.data.wfMasterDetails['0'].WORKFLOW_MASTER_NAME; 
            $scope.workflowExistingName =  response.data.wfMasterDetails['0'].WORKFLOW_MASTER_NAME; 
            $scope.wfDesc           = response.data.wfMasterDetails['0'].DESCRIPTION;
            $scope.circleId         = response.data.wfMasterDetails['0'].CIRCLE_ID; 
            $scope.subcircleId      = response.data.wfMasterDetails['0'].SUB_CIRCLE_ID; 
            $scope.wfMasterId      = response.data.wfMasterDetails['0'].WORKFLOW_MASTER_ID; 
            $scope.SubCircle        = response.data.subcircle;
            
            
            
        },
                function myError(response) {
                    console.log(response);
                });
    };
    $scope.newworkflowlist = [];
    $scope.addnewitem = function (item)
    {
        var index = $scope.wfStages.indexOf(item);
        $scope.wfStages.splice(index, 1);
        $scope.newworkflowlist.push(item);
    }

    $scope.reddnewitem = function (item)
    {
        var index = $scope.newworkflowlist.indexOf(item);
        $scope.newworkflowlist.splice(index, 1);
        $scope.wfStages.push(item);
    }

    $scope.upitem = function (item, position) {
        if (position > -1 && position < $scope.newworkflowlist.length)
        {
            if (position == 0)
            {
                return false;
//                var indexposition        =   $scope.newworkflowlist[position];
//                $scope.newworkflowlist[$scope.newworkflowlist.length]  =   indexposition;
//                $scope.newworkflowlist.splice($scope.newworkflowlist[indexposition+1],1);
            } else
            {
                var nextposition = $scope.newworkflowlist[position - 1];
                $scope.newworkflowlist[position - 1] = $scope.newworkflowlist[position];
                $scope.newworkflowlist[position] = nextposition;
            }
        }
    };
    $scope.downitem = function (item, position) {
        if (position > -1 && position < $scope.newworkflowlist.length)
        {
            if (position == $scope.newworkflowlist.length - 1)
            {
                return false;
//                var indexposition           =   $scope.newworkflowlist[position];
//                $scope.newworkflowlist[0]   =   indexposition;
//                $scope.newworkflowlist[$scope.newworkflowlist.length-1]  =   indexposition;
//                $scope.newworkflowlist.splice($scope.newworkflowlist[indexposition+1],1);
            } else
            {
                var nextposition = $scope.newworkflowlist[position + 1];
                $scope.newworkflowlist[position + 1] = $scope.newworkflowlist[position];
                $scope.newworkflowlist[position] = nextposition;
            }
        }
    };
    /*
     *  Get All the active stages
     *  This method get all the active stages
     */
    $scope.getAllStages = function () {
        var inp = {stageId: 0, opt: 'All'};
        $http.post(API_URL + "getStageDetail", inp).then(function mySuccess(response) {
            $scope.wfStages = response.data.stage;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    /*
     *  Get All the circles
     *  This method get all the circles
     */
    $scope.getCircles = function () {
        $http.get(API_URL + "getCircle").then(function mySuccess(response) {
            $scope.Circle = response.data;
            $scope.wfCircles = $scope.Circle;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    /*
     *  Get Subcircles
     *  This method get all the subcircles for the selected circle
     */
    $scope.fillSubCircle = function (subcircleName) {
        var inp = {circleId: $scope.wfEG};
        $http.post(API_URL + "getSubCircle", inp).then(function mySuccess(response) {
            $scope.SubCircle = response.data;
            $scope.wfCluster = subcircleName;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    /*
     *  Get Workflow List
     *  This method get all the active workflows from DB
     */
    $scope.showWorkflowList = function () {
        $scope.wfList = [];
        var inp = {workflowId: 0, opt: 'All'};
        $http.post(API_URL + "getWorkflowList", inp).then(function mySuccess(response) {
            $scope.wfList = response.data.workflow;
            console.log($scope.wfList);
        },
        function myError(response) {
            console.log(response);
        });
    };
    
    $scope.showWorkflowList();

    $scope.getWorkflowPackage = function () {
      //  $scope.wfList = [];
        var inp = {workflowId: 0, opt: 'All'};
        $http.post(API_URL + "getWorkflowPackageCode", inp).then(function mySuccess(response) {
            $scope.packageCode = response.data.packageCode[0].code;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    /*
     *  View Workflow
     *  This method get workflow and its stages for display
     */
    $scope.viewWorkflow = function (workflowMasterId) {
        var title = 'View Workflow';
        $scope.wkInfo = '';
        $scope.workflow = [];
        $scope.stageInfo = [];
        var inp = {workflowMasterId: workflowMasterId};
        $http.post(API_URL + "getWorkflowAndStages", inp).then(function mySuccess(response) {
            console.log(response);
            $scope.workflow = response.data.workflow;
            $scope.stageInfo = response.data.stage;

            $scope.wkInfo += '<div class="dd" id="nestable"><ol class="dd-list">';
            for (var k = 0; k < $scope.workflow.length; k++) {
                $scope.wkInfo += '<li class="dd-item" data-id="' + k + '"><div class="dd-handle orange">';
                if ($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
                    $scope.wkInfo += "Main Workflow - ";
                } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
                    $scope.wkInfo += "Parallel Workflow - ";
                } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
                    $scope.wkInfo += "Art Workflow - ";
                } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
                    $scope.wkInfo += "Art Correction Workflow - ";
                }
                $scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

                if ($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
                    $scope.wkInfo += " (";
                    if ($scope.workflow[k]['START_STAGE'] != '') {
                        $scope.wkInfo += " Start Stage: " + $scope.workflow[k]['START_STAGE'];
                        $scope.wkInfo += " End Stage: " + $scope.workflow[k]['END_STAGE'];
                    } else {
                        $scope.wkInfo += " No Start and End stage is defined";
                    }
                    $scope.wkInfo += ") ";
                }
                $scope.wkInfo += '</div><ol class="dd-list">';
                for (var i = 0; i < $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']].length; i++) {
                    $scope.wkInfo += '<div class="dd-handle"><li class="dd-item" data-id="' + i + '">';
                    $scope.wkInfo += $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_NAME'];

                    $scope.wkInfo += '</div></li>';
                }
                $scope.wkInfo += '</ol></li>';
            }
            $scope.wkInfo += '</ol></div>';
            showInfo(title, $scope.wkInfo);
            $('.dd').nestable();
        },
                function myError(response) {
                    console.log(response);
                });
    };
    /*
     *  Delete Workflow
     *  This method used to update the workflow active status = 0
     */
    $scope.deleteWorkflow = function (workflowMasterId) {
        bootbox.confirm("Are you sure you want to delete?", function (result) {
            if (result) {
                var inp = {workflowMasterId: workflowMasterId};
                $http.post(API_URL + "deleteWorkflow", inp).then(function mySuccess(response) {
                    showMessage('Workflow', 'Successfuly deleted.', 'success');
                    $scope.showWorkflowList();
                },
                        function myError(response) {
                            console.log(response);
                        });
            }
        });
    };
    /*
     *  Add Workflow
     *  This method used to add new Workflow details
     */
    $scope.addWorkflow = function () {
        
        $scope.clearWorkflow();
        $scope.getAllStages();
        $scope.getWorkflowPackage();


        $scope.getCircles();
        $("#show-edit").click();
        $scope.action = 'add';
        $scope.wf = $scope.AllStages;
        $scope.wfCircles = $scope.Circle;
    };
    /*
     *  Clear Workflow Details
     *  This method used to clear Workflow details 
     */
    $scope.clearWorkflow = function () {
        $scope.wfEG = "";
        $scope.wfCluster = "";
        $scope.wfCode = "";
        $scope.wfName = "";
        $scope.wfId = 0;
        $scope.newworkflowlist  = [];
        $scope.errorMsg = "";
        $scope.wfStageSel = [];
        $("#edit-close").click();
    };
    /*
     *  Edit Workflow
     *  This method used to edit the workflow stages
     */
    $scope.editWorkflow = function (wfmid,wfid) {
        
        $scope.action = 'edit';
        $scope.getCircles();
        $("#show-edit").click();
        $scope.getAssignedStages(wfmid,wfid);
        $scope.wfCircles = $scope.Circle;

        /*$scope.errorMsg = "";
        $scope.wfEG = wf.CIRCLE_ID.toString();
        $scope.fillSubCircle(wf.SUB_CIRCLE_ID.toString());

        $scope.wfCluster = wf.SUB_CIRCLE_ID.toString();
        $scope.wfCode = wf.CODE;
        $scope.wfName = wf.WORKFLOW_MASTER_NAME;
        $scope.wfId = wf.workflow_id;
        $scope.wfMasterId = wf.WORKFLOW_MASTER_ID;*/
    };
    /*
     *  Save Workflow
     *  This method used to save Workflow details
     */
    $scope.saveWorkflow = function () {
        if ($scope.wfName == "") {
            $scope.errorMsg = "Please enter workflow name.";
        } else {
            showLoader('Please wait while adding Data...');
            
            var inp = {action:$scope.action,userId: '', wfMasterId: $scope.wfMasterId, wfId: $scope.workflowId, wfEG: $scope.wfEG, wfCluster: $scope.wfCluster, wfCode: $scope.packageCode, wfName: $scope.wfName, wfDesc: $scope.wfDesc, wfStage: $scope.newworkflowlist};
     
            $http.post(API_URL + "saveWorkflow", inp).then(function mySuccess(response) {
                hideLoader();
                
                if (response.data.errMsg == 'success') {
                    $("#edit-close").click();
                    $scope.showWorkflowList();
                    showNotify('Successfully Added', 'success');
                } else {
                    $("#edit-close").click();
                    showNotify('Unable to insert data', 'danger');
                }
                //
            },
                    function myError(response) {
                        console.log(response);
                    });
        }
    };	/*
     *  This method used to move the workflow stages up, down, left, right.
     */
    $scope.WorkflowStageMovement = function (listID, direction) {
        var listbox = document.getElementById(listID);
        var selIndex = listbox.selectedIndex;

        if (-1 == selIndex) {
            alert("Please select an option to move.");
            return;
        }

        var increment = -1;
        if (direction == 'up')
            increment = -1;
        else
            increment = 1;

        if ((selIndex + increment) < 0 || (selIndex + increment) > (listbox.options.length - 1))
            return;

        var selValue = listbox.options[selIndex].value;
        var selText = listbox.options[selIndex].text;
        listbox.options[selIndex].value = listbox.options[selIndex + increment].value
        listbox.options[selIndex].text = listbox.options[selIndex + increment].text

        listbox.options[selIndex + increment].value = selValue;
        listbox.options[selIndex + increment].text = selText;

        listbox.selectedIndex = selIndex + increment;
    };
    jQuery("#right2,#left2").click(function (event) {
        var id = jQuery(event.target).attr("id");
        var selectFrom = id == "right2" ? "#sbox3" : "#sbox4";
        var moveTo = id == "right2" ? "#sbox4" : "#sbox3";

        var selectedItems = jQuery(selectFrom + " :selected").toArray();
        jQuery(moveTo).append(selectedItems);
        selectedItems.remove;
    });


    $scope.validateWorkflowName = function () {

        if ($scope.wfName == '') {
            $scope.errorPackageName = false;
        }
        
         if ($scope.workflowExistingName != '') {
            console.log($scope.wfName);
            console.log($scope.workflowExistingName);
            if ($scope.wfName == $scope.workflowExistingName) {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;
                console.log($scope.PackageExistingName);
                return false;
            }
        }


        var inp = {workflowname: $scope.wfName};
        $http.post(API_URL + "validateworkflowname", inp).then(function mySuccess(response) {
            if (response.data.msg == 'invalid') {

                if (response.data.msg == 'empty') {
                    $scope.errorPackageName = false;
                }

                $scope.buttonvalidation = true;
                $scope.errorPackageName = true;
            } else {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;

            }
            //
        },
                function myError(response) {
                    console.log(response);
                });

    };
    
     $scope.validateparallelWorkflowName = function () {

        if ($scope.wfName == '') {
            $scope.errorPackageName = false;
        }
        
         if ($scope.workflowExistingName != '') {
            console.log($scope.wfName);
            console.log($scope.workflowExistingName);
            if ($scope.wfName == $scope.workflowExistingName) {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;
                console.log($scope.PackageExistingName);
                return false;
            }
        }


        var inp = {workflowname: $scope.wfName,wftype:'parallel', wfmasterId:$scope.workflowMId };
        $http.post(API_URL + "validateworkflowname", inp).then(function mySuccess(response) {
            if (response.data.msg == 'invalid') {

                if (response.data.msg == 'empty') {
                    $scope.errorPackageName = false;
                }

                $scope.buttonvalidation = true;
                $scope.errorPackageName = true;
            } else {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;

            }
            //
        },
                function myError(response) {
                    console.log(response);
                });

    };

     $scope.addparllelworkflow = function (workflowMId) {
        
        $scope.clearWorkflow();
        $scope.getAllStages();
        $scope.getMasterWorkflowDetails(workflowMId);
        $scope.getCircles();
        $("#show-parallel").click();
        $scope.action = 'add';
        $scope.wf = $scope.AllStages;
        $scope.wfCircles = $scope.Circle;
    };
    
    
    $scope.getMasterWorkflowDetails = function (workflowMId,workflowId) {
        $scope.workflowMId           = workflowMId;
        $scope.workflowId           = workflowId;
        var inp = {workflowId: workflowMId};
        $http.post(API_URL + "getParallelWorkflowDetails", inp).then(function mySuccess(response) {
            
            $scope.wfcode           = response.data.workflowMasterDetails.CODE;
            $scope.mainwfName       = response.data.workflowMasterDetails.WORKFLOW_NAME;
            $scope.subcircleId      = response.data.workflowMasterDetails.SUB_CIRCLE_NAME;
            $scope.circleId         = response.data.workflowMasterDetails.CIRCLE_NAME;
            $scope.pworkflowname    = response.data.workflowDetails;
            $scope.wfName           = '';
          
        },
                function myError(response) {
                    console.log(response);
                });
    };
    
    
    $scope.selectParallelWorkflow = function () {
        var wfId = $scope.wfpworkflow;
        
        if( wfId == 'new' ){
          $scope.action = 'add';
          $mastesStages =   $scope.getMasterWorkflowAssignStages($scope.workflowMId);
        } else {
          $scope.action = 'edit';
         
          $mastesStages =   $scope.updateParallelWorkflow(wfId);
          
        }

        
        var inp = {wfid: wfId};
        
        console.log(inp);
        return false;
        $http.post(API_URL + "getSubCircle", inp).then(function mySuccess(response) {
            $scope.SubCircle = response.data;
            $scope.wfCluster = subcircleName;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    
    $scope.getMasterWorkflowAssignStages = function (workflowMId) {
        var inp = {workflowMasterId: workflowMId};
        $scope.wfMasterId = workflowMId;
        $http.post(API_URL + "getMasterWorkflowAssignStages", inp).then(function mySuccess(response) {
            $scope.wfName = "";
            $scope.newworkflowlist    = [];
            $scope.workflowlist           = response.data;
            //$scope.wfEndStage           = response.data;
             
            
        },
                function myError(response) {
                    console.log(response);
                });
    };
    
        /*
     *  Save Workflow
     *  This method used to save Workflow details
     */
    $scope.saveParallelWorkflow = function () {
        if ($scope.wfName == "") {
            $scope.errorMsg = "Please enter workflow name.";
        } else {
            showLoader('Please wait while adding Data...');
            
            var inp = {action:$scope.action,userId: '', wfMasterId: $scope.wfMasterId, wftype: $scope.wfpworkflow, wfName: $scope.wfName, wfStartStage:$scope.wfStartStage,wfendstage:$scope.wfEndStage, wfStage: $scope.newworkflowlist};
               
            $http.post(API_URL + "saveParallelWorkflow", inp).then(function mySuccess(response) {
                hideLoader();
                
                if (response.data.errMsg == 'success') {
                   $scope.wfName = "";
                   $scope.wfpworkflow = "";
                   $scope.wfStartStage  = "";
                   $scope.wfEndStage    = "";
                   $scope.wfStages    = "";
                   $scope.newworkflowlist    = "";
                   $scope.getAllStages();
                   $scope.getMasterWorkflowDetails($scope.wfMasterId);
                    showNotify('Successfully Added', 'success');
                } else {
                   
                    showNotify('Unable to insert data', 'danger');
                }
                //
            },
                function myError(response) {
                    console.log(response);
                });
        }
    };
    
    $scope.updateParallelWorkflow = function (wfId) {
        var inp = {workflow: wfId};
         
        $http.post(API_URL + "getAssignParallelWorkflowDetails", inp).then(function mySuccess(response) {
          
            $scope.wfName                =  response.data.workflowDetails['0'].WORKFLOW_NAME;
            $scope.workflowExistingName  =  $scope.wfName;
            $scope.wfMasterId            =  response.data.workflowDetails['0'].WORKFLOW_MASTER_ID;
            $scope.asswfStartStage      =   response.data.workflowDetails['0'].START_STAGE;
            $scope.asswfEndStage        =   response.data.workflowDetails['0'].END_STAGE;
            $scope.wfStartStage         =   {STAGE_ID:response.data.workflowDetails['0'].START_STAGE};
            $scope.wfEndStage           =   {STAGE_ID:response.data.workflowDetails['0'].END_STAGE};
           // $scope.wfStage              = response.data.masterWorkflowStages; 
            $scope.workflowlist         =   response.data.masterWorkflowStages; 
            $scope.wfStages             =   response.data.stage;
            $scope.newworkflowlist      =   response.data.assignedStage;
        },
        function myError(response) {
            console.log(response);
        });

    };

    $scope.models = {
        selected: null,
        lists: {"A": [], "B": []}
    };

    // Generate initial model
    for (var i = 1; i <= 3; ++i)
    {
        $scope.models.lists.A.push({label: "Item A" + i});
        $scope.models.lists.B.push({label: "Item B" + i});
    }

    // Model to JSON for demo purpose
    $scope.$watch('models', function (model)
    {
        $scope.modelAsJson = angular.toJson(model, true);
    }, true);

    /*$scope.getAllStages();
     $scope.getCircles();*/

});