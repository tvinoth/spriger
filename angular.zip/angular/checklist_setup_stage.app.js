/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout,$location,$q, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    $scope.userId 	=   '0';	
    $scope.menuParent 	=   'Customization';
    $scope.menuChild 	=   'Check List';
    $scope.errorMsg 	=   "";
    $scope.stgaelist    =   [];
    $scope.roundlist    =   [];
    $scope.editeditem   =   {};
    if(isNaN(getUrlParameter(1))) 
    {
        $scope.JobID 	=   "";
    } 
    else 
    {
        $scope.JobID 	=   getUrlParameter(1);
    }
    
    $scope.clearaddformdata =   function()
    {
        var checkchildrow   =   $("#trrow tr").hasClass("childrowadded");
        if(checkchildrow    ==  true)
        {
            $("#trrow").find("tr.childrowadded").remove();
        }
        $("#trrow").find("textarea,select").val('');
        $scope.removeitembutton     =   false;
        $scope.roundmodel       =   "";
        $scope.stagemodel       =   "";
        $scope.levelmodel       =   "";
    }
    
    $scope.openAddCheckItem =   function()
    {
        $scope.clearaddformdata();   
    }
    
    $scope.contentloadtimer     =   1;
    
    $scope.getemailStageList	=   function(){
        
        $scope.checklist        =   [];
        $scope.dtOptions        =   DTOptionsBuilder.newOptions()
                                        .withOption('ajax', {
                                                //dataSrc: "data",
        //                                        data: ,
                                                url: BASE_URL + 'getAllChecklistItem',
                                                type: 'POST'
                                        })
                                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                                        .withOption('createdRow', function( row , data , dataIndex) {
                                            
                                            // Recompiling so we can bind Angular directive to the DT
                                            $compile(angular.element(row).contents())($scope);
                                            
                                        })
                                        .withOption('stateSave', false)
                                        .withOption('processing', true) // required - for show progress bar
                                        .withOption('serverSide', true)// required - for server side processing
                                        .withOption('responsive', true)// required - for server side processing
                                        .withOption('paging', true)// required
                                        .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                                        .withDisplayLength(10) //// Page size
                                        .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                                        .withOption('order', [[0, 'desc'], [0, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


        $scope.dtColumns    =   [
                                    DTColumnBuilder.newColumn('ROUND_NAME').withTitle('Stage'),
                                    DTColumnBuilder.newColumn('STAGE_NAME').withTitle('Process'),
                                    DTColumnBuilder.newColumn('LEVEL_NAME').withTitle('Copy Editing Level'),
                                    DTColumnBuilder.newColumn('INSTRUCTION').withTitle('Check List').notSortable(),
                                    DTColumnBuilder.newColumn('MANDATORY_TYPE').withTitle('Mandatory Type'),
                                    DTColumnBuilder.newColumn('ACTION').withTitle('Action')
                                ];

        $scope.dtInstance   =   {};
      
        var deferred            =   $q.defer();
        $http.get(BASE_URL+"dogetRoundstagelist").then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
            }
            $scope.checklist        = 	response.data.checklist;
            $scope.stgaelist        = 	response.data.stgaelist;
            $scope.roundlist        = 	response.data.roundlist;
            $scope.levellist        = 	response.data.levellist;
            deferred.resolve(response);
        }, 
        function myError(response) {
            if($scope.contentloadtimer    <  10){
                $scope.getemailStageList();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            deferred.reject(response);
        });	
        $scope.contentloadtimer++;
        return deferred.promise;
    };
    
    $scope.getemailStageList();
    
    $scope.checkItemAddSubmit = function()
    {
        $scope.submititemdisabled   =   true;
        if ($scope.addCheckItemFrm.$valid)
        {
            if($scope.roundmodel    ==  undefined || $scope.roundmodel    ==  '' ||  $scope.stagemodel    ==  '' || $scope.stagemodel    ==  undefined || $scope.levelmodel    ==  '' || $scope.levelmodel    ==  undefined)
            {
                showNotify('All fields are required', 'danger' );
                return false;
            }
        
            var checkIteminfo       =   $('textarea[name="checkIteminfo[]"]').map(function(){return $(this).val();}).get();
            var mandatorymodelarray =   [];
            var mandatorymodel      =   $('.mandatorymodel').each(function(inx){
                if($(this).is(':checked')   ==  true)
                {
                    mandatorymodelarray.push(1);
                }else{
                    mandatorymodelarray.push(0);
                }
            });
            
            var emptyinstructionvalue   =   checkIteminfo.filter(consmval => consmval.length == 0);
            if(emptyinstructionvalue.length   >=  1)
            {
                $scope.submititemdisabled   =   false;
                showNotify('All Check list filed is required', 'danger' );
                hideLoader();
                return false;
            }
            
            var inp                 =   {
                                            roundmodel          :   $scope.roundmodel,
                                            stagemodel          :   $scope.stagemodel,
                                            levelmodel          :   $scope.levelmodel,
                                            checkIteminfo       :   checkIteminfo,
                                            mandatorymodel      :   mandatorymodelarray,
                                            instruct_caption    :   $scope.instruct_caption
                                        };
            $http.post(BASE_URL+'storechecklist',inp).then(function mySuccess(response) {
                if(response.data.result == 200) 
                {   
                    showNotify(response.data.errMsg, 'success' );
                    $scope.checklist    = 	response.data.checklist;
                    $("#addCheckItem-close").click();
                } 
                else
                {
                    $scope.submititemdisabled   =   false;
                    showNotify(response.data.errMsg, 'danger' );
                }
            },function myError(response) {
                $scope.submititemdisabled   =   false;
                showNotify(response.data.errMsg,'danger' );
            });

        } else {
            $scope.submititemdisabled   =   false;
            showNotify('Please fill in required fields', 'danger' );
        }
    };
    
    var row                 =   1;
    $scope.additem          =   function()
    {
        var newitem         =   '<tr class="childrowadded" id="indexrow'+row+'"><td><textarea name="checkIteminfo[]" rows="4" cols="5"  class="form-control" required /></textarea></td><td><input name="mandatorymodel[]" type="checkbox" class="mandatorymodel"> <span><i alt="Click here to add check list" title="Click here to add new check list" class="ml-20 ace-icon fa fa-minus-circle bigger-200 pointer red" ng-click="removeitem('+row+')"></i></span></td></tr>';
        $("#trrow tr:last").after($compile(newitem)($scope));
        row++;
    }
    
    $scope.removeitem       =   function(row)
    {
        var checkchildrow   =   $("#indexrow"+row).remove();
    }
    
    $scope.editChecklist    =   function (checklistLevelID,checklistID) {
        $scope.editinp = { instruct_caption: '',levelmodel:'',roundmodel:'',instructionlevelid:'',instructionid:'',stagemodel:'',checkEditIteminfo:'',mandatorymodel:''};
        
        var inp                 =   {   
                                        ilid :   checklistLevelID,
                                        insid     :   checklistID
                                    };
        $http.post(BASE_URL+'getChecklistInstructionById',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {   
                $scope.editinp.instruct_caption     =   response.data.data.instructionCaption;
                $scope.editinp.levelmodel           =   response.data.data.copylevel;
                $scope.editinp.checkEditIteminfo    =   response.data.data.instruction;
                $scope.editinp.instructionid    =   response.data.data.instructionid;
                $scope.editinp.instructionlevelid     =   response.data.data.instructionlevelid;
                $scope.editinp.mandatorymodel     =   response.data.data.mandatory;
                $scope.editinp.roundmodel     =   response.data.data.roundid;
                $scope.editinp.stagemodel    =   response.data.data.stageid;
                $('#show-edit-check-item').trigger('click');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
        
        
        /*$scope.removeattrmethod(index);
        angular.element(document.getElementById("setupdatefile_"+index)).text('');
        var updatebutton    =   '<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doUpdatechecklist('+index+','+itemdata+')">Update</button> <button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doUndochecklist('+index+','+itemdata+')">Undo</button>';
        var emailuptebutton =   $compile(updatebutton)($scope);
        angular.element(document.getElementById("setupdatefile_"+index)).append(emailuptebutton);*/
    };
    
    $scope.doUndochecklist  =   function (index,id) {
        var inp             =   {   
                                    checklistid     :   id
                                };

        $http.post(BASE_URL+'dogetundochecklist',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            { 
                $scope.addattrmethod(index);
                angular.element(document.getElementById("setupdatefile_"+index)).text('');
                var updatebutton    =   '<div class="hidden-sm hidden-xs action-buttons"><a class="green" ng-click="editChecklist('+index+','+response.data.checklistitem.ID+')"><i class="ace-icon fa fa-pencil bigger-130"></i></a><a class="red" ng-click="removechecklist('+index+','+response.data.checklistitem.ID+','+response.data.checklistitem.INSTRUCTION_ID+')"><i class="ace-icon fa fa-trash-o bigger-130"></i></a></div>';
                var emailuptebutton =   $compile(updatebutton)($scope);
                angular.element(document.getElementById("setupdatefile_"+index)).append(emailuptebutton);
                
                $('#instructioncontent_'+index).val(response.data.checklistitem.INSTRUCTION);
                $('#stagemodel_'+index).val(response.data.checklistitem.STAGE_ID);
                $('#roundmodel_'+index).val(response.data.checklistitem.ROUND_ENUM_ID);
                if(response.data.checklistitem.MANDATORY_TYPE     ==  1){
                    $('#mandatorytype_'+index).prop('checked','checked');
                }else
                {
                    $('#mandatorytype_'+index).removeAttr('checked');
                }
                $('#levelmodel_'+index).val(response.data.checklistitem.INSTRUCTION_TYPE_ENUM_ID);
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    };
    
    $scope.checkItemEditSubmit    =   function(index,id) 
    {
        if(($scope.editinp.roundmodel    ==  '' || $scope.editinp.roundmodel == undefined) || ($scope.editinp.stagemodel    ==  '' || $scope.editinp.stagemodel == undefined) || ($scope.editinp.levelmodel    ==  '' || $scope.editinp.levelmodel == undefined) || ($scope.editinp.instruct_caption    ==  '' || $scope.editinp.instruct_caption == undefined) || ($scope.editinp.checkEditIteminfo    ==  '' || $scope.editinp.checkEditIteminfo == undefined))
        {
            showNotify('All fields are required', 'danger' );
            return false;
        }
        var checkistrueorfalse  =   $("input[name='mandatorymodel']").is(":checked");
        $scope.editinp.mandatorymodel   =   (checkistrueorfalse   ==  true?1:0);
        var inp     =   $scope.editinp;
        showLoader('Please wait while updating records...');
        $http.post(BASE_URL+'updateChecklist',inp).then(function mySuccess(response) {
            hideLoader();
            if(response.data.status == 1) 
            {   
                $scope.dtInstance.rerender();
                $('#modal-edit-check-item').modal('toggle');
                showNotify(response.data.errMsg, 'success' );
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            hideLoader();
            showNotify(response.data.errMsg,'danger' );
        });
    }
            
    $scope.addattrmethod    =   function(index)
    {
        $("#levelmodel_"+index).attr('disabled',true);
        $("#instructioncontent_"+index).attr('readonly',true);
        $(".stage_"+index).attr('disabled',true);
    }
    
    $scope.removeattrmethod    =   function(index)
    {
        $("#levelmodel_"+index).removeAttr('disabled');
        $("#instructioncontent_"+index).removeAttr('readonly');
        $(".stage_"+index).removeAttr('disabled');
    }
    
    $scope.removechecklist  =   function(position,itemId,InstructionId)
    {
        
        bootbox.confirm("Are you sure to delete on this ?", function( result ) {
            if(result){ 
                var inp         =   {   
                                        checkitemid     :   itemId,
                                        instrucitonid   :   InstructionId
                                    };
                $http.post(BASE_URL+'checklistdelete',inp).then(function mySuccess(response) {
                    if(response.data.status == 1) 
                    {   
                        $scope.dtInstance.rerender();
//                        $scope.checklist.splice(position, 1); 
                        showNotify(response.data.errMsg, 'success' );
                    } 
                    else
                    {
                        showNotify(response.data.errMsg, 'danger' );
                    }
                },function myError(response) {
                    showNotify(response.data.errMsg,'danger' );
                });
            }
        });
    }
    
    $scope.readinst             =   [];
    
	$scope.viewCheckoutlist     =   function(roundID,stageID,jobID,metadataID){
		
        var inp                 =   {   
                                        roundID     :   roundID,
                                        stageID     :   stageID,
                                        jobID       :   jobID,
                                        metadataID  :   metadataID,
                                        readtype    :   '2'
                                    };
        $http.post(BASE_URL+'readchecklistReport',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {   
                $scope.readinst     =   response.data.readinstruction;
                $scope.readname     =   response.data.readname;
                $scope.stagename    =   $scope.readname.stagename;
                $scope.roundname    =   $scope.readname.roundname;
                $scope.leveltype    =   $scope.readname.levelname;
                $scope.stageID      =   $scope.readname.stageid;
                $scope.roundID      =   $scope.readname.roundid;
                $scope.jobID        =   $scope.readname.jobid;
                $scope.MetadataID   =   $scope.readname.metadata;
                $("#show-add-check-item").click();
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    $scope.readallchecklist         =   function(){
        if($scope.allchecklist  ==  true)
        $(".emailrecipieentcheckeditem").prop('checked','checked');
        else
        $(".emailrecipieentcheckeditem").prop('checked',false);
    }
    
    $scope.submitinstruction        =   function() {
        $scope.submititemdisabled   =   true;
        var checkemptychapter       =   $('input[name="readchecklist[]"]:checked').map(function(){return $(this).val();}).get();
        
        if(checkemptychapter.length ==  0)
        {
            $scope.submititemdisabled   =   false;
            showNotify('Kindly select anyone chapter', 'danger' );
            return false;
        }
        if($scope.allchecklist  ==  undefined)
        {
            $scope.allchecklist =   false;
        }
        var inp                     =   {   
                                        roundID     :   $scope.roundID,
                                        stageID     :   $scope.stageID,
                                        jobID       :   $scope.jobID,
                                        metadataID  :   $scope.MetadataID,
                                        readtype    :   2,//chapter-level
                                        typeofinstruction   :   $scope.allchecklist,
                                        instructionID   :   checkemptychapter
                                    };
                                    
        $http.post(BASE_URL+'SubmitChecklistValidate',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {   
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });   
    }
       
});
