/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */


ngApp.controller('ngController', function ($scope, $http) {
    
	$scope.projectList = [];
	$scope.showProject = false;
	
	$scope.menuParent = 'Pre-Production';
	$scope.menuChild  = 'bookContactImport';
        
        /*
	 *  This method navigate the user to the setup page
	 *  User click project from the project list, this method will invoke.
	 */
        
	$scope.gotoProjetSetup = function(jobID){
		window.location.href=BASE_URL+"pre-production/tps-setup/"+jobID;
	};
	
        /*
	 *  Show Project List
	 *  This method pass the user id, team id of the logged in user and get the list of projects for this user.
	 */
        
	$scope.showProjectList = function() {
		$scope.projectList = [];
		var inp = {	user_id : '', team_id : ''};
		$http.post(API_URL+"getProjectList", inp) .then(function mySuccess(response) {
			$scope.projectList = response.data.data;
			$scope.vm = {};
			$scope.vm.dtOptions = {};
		}, 
		function myError(response) {
		});			
	};
});


ngApp.controller('contactDetails', function ( $scope , $http, $filter , $timeout , $interval , DTOptionsBuilder , DTColumnBuilder ) {
    
    $scope.addprdl = {};
    
    $scope.contactAddSubmit = function() {    
    
        var input = {
            contact_name    :   $scope.addContact.contact_name ,
            contact_email   :   $scope.addContact.contact_email ,
            location_id     :   $scope.addContact.location_id
        };
        var request     =   $http({
                                    method  :   "post",
                                    url     :   "insertContact",                                   
                                    data    :   input 
                                 });
                                 
        request.success( function( response ) {
            
            $( '#addContact-close' ).click();
            
            var data        =       angular.fromJson( response );
            showNotify(data.errMsg  , 'success' );
            //showInfo(data.msg , data.errMsg);
            $scope.getContactList();
            
            if( data.status ){
               $scope.addContact.contact_name  =   '';   
               $scope.addContact.contact_email =   '';
               $scope.addContact.location_name =   '';
            }
            
        });
    };
      
    $scope.addNewLocationMap    =   function(){
        
        var input   =   {
            manager_id      :    $scope.addAM.userName ,
            location        :    $scope.addAM.location 
//            production_area :    $scope.addAM.productionArea
        };
        
        var request     =   $http({
            method : 'post' , 
            url : 'insertLocationOfAm' , 
            data : input
        });
        
        request.success( function( response ){
            
            var data    =   angular.fromJson( response );
            showNotify(data.errMsg  , data.errormsg);
            $scope.getAmWithLocation();
            
            $("#edit-addAm-close").click();
            
            if( data.status ){
               $scope.manager_id  =   '';   
               $scope.location =   '';
//               $scope.production_area =   '';
            }
            
            
        });
        
        
    }  
    
    $scope.openAddContact       =   function( ){
        $scope.addContact       =   {};
        $("#show-add-contact").click();
    }
    
    
    $scope.getAmWithLocation    =   function( input_str ){
        
        var input   =   { id : '' };
        $scope.locationWithAmList   =   null;
        $http.get( BASE_URL+"locationWithAm" ).then( 
            function mySuccess( response ){ 
               $scope.locationWithAmList   =  response.data.locationAm;
            },
            function myError( response ){  }
        );

    };
    
    $scope.getallPMWithLocation     =   function( input_str ){
        
        var input   =   { id : '' };
        $scope.pmlocationlist       =   null;
        $http.get( BASE_URL+"pmlocationlist" ).then( 
            function mySuccess( response ){ 
               $scope.pmlocationlist   =  response.data.locationAm;
            },
            function myError( response ){  }
        );

    };
    
    $scope.getContactList = function( input_str ){
        
        var input   =   { id : '' };
        
        $scope.contactList  =   null;
        
        $http.get(  BASE_URL+"getContactDetails" , input ) .then(
                
             function mySuccess( response ){  
                 console.log( response.data );
                 $scope.contactList   =   response.data.contacts; 
                 console.log($scope.contactList);
             } ,              
             function myError( response ){ 
             
             }
                  
        );
        
    }
    
    $scope.tabSelectMapping = function () {       
       $scope.getAmWithLocation();       
    };
  
    $scope.getAllLocations     =       function(){
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getLocations" ).then( 
            function mySuccess( response ){
                console.log( "get location data" + response.data );
                $scope.locationList     =       response.data.location;
                
            } , 
            function myError( response ){     
            
        });
        return $scope.locationList;
    }
        
    $scope.contactEdit  =   function( obj ){
        
        $scope.update          =        {};
        $scope.update.contactId    =   obj.ID;
        $scope.update.contactName  =   obj.CONTACT_NAME;
	$scope.update.contactEmail =   obj.CONTACT_EMAIL;
	$scope.update.locationId   =   obj.LOCATION_ID.toString();
        //$scope.update.contactStatus   =   obj.STATUS;
        
        console.log( $scope );
        
        $("#show-edit-contact").click();
        
    }    
        
    $scope.mappedLocationEdit  =   function( obj ){
        
        $scope.getAMUserList();
        $scope.getProductionArea();
        
        $scope.AmUpdate        =        {};
        $scope.AmUpdateID     =   obj.ID;
        
        if( obj.LOCATION_NAME )
            $scope.AmUpdatelocation   =    obj.LOCATION_NAME;
        
        if( obj.PRODUCTION_AREA_ID )
            $scope.AmUpdateproductionArea =   obj.PRODUCTION_AREA_ID.toString();
        
        if( obj.ACCOUNT_MANAGER_ID )
            $scope.AmUpdateuserId       =   obj.ACCOUNT_MANAGER_ID.toString();
        
        
        $("#editLocationMapping").click();
        
    }
    
    /*
    *  update contact Infomation
    *  This method update the given value as a Contact information.
    */
   
    $scope.updateContact        =       function(){
        
        console.log( ' contact update information   : '+$scope.update );
        if($scope.update.contactId == '' || $scope.update.contactId == "undefined")
        {
            showNotify('Kindly check all fields'  , 'danger' );
            return false;
        }
        var inp         =       $scope.update;
        $http.post( BASE_URL+"updateContact", inp ) .then(function mySuccess(response) {
            
            var res = response.data;	
            $scope.update          =        {};
            $scope.getContactList();
            console.log( 'contact update print Log : '+JSON.stringify( response.data ) );
            var data        =       angular.fromJson( response.data );
            showNotify(data.errMsg  , 'success' );
            //showMessage('Contact', 'Contact Information Updated Successfully.', 'success' );
            
            $("#edit-close").click();
            
        }, 
        function myError(response) {
            $scope.getContactList();
        });
        
    }
    
    $scope.updateLocationMap    =   function()
    {
        var inp         =       {
                                    ID : $scope.AmUpdateID,
                                    userroleid :$scope.AmUpdateuserId,
                                    location :$scope.AmUpdatelocation
//                                    productionArea :$scope.AmUpdateproductionArea
                                }
        console.log(inp);
        $http.post( BASE_URL+"updateLocationWithAm", inp ) .then(function mySuccess(response) {
            
            var res = response.data;	
            $scope.Amupdate          =        {};
            showNotify(response.data.msg , response.data.errormsg);
            $scope.getAmWithLocation();
            $("#edit-Am-close").click();	
        }, 
        function myError(response) {
            $scope.getAmWithLocation();        
        });        
        
    }
        
    /*
    *  Delete contact Infomation
    *  This method deletes the given Contact information.
    */
   
    $scope.deleteContact = function(contactId) {
       
        bootbox.confirm("Are you sure you want to delete?", function(result) {
            if(result) {
                
		var inp = {
                            ID: contactId
            		  };
                          
		$http.post( BASE_URL+"deleteContact", inp ) .then(function mySuccess(response) {
                    var res = response.data;	
                    
                    console.log( 'Print Log : '+response.data );
                    showNotify('Contact Information successfully deleted.' , 'success' );
                    $scope.getContactList();
                    
		}, 
                
                function myError(response) {
                    $scope.getContactList();
		});
                
            }
	});	
    };    
        
    $scope.deleteMappedLocation = function(id,status) {
       
        
                
		var inp = {
                            ID: id,
                            STATUSID : status
            		  };
                          
		$http.post( BASE_URL+"deleteAmLocation", inp ) .then(function mySuccess(response) {
                    var res = response.data;	
                    
                    console.log( 'Print Log : '+response.data );
                    showNotify(response.data.msg , response.data.errormsg);
                    $scope.getAmWithLocation();
		}, 
                
                function myError(response) {
                    $scope.getAmWithLocation();
		});
                
    };    
        
    $scope.getAllLocations();
   
    $scope.getContactList();
   
    $scope.contactImport    =   function(){
        var exelFile    =   $scope.uploadedFile;
        if( exelFile == "" || typeof exelFile == "undefined" ) {
                $scope.progress_upload = 'Please select a file for upload.';
                angular.element('#upload-file-errors').addClass("alert alert-danger").show();
            } else {
                    $scope.upload_btn   =   true;
                    angular.element('#loading_status').show();
                    var fileName = exelFile.name;
                    var extn = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
                    console.log( exelFile );
                      
                    if (extn == "xls" || extn == "xlsx"  ){
                        
                        $http.post( BASE_URL+"contactImport" , exelFile ).then(function mySuccess(response) {
                            console.log( 'After upload' );
                            console.log( response.data );
                            if( response.data.status == 1 ){    
                                console.log( 'uploaded successfulluy' );
                                console.log( 'insertion process initialized' );
                                $scope.importContactInfoToDB(response.data.fileName);	
                                
                            }else{
                                
                                showNotify( response.data.errMsg , 'danger' );
                                
                            }
                            return false;

                        }, 
                        function myError(response) {
                                 console.log(response);
                        });	
                            
                    } else {
                            $scope.progress_upload = 'Please upload only excel file.';
                    }

                    // if( angular.element('#upload-file-errors').text() !== '' )
                    //angular.element('#upload-file-errors').addClass("alert alert-danger").show();                        

            }          
        setTimeout( function(){  angular.element('#upload-file-errors').hide(); } , 10000 );
    }
    
    $scope.openUpload   =   function(){
        $scope.uploadedFile = "";
        $("#exel_upload").click();
        $scope.progress_upload = "";
        
    } 
    
    $scope.openAddLocation    =   function(){
        $scope.addAM    =   {};
        $scope.getProductionArea();
        $scope.getAMUserList();
        $("#AddLocationMapping").click();
        
    }
    
    $scope.getProductionArea        =       function(){ 
        
        $scope.productionArea      =        null;   
        
        $http.get( BASE_URL+"getProductionArea" ).then( 
            function mySuccess( response ){
                console.log( "get pro location data" + response.data[1] );
                
                $scope.productionArea     =       response.data;                   
                
            } , 
            function myError( response ){     
            
        });     
    }
    
    $scope.importContactInfoToDB    =   function( fileName ){
       
        console.log( 'file name upload as :' + fileName );
        
        var inp = {
                    userId      :   '' , 
                    fileName    :   fileName
                  };
			
	$http.post( BASE_URL+"importContactInfoToDB", inp ).then(function mySuccess(response) {
        
        console.log(' imported response '+response.data );
            $scope.upload_btn   =   false;
            angular.element('#loading_status').hide();
            $scope.uploadedFile = "";
            if(response.data.status == 1 ){
                $scope.progress_upload = response.data.msg;
                angular.element('#upload-file-errors').removeClass().addClass("alert alert-success").show(800);
            } else {               
                $scope.progress_upload = response.data.msg;
                angular.element('#upload-file-errors').removeClass().addClass("alert alert-danger").show( 800 );
                angular.element("input[type='file']").val(null);                         
            }
            $("#exel_upload").val('');
            
            if( response.data.status == 1 ){
                if( response.data.otherParams !== undefined ){
                    $("#import_report").html( response.data.otherParams );
                }
            }
            
            setTimeout( function(){  angular.element('#upload-file-errors').hide(); } , 10000 );            
            $scope.getContactList();
            
	}, 
	function myError(response) {
            console.log(' upload response '+response);
	});
        
    }
    
    $scope.getAMUserList =   function(){
          
        $scope.amUSerList     =   null;        
        $http.get( BASE_URL+"getAmUserList" ).then( 
            function mySuccess( response ){
                console.log( "get Am user data" + response.data );
                $scope.amUSerList     =       response.data;                
            } , 
            function myError( response ){     
            
        });
        return $scope.amUSerList;
        
    };
        
    $scope.downloadContactTemplate      =   function(){
       
       $http.get( BASE_URL+"downloadContactTemplate" ).then( 
            function mySuccess( response ){
            }, 
            function myError( response ){
        });     
        
    }
    
    $scope.openAddProductionLocation  =   function(){
        $scope.getPrdlinfo();
        $scope.prdl    =   {};
        $("#AddprdLocation").click();
        
    }
    
    //production angular controller 
    
   $scope.getPrdlinfo           =   function(){
       
        $scope.prdLocList       =   null;
        var input               =   {};
        $http.get( BASE_URL+"getProductionLocation" , input ) .then(
                
             function mySuccess( response ){  
                 $scope.prdLocList   =   response.data.locations; 
             } ,              
             function myError( response ){ 
             
             }
        );
    }
    
   

    $scope.tabSelectPrdl = function () {       
       $scope.getProductionLocationList();       
    };
    
    $scope.tabPmlocation    = function () {       
       $scope.getallPMWithLocation();       
    };
    
   $scope.addNewPrdLocation     =       function(){
       
        var input = {
            prdlid          :       $scope.prdl.prdlname ,
            ftphost         :       $scope.prdl.ftphost ,
            ftpusername     :       $scope.prdl.ftpusername ,
            ftppassword     :       $scope.prdl.ftppassword ,
            ftppath         :       $scope.prdl.ftppath             
        };        
        
        var request     =   $http({
                                    method  :   "post",
                                    url     :   "insertProductionLocation",                                   
                                    data    :   input 
                                 });
                                 
        request.success( function( response ) {
            
            $( '#addPrdloc-close' ).click();
            
            var data        =       angular.fromJson( response );
            showNotify(data.errMsg , data.msg);
            $scope.getProductionLocationList();
            
            if( data.status ){
               $scope.prdl  =   '';   
            }
            
        });
   }
   
   $scope.getProductionLocationList     =       function(){
       
       $scope.productionlocationList     =   null;    
       
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.productionlocationList     =       response.data.locations;
            } , 
            function myError( response ){                 
            });
   
   }
   
   $scope.getProductionLocationList();
  
   $scope.prodLocationEdit      =       function( inp_data ){
       $scope.getPrdlinfo();
       $('#editPrdLocation').click();
       $scope.prdlUpdate        =        {};
       $scope.prdlUpdate.prdlid    =   inp_data.ID;
       $scope.prdlUpdate.prdloc    =   inp_data.PRODUCTION_LOCATION_ID.toString();
       $scope.prdlUpdate.ftphost    =   inp_data.FTP_HOST;
       $scope.prdlUpdate.ftpusername    =   inp_data.FTP_USER_NAME;
       $scope.prdlUpdate.ftppassword    =   inp_data.FTP_PASSWORD
       $scope.prdlUpdate.ftppath    =   inp_data.FTP_PATH;
   
   }
   
   $scope.updatePrdLocation     =       function(){
       if($scope.prdlUpdate.ID == '' || $scope.prdlUpdate.ID == "undefined")
        {
            showNotify('Kindly check all fields'  , 'danger' );
            return false;
        
        var inp         =       $scope.prdlUpdate;
        $http.post( BASE_URL+"updateProductionLocation", inp ) .then(function mySuccess(response) {
            
            var res = response.data;	
            $scope.prdlUpdate          =        {};
            $scope.getProductionLocationList();
            var data        =       angular.fromJson( response.data );
            showNotify(data.errMsg , data.msg );
            $("#edit-prdloc-close").click();
            
        }, 
        function myError(response) {
            $scope.getProductionLocationList();        
        });
        
       
   }
   
   $scope.deleteProdLocation    =       function( rowid ){
             
                
		var inp = {
                            ID: rowid
            		  };
                          
		$http.post( BASE_URL+"deleteProductionLocation", inp ) .then(function mySuccess(response) {
                    var res = response.data;	
                    showNotify('Location Information Deleted Successfully.', 'success' );
                    $scope.getProductionLocationList();
                    
		}, 
                
                function myError(response) {
                    $scope.getProductionLocationList();
		});
                
            
	}
        
   
   
   $scope.savePmPrdlMapping     =       function(){
       
       console.log( $scope.addprdl );
       
        var input = {
            prdl    :       $scope.addprdl.prodlocName         
        };        
       
        var request     =   $http({
                                    method  :   "post",
                                    url     :   "insertPmProductionLocation",                                   
                                    data    :   input 
                                 });
                                 
        request.success( function( response ) {
            console.log(response);
            var data = response;
            showNotify(data.errMsg, 'danger' );
        });
       
   }
   
    $scope.getPMWithLocation    =   function( ){
        
        $scope.locationWithPmList   =   null;
        $http.get( BASE_URL+"locationWithPm" ).then( 
            function mySuccess( response ){ 
               $scope.locationWithPmList   =  response.data.locationPm;
               var data =   $scope.locationWithPmList;
                $scope.addprdl.prodlocName =   ( data[0]['PRODUCTION_AREA_ID'] );
            },
            function myError( response ){  }
        );

    };
    
    $scope.getPMWithLocation();
    
     // Set the default value of inputType
    $scope.inputType = 'password';

    // Hide & show password function
    $scope.hideShowPassword = function(){
      if ($scope.inputType == 'password')
        $scope.inputType = 'text';
      else
        $scope.inputType = 'password';
    };
    
}
}
);