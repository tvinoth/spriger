/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout,$location, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder,fileUploadService) 
{
    $scope.userId 	=   '0';	
    $scope.menuParent 	=   'Customization';
    $scope.menuChild 	=   'Email Notification Setup';
    $scope.errorMsg 	=   "";
    $scope.stgaelist    =   [];
    $scope.roundlist    =   [];
    $scope.statusenum   =   [{'STATUS_ID':1,'NAME':'ACTIVE'},{'STATUS_ID':0,'NAME':'IN ACTIVE'}];
    $scope.editeditem   =   {};
    if(isNaN(getUrlParameter(1))) 
    {
        $scope.JobID 	=   "";
    } 
    else 
    {
        $scope.JobID 	=   getUrlParameter(1);
    }
	
    $scope.addnewstage  =   function()
    {
        var exelFile            =   $scope.myFile;
        if( $scope.roundmodel   ==   undefined || $scope.stagemodel   ==   undefined || $scope.toemail   ==   undefined || $scope.subject   ==   undefined) 
        {
            $scope.adderrorMsg  =   'all fields are required';
            showNotify($scope.adderrorMsg  , 'danger' );
            return false;
        }
        var checktoemail        =   $scope.toemail.indexOf(",");
        $scope.validtoemailidres    =   $scope.validateemailid(checktoemail,$scope.toemail);
        if($scope.validtoemailidres     ==  false)
        {
            showNotify('Invalid Email Id', 'danger' );
            return false;
        }
        
        if($scope.ccemail   !=   undefined)
        {
            var checkccemail            =   $scope.ccemail.indexOf(",");
            $scope.validccemailidres    =   $scope.validateemailid(checkccemail,$scope.ccemail);
            if($scope.validccemailidres   ==  false)
            {
                showNotify('Invalid Email Id', 'danger' );
                return false;
            }
        }
        
        if( exelFile ==     "" ||   exelFile == undefined ) 
        {
            $scope.adderrorMsg  =   'Kindly upload file';
            showNotify($scope.adderrorMsg  , 'danger' );
            return false;
        } 
        else 
        {
            showLoader('Please wait while add new setup...'); 
            $scope.fileupload   =   true;
            var uploadUrl       =   BASE_URL+"emailsetup/addnewemailsetupstage";
            promise             =   fileUploadService.uploadFileToUrl(exelFile,$scope.roundmodel,$scope.stagemodel,$scope.componentmodel,$scope.subject,$scope.toemail,$scope.ccemail,'','','insert', uploadUrl);
            promise.then(function (response) 
            {
                if(response.data.result  ==  200)
                {
                    $scope.roundmodel   =   undefined;
                    $scope.subject      =   undefined;
                    $scope.stagemodel   =   undefined;
                    $scope.toemail      =   undefined;
                    $scope.ccemail      =   undefined;
                    $scope.myFile       =   undefined;
                    $scope.componentmodel   =   undefined;
                    $scope.getemailStageList();
                    $(".ace-file-name").attr('data-title','No File ...');
                    angular.element(document.getElementById("loading_status")).remove();
                    showNotify(response.data.errMsg  , 'success' );
                }
                hideLoader();
            }, function (errorresponse) 
            {
                hideLoader();
                if(errorresponse.data.errMsg)
                {
                    showNotify(errorresponse.data.errMsg  , 'danger' );
                }
                $scope.fileupload   =   false;
                showNotify("Internal server error try again...", 'Warning');
            });
        } 
    }
    
    $scope.resetForm    =   function()
    {
        $scope.roundmodel   =   undefined;
        $scope.stagemodel   =   undefined;
        $scope.toemail      =   undefined;
        $scope.ccemail      =   undefined;
        $scope.myFile       =   undefined;
        $scope.subject      =   undefined;
        $scope.fileupload   =   false;
        $(".ace-file-name").attr('data-title','No File ...');
    }
	
    $scope.currentuserid    =   '';
    
    $scope.openchapterlistdetails   =   function(book)
    {
        $window.location.href       = 	BASE_URL+"remainderchapterlist/"+book.JOB_ID;
    }
    
    $scope.contentloadtimer     =   1;
    $scope.getemailStageList	= 	function() 
    {
        $scope.emaillist    = 	[];
        $http.get(BASE_URL+"emailsetup/dogetemailstagelist").then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
            }
            $scope.emaillist        = 	response.data.emaillist;
            $scope.stgaelist        = 	response.data.stgaelist;
            $scope.component        = 	response.data.component;
            $scope.roundlist        = 	response.data.roundlist;
            $scope.userId           =   response.data.userId;
        }, 
        function myError(response) {
            if($scope.contentloadtimer    <  10){
                $scope.getemailStageList();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
        });	
        $scope.contentloadtimer++;
    };
    
    $scope.emaillistselected        =   {};    
    $scope.getTemplate  =   function (contact) {
        if (contact.ID === $scope.emaillistselected.ID) return 'edit';
        else return 'display';
    };

    $scope.editStage    =   function (contact) {
        $scope.emaillistselected    =   angular.copy(contact);
    };
    
    $scope.showSuccessredologview   =   function(item){
        var inp     =   {   
                            emailstageid:   item
                        };
        $http.post(BASE_URL+'emailsetup/viewemailsetupcontent',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Email Setup Stage View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    $scope.showplaceholder  =   function()
    {
        var placeholdercontent     =   "[bookid] , [to_name] ,[contact_personname], [chapter_no], [stage_name] ,[round_name], [am_name],[pm_name]";
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Email Setup Placeholder View";
        $('#redofailed').html('<p class="text-left">'+placeholdercontent+'</p>');   
    }
    $scope.undostage    =   function () {
        $scope.emaillistselected    =   {};
    };
    
    $scope.validateemailid  =   function(checkmultipleemail,currentemailvaluevalid)
    {
        var emailReg        =   /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
        var validationfailedorsuccess   =   true;
        if(checkmultipleemail !==   -1)
        {
            var morethanemailvalid  =   currentemailvaluevalid.split(',');
            angular.forEach(morethanemailvalid, function(value, key) {
                if(value != ''){
                    if(!(value).match(emailReg)){
//                        $('.ccemailstage').css('border','1px solid #f37070'); 
                        return validationfailedorsuccess = false;
                    }else{
//                        $('.ccemailstage').css('border','1px solid #d5d5d5'); 
                        return validationfailedorsuccess   =   true;
                    }}
                });
        }else{
            if(!(currentemailvaluevalid).match(emailReg)){
//                $('.ccemailstage').css('border','1px solid #f37070'); 
                validationfailedorsuccess   =   false;
            }else{
//                $('.ccemailstage').css('border','1px solid #d5d5d5'); 
                validationfailedorsuccess   =   true;
            }
        }
        return validationfailedorsuccess;
    }
    
            
    $scope.updateexiststage     =   function(position,item)
    {
        var getroundvalue       =   $("#roundmodel_"+position).val();
        var getstagevalue       =   $("#stagemodel_"+position).val();
        var getcompntvalue      =   $("#componentmodel_"+position).val();
        var getsubjectvalue     =   $("#emailsubject_"+position).val();
        var gettoemailvalue     =   $("#emailtocontent_"+position).val();
        var getccemailvalue     =   $("#emailcccontent_"+position).val();
        var getstatusvalue      =   $("#statusmodel_"+position).val();
        var updateexistidval    =   item.ID;
        var tempFile            =   angular.element(document.getElementById("updateemailtemp").files[0]);
        if( (getroundvalue      ==   undefined || getroundvalue     ==  '') || (getsubjectvalue       ==   undefined || getsubjectvalue     ==  '') || (getstagevalue       ==   undefined || getstagevalue     ==  '') || (gettoemailvalue       ==   undefined || gettoemailvalue     ==  '') || (getstatusvalue       ==   undefined || getstatusvalue     ==  '')) 
        {
            $scope.adderrorMsg  =   'all fields are required';
            showNotify($scope.adderrorMsg  , 'danger' );
            return false;
        }
        var checktoemail            =   gettoemailvalue.indexOf(",");
        $scope.validtoemailidres    =   $scope.validateemailid(checktoemail,gettoemailvalue);
        if($scope.validtoemailidres ==  false)
        {
            showNotify('Invalid Email Id', 'danger' );
            return false;
        }
        if(getccemailvalue   !=   '')
        {
            var checkccemail            =   getccemailvalue.indexOf(",");
            $scope.validccemailidres    =   $scope.validateemailid(checkccemail,getccemailvalue);
            if($scope.validccemailidres ==  false)
            {
                showNotify('Invalid Email Id', 'danger' );
                return false;
            }
        }
        
//        if( tempFile ==     "" ||   tempFile == undefined ) 
//        {
//            $scope.adderrorMsg  =   'Kindly upload file';
//            showNotify($scope.adderrorMsg  , 'danger' );
//            return false;
//        } 
//        else 
//        {
            showLoader('Please wait while add new setup...'); 
            var uploadUrl       =   BASE_URL+"emailsetup/addnewemailsetupstage";
            promise             =   fileUploadService.uploadFileToUrl(tempFile[0],getroundvalue,getstagevalue,getcompntvalue,getsubjectvalue,gettoemailvalue,getccemailvalue,updateexistidval,getstatusvalue,'update', uploadUrl);
            promise.then(function (response) 
            {
                if(response.data.result  ==  200)
                {
                    $scope.undostage();
                    $scope.emaillist[position]   =   response.data.validation;
                    showNotify(response.data.errMsg  , 'success' );
                }
                hideLoader();
            }, function (errorresponse) 
            {
                hideLoader();
                if(errorresponse.data.errMsg)
                {
                    showNotify(errorresponse.data.errMsg  , 'danger' );
                }
                showNotify("Internal server error try again...", 'Warning');
            });
//        } 
    }
    
    $scope.removestage  =   function(position,item)
    {
        bootbox.confirm("Are you sure to delete on this ?", function( result ) {
            if(result){
                        
                var inp         =   {   
                                emailstageid:   item
                            };
                $http.post(BASE_URL+'emailsetup/delete',inp).then(function mySuccess(response) {
                    if(response.data.status == 1) 
                    {   
//                        var index       =   $scope.emaillist.indexOf(position);
//                        $scope.emaillist.splice(index, 1); 
                        $scope.emaillist.splice(position, 1); 
                        showNotify(response.data.errMsg, 'success' );
                    } 
                    else
                    {
                        showNotify(response.data.errMsg, 'danger' );
                    }
                },function myError(response) {
                    showNotify(response.data.errMsg,'danger' );
                });
            }
        });
    }
    
    $scope.getemailStageList();    
});

ngApp.directive('demoFileModel', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) 
            {
                var model 	= 	$parse(attrs.demoFileModel),
                modelSetter     = 	model.assign; //define a setter for demoFileModel
        
                //Bind change event on the element
                element.bind('change', function ($scope) 
				{
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                        //set the model value
                        modelSetter(scope, element[0].files[0]);
			$scope.bookmapUploadMsg 	=	'';
                        $(".ace-file-name").attr('data-title',element[0].files[0].name);
                    });
                });
            }
        };
    });
	    
    ngApp.service('fileUploadService', function ($http, $q) 
    {
            this.uploadFileToUrl 	= 	function (file,roundId,stageId,componentId,subject,toemail,ccemail,existid,statusval,type, uploadUrl) 
            {
            var fileFormData 	= 	new FormData();
            fileFormData.append('emailsetupfile', file);
			fileFormData.append('roundId', roundId);
			fileFormData.append('stageId', stageId);
                        fileFormData.append('componentId', componentId);
			fileFormData.append('emailsubject', subject);
			fileFormData.append('toemail', toemail);
			fileFormData.append('ccemail', ccemail);
                        fileFormData.append('existId', existid);
                        fileFormData.append('Typeofrequest', type);
                        fileFormData.append('statusEnum', statusval);
            var deffered 		= 	$q.defer();
            $http.post(uploadUrl, fileFormData, 
			{
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
 
            }).then(function mySuccess(response) 
			{
                deffered.resolve(response);
 
            },
			function myError(response) 
			{
				deffered.reject(response);
			});
            return deffered.promise;
        }
    });