/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ($scope, $http , $window , $timeout ,DTOptionsBuilder, DTColumnBuilder) {
	
	$scope.projectList = [];
	$scope.showProject = false;
	
	$scope.menuParent = 'Project List';
	$scope.menuChild = 'Project List';
	/*
	 *  Show Project List
	 *  This method pass the user id, team id of the logged in user and get the list of projects for this user.
         *  
	*/
        $scope.contentloadtimer     =   1;
	$scope.showProjectList = function() {
            
		$scope.jobAssignedList = [];
                
		var inp = {	user_id : '', team_id : ''};
                $http.post(API_URL+"getJobList",inp) .then(function mySuccess(response) {
                
                $scope.jobAssignedList  =   response.data.assignjob;
                $scope.userlist         =   response.data.teamMember;
                $scope.AmMember         =   response.data.AmMember;
                $scope.vm = {};
                $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
                
		}, 
		function myError(response) {
                    if($scope.contentloadtimer    <  10){
                    $scope.showProjectList();
                    }
                    if($scope.contentloadtimer    ==  10){
                        showNotify('Kindly reload page error occured.'  , 'danger' );
                        return false;
                    }
		});
                $scope.contentloadtimer++;
                
	};
        
        $scope.showProjectList();
        
        //show meta extrator remarks commands
        $scope.showMeataextratorremarksview = 	function(params){   

             var printMsg    =   ( params.UPDATE_REMARKS == null ) ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	
        
        //show meta extrator remarks commands
        $scope.showUploadRemarksview = 	function(params){   
             var printMsg    =   ( params.UPLOAD_REMARKS == null ) ? 'remarks not found..' : params.UPLOAD_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Uploade";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	

        $scope.sendRedoExtration 			= 	function(params){   
            
           console.log( params );
           var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
           $('#show-redo').trigger('click');
           $scope.Msgbox 	=	"Success Redo";
           $('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
        
        $scope.showRedoview =   function(params){
             var printMsg    =   ( params.SR_REMARKS == null ) ? 'remarks not found..' : params.SR_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Client Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
        
        $scope.showSuccessredologview   =   function(typeoflog,item){
            var inp     =   {   
                                typeoflog   :   typeoflog,
                                clientid:   item.CLIACKID,
                                jobID   :   item.JOB_ID,
                                roundID :   item.ROUND_ID
                            };
            $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
                if(response.data.status == 1) 
                {      
                    hideLoader();
                    $('#show-redo').trigger('click');
                    $scope.Msgbox 	=	"Success/Redo Log View";
                    $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
                } 
                else
                {
                    showNotify(response.data.errMsg, 'danger' );
                }
            },function myError(response) {
                showNotify(response.data.errMsg,'danger' );
            });
        }
    
        $scope.retryJobsheetUpdate 			= 	function(params){   
           var printMsg     =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
           showLoader();
           var jobid        =   params.JOB_ID;           
           var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID;  
           
           $http.get(BASE_URL+dynamic_url) .then(function mySuccess(response) {
            
                if(response.data.status == 1) {      
                  $timeout( function(){  
                    hideLoader();
                    showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                    
                    $timeout( function(){  
                       $window.location.reload();
                    }, 2000 );
                   
                   }, 5000 );                   
		}else if( response.data.status == 0 ){
                     showNotify( response.data.errMsg , 'danger' )
                     hideLoader();
                } else {
                    hideLoader();        
                    showNotify( 'Request got failed..' , 'danger');
		}
                
            },function myError(response) {
                console.log(response);
                showNotify( 'Oops, Kindly reload the page...' , 'danger' );
            });
	
           //$('#show-redo').trigger('click');
           //$scope.Msgbox 	=	"Success Redo";
           //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
	
        
        $scope.tapsType     =   function(item,typeofrequest)
        {   
              var tapstype = angular.element("#gettapstype_"+item.JOB_ID+'_'+item.ROUND_ID).val();
              if(tapstype  == ''){
                        hideLoader();
                    //    showNotify( 'Successully assign' , 'success' );                        
                        return false;
                    }
            
            bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
            {     
                if( result )
                {       
                    var adddisable  =   $("#gettapstype_"+item.JOB_ID+'_'+item.ROUND_ID).attr('disabled','disabled');
                    
                    var tapstype = '3';
                
                    showLoader( 'please wait for a while...' );
                    var inp     =   {	
                                        jobId : item.JOB_ID, 
                                        metadataId  :   '',
                                        tapstype    :   '3',
                                        ChapterNo   :   '',
                                        ChapterTitle    :   '',
                                        roundid :item.ROUND_ID
                                    };   
                        $http.post(API_URL+"dosfiftymovenonTaps", inp ).then(function mySuccess(response) 
                        {
                            hideLoader();
                            if( response.data.status == 1 ){
                                var appenddata  =   '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for womat response</code>';
                                if(typeofrequest    ==  'failed')
                                {
                                    angular.element("#removeredo_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                    angular.element("#movetowomat_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                }
                                angular.element("#movetowomat_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                angular.element("#movetowomatres_"+item.JOB_ID+'_'+item.ROUND_ID).append(appenddata);
                                showNotify( response.data.errMsg , 'success' );
                            }
                            if( response.data.status == 2 ){
                                if(typeofrequest    ==  'failed')
                                {
                                    angular.element("#removeredo_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                    angular.element("#movetowomat_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                }
                                angular.element("#locationshow_"+item.JOB_ID+'_'+item.ROUND_ID).show();
                                angular.element("#movetowomat_"+item.JOB_ID+'_'+item.ROUND_ID).remove();
                                showNotify( response.data.errMsg , 'success' );
                            }
                            if( response.data.status == 401 ){    
                                $scope.errorshow    =   true;
                                $scope.shownotavaiablechapter   =   response.data.errMsg;
                                $(adddisable).removeAttr('disabled');
                            }
                            if( response.data.status == 0 ){
                                $(adddisable).removeAttr('disabled');
                                showNotify( response.data.errMsg , 'danger' );
                            }
                        },function myError(response) {
                            $(adddisable).removeAttr('disabled');
                            hideLoader();
                            showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
                    });
                }

            });
        }
        
        $scope.showTapsremarks =   function(params)
        {
            var printMsg    =   ( params.TAPS_REMARKS == null || params.TAPS_REMARKS == '' ) ? 'remarks not found..' : params.TAPS_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox   =	"Womat Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
   
        $scope.retryJobsheetUpload 			= 	function(params){   
            
           var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
           showLoader();
           showNotify( 'please wait for a while...' , 'success');
           var jobid        =   params.JOB_ID;
           var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID;
           
           $http.get(BASE_URL+dynamic_url) .then(function mySuccess(response) {
            
               hideLoader();
                if(response.data.status == 1) {                    
                   console.log( response.data );
                    $timeout( function(){ 
                        
                    if( response.data.msg == 'Success' ){                        
                        showNotify( response.data.errMsg , 'success' );
                    }
                    else{
                       showNotify( response.data.errMsg , 'danger' );
                    }
                     $timeout( function(){  
                       $window.location.reload();
                     }, 2000 );
                   
                   }, 7000 );
                   
                  
                   
		} else {
                    hideLoader();        
                   showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
		}
                
            },function myError(response) {
                console.log(response);
                showNotify( 'Oops, Kindly reload the page...' , 'danger' );
            });
	
           //$('#show-redo').trigger('click');
           //$scope.Msgbox 	=	"Success Redo";
           //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
	
        $scope.contentloadtimer     =   1;
        $scope.getAllPrdLocations   =   function(){

            $scope.locationList     =   null;        
            $http.get( BASE_URL+"getProductionLocationsList" ).then( 
                function mySuccess( response ){
                    $scope.locationList     =       response.data.locations;                
                } , 
                function myError( response ){   
                    if($scope.contentloadtimer    <  10){
                        $scope.getAllPrdLocations();
                    }
                    if($scope.contentloadtimer    ==  10){
                        showNotify('Kindly reload page error occured.'  , 'danger' );
                        return false;
                    }
            });
            $scope.contentloadtimer++;
            return $scope.locationList;
        }
        
        $scope.getAllPrdLocations();
        
        $scope.assignPm = function( pmselect,item ){
           
           bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
               if( result ){
                   showLoader( 'please wait for a while...' ); 
                   
                   
                   
                    var inp = {	user_id : pmselect, book_id : item.BOOK_ID};
                    $http.post(API_URL+"jobassignPm",inp) .then(function mySuccess(response) {
                        
                        hideLoader();                        
                        if( response.data.status == 1 ){                                 
                            showNotify( response.data.msg , 'success' );
                            $scope.retryJobsheetUpdate( item );
                        }
                        if( response.data.status == 0 ){                                 
                            showNotify( response.data.msg , 'danger' );
                        }
                        
                        /*
                         * 
                         setTimeout( function(){ 
                            $window.location.reload();
                        } , 5000 );
                        
                        */
                    }, 
                    function myError(response) {
                        hideLoader();                        
                         showNotify( 'Oops, Kindly reload the page...' , 'danger');
                    });	
                    
                }    

            });
        }
        
        $scope.assignAm = function(pmselect,item){
            
            bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
            
                if( result ){
                    showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect, book_id : item.BOOK_ID};
                         
                        $http.post(API_URL+"jobassignAm",inp) .then(function mySuccess(response) {
                            hideLoader();
                            
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                             
                             setTimeout(function(){ 
                                 $window.location.reload();
                            }, 5000);
                             
                        }, 
                        function myError(response) {
                            console.log(response);
                            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
                        });	
                        
                }

            });
            
        }
        
        $scope.chgPrdLoc2    =       function( drpdwn , row_info ){
 
            bootbox.confirm("Are you sure to proceed on this ?", function( result ) {

                //$('#xmlContent1').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                showLoader( 'please wait for a while...' );
                if( result ){

                    var inp = {	location_id : drpdwn  , book_id : row_info.BOOK_ID ,  job_id : row_info.JOB_ID  };

                        $http.post( API_URL+"changePrdLocation" , inp ).then(function mySuccess(response) {
                            
                            //$('#xmlContent1').html('');
                            
                            hideLoader();
                            
                            if( response.data.status == 1 ){                                 
                                showNotify( response.data.errMsg , 'success' );
                            }
                             
                            if( response.data.status == 0 ){                                 
                                showNotify( response.data.errMsg , 'danger' );
                            }
                            //showMessage('Message', response.data.errMsg , response.data.msg );               
                        }, 
                        function myError(response) {
                            
                            console.log(response);
                            showNotify( 'Oops, Try again after sometimes' , 'danger' );
                            
                        });

                }
                $('#xmlContent1').html('');
                hideLoader();
            });
        
        }
        $scope.downloadClientAckFiles  = function( params , type  ){
        
        var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID , type : type };
        
        showLoader('Please wait while opening...');                
            
        $http.post( API_URL+"downloadClientAckFailureRetryFiles" , inp ).then(function mySuccess(response) {
            
            if( response.data.status == 1 ){
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 || response.data.status == 'failed'){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });            
        
    };
        $scope.showXMLInModal = function(jobId , round) { 
        
            var inp = { jobId: jobId };
            $('#show-edit').trigger('click');
            $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
            $http({
                    url: API_URL + "getJobXMLInfo/"+jobId+"/"+round,
                    method: 'GET',
                 })
                .success(function(response) {
                    $('#xmlContent').html(response);
                })
                .error(function(response) {
                    console.log(response);
                    $('#xmlContent').html('');
                });
        }     
});