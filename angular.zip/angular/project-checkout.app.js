/*
 *  Check Out Controller
 *  This controller contains all the methods related to check out screen.
 */
ngApp.controller('ngController', function ($scope, $http,$timeout,$interval) {
	
	$scope.JobID = getUrlParameter(2);
	$scope.JobStageID = getUrlParameter(1);
	$scope.noOfAttemptsToCheckIndesign = 10;
	$scope.inddFile = ""; 
	$scope.inddVer = "";
	$scope.batchId = 0;
	$scope.checkoutBtn = "Open File";
	$scope.checkInMsg = "";
	$scope.fileStatus = 0;
	
	/*
	 *  Get Previous Comments
	 *  This method get the comments / remarks for the given stage Id.
	 */
	$scope.showPreviousRemarks = function() {
		var title = 'Previous Stage Comments for Page No(s)', content = '<table id="remarks" class="table table-striped table-bordered "></table>';	
		showInfo(title, content);		
		
		$scope.remarks = [];
		var inp = {	stageId : $scope.JobStageID, opt : 'remarks'};
		
		$http.post(API_URL+"getComments", inp) .then(function mySuccess(response) {
			console.log(response);	
			$scope.remarks = response.data.data;	
			$(document).ready(function() {

				var table = $('#remarks').DataTable( {
					data: $scope.remarks,
					columns: [
						{ data: "page_number", title: "Page No(s)" },
						{ data: "NAME" , title: "Round Name" },
						{ data: "STAGE_NAME" , title: "Stage Name" },
						{ data: "commentedby", title: "Commented By"  },
						{ data: "commentdate", title: "Comment Date"  },
						{ data: "comments", title: "Remarks"  }			
					]
				});
			});
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
	
	/*
	 *  Get Partial Comments
	 *  This method get the comments / remarks for the given stage Id.
	 */	
	$scope.showPartialComments = function() {
		var title = 'Partial Check-out / Check-in Comment(s)', content = '<table id="comments" class="table table-striped table-bordered "></table>';	
		showInfo(title, content);		
		
		$scope.comments = [];
		var inp = {	stageId : $scope.JobStageID, opt : 'comments'};
		
		$http.post(API_URL+"getComments", inp) .then(function mySuccess(response) {
			console.log(response);	
			$scope.comments = response.data.data;	
				$(document).ready(function() {

					var table = $('#comments').DataTable( {
						data: $scope.comments,
						columns: [
							{ data: "CHAPTER_NO", title: "Chapter No" },
							{ data: "user" , title: "User" },
							{ data: "CHECK_OUT" , title: "Check-out Time" },
							{ data: "CHECK_IN", title: "Check-in Time"  },
							{ data: "PROCESS_START_TIME", title: "Background Start Time"  },
							{ data: "PROCESS_END_TIME", title: "Background End Time"  },
							{ data: "INPUT_QUANTITY" , title: "Input Quantity" },
							{ data: "OUTPUT_QUANTITY", title: "Output Quantity"  },
							{ data: "REMARKS" , title: "Remarks" }							
						]
					});
					
				});
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
	/*
	 *  Download Font files
	 */	
	$scope.downloadFiles = function(fontPath, opt) {
		var method = "";

		if(opt == "Fonts") showLoader('Please wait while downloading fonts...');
		else  showLoader('Please wait while opening sample files...');
		
		if(opt == "Fonts" ) method = "downloadfonts"; 
		else method = "openLocalDrive";
		
		var inp = {filePath : fontPath,
		   projectId : "",
		   methodName : method,
		   inddVersion : "",
		};
		$http.post(API_URL+"saveRMIInfo", inp).then(function mySuccess(response) {
			console.log(response.data[0].rmiId);
			
			if(response.data[0].rmiId > 0) {
				var attempt = 0;
				$scope.checkRmiStatus(response.data[0].rmiId, attempt, opt);
			} else {
				hideLoader();
				showMessage('Download Status', 'Having problem in insert data.', 'success');
			}
		//	window.location.href=BASE_URL+"check-out";
			
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  Check RMI Status
	 *  This method check the RMI status for the selected folios.
	 */
	$scope.checkRmiStatus = function(rmiId, attempt, opt) {
		var inp = {rmiID : rmiId};
		$http.post(API_URL+"checkRMIStatus", inp).then(function mySuccess(response) {
			console.log(response);
			$scope.IsRunning = response.data[0].is_running;   // status, remarks
			if(response.data[0].status == 1) {
				if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
					hideLoader();
					if(opt == "Fonts") {
						showMessage('Download Status', 'Font Downloaded successfully.', 'success');
					} else if(opt == "InDesign") {
						hideLoader();
						$scope.checkoutBtn = "Open File";
						showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
						//$scope.checkFileStatus();
						$scope.checkoutProcess();
					} else {
						showMessage('Download Status', 'Folder Opened Successfully.', 'success');
					}
					
				} else {
					hideLoader();
					showMessage('Download Status', response.data[0].remarks, 'error');
				}
			} else {
				attempt++;
				if(attempt < $scope.noOfAttemptsToCheckIndesign) {
					 $timeout( function(){ $scope.checkRmiStatus(rmiId, attempt, opt); }, 10000);
				} else {
					hideLoader();
					showMessage('Download Status', "File handler is not running. Please check.", 'error');
				}
			}
		}, 
		function myError(response) {
			 console.log(response);
		});		
	};
	/*
	 *  Checkout process
	 *  This method creates entry in work log table and update checkout time in job_stage table
	 */
	$scope.checkoutProcess = function() {
		var inp = {jobId : $scope.JobID, jobStageId : $scope.JobStageID, userId: '', teamId: ''};
		console.log(inp);
		$http.post(API_URL+"checkoutProcess", inp).then(function mySuccess(response) {
			console.log(response);
			showMessage('Check Out', 'Page(s) opened successfully.', 'success');
			$scope.checkFileStatus();
		}, 
		function myError(response) {
			 console.log(response);
		});	
	};

	/*
	 *  Check out files
	 */	
	$scope.checkoutFiles = function() {	
		var checkbox_count = $("input[name='check_instruction']").size();
		var checked_count = $("input[name='check_instruction']:checked").size();	
		if(checkbox_count  == checked_count){
			showLoader('Please wait while opening InDesign file...');
			
			var inp = {jobId: $scope.JobID, jobStageId: $scope.JobStageID};
			$http.post(API_URL+"getCheckoutInfo", inp).then(function mySuccess(response) {
				$scope.inddFile = response.data[0].indd_file_path+""+response.data[0].indd_file_name; 
				$scope.inddVer = response.data[0].indd_version;
				$scope.batchId = response.data[0].batch_id;
				$scope.checkoutThroughRmi();	
			}, 
			function myError(response) {
				 console.log(response);
			});			
		} else {
			showMessage('Check Out', 'Please read and select all the page instructions.', 'success');
		}
	};
	/*
	 *  Checkout files through RMI
	 *  This method check out the selected folios using RMI
	 */
	$scope.checkoutThroughRmi = function() {
		
		var inp = {filePath : $scope.inddFile,
				   projectId : $scope.batchId,
				   methodName : 'launchindd',
				   inddVersion : $scope.inddVer ,
				  };
		$http.post(API_URL+"saveRMIInfo", inp).then(function mySuccess(response) {
			console.log(response.data[0].rmiId);
			
			if(response.data[0].rmiId > 0) {
				var attempt = 0;
				$scope.checkRmiStatus(response.data[0].rmiId, attempt, 'InDesign');
			} else {
				hideLoader();
				showMessage('Check Out', 'Having problem in insert data.', 'success');
			}
		//	window.location.href=BASE_URL+"check-out";
			
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	/*
	 *  Watch Indesign Close
	 *  This method get the workflow details for the given job and stage Id.
	 */	
	$scope.checkFileStatus = function() {
		var inp = {batchId : $scope.batchId};
		console.log(inp);
		$http.post(API_URL+"getFileStatus", inp).then(function mySuccess(response) {
			console.log(response);
			if(response.data.file_status == 1 || response.data.file_status == 2 ) {
				$scope.fileStatus = response.data.file_status;
				$("#chkout").click();
				hideMessage();
			
			} if(response.data.file_status == 4) {
				showMessage('Check Out', 'Unable to open the file!', 'success');
			} if(response.data.file_status == 5) {
				showMessage('Check Out', 'File does not exists!', 'success');
			} else {
				console.log('repeat');
				$timeout( function(){ $scope.checkFileStatus(); }, 1000);
			}
		}, 
		function myError(response) {
			 console.log(response);
		});
	};
	
	/*
	 *  Check In Files
	 *  This method get the workflow details for the given job and stage Id.
	 */	
	 $scope.checkIn = function() {
	 
		var inp = {jobId : "84433", jobStageId: "234,255,248,241", batchId: 144, selectedPages: '1,2,3,4', fileStatus:$scope.fileStatus };
		console.log(inp);
		
		$http.post(API_URL+"checkInProcess", inp) .then(function mySuccess(response) {
			console.log(response);
		},
		function myError(response) {
			 console.log(response);
		});			
		 
	 };
	 $scope.checkIn ();
			
	 $scope.checkInFiles = function() {
		var checkbox_count = $("input[name='chk_ins']").size();
		var checked_count = $("input[name='chk_ins']:checked").size();	
		if(checkbox_count  == checked_count){
			$scope.checkInMsg = "";
			var chkFolioCnt = $("input[name='chk_folio']:checked").size();	
			alert(chkFolioCnt);
			var selectedPages = ""; var t = 0;
			$("input[name=chk_folio]:checkbox").each(function() {
				if ($(this).is(":checked")) {
					if(t > 0 ) selectedPages += ",";
					selectedPages += $(this).val();
					t++;
				}
			});
			console.log(selectedPages);
			
			var inp = {jobId : $scope.JobID, jobStageId: $scope.JobStageID, batchId: $scope.batchId, selectedPages: selectedPages , fileStatus:$scope.fileStatus};
			console.log(inp);
			
			$http.post(API_URL+"checkInProcess", inp) .then(function mySuccess(response) {
			},
			function myError(response) {
				 console.log(response);
			});			
				
		
			
		} else {
			$scope.checkInMsg = "Please read and select all the page instructions.";
		}
		 
	 };
	 
	/*
	 *  Check the touched folios
	 *  This will check / uncheck all the folios.
	 */	

	 $scope.chkAllFolios = function() {
		 if ($('#chk_folio_all').is(':checked')) {
			 $('.chk_folio').prop("checked", true); 
		 } else {
			 $('.chk_folio').prop("checked", false); 
		 }
	 };

	/*
	 *  Get Workflow Details
	 *  This method get the workflow details for the given job and stage Id.
	 */	
	$scope.showWorkflow = function() {
		var title = 'View Workflow';	
	    $scope.wkInfo = '';	
		$scope.workflow = []; $scope.stageInfo = []; $scope.roundInfo = [];
		var inp = {	stageId : $scope.JobStageID, job_id : $scope.JobID };
				
		$http.post(API_URL+"getWorkflowDetails", inp) .then(function mySuccess(response) {
			console.log(response);	
			$scope.workflow = response.data.data.workflow;	
			$scope.stageInfo = response.data.data.stageInfo;
			$scope.roundInfo = response.data.data.roundInfo;
			console.log($scope.roundInfo);
			$scope.wkInfo +='<table class="table table-bordered width-70"><tr><th>Project Name </th><td>'+$scope.roundInfo[0]['JOB_TITLE'] +'</td>';
			$scope.wkInfo +='<th>Project Code </th><td> '+$scope.roundInfo[0]['JOB_ID'] +'</td></tr></table>';
			$scope.wkInfo +='<div class="dd" id="nestable"><ol class="dd-list">';
			for(var k=0; k<$scope.workflow.length; k++) {
				$scope.wkInfo +='<li class="dd-item" data-id="'+k+'"><div class="dd-handle orange">';
				if($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
					$scope.wkInfo += "Main Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
					$scope.wkInfo += "Parallel Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
					$scope.wkInfo += "Art Workflow - ";
				} else if($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
					$scope.wkInfo += "Art Correction Workflow - ";
				}
				$scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

				if($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
					$scope.wkInfo += " (";
					if($scope.workflow[k]['START_STAGE'] != '') {
						$scope.wkInfo += "Start Stage:" + $scope.workflow[k]['START_STAGE'];
						$scope.wkInfo += "End Stage:" + $scope.workflow[k]['END_STAGE'];
					} else {
						$scope.wkInfo += "No Start and End stage is defined";
					}
					$scope.wkInfo += ") ";
				} 
				$scope.wkInfo += '</div><ol class="dd-list">';
				for(var i=0; i<$scope.stageInfo.length; i++) {
					$scope.wkInfo += '<div class="dd-handle"><li class="dd-item" data-id="'+i+'">';
					$scope.wkInfo += $scope.stageInfo[i]['STAGE_NAME'];
				
					$scope.wkInfo += '</div></li>';			
				}
				$scope.wkInfo += '</ol></li>';
			}
			$scope.wkInfo +='</ol></div>';
			showInfo(title, $scope.wkInfo);
			$('.dd').nestable();							
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};

});