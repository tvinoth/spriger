/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */

ngApp.controller('ngController',function ($scope,$filter,$compile,$http,$interval,$window,$q,DTOptionsBuilder, DTColumnBuilder,$timeout) 
{
        
	$scope.userId 		=   0;	
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'BookInfo';
	$scope.errorMsg 	=   "";
        $scope.srciframepath    =   null;
        $scope.errorshow        =   false;
        $scope.workflowList     =   [];
        $scope.workflowDetails  =   [];
        $scope.SessionMsg 	=   true;
        $scope.jobsheetlessbtn  =   true;
        $scope.showcurrenttab   =   1;
        var emailReg    =   /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
        var q_str       =   getUrlParameter(1);
        var job_obj     =   ( q_str.split('?')  );
        $scope.statusenum   =   [{'STATUS_ID':1,'NAME':'ACTIVE'},{'STATUS_ID':2 ,'NAME':'BLOCK'}];
        
	if(isNaN(getUrlParameter(1))){
		
		$scope.JobID 	=   "";
		if( q_str.indexOf('?') !== '-1' ) {
			$scope.JobID    =   q_str.substring( 0 , ( q_str.indexOf('?') ) );
		}
            
	}else{
            $scope.JobID 	=   getUrlParameter(1);
	}
      //  $scope.getUserDetail();
	$timeout(function() 
	{
		$scope.SessionMsg 		= 	false;
	}, 5000);
        
        
        
	$scope.getUserDetail    =   function ()
	{	
	    $scope.userName 	=   "";
	    $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) 
            {
                if(response.data.msg 	== 	"success") 
                {
                   $scope.userName 	= 	response.data.user_name;
                   $scope.roleName 	= 	response.data.role_name;
                   $scope.UserDetails 	= 	response.data;
                 
                   $scope.getbookinfoList();
                  
                   $scope.showAssignWorkflow($scope.JobID);
                   $scope.getAssignWorkflow($scope.JobID);
                   $scope.getroundList();
                   $scope.getChapterConf();
                   $scope.getEproofList();
                 
                } else {
                   window.location.href 	= 	BASE_URL+"?expired";
                }
            }, 
            function myError(response) 
            {
                console.log(response);
            });
        };
        

        $scope.bookinfotab          =   function(number){
            $scope.showcurrenttab   =   number;
        }
        
        $scope.updatebookdata       =   function(){
            
            $('.required_field').removeClass('val-error');
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).val();
                    value       =   value.trim();
                    if(value    ==  '' || value ==  ' ' || value.length ==  0){
                    validation  =   false;
                    $(this).addClass('val-error');
                }
            });
            
            if(validation   ==  false){
                showNotify('mandatory fields are required', 'danger' );
                return false;
            }
            showLoader('Please wait while update...');    
            var inp                     =   {
                                                'book_title' :$("input[name='book_title']").val(),
                                                'book_type' : $("input[name='book_type']").val(),
                                                'book_publishername' :$("input[name='book_publishername']").val(),
                                                'book_publisher_location' :$("input[name='book_publishername']").val(),
                                                'contact_person' :$("input[name='contact_person']").val(),
                                                'book_authorname' :$("input[name='book_authorname']").val(),
                                                'book_print_issn' :$("input[name='book_print_issn']").val(),
                                                'book_production_location' :$("input[name='book_production_location']").val(),
                                                'jobId' :$scope.JobID,
                                                'profilename' :$("select[name='profilename']").val(),
                                                'book_application' :$("select[name='book_application']").val(),
                                                'book_ispar' :($("input[name='book_ispar']").is(':checked')?1:0),
                                                'book_jobtype' :$("#book_jobtype").val(),
                                                'ce_required' :$("select[name='ce_required']").val(),
                                                'embbedname' :$("select[name='embbedname']").val(),
                                                'book_jobcode' :$("input[name='book_jobcode']").val(),
                                                'workflowtype' :$("select[name='workflowtype']").val(),
                                                'categorytype' :$("select[name='categorytype']").val(),
                                                'eproof_system' :$("select[name='eproof_system']").val(),
                                                'eproof_type' :$("select[name='eproof_type']").val(),
                                                'copyeditinglevel' :$("select[name='copyeditinglevel']").val(),
                                                'indexing' :$("select[name='indexing']").val(),
                                                'tapslocation' :$("select[name='tapslocation']").val(),
                                                'ptype' :$("select[name='ptype']").val() ,
												'printtype' : $("select[name='book_print_type']").val() ,
												'blankBm' :$("select[name='blankBm']").val(),
                                            };
            
            $http.post(BASE_URL+"book_infodetailssave",inp) .then(function mySuccess(response) 
            {
                    hideLoader();
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                }
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.result     ==  200)
                {
                    showNotify( response.data.errMsg  , 'success' );
                    return false;
                }
            }, 
            function myError(response) 
            {
                
                    hideLoader();
                showNotify('Invalid request try again..'  , 'danger' );
                return false;
            });	
        }
        
        $scope.getbookinfoList      =   function () {

                $scope.dtOptions    =   DTOptionsBuilder.newOptions()
                                        .withOption( 'ajax', {
                                                //dataSrc: "data",
        //                                        data: ,
                                                url: BASE_URL + 'getall_book_info',
                                                type: 'POST'
                                        })
                                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                                        .withOption('createdRow', function(row, data, dataIndex) {
                                            // Recompiling so we can bind Angular directive to the DT
                                            $compile(angular.element(row).contents())($scope);
                                        })
        //                                .withOption('rowCallback', rowCallback)
        //                                .withOption('drawCallback', drawCallback)
                                        /*.withOption('columnDefs', { "visible": false, "targets": 1 })*/
                                        .withOption('stateSave', false)
                                        .withOption('processing', true) // required - for show progress bar
                                        .withOption('serverSide', true)// required - for server side processing
                                        .withOption('responsive', true)// required - for server side processing
                                        .withOption('paging', true)// required
                                        .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                                        .withDisplayLength(10) //// Page size
                                        .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                                        .withOption( 'order' , [ [0, 'desc'], [0, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


                $scope.dtColumns    =   [
                                            DTColumnBuilder.newColumn('BOOK_ID').withTitle('Book Id'),
                                            DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Book Title'),
                                            DTColumnBuilder.newColumn('PM_NAME').withTitle('PM Name'),
                                            DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created date'),
                                            DTColumnBuilder.newColumn('QUERY').withTitle('Query').notSortable(),
                                            DTColumnBuilder.newColumn('SPIKE').withTitle('Spike').notSortable(),
                                            DTColumnBuilder.newColumn('JSCOMPARE').withTitle('Js Compare').notSortable()
                                            
                                        ];

                $scope.dtInstance   =   {};
        };
        
        if($scope.JobID     ==  ""){
            $scope.getbookinfoList();
        }
                
        $scope.contentloadtimer     =   1;
        
        $scope.getroundList         =   function() 
	{
            $scope.roundList        =   [];
            $http.get(BASE_URL+"jobround") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.roundList    =   response.data.prr;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getroundList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            
            $scope.contentloadtimer++;
	};
        
        $scope.compareJs                 =       function(jobId, roleid, stage,chapter){

       $scope.bookTitle        =   jobId;
       $scope.srcijcframepath    =   JSCOMPARE_URL+"?titleacronym="+jobId;   
	   
	   console.log($scope.srcijcframepath);
	   
       $('#iframejscompareview').attr('src',$scope.srcijcframepath);
            
    };
        
        $scope.eprooftypes      =   [{id:1,name:'E-Proof'},{id:2,name:'Hold'}];
        $scope.contentloadtimer =   1;
        $scope.getEproofList    =   function() 
        {
         
            $scope.eproofList   =   [];
            var inp             =   {jodId:$scope.JobID}
            $http.post(BASE_URL+"dogeteprooflistdetails",inp) .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify( 'Kindly reload page error occured.'  , 'danger' );
                }
                $scope.eproofList       =   response.data.cuclist;
                $scope.userId           =   response.data.user_id;
                $scope.eproof           =   {};
                $scope.eproof.dtOptions =   DTOptionsBuilder.newOptions().withOption('order', []);
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getEproofList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;
        };

        $scope.contentloadtimer =   1;
        $scope.getChapterConf    =   function() 
        {
            $scope.chapterlist   =   [];
            var inp             =   {jodId:$scope.JobID};
            var deferred                =   $q.defer();
            $scope.chpconfig    =   {};
            $scope.chpconfig.dtOptions    =   DTOptionsBuilder.newOptions().withOption('order', []);
            $http.post(BASE_URL+"chapterlist",inp) .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify( 'Kindly reload page error ocured.'  , 'danger' );
                }
                
                $scope.bookWorkflowId   =   response.data.bookWorkflowId;
                $scope.chapterlist      =   response.data.cuclist;
                $scope.wfdata           =   response.data.wfdata;
                $scope.userId           =   response.data.user_id;
                $scope.emptype           =   response.data.embbedType;
                $scope.roundId           =   response.data.roundId;
                $scope.catData           =   response.data.catData;
                $scope.jobCategoryType   =   response.data.jobCategoryType;
                $scope.jobsheetless      =   response.data.jobsheetless;
                if(response.data.jobsheetlessbtn    ==  0){
                    $scope.jobsheetlessbtn  =   false;
                }
                $scope.s5notification   =   response.data.s5notification;
                
                if(response.data.jobsheetless == 1){
                    $('*[id="movetoPro"]').show();
                    $("#jsless").prop("checked", true);
                }else{
                    $('*[id="movetoPro"]').hide();
                    $("#jsless").prop("checked", false);
                }
                deferred.resolve(response);
                
            }, 
            function myError(response) {
                if($scope.contentloadtimer    <  10){
                    $scope.getChapterConf();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                deferred.reject(response);
            });	
            return deferred.promise;
            $scope.contentloadtimer++;
        };

        $scope.showAssignWorkflow   =   function(jobId) {
            var inp     =   {	jobId : jobId};
            $http.post(API_URL+"getassignworkflow", inp) .then(function mySuccess(response) {
                $scope.roundList    = response.data.roundList;
                $scope.workflowList = response.data.workflowList;
            }, 
            function myError(response) {
                console.log(response);
            });			
	};

        
        if($scope.JobID     !=  ""){
            
            $scope.showAssignWorkflow   =   function(jobId) {
                var inp     =   {	jobId : jobId};
                $http.post(API_URL+"getassignworkflow", inp) .then(function mySuccess(response) {
                    $scope.roundList    = response.data.roundList;
                    $scope.workflowList = response.data.workflowList;
                }, 
                function myError(response) {
                    console.log(response);
                });			
            };
            
             $scope.getAssignWorkflow = function(jobId) {
                var inp     =   {	jobId : jobId};
                $http.post(API_URL+"getAssignedWorkflowToJob", inp) .then(function mySuccess(response) {
                    $scope.workflowDetails      =   response.data.workflowDetails;
                }, 
                function myError(response) {
                    console.log(response);
                });			
            };
            
            $scope.getroundList();
            $scope.getEproofList();
            $scope.showAssignWorkflow($scope.JobID);
            $scope.getAssignWorkflow($scope.JobID);
//            $scope.getChapterConf();
        }
        
        $scope.eproofsystem     =   function( type,item )
        {
            bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
               if(result){
                    showLoader('Please wait while updating Data...');
                    var inp     =       {  
                                            metadtaid   : item.taskmetaid,
                                            jobid       : item.jobid,
                                            eproofsystem_type   :  type
                                        };

                    $http.post(BASE_URL + "doeproofsystemchange",inp).then(function mySuccess(response)
                    {
                        hideLoader();
                        if(response.data.result     ==  401)
                        {
                            if (typeof response.data.validation !== 'undefined') {
                                $.each(response.data.validation,function(key,val)
                                {
                                    $.each(val,function(key,errval)
                                    {
                                        $.notify(errval,'error');
                                    });
                                });
                            }
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                        if(response.data.status == 1)
                        {
                            showNotify(response.data.errMsg, 'success');
                        }
                    },
                    function myError(response)
                    {
                        hideLoader();
                        showNotify(response.data.errMsg, 'danger');
                    });
                }
            });
        }
        
        $scope.doupdaterecipientitem    =   function(){
			
            $scope.showvalidationerror  =   [];
			//showLoader('Please wait while updating Data...');
			//if(($scope.eproofrecipient   ==  '' || $scope.eproofrecipient   ==  undefined) || ($scope.additionalrecipient   ==  '' || $scope.additionalrecipient   ==  undefined))
            
			if($scope.additionalrecipient   ==  '' || $scope.additionalrecipient   ==  undefined || $scope.additionalrecipient   ==  " "){

                if($scope.additionalrecipient   ==  '' || $scope.additionalrecipient   ==  undefined || $scope.additionalrecipient   ==  " "){
                    $('.additionalrecipient').addClass('val-error');
                }else{
                    $('.additionalrecipient').removeClass('val-error');
                }
                showNotify('All fields are required', 'danger');
                return false;
            }
			
            var checkaddirecipient      =   $scope.additionalrecipient.indexOf(",");
            var checkspaceaddirecipient =   $scope.additionalrecipient.indexOf(" ");
			if(checkspaceaddirecipient >= 0){
				$('.additionalrecipient').addClass('val-error');
				showNotify('Kindly remove space from additional recipient field', 'danger');
				return false;
			}
			
            var validationfailedorsuccess   =   false;
            var validationaddrecipient      =   [];
            if(checkaddirecipient !==   -1){
                var morethanemailvalid  =   $scope.additionalrecipient.split(',');
                angular.forEach(morethanemailvalid, function(value, key) {
                    // value   =   value.trim();
                    if(value != ''){
                        if(!(value).match(emailReg)){$('.additionalrecipient').addClass('val-error'); 
                            validationaddrecipient.push(false);
                            showNotify('Invalid E-Mail ID', 'danger');
                        }else{$('.additionalrecipient').removeClass('val-error'); 
                            validationaddrecipient.push(true);
                        }}});
            }else{
                if(!($scope.additionalrecipient).match(emailReg)){
                    $('.additionalrecipient').addClass('val-error'); 
                    showNotify('Invalid E-Mail ID', 'danger');
                    validationaddrecipient.push(false);
                }else{$('.additionalrecipient').removeClass('val-error');
                    validationaddrecipient.push(true);
                }
            }
            
            if(validationaddrecipient.includes(false) == true){
                $('.additionalrecipient').addClass('val-error'); 
                showNotify('Invalid E-Mail ID', 'danger');
                return false;
            }
			
            var inp     =       {  
                                    eproof_recipient        :   $scope.eproofrecipient,
                                    additional_recipient    :   $scope.additionalrecipient.trim(),
                                    metadtaid               :   $scope.currnteproof.taskmetaid , 
									type					: 	2
                                };
			
			if( $scope.currnteproof.type == 1 ){
				inp['type']		=	1;
				inp['jobid']		=	$scope.currnteproof.jobid;
			}
				
            $scope.savechapterdisabled  =   true;  
			
            $http.post(BASE_URL + "doupdateeproofrecipient", inp ).then(function mySuccess(response){
				
              
                if( response.data.status == 0 ){   
					hideLoader();
                    $scope.savechapterdisabled  =   false;                   
                    $scope.validerrorshow       =   true;
                    $scope.showvalidationerror  =   response.data.validation;
                    showNotify( response.data.errMsg , 'danger');
                    return false;
                }
				
                if(response.data.status == 1){
					
                    $scope.savechapterdisabled  =   false; 
					showNotify(response.data.errMsg, 'success');
					
					$timeout(function(){
						var link 	= 		document.getElementById('show-email');						
						link.click();
						window.location.hash = '';
						hideLoader();
					}, 2000 );
					
                }
            },
            function myError(response){
                $scope.savechapterdisabled      =   false;                   
                hideLoader();
                showNotify(response.data.errMsg, 'danger');
            });
        };
        
        $scope.doupdateemaild           =   function( item ){
			
            $scope.validerrorshow       =   false;
			showLoader();
			
            $('.eproofrecipient').removeClass('val-error');
            $('.additionalrecipient').removeClass('val-error');
			
			//$('#show-email').trigger('click');
			//$('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
			
			$('.eproofrecipient').attr( "readonly" , true );
			
            var inp     =       {  
                                    metadtaid   :   item.taskmetaid 
                                };
								
            if( item.type !== undefined && item.type == 1 ){
				
                inp['jobid']  = item.jobid;
                inp['type']  = 1;
				
            }
          
            $http.post( BASE_URL + "dogetEproofrecipient",inp).then(function mySuccess(response){
				
                if( response.data.result == 401 ){     
					hideLoader();	
                    $scope.showvalidationerror  =   response.data.validation;
                    showNotify(response.data.errMsg, 'danger');
                    return false;
                }
				
                if(response.data.status == 1){
                    
					$timeout(function(){
						
						var link 	= 		document.getElementById('show-email');
						
						if( item.type !== undefined && item.type == 1 ){
							$('.eproofrecipient').attr( "readonly" , false );
						}
						
						link.click();
						hideLoader();
						
						$scope.eproofrecipient      =   response.data.errMsg.EPROOFING_RECIPIENT;
						$scope.additionalrecipient  =   response.data.errMsg.ADDITIONAL_RECIPIENT;
						$scope.emailchaptertitle    =   response.data.errMsg.CHAPTER_NO;
						$scope.currnteproof         =   item;
						window.location.hash = '';
					
					}, 2000 );
					
                    //$('#show-email').trigger('click');
					//return false;
                    
                }
            },function myError(response)
            {
                hideLoader();
                showNotify(response.data.errMsg, 'danger');
            });
			
        };
        
        $scope.doupdatemultiple         =   function( item)
        {   
            $scope.validerrorshow       =   false;
            showLoader();
            var inp     =       {  
                                    metadtaid   :   item,
                                    jobid       :   item
                                };
            $http.post(BASE_URL+"dogetEproofrecipient",inp).then(function mySuccess(response)
            {
                hideLoader();
                if( response.data.status == 401 ){                    
                    $scope.showvalidationerror  =   response.data.errMsg;
                    return false;
                }
                if(response.data.status == 1)
                {
                    hideLoader();
                    $('#show-multipleemail').trigger('click');
                    $scope.eproofdtails     =   response.data.errMsg;
                }
            },
            function myError(response)
            {
                hideLoader();
                showNotify(response.data.errMsg, 'danger');
            });
        };
        
        $scope.doupdateallrecipient     =   function()
        {
            var getcheckedmetaitems     =   [];
            var geteproofrecipientemail =   [];
            var getadditionalreciemail  =   [];
            var getupdateidvalues       =   $('tr input[name="emailrecipientcheck[]"]:checked').each(function()
            {
                if($(this).val()    !=  ''){
//                    geteproofrecipientemail.push($("tr").find('#eproofrecipientemails_'+$(this).val()).val());
                    getadditionalreciemail.push($("tr").find('#additionalrecipientemails_'+$(this).val()).val());
                    getcheckedmetaitems.push($(this).val());
                }
            });
            var validationaddrecipient  =   true;
            $.each(getadditionalreciemail,function(ind,val){
                val   =   val.trim();
                if(val.indexOf(",") !==   -1)
                {
                    var newEmail    =   val.split(',');
                    $.each(newEmail,function(ind,value){
                        value       =   value.trim();
                        if(value != ''){
                            if(!(value).match(emailReg)){
                                validationaddrecipient   =   false;
                            }
                        }
                    });
                }else{
                    if(!(val).match(emailReg)){
                        validationaddrecipient   =   false;
                    }
                }
            });
            
            if(validationaddrecipient   ==  false){
                showNotify('Invalid E-Mail ID', 'danger');
                return false;
            }
            
            $scope.showvalidationerror  =   [];
            showLoader('Please wait while updating Data...');
            var inp     =       {  
                                    eproof_recipient        :   geteproofrecipientemail,
                                    additional_recipient    :   getadditionalreciemail,
                                    metadtaid               :   getcheckedmetaitems
                                };
            $scope.savechapterdisabled  =   true;                   
            $http.post(BASE_URL + "doEmailrecipientdetails",inp).then(function mySuccess(response)
            {
                hideLoader();
                if( response.data.result == 401 ){   
                    $scope.savechapterdisabled  =   false;                   
                    $scope.validerrorshow       =   true;
                    $scope.showvalidationerror  =   response.data.validation;
                    showNotify(response.data.errMsg, 'danger');
                    return false;
                }
                if(response.data.status == 1)
                {
                    $scope.savechapterdisabled  =   false; 
                    $('#show-multipleemail').trigger('click');
                    showNotify(response.data.errMsg, 'success');
                }
            },
            function myError(response)
            {
                $scope.savechapterdisabled      =   false;                   
                hideLoader();
                showNotify(response.data.errMsg, 'danger');
            });
        };
        
        $scope.checkedlist      =   [];
        $scope.dovalidationsubmitchckbutton     =   function(index,item)
        {
            if(index){
                $scope.checkedlist.push(index);
//                $("tr").find("#eproofrecipientemails_"+item).attr('readonly',false);
                $("tr").find("#additionalrecipientemails_"+item).attr('readonly',false);
            }else{
                $scope.checkedlist.splice($scope.checkedlist.indexOf(index), 1);
//                $("tr").find("#eproofrecipientemails_"+item).attr('readonly',true);
                $("tr").find("#additionalrecipientemails_"+item).attr('readonly',true);
            }
            if($scope.checkedlist.length >=1 ){
                $scope.validatesubmit   =   true;
            }
            if($scope.checkedlist.length ==     0){
                $scope.validatesubmit   =   false;
            }
        };
        
        $scope.addWorkflowtoJob = function() {
            
            var wfMid           =   $scope.workflowMaster;
            var roundId         =   $scope.round;
            if($scope.JobID     ==  undefined || $scope.JobID     ==  "" || $scope.workflowMaster     ==  undefined || $scope.workflowMaster     ==  "" || $scope.round     ==  undefined || $scope.round     ==  "")
            {
                showNotify('All Fields are required', 'danger');
                hideLoader();
                return false;
            }
            var inp     =   {jobId :  $scope.JobID, roundId:roundId, wfMid: wfMid};
            showLoader('Please wait while adding Data...');
            $http.post(API_URL+"saveWorkflowtoJob", inp) .then(function mySuccess(response) {

                hideLoader();
                if( response.data.status == '2'){
                    $scope.workflowMaster   =   undefined;
                    $scope.round            =   undefined;
                    $scope.getAssignWorkflow($scope.JobID);
                    showNotify('Successfully added', 'success');
                  //  $window.location.reload()
                }

                if( response.data.status == '1'){
                    showNotify('Already exist', 'warning');
                }

                if( response.data.status == '0'){
                    showNotify('Something Went wrong!! Try Again', 'danger');
                }

            }, 
            function myError(response) {
                     console.log(response);
            });			
	};
        
        var counter 	=	PAGE_RELOAD_TIMER;		
        $scope.autoreloadstart 	=	function()
        {
            $scope.timermessage =	true;
            $scope.Timer 		= 	$interval(function() 
            {
                    var timerdiv 	=	angular.element(document.getElementById("timeralert"));
                    if(counter 	==	15)
                    {
                            timerdiv.removeClass('alert-info');
                            timerdiv.addClass('alert-danger');
                    }
                    if(counter 	==	5)
                    {
                            timerdiv.addClass('alert-info');
                            timerdiv.removeClass('alert-danger');
                            $scope.loadspinner 	=	true;
                            $scope.getbookinfoList();
                    }
                    if(counter 	==	4)
                    {
                            timerdiv.addClass('alert-info');
                            timerdiv.removeClass('alert-danger');
                            $scope.loadspinner 	=	false;
                    }
                    if(counter 	==	0)
                    {
                            counter 	=	PAGE_RELOAD_TIMER;	
                    }
                    $scope.Timershow 	=	counter;
                    counter--;
            }, 1000);
        };

        $scope.autoreloadstop 	=	function(){
            $scope.Timershow 	=	counter;
            if (angular.isDefined($scope.Timer)) 
            {
                $scope.loadspinner 	=	false;
                $interval.cancel($scope.Timer);
            }
        };

        $scope.autoreloadreset 	=	function(){
            counter 	=	PAGE_RELOAD_TIMER;
            $scope.Timershow 	=	counter;
            if (angular.isDefined($scope.Timer)){
                $scope.loadspinner 	=	false;
                $interval.cancel($scope.Timer);
            }
        };	

	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
        
        
        /*$scope.contentloadtimer     =   1;
	$scope.getbookinfoList      = 	function() 
	{
            $scope.srciframepath    =   null;
            $scope.bookinfoList     = 	[];
            $http.get(BASE_URL+"getall_book_info") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error ocured.'  , 'danger' );
                }
                $scope.bookinfoList 	=   response.data.book;
                $scope.userId           =   response.data.userId;
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    !==  10){
                    $scope.getbookinfoList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error ocured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;
	};*/
       
        $scope.viewWorkflow     =   function (workflowMasterId) {
            var title           =   'View Workflow';
            $scope.wkInfo       =   '';
            $scope.workflow     =   [];
            $scope.stageInfo    =   [];
            var inp             =   {workflowMasterId: workflowMasterId};
            $http.post(API_URL + "getWorkflowAndStages", inp).then(function mySuccess(response) {
                console.log(response);
                $scope.workflow     =   response.data.workflow;
                $scope.stageInfo    =   response.data.stage;

                $scope.wkInfo += '<div class="dd" id="nestable"><ol class="dd-list">';
                for (var k = 0; k < $scope.workflow.length; k++) {
                    $scope.wkInfo += '<li class="dd-item" data-id="' + k + '"><div class="dd-handle orange">';
                    if ($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
                        $scope.wkInfo += "Main Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
                        $scope.wkInfo += "Parallel Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
                        $scope.wkInfo += "Art Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
                        $scope.wkInfo += "Art Correction Workflow - ";
                    }
                    $scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

                    if ($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
                        $scope.wkInfo += " (";
                        if ($scope.workflow[k]['START_STAGE'] != '') {
                            $scope.wkInfo += " Start Stage: " + $scope.workflow[k]['START_STAGE'];
                            $scope.wkInfo += " End Stage: " + $scope.workflow[k]['END_STAGE'];
                        } else {
                            $scope.wkInfo += " No Start and End stage is defined";
                        }
                        $scope.wkInfo += ") ";
                    }
                    $scope.wkInfo += '</div><ol class="dd-list">';
                    for (var i = 0; i < $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']].length; i++) {
                        $scope.wkInfo += '<div class="dd-handle"><li class="dd-item" data-id="' + i + '">';
                        $scope.wkInfo += $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_NAME'];

                        $scope.wkInfo += '</div></li>';
                    }
                    $scope.wkInfo += '</ol></li>';
                }
                $scope.wkInfo += '</ol></div>';
                showInfo(title, $scope.wkInfo);
                $('.dd').nestable();
            },
            
            function myError(response) {
                console.log(response);
            });
        };
	
        $scope.deleteWorkflow       = 	function(item) 
	{
            $scope.errorshow        =   false;
            bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
            if(result){
                showLoader( 'please wait for a while delete record...' );
                    var inp     =   {
                        wkrflwmasterId  :   item.WORKFLOW_MASTER_ID,
                        wrkflowjobId    :   item.JOB_ID,
                        wrkflwround     :   item.ROUND
                    }
                    $http.post(API_URL+"deleteJobassignedWorkflow", inp ).then(function mySuccess(response) 
                    {
                        hideLoader();
                        if( response.data.status == 1 ){
                            var index   =   $scope.workflowDetails.indexOf(item);
                            if(index){
                                $scope.workflowDetails.splice(index, 1); 
                            }
                            showNotify( response.data.errMsg , 'success' );
                        }
                        if( response.data.result == 401 ){    
                            $scope.errorshow    =   true;
                            $scope.shownotavaiablechapter   =   response.data.validation;
                            showNotify( response.data.errMsg , 'danger' );
                        }
                        if( response.data.status == 0 ){                                 
                            showNotify( response.data.errMsg , 'danger' );
                        }
                    },function myError(response) {
                        hideLoader();
                        showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
                    });
                }
            });
	};
        
        $scope.buttonchangeprocess  =   function(type){
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            if(type     ==  1){
                $(currentChapter).val('Downloading');
                $(currentChapter).attr('disabled','true');   
            }else if(type ==    2){
                $(currentChapter).val('Opening');
                $(currentChapter).attr('disabled','true');   
            }
            else{
                $(currentChapter).val('Open Raw File');
                $(currentChapter).removeAttr('disabled');   
            }
        };
        //open openjobrawfile
        $scope.openjobrawfile   =   function(jobId)
        {
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            $scope.buttonchangeprocess(1);
            showLoader('Please wait while Open Drive ...');
            var inp             = 	{
                                        jobId       :   jobId
                                    };   
            $http.post(BASE_URL + 'cucOpenrawFile', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    $scope.buttonchangeprocess(0);
                    showNotify( response.data.errMsg  , 'danger' );
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    // check tool end response
                    if (typeof response.data.lastID !== 'undefined' && response.data.lastID !=  '') {
                        $scope.checkToolresponse(response.data.lastID,jobId,attempt);
                    }else{
                        showNotify( response.data.errMsg  , 'success' );
                        var attempt         =   1;
                        var filehandlerid   =   response.data.rmID;
                        $scope.buttonchangeprocess(2);
                        $scope.checkfilestatusopenornot(filehandlerid,attempt);
                    }
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            });
        };
        
        $scope.checkToolresponse     =   function(ID,jobId,attempt) 
        {           
            var inp             = 	{ID  :   ID };
            $http.post(API_URL + 'checkToolStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
//                    $.notify(response.data.errMsg,'error');
                    $timeout( function(){ $scope.checkToolresponse(ID,jobId,attempt); }, 4000 );
                }
                if(response.data.result     ==  404)
                {
                    $scope.buttonchangeprocess(0);
                    showNotify("File handler is not running. Please check....", 'danger');
                }
                if(response.data.result     ==  400)
                {
                    $scope.buttonchangeprocess(0);
                    showNotify( response.data.errMsg, 'danger' );
                }
                if(response.data.result     ==  200)
                {
//                    showNotify( response.data.errMsg, 'success' );
                    $scope.RawfileOpenrequestInsert(jobId);
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
            });
        };
        
        $scope.RawfileOpenrequestInsert =   function(jobId){
            var inp     =   {jobId        :   jobId}        
            showLoader('Please wait while Open Drive ...');
            $http.post(BASE_URL + 'rawfileOpenrequestInsert', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                    $scope.buttonchangeprocess(0);         
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
                    $scope.buttonchangeprocess(2);
                    $scope.checkfilestatusopenornot(filehandlerid,attempt);
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            });
		
	};
        
        $scope.checkfilestatusopenornot     =   function(filehandlerid,attempt) 
        {           
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Opendrive'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(filehandlerid,attempt); }, 2000 );
                    } else {
                        $scope.buttonchangeprocess(0);
                        hideLoader();
                        showNotify("File handler is not running. Please check.", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    $scope.buttonchangeprocess(0);
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    $scope.buttonchangeprocess(0);
                    hideLoader();
                    showNotify( response.data.errMsg, 'success' );
                }
            }, 
            function myError(response) 
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
            });
        };
        
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
	$scope.bookinfodetails 	= 	function(book) 
	{
            $window.location.href 	=   BASE_URL+"book_infodetails/"+book;
	};
        
	$scope.Msgsuccess 		=   true;
	
	$scope.hidemsg 			=   function(){
            $scope.Msgsuccess           =   false;
	};
       
	$scope.qmsspike                 =   function(jobId, userId, bookId,type){
		
		console.log(jobId);
		
		if(type     ==  'qms'){
			$scope.bookTitle        =   bookId;
			$scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
			$('#iframeqms').attr('src',$scope.srciframepath);
		}else{
			$scope.bookTitle        =   bookId;
			$scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
			$('#iframespike').attr('src',$scope.srciframepath);
		}
	
	};

	$scope.prepareJobCode  = function(){ 
            
            var jobtype     =    $('#book_jobtype').val();
            var jobcode     =    $('#book_jobcode').val(); 
            var seqval      =    $('#book_sequence').val();
            var shortCode   =    JOB_CODE_PATTERN;
            jobtype         =    shortCode[ jobtype ];
            $('#book_jobcode').val(jobtype);

	};
	        
	$scope.chapterConfig =   function(metaId){
		
		var categoryId = $('#categoryId_'+metaId).val();
		var workflowId = $('#workflowId_'+metaId).val();
	  
		var inp     =   {
							masterId        :   workflowId,
							categroy        :   categoryId,
							metaId          :   metaId          
						}
		showLoader();
		
		$http.post(API_URL+"chapterconfig", inp ).then(function mySuccess(response) 
			   {
				   hideLoader();
				  if( response.data.status == 1 ){
					   showNotify( response.data.errMsg , 'success' );
				   }
				   if( response.data.status == 401 ){    
					   $scope.errorshow    =   true;
					   $scope.shownotavaiablechapter   =   response.data.errMsg;
				   }
				   if( response.data.status == 0 ){                                 
					   showNotify( response.data.errMsg , 'danger' );
				   }
			   },function myError(response) {
				   hideLoader();
				   showNotify('Oops , something went wrong try again.','danger' ); 
			   });
	  
		return false;
		
	};
    
	if($scope.JobID     ==  ""){
            $scope.getbookinfoList();
	};
        
	$scope.selectworkflow   =   function(metaId){
	   var obj = JSON.parse($scope.catData);
	   console.log(obj);
	   var selectedVal      =   $('#categoryId_'+metaId).val();
	 
		for(var key in obj){
		   rowContent = key + "-" + obj[key];
		   console.log(rowContent);
		}
		
						   
	   var selectedVal      =   $('#categoryId_'+metaId).val();
	   
	   var emptype          =   $scope.emptype;
	   var roundId          =   $scope.roundId;
	   var c                =   selectedVal+'_'+emptype+'_'+roundId;
		console.log(c);
	   for(var key in obj){
		  if(c == key){
		   var wf = obj[key];   
		  }
		}
		console.log( wf);
	   $("#workflowId_"+metaId).val(wf);
          
	};
                     
	$scope.metaMovetopro =   function(metaId){
		
		var categoryId = $('#categoryId_'+metaId).val();
		var workflowId = $('#workflowId_'+metaId).val();
		console.log(categoryId);
		
		console.log(workflowId);
		if(categoryId == '' || categoryId == '? string:43 ?' || workflowId == '' || workflowId == '? string:43 ?'){
			showNotify('Category Level or Workflow should not be empty  ','danger' );
		   return false;
		}
		
	   if( $scope.s5notification == 0){
		   showNotify('Kindly completed the S5 stage to continue this process ','danger' );
		   return false;
	   }
	 
		var inp     =   {
                                            masterId        :   workflowId,
                                            categroy        :   categoryId,
                                            metaId          :   metaId          
						
                                 }
		showLoader();
		$http.post(API_URL+"manualmovetoproduction", inp ).then(function mySuccess(response) 
			   {
				   hideLoader();
				  if( response.data.status == 1 ){
                                           $scope.getChapterConf();
					   showNotify( response.data.errMsg , 'success' );
				   }
				   if( response.data.status == 401 ){    
					   $scope.errorshow    =   true;
					   $scope.shownotavaiablechapter   =   response.data.errMsg;
				   }
				   if( response.data.status == 0 ){                                 
					   showNotify( response.data.errMsg , 'danger' );
				   }
			   },function myError(response) {
				   hideLoader();
				   showNotify('Oops , something went wrong try again.','danger' ); 
			   });
	  
		return false;
	
	}; 
        
	$scope.ConfirmJsless =   function(){
            
		var x = confirm("Are you sure you want to change");
		
		if (x){
			
			if($('#jsless').is(":checked") == true){
				$('*[id="movetoPro"]').show();
				var jsflage = 1;				
			}else{
				$('*[id="movetoPro"]').hide();
				var jsflage = 0;
			}
			$scope.jsflag($scope.JobID,jsflage);
			
			return true;
			
		}else{
			event.preventDefault();
			console.log('tttt');
			return false;
			
		}   
            
	};
	
	$scope.jsflag =   function(jobId,jsflag){
		
		var inp     =   {
							jobId          :   jobId,
							jsflag         :   jsflag
						}
						
		$http.post(API_URL+"jsless", inp ).then(function mySuccess(response){
			
			hideLoader();
			if( response.data.status == 1 ){
                            $scope.getChapterConf();
			   showNotify( response.data.errMsg , 'success' );
			}
		   
			if( response.data.status == 401 ){    
				$scope.errorshow    =   true;
				$scope.shownotavaiablechapter   =   response.data.errMsg;
			}
		   
			if( response.data.status == 0 ){                                 
			   showNotify( response.data.errMsg , 'danger' );
			}
		   
		},function myError(response) {
		   hideLoader();
		   showNotify('Oops , something went wrong try again.','danger' ); 
		});
        }
    
        if($scope.JobID     !=  ''){
            var getvalue    =   $("#txtDoopenrawfile").data('rawbutton');
            if(getvalue     !=  0 && getvalue   !=  undefined){
                var attempt     =   1;
                $scope.checkToolresponse(getvalue,$scope.JobID,attempt);
            }
        }
		
        $scope.prepareJobCode  = function(){ 
            
            var jobtype     =    $('#book_jobtype').val();
            var jobcode     =    $('#book_jobcode').val(); 
          //  var seqval      =    $('#book_sequence').val();
            var shortCode   =    JOB_CODE_PATTERN;
            jobtype         =    shortCode[ jobtype ];
            $('#book_jobcode').val(jobtype);

        };

        $scope.roundsenum       =   [];
        $scope.compsenum       =   [];
        
        $scope.getCompodetails =   function(){
            
            var deferred                =   $q.defer();
            
            $http.get(BASE_URL+"getCompoListByjobid/"+$scope.JobID ) .then(function mySuccess(response){
                if(response.data.status == 0 ){
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.status == 1 ){
                    
                    $scope.compolist    =   response.data.compolist;
                    $scope.roundsenum   =   response.data.roundinfo;
                    $scope.compsenum    =   response.data.components;
                    
                    deferred.resolve(response);
                }
            },function myError(response){
                
                deferred.reject(response);
            });
            
            return deferred.promise;
            
	};
        
        $scope.getCompodetails();
        $scope.editcompoSelectRow      =   [];
        
        $scope.getCompoTemplate  =   function (item) {
            
            console.log('template');
            console.log( $scope.editcompoSelectRow );
            console.log( item.ID );
            
            if (item.ID === $scope.editcompoSelectRow.ID){
                return 'editTemplate';
            }else{
                return 'listTemplate';
            }
            
        };
        
        $scope.compform       =   [];
        
        $scope.editComponent    =   function(item){
            $scope.editcompoSelectRow  =    angular.copy(item);
        };
        
        $scope.undoChanges    =   function () {
            $scope.editcompoSelectRow    =   {};
        };
        
        $scope.redoChanges     =   function(){
            //$("#servicemanager_name").removeClass('val-error');
        };
        
        $scope.removeComponentRow  =   function(position,item){
            
            bootbox.confirm("Are you sure to delete this component ?", function( result ) {
                if(result){
                    var inp         =   { id : item };
                    $http.post( BASE_URL+'deleteComponent' , inp ).then(function mySuccess(response) {
                        
                        if(response.data.status     ==  1){
                            //$scope.servicelist.splice(position, 1); 
                            $scope.getCompodetails();
                            showNotify(response.data.errMsg, 'success' );
                        }
                        if(response.data.status     ==  0){
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                
                    },function myError(response) {
                        showNotify(response.data.errMsg,'danger' );
                    });
                }
            });
            
        };
        
        $scope.createComponet  =   function( ){
            showLoader();
            
            var input   =   { 
                job_id  :       $scope.JobID , 
                round   :       $('#formcompround').val() , 
                compotype :     $('#formcomptype').val() ,
                componame :     $('#formcompname').val() ,
                descrip :       $('#formcompdescrip').val() 
            };
           
            $http.post(BASE_URL + 'storeComponentInfo', input )
            .then(function mySuccess(response){
                
                hideLoader();
        
                if(response.data.result     ==  404){
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401){
                    
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                
                if(response.data.result     ==  200){
                    
                    $('#formcompround').val('');
                    $('#formcomptype').val('');
                    $('#formcompname').val('');
                    $('#formcompdescrip').val('');
                    $('#showcompoedit').modal('toggle');
                    $('#editCheckItem-close').trigger('click');
                     
                    showNotify(response.data.errMsg  , 'success' );
                    $scope.getCompodetails();
                }
                
            }, 
            function myError(response){
                hideLoader();
            });
            
            return false;
            
        };
        
        $scope.updateComponentInfo     =   function(position,item){
            console.log( position );
            
            var validation  =   true;
            $(".required_"+position).each(function(key,val){
                var getid = $(this).attr('id');
                if($(this).val()    ==  '' || $(this).val() == undefined){
                    var validation  =   false;
                    $("#"+getid).addClass('val-error');
                }else{
                    $("#"+getid).removeClass('val-error');
                }
            });
            
            if(validation   ==  false){
                showNotify('Required field validation error occured', 'danger' );
                return false;
            }
            
            if($("#componame_"+position).val().length <= 2){
                showNotify('Component name is to short', 'danger' );
                return false;
            }
            
            var inp = 	{
                            id :   item.ID,
                            round :   $("#roundname_"+position).val(),
                            componame  :   $("#componame_"+position).val(),
                            descrip :   $("#compodesc_"+position).val(),
                            compotype:   $("#compotype_"+position).val(),
                            status   :   $("#status_"+position).val(),
                            job_id    :   $scope.JobID 
                        };  
                     
            $http.post(BASE_URL + 'updateComponentInfo', inp)
            .then(function mySuccess(response){
                hideLoader();
                if(response.data.result     ==  404){
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401){
                    
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  200){
                    
                    $scope.getCompodetails();
                    $scope.undoChanges();
                    //$scope.servicelist[position]   =   response.data.validation;
                    showNotify(response.data.errMsg  , 'success' );
                    ;
                }
            }, 
            function myError(response){
                hideLoader();
            });
            
        };
        
        $(document).ready(function() {
            
            $("#addCompoRow").click(function(){
                //$('#show-showcompoform').trigger('click');
                $('#showcompoedit').modal('show');
            });
  
        });
        
});