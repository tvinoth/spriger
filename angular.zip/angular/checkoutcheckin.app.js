/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
    
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout,$http,$q,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    
    $scope.userId 	= 	'0';	
    $scope.UserDetails 	= 	{};
    $scope.menuParent 	= 	'Production';
    $scope.menuChild 	= 	'Project Bin';
    $scope.errorMsg 	= 	"";
    $scope.noOfAttemptsToCheckIndesign  =   10;
    $scope.observeAvailale      =   false;
    $scope.openCreatedPdfShow        =   false;
    $scope.creatpdf_inprog       =   false;
    $scope.formAdditionalOptions        =       null;
    $scope.observeXmlBtn   =   false;
    $scope.instructionsArr      =   [];
    $scope.instructionsLevelArr      =   [];
    
    $scope.typeofcorrection     =   [ {'name':'NA','value':'NA'},{'name':'YES','value':'Y'},{'name':'NO','value':'N'}];
    
    
    $scope.prQc =   [];
    
    $scope.getUserDetail = function (){
        
	$scope.userName = "";
	    $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) {
                    if(response.data.msg == "success") {
                           $scope.userName = response.data.user_name;
                           $scope.roleName = response.data.role_name;
                           $scope.UserDetails = response.data;
                           //$scope.showProjectList();
                    } else {
                           window.location.href= BASE_URL+"?expired";
                    }
		}, 
		function myError(response) {
                    
                    //showLoader( 'Oops! Try again after sometimes.' );
                    
		});
	
    };
    
    $scope.getUserDetail();
    
    $scope.contentloadtimer     =   1;
    $scope.filecpstatus   =   1;
    $scope.fn_load = function(checoutFlag,jobStageid){  
        if(checoutFlag == '1'){
			
		showLoader('Please wait while files are copying...');
		var inp = {	jobStageId : jobStageid};
            
		$http.post(API_URL+"checkoutfileCopy", inp) .then(function mySuccess(response) {
                    hideLoader();
                    if(response.data.filetransferStatus == 'success'){
                        if(response.data.opendir != ''){
                            $scope.openDrive(response.data.opendir);
                        }
                         //showNotify('Successfully Checkout', 'success');
                    }
                    if(response.data.sourcenotexist == 1 && response.data.filetransferStatus == "failed"){
                        showNotify(response.data.errMsg, 'danger');
                    }
                    if(response.data.sourcenotexist == 0){
                        showNotify(response.data.errMsg, 'danger');
                    }
                    if( response.data.correctionLaunch == 1 ){
                        window.open(  response.data.correctionEditorSoftPath , '_blank' ); 
                        
                    }
                    
                    if(response.data.status == 'failed'){
                        showNotify('Not able to checkout files', 'danger');
                    }
                     
		}, 
		function myError(response) {
//                    if($scope.contentloadtimer    <  5){
//                        $scope.fn_load(checoutFlag,jobStageid);
//                    }
//                    
//                    if($scope.contentloadtimer    ==  5){
//                        showNotify('Kindly reload page error occured.'  , 'danger' );
//                        return false;
//                    }
		});			
            hideLoader();
       }
       $scope.contentloadtimer++;
   };
   
    $scope.fn_Art_load = function(checoutFlag,batchId){  
     //checoutFlag   =0;
       if(checoutFlag == '1'){
           
            showLoader('Please wait while files are copying...');
           var inp = {	batchId : batchId};
		$http.post(API_URL+"checkoutBatchfileCopy", inp) .then(function mySuccess(response) {
                    console.log(response);
                    hideLoader();
                    if(response.data.filetransferStatus == 'success'){
                        
                        if(response.data.opendir != ''){
                            $scope.openDrive(response.data.opendir);
                        }
                         //showNotify('Successfully Checkout', 'success');
                    }
                    
                    if(response.data.filetransferStatus == 'failed'){
                        showNotify('Not able to checkout files', 'danger');
                    }
                                        

                    console.log(response);
		}, 
		function myError(response) {
			 console.log(response);
		});			
             hideLoader();
       }
       
   };
  
    $scope.openCreatedPdf    = 	function( path , jobid , metaid ) 
    {
        var inp                 =   {
                                        jobid       :   jobid,
                                        openPath    :   path ,
                                        metaid      :   metaid
                                    };
                                    
        showNotify( 'Please Wait for a while...' , 'success' );
        showLoader('Please wait while download file...'); 
        
        $http.post(API_URL+'downloadArtCreatedPdf',inp).then(function mySuccess(response){
           hideLoader();
            
            if( response.data.status  ==  1 ){
                var url             =   response.data.link;   
                $scope.downloadUrl  =   response.data.link;
                showNotify('Download Initialized...'  , 'success' );
                $scope.fileopened   =   1;
                window.open(url, '_blank');
                
            }else{
                
                showNotify( response.data.errMsg , 'danger' );
            }
        },
        function myError(response)
        {
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
            
        });                         
    };
   
    /*
     *  Drive Open
     *  
     */
    
    $scope.openFolderDrive  =   function(path){
        showLoader('Please wait open folder inprogress..');
        var inp = {filePath : path };

        $http.post( BASE_URL+"openFolderDrive", inp ).then(function mySuccess(response) {

            if(response.data.result     ==  401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation,function(key,val)
                    {
                        $.each(val,function(key,errval)
                        {
                            $.notify(errval,'error');
                        });
                    });
                }
                showNotify( response.data.errMsg  , 'danger' );
                hideLoader();
            }

            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                $scope.openDrive(response.data.path);
            }       
        },function myError(response) {
                showLoader( 'Oops! Try again after sometimes.' );
        });
    }
    
    $scope.openDrive = function( path ) {
         
       // bootbox.confirm("Are you sure to open this book working directive ?", function(result) {
        var result   =   true;
        showLoader('Please wait open folder inprogress..');
            if( result ){
                
                $scope.openFolderButtonText     =   "In Progress";
                var method = "";
                
                //showLoader('Please wait while opening...');
                
                method = "doOpenDriveServer";

                var inp = {

                           filePath : path ,
                           methodName : method  ,
                           processname  :   'checkout'
                           
                };

                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                    if(response.data[0].rmiId > 0) {
                        
                        var attempt = 5;
                        $scope.checkFhStatus(response.data[0].rmiId, attempt);
                        
                        
                    } else {
                       // hideLoader();
                        showNotify( 'Having problem in insert data.', 'danger');
                    }
                    
                    
                },function myError(response) {
                        showLoader( 'Oops! Try again after sometimes.' );
                });
                
                $timeout(function () {
                    $scope.openFolderButtonText     =   "Open Folder";
                    $scope.submitButtonDisabled     =   false;      
                    $scope.checkinButtonDisabled     =   false;      
                }, 2000); 
                    
            }
       // });    
        
    };
    
    $scope.openRawDrive = function(jobid,metadataId,chapter, path ) {

        // showLoader('Please wait open folder inprogress..');
        $scope.openFolderButtonText     =   "In Progress";
        var method = "";

        //showLoader('Please wait while opening...');

        method = "doOpenDriveServer";

        var inp = 

                           {'jobId' :jobid,'metadataId':metadataId,'Chapter':chapter,'type':"RAW",'filePath':path};

        $http.post( BASE_URL+"openSourcePath", inp ).then(function mySuccess(response) {
                 if(response.data.result     ==  401)
                        {
                                if (typeof response.data.validation !== 'undefined') {
                                        $.each(response.data.validation,function(key,val)
                                        {
                                                $.each(val,function(key,errval)
                                                {
                                                        $.notify(errval,'error');
                                                });
                                        });
                                }
                                showNotify( response.data.errMsg  , 'danger' );
                                hideLoader();
                        }

                        if(response.data.result     ==  404)
                        {
                                showNotify( response.data.errMsg  , 'danger' );
                                hideLoader();
                        }
                        if(response.data.result     ==  200)
                        {
                                var attempt         =   1;
                                var filehandlerid   =   response.data.rmID;
                                $scope.checkFhStatus(filehandlerid,attempt);
                        }else {
                        showNotify( response.data.errMsg  , 'danger' );
                }


        },function myError(response) {
                        showLoader( 'Oops! Try again after sometimes.' );
        });

        $timeout(function () {
                $scope.openFolderButtonText     =   "Open Folder";
                $scope.submitButtonDisabled     =   false;      
                $scope.checkinButtonDisabled     =   false;      
        }, 2000); 

   }
    
    $scope.openSourcePathDrive = function(jobid,metadataId,chapter, path ) {
         
        bootbox.confirm("If any file's which is already downloaded in user work directory will be replaced, Are you sure?", function(result) {
        
            if( result ){
                showLoader('Please wait open folder inprogress..');
                $scope.openFolderButtonText     =   "In Progress";
                var method = "";
                
                //showLoader('Please wait while opening...');
                
                method = "doOpenDriveServer";

                var inp = 

                           {'jobId' :jobid,'metadataId':metadataId,'Chapter':chapter,'type':"SOURCE",'filePath':path};

                $http.post( BASE_URL+"openSourcePath", inp ).then(function mySuccess(response) {
                     if(response.data.result     ==  401)
                        {
                            if (typeof response.data.validation !== 'undefined') {
                                $.each(response.data.validation,function(key,val)
                                {
                                    $.each(val,function(key,errval)
                                    {
                                        $.notify(errval,'error');
                                    });
                                });
                            }
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                        
                        if(response.data.result     ==  404)
                        {
                            showNotify( response.data.errMsg  , 'danger' );
                            hideLoader();
                        }
                        if(response.data.result     ==  200)
                        {
                            var attempt         =   1;
                            var filehandlerid   =   response.data.rmID;
                            $scope.checkFhStatus(filehandlerid,attempt);
                        }else {
                       // hideLoader();
                        showNotify( response.data.errMsg  , 'danger' );
                    }
                    
                    
                },function myError(response) {
                        showLoader( 'Oops! Try again after sometimes.' );
                });
                
                $timeout(function () {
                    $scope.openFolderButtonText     =   "Open Folder";
                    $scope.submitButtonDisabled     =   false;      
                    $scope.checkinButtonDisabled     =   false;      
                }, 2000); 
                    
            }
        });    
        
    };
    /*
        *  Check RMI Status
        *  This method check the RMI status for the selected folios.
    */
   
    $scope.checkFhStatus = function(rmiId, attempt) {
        
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
                    hideLoader();
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            /*if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }*/
			$scope.fileHandlerRunningStatus($scope.IsRunning,rmiId,attempt,$scope.noOfAttemptsToCheckIndesign,opt);
	}
	},
        function myError(response) {
            
                 showLoader( 'Oops! Try again after sometimes.' );
                    
	});		
        
    };
    
	$scope.fileHandlerRunningStatus 	=	function(running,rmiId,attempt,endattemptvalue,opt){
		if(running 	==	1){
			$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
		}else{
			if(attempt < endattemptvalue) {
				$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
			} else {
				hideLoader();
				showMessage('Download Status', "File handler is not running. Please check.", 'error');
			}
		}
	}	
	
    $scope.prQcSubmit = function(){
        $("#show-PrQc_submit").click(); 
    }
    
    $scope.reviewSubmit = function(){
        $("#show-review_submit").click(); 
    }
     $scope.xmlDeliverSubmit = function(){
        $("#show-xmlDeliver_submit").click(); 
    }
    
    $scope.triggerChecklistEvent    =   function( jobstgid ){
        var inp   =     { jbstgid : jobstgid };
        
        $http.post(BASE_URL+'readchecklistReport',inp).then(function mySuccess(response) {
            if(response.data.status == 1){  
                
                $scope.readinst                 =       response.data.readinstruction;
                $scope.instructionsArr          =       response.data.instructionarr;
                $scope.instructionsLevelArr     =       response.data.instructionLevelArr;
           //     console.log( $scope.instructionsLevelArr  );
                $scope.readmandatoryinst    =   response.data.mandatoryid;
                $scope.readname     =   response.data.readname;
                $scope.stagename    =   $scope.readname.stagename;
                $scope.roundname    =   $scope.readname.roundname;
                $scope.leveltype    =   $scope.readname.levelname;
                
            }else{
                showNotify(response.data.errMsg, 'danger' );
            }
            
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
        
    }
    
    $scope.showFormErrors       =       function( errors ){
        
        for (var property1 in errors) {
            $( '.'+property1+'_help' ).text( errors[property1] );
            $( '.'+property1+'_help' ).parent().addClass('has-error');
        }
        
    };    
    
    $scope.resetPRQcForm            =       function(){
        $( '.remarks_error_help' ).empty();
        $( '.remarks_error_help' ).parent().removeClass('form-group has-error');
        $('.help-block').text('');
        $('.help-block').parent().removeClass();
        
    };
    
    $scope.bookReviewFinalSubmit = function( errorObj , formobj ){
        
        showLoader();
        
        var errorflag       =   true;
        var errorElm        =   {};
        $scope.resetPRQcForm();
        
        //validation section - start        
            for (i in errorObj.error ) {
                if( errorObj[i] == '' ){              
                    errorflag   =   false;
                    errorElm[i] =   '*Required';              
                }
            }
            
            if(errorObj.error.errorid_13 > 0 ){
                if($.trim($("#remarks_errorvalidation").val()) == "" || $.trim($("#remarks_errorvalidation").val()) == 0){
                    errorflag   =   false;
                    $( '.remarks_error_help' ).text( 'required' );
                    $( '.remarks_error_help' ).parent().addClass('form-group has-error');              
                    return false;
                }
            }
            
            if( !errorflag ){
                $scope.showFormErrors(errorElm);
                return false;
            }  
            
        //validation section - End
        
        if( errorflag ){
            
            console.log( 'Form action ready to proceed from pr_qc submit' );        
            
            var artErrors       =   document.querySelectorAll("input[name='art_remarks[]']");
            errorObj.artErrors  =   artErrors;
            errorObj.artmetaidSelect =   $(".prqcArtRejectionSelection").chosen().val();
        
            var srcFolder               =   $("#srcFolder").val();
            var submitStatus = '';
            var filemoveStatus = '';
            var typeofsubmit            =   formobj.submitype;
           
            formobj.instID         =   [];
            formobj.mandatorytype  =   [];
            formobj.typeoflevel            =   2;
            
            //instruction data end
            showLoader('Please wait while files are copying...');
            //Save error qc log
            $scope.saveBookReviewLogSave( errorObj );                
            //Success stage close 
            //Failure rollback stage.
            
        }
        
    };
    
    $scope.saveBookReviewLogSave = function( errorObj ){
       
        var input   =  { storeQc : { basic : errorObj.basic , error : errorObj.error ,
                                     remarks : errorObj.remarks , 
                                     artmetaidSelect : errorObj.artmetaidSelect 
                                    } };
        var deferred    =   $q.defer();
        $http.post( BASE_URL+"bookreviewErrors", input ).then(function mySuccess(response) {
         
            if( response.data.status ){
                
                showNotify( response.data.errMsg , 'success' );
                var srcFolder               =   $("#srcFolder").val();
				if(srcFolder != ""){
                    var resultofartfigure    =   $scope.closeFolder(srcFolder);
                    resultofartfigure.then(function(rest) 
                    {
						deferred.resolve(response);
						$timeout(function()
						{ 
							hideLoader();
							$window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
							
						},3000 );
						
                    })
                    .catch(function(fallback) {

                    }); 
                }else{
					$timeout(function()
                    { 
                        hideLoader();
                        $window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
                        
                    },3000 );
				}
				
				deferred.resolve(response);
                //project bin screen redirect need to do
                
                
            }else{
                showNotify( response.data.errMsg , 'danger' );
            }
          
        },function myError(response){
			deferred.reject(response);
           shownotify( 'Something went wrong' ,  'danger' );
           return false;
        });
        return deferred.promise;
    };
        
    $scope.prQcFinalSubmit = function( errorObj , formobj ){
        
        console.log( formobj );
        var jbstgid         =   formobj['jbstgid'];
        console.log( jbstgid );
        var returnService   =   $scope.runInternalWebservice( jbstgid );
        
        returnService.then(function( respon ){
            
            if( respon.data.status == 1 || respon.data.status == 4 ){
                
                console.log( 'Am ready to go :' );
                showLoader();

                var errorflag       =   true;
                var errorElm        =   {};
                $scope.resetPRQcForm();

                //validation section - start        
                for (i in errorObj.error ) {
                    if( errorObj[i] == '' ){              
                        errorflag   =   false;
                        errorElm[i] =   '*Required';              
                    }
                }

                if(errorObj.error.errorid_13 > 0 ){
                    if($.trim($("#remarks_errorvalidation").val()) == "" || $.trim($("#remarks_errorvalidation").val()) == 0){
                        errorflag   =   false;
                        $( '.remarks_error_help' ).text( 'required' );
                        $( '.remarks_error_help' ).parent().addClass('form-group has-error');              
                        return false;
                    }
                }

                if( !errorflag ){
                    $scope.showFormErrors(errorElm);
                    return false;
                }  
            
            //validation section - End

                if( errorflag ){

                    console.log( 'Form action ready to proceed from pr_qc submit' );        

                    var artErrors       =   document.querySelectorAll("input[name='art_remarks[]']");
                    errorObj.artErrors  =   artErrors;
                    errorObj.artmetaidSelect =   $(".prqcArtRejectionSelection").chosen().val();

                    var srcFolder               =   $("#srcFolder").val();
                    var submitStatus = '';
                    var filemoveStatus = '';
                    var typeofsubmit            =   formobj.submitype;
                    var instrucdata             =   $scope.Instructionvalidation(formobj);

                    if(instrucdata  ===  false){

                        hideLoader();
                        return false;

                    }else if(instrucdata.length >= 1){

                        console.log(instrucdata);
                        formobj.instID         =   instrucdata[0];
                        formobj.mandatorytype  =   instrucdata[1];

                    }else{
                        console.log(instrucdata);
                        formobj.instID         =   [];
                        formobj.mandatorytype  =   [];
                    }

                    formobj.typeoflevel            =   2;

                    //instruction data end
                    showLoader('Please wait while files are copying...');
                    //Save error qc log
                    $scope.saveErrorQcLogSave( errorObj );                
                    //Success stage close 
                    //Failure rollback stage.

                }
            
            }else{
                showNotify( respon.data.errMsg, 'danger' );
            }

        }).catch(function(fallback) {

        }); 
        
    };
    
    $scope.xmlValidationFinalSubmit = function( errorObj , formobj ){
        
       // showLoader();
        	
        var errorflag       =   true;
        var errorElm        =   {};
		
		$scope.cevalidatewithxml(errorObj);
      //  $scope.resetPRQcForm();
        
        //validation section - start        
            for (i in errorObj.error ) {
                if( errorObj[i] == '' ){              
                    errorflag   =   false;
                    errorElm[i] =   '*Required';              
                }
            }
            
            if( !errorflag ){
                $scope.showFormErrors(errorElm);
                return false;
            }
            
        //validation section - End
        
        if( errorflag ){
            
            console.log( 'Form action ready to proceed from pr_qc submit' );        
            
            var artErrors       =   document.querySelectorAll("input[name='art_remarks[]']");
            errorObj.artErrors  =   artErrors;
            errorObj.artmetaidSelect =   $(".prqcArtRejectionSelection").chosen().val();
            
            
            var srcFolder               =   $("#srcFolder").val();
            var submitStatus = '';
            var filemoveStatus = '';
            var typeofsubmit            =   formobj.submitype;
            var instrucdata             =   $scope.Instructionvalidation(formobj);
            
            if(instrucdata  ===  false){
                
                hideLoader();
                return false;
                
            }else if(instrucdata.length >= 1){
                
                console.log(instrucdata);
                formobj.instID         =   instrucdata[0];
                formobj.mandatorytype  =   instrucdata[1];
                
            }else{
                console.log(instrucdata);
                formobj.instID         =   [];
                formobj.mandatorytype  =   [];
            }
            
            formobj.typeoflevel            =   2;
            
            //instruction data end
            showLoader('Please wait while files are copying...');
            //Save error qc log
            $scope.CeArtvalidationSave( errorObj );                
            //Success stage close 
            //Failure rollback stage.
            
        }
        
    };
    
    $scope.cevalidatewithxml = function(errorObj){

            console.log(errorObj);
            return false;

    }

    $scope.CeArtvalidationSave = function( errorObj ){
		var artReject 		=   $("#artRejct").is(':checked');
		var ceReject  		=   $("#ceRejct").is(':checked');
		var nextskip             =   $("#artStatus").val();
		var ceRejectRemark  	=   $("#ceRemarks").val();
		var artRejectRemark  =   $("#artRemarks").val();
		var deferred    =   $q.defer();
	          
        var input   =  { storeQc : { basic     : errorObj.basic , error : errorObj.error ,
                                     remarks   : errorObj.remarks ,
                                     artReject : artReject ,
                                     ceReject  : ceReject ,
                                     nextskip  : nextskip ,
                                     ceRejectRemark : ceRejectRemark ,
                                     artRejectRemark  : artRejectRemark ,
                                     artmetaidSelect : errorObj.artmetaidSelect 
                                    } };
        
        $http.post( BASE_URL+"artValidationProcess", input ).then(function mySuccess(response) {
            
           
            if( response.data.status ){
                var srcFolder               =   $("#srcFolder").val();
                showNotify( response.data.errMsg , 'success' );
                if(srcFolder != ""){
                    var resultofartfigure    =   $scope.closeFolder(srcFolder);
                    resultofartfigure.then(function(rest) 
                    {
						deferred.resolve(response);
						$timeout(function()
						{ 
							hideLoader();
							$window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
							
						},3000 );
						
                    })
                    .catch(function(fallback) {

                    }); 
                }else{
					$timeout(function()
                    { 
                        hideLoader();
                        $window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
                        
                    },3000 );
				}
				
				deferred.resolve(response);
                //project bin screen redirect need to do
                
                
            }else{
                showNotify( response.data.errMsg , 'danger' );
            }
          
        },function myError(response){
			deferred.reject(response);
			shownotify( 'Something went wrong' ,  'danger' );
			return false;
        });
        return deferred.promise;
    };
    
    $scope.updateMetaXml       =    function( jobstgid , option , filename ){
        
        var input   =   { jobstgid : jobstgid , option : option , metafilename : filename };
        showLoader();
        $http.post( BASE_URL+"editPostedMetaxml", input ).then(function mySuccess(response) {
            
            if( response.data.status ){
                
                //showNotify( response.data.errMsg , 'success' );
                    $timeout(function(){ 
                           hideLoader();
                    },2000 );
                //project bin screen redirect need to do
                
            }else{
                showNotify( response.data.errMsg , 'danger' );
            }
          
        },function myError(response){
            
            //$scope.updateMetaXml( jobstgid , option , filename );
            
            return false;
        });
        
    };
    
    $scope.respwbcRet       =   false;
    $scope.respwbcRetArr    =   [];
    
    $scope.runInternalWebservice    =   function( jobstgid ){
        
        $scope.respwbcRet =   false;
        var inp = { jbstgid : jobstgid };
        var deferred    =   $q.defer();
       
        showLoader();
        
        $http.post( BASE_URL+'runBgWebservice', inp ).then(function mySuccess(response) {
            
            if(response.data.status == 1){
                console.log( response.data.errMsg );
                if( response.data.errMsg != '' ){
                    showNotify( response.data.errMsg , 'success' );
                }
                hideLoader();
                deferred.resolve(response);
            }else if(response.data.status == 4 ){
                response.data.status = 1;
                hideLoader();
                deferred.resolve(response);
            }else{
                showNotify( response.data.errMsg, 'danger' );
                hideLoader();
                deferred.resolve(response);
            }
            
        },function myError(response) {
            showNotify(response.data.errMsg , 'danger' );
            hideLoader();
            deferred.reject(response);
        });
        
        return deferred.promise;
        
    };
    
    $scope.saveErrorQcLogSave = function( errorObj ){
		
        var input   =  { storeQc : { basic : errorObj.basic , error : errorObj.error ,
                                     remarks : errorObj.remarks , 
                                     artmetaidSelect : errorObj.artmetaidSelect 
                                    } };
        var deferred    =   $q.defer();
        $http.post( BASE_URL+"storeQcErrors", input ).then(function mySuccess(response) {
			
            if( response.data.status ){
                
                showNotify( response.data.errMsg , 'success' );
				var srcFolder               =   $("#srcFolder").val();
				
                if(srcFolder != ""){
                    var resultofartfigure    =   $scope.closeFolder(srcFolder);
                    resultofartfigure.then(function(rest) 
                    {
						deferred.resolve(response);
						$timeout(function()
						{ 
							hideLoader();
							$window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
							
						},3000 );
						
                    })
                    .catch(function(fallback) {

                    }); 
                }else{
					$timeout(function()
                    { 
                        hideLoader();
                        $window.location.href = BASE_URL+'projectbin/'+errorObj.basic.jobId;
                        
                    },3000 );
				}
				
				deferred.resolve(response);
                 
                //project bin screen redirect need to do
                
                
            }else{
                showNotify( response.data.errMsg , 'danger' );
            }
        },function myError(response){
			deferred.reject(response);
           shownotify( 'Something went wrong' ,  'danger' );
           return false;
        });
        return deferred.promise;
    };
    // check list start
    // check instruction is exist or not
    $scope.readmandatoryinst    =   [];
	
    $scope.checkoutSubmit   =   function(roundID,stageID,jobID,metadataID,copylevel , jbstgid ){
        
        var inp             =   {   
                                    roundID     :   roundID,
                                    stageID     :   stageID,
                                    jobID       :   jobID,
                                    metadataID  :   metadataID,
                                    copylevel   :   copylevel,
                                    readtype    :   'chapter_level'
                                };  
                                
        var returnService   =   $scope.runInternalWebservice( jbstgid );
        
        returnService.then(function( respon ){
            
            if( respon.data.status == 1 ){
                
                $http.post(BASE_URL+'readchecklistReport',inp).then(function mySuccess(response) {

                    if(response.data.status == 1){    
                        $scope.readinst             =           response.data.readinstruction;
                        $scope.instructionsArr      =           response.data.instructionarr;
                        $scope.instructionsLevelArr      =      response.data.instructionLeveleArr;

                        console.log( $scope.instructionArr );
                        $scope.readmandatoryinst    =   response.data.mandatoryid;
                        $scope.readname     =   response.data.readname;
                        $scope.stagename    =   $scope.readname.stagename;
                        $scope.roundname    =   $scope.readname.roundname;
                        $scope.leveltype    =   $scope.readname.levelname;
                        if(response.data.inputanaylsisvalidate  ==  "YES"){
                            bootbox.confirm("No querie(s) found, Do you want to proceed?", function(result){
                                if(result){
                                    $("#show-submit").click();
                                }
                            });
                        }else{
                            $("#show-submit").click();
                        }
                    }else{
                        showNotify(response.data.errMsg, 'danger' );
                    }

                },function myError(response) {
                    showNotify(response.data.errMsg,'danger' );
                });
        }else{
            showNotify( respon.data.errMsg, 'danger' );
        }
        
        }).catch(function(fallback) {

        }); 
        
    };
    
    $scope.readallchecklist         =   function(){
        if($scope.checkout.allchecklist  ==  true)
        $(".emailrecipieentcheckeditem").prop('checked','checked');
        else
        $(".emailrecipieentcheckeditem").prop('checked',false);
    }
    
    // check list end
    $scope.checkinmandatoryinst     =   [];
    
    $scope.checkoutCheckin  =   function(jbstgid){
         
         var inp            =   {  
                                    jbstgid     :   jbstgid
                                };
                             
        $http.post(BASE_URL+'readchecklistReport', inp ).then(function mySuccess(response) {
            if(response.data.status == 1){
                
                $scope.readinst                 =       response.data.readinstruction;
                $scope.instructionsArr          =       response.data.instructionarr;
                $scope.instructionsLevelArr     =       response.data.instructionLevelArr;
                
                $scope.checkinmandatoryinst    =   response.data.mandatoryid;
                $scope.readmandatoryinst    =   response.data.mandatoryid;
                $scope.readname     =   response.data.readname;
                $scope.stagename    =   $scope.readname.stagename;
                $scope.roundname    =   $scope.readname.roundname;
                $scope.leveltype    =   $scope.readname.levelname;
                
                $("#show-checkin_submit").click();
                
            }else{
                showNotify(response.data.errMsg, 'danger' );
            }
            
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
        
    };
    
    
    $scope.readchecklist = function( jobstgid ){
        
        var inp   =     { jbstgid : jobstgid };
         var deferred    =   $q.defer();
        $http.post(BASE_URL+'readchecklistReport', inp ).then(function mySuccess(response) {
            
            if(response.data.status == 1){
                
                $scope.readinst                 =       response.data.readinstruction;
                $scope.instructionsArr          =       response.data.instructionarr;
                $scope.instructionsLevelArr     =       response.data.instructionLevelArr;
                
                $scope.checkinmandatoryinst    =   response.data.mandatoryid;
                $scope.readmandatoryinst    =   response.data.mandatoryid;
                $scope.readname     =   response.data.readname;
                $scope.stagename    =   $scope.readname.stagename;
                $scope.roundname    =   $scope.readname.roundname;
                $scope.leveltype    =   $scope.readname.levelname;
                
                //$("#show-checkin_submit").click();
                deferred.resolve(response);
            }else{
                showNotify(response.data.errMsg, 'danger' );
                deferred.reject(response);
            }
            
        },function myError(response) {
            deferred.reject(response);
            showNotify(response.data.errMsg,'danger' );
        });
         return deferred.promise;
         
    };
    
    $scope.checkoutReject = function(stageId){
         //$scope.clearWorkflow();
         $("#show-reject_submit").click();
    };
    
    $scope.checkinFinalSubmit = function(formData){
        
        var submitStatus = '';
        var filemoveStatus = '';      
        
        showLoader('Please wait while files are copying...');
        
        $http.post( API_URL+"stageLevelTracker", formData ).then(function mySuccess(response) {
           
            var submitStatus = '';
            var filemoveStatus = '';
            hideLoader();

            if(response.data.filemovement == 'success'){
                  filemoveStatus = true;
            }else{
                 filemoveStatus = 'failed';
                 showMessage('Download Status', "Not able too move files", 'error');
                 return false;
            }

            if(response.data.manageStage == 'success'){
                 submitStatus = true;
             }else{
                 showMessage('Download Status', "Moving stage having problem. Conduct support team. ", 'error');
                 submitStatus = 'failed';
                 return false;
             }

            if(filemoveStatus == true && submitStatus == true){

                showNotify( 'Successfully completed.', 'success');
                $window.location.href = BASE_URL+'projectbin/'+formData.jobId;
                
             }else{

                 return false;
             }
                
        },function myError(response) {
                showLoader( 'Oops! Try again after sometimes.' );
        });
        return false;
    };
    // close user work folder function starts here
    $scope.closeFolder = function( srcFolder ) {
        
        method = "closeFolderServer";
        var inp = {
                   filePath : srcFolder ,
                   methodName : method  
        };
        var deferred    =   $q.defer();
        $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {
            deferred.resolve(response);
        },function myError(response) {
            deferred.reject(response);
            showNotify( response.data  , 'danger' );                    
        });
        return deferred.promise;
    };
    
    $scope.deleteFolder = function( srcFolder ) {
        if(srcFolder != ""){
            method = "deleteFileServer";
            var inp = {
                       filePath : srcFolder ,
                       methodName : method  
            };
            var deferred    =   $q.defer();
            $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {
                deferred.resolve(response);
            },function myError(response) {
                deferred.reject(response);
                showNotify( response.data  , 'danger' );                    
            });
            return deferred.promise;
        }
    };
    
    $scope.prepareObserveXml = function( jbstgid ){
        
        showLoader();
        $scope.observeXmlBtn   =   true;
        
        $http.get( API_URL+"initializeObserveXml/"+jbstgid ).then(function mySuccess(response) {
            hideLoader();
            if( response.data.status == 1 ){
                
                showNotify( response.data.errMsg , 'success' );
                var arrInput    =   { 
                        token : response.data.params.tokenkey  , 
                        table : "api_observexml" , 
                        process : 'Observation XML'
                    };
                
                $( '.prgressSec' ).show(); 
                
                $scope.watchApiTable( arrInput , 1 );
            }
            
            if( response.data.status == 0 ){
                $scope.observeXmlBtn = false;
                showNotify( response.data.errMsg  , 'danger' );    
                
            }
            
        },function myError(response) {
            $scope.observeXmlBtn = false;
            showNotify( response.data.errMsg  , 'danger' );                    
            
        });
        
        
    };
    
    //instruction validation function
    $scope.Instructionvalidation    =   function(formData)
    {
        var returndata              =   [];
        var typeofsubmit            =   formData.submitype;
        var mandatorymodelarray     =   [];
        var parentPopid  =  '';
        
            if(typeofsubmit     ==  'checkout'){
                parentPopid     =       $('div#chapterspop');
            }else if( typeofsubmit     ==  'checkin' ){
                parentPopid     =       $('div#chapterscheckinpop');
            }else if( typeofsubmit == 'prqccheckout' ){
                parentPopid     =       $('div#chapterQcPopUp');
            }
        
            if($scope.readinst.length !==  0){
                
                var checkemptychapter   =   $(parentPopid).find('input[name="readchecklist[]"]:checked').map(function(){return $(this).val();}).get();
                var mandatorylist   =   $scope.readmandatoryinst.map( function(x){ return x; } ).sort();
                var usercheckedid   =   checkemptychapter.map( function(x){ return x; } ).sort();
                
                var correction_data =   $(parentPopid).find('select[name="correct_yn[]"]').map(function(){
                    if($(this).val() != 'NA'){
                        return  $(this).val();
                    }
                }).get();
                
                if(mandatorylist.join(',') == usercheckedid.join(',')    ==  false){
                    $scope.submititemdisabled   =   false;
                    showNotify(' Required Field validation error occured! [ Checklist ]', 'danger' );
                   return false;
                }
                
                var mandatorymodel      =   $(parentPopid).find('.readcheckoutinstruction').each(function(inx){
                    if($(this).is(':checked')   ==  true){
                        mandatorymodelarray.push(1);
                    }else{
                        mandatorymodelarray.push(0);
                    }
                });
                
                var readallinsID        =   $(parentPopid).find('.readcheckoutinstruction:checked').map(function(){return $(this).val();}).get();
                
                returndata.push( readallinsID );
                returndata.push( mandatorymodelarray );
                returndata.push( correction_data );
                
            }           
        
        return returndata;
        
    }
    
    $scope.getbookReviewTypeTable  = function( jobstageid ){
        
        showLoader();
        
        $http.get(BASE_URL+"getbookReviewTypeTable/"+jobstageid) .then(function mySuccess(response) {
            if(response.data.msg == "success"){
                
                var tableRow        =       response.data.tablestr;
                
                //$('.proofReadingTable').html( tableRow );

                var template = angular.element(tableRow);
                var linkFn = $compile(template);
                var element = linkFn($scope);
                // Step 4: Append to DOM (optional)
                $('.proofReadingTable').html(element);
                $(".chosen-select").chosen({ width: '100%' });
                $(".chosen-select").trigger("chosen:updated");
            }
            hideLoader();
        }, 
        function myError(response) {
            
            showNotify( 'Something went wrong , try again.' , 'danger' );
            hideLoader();
            
        }); 
        
    };
    
    $scope.getQcErrorLogTypeTable  = function( jobstageid ){
        
        showLoader();
        
        $http.get(BASE_URL+"getQcErrorLogTypeTable/"+jobstageid) .then(function mySuccess(response) {
            if(response.data.msg == "success"){
                
                var tableRow        =       response.data.tablestr;
                
                //$('.proofReadingTable').html( tableRow );

                var template = angular.element(tableRow);
                var linkFn = $compile(template);
                var element = linkFn($scope);
                // Step 4: Append to DOM (optional)
                $('.proofReadingTable').html(element);
                $(".chosen-select").chosen({ width: '100%' });
                $(".chosen-select").trigger("chosen:updated");
            }
            hideLoader();
        }, 
        function myError(response) {
            
            showNotify( 'Something went wrong , try again.' , 'danger' );
            hideLoader();
            
        }); 
        
    };
    
    $scope.getxmlValidation  = function( jobstageid ){

    showLoader();

    $http.get(BASE_URL+"validateArtxml/"+jobstageid) .then(function mySuccess(response) {
        if(response.data.msg == "success"){

            var tableRow        =       response.data.tablestr;

            //$('.proofReadingTable').html( tableRow );

            var template = angular.element(tableRow);
            var linkFn = $compile(template);
            var element = linkFn($scope);
            // Step 4: Append to DOM (optional)
            $('.proofReadingTable').html(element);
            $('.chosen-select').chosen({});
            $(".chosen-select").trigger("chosen:updated");
			$("div.chosen-container").css('width','470px');
        }
        hideLoader();
    }, 
    function myError(response) {

        showNotify( 'Something went wrong , try again.' , 'danger' );
        hideLoader();

    }); 
        
    };
    
    $scope.artPrqcRejectionDesign   =   false;
    
    $scope.artErrorPR_QC_RejectionDesign        =   function( currentElm ){
      
            var input       =   { metaid : $scope.prQc.basic.metaid };

                if( $scope.prQc.error.errorid_8 > 0 && !$scope.artPrqcRejectionDesign ){

                        $http.post( BASE_URL+"getArtListTableDesignForRejection", input ).then(function mySuccess(response) {

                            if(response.data.status == 1){

                                $scope.artPrqcRejectionDesign   =   true;
                                var tempElement     =   response.data.artTableDesign;
                                //showing pr art rejection table with angular compiled element
                                var temp        =   $compile(tempElement)($scope);
                                var template    =   angular.element(tempElement);
                                var linkFn      =   $compile(template);
                                var element     =   linkFn($scope);

                                $('#artRejectionTable').html(element);

                            }else{
                                showNotify( response.data.errMsg , 'danger' );
                            }

                        },function myError(response){

                            //$scope.artErrorPR_QC_RejectionDesign();

                        });

                }else{
                    
                    if( $scope.prQc.error.errorid_8 == 0 && $scope.prQc.error.errorid_8 !== ''){
                        $scope.artPrqcRejectionDesign = false;
                        $('#artRejectionTable').html('');
                    }
                    
                }
        
    }
    
    $scope.selectionPR_QC_art=[];
    
    // toggle selection for a given employee by name
    $scope.toggleSelection = function toggleSelection(artmetaid) {
       var idx = $scope.selectionPR_QC_art.indexOf(artmetaid);

       // is currently selected
       if (idx > -1) {
         $scope.selectionPR_QC_art.splice(idx, 1);
       }

       // is newly selected
       else {
         $scope.selectionPR_QC_art.push(artmetaid);
       }
     };
    
    // close user work folder function ends here
    $scope.checkoutFinalSubmit = function(formData){
      
	var srcFolder               =   $("#srcFolder").val();
        var submitStatus = '';
        var filemoveStatus = '';
        var typeofsubmit            =   formData.submitype;
        
        var instrucdata             =   $scope.Instructionvalidation(formData);
        
        if(instrucdata  ===  false){
            return false;
        }else if(instrucdata.length >= 1){
            
            formData.instID         =   instrucdata[0];
            formData.mandatorytype  =   instrucdata[1];
            formData.correctiontype  =   instrucdata[2];
            
			var checkcorrectionData 	=	$("select[name='correct_yn[]']").is(':visible');
			if(checkcorrectionData 	==	true){
				if(instrucdata[0].length    !=  instrucdata[2].length){
					showNotify( 'Invalid try , Input selections is invalid.!', 'danger');
					return false;
				}
			}
        }else{
            formData.instID         =   [];
            formData.mandatorytype  =   [];
            formData.correctiontype  =   [];
        }
		
        formData.typeoflevel            =   2;
        
        //instruction data end
        showLoader('Please wait while files are copying...');
        $http.post( API_URL+"stageLevelTracker", formData ).then(function mySuccess(response) {
         
        var submitStatus = '';
        var filemoveStatus = '';
        hideLoader();
            var deletedirpath   =   response.data.deletefiledrive;
            if(response.data.filemovement == 'instructionchecklist'){
                showNotify( response.data.errMsg, 'danger');
                return false;
            }
            
            if(response.data.filemovement == 'success'){
                filemoveStatus = true;
            }else{
                filemoveStatus = 'failed';
				var filemovementerrormsg	= 	(response.data.filemovement == "failed"?"Not able too move files":response.data.filemovement);
                showMessage('Download Status', filemovementerrormsg, 'error');
                return false;
            }

           if(response.data.manageStage == 'success'){
                submitStatus = true;
            }else{
                showMessage('Download Status', "Moving stage having problem. Conduct support team. ", 'error');
                submitStatus = 'failed';
                return false;
            }

           if(filemoveStatus == true && submitStatus == true){
                showNotify( 'Successfully completed.', 'success');
                if(srcFolder != ""){
                    var resultofartfigure    =   $scope.closeFolder(srcFolder);
                    resultofartfigure.then(function(rest) 
                    {
                        $scope.deleteFolder(deletedirpath);
                    })
                    .catch(function(fallback) {

                    }); 
                }
                
                $timeout(function () {
                    $window.location.href = BASE_URL+'projectbin/'+formData.jobId;
                }, 3000); 
            }else{
                return false;
            }

        },function myError(response) {
            showLoader( 'Oops! Try again after sometimes.' );
        });
        
    };
    
    $scope.filetype         =   filetype;
    $scope.fileextension    =   fileextension;
    $scope.complexity       =   complexity;
    $scope.modetype         =   modetype;
    $scope.workinvolved     =   workinvolved;
    $scope.colours          =   colours;
    
    $scope.checkoutArtSubmit    =   function( jobId,metaId,bookid,chapterno,batchId,checkFlag )
    {
        
        $scope.chapterlist          =   [];
        $scope.partlist             =   [];
        $scope.existchapterlist     =   [];
        $scope.showallresponse      =   '';
        $scope.submitButtonDisabled =   true;
        $scope.checkFlag =  checkFlag;
        
        var inp = {
               jobId    :   jobId,
               metaId   :   metaId,
               bookid   :   bookid,
               chapterno:   chapterno,
               batchId  :   batchId,
               checkinFlag: checkFlag
           };
           
        showLoader('Please wait while open data...' );
        $scope.submitButtonText     =   "In Progress";
            
        //var readedcheck   =  $scope.readchecklist( '6258' );
        //readedcheck.then(function(rest) 
        //                        {  }); 
        
        $http.post( BASE_URL+"checkoutxmlread" , inp ).then(function mySuccess(response) {
            
            $scope.bookidshow       =   response.data.Book_id;
            $scope.chaptershow      =   response.data.chaptername;
            $scope.chapterlist      =   response.data.art;
            
            if( response.data.status == 1 ){
               
                var keys        =   Object.keys(response.data.art);
                var totalart    =   keys.length;
                
                if(response.data.art.length >= 1){
                    
                    angular.element('#show-doopenfiles').trigger('click');
                    $scope.heightofmodal        =   600;
                    $scope.saveChapterbutton    =   true;
                    
                }else{
                    
                    showNotify( 'No art file(s) found for this Chapter... '  , 'danger' );
                    $scope.submitButtonDisabled     =   true;
                    $timeout(function(){
                        angular.element('#chapterinfo').trigger('click');
                    },3000);
                    $scope.saveChapterbutton    =   false;
                    
                }
            }
            
            if( response.data.status == 0){
                $scope.artcomplete =   true;
                showNotify( response.data.errMsg  , 'danger' );
            }
            
            hideLoader();   
            
        },function myError(response) {
            
            hideLoader();   
            $scope.artcomplete =   true;
            showNotify( 'Oops! Try again after sometimes.' , 'danger' );
            
        });
      
    }
   
    $scope.artCompletecall   =   function( param,batchid)
    {
       
        $scope.chapterlist          =   [];
        $scope.partlist             =   [];
        $scope.existchapterlist     =   [];
        $scope.showallresponse      =   '';
        $scope.submitButtonDisabled =   true;
        $scope.submitButtonText     =   "In Progress";
        $scope.batchId              =   batchid;
        

        var inp = {
               stageInfo   :   param.data.stageInfo[0],
               serverpath    :  param.data.serverpath
              
           };
           
        var deferred    =   $q.defer();
        console.log(inp);
        
        $http.post( BASE_URL+"checkoutxmlread" , inp ).then(function mySuccess(response) {
            $scope.submitButtonDisabled     =   false;
            $scope.bookidshow       =   response.data.Book_id;
            $scope.chaptershow      =   response.data.chaptername;
            $scope.chapterlist      =   response.data.art;
            if( response.data.status == 1 ){
               
                var keys        =   Object.keys(response.data.art);
                var totalart    =   keys.length;
                if(response.data.art.length >= 1)
                {
                    angular.element('#show-doopenfiles').trigger('click');
                    $scope.heightofmodal        =   600;
                    $scope.saveChapterbutton    =   true;
                }
                else
                {
                    showNotify( 'No art file(s) found for this Chapter... '  , 'danger' );
                    $scope.submitButtonDisabled     =   true;
                    $timeout(function()
                    {
                        angular.element('#chapterinfo').trigger('click');
                    },3000);
                    $scope.saveChapterbutton    =   false;
                }
            }
            if( response.data.status == 0){
                $scope.artcomplete =   true;
                showNotify( response.data.errMsg  , 'danger' );
            }   
            deferred.resolve(response);
                 hideLoader();   
        }, function myError(response) {
            hideLoader();   
                        $scope.artcomplete =   true;
                        showNotify( 'Oops! Try again after sometimes.' , 'danger' );
                        deferred.reject(response);
		});
                $timeout(function () {
                    $scope.submitButtonText     =   "Submit";
                }, 2000); 
            return deferred.promise;
    }
    
    $scope.artFigureDetails =   function( param1 )
    {
        var deferred    =   $q.defer();
        var inp = {jstageId : param1};
        $http.post( API_URL+"artGenerateMetaxml" , inp ) .then(function mySuccess(response) {

            if(response.data.Status == "1") {
                deferred.resolve(response);
            } 
            else 
            {
                hideLoader();
                deferred.reject(response);
                showNotify( response.data.Msg , 'danger' );
            }

        }, 
        function myError(response) {
            deferred.reject(response);
            showLoader( 'Oops! Try again after sometimes.' );
        });
        return deferred.promise;
    };
    
    $scope.validaterequired     =   function(item)
    {
        var checkischecked      =   angular.element("#checkrequired_"+item).is(':checked');
        if(checkischecked   ==  true)
        {
            angular.element("#required_"+item).attr('required',true);
        }
        else
        {
            angular.element("#required_"+item).removeAttr('required');
        }
    };
    
    $scope.artSubmit =   function(batchId )
    {
        var checkincompleted=   $('input[name="partiallycompleted[]"]:checked').map(function(){return $(this).val();}).get();
        var isRej           =   $('input[name="isRect[]"]:checked').map(function(){return $(this).val();}).get();
        var meta            =   $('input[name="metaid"]').val();
        var jobStageId      =   $('input[name="artstageid[]"]').map(function(){return $(this).val();}).get();
        var ChapterJobId    =   $('input[name="ChapterJobId"]').val();
        var metadataStatusId =   $('input[name="metadataStatusId"]').val();
        var artName         =   $('input[name="chapters[]"]').map(function(){return $(this).val();}).get();
        var artMeta         =   $('input[name="artmetaid[]"]').map(function(){return $(this).val();}).get();
        var files           =   $('select[name="file[]"]').map(function(){return $(this).val();}).get();
        var type            =   $('select[name="type[]"]').map(function(){return $(this).val();}).get();
        var complexity      =   $('select[name="complexity[]"]').map(function(){return $(this).val();}).get();
        var mode            =   $('select[name="mode[]"]').map(function(){return $(this).val();}).get();
        var workinvolved    =   $('select[name="workinvolved[]"]').map(function(){return $(this).val();}).get();
        var inputcolor      =   $('select[name="inputcolor[]"]').map(function(){return $(this).val();}).get();
        var outputcolor     =   $('select[name="outputcolor[]"]').map(function(){return $(this).val();}).get();
        var remarks         =   $('input[name="remarks[]"]').map(function(){return $(this).val();}).get();
        var completed       =   $('input[name="isCompleted[]"]:checked').map(function(){return $(this).val();}).get();
        var chaptername     =   $('input[name="chaptername"]').val();
        var checkFlag       =   $('input[name="CheckFlag"]').val();
        var checkemptyfilename  =   [];
        
        console.log(type);
        $('input[name="chapters[]"]').each(function(value)
        {
            if($(this).val()){}else{
                checkemptyfilename.push($(this).val());
            }
        });
        
        if(checkemptyfilename.length    >=  1)
        {
          showNotify('Art name should not be empty', 'danger' );
            return false;
        }
        
        var checkemptyfileExtension  =   [];
        $('select[name="file[]"]').each(function(value)
        {
            if($(this).val()){}else{
                checkemptyfileExtension.push($(this).val());
            }
        });
        
        if(checkemptyfileExtension.length    >=  1)
        {
          showNotify('Art File should not be empty', 'danger' );
            return false;
        }
    
        var inp             =   {
                                    checkinfile :  checkincompleted,
                                    isRej       :   isRej ,
                                    isCompleted :   completed,
                                    metadataStatusId : metadataStatusId,
                                    batchId     :   batchId,
                                    jobID       :   ChapterJobId,
                                    artName     :   artName ,
                                    artmetaid   :   artMeta,
                                    files       :   files , 
                                    type        :   type , 
                                    complexity  :   complexity , 
                                    mode        :   mode , 
                                    workinvolved:   workinvolved , 
                                    inputcolor  :   inputcolor ,
                                    outputcolor :   outputcolor ,
                                    metaid      :   meta,
                                    remarks     :   remarks,
                                    chaptername : chaptername,
                                    jobStageId  : jobStageId,
                                    checkFlag   : checkFlag
                                }; 
        
        $scope.savechapterdisabled  =   true;
        showLoader( 'Pleasse wait while adding data...' );
        $http.post( API_URL+"artsubmit" , inp ) .then(function mySuccess(response){    
            hideLoader();
           
            if(response.data.status == 'success' ){
                var srcFolder = $("#srcFolder").val();
                $scope.closeFolder(srcFolder);
                    /* userwork folder close */
                showNotify('Successfully completed', 'success' );
                $timeout( function(){ window.location.href    =    BASE_URL+'projectbin/'+ChapterJobId; }, 4000 );               
            }else{
                $scope.savechapterdisabled  =   false;
                 showNotify(response.data.msg, 'danger' );
                 return false;
            }

        },function myError(response) {
            $scope.spitcomplete =   true;
            $scope.submitButtonDisabled     =   false;
            $scope.savechapterdisabled  =   false;
            showLoader( 'Oops! Try again after sometimes.' );
        });
    };
    
    $scope.viewjobSheet   =   function() 
    {   
        if($scope.viewjobsheet  ==  "" || $scope.viewjobsheet   ==  undefined)
        {
            return false;
        }
        var jobid           =   $(".jobsheetviewdata").data('getjobid');
        var meta_id         =   $(".jobsheetviewdata").data('getmetaid');
        var chapterno       =   $(".jobsheetviewdata").data('getchpno');
        var bookid          =   $(".jobsheetviewdata").data('getbookid');
        var inp             = 	{
                                        jobId       :   jobid,
                                        metadataid  :   meta_id,
                                        Chapter     :   chapterno,
                                        bookid      :   bookid,
                                        roundid     :   $scope.viewjobsheet
                                    };
        $scope.htmlcon      =   "Chapter XML Information";
        $('#show-edit').trigger('click');
        $('div#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
                url         :   API_URL + "getChapterjobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            $('div#xmlContent').empty();
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('div#xmlContent').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('div#xmlContent').html(response.errMsg);
            }
            else
            {
                $('div#xmlContent').html('<p class="text-center">'+response.errMsg+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('div#xmlContent').html(response.errMsg);
        });
    };
      
    $scope.postPdfCreationMeta  =   function()
    {
        showLoader('Please wait whilde creating PDF...');
        $scope.openFolderBtn    =   true;
        $scope.creatpdf_inprog  =   true;
        
        var jobid =  $("input[name='jobId']").val();
        var metadataid =  $("input[name='metadataid']").val();
        var artmetaid   =   $("input[name='artmetadataID']").val();
        
        var inp     =   {
            artmetaid   :   artmetaid ,
            jobId       :   jobid ,
            metadataid  :   metadataid ,
            processtype :   '1'
        };
        
        $http.post( BASE_URL+"doArtfigurePdfCreationxml" , inp ).then(function mySuccess(response) {
            
            $scope.openFolderBtn    =   false;
            $scope.creatpdf_inprog  =   false;
            $scope.openCreatedPdfShow = false;
            
            hideLoader();
            if( response.data.status == 1 ){
                
                showNotify( response.data.errMsg  , 'success' );
                
                var arrInput    =   { token : response.data.params.tokenkey  , 
                    table : "api_pdfcreation"  ,  
                    jobid : jobid , 
                    artmetaid   :   artmetaid , 
                    metaid  :   metadataid , 
                    process :   'Art Pdf '
                };
                
                $( '.prgressSec' ).show(); 
                
                $scope.watchApiTable( arrInput , 1 );
                
            }  
            if( response.data.status == 0 ){
                showNotify( response.data.errMsg  , 'danger' );
            }  
            
        }, function myError(response) {
            hideLoader();   
            showNotify( 'Oops! Try again after sometimes.' , 'danger' );
        });
            
        };
        
     //'6523','4758','Chapter_5', '172.24.191.59/SP_BOOKS/PRODUCTION/463351_1_En/S600/PAGINATION_FILES/Chapter_5/'   
     $scope.bookMergeProcess        =       function( jobId, metaid, jobStageId ){

         var inp     =   {
            jobId   :   jobId ,
            metadataid  :   metaid ,
            jobStageId :  jobStageId
        };

        $http.post(API_URL+"startbook", inp ).then( function mySuccess( response ) {
            
            
             if(response.data.status == 1 ) {
                showNotify( response.data.errMsg , 'success' ); 
                $window.location.reload();
             }else{
                showNotify(  response.data.errMsg , 'danger' );
                
            }

        },
        function myError(response) {

                 showLoader( 'Oops! Try again after sometimes.' );

        });	
    };
    
    $scope.BookPrQcSubmit  = function(){
        showNotify( "Book Merge pdf process not completed", 'danger');
        return false;
    };
    
    $scope.watchApiTable        =       function( input , attempt ){

        var inp = input;

        $http.post(API_URL+"checkApiTableStatus", inp ).then( function mySuccess( response ) {

            var progval     =   $scope.noOfAttemptsToCheckIndesign * attempt;
            $( '#createPdfProgress' ).attr( 'style' ,  'width:'+progval+'%' );

            if(response.data.status == 2 ) {

                $( '#createPdfProgress' ).attr( 'style' ,  'width:99%' );

                $timeout( function(){   
                    $( '.prgressSec' ).hide(); 
                    $scope.openCreatedPdfShow = true;
                    $scope.observeAvailale  =   true;
                    showNotify(  response.data.remarks , 'success' );
                
                    
                }, 2000 );


            } else if(response.data.status == 3 ){
                
                showNotify(  response.data.remarks , 'danger' );
                
                $( '.prgressSec' ).hide(); 
                
                $scope.observeXmlBtn   =   false;
                
            }else {

                attempt++;
                if(attempt < $scope.noOfAttemptsToCheckIndesign) {
                    $timeout( function(){ $scope.watchApiTable( input , attempt ); }, 5000 );
                } else {
                    console.log('waiting over');
                    showNotify( inp['process']+' Creation Status : '+"Waiting time limit crossed , kindly check with tools", 'danger');
                    $( '.prgressSec' ).hide(); 
                }

            }

        },
        function myError(response) {

                 showLoader( 'Oops! Try again after sometimes.' );

        });	
    };
        
    $scope.rejectStage        =       function( userdefinId, goToStage, currentStage, jobid ){
        
        showLoader('Please wait...');
		
		if(typeof($scope.checkout1.inputRemarks) == 'undefined' || $scope.checkout1.inputRemarks === null){
		var remarks           =   '';
		}else{
			
			var remarks           =   $scope.checkout1.inputRemarks;
		}
        
        var quantity          =   $scope.checkout1.inputQuantity;
		
		if(remarks == "" ){
			showNotify( 'Remarks should not be empty'  , 'danger' );
			hideLoader();
			return false;
		}
				
        var inp             =   { userDefinedId     :  userdefinId,
                                  goToStageId       :   goToStage ,
                                  currentStageId    :   currentStage,
                                  quantity          :   quantity,
                                  remarks           :   remarks
                              }; 

        $http.post(API_URL+"rejectProcess", inp ).then( function mySuccess( response ) {
        hideLoader();
            if(response.data.status == 2 ) {
                showNotify('Successfully completed', 'success' );
                $timeout( function(){ window.location.href    =    BASE_URL+'projectbin/'+jobid; }, 4000 ); 
            } else if(response.data.status == 3){
                showNotify( 'BookMerge process is inprogress, Kindly proceed after bookMerge process is completed'  , 'danger' );
            } else {
				showNotify( 'Request not completed'  , 'danger' );
			}

        },
        function myError(response) {
             hideLoader();

                 showLoader( 'Oops! Try again after sometimes.' );

        });	
    };
    
    $scope.addArtItem = function(){
        
        //var templateElement     =   '<tr class="clear ng-scope" ><td><input name="chapters[]" class="form-control ng-pristine ng-untouched ng-valid ng-not-empty ng-valid-required" value="" ng-model="FILE_NAME" required="" type="text"></td><td> <select  class="form-control" name="file[]" ng-model="INPUT_FILE" required/><option  value=""> -- Select -- </option><option ng-repeat="filety in filetype track by $index"  value="{{filety}}" >{{filety}}</option></select></td><tr>';   
        var templateElement     = '11';
        var temp                =   $compile(templateElement)($scope);
        //  console.log(temp);return false;
        var chapId = $scope.chapterlist.length;
        $scope.chapterlist.push(temp);
        console.log($scope.chapterlis);
        var newchapId = parseInt(chapId);
       // console.log($('#chapter_'+newchapId).find("tr").length);
        $('#chapter_'+newchapId).removeAttr('readonly');
        //  $('#chapter_'+newchapId).find("input[name='chapters[]']").removeAttr('disabled');
        //var ddd =  $('#chapter_'+newchapId).find('td').lenght;
        console.log('#chapter_'+newchapId);
        
        //angular.element(document.getElementById("newArt")).append(temp);
        
     };
        
    $scope.removeajaxRow    =   function(index,event){
		var item_id =  $(event.target).attr("id");
		if (confirm("Are you sure want to delete this?")){
                    showLoader('Please wait...');
                    if(item_id !=''){
                            var inp             =   { artmetaId     :  item_id}; 
                            $http.post(API_URL+"deleteArtRecords", inp ).then( function mySuccess( response ) {
                            hideLoader();
                                if(response.data.status == 2 ) {
                                    $scope.chapterlist.splice(index, 1);
                                    showNotify( response.data.errMsg  , 'danger' );
                                    //$timeout( function(){ window.location.href    =    BASE_URL+'projectbin/'+jobid; }, 4000 ); 
                                } else {
                                     showNotify( response.data.errMsg  , 'danger' );
                                }

                            },
                            function myError(response) {
                                 hideLoader();

                                     showLoader( 'Oops! Try again after sometimes.' );

                            });

                    }else{
                         hideLoader();
                        $scope.chapterlist.splice(index, 1);
                    }
				//do your process of delete using angular js.
                }
		
        };  
   
    $scope.deleteArtItem = function(name){				
		
          console.log(name);
          $scope.chapterlist.splice( index, name );
          var index = -1;		
		var comArr = eval( $scope.chapterlist );
                console.log(comArr);
                return false;
		for( var i = 0; i < comArr.length; i++ ) {
                   
			if( comArr[i] == name ) {
				index = i;
				break;
			}
		}
		if( index === -1 ) {
			alert( "Something gone wrong" );
		}
		$scope.chapterlist.splice( index, 1 );		
	};
        
    $scope.downloadSupportfile = function(workupPath,stagedetails,openpath){				
        showLoader('Please wait...');
        var inp             =   { workuppath : workupPath,batchId:stagedetails,openpath }; 
        $http.post(API_URL+"downloadsupportPath", inp ).then( function mySuccess( response ) {
        hideLoader();
            if(response.data.status == 2 ) {
                showNotify('Successfully completed', 'success' );
                //$timeout( function(){ window.location.href    =    BASE_URL+'projectbin/'+jobid; }, 4000 ); 
            } else {
                showNotify( 'No work-up file(s) to download'  , 'danger' );
            }

        },
        function myError(response) {
            hideLoader();
            showLoader( 'Oops! Try again after sometimes.' );
        });	
    };

    $scope.select_platform      =   function(platform , default_msg ){
        
        var selected_val  =  platform.toLowerCase();
       
            bootbox.prompt({
                title: "Choose the Mode",
                inputType: 'select',
                inputOptions: [
                    {
                        text: 'Choose one...',
                        value: '',
                    },
                    {
                        text: 'FPP',
                        value: 'FPP',
                    },
                    {
                        text: 'CAP',
                        value: 'CAP',
                    },
                    {
                        text: 'AutoPage',
                        value: 'AUTOPAGE',
                    }
                ],
                callback: function (result) {
                    console.log(result);
                    $('#mode_opt').val( result );
                }
            });            
        
    };
         
    $scope.autoPageSubmit   =   function( jobid , jobstageid ){
              
        //step 1 ;
        //trigger the submit event , close the current stage and do autostage movement

        //step 2;
        //post the metafile for the current stage

        //step 3
        //transfer this into project bin    -   [on success] 
        //roleback auto page stage with prober error msg.
        
        var optionsObj      =   $scope.formAdditionalOptions;
        
        var inputJson           =       {
            platform    :   optionsObj.hid_platform ,  
            arttags     :   1 , 
            location    :   optionsObj.location , 
            mode        :   optionsObj.mode ,  
            autopageext :   optionsObj.autopageext , 
            withprint   :   optionsObj.withprint
        };  
        
        var autoCheckout        =       {  
                                            checkin :    0       , 
                                            jobId   :    jobid   , 
                                            inputQuantity    :   '10' , 
                                            jbstgid          :   jobstageid , 
                                            outputQuantity   :   '10'  ,
                                            inputRemarks     :   '' , 
                                            optionalParamJson :   JSON.stringify( inputJson )                                         
                                        };
                                        
        $scope.validationSignal     =   false;
        showLoader();
        $http.post(BASE_URL+"validateAutopageSignal", autoCheckout ).then( function mySuccess( response ) {
            
             if(response.data.status == 1 ) {                 
                //$timeout( function(){ window.location.href    =    BASE_URL+'projectbin/'+jobid; }, 4000 ); 
                $scope.checkinFinalSubmit( autoCheckout );
                
            } else {
                showNotify( response.data.errMsg  , 'danger' );
                hideLoader();
            }
            //
    
        });
        
        
        
          
    };
     
    $scope.qmsspike                 =       function(jobId, userId, bookId,type){

        if(type     ==  'qms'){
                $scope.bookTitle        =   bookId;
                $scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
                $('#iframeqms').attr('src',$scope.srciframepath);
        }else{
                $scope.bookTitle        =   bookId;
                $scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
                $('#iframespike').attr('src',$scope.srciframepath);
        }
            
    };
    
    $scope.compareJs                 =       function(jobId, roleid, stage,chapter, jspath,jrole){

       $scope.bookTitle        =   jobId;
       $scope.srcijcframepath    =   JSCOMPARE_URL+"?titleacronym="+jobId+"&stage="+stage+"&chapter="+chapter+"&userrole="+jrole+"&jobsheet="+jspath;   
	   
	   console.log($scope.srcijcframepath);
	   
       $('#iframejscompareview').attr('src',$scope.srcijcframepath);
            
    };
    
    
    $(document).on('change', '.chosen-select', function(evt, params) {
        
       var selectedArtValue     =   $(this).val();
       if( selectedArtValue ){
            $('#errorid_8').val(selectedArtValue.length);
            
        }else{
            $('#errorid_8').val(0);
           
        }
        totalerrorCountCalc();
         
    });
    
    $(document).on('keyup', "input[name*='errorid_']" , function () {
       totalerrorCountCalc();
    });
    
    $(document).on('focusout', "input[name*='errorid_']" , function () {
       totalerrorCountCalc();
    });
    
    $(document).on('blur', "input[name*='errorid_']" , function () {
       totalerrorCountCalc();
    });
    
    $(document).on('focusin',"#remarks_errorvalidation",function(){
        $("#remarks_errorvalidation").css('color','black');
    });
    
    function totalerrorCountCalc(){ 
        
        var tempcount   =   0;
        
            $( "input[name*='errorid_']" ).each(function() {
                
                if(  $(this).attr( 'id' ) !==  'errorid_13' ){
                    var getvalue        =   ($.trim($(this).val()) == "" || $.trim($(this).val()) == 0?0:$(this).val()); 
                    var temindx        =   parseInt(getvalue);
                    tempcount        =  tempcount+temindx;
                }
                
            });
            
            if( parseInt( $('#errorid_8').val() > 0 ) )
                tempcount   =   tempcount+parseInt( $('#errorid_8').val());
        
        $('#errorid_13').val(tempcount);
        $scope.prQc.error.errorid_13 =tempcount;
        
    }
    
    $(document).on('change', ".changeCorrection" , function () {
       
        var index    =   $(this);
        var selval   =    $(index).val().toString();
       
       if( selval ==  'no' ){
           
           $(index).parent().parent().find('.insinput1 > input').val( $('#currentusername').val() );
           $(index).parent().parent().find('.insinput2 > input').val( $('#currentdate').val(  ) );
           
       }else{
           $(index).parent().parent().find('.insinput1 > input').val( '' );
           $(index).parent().parent().find('.insinput2 > input').val( '' );
       }
       
    });
    
    //retrieve versions
    $scope.alfrescodata     =   [];
    $scope.getretrieve      =       function(taskmetaid,jobId,alfrescoID)
    {
        showLoader('Please wait while Submit ...');
        var inp             = 	{
                                    metadataId  :   taskmetaid,
                                    jobId       :   jobId,
                                    alfrescoId  :   alfrescoID
                                };
                                
        var deferred        =   $q.defer();
        $http.post(API_URL+"alfrescoRetrieveVersions",inp) .then(function mySuccess(response) 
        {
            
                hideLoader();
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                return false;
            }
            if(response.data.result     ==  401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation,function(key,val)
                    {
                        $.each(val,function(key,errval)
                        {
                            $.notify(errval,'error');
                        });
                    });
                }
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  200){
                $scope.alfrescodata     =   response.data.data;
                $("#show-alfresco").trigger('click');
            }
            deferred.resolve(response);
        }, 
        function myError(response) 
        {   
            hideLoader();
            deferred.reject(response);
        });	
        
        return deferred.promise;
    }
    
    //show client ack remarks commands
    $scope.showAlfrescoerror   =   function(data){  
        var printMsg       =   (data.REMARKS == null || data.REMARKS == "" ) ? 'Remarks not found..' : data.REMARKS;
        $scope.Msgbox 	=   "Alfresco Error Log Files";
        $('#trigger-alfresco').trigger('click');
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
    
});

