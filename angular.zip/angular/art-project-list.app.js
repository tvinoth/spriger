/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ( $scope, $http , $window ,  $timeout ) {
	
    $scope.userId = 0;
    $scope.projectList = []; 
    $scope.UserDetails = {};
    $scope.Checkout =   false;
    $scope.showProject = false;
    $scope.menuParent   =   'Pre-Production';
    $scope.menuChild    =   'ArtProcess';
    
    $scope.jobListView       =   true;
    $scope.chapterListView      =   false;
    
    
    /*
     *  Get User Details
     *  This method get the logged in user details from the session.
    */
        
    $scope.getUserDetail = function (){
        
	$scope.userName = "";
	    $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) {
			 if(response.data.msg == "success") {
				$scope.userName = response.data.user_name;
				$scope.roleName = response.data.role_name;
				$scope.UserDetails = response.data;
				$scope.showProjectList();
			 } else {
				window.location.href= BASE_URL+"?expired";
			 }
		}, 
		function myError(response) {
                    
                    showLoader( 'Oops! Try again after sometimes.' );
                    
		});
	
    };
    
    $scope.getUserDetail();
    
    $scope.showProjectList = function(){
	
        $scope.projectList = [];
	var inp = { 
                    user_id : $scope.UserDetails.user_id , 
                    team_id : $scope.UserDetails.team_id
                  };
	
        $http.get(BASE_URL+"getArtProcessBookList", inp) .then(
            function mySuccess(response) {
                $scope.projectList = response.data.data;
                $scope.userId       =   response.data.userId;
                $scope.vm = {};
                $scope.vm.dtOptions = {};
            },function myError(response) {
               
                showNotify( 'Kindly reload the page &nbsp;' , 'danger');
            });	
    };
    
    $scope.chapterList      =   [];
    
    
    $scope.artContinue      =   function( jb_obj  ,  cur_elem ){
        
        var job_id      =       ( jb_obj.JOB_ID );
        
        var inp  =   {
            jobid  :   job_id            
        };
        
        window.location.href        =       BASE_URL+"getChapterInfo/"+job_id;  
        return false;
   
    }
    
    $timeout(function () {
        //angular.element('#downloadButton').trigger('click');
    }, 2000); 
    
    $scope.qmsspike                 =       function(jobId, userId, bookId,type)
    {
        if(type     ==  'qms')
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
            $('#iframeqms').attr('src',$scope.srciframepath);
        }
        else
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
            $('#iframespike').attr('src',$scope.srciframepath);
        }
    };


    
});