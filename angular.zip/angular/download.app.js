/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */

ngApp.controller('ngController', function ( $scope , $http , $filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
    
    $scope.userId       = 	0;
    $scope.projectList 	= 	[];
    $scope.showProject 	= 	false;
	
    $scope.menuParent 	= 	'Download';
    $scope.menuChild  	= 	'';
    $scope.noOfAttemptsToCheckIndesign  =   10;
    if( isNaN( getUrlParameter(1) ) ){
        $scope.searchrounddownload  =   "104";
    }else{
        $scope.searchrounddownload  =   getUrlParameter(1);
    }
    /*
     *  Get User Details
     *  This method get the logged in user details from the session.
     *  
    */
    
    $scope.contentloadtimer     =   1;
    $scope.getDownloadFailedList = function( ){
       
        var requesturl          =       BASE_URL+"getDownloadFailedList";
        if( $scope.searchrounddownload == 119 ){
            var requesturl          =       BASE_URL+"getDownloadFailedList/"+$scope.searchrounddownload;
        }
        
        $scope.downloadFailed  =   null;
        $http.get( requesturl ) .then(
            function mySuccess( response ){  
                  $scope.downloadFailed   =   response.data.downloadfailed; 
            } ,              
            function myError( response ){ 
               if($scope.contentloadtimer    <  10){
                   $scope.getDownloadFailedList();
               }
               if($scope.contentloadtimer    ==  10){
                   showNotify('Kindly reload page error occured.'  , 'danger' );
                   return false;
               }
               $scope.contentloadtimer++;      
           });
    }
        
    $scope.retryMetaExtractor = function( item ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
           
           if(result){
               
               var inp      =      {  book_id : item.BOOK_ID  };
               
               $http.post( BASE_URL+'' , inp ).then( function mySuccess( response ){
                   
                   
                   
               }, 
               function myError(response) {
                    console.log(response);
                    showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
           }
            
        });
    
    }
    
    $scope.contentloadtimer     =   1;
    $scope.jobassigned     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
        var requesturl          =       BASE_URL+"jobassigned";
        if( $scope.searchrounddownload == 119 ){
            var requesturl          =       BASE_URL+"jobassigned/"+$scope.searchrounddownload;
        }
        
        $http.get( requesturl  ).then(function mySuccess( response ){  
            $scope.jobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
        } ,
        function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;
        });
    }
    
    $scope.latejobassigned   =   [];
    
    $scope.latejobassigned     	=   function(){
        
        $scope.vm = {};
        $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
        var requesturl   =   BASE_URL+"lateCorrectionDownload/"+ $scope.searchrounddownload;
        
        if( $scope.searchrounddownload == 119 ){
            
        }else{
           return false;
        }
        
        $http.get( requesturl  ).then(function mySuccess( response ){  
            $scope.latejobassigned   =   response.data.jobassigned;
            $scope.userlist      =   response.data.amUserList;
        } ,
        function myError( response ){ 
            if($scope.contentloadtimer    <  10){
                $scope.jobassigned();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            $scope.contentloadtimer++;
        });
        
    }
    
    $scope.assignAm = function(pmselect,item){
       
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
             
            if( result ){                
                showLoader( 'please wait for a while...' );
                    var inp = {	user_id : pmselect  , book_id : item.BOOK_ID };
                    
                    $http.post( API_URL+"jobassignAm" , inp ).then(function mySuccess(response) {
                        hideLoader();
                          
                             if( response.data.status == 1 ){                                 
                                 showNotify( response.data.msg , 'success' );
                             }
                             
                             if( response.data.status == 0 ){                                 
                                 showNotify( response.data.msg , 'danger' );
                             }
                        
                    },function myError(response) {
                        showMessage('Message', response.data , 'Oops , something went wrong try again after sometimes.' ); 
                });
            }
            
        });
        
    }
    
    $scope.showXMLInModal = function( jobId , round ){   
        
        var inp = { jobId: jobId };
        
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	
        $http({
                url: API_URL + "getJobXMLInfo/"+jobId+'/'+round,
                method: 'GET',
             })
            .success(function(response) {
		$('#xmlContent').html(response);
            })
            .error(function(response) {
		console.log(response);
            });
    }
    
    $scope.showXMLInModal2   =   function(item) 
    {     
        var inp             = 	{
                                        jobId       :   item.JOB_ID,
                                        metadataid  :   item.METADATA_ID,
                                        Chapter     :   item.CHAPTER_NO,
                                        bookid      :   item.BOOK_ID,
                                        roundid     :   item.ROUND_ID
                                    };
        $scope.htmlcon      =   "Chapter XML Information";
        $('#show-edit-late').trigger('click');
        $('#xmlContent2').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
                url         :   API_URL + "getChapterjobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if( response.result == 401 ){    
                $scope.errorshow    =   true;
                showNotify( response.errMsg , 'danger' );
                $scope.shownotavaiablechapter   =   response.validation;
                $('#xmlContent2').html('');
                return false;
            }
            if(response.xmlcount >= 1)
            {
                $('#xmlContent2').html(response.errMsg);
            }
            else
            {
                $('#xmlContent2').html('<p class="text-center">'+response.errMsg+'</p>');
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    
    $scope.showMeataextratorremarksview = 	function(params){   

             var printMsg    =   params;//( params.UPDATE_REMARKS == null ) ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
            
    //show meta extrator remarks commands
    $scope.showUploadRemarksview = 	function(params){   
         var printMsg    =   ( params.UPLOAD_REMARKS == null ) ? 'remarks not found..' : params.UPLOAD_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Jobsheet Uploade";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
    
    $scope.showDownloadRemarksview = 	function(params){   
         var printMsg    =   ( params.APFT_REMARKS == null || params.APFT_REMARKS == '' ) ? 'remarks not found..' : params.APFT_REMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Jobsheet Download";
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
   
    $scope.sendRedoExtration 			= 	function(params){   
            
           var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
           $('#show-redo').trigger('click');
           $scope.Msgbox 	=	"Success Redo";
           $('#redofailed').html('<p class="text-center">please wait for a while..</p>');
           
        };
    
    $scope.showRedoview =   function(params){
             var printMsg    =   ( params.SR_REMARKS == null ) ? 'remarks not found..' : params.SR_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Client Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
        
    $scope.showSuccessredologview   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.CLIACKID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
	
	$scope.downloadRedo 			=	function(params){
	
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "api/downloadRedo/"+jobid+'/'+params.ROUND_ID;  
	   var deferred    =   $q.defer();	   
		
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            showLoader('Please wait while opening...');                
            if( response.data.status == 1 ){
				deferred.resolve(response);
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 ){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });
            
		
	};
	
	$scope.retryupdate 			=	function(params){
	
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
	   
       var jobid        =   params.JOB_ID;
	   
	   
       var dynamic_url  =   "api/redojsRetry/"+jobid+'/'+params.ROUND_ID;   
	   
	
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {
		  
            showLoader(response.data.errMsg);                
            if( response.data.status == 1 ){
				        params.optiontype = '2'
                $scope.retryJobsheetUpdate(params);
            }
			
			if( response.data.status == 2 ){
				params.optiontype = '1'
                $scope.retryJobsheetUpdate(params);
            }


            if( response.data.status == 0 ){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });
            
		
	};

	
    
     $scope.retryJobsheetUpdate 			= 	function(params){
     
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
	   var metaid		=	null;
	   if(params.optiontype == 2){
		  optionType = 'LogRetry';
	   }else{
		   optionType = 'New';
	   }
       var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/RECEIPT/'+metaid+'/'+optionType;   

       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {      

              $timeout( function(){  
                hideLoader();
                showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );



            } else {
               showNotify( response.data.errMsg , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
    $scope.retryJobsheetDownload    = 	function(params){
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobdownloadid        =   params.APFTID;
       var dynamic_url  =   "retrydownload/"+jobdownloadid;   

       $http.get(API_URL+dynamic_url).then(function mySuccess(response) {
            if(response.data.status == 1) {
              $timeout( function(){  
                hideLoader();
                showNotify(response.data.errMsg , 'success' );
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );
               }, 5000 );
            }
            if(response.data.status == 0) {
               showNotify(response.data.errMsg , 'danger' );
               hideLoader();
            }

        },function myError(response) {
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
    $scope.retryJobsheetUpload 			= 	function(params){   
            
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();

        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/RECEIPT';      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
             showNotify( 'Oops, Kindly reload the page...' , 'danger' );
         });

        //$('#show-redo').trigger('click');
        //$scope.Msgbox 	=	"Success Redo";
        //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');

        };
    
    $scope.sendRedo = function(params) 
    {   
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) 
        {
            if(result) 
            {
                var inp 	= 	{ jobID: params.JOB_ID};
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success Redo";
                $('#redofailed').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $http({
                                url: BASE_URL + "retrySuccessRedo",
                                method: 'post',
                                data:inp
                         })
                        .success(function(response) {
                                $('#redofailed').html(response);
                        })
                        .error(function(response) {

                        });
            }
        });
    }
	$scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {

        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            /*if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }*/
			$scope.fileHandlerRunningStatus($scope.IsRunning,rmiId,attempt,$scope.noOfAttemptsToCheckIndesign,opt);
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    };  

	$scope.fileHandlerRunningStatus 	=	function(running,rmiId,attempt,endattemptvalue,opt){
		if(running 	==	1){
			$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
		}else{
			if(attempt < endattemptvalue) {
				$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
			} else {
				hideLoader();
				showMessage('Download Status', "File handler is not running. Please check.", 'error');
			}
		}
	}	
   
    $scope.contentloadtimer     =   1;
    $scope.getAllPrdLocations    =       function(){
        
        $scope.locationList     =   [];        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){   
                if($scope.contentloadtimer    <  10){
                    $scope.getAllPrdLocations();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                $scope.contentloadtimer++;      
        });
    }
    
    $scope.getAllPrdLocations();
    
    $scope.chgPrdLoc             =       function( drpdwn , row_info ){
        
        bootbox.confirm("Are you sure to proceed on this ?", function( result ) {
         $('#xmlContent1').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	    
            if( result ){
                
                var inp = {	location_id : drpdwn  , book_id : row_info.BOOK_ID ,  job_id : row_info.JOB_ID  };

                    $http.post( API_URL+"changePrdLocation" , inp ).then(function mySuccess(response) {
                        
                        $('#xmlContent1').html('');
                        showMessage('Message', response.data.errMsg , response.data.msg );               
                        
                    }, 
                    function myError(response) {
                             console.log(response);
                    });
                    
            }
             $('#xmlContent1').html('');
            
        });
        
    }
    
    $scope.contentloadtimer     =   1;
    
    $scope.getPmList            =       function(){     
        
        $scope.locationList     =   [];        
        $http.get( BASE_URL+"getProductionLocationsList" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.locations;                
            } , 
            function myError( response ){
                if($scope.contentloadtimer    <  10){
                    $scope.getPmList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                $scope.contentloadtimer++;      
        });
    }
	
	
    $scope.showSuccessredologviewdemo   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   'success',
                            clientid:    694 ,
                            jobID   :   6514 ,
                            roundID :   104
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    
});