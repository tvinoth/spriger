/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$q, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{	
	$scope.chapterdata      =   [];
        $('.chosen-select').chosen({}); 
        $scope.apsemailsetup    =   [];
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'Chapter Promotion';
        $scope.errorvalidationmsg   =   "";
        $scope.chapterpromotionTxt  =   true;
        $scope.addchapterpromotionBtn  =   true;
        $scope.submitchapterpromotionBtn  =   false;
        $scope.errordivShow  =   false;
        $scope.saveChapterbutton  =   false;
        $scope.contentloadtimer     =   1;
        $scope.workflowlist     =   [];      
        $scope.shownotavaiablechapter   =   [];
        $scope.processlist  =   [];
        
        $scope.roundchangedetails =   function() 
	{
            $("div[id^='viewsource_']").removeClass('val-error');
            var validation  =   true;
            var bookname    =   $("#viewsource_bookidselect").find('option:selected').val();
            var round    =   $("#viewsource_componentselect").find('option:selected').val();
            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (round  ==  '' || round   ==  undefined || round ==  ' ' || round.length ==  0)){
                $("div[id^='viewsource_']").not('#viewsource_stageSelect_chosen').addClass('val-error');
                $.notify("All fields are required", "error");
                $scope.chapterpromotionTxt  =   true;
                return false;
            }
            
            $scope.chapterpromotionTxt  =   false;
            $("div[id^='viewsource_']").not('#viewsource_stageSelect_chosen').removeClass('val-error');
            var inp                     =   {'jodId' :bookname,'bookId':$("#viewsource_bookidselect").find(":selected").data('bookid'),'roundId':round};
            var deferred                =   $q.defer();
            $http.post(BASE_URL+"viewSourceChapter",inp) .then(function mySuccess(response) 
            {
                if(response.data.result     ==  400)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                    
                $scope.chapterdata      =   response.data.chapterdata;
                deferred.resolve(response);
            }, 
            function myError(response) 
            {
                deferred.reject(response);
            });	
            return deferred.promise;
	};
        
        $scope.component1   =  function(){
           
            var component    =   $("#viewsource_componentselect").find('option:selected').val();
            if(component == '2'){
                $("#chapterRange").show();
                $("#componentTypes").hide();
            }else{
                $("#componentTypes").show();
                 $("#chapterRange").hide();
            }
            
        };
        
        $scope.inputValadation  =   function(value){
            var validation  =   false;
            if(value != undefined && value !=   ''){
                var fisrtchar   =   value.substring(0, 1);
                if(fisrtchar    ==  ',' || fisrtchar    ==  '-'){
                    $scope.chapter_promotion    =   '';
                }
                var totallength     =   value.length;
                // check comma string is found or not
                if(value.indexOf(',') !=    -1){
                    var splitstring     =   value.split(',');
                    var newemptyarray   =   [];
                    if(splitstring.length >= 1){
                        $.each(splitstring,function(ind,val){
                            if(val  ==  ''){
                                newemptyarray.push(val);
                            }
                            if(newemptyarray.length > 1){
                                $scope.chapter_promotion    =   value.substring(0,totallength-1);     
                            }
                        });
                    }
                }
                
                if(value.indexOf('--') !=    -1){
                    $scope.chapter_promotion    =   value.substring(0,totallength-1);    
                }
            }
        }
        
        $scope.chapterinputnumber   =   function(){
            $scope.inputValadation($scope.chapter_promotion);
        }
        
        $scope.workflowdetails =   function() 
	{
            $("div[id^='viewsource_']").removeClass('val-error');
            var validation  =   true;
            $scope.chapterdata  =   [];

            var bookname    =   $("#viewsource_bookidselect").find('option:selected').val();
            var stage    =   $("#viewsource_stageSelect").find('option:selected').val();
            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (stage  ==  '' || stage   ==  undefined || stage ==  ' ' || stage.length ==  0)){
                $scope.filterchapterdata  =   [];
                $("div[id^='viewsource_']").not('#viewsource_componentselect_chosen').addClass('val-error');
                $.notify("All fields are required", "error");
                $scope.chapterpromotionTxt  =   true;
                return false;
            }
            
            $scope.chapterpromotionTxt  =   false;
            $("div[id^='viewsource_']").not('#viewsource_componentselect_chosen').removeClass('val-error');
            var inp                     =   {'jodId' :bookname,'roundId':stage};
            var deferred                =   $q.defer();
            $http.post(BASE_URL+"jobWorkflowlist",inp) .then(function mySuccess(response) 
            {
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  200)
                {
                    $scope.workflowlist     =   response.data.workflowlist;
                    deferred.resolve(response);
                }
            }, 
            function myError(response) 
            {
                deferred.reject(response);
            });	
            return deferred.promise;
	};
        
        $scope.viewprocessData  =   [];
        $scope.workflowname     =   '';
        $scope.viewProcess =   function() 
	{
            var bookname    =   $("#viewsource_bookidselect").find('option:selected').val();
            var inp                     =   {'jodId' :bookname};
            var deferred                =   $q.defer();
            $http.post(BASE_URL+"viewProcessStage",inp) .then(function mySuccess(response) 
            {
                $("#viewsource_stageSelect option").prop('selected','');
                $("#viewsource_stageSelect").trigger("chosen:updated");
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                
                $('#viewsource_stageSelect').prop('disabled', true).trigger("chosen:updated");
                
                $scope.workflowlist     =   response.data.workflowname;
                $scope.workflow         =   response.data.workflowId;
                $scope.processlist      =   response.data.process;
                $("#viewsource_stageSelect option[value='"+response.data.stage+"']").prop('selected','selected');
                $("#viewsource_stageSelect").trigger("chosen:updated");
                $("#viewsource_workflowSelect").attr('disabled',true);
                        
                $scope.workflowtype     =   response.data.workflowtype;
                deferred.resolve(response);
                
                
            }, 
            function myError(response) 
            {
                deferred.reject(response);
            });	
            return deferred.promise;
	};
        
        $scope.btnContentchanges    =   function(){
            var bookname        =   $("#viewsource_bookidselect").find('option:selected').val();
            var chaptercomp     =   $("#viewsource_componentselect").find('option:selected').val();
            var chapter_promotion     =   $("#chapter_promotion").val();
            $("#hiddendata_bookid").val(bookname);
            $("#hiddendata_componentid").val(chaptercomp);
            $("#hiddendata_chapterid").val(chapter_promotion);
            $('#viewsource_bookidselect').prop('disabled', true).trigger("chosen:updated");
            $('#viewsource_componentselect').prop('disabled', true).trigger("chosen:updated");
            $("#chapter_promotion").attr('disabled',true);
        }
        
        $scope.redochanges     =   function(){
//            $('#viewsource_bookidselect').prop('disabled', false).trigger("chosen:updated");
//            $('#viewsource_componentselect').prop('disabled', false).trigger("chosen:updated");
//            $('#viewsource_stageSelect').prop('disabled', false).trigger("chosen:updated");
            $("#viewsource_stageSelect option").prop('selected','');
            $("#viewsource_stageSelect").trigger("chosen:updated");
            
            $("#viewsource_bookidselect option").prop('selected','');
            $("#viewsource_bookidselect").trigger("chosen:updated");
            
            $("#viewsource_componentselect option").prop('selected','');
            $("#viewsource_componentselect").trigger("chosen:updated");
            
            $("#viewsource_workflowSelect").attr('disabled',true);
            $("#chapter_promotion").removeAttr('disabled');
            
            $scope.processlist  =   [];
            $scope.workflowlist  =   [];
            $scope.chapter_promotion    =   "";
            $("#chapter_promotion").val('');
            $("#hiddendata_bookid").val('');
            $("#hiddendata_componentid").val('');
            $("#hiddendata_chapterid").val('');
            $("#hiddendata_workflowtypeid").val('');
            $("#viewsource_workflowSelect").val('');
            $("div[id^='viewsource_']").removeClass('val-error');
            $("#chapter_promotion").removeClass('val-error');
            $("#chapter_promotion").removeClass('val-error');
            $("#viewsource_workflowSelect").removeClass('val-error');
            $("#viewsource_processSelect").removeClass('val-error');
            $scope.addchapterpromotionBtn  =   true;
            $scope.submitchapterpromotionBtn  =   false;
            $("#hiddendata_workflowtypeid").val('');
            $scope.process  =   "";
            $scope.workflow =   "";
            
            $('input[name="chaptertitle[]"]').each(function(){$(this).val('');});
            $('input[name="Quantity[]"]').each(function(){$(this).val('');});
        }
        //fm,bm chapter validation
//        $scope.fmbminputValadation  =   function(value){
//            var validation  =   true;
//            if(value.indexOf(",") == -1 || value.indexOf("-") == -1 || value.indexOf("--") == -1){
//                validation  =   false;
//            }
//            return validation;
//        }
        
        $scope.addchapterfiles      =   function() 
        {   
            var validation  =   true;
            $('.required_field').removeClass('val-error');
            $("input[name='chapter_promotion']").removeClass('val-error');
            $("#chapter_promotion").removeClass('val-error');
            var bookname        =   $("#viewsource_bookidselect").find('option:selected').val();
            var chaptercomp     =   $("#viewsource_componentselect").find('option:selected').val();
            var stage           =   $("#viewsource_stageSelect").find('option:selected').val();
            var compType        =   $("#viewsource_componentTypes").find('option:selected').val();
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).find('option:selected').val();
                    var attrID   =   $(this).attr("id");
                    
                    console.log(attrID);
                    var attrClass   =   $(this).attr("class");
                    if(value    !=  undefined){
                        if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                        validation  =   false;
                        if(attrClass.indexOf('chosen-select') !=   '-1'){
                            $("div[id^='"+attrID+"']").addClass('val-error');
                        }else{
                            $(this).addClass('val-error');
                        }
                        }else{
                            $("div[id^='"+attrID+"']").removeClass('val-error');
                        }
                    }
            });
           console.log(chaptercomp);
            if(chaptercomp == 2){
            
            if($scope.chapter_promotion     ==  '' || $scope.chapter_promotion   ==  undefined || $scope.chapter_promotion ==  ' ' || $scope.chapter_promotion.length ==  0 || $scope.chapter_promotion.indexOf('?') !=   '-1'){
                $("input[name='chapter_promotion']").addClass('val-error');
                validation  =   false;
            }
        }else{
            
            $scope.chapter_promotion   = 1;
            validation  =   true;
        }
        
        console.log( validation );
//            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (chaptercomp  ==  '' || chaptercomp   ==  undefined || chaptercomp ==  ' ' || chaptercomp.length ==  0)){
//                $('.required_field').each(function(index,element){
////                    console.log($(this).getType()); 
//                        var inputvalue      =   $(this).val();
//                        var selectvalue     =   $(this).find('option:selected').val();
////                        value       =   value.trim();
////                        if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
//                        validation  =   false;
//                        $(this).addClass('val-error');
////                    }
//                });
//                $("div[id^='viewsource_']").addClass('val-error');
//                $.notify("All fields are required", "error");
//                return false;
//            }

//            if($("#viewsource_componentselect").find(":selected").data('codeid')    !=  "#CHAPTER" && $("#viewsource_componentselect").find(":selected").data('codeid')    !=  "#PART"){
//                if($scope.chapter_promotion  !=  '' && $scope.chapter_promotion   !=  undefined){
//                    var funcresult  =   $scope.fmbminputValadation($scope.chapter_promotion);
//                    if(funcresult   ==  false){
//                        showNotify('It will allow only one chapter, Kindly give it correctly!', 'danger' );
//                        $("input[name='chapter_promotion']").addClass('val-error');
//                        return false;
//                    }
//                }
//            }
            
            if(validation   ==  false){
                showNotify('All fields are required', 'danger' );
                return false;
            }
            
            $("div[id^='viewsource_']").removeClass('val-error');
            
//            showLoader('Please wait while checkout...');
            var inp             = 	{
                                jobId       :   bookname,
                                inputChapter :   $scope.chapter_promotion,
                                compenentCategory :   chaptercomp,
                                compenentType :   compType,
                                stage       :   stage,
                                workflow    :   $scope.workflow,
                                currentStage     :   $scope.process,
                                workflowtype    :   $scope.workflowtype
                        };  
                     
            $http.post(BASE_URL + 'addPromotionChapter', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                $scope.heightofmodal    =   450;
                if(response.data.result     ==  400)
                {
                    $("#show-edit").trigger('click');
                    $scope.errorvalidationmsg   =   response.data.validationerror;
                    if(response.data.existchapter.length >= 1){
//                        showNotify( response.data.errMsg  , 'danger' );
                        $scope.errordivShow     =   true;
                        $scope.saveChapterbutton  =   false;
                        $scope.shownotavaiablechapter  =   response.data.existchapter;
                        $scope.chapterlist      =   response.data.chapternames;
                        $("#hiddendata_workflowtypeid").val(response.data.workflowtype);
                    }
                }
                
                if(response.data.result     ==  200)
                {
                    $('input[name="chaptertitle[]"]').each(function(){$(this).val('');});
                    $('input[name="Quantity[]"]').each(function(){$(this).val('');});
                    $("#show-doopenfiles").trigger('click');
                    $scope.errorvalidationmsg   =   response.data.validationerror;
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
//                    showNotify( response.data.errMsg  , 'success' );
                    $scope.errordivShow     =   false;
                    $scope.checkfilestatusopenornot(attempt,filehandlerid);
                    $scope.saveChapterbutton  =   true;
                    $scope.chapterlist      =   response.data.chapternames;
                }
            }, 
            function myError(response) 
            {
                hideLoader();
            });
        };

        //open drive
        $scope.doChapterOpenDrive 	=       function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID)
        {
            showLoader('Please wait while Open Drive ...');
            var bookname        =   $("#viewsource_bookidselect").find('option:selected').val();
            var inp             = 	{
                                        jobId       :   bookname
                                    };   
            $http.post(BASE_URL + 'userOpenDrive', inp)
            .then(function mySuccess(response) 
            {
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  404)
                {
                    hideLoader();
                    showNotify( response.data.errMsg  , 'danger' );
                }
                
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
                    $scope.checkfilestatusopenornot(attempt,filehandlerid);
                }
            }, 
            function myError(response) 
            {
                hideLoader();
            });
        }
    
        $scope.savechapterdisabled  =   false;
        $scope.submitchapterfiles      =   function() 
        {        
            $('.required_field').removeClass('val-error');
            $("input[name='chapter_promotion']").removeClass('val-error');
            $("#chapter_promotion").removeClass('val-error');
            var bookname        =   $("#viewsource_bookidselect").find('option:selected').val();
            var chaptercomp     =   $("#viewsource_componentselect").find('option:selected').val();
            var stage           =   $("#viewsource_stageSelect").find('option:selected').val();
             var compType        =   $("#viewsource_componentTypes").find('option:selected').val();
//            console.log(stage); 
//            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (chaptercomp  ==  '' || chaptercomp   ==  undefined || chaptercomp ==  ' ' || chaptercomp.length ==  0) || ($scope.chapter_promotion  ==  '' || $scope.chapter_promotion  ==  undefined || $scope.chapter_promotion  ==  0)){
//                $("div[id^='viewsource_']").addClass('val-error');
//                if(($scope.chapter_promotion  ==  '' || $scope.chapter_promotion  ==  undefined || $scope.chapter_promotion  ==  0)){
//                    $("#chapter_promotion").addClass('val-error');
//                }else{
//                    $("#chapter_promotion").removeClass('val-error');
//                }
//                $.notify("All fields are required", "error");
//                return false;
//            }
            
             var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).find('option:selected').val();
                    var attrID   =   $(this).attr("id");
                    var attrClass   =   $(this).attr("class");
                    if(value    !=  undefined){
                        if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                        validation  =   false;
                        if(attrClass.indexOf('chosen-select') !=   '-1'){
                            $("div[id^='"+attrID+"']").addClass('val-error');
                        }else{
                            $(this).addClass('val-error');
                        }
                        }else{
                            $("div[id^='"+attrID+"']").removeClass('val-error');
                        }
                    }
            });
            if($scope.chapter_promotion != 1){
                if($scope.chapter_promotion     ==  '' || $scope.chapter_promotion   ==  undefined || $scope.chapter_promotion ==  ' ' || $scope.chapter_promotion.length ==  0 || $scope.chapter_promotion.indexOf('?') !=   '-1'){
                    $("input[name='chapter_promotion']").addClass('val-error');
                    validation  =   false;
                }
            }
            
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).val();
                    value       =   value.trim();
                    if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                    validation  =   false;
                    $(this).addClass('val-error');
                }
            });
            
            if(validation   ==  false){
                showNotify('All fields are required', 'danger' );
                return false;
            }
            $scope.savechapterdisabled  =   true;
            var chapternames    =   $('input[name="chaptername[]"]').map(function(){return $(this).val();}).get();
            var chaptertitle    =   $('input[name="chaptertitle[]"]').map(function(){return $(this).val();}).get();
            var Quantity        =   $('input[name="Quantity[]"]').map(function(){return $(this).val();}).get();
            if(chapternames.length  ==  0){
                showNotify( 'Input Chapter is empty'  , 'danger' );
                return false;
            }
            $("div[id^='viewsource_']").removeClass('val-error');
            
            showLoader('Please wait while checkout...');
            var inp             = 	{
                                jobId               :   bookname,
                                inputChapter        :   $scope.chapter_promotion,
                                compenentCategory   :   chaptercomp,
                                chapterName         :   chapternames,
                                chapterTitle        :   chaptertitle,
                                compType            :   compType,
                                stage       :   stage,
                                workflow    :   $scope.workflow,
                                currentStage     :   $scope.process,
                                msPages    :   Quantity,
                                workflowtype    :   $("#hiddendata_workflowtypeid").val(),
                                process    :   $scope.process
                        };  
            
            $("div[id^='viewsource_']").removeClass('val-error');

            $http.post(BASE_URL + 'submitPromotionChapter', inp)
            .then(function mySuccess(response) 
            {
                hideLoader();
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                    $scope.savechapterdisabled  =   false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    $scope.savechapterdisabled  =   false;
                    hideLoader();
                }

                if(response.data.result     ==  400)
                {
                    $scope.heightofmodal    =   400; 
                    $scope.savechapterdisabled  =   false;
                    $scope.errorvalidationmsg   =   response.data.validationerror;
//                    showNotify( response.data.errMsg  , 'danger' );
                    $scope.errordivShow     =   true;
                    $scope.shownotavaiablechapter  =   response.data.existchapter;
                }
                
                if(response.data.result     ==  200)
                {
                    $scope.redochanges();
                    showNotify( response.data.errMsg  , 'success' );
                    $("#show-doopenfiles").trigger('click');
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                $scope.savechapterdisabled  =   false;
            });
        };
        
        $scope.checkfilestatusopenornot     =   function(attempt,filehandlerid) 
        {           
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Opendrive'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(attempt,filehandlerid); }, 2000 );
                    } else {
                        hideLoader();
                        showNotify("File handler is not running. Please check..", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    hideLoader();
                    showNotify("File handler is not running. Please check....", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    hideLoader();
                    $scope.savechapterdisabled  =   false;
//                    $scope.btnContentchanges();
//                    $scope.addchapterpromotionBtn   =   false;
//                    $scope.submitchapterpromotionBtn   =   true;
                    showNotify( response.data.errMsg, 'success' );
                }
            }, 
            function myError(response) 
            {
                hideLoader();
            });
        };
});
    