/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$filter,$compile, $http,$timeout,$interval,$window,DTOptionsBuilder, DTColumnBuilder ,fileUploadService ) 
{
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'Job Revised';
	$scope.errorMsg 	=   "";
        $scope.showcurrenttab   =   1;
        
	$scope.revisedinfotab   =   function(number)
        {
            $scope.showcurrenttab   =   number;
        }
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
        $scope.contentloadtimer     =   1;
	$scope.getroundList         =   function() 
	{
            $scope.roundList        =   [];
            $http.get(BASE_URL+"jobround") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.roundList    =   response.data.prr;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getroundList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });			
            $scope.contentloadtimer++;
	};
        
        $scope.contentloadtimer     =   1;
        $scope.getbookList          =   function() 
	{
            $scope.bookList         =   [];
            $http.get(BASE_URL+"getjoblist") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.bookList    =   response.data.book;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getbookList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });	
            $scope.contentloadtimer++;
	};
        
        $scope.getBookChaperList   =   function(jobid) 
	{
            input = {jobId: jobid};
            $http.post(BASE_URL+"getBookChaperList",input) .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.chapterList    =   response.data.chapter;	
            }, 
            function myError(response) 
            {
                showNotify('Kindly reload page error occured.'  , 'danger' );
            });			
	};
        
	
        $scope.jobrevisedSend       =     function()
        {
            var exelFile            =   $scope.myFile;
            if( $scope.jobid        ==   undefined) 
            {
                $scope.showerror    =   true;
                $scope.adderrorMsg  =   'all fields are required';
                $scope.errorMsg     =   "red";
                return false;
            }
            if( $scope.roundid        ==   undefined) 
            {
                $scope.showerror    =   true;
                $scope.adderrorMsg  =   'all fields are required';
                return false;
            }
            if( exelFile ==     "" ||   exelFile == undefined ) 
            {
                $scope.showerror    =   true;
                $scope.adderrorMsg  =   'Kindly upload file';
                return false;
            } 
            else 
            {
                showLoader('Please wait while send Email...'); 
                $scope.showerror    =   false;
                $scope.fileupload   =   true;
                var uploadUrl       = 	BASE_URL+"addjobRevise";
		promise             = 	fileUploadService.uploadFileToUrl(exelFile,$scope.jobid,$scope.roundid, uploadUrl,$scope.chapterId);
		promise.then(function (response) 
                {
                    if(response.data.result     ==  401)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'error');
                                });
                            });
                        }
                        showNotify( response.data.errMsg  , 'danger' );
                    }
                    
                    if(response.data.result     ==  404)
                    {
                        showNotify( response.data.errMsg  , 'danger' );
                    }
                    
                    if(response.data.result  ==  200)
                    {
                        $scope.jobid    =   undefined;
                        $scope.roundid  =   undefined;
                        $scope.myFile   =   [];
                        location.reload();
                        $(".ace-file-name").attr('data-title','No File ...');
                        angular.element(document.getElementById("loading_status")).remove();
                        showNotify(response.data.errMsg  , 'success' );
                    }
                    hideLoader();
		}, function (errorresponse) 
                {
                    hideLoader();
                    if(errorresponse.data.errMsg)
                    {
                        showNotify(errorresponse.data.errMsg  , 'danger' );
                    }
                    $scope.fileupload   =   false;
                    showNotify("Internal server error try again...", 'Warning');
		});
                } 
            };     
            
        $scope.jobreviseditems          =   function(){
            $scope.vm                   =   {};
            $scope.vm.dtOptions         =   DTOptionsBuilder.newOptions().withOption('order', []);
            var input   		=   { id : '' };
            $scope.jobrevisedlist       =   [];        
            $http.get(  BASE_URL+"jobrevisedlist" , input ) .then(function mySuccess( response ){  
                $scope.jobrevisedlist   =   response.data.jobassigned;
            } ,
            function myError( response ){ 
                $scope.jobreviseditems();
            });
        } 
        
        var searchjobid         =   "";
        var searchroundid       =   "";
        var searchchapterid     =   "";
        var searchcategory      =   "alllist";
        $scope.chapterlist      =   [];
        
        $scope.searchrevised    =   function(typeofsearch)
        {
            if(typeofsearch     ==  'projects'){
                searchjobid     =   $("#projectSelect").find('option:selected').val();
//                $scope.binObj.chapter   =   "";
            }
            if(typeofsearch     ==  'round'){
//                if(searchjobid  ==  ''){
//                    $("#chapterselect").find('option:selected').remove();
//                    showNotify('Select Book ID'  , 'danger' );
//                    return false;
//                }
                searchroundid   =   $("#roundSelect").find('option:selected').val();
                if(searchroundid    >=  116 && searchroundid    <=  119){
                    $scope.chaptershow  =   true;
                }else{
                    $scope.chaptershow  =   false;
                }
            }
            if(typeofsearch     ==  'chapter'){
//                if(searchjobid  ==  ''){
//                    showNotify('Select Book ID'  , 'danger' );
//                    return false;
//                }
                searchcategory  =   "alllist";
                searchchapterid =   $("#chapterselect").find('option:selected').val();
                if(searchroundid    >=  116 && searchroundid    <=  119){
                    $scope.chaptershow  =   true;
                }else{
                    $scope.chaptershow  =   false;
                }
            }
//            if(searchchapterid  ==  '' && searchroundid     !=  ''){
//                searchcategory  =   "alllist";
//            }
//            if(searchchapterid  ==  '' && searchroundid     ==  '' && searchjobid   !=  ''){
//                searchcategory  =   "getchapterdetails";
//            }
            var input           =   { bookid : searchjobid,roundid : searchroundid, metadataid : searchchapterid ,searchcategory : searchcategory};
                $http.post( BASE_URL+"jobrevisedlist",input).then(function mySuccess(response) 
                {  
//                    if(searchcategory   ==  "getchapterdetails"){
//                        $scope.chapterlist  =   response.data.chapterlist;      
//                    }else
//                    {
                        $scope.chapterlist      =   response.data.chapterlist; 
                        $scope.jobrevisedlist   =   response.data.jobassigned;
//                    }
//                    if(searchchapterid  !=  ''){
//                        $scope.binObj.chapter   =   searchchapterid;
//                    }
                    },function myError(response) {
                });   
        }
        
        $scope.showXMLInModal   =   function( item,jobId , round ){  
            console.log(round);
            if(round >= 116 && round <= 119){
                var inp             = 	{
                                        jobId       :   item.JOB_ID,
                                        metadataid  :   item.METADATA_ID,
                                        Chapter     :   item.CHAPTER_NO,
                                        bookid      :   item.BOOK_ID,
                                        roundid     :   item.ROUND_ID
                                    };
                $scope.htmlcon      =   "Chapter XML Information";
                $('#show-edit').trigger('click');
                $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $http({
                        url         :   API_URL + "getChapterjobsheetview",
                        method      :   'POST',
                        data        :   inp
                     })
                .success(function(response) 
                {
                    if( response.result == 401 ){    
                        $scope.errorshow    =   true;
                        showNotify( response.errMsg , 'danger' );
                        $scope.shownotavaiablechapter   =   response.validation;
                        $('#xmlContent').html('');
                        return false;
                    }
                    if(response.xmlcount >= 1)
                    {
                        $('#xmlContent').html(response.errMsg);
                    }
                    else
                    {
                        $('#xmlContent').html('<p class="text-center">'+response.errMsg+'</p>');
                    }
                })
                .error(function(response) 
                {
                    hideLoader();
                    $('#xmlContent').html(response.errMsg);
                });
            }
            
            if((round >= 104 && round <= 114) || round == 120){
                $scope.errorshow    =   false;
                $scope.htmlcon      =   "Job XML Information";
                $('#show-edit').trigger('click');
                $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
                $http({
                        url: API_URL + "getJobXMLInfo/"+jobId+'/'+round,
                        method: 'GET',
                })
               .success(function(response) {
                   $('#xmlContent').html(response);
               })
               .error(function(response) {
                   console.log(response);
               });
            }
        }
        
        $scope.showSuccessredologview   =   function(typeoflog,item){
            var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.CLIACKID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) 
        {
            if(response.data.status == 1) {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            }else{
                showNotify(response.data.errMsg, 'danger' );
                }
            },function myError(response) {
                showNotify(response.data.errMsg,'danger' );
            });
        }
        
        $scope.showMeataextratorremarksview = 	function(params){   
            var printMsg    =   ( params.UPDATE_REMARKS == null ) ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
        
        $scope.showRedoview =   function(params){
            var printMsg    =   ( params.SR_REMARKS == null ) ? 'remarks not found..' : params.SR_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Client Acknowledgement";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        }
        
        $scope.retryJobsheetUpdate  = 	function(params){       
            showLoader();
            showNotify( 'please wait for a while...' , 'success');
            var jobid               =   params.JOB_ID;
            var dynamic_url         =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID;   
            $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {
                if(response.data.status == 1) {      
                    $timeout( function(){  
                    hideLoader();
					showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );
                     
                    $timeout( function(){  
                            $window.location.reload();
                        }, 2000 );
                    }, 5000 );
                } else {
                    showNotify( response.data.errMsg , 'danger');
                    hideLoader();
                }
            },function myError(response) {
                showNotify( 'Oops, Kindly reload the page...' , 'danger' );
            });
        };
    
        $scope.retryJobsheetUpload  =   function(params){    
            showLoader();
            showNotify( 'please wait for a while...' , 'success');
            var jobid               =   params.JOB_ID;           
            var dynamic_url         =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/RECEIPT';      
            $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
                hideLoader();
                if(response.data.status == 1) {                    
                    $timeout( function(){
                        if( response.data.msg == 'Success' ){                        
                            showNotify( response.data.errMsg , 'success' );
                        }
                        else{
                            showNotify( response.data.errMsg , 'danger' );
                        }
                        $timeout( function(){  
                            $window.location.reload();
                        }, 2000 );
                    }, 7000 );
                    } else {
                        showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
                    }
                },function myError(response) {
                    showNotify( 'Oops, Kindly reload the page...' , 'danger' );
            });
        };
        
        $scope.jobreviseditems();
        $scope.getroundList();
        $scope.getbookList();
});


    ngApp.directive('demoFileModel', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) 
            {
                var model 	= 	$parse(attrs.demoFileModel),
                modelSetter     = 	model.assign; //define a setter for demoFileModel
        
                //Bind change event on the element
                element.bind('change', function ($scope) 
				{
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                        //set the model value
                        modelSetter(scope, element[0].files[0]);
			$scope.bookmapUploadMsg 	=	'';
                        $(".ace-file-name").attr('data-title',element[0].files[0].name);
                    });
                });
            }
        };
    });
	
    ngApp.service('fileUploadService', function ($http, $q) 
    {
            this.uploadFileToUrl 	= 	function (file,jobId,Mailid, uploadUrl,chapterId) 
            {
            var fileFormData 	= 	new FormData();
            fileFormData.append('jobsheetfile', file);
			fileFormData.append('jobId', jobId);
			fileFormData.append('roundId', Mailid);
                        fileFormData.append('chapterId', chapterId);
                        
            var deffered 		= 	$q.defer();
            $http.post(uploadUrl, fileFormData, 
			{
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
 
            }).then(function mySuccess(response) 
			{
                deffered.resolve(response);
 
            },
			function myError(response) 
			{
				deffered.reject(response);
			});
            return deffered.promise;
        }
    });