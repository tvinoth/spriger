ngApp.controller('ngController', function ($scope,$filter,$compile, $http, $timeout , $interval,$window,DTOptionsBuilder, DTColumnBuilder  ) 
{
	$scope.userId 		=   0;	
	$scope.UserDetails 	=   {};
 	$scope.menuParent       =   'Customization';
        $scope.menuChild        =   'BG Setup';
	$scope.errorMsg 	=   "";
        $scope.noOfAttemptsToCheckIndesign  =   10;
        $scope.caption      =       '';
        
        $scope.bgsetup          =      {};
        $scope.metatag      =   {};
        
        $('.chosen-select').chosen({}); 
        
	/*
	 *  Get User Details
	 *  This method get the logged in user details from the session.
        */
        
        $scope.getStageRelatedXmlConfig     =       function( stageinfo ){
            
            console.log( stageinfo );
            
        };
      
        $scope.validateBgSetup     =   function( rootTag ){
         
            var inp     =   { xmlFormat : '<'+rootTag+'>'+$('#xmlFormat').val()+'</'+rootTag+'>'};
            
            $http.post( BASE_URL+"validateBgSetupXml" , inp ).then(function mySuccess(response){
                
                //$scope.bgsetup.xmlFormat    =   response.data;
                //$scope.saveXml();
                
                console.log( 'Xml is in correct format' );
                return true;
            },function myError( response ){
                showNotify( 'Invalid xml string [ xml validation got failed ]' , 'danger' );
                return false;
            });   
            
        };
      
        $scope.saveXml          =   function( bgsetup ){
            
            var xmlTags     =       $scope.bgsetup.xmlFormat;
            
            var inp     =   { 
                xmlFormat : xmlTags , 
                stageid :  $('#stageid').val() , 
                round  : $('#round').val()  ,
                wmid : $('#wmid').val() , 
                wfid : $('#wfid').val() ,
                type : $('#bgtype').val() ,
                chunkid : $('#chunkid').val() ,
                chunkname : $('#chunkname').val() 
            };
           
            $http.post( BASE_URL+"storeBgSetupXml" , inp ).then(function mySuccess(response){
                
                var alflag      =   ( response.data.status == 1 ) ? 'success' : 'danger';
                
                showNotify( response.data.errMsg , alflag );
                $('#xmlFormat').val('');
                $scope.loadMetaFormatStructure();
            });
            
        };
       
        $scope.loadMetaFormatStructure      =       function( ){
          
            var bgtype      =      '';
            var modetype    =      '';
            
            if( $('#bgtype').val().length ){
                bgtype  =   '/'+$('#bgtype').val();
            }
            
            if( $('#modetype').val().length ){
                modetype  =   '/'+$('#modetype').val();
            }
            
            var inp     =       $('#stageid').val()+'/'+$('#round').val()+'/'+$('#wmid').val()+'/'+$('#wfid').val()+bgtype+modetype;
            var elem_tag    =   '';
            console.log( inp );
            $http.post( BASE_URL+"getBgSetupStructure/"+inp ).then(function mySuccess(response){
                
                var length_     =       Object.keys(response.data.WorkflowMetadata).length;
                var metatags    =       response.data.WorkflowMetadata;
                $scope.metatag  =   metatags;
                var elem_tag     =      '<div class="dd" id="nestable">';
                    elem_tag    +=      '<ol class="dd-list">';
                    elem_tag    +=      '<li class="dd-item" data-id="WorkflowMetadata">';
                    elem_tag    +=	'<div class="dd-handle orange"> WorkflowMetadata </div>';
                    elem_tag    +=	'<ol class="dd-list" style="">';
               
                    Object.keys(metatags).forEach(function(key) {
                        var tagCollection   =  "'"+key+"'";
                        
                        elem_tag    += '<div class="dd-handle pointer" >';
                            elem_tag    += '<li class="dd-item" ng-click="showSubTags( '+metatags[key]['ID']+' , '+tagCollection+' )" data-id="'+metatags[key]['ID']+'">'+key+'</li>';
                        elem_tag    += '</div>';
                        
                    });

                        elem_tag    +=  '</ol>';
                        elem_tag    +=  '</li>';
                        
                    elem_tag    +=  '</ol>';
                    elem_tag    +=  '</div>';
                
                var compiledElm    =       $compile(elem_tag)($scope);
                $('.treeboard').html( compiledElm );
                    
                hideLoader();
                
            });
            
            hideLoader();
        };
        
        $scope.showSubTags  = function( id , tagCollection ){
            
            showLoader();
            var metatags    =   $scope.metatag;
            
            $('#chunkid').val( id ); 
            $('#chunkname').val( tagCollection ); 
            
            Object.keys(metatags).forEach(function(key) {
                
                if( parseInt(metatags[key]['ID']) == id ){
                    if( metatags[key]['TAG_TEXT'] !== '' ){
                        $scope.caption =   tagCollection;
                        $('#xmlFormat').val( metatags[key]['TAG_TEXT'] );
                        //$('#xmlFormat').val( '<'+tagCollection+'>'+metatags[key]['TAG_TEXT']+'</'+tagCollection+'>' );
                        $scope.validateBgSetup(tagCollection);
                    }else{
                        showNotify( 'Record not found!' , 'warning' );
                        $scope.caption =   tagCollection;
                        $('#xmlFormat').val( metatags[key]['TAG_TEXT'] );
                    }
                    hideLoader();
                }
                
            });
              
        };
        
        $scope.reset =function(){
            $('#xmlFormat').val( '' ); 
        }
        
        $scope.getNetedDesignOf     =   function (workflowMasterId) {
            
            var title           =   'View Workflow';
            $scope.wkInfo       =   '';
            $scope.workflow     =   [];
            $scope.stageInfo    =   [];
            var inp             =   {workflowMasterId: workflowMasterId};
            $http.post(API_URL + "getWorkflowAndStages", inp).then(function mySuccess(response) {
                console.log(response);
                $scope.workflow     =   response.data.workflow;
                $scope.stageInfo    =   response.data.stage;

                $scope.wkInfo += '<div class="dd" id="nestable"><ol class="dd-list">';
                for (var k = 0; k < $scope.workflow.length; k++) {
                    $scope.wkInfo += '<li class="dd-item no-drag" data-id="' + k + '"><div class="dd-handle orange">';
                    if ($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
                        $scope.wkInfo += "Main Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
                        $scope.wkInfo += "Parallel Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
                        $scope.wkInfo += "Art Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
                        $scope.wkInfo += "Art Correction Workflow - ";
                    }
                    $scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

                    if ($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
                        $scope.wkInfo += " (";
                        if ($scope.workflow[k]['START_STAGE'] != '') {
                            $scope.wkInfo += " Start Stage: " + $scope.workflow[k]['START_STAGE'];
                            $scope.wkInfo += " End Stage: " + $scope.workflow[k]['END_STAGE'];
                        } else {
                            $scope.wkInfo += " No Start and End stage is defined";
                        }
                        $scope.wkInfo += ") ";
                    }
                    $scope.wkInfo += '</div><ol class="dd-list">';
                    for (var i = 0; i < $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']].length; i++) {
                        $scope.wkInfo += '<div class="dd-handle"><li class="dd-item no-drag" data-id="' + i + '">';
                        $scope.wkInfo += $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_NAME'];

                        $scope.wkInfo += '</div></li>';
                    }
                    $scope.wkInfo += '</ol></li>';
                }
                $scope.wkInfo += '</ol></div>';
                showInfo(title, $scope.wkInfo);
               // $('.dd').nestable();
                  $('.nestable').nestable({handleClass:'123'});
            },
            
            function myError(response) {
                console.log(response);
            });
            
        };
	
        $(".animsition-overlay").animsition({
            inClass: 'overlay-slide-in-bottom',
            outClass: 'overlay-slide-out-top',
            inDuration: 1500,
            outDuration: 800,
            linkElement: '.animsition-link',
            // e.g. linkElement: 'a:not([target="_blank"]):not([href^="#"])'
            loading: false,
            loadingParentElement: 'body', //animsition wrapper element
            loadingClass: 'animsition-loading',
            loadingInner: '<i class="fa fa-spinner fa-spin spin-normal"></i>', // e.g '<img src="loading.svg" />'
            timeout: false,
            timeoutCountdown: 5000,
            onLoadEvent: true,
            browser: [ 'animation-duration', '-webkit-animation-duration'],
            // "browser" option allows you to disable the "animsition" in case the css property in the array is not supported by your browser.
            // The default setting is to disable the "animsition" in a browser that does not support "animation-duration".
            overlay : true,
            overlayClass : 'animsition-overlay-slide',
            overlayParentElement : 'body',
            transition: function(url){ window.location.href = url; }
        });
        
        
       
        $("#wkflwmstselect").chosen().change(function() {

            var wkflwMaster    =   $(this).val();
            showLoader();
            $scope.viewWorkflow( wkflwMaster );
            
        });
        
        $scope.viewWorkflow     =   function (workflowMasterId) {
            var title           =   'View Workflow';
            $scope.wkInfo       =   '';
            $scope.workflow     =   [];
            $scope.stageInfo    =   [];
            var inp             =   {workflowMasterId: workflowMasterId};
            
            $http.post(API_URL + "getWorkflowAndStagesForbgsetup", inp).then(function mySuccess(response) {
                
                $scope.workflow     =   response.data.workflow;
                $scope.stageInfo    =   response.data.stage;
                $scope.stagetypes    =   response.data.stagetypes;
                $scope.round        =   response.data.activeround;

                $scope.wkInfo += '<div class="dd" id="nestable">'
                       +'<ol class="dd-list">';
               
                for (var k = 0; k < $scope.workflow.length; k++) {
                    $scope.wkInfo += '<li class="dd-item no-drag" data-id="' + k + '">'
                            +'<div class="dd-handle orange">';
                    
                    if ($scope.workflow[k]['WORKFLOW_TYPE'] == 0) {
                        $scope.wkInfo += "Main Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 1) {
                        $scope.wkInfo += "Parallel Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 2) {
                        $scope.wkInfo += "Art Workflow - ";
                    } else if ($scope.workflow[k]['WORKFLOW_TYPE'] == 3) {
                        $scope.wkInfo += "Art Correction Workflow - ";
                    }
                    
                    $scope.wkInfo += $scope.workflow[k]['WORKFLOW_NAME']

                    if ($scope.workflow[k]['WORKFLOW_TYPE'] != 0) {
                        $scope.wkInfo += " (";
                        if ($scope.workflow[k]['START_STAGE'] != '') {
                            $scope.wkInfo += " Start Stage: " + $scope.workflow[k]['START_STAGE'];
                            $scope.wkInfo += " End Stage: " + $scope.workflow[k]['END_STAGE'];
                        } else {
                            $scope.wkInfo += " No Start and End stage is defined";
                        }
                        $scope.wkInfo += ") ";
                    }
                    
                    $scope.wkInfo += '</div><ol class="dd-list">';
                    for (var i = 0; i < $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']].length; i++) {
                        
                        if( $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['IS_AUTO'] ){                            
                            
                            var stageid     =   $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_ID'];
                            var linkurl     =   'bgconfig/'+stageid+'/'+$scope.round+'/'+$scope.workflow[k]['WORKFLOW_MASTER_ID']+'/'+$scope.workflow[k]['WORKFLOW_ID']+'/';
                            var printurl    =   "'"+linkurl+"'";
                                
                            $scope.wkInfo += '<li class="dd-item no-drag"> '
                                    +'<div class="dd-handle yellow" data-id="' + i + '">';
                            $scope.wkInfo += $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_NAME'];
                             if( $scope.stagetypes[stageid] == undefined ){                                
                                $scope.wkInfo += '<div class="pull-right action-buttons">'
                                    +'<a class="blue" href="'+linkurl+'" ng-click="procedtosetup('+printurl+')">'
                                      +'<i class="ace-icon fa fa-gear bigger-130"></i>'
                                    +'</a>'
                                +'</div>';
                            }
                             $scope.wkInfo += '</div>';
                    
                            if( $scope.stagetypes[stageid] !== undefined ){
                                
                                $scope.wkInfo += '<ol class="dd-list">';
                                    for (var ii = 0; ii < $scope.stagetypes[stageid].length; ii++) {
                                        printurl =  "'"+linkurl+$scope.stagetypes[stageid][ii]+"'";
                                        $scope.wkInfo +='<li class="dd-item no-drag" ng-click="procedtosetup('+printurl+')"><div class="dd-handle">'
                                                +$scope.stagetypes[stageid][ii]
                                                +'<div class="pull-right action-buttons">'
                                                    +'<a class="blue" href="'+linkurl+$scope.stagetypes[stageid][ii]+'">'
                                                        +'<i class="ace-icon fa fa-gear bigger-130"></i>'
                                                    +'</a>'
                                                +'</div></li>';
                                    }
                                $scope.wkInfo +='</ol>';   
                            }
                            $scope.wkInfo += '</li>';
                    
                        }else{
                        
                            //$scope.wkInfo += '<li class="dd-item"><div class="dd-handle" data-id="' + i + '">';
                            //$scope.wkInfo += $scope.stageInfo[$scope.workflow[k]['WORKFLOW_ID']][i]['STAGE_NAME'];
                            //$scope.wkInfo += '</div></li>';
                    
                        }
                        
                    }
                    
                    $scope.wkInfo += '</ol></li>';
                }
                $scope.wkInfo += '</ol></div>';
                //showInfo(title, $scope.wkInfo);
                hideLoader();
                $(".treeboard").html( $scope.wkInfo );
                 $('.nestable').nestable({handleClass:'123'});
              
              
            },
            
            function myError(response) {
                hideLoader();
                console.log(response);
            });
        };
	
        $scope.procedtosetup    =   function( url ){
            console.log( url );
            //window.location.href = url;
        }
        
        /*
            $('.dd a').on('mousedown', function (event) { event.preventDefault(); console.log('sdfdsfdsf'); return false; });

            $('.dd-list,.dd-item').on('click' , function(){
                alert('dsfsdfs');
            });
    
        */
        
    });