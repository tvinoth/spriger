
ngApp.controller('ngController', function($scope, $http, $filter, $timeout, $interval, DTOptionsBuilder, DTColumnBuilder)
{
    $scope.userId = 0;
    $scope.jobId = "";
    if (isNaN(getUrlParameter(1)))
    {
        $scope.jobId = "";
    }
    else
    {
        $scope.jobId = getUrlParameter(1);
    }
    $scope.projectList = [];
    $scope.showProject = false;
    $scope.checkItemsList = [];
    $scope.checkItemsParentList = [];
    $scope.checkItemsTypeList = [];
    $scope.addCheckItemFrm = {};
    $scope.adderrorMsg = '';
    $scope.checkItemTitle = '';
    $scope.addCheckItem = {};
    // $scope.addCheckItemFrm.checkItemIsParent = 1;
    $scope.menuParent = 'Check Items';
    $scope.menuChild = 'Check Items';

    $scope.getCheckItemsList = function()
    {
        var input = {jobId: $scope.jobId};
        $http.post(API_URL + "getCheckItemsList", input)
                .then(
                        function mySuccess(response)
                        {
                            $scope.checkItemsList = response.data;
                        },
                        function myError(errresponse)
                        {
                            //showMessage('Message', errresponse.data.msg, 'warning' );
                        }
                );
    }

    $scope.getCheckItemsParentList = function()
    {
        var input = {jobId: $scope.jobId};
        $http.post(API_URL + "getCheckItemsParentList", input)
                .then(
                        function mySuccess(response)
                        {
                            $scope.checkItemsParentList = response.data;
                        },
                        function myError(response)
                        {
                            console.log(response);
                        }
                );
    }

    $scope.getCheckItemsTypeList = function() {
        $http.get(API_URL + "getCheckItemsTypeList")
                .then(
                        function mySuccess(response) {
                            $scope.checkItemsTypeList = response.data;
                        },
                        function myError(response) {
                            console.log(response);
                        }
                );
    }

    $scope.getCheckItemsList();
    $scope.getCheckItemsParentList();
    $scope.getCheckItemsTypeList();

    $scope.openAddCheckItem = function()
    {
        $scope.addCheckItem = {};
        $scope.adderrorMsg = '';
        $scope.getCheckItemsParentList();
        $("#show-add-check-item").click();
    }

    $scope.checkItemAddSubmit = function()
    {
        if ($scope.addCheckItemFrm.$valid)
        {
            $scope.adderrorMsg = '';
            var input = {
                jobId: $scope.jobId,
                checkItemTitle: $scope.addCheckItem.checkItemTitle,
                checkItemIsParent: $scope.addCheckItem.checkItemIsParent,
                checkItemParentId: $scope.addCheckItem.checkItemParentId,
                checkItemquickinfo: $scope.addCheckItem.checkItemquickinfo,
                checkItemType: $scope.addCheckItem.checkItemType
            };

            $http({
                method: 'POST',
                url: API_URL + 'addCheckItem',
                data: input
            }).success(function(response) {
                $('#addCheckItem-close').click();

                var data = angular.fromJson(response);
                showMessage('Message', data.errMsg, data.msg);
                $scope.getCheckItemsList();

                if (data.status) {
                    $scope.addCheckItemFrm.checkItemTitle = '';
                    $scope.addCheckItemFrm.checkItemIsParent = '';
                    $scope.addCheckItemFrm.checkItemParentId = '';
                    $scope.addCheckItemFrm.checkItemType = '';
                }

            });

        } else {
            $scope.adderrorMsg = 'Please fill in required fields';
        }

    };

    $scope.checkItemEdit = function(checkItem)
    {
        $scope.editCheckItem = {};
        $scope.editCheckItem.checkItemId = checkItem.ID;
        $scope.editCheckItem.checkItemTitle = checkItem.TITLE;
        $scope.editCheckItem.checkItemIsParent = checkItem.IS_PARENT;
        $scope.editCheckItem.checkItemParentId = checkItem.PARENT_ID.toString();
        $scope.editCheckItem.checkItemType = checkItem.TYPE_ID.toString();
        $("#show-edit-check-item").click();
    }

    $scope.checkItemEditSubmit = function()
    {
        if ($scope.editCheckItemFrm.$valid)
        {
            $scope.adderrorMsg = '';
            var input = {
                jobId: $scope.jobId,
                checkItemId: $scope.editCheckItem.checkItemId,
                checkItemTitle: $scope.editCheckItem.checkItemTitle,
                checkItemIsParent: $scope.editCheckItem.checkItemIsParent,
                checkItemParentId: $scope.editCheckItem.checkItemParentId,
                checkItemquickinfo: $scope.editCheckItem.checkItemquickinfo,
                checkItemType: $scope.editCheckItem.checkItemType
            };

            $http({
                method: 'POST',
                url: API_URL + 'editCheckItem',
                data: input
            }).success(function(response) {
                $('#editCheckItem-close').click();

                var data = angular.fromJson(response);
                showMessage('Message', data.errMsg, data.msg);
                $scope.getCheckItemsList();

                if (data.status) {
                    $scope.editCheckItemFrm.checkItemTitle = '';
                    $scope.editCheckItemFrm.checkItemIsParent = '';
                    $scope.editCheckItemFrm.checkItemParentId = '';
                    $scope.editCheckItemFrm.checkItemType = '';
                }

            });

        } else {
            $scope.adderrorMsg = 'Please fill in required fields';
        }

    }

    $scope.deleteCheckItem = function(checkItemId)
    {
        bootbox.confirm("Are you sure you want to delete?", function(result)
        {
            if (result)
            {
                var inp = {ID: checkItemId};
                $http.post(API_URL + 'deleteCheckItem', inp)
                        .then(function mySuccess(response)
                        {
                            showMessage('Message', 'Check Item successfully deleted.', 'success');
                            $scope.getCheckItemsList();
                        },
                                function myError(response)
                                {
                                    showMessage('Message', response.data.msg, 'warning');
                                });
            }
        });
    }

    function setCookie(problemcheck, quickinfocheck, checkjob, exdays)
    {
        var d = new Date();
        d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
        var expires = d.toUTCString();
        document.cookie = "springer_" + $scope.jobId + "=" + JSON.stringify({'problemcheck': problemcheck, 'checkjob': checkjob, 'quickinfocheck': quickinfocheck, 'expires': expires});
    }
    function getCookie(cname)
    {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i].trim();
            if (c.indexOf(name) == 0)
                return c.substring(name.length, c.length);
        }
        return "";
    }

    var json = getCookie('springer_' + $scope.jobId);
    if (json.length == 0)
    {
        $scope.othersprojCheckItemProblem = "";
        $scope.othersprojCheckItemQuickInfo = "";
    }
    else
    {
        var data = JSON.parse(json);
        if ($scope.jobId == data.checkjob)
        {
            $scope.othersprojCheckItemProblem = data.problemcheck;
            $scope.othersprojCheckItemQuickInfo = data.quickinfocheck;
        }
    }

    $scope.checkProjectItemEdit = function(checkid, okdata, problemtext, quickinfo)
    {
        $scope.adderrorMsg = '';
        var projectproblem = 'projectcheck_Problem_' + checkid.toString();
        var projectquickinfo = 'projectcheck_Quick_' + checkid.toString();
        var problemid = document.getElementById(projectproblem);
        var quickinfoid = document.getElementById(projectquickinfo);
        if (checkid == "Others")
        {
            setCookie($scope.othersprojCheckItemProblem, $scope.othersprojCheckItemQuickInfo, $scope.jobId, 60);
            showMessage('Message', 'Project Check Items Updated Successfully.', 'success');
            return false;
        }
        var input = {
            jobId: $scope.jobId,
            checkItemId: checkid,
            checkOkdata: okdata,
            checkProblem: problemid.value,
            checkQuick: quickinfoid.value
        };
        $http({
            method: 'POST',
            url: API_URL + 'editProjectCheckItem',
            data: input
        }).success(function(response)
        {
            var data = angular.fromJson(response);
            showMessage('Message', data.errMsg, data.msg);
            //$scope.getCheckItemsList();
        });
    }
    $scope.checkProjectItemDelete = function(itemid)
    {
        bootbox.confirm("Are you sure you want to delete?", function(result)
        {
            if (result)
            {
                var projectproblem = 'projectcheck_Problem_' + itemid.toString();
                var projectquickinfo = 'projectcheck_Quick_' + itemid.toString();
                $scope.adderrorMsg = '';
                //console.log($scope.projectcheck_Problem_+projectcheckitem);
                var problemid = document.getElementById(projectproblem);
                var quickinfoid = document.getElementById(projectquickinfo);
                var input = {checkItemId: itemid};
                $http.post(API_URL + 'deleteProjectCheckItem', input)
                        .then(function mySuccess(response)
                        {
                            showMessage('Message', response.data.errMsg, response.data.msg);
                            problemid.value = '';
                            quickinfoid.value = '';
                        },
                                function myError(response)
                                {
                                    showMessage('Message', response.data.errMsg, 'warning');
                                });
            }
        });
    };

    $scope.projCheckItemAddSubmit = function() {
        $('form[name="addCheckItemFrm"]').submit();
        return;

    }

});

ngApp.filter('startsWithA', function() {
    return function(items) {
        var filtered = [];
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            if (/a/i.test(item.substring(0, 1))) {
                filtered.push(item);
            }
        }
        return filtered;
    };
});


