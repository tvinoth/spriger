/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */


ngApp.controller('ngController', function ($scope, $http) {
    
	$scope.userId = 0;
	$scope.projectList = [];
	$scope.showProject = false;
	
	$scope.menuParent = 'ProjectList';
	$scope.menuChild  = 'ProjectList';
	
        /*
	 *  This method navigate the user to the setup page
	 *  User click project from the project list, this method will invoke.
	 */
        
	$scope.gotoProjetSetup = function(jobID){
		window.location.href=BASE_URL+"pre-production/tps-setup/"+jobID;
	};
	
        /*
	 *  Show Project List
	 *  This method pass the user id, team id of the logged in user and get the list of projects for this user.
	 */
        
	$scope.showProjectList = function() {
		$scope.projectList = [];
		var inp = {	user_id : '', team_id : ''};
		console.log(inp);	
		$http.post(API_URL+"getProjectList", inp) .then(function mySuccess(response) {
			console.log(response.data.data);	
			$scope.projectList = response.data.data;
			
			$scope.vm = {};
			$scope.vm.dtOptions = {};
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        $scope.showProjectList();
    
});


ngApp.controller('contactDetails', function ( $scope , $http, $filter,$timeout,$interval,DTOptionsBuilder, DTColumnBuilder) {
    
    $scope.contactAddSubmit = function() {    
    
        var input = {
            contact_name    :   $scope.contact_name ,
            contact_email   :   $scope.contact_email ,
            location_id     :   $scope.location_id
        };
        
        console.log("posting data....");
        console.log( input );
        
        var request     =   $http({
                                    method  :   "post",
                                    url     :   "insertContact",                                   
                                    data    :   input 
                                 });
                                 
        request.success( function( response ) {
            
            var data        =       angular.fromJson( response );
            showMessage('Message', data.errMsg , data.msg );
            //showInfo(data.msg , data.errMsg);
            $scope.getContactList();
            if( data.status ){
               $scope.contact_name  =   '';   
               $scope.contact_email =   '';
               $scope.location_name =   '';
            }
        });
    };
      
    $scope.getContactList = function( input_str ){
        
        var input   =   { id : '' };
        
        $scope.contactList  =   null;
        
        $http.get(  BASE_URL+"getContactDetails" , input ) .then(
                
             function mySuccess( response ){  
                 console.log( response.data );
                 $scope.contactList   =   response.data.contacts; 
                 console.log($scope.contactList);
             } ,              
             function myError( response ){ 
             
             }
                  
        );
        
    }
    
    $scope.showDataOnDT     =      function(){
    
        //$dataOf     =       $scope.contactList;
        
    }
    
    $scope.getAllLocations     =       function(){
        
        $scope.locationList     =   null;        
        $http.get( BASE_URL+"getLocations" ).then( 
            function mySuccess( response ){
                $scope.locationList     =       response.data.location;
            } , 
            function myError( response ){     
            
        });
        
    }
        
    $scope.contactEdit  =   function( obj ){
        
        $scope.update          =        {};
        $scope.update.contactId    =   obj.ID;
        $scope.update.contactName  =   obj.CONTACT_NAME;
	$scope.update.contactEmail =   obj.CONTACT_EMAIL;
	$scope.update.locationId   =   obj.LOCATION_ID.toString();
        //$scope.update.contactStatus   =   obj.STATUS;
        
        console.log( $scope.update );
        
        $("#show-edit").click();
        
    }
    
    /*
    *  update contact Infomation
    *  This method update the given value as a Contact information.
    */
   
    $scope.updateContact        =       function(){
        
        console.log( ' contact update information   : '+$scope.update );
        var inp         =       $scope.update;
        $http.post( BASE_URL+"updateContact", inp ) .then(function mySuccess(response) {
            
            var res = response.data;	
            $scope.update          =        {};
            $scope.getContactList();
            console.log( 'contact update print Log : '+response.data );
            showMessage('Contact', 'Contact Information Updated Successfully.', 'success' );
            $("#edit-close").click();	
        }, 
        function myError(response) {
                    
        });
        
    }
    
    /*
    *  Delete contact Infomation
    *  This method deletes the given Contact information.
    */
   
    $scope.deleteContact = function(contactId) {
       
        bootbox.confirm("Are you sure you want to delete?", function(result) {
            if(result) {
                
		var inp = {
                            ID: contactId
            		  };
                          
		$http.post( BASE_URL+"deleteContact", inp ) .then(function mySuccess(response) {
                    var res = response.data;	
                    
                    console.log( 'Print Log : '+response.data );
                    showMessage('Contact', 'Contact Information successfully deleted.', 'success' );
                    $scope.getContactList();
                    
		}, 
                
                function myError(response) {
                    
		});
                
            }
	});	
    };    
    
    $scope.getAllLocations();
   
    $scope.getContactList();
    
    $scope.contactImport        =   function(){        
        var exelFile    =   $scope.uploadedFile;
        
		if( exelFile == "" ) {
                    $scope.progress_upload = 'Please select a file to upload.';
		} else {
			var fileName = exelFile.name;
			var extn = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
			
			if (extn == "xls" || extn == "xlsx"  ) {	
				$http.post( BASE_URL+"contactImport" , exelFile ).then(function mySuccess(response) {
					$scope.importContactInfoToDB(response.data.fileName);	
				}, 
				function myError(response) {
					 console.log(response);
				});	
			} else {
				$scope.progress_upload = 'Please upload only excel file.';
			}
		}
    }
    
    $scope.openUpload   =   function(){
        $("#exel_upload").click();
        $scope.progress_upload = "";
    } 
    
    $scope.importContactInfoToDB    =   function( fileName ){
        console.log( 'file name upload as :' + fileName );
       
        var inp = {
                    userId      :   ''  , 
                    fileName    :   fileName
                  };
			
	$http.post( BASE_URL+"importContactInfoToDB", inp ) .then(function mySuccess(response) {
        
            console.log(response);
            return false;
            
            if(response.data.rowCnt > 0)	{
		$scope.bookmapUploadMsg = response.data.errMsg;
            } else {
                showMessage('Message', response.data.errMsg, 'success');
                $scope.bookmapUploadMsg = "";
                angular.element("input[type='file']").val(null);
                $scope.myFile = "";
                $("#bookmapimport-close").click();	
                $scope.getBookmapDetails();				
            }
	}, 
	function myError(response) {
            console.log(response);
	});
        
    }
    
});