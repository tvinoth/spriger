/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout,$location, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    $scope.userId 	=   '0';	
    $scope.menuParent 	=   'Pre-Production';
    $scope.menuChild 	=   'Email Remainder Setup';
    $scope.errorMsg 	=   "";
    $scope.Type 	=   "";
    if(isNaN(getUrlParameter(2))){
        $scope.JobID 	=   "";
    }else{
        $scope.JobID 	=   getUrlParameter(2);
    }
    if(isNaN(getUrlParameter(1))){
        $scope.Type 	=   getUrlParameter(1);
    }
        
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
    $scope.currentuserid    =   '';
    
    $scope.openchapterlistdetails   =   function(jobid,prooftype)
    {
        $window.location.href       = 	BASE_URL+"remainderchapterlist/"+jobid+'/'+prooftype;
    }
    
    
    
    $scope.remainderlisundo     =   [];
    $scope.getemailchapterlevelList = 	function() 
    {
        $scope.CucList      = 	[];
        var inp             =   {
                                    jodId           :   $scope.JobID,
                                    remaindertype   :   $scope.Type
                                }
        $http.post(BASE_URL+"emailremainderchapterlist",inp) .then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
            }
            $scope.emailremainderlist   =   {'remainderlist':response.data.emailremainderlist,'selected':{}};
            setTimeout(function() {
            angular.forEach($scope.emailremainderlist.remainderlist, function (value, key) {
               
		$(".startdatepicker_"+key).datepicker({
                    autoclose: true,
                    format: 'yyyy-mm-dd',
                    todayHighlight: true
                });

              });
			  
              $scope.$digest();
              }, 7000);
            
            $scope.vm              =   {};
            $scope.vm.dtOptions    =   DTOptionsBuilder.newOptions().withOption('order', []);
        }, 
        function myError(response) {
            showNotify( 'Kindly reload page error occured.'  , 'danger' );
        });			
    };
    
    if($scope.JobID !=  '')
    {
        $scope.getemailchapterlevelList();
    }
    
    $scope.getTemplate = function (contact) {
        if (contact.ID ===  $scope.emailremainderlist.selected.ID) return 'edit';
        else return 'display';
    };

    $scope.editContact = function (contact) {
        $scope.emailremainderlist.selected = angular.copy(contact);
    };

    $scope.saveContact = function (idx) {
        $scope.emailremainderlist.remainderlist[idx] = angular.copy($scope.emailremainderlist.selected);
        $scope.reset();
    };

    $scope.reset = function () {
        $scope.emailremainderlist.selected = {};
    };
    
    $scope.doEditcorrection   =   function(metataid,roundid,apsid,typeofproof,index)
    {
        $(".remainder_date").datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            todayHighlight: true
        });
        
        if(typeofproof  ==  1)
        {
            $scope.validationdateformateproof(index);
        }
        if(typeofproof  ==  2)
        {
            $scope.validationdateformataps(index);
        }
        
        $scope.removeattrmethod(index);
        $("#enablededitbtn_"+index).text('');
        var updatebutton    =   '<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="updatecorrectiontage('+metataid+','+roundid+','+apsid+','+typeofproof+','+index+')">Update</button> &nbsp;&nbsp;<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="undoCorrection('+metataid+','+roundid+','+apsid+','+typeofproof+','+index+')">Undo</button>';
        var emailuptebutton =   $compile(updatebutton)($scope);
        angular.element(document.getElementById("enablededitbtn_"+index)).append(emailuptebutton);
        $scope.emailremainderlist.selected  =   angular.copy($scope.emailremainderlist.remainderlist[index]);
        $scope.remainderlisundo.push($scope.emailremainderlist.remainderlist[index]);
    }
    
    $scope.validationdateformateproof   =   function(index)
    {
        var settodatdate    =   new Date();
        var corrtstartdate  =   settodatdate.setDate(settodatdate.getDate()); // settodatdate.setDate(settodatdate.getDate()+3);
        var setdefaultdate  =   new Date();
        var setdefaultstartdate     =   setdefaultdate.setDate(setdefaultdate.getDate()); // setdefaultdate.setDate(setdefaultdate.getDate()+1)
        $('#correctionDate_'+index).datepicker('setStartDate',new Date(corrtstartdate.valueOf()));
        $('#firstDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $('#secondDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $('#thirdDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $("#correctionDate_"+index).datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                todayHighlight: true
        }).on('changeDate', function (selected) {
            var setstartdate    =   new Date(selected.date.valueOf());
            var setseconddate   =   new Date();
            var firstdate       =   setseconddate.setDate(setseconddate.getDate());
            var seconddate      =   setseconddate.setDate(setseconddate.getDate()); //setseconddate.setDate(setseconddate.getDate()+1)
            //first remainder
            var setsecnddate    =   new Date(selected.date.valueOf());
            var secondremdate   =   setsecnddate.setDate(setsecnddate.getDate()+3);
            $('#firstDate_'+index).datepicker('setStartDate',new Date(selected.date.valueOf()));
            $('#firstDate_'+index).datepicker('setDate',new Date(selected.date.valueOf()));
            //second remainder
            $('#secondDate_'+index).datepicker('setStartDate',new Date(seconddate.valueOf()));
            $('#secondDate_'+index).datepicker('setDate',new Date(secondremdate.valueOf()));
            //third remainder
            var setthirddate    =   new Date(selected.date.valueOf());
            var thirddate       =   setthirddate.setDate(setthirddate.getDate()+5);
            $('#thirdDate_'+index).datepicker('setStartDate',new Date(seconddate.valueOf()));
            $('#thirdDate_'+index).datepicker('setDate',new Date(thirddate.valueOf()));
        });
    }
    
    $scope.validationdateformataps   =   function(index)
    {
        var settodatdate    =   new Date();
        var corrtstartdate  =   settodatdate.setDate(settodatdate.getDate()); // settodatdate.setDate(settodatdate.getDate()+1)
        var setdefaultdate  =   new Date();
        var setdefaultstartdate     =   setdefaultdate.setDate(setdefaultdate.getDate());
        $('#correctionDate_'+index).datepicker('setStartDate',new Date(corrtstartdate.valueOf()));
        $('#firstDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $('#secondDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $('#thirdDate_'+index).datepicker('setStartDate',new Date(setdefaultstartdate.valueOf()));
        $("#correctionDate_"+index).datepicker({
                autoclose: true,
                format: 'yyyy-mm-dd',
                todayHighlight: true
        }).on('changeDate', function (selected) {
            var setstartdate    =   new Date(selected.date.valueOf());
            var setseconddate   =   new Date();
            var seconddate      =   setseconddate.setDate(setseconddate.getDate());
            //first remainder
            var setsecnddate    =   new Date(selected.date.valueOf());
            var secondremdate   =   setsecnddate.setDate(setsecnddate.getDate()+3);
            $('#firstDate_'+index).datepicker('setStartDate',new Date(selected.date.valueOf()));
            $('#firstDate_'+index).datepicker('setDate',new Date(selected.date.valueOf()));
            //second remainder
            $('#secondDate_'+index).datepicker('setStartDate',new Date(seconddate.valueOf()));
            $('#secondDate_'+index).datepicker('setDate',new Date(secondremdate.valueOf()));
            //third remainder
            var setthirddate    =   new Date(selected.date.valueOf());
            var thirddate       =   setthirddate.setDate(setthirddate.getDate()+5);
            $('#thirdDate_'+index).datepicker('setStartDate',new Date(seconddate.valueOf()));
            $('#thirdDate_'+index).datepicker('setDate',new Date(thirddate.valueOf()));
        });
    }
    
    $scope.updatecorrectiontage =   function(metataid,roundid,apsid,typeofproof,index) 
    {
        if(($("#firstDate_"+index).prop('disabled')  !=  true && $("#firstDate_"+index).val()    ==  '') || ($("#secondDate_"+index).prop('disabled')  !=  true && $("#secondDate_"+index).val()    ==  '') || ($("#thirdDate_"+index).prop('disabled')  !=  true && $("#thirdDate_"+index).val()    ==  '') || ($("#correctionDate_"+index).prop('disabled')  !=  true && $("#correctionDate_"+index).val()    ==  ''))
        {
            showNotify('All fields are required', 'danger' );
            return false;
        }
//        var myDate  =   new Date($("#correctionDate_"+index).val());
//        var today   =   new Date();
//        if ( today > myDate ) { 
//            showNotify('Correction due date should be greater than today date', 'danger' );
//            return false;
//        }
        
        var inp                 =   {   
                                        metadataid  :  metataid,// item.METADATA_ID,
                                        roundid     :   roundid,//item.ROUND_ID
                                        apsid       :   apsid,//item.APSID
                                        typeofproof :   typeofproof,
                                        correction_duedate          :   $("#correctionDate_"+index).val(),
                                        first_correction_duedate    :   $("#firstDate_"+index).val(),
                                        second_correction_duedate   :   $("#secondDate_"+index).val(),
                                        third_correction_duedate    :   $("#thirdDate_"+index).val()
                                    };
        showLoader('Please wait while updating records...');
        $http.post(BASE_URL+'updateCorrectionRemainder',inp).then(function mySuccess(response) {
            hideLoader();
            if(response.data.result     ==  401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation,function(key,val)
                    {
                        $.each(val,function(key,errval)
                        {
                            $.notify(errval,'error');
                        });
                    });
                }
                showNotify( response.data.errMsg  , 'danger' );
                hideLoader();
            }
            
            if(response.data.status == 1) 
            {   
                $scope.addattrmethod(index);
                var mailtempthrevert    =   '<button ng-click="doEditcorrection('+response.data.remainderitem.METADATA_ID+','+response.data.remainderitem.ROUND+','+response.data.remainderitem.ID+','+typeofproof+','+index+')" class="btn btn-primary btn-xs pointer">Edit</button>';
                var trcontent           =   $compile(mailtempthrevert)($scope);
                $("#enablededitbtn_"+index).text('');
                angular.element(document.getElementById("enablededitbtn_"+index)).append(trcontent);
                showNotify(response.data.errMsg, 'success' );
            } 
            else
            {
                $scope.removeattrmethod(index);
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            hideLoader();
            $scope.removeattrmethod(index);
            showNotify(response.data.errMsg,'danger' );
        });
//        $scope.emailremainderlist.remainderlist[idx]    =   angular.copy($scope.emailremainderlist.selected);
//        console.log($scope.emailremainderlist.selected);
    }
    
    $scope.undoCorrection   =   function(metataid,roundid,apsid,typeofproof,index) 
    {
        $(".remainder_date").datepicker({
            autoclose: true,
            format: 'yyyy-mm-dd',
            todayHighlight: true
        });
        $scope.emailremainderlist.selected  =   {};
        $scope.addattrmethod(index);
        var inp                 =   {   
                                        apsid       :   apsid,
                                        typeofproof :   typeofproof
                                    };
        showLoader('Please wait while undo records...');
        $http.post(BASE_URL+'dogetundoremainder',inp).then(function mySuccess(response) {
            hideLoader();
            if(response.data.status == 1) 
            { 
                angular.element(document.getElementById("enablededitbtn_"+index)).text('');
                var updatebutton    =   '<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doEditcorrection('+metataid+','+roundid+','+apsid+','+typeofproof+','+index+')">Edit</button>';
                var emailuptebutton =   $compile(updatebutton)($scope);
                angular.element(document.getElementById("enablededitbtn_"+index)).append(emailuptebutton);
                $('#correctionDate_'+index).datepicker('setStartDate',new Date(response.data.remainderitem.CORRECTION_DUE));
                $('#correctionDate_'+index).datepicker('setDate',new Date(response.data.remainderitem.CORRECTION_DUE));
                $('#firstDate_'+index).datepicker('setStartDate',new Date(response.data.remainderitem.FIRST_CORRECTION_DUE));
                $('#firstDate_'+index).datepicker('setDate',new Date(response.data.remainderitem.FIRST_CORRECTION_DUE));
                $('#secondDate_'+index).datepicker('setStartDate',new Date(response.data.remainderitem.SECOND_CORRECTION_DUE));
                $('#secondDate_'+index).datepicker('setDate',new Date(response.data.remainderitem.SECOND_CORRECTION_DUE));
                $('#thirdDate_'+index).datepicker('setStartDate',new Date(response.data.remainderitem.THIRD_CORRECTION_DUE));
                $('#thirdDate_'+index).datepicker('setDate',new Date(response.data.remainderitem.THIRD_CORRECTION_DUE));
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            hideLoader();
            showNotify(response.data.errMsg,'danger' );
        });
        
//        angular.element(document.getElementById("enablededitbtn_"+index)).text('');
//        var updatebutton    =   '<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doEditcorrection('+metataid+','+roundid+','+apsid+','+index+')">Edit</button>';
//        var emailuptebutton =   $compile(updatebutton)($scope);
//        angular.element(document.getElementById("enablededitbtn_"+index)).append(emailuptebutton);
//        var undogetvalue    =   $scope.emailremainderlist.remainderlist[index];
//        console.log(undogetvalue.SECOND_CORRECTION_DUE);
    }
    
    $scope.addattrmethod    =   function(index)
    {
        $("#correctionDate_"+index).attr('disabled',true);
        $("#firstDate_"+index).attr('disabled',true);
        $("#secondDate_"+index).attr('disabled',true);
        $("#thirdDate_"+index).attr('disabled',true);
    }
    
    $scope.removeattrmethod    =   function(index)
    {
        $("#correctionDate_"+index).removeAttr('disabled');
        $("#firstDate_"+index).removeAttr('disabled');
        $("#secondDate_"+index).removeAttr('disabled');
        $("#thirdDate_"+index).removeAttr('disabled');
    }
    
    /*$scope.getRemainderList = 	function() 
    {
        $scope.emaillist    = 	[];
        $http.get(BASE_URL+"getemailremainderlist").then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
            }
            $scope.emaillist       = 	response.data.emaillist;
            $scope.userId           =   response.data.userId;
        }, 
        function myError(response) {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
        });			
    };*/
    
    $scope.getRemainderList =   function () {

        $scope.dtOptions    =   DTOptionsBuilder.newOptions()
                                .withOption('ajax', {
                                        url: BASE_URL + 'getemailremainderlist',
                                        type: 'POST'
                                })
                                .withDataProp('data')// parameter name of list use in getLeads Fuction
                                .withOption('createdRow', function(row, data, dataIndex) {
                                    // Recompiling so we can bind Angular directive to the DT
                                    $compile(angular.element(row).contents())($scope);
                                })
                                .withOption('stateSave', false)
                                .withOption('processing', true) // required - for show progress bar
                                .withOption('serverSide', true)// required - for server side processing
                                .withOption('responsive', true)// required - for server side processing
                                .withOption('paging', true)// required
                                .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                                .withDisplayLength(10) //// Page size
                                .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                                .withOption('order', [[0, 'desc'], [0, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


        $scope.dtColumns    =   [
                                    DTColumnBuilder.newColumn('BOOK_ID').withTitle('Book Id'),
                                    DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Book Title'),
                                    DTColumnBuilder.newColumn('PM_NAME').withTitle('PM Name'),
                                    DTColumnBuilder.newColumn('EPROOF').withTitle('Remainder Type'),
                                    DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created date')
                                ];

        $scope.dtInstance   =   {};
    };
    
    if($scope.JobID     ==  ""){
        $scope.getRemainderList();
    }
    
    $scope.deleteemailremainder =   function(id,status,params) {
        var inp         =   {
                            ID: id,
                            STATUSID : status,
                            EMAILTYPE : params
                        };
        if(params   ==  1 && status ==  0)
        {
            $("#second_remainder_"+id).removeAttr('checked');
            $("#third_remainder_"+id).removeAttr('checked');
        }
        if(params   ==  2 && status ==  0)
        {
            $("#third_remainder_"+id).removeAttr('checked');
        }

        if(params   ==  1 && status ==  1)
        {
            $("#second_remainder_"+id).attr('checked','checked');
            $("#third_remainder_"+id).attr('checked','checked');
        }
        if(params   ==  2 && status ==  1)
        {
            $("#third_remainder_"+id).attr('checked','checked');
        }
        $http.post( BASE_URL+"remainderonoff", inp ) .then(function mySuccess(response) {
            showNotify(response.data.msg , response.data.errormsg);
            $window.location.href       = 	BASE_URL+"remainderchapterlist/"+$scope.JobID+'/'+$scope.Type;
        }, 

        function myError(response) {
            $window.location.href       = 	BASE_URL+"remainderchapterlist/"+$scope.JobID+'/'+$scope.Type;
        });
                
    }  

    
});