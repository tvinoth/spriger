    ngApp.controller('ngController', function ($scope,$filter,$compile,$timeout, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder ,fileUploadService ) 
    {
	$scope.userId 		= 	0;
 	$scope.menuParent 	= 	'Reports';
	$scope.menuChild 	= 	'Reports';
	$scope.errorMsg 	= 	"";
    });

    ngApp.service('fileUploadService', function ($http, $q) 
    {
            this.uploadFileToUrl 	= 	function (file,jobId,Mailid, uploadUrl) 
            {
            var fileFormData 	= 	new FormData();
            fileFormData.append('file', file);
			fileFormData.append('jobId', jobId);
			fileFormData.append('Mailid', Mailid);
            var deffered 		= 	$q.defer();
            $http.post(uploadUrl, fileFormData, 
			{
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
 
            }).then(function mySuccess(response) 
			{
                deffered.resolve(response);
 
            },
			function myError(response) 
			{
				deffered.reject(response);
			});
            return deffered.promise;
        }
    });