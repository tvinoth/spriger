/*
 *  Project Status Controller
 *  This controller contains all the methods related to project status screen.
 */
ngApp.controller('ngController', function ($scope, $http,DTOptionsBuilder, DTColumnBuilder) {
	
	$scope.chapterStatus = [];
	$scope.artStatus = [];
	$scope.JobID = getUrlParameter(1);
	
	/*
	 *  Get Chapter Status List
	 *  This method get all the active chapter status for the given job Id.
	 */
	$scope.getChapterStatus = function() {		
		var inp = {	job_id : $scope.JobID, opt : 'Chapter'};
		
		$http.post(API_URL+"getChapterArtStatus", inp) .then(function mySuccess(response) {
			$scope.chapterStatus = response.data.data;	
		}, 
		function myError(response) {
			 console.log(response);
		});	
		
	};
	/*
	 *  Get Art List
	 *  This method get all the art status list from DB for the given job Id.
	 */
	$scope.getArtStatus = function() {		
		var inp = {	job_id : $scope.JobID, opt : 'Art'};
		
		$http.post(API_URL+"getChapterArtStatus", inp) .then(function mySuccess(response) {
			$scope.artStatus = response.data.data;	
		}, 
		function myError(response) {
			 console.log(response);
		});	
		
	};
	$scope.getChapterStatus();
	$scope.getArtStatus();

});