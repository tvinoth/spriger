/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ($scope, $http , $window ) {
    $scope.projectList  =   [];
    $scope.showProject  =   false;
    $scope.isManager    =   false;
    $scope.menuParent   =   'Production';
    $scope.menuChild    =   'Project Bin';
    $scope.binObj       =   {};
    $scope.vm           =   {};
    $scope.vm.dtOptions =   {};
    $scope.JobID 		=	"";
	if(isNaN(getUrlParameter(1))){
		$scope.JobID 	= 	"";
	}else{
		$scope.JobID 	= 	getUrlParameter(1);
	}  
		
	if($scope.JobID 	!=	''){
		$('.chosen-select').chosen({});
		$('#projectSelect').chosen().val($scope.JobID).trigger('chosen:updated');
	}else{
		$('.chosen-select').chosen({}); 
	}		

    
    
    $scope.getUserDetail = function (){	
        
        $scope.userName = "";
        $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) {
               
                if(response.data.msg == "success") {
                    
                   $scope.userName = response.data.user_name;
                   $scope.roleName = response.data.role_name;
                   $scope.UserDetails = response.data;
                   
                } else {
                    window.location.href= BASE_URL+"?expired";
                }
            }, 
            function myError(response) {
                  showMessage('Message', 'Oops !, something went wrong , Kindly Reload the page.'   ); 
            });

    };
    $scope.gotoProjetSetup      =   function(jobID){
        window.location.href    =   BASE_URL+"pre-production/tps-setup/"+jobID;
    };
    
    /*
     *  Show Project List
     *  This method pass the user id, team id of the logged in user and get the list of projects for this user.
     */
    /*
	 *  Skip the current stage for the selected folios.
	 *  This method skip the current stage after getting confirmation from the user.
	 */
	$scope.skipStage = function(stageSeq, jobStageId, isArt, quantity, jobRoundId, iteration ) {
			
			bootbox.confirm("Are you sure you want to skip the process ?", function(result) {
			 	if(result) {					
							var inp = {	
							JOB_STAGE_ID     :   jobStageId,
							STAGE_SEQ        :   stageSeq,
							INPUT_QUANTITY   :   quantity,
							JOB_ROUND_ID	 :   jobRoundId,
							ITERATION_ID     :   iteration
						};
						  $http.post( API_URL+"skipStage" , inp ).then( function mySuccess(response) {
							var data  =  response.data;
							 if( response.data.status == 1 ){
								$window.location.href       =   BASE_URL+'projectbin';
								showNotify(response.data.msg , 'success' );	
								}else{
									showNotify( response.data.errMsg , 'danger' );
								}
							},function myError(response){
								showMessage('Message', 'oops! , something went wrong try again!'   ); 
						   });		
				} 
			});	
				
	};
	$scope.rollbacklist 	=	[];
	$scope.processRollBack = function (jobStageId) {
	//	alert(jobStageId);
			$('#show-rollback').click();
			$('#currentJSId').val(jobStageId);
			var inp = {	
				 JOB_STAGE_ID     :   jobStageId
            };
				$http.post( API_URL+"processRollBack" , inp ).then( function mySuccess(response) {
				$scope.rollbacklist 	=	response.data.rollbacklist;
            
            }, 
            function myError(response) {
                showMessage('Message', 'Oops !, something went wrong , Kindly Reload the page.'   ); 
            });	
		
	}
	$scope.rollStage = function () {
		currentJSId = $("#currentJSId").val();
		val = $("#rollStgs").val();
		out  = val.split(",");
		 
				 jobStageId   =  out[1];
				 stageId 	  =   out[0];
            
				$http.get( API_URL+"stageRollBack/"+currentJSId+"/"+stageId).then( function mySuccess(response) {
					 if( response.data.status == 1 ){
								$window.location.href       =   BASE_URL+'projectbin';
								showNotify(response.data.errMsg , 'success' );	
								}else{
									showNotify( response.data.errMsg , 'danger' );
								}
					
            }, 
            function myError(response) {
                showMessage('Message', 'Oops !, something went wrong , Kindly Reload the page.'   ); 
            });	
	}
        
    $scope.contentloadtimer     =   1;    
    $scope.showProjectBinData = function( jobid , round , stage ) {
            showLoader();
            
            var inp = {	
                user_id     :   '', 
                team_id     :   '' ,
                jobid       :   jobid ,
                round       :   round , 
                stage       :   stage
            };
            
            $http.post( API_URL+"getProjectBinInfo" , inp ).then( function mySuccess(response) {
                
                $scope.projectList = response.data.dt;
                var teamUser        =   false;
                teamUser            =   response.data.teamUser;
                $scope.isManager    =   response.data.is_manager;
                hideLoader();
            }, 
            function myError(response) {
                if($scope.contentloadtimer    <  5){
                    $scope.showProjectBinData(jobid , round , stage );
                }
                
                if($scope.contentloadtimer    ==  5){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });		
            $scope.contentloadtimer++;
            
    };

    $scope.getFiteredProjectBin     =       function( binObj ){
        
        if( binObj.projects == undefined  || binObj.round == undefined || binObj.stage  == undefined || 
            binObj.projects == ""  || binObj.round == "" || binObj.stage  == ""     ){
            
            if(  binObj.stage ==  null  ||  binObj.stage ==  ""  ){
                $('.stage_help').text('Kindly select option here.');
                $( '.stage_help' ).parents('.form-group').addClass('has-error');
            }
            
            if(  binObj.round == null ||  binObj.round == ""  ){
                $('.round_help').text('Kindly select option here.');
                $( '.round_help' ).parents('.form-group').addClass('has-error');
            }
            
            if(  binObj.projects == null ||  binObj.projects == ""  ){
                $('.bookId_help').text('Kindly select option here.');
                $( '.bookId_help' ).parents('.form-group').addClass('has-error');
            }
            
            return false;
        }
        
        showLoader();
        
            var inp = {	
                user_id     :   '', 
                team_id     :   '' ,
                jobid       :   binObj.projects ,
                round       :   binObj.round , 
                stage       :   binObj.stage
            };
            
            $http.post( API_URL+"getProjectBinInfo" , inp ).then( function mySuccess(response) {
                
                $scope.projectList  =   response.data.dt;
                var teamUser        =   false;
                teamUser            =   response.data.teamUser;
                $scope.isManager        =       response.data.is_manager;
                
                if( teamUser ){
                
                }
                
                hideLoader();
                
            }, 
            function myError(response) {
                showMessage('Message', 'Oops !, something went wrong , Kindly Reload the page.'   ); 
            });		
    };

    
      
    $scope.downloadPackageZip  = function( params , type  ){
        
        var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID , type : type };
        showLoader();
        $http.post( API_URL+"downloadPackageZip" , inp ).then(function mySuccess(response) {

            if( response.data.status == 1 ){
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 ){   
                hideLoader();
                showNotify( response.data.errMsg , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log(response);
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });
            
        
    };
    
    
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            /*if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }*/
			$scope.fileHandlerRunningStatus($scope.IsRunning,rmiId,attempt,$scope.noOfAttemptsToCheckIndesign,opt);
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    }; 

	$scope.fileHandlerRunningStatus 	=	function(running,rmiId,attempt,endattemptvalue,opt){
		if(running 	==	1){
			$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
		}else{
			if(attempt < endattemptvalue) {
				$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
			} else {
				hideLoader();
				showMessage('Download Status', "File handler is not running. Please check.", 'error');
			}
		}
	}	
	
     $scope.getUserDetail();
    
    $(document).ready(function () {

        $('#refreshbtn').on( "click",  function(){ 
            var tempjobid       =   ( $('#hiddenjobid').val() );
            if( tempjobid !== '' ){
                $scope.showProjectBinData( tempjobid , null , null );
            }
        });
                
        $('.ng-scope :checkbox').change(function () {
            var checkedCheckBoxes = $(this).parent().find(':checkbox:checked');
            if (checkedCheckBoxes.length > 2) {
                    this.checked = false;
                    $("#error").html("Only 5 can be checked. Please uncheck some if you want to check others... :)");
            }
            else {
                    $("#error").empty();
            }
        });
        
        var $firstid = '';
        $( "table" ).delegate( "input", "click", function() {
                //alert( $( this ).attr('id')  );
                if(document.querySelectorAll('input[type="checkbox"]:checked').length == '1'){
                        $firstid = $( this ).val();
                        $('#chapters_'+$firstid ).find('select').removeAttr("disabled");
                        //$('#bincontent').find('select').attr("disabled", "disabled");
                }else if(document.querySelectorAll('input[type="checkbox"]:checked').length == '0'){
                        $('#bincontent').find('select').removeAttr("disabled");
                }else{
                        //alert($firstid);

                        $('#bincontent').find('select').attr("disabled", "disabled");
                        $('#chapters_'+$firstid ).find('select').removeAttr("disabled");
                }
                
        });

		
       //alert(document.querySelectorAll('input[type="checkbox"]:checked').length);
        $( "input,select" ).focus(function() {
            $('.help-block').text('');
            $('.help-block').parents('.form-group').removeClass('has-error');
        });


        $(document).delegate("#chkall", "click", function(event){

            console.log( this.checked );

            if(this.checked) {
                jQuery('input:checkbox').attr('checked', 'checked');		
                jQuery('#row_normal > tbody ').find('input:checkbox').closest('tr').css('background-color', '#AFDCEC');
            }
            else {
                jQuery('input:checkbox').removeAttr('checked');
                jQuery('#row_normal > tbody > tr').css('background-color', '');

            }
        });
        
        var searchjobid         =   "";
        var searchroundid       =   "";
        var searchstageid       =   "";
        
        $scope.searchprojectbin     =   function(typeofsearch)
        {
            if(typeofsearch     ==  'projects'){
                searchjobid     =   $("#projectSelect").find('option:selected').val();
            }
			
			if(searchjobid	==	'' || searchjobid	==	undefined){
				searchjobid		=	 $scope.JobID;
			}
			
            if(typeofsearch     ==  'round'){
                if(searchjobid  ==  ''){
                    showNotify('Select Book ID'  , 'danger' );
                    return false;
                }
            }
            searchroundid   =   $("#roundSelect").find('option:selected').val();
            if(typeofsearch     ==  'stage'){
                if(searchjobid  ==  ''){
                    showNotify('Select Book ID'  , 'danger' );
                    return false;
                }
            }
            searchstageid   =   $("#stageselect").find('option:selected').val();
            if( searchjobid != '' ){
                $http.get( API_URL+"getBookInfoByJoid/"+searchjobid ).then(function mySuccess(response) {    
                    var bookinfo       =       response.data.bookinfo;
                    if(bookinfo.lenth   ==  0){
                        showNotify('Book data is not found', 'danger');
                        return false;
                    }
                    bookinfo           =       bookinfo[0];
                    $scope.bookinfo    =       bookinfo;
                    $scope.binObj.jobId          =       searchjobid;
                    $scope.binObj.bookId         =       bookinfo.bookId;

                    $scope.showProjectBinData( searchjobid , searchroundid , searchstageid );

                    },function myError(response) {
                });   
            }
        }
        
        /*$scope.searchprojectbin     =   function(typeofsearch)
        {
            if(typeofsearch     ==  'projects'){
                searchjobid     =   $("#projectSelect").find('option:selected').val();
            }
            if(typeofsearch     ==  'round'){
                if(searchjobid  ==  '' || searchjobid  ==  undefined){
                    showNotify('Select Book ID'  , 'danger' );
                    return false;
                }
            }
            searchroundid   =   $("#roundSelect").find('option:selected').val();
            if(typeofsearch     ==  'stage'){
                if(searchjobid  ==  '' || searchjobid  ==  undefined){
                    showNotify('Select Book ID'  , 'danger' );
                    return false;
                }
            }
            searchstageid   =   $("#stageselect").find('option:selected').val();
            if( searchjobid != '' ){
                var inp = {	
                    jobId       :   searchjobid ,
                    round       :   searchroundid,
                    typeofsearch:   typeofsearch
                };
                
                $http.post( API_URL+"getBookinfoByJobidwithProjectbinStage",inp ).then(function mySuccess(response) {    
                    var bookinfo        =   response.data.bookinfo;
                    var stagedata       =   "";
                    if(typeofsearch     !=  'stage'){
                        $("#stageselect").empty();
                        stagedata   +=   "<option value=''>--Select--</option>";
                    }
                    
                    if(response.data.stageinfo.length !=    0 && typeofsearch   !=  'stage'){
                        $.each(response.data.stageinfo,function(key,item){
                            stagedata   +=  "<option value="+item.STAGE_ID+">"+item.STAGE_NAME+"</option>";
                        });
                    }
                    $("#stageselect").append(stagedata);
                    $('#stageselect').trigger("chosen:updated");
                    if(bookinfo.lenth   ==  0){
                        showNotify('Book data is not found', 'danger');
                        return false;
                    }
                    bookinfo           =       bookinfo[0];
                    $scope.bookinfo    =       bookinfo;
                    $scope.binObj.jobId          =       searchjobid;
                    $scope.binObj.bookId         =       bookinfo.bookId;

                    $scope.showProjectBinData( searchjobid , searchroundid , searchstageid );

                    },function myError(response) {
                });   
            }
        }*/
        
        $( "#takeOwnership" ).on( 'click' ,  function(e) {

            e.preventDefault();                
            //Make inprogress here : yet to do                
                var checkboxes = document.getElementsByName('selected_chapters[]');                   
                var vals = "";
                
                

                if( checkboxes.length == undefined || checkboxes.length == 0 ){
                    showNotify( 'Invalid try.' , 'danger' );
                    return false;
                }

                for (var i=0, n=checkboxes.length;i<n;i++){
                    if (checkboxes[i].checked){
                        vals += ","+checkboxes[i].value;
                    }
                }
				
				 var selectList		=	new Array();
                        var art 		=	0;
                        var chapter     = 	0;
                        var differe    = 	0;
                        var same		=	0;
                        var stageCheck	=	new Array();
                         for (var i=0, n=checkboxes.length;i<n;i++){
                                if (checkboxes[i].checked && checkboxes[i].value !='' ){
									
									selectList[i] = checkboxes[i].value;
									var spliteVals    =       ( checkboxes[i].value.split('_') );

									if(spliteVals.indexOf("") == '-1'){
									  var art = 1;
									} else{
									  var chapter = 1;
									}
									//console.log(spliteVals);
									var splitCon	=	spliteVals['0']+'_'+spliteVals['1']+'_'+spliteVals['2']+'_'+spliteVals['3'];
											stageCheck[i] 	= 	splitCon;

                                }

                        }
				
				var filteredArray = stageCheck.filter(function(item, pos){
					return stageCheck.indexOf(item)== pos; 
				});
				
				if( chapter == 1 && art == 1){
					showNotify( 'Invalid Try!. Select only Chapter or Art  to Proceed on this.' , 'danger' );
					return false;
				}else if(chapter == 0 && art == 1){
					
					if(filteredArray.length == 1){
						
					}else{
						showNotify( 'Invalid Try!. Select same process to Proceed on this.' , 'danger' );
						return false;
					}
									
				}else if(chapter == 1 && art == 0){
					
					if(filteredArray.length == 1){
						
					}else{
						showNotify( 'Invalid Try!. Select Only one Chapter to Proceed on this.' , 'danger' );
						return false;
					}
				}
				
				

                if (vals) vals = vals.substring(1);

                if( vals.indexOf(",") == '-1' && vals !== '') {

                    var required_info       =       vals.split('_');
                    if ( required_info[required_info.length-1] !== '' ) {
                        console.log('Batch Checkout process start : ');                             
                            proceedBatchCheckout( vals );
                    } else {                            
                        //Yet to deside single checkout or batch Checkout
                        console.log('Single Checkout process start : ');
                        proceedSingleCheckout( vals );                            
                    }

                }else if( vals.indexOf(",") > 0 ){

                    var status_chk      =       proceedBatchCheckout( vals );
                    //if( !status_chk )
                        //showNotify( 'Invalid Try!. Select Only one Chapter to Proceed on this.' , 'danger' );

                }else if( vals == '' ){
                    showNotify( 'Invalid Try, Please Select a Chapter' , 'danger' );
                }else{
                    showNotify( 'Invalid Try.' , 'danger' );
                }

        });

        $( "#assignTo" ).on( 'click' ,  function(e) {
			//alert($firstid );
            e.preventDefault();
            //Make inprogress here : yet to do
            
			sbookId 		=   $("#projectSelect").find('option:selected').val();
			
			if(sbookId	==	'' || sbookId	==	undefined){
				sbookId		=	 $scope.JobID;
			}
            sroundId          =    $('#roundSelect').val();
            sstageId          =    $('#stageselect').val();
            
            if(sbookId == '')
             sbookId  = null;
           
            if(sroundId == '')
             sroundId  = null;
            
            if(sstageId == '')
             sstageId  = null;
       
            var checkboxes = document.getElementsByName('selected_chapters[]');

                var vals = "";

                if( checkboxes.length == undefined || checkboxes.length == 0 ){
                    showNotify( 'Invalid try.' , 'danger' );
                    return false;
                }

                for (var i=0, n=checkboxes.length;i<n;i++){
                    if (checkboxes[i].checked){
                        vals += ","+checkboxes[i].value;
                    }
                }

                if (vals) vals = vals.substring(1);
                

                if( vals.indexOf(",") == '-1' && vals !== '') {

                    console.log('Assigning process start : ');
                    var params      =       ( vals.split('_') );
                    metaid          =       params[1];
                    userto          =       0;

                    if ( params[params.length-1] !== '' ) {
                        userto      =       jQuery('#select_art_'+params[params.length-1] ).parents('tr').find('select').val();                       
                    }else{
                        userto      =       jQuery('#select_'+metaid ).parents('tr').find('select').val();
                    }

                    if( userto > 0 ){
                       
                        proceedtoAssign( vals , userto );
                    }else{
                        showNotify( 'Invalid try! , Select User from the drop down to assign.' , 'danger' );
                    }

                }else if( vals.indexOf(",") > 0 ){
                 			 
                        var selectList		=	new Array();
                        var art 		=	0;
                        var chapter     = 	0;
                        var differe    = 	0;
                        var same		=	0;
                        var stageCheck	=	new Array();
                         for (var i=0, n=checkboxes.length;i<n;i++){
                                if (checkboxes[i].checked && checkboxes[i].value !='' ){
									
                                        selectList[i] = checkboxes[i].value;
                                        var spliteVals    =       ( checkboxes[i].value.split('_') );

                                        if(spliteVals.indexOf("") == '-1'){
                                          var art = 1;
                                        } else{
                                                   var chapter = 1;
                                        }
                                        //console.log(spliteVals);
                                        var splitCon	=	spliteVals['0']+'_'+spliteVals['1']+'_'+spliteVals['2']+'_'+spliteVals['3'];
                                                stageCheck[i] 	= 	splitCon;

                                }

                            }
				
				var filteredArray = stageCheck.filter(function(item, pos){
					return stageCheck.indexOf(item)== pos; 
				});
				
				if( chapter == 1 && art == 1){
					showNotify( 'Invalid Try!. Select only Chapter or Art  to Proceed on this.' , 'danger' );
				}else if(chapter == 0 && art == 1){
					
					if(filteredArray.length >=1){
						var userID = $('#chapters_'+$firstid ).find('select').val();  
						//console.log(userID);
						var postData	=	{data:selectList,userid:userID};
						 $http.post( BASE_URL+"assignMultiTaskToUser" , postData ).then( function mySuccess(response) {  
							var data         =   response.data;
							//console.log(data);
							if( data.status == 1 ){
								showNotify( 'Successfully Assigned.' , 'success' );
								$scope.showProjectBinData(  sbookId, sroundId , sstageId );
							}else{
								showNotify( data.errMsg , 'danger' );
							}
						},function myError(response){
							showMessage('Message', 'Oops , something went wrong try again.'   ); 
						});

					}else{
						showNotify( 'Invalid Try!. Select same process to Proceed on this.' , 'danger' );
					}
									
				}else if(chapter == 1 && art == 0){
					
					if(filteredArray.length == 1){
						
						
						
					}else{
						var userID = $('#chapters_'+$firstid ).find('select').val();  
					
						if(userID == '0'){
							 showNotify( 'Invalid try! , Select User from the drop down to assign.' , 'danger' );
							 return false;
						}
						
						//console.log(userID);
						var postData	=	{data:selectList,userid:userID};
						 $http.post( BASE_URL+"assigningChaptersTaskToUser" , postData ).then( function mySuccess(response) {  
							var data         =   response.data;
							//console.log(data);
							if( data.status == 1 ){
								showNotify( 'Successfully Assigned.' , 'success' );
								$scope.showProjectBinData(  sbookId, sroundId , sstageId );
							}else{
								showNotify( data.errMsg , 'danger' );
							}
						},function myError(response){
							showMessage('Message', 'Oops , something went wrong try again.'   ); 
						});
												
					}
				}
			
				
                
                
                }else if( vals == '' ){
                    showNotify( 'Invalid Try, Please Select a Chapter' , 'danger' );
                }else{
                    showNotify( 'Invalid Try.' , 'danger' );
                }
				  return false;  

        });

        $( "#unlock" ).on( 'click' ,  function(e) {

            e.preventDefault();

            //Make inprogress here : yet to do
  
            var checkboxes = document.getElementsByName('selected_chapters[]');

                var vals = "";

                if( checkboxes.length == undefined || checkboxes.length == 0 ){
                    showNotify( 'Invalid try.' , 'danger' );
                    return false;
                }

                for (var i=0, n=checkboxes.length;i<n;i++){
                    if (checkboxes[i].checked){
                        vals += ","+checkboxes[i].value;
                    }
                }

                if (vals) vals = vals.substring(1);

                if( vals.indexOf(",") == '-1' && vals !== '') {

                    console.log('Unlock process start : ');
                    proceedtoUnlock( vals );

                }else if( vals.indexOf(",") > 0 ){
                    showNotify( 'Invalid Try!. Select Only one Chapter to Proceed on this.' , 'danger' );
                }else if( vals == '' ){
                    showNotify( 'Invalid Try, Please Select a Chapter' , 'danger' );
                }else{
                    showNotify( 'Invalid Try.' , 'danger' );
                }

        });

        function proceedtoUnlock( vals ){

             var params      =       ( vals.split('_') );
			 
            bookId     		=   $("#projectSelect").find('option:selected').val();
			
			if(bookId	==	'' || bookId	==	undefined){
				bookId		=	 $scope.JobID;
			}
			
            roundId          =    $('#roundSelect').val();
            stageId          =    $('#stageselect').val();
            
            if(bookId == '')
             bookId  = null;
           
            if(roundId == '')
             roundId  = null;
            
            if(stageId == '')
             stageId  = null;

            var postData     =      { 
                                        'jobid'     :  params[0] , 
                                        'metaid'    :  params[1] , 
                                        'round'     :  params[2] , 
                                        'stageId'   :  params[3] , 
                                        'jobstageid':  params[4] , 
                                        'artMetaid' :  params[5] 
                                    };
            
            $http.post( BASE_URL+"unlock" , postData ).then( function mySuccess(response) {  

                var data         =      response.data;
                if( response.data.status == 1 ){
                    showNotify( response.data.errMsg , 'success');
//                    $('#binfilter').trigger('click'); 
                    //$scope.showProjectBinData(  binObj.projects , binObj.round , binObj.stage );
                    $scope.showProjectBinData(  bookId , roundId , stageId );

                }else{
                    showNotify( response.data.errMsg , 'danger' );
                }

            },function myError(response){

                showMessage('Message', 'Oops , something went wrong try again after sometimes.'   ); 

           });

        }

        function proceedSingleCheckout( vals ){

            var params      =       ( vals.split('_') );

            var postData     =      { 
                                        'jobid'     :  params[0] , 
                                        'metaid'    :  params[1] , 
                                        'round'     :  params[2] , 
                                        'stageId'   :  params[3] , 
                                        'jobstageid':  params[4] , 
                                        'artMetaid' :  params[5] 
                                    };

            $http.post( BASE_URL+"checkOutProcess" , postData ).then( function mySuccess(response) {  

                var data         =   response.data;
                if( data.status == 1 ){
                    console.log( 'Proceed to Check-in Screen : ' );
                    $window.location.href       =       BASE_URL+'checkout/'+params[4];
                }else{
                    showNotify( data.errMsg , 'danger' );
                }

            },function myError(response){
                showMessage('Message', 'Oops , something went wrong try again after sometimes.'   ); 
           });

        }

        function proceedtoAssign( vals , assignto ){
            var params      =       ( vals.split('_') );
            var postData     =      { 
                                        'jobid'     :  params[0] , 
                                        'metaid'    :  params[1] , 
                                        'round'     :  params[2] , 
                                        'stageId'   :  params[3] , 
                                        'jobstageid':  params[4] , 
                                        'artMetaid' :  params[5] ,
                                        'assign_to' :  assignto
                                    };

            $http.post( BASE_URL+"assignTaskToUser" , postData ).then( function mySuccess(response) {  
                var data         =   response.data;
                if( data.status == 1 ){
                    $('#binfilter').trigger('click'); 
                    //console.log( 'Proceed to Check-in Screen : ' );
                    //$window.location.href       =       BASE_URL+'checkout/'+params[4];
                    $scope.showProjectBinData(  params[0] , null , null );
                }else{
                    showNotify( data.errMsg , 'danger' );
                }
            },function myError(response){
                showMessage('Message', 'Oops , something went wrong try again after sometimes.'   ); 
            });


        }

        function proceedBatchCheckout( vals ){
             
                var params      =       vals.split(',');
                var input_batch =      []; 
                
                for( var i =  0; i < params.length; i++ ){
                    
                    var required_info       =       params[i].split('_');
                    console.log( required_info[required_info.length-1] );
                    if ( required_info[required_info.length-1] == '' ) {                        
                        console.log( 'Invalid try for batch checkout.' );
                        return false;                    
                    }else{
                        
                        var postData     =      { 
                                                    'jobid'     :  required_info[0] , 
                                                    'metaid'    :  required_info[1] , 
                                                    'round'     :  required_info[2] , 
                                                    'stageId'   :  required_info[3] , 
                                                    'jobstageid':  required_info[4] , 
                                                    'artMetaid' :  required_info[5] 
                                                };
                                        
                        input_batch.push( postData );
                        
                    }
                    
                }
                
                console.log( 'Final level prepared input for batch checkout :' );
                console.log( input_batch );
                
                $http.post( BASE_URL+"batchCheckoutProcess" , { batch:input_batch } ).then( function mySuccess(response) {  
                    
                    var data         =   response.data;
                    
                    if( data.status == 1 ){
                        $window.location.href       =       BASE_URL+'checkout/'+data.params.batchid+'/batch';
                        
                    }else{
                        showNotify( data.errMsg , 'danger' );
                    }
                        
                },function myError(response){
                    showNotify( 'Oops , something went wrong try again after sometimes.' , 'danger' );
               });
                
            }
			
			
            
    });
    
});