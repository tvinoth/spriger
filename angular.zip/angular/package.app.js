/*
 *  Preset Master Controller
 *  This controller contains all the methods related to customization > Preset screen.
 */
ngApp.controller('ngController', function ($scope, $http, DTOptionsBuilder, DTColumnBuilder) {

    $scope.userId = 0;
    $scope.menuParent = 'Customization';
    $scope.menuChild = 'Transaction Package';

    $scope.preset = "";
    $scope.errorMsg = "";
    $scope.presetId = 0;
    
    /*
     *  Get Preset List
     *  This method get all the active preset from DB
     */
    $scope.showpackageList = function () {
        $scope.presetList = [];
        var inp = {roundId: 0, opt: 'All'};
        $http.post(API_URL + "getPackageList").then(function mySuccess(response) {
            $scope.presetList = response.data.packagelist;


        },
                function myError(response) {
                    console.log(response);
                });
    };

    $scope.showpackageList();

    /*
     *  Add Workflow
     *  This method used to add new Workflow details
     */
    $scope.addWorkflow = function () {
        $scope.clearWorkflow();
        $scope.getMenuList();
        $scope.action = 'add';
        $scope.Labelaction = 'ADD';
        $("#show-edit").click();
        //$scope.wfStages = $scope.AllStages;
        //$scope.wfCircles = $scope.Circle;
    };

    /*
     *  Clear Workflow Details
     *  This method used to clear Workflow details 
     */
    $scope.clearWorkflow = function () {
        $scope.PackageExistingName = "";
        $scope.wfName = "";
        $scope.wfdesc = "";
        $scope.packageId = '';
        $scope.errorMsg = "";
        $scope.newworkflowlist = [];
    };

    /*
     *  Get Preset List
     *  This method get all the active preset from DB
     */
    $scope.getMenuList = function () {

        $http.post(API_URL + "getMenuList").then(function mySuccess(response) {
            $scope.menuList = response.data.menulist;
            $scope.packageCode = response.data.packageCode[0].code;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    $scope.newworkflowlist = [];
    $scope.addnewitem = function (item)
    {
        var index = $scope.menuList.indexOf(item);

        $scope.menuList.splice(index, 1);
        $scope.newworkflowlist.push(item);
    }

    $scope.reddnewitem = function (item)
    {
        var index = $scope.newworkflowlist.indexOf(item);
        $scope.newworkflowlist.splice(index, 1);
        $scope.menuList.push(item);
    }

    $scope.upitem = function (item, position) {
        if (position > -1 && position < $scope.newworkflowlist.length)
        {
            if (position == 0)
            {
                return false;
//                var indexposition        =   $scope.newworkflowlist[position];
//                $scope.newworkflowlist[$scope.newworkflowlist.length]  =   indexposition;
//                $scope.newworkflowlist.splice($scope.newworkflowlist[indexposition+1],1);
            } else
            {
                var nextposition = $scope.newworkflowlist[position - 1];
                $scope.newworkflowlist[position - 1] = $scope.newworkflowlist[position];
                $scope.newworkflowlist[position] = nextposition;
            }
        }
    };
    $scope.downitem = function (item, position) {
        if (position > -1 && position < $scope.newworkflowlist.length)
        {
            if (position == $scope.newworkflowlist.length - 1)
            {
                return false;
//                var indexposition           =   $scope.newworkflowlist[position];
//                $scope.newworkflowlist[0]   =   indexposition;
//                $scope.newworkflowlist[$scope.newworkflowlist.length-1]  =   indexposition;
//                $scope.newworkflowlist.splice($scope.newworkflowlist[indexposition+1],1);
            } else
            {
                var nextposition = $scope.newworkflowlist[position + 1];
                $scope.newworkflowlist[position + 1] = $scope.newworkflowlist[position];
                $scope.newworkflowlist[position] = nextposition;
            }
        }
    };


    /*
     *  Save Workflow
     *  This method used to save Workflow details
     */
    $scope.saveWorkflow = function () {

        if ($scope.newworkflowlist == "") {
            $scope.errorMsg = "Please enter menu name.";
        } else if ($scope.wfName == '') {
            $scope.errorMsg = "Please enter package name.";
        } else {
            showLoader('Please wait while adding Data...');
            var packageName = $scope.wfName;
            var packageDesc = $scope.wfdesc;
            var packagecode = $scope.packageCode;
            var action = $scope.action;
            var packageId = '';

            if (action == 'edit') {
                packageId = $scope.packageId;
            }
            var inp = {packageId: packageId, actionType: action, userId: '', packagecode: packagecode, packageName: packageName, packageDesc: packageDesc, packageList: $scope.newworkflowlist};

            $http.post(API_URL + "savePackage", inp).then(function mySuccess(response) {
                hideLoader();
                if (response.data.errMsg == 'success') {
                    $("#edit-close").click();
                    $scope.showpackageList();
                    showNotify('Successfully Added', 'success');
                } else {
                    $("#edit-close").click();
                    showNotify('Unable to insert data', 'danger');
                }
                //
            },
                    function myError(response) {
                        console.log(response);
                    });

            hideLoader();
        }
    };


    $scope.validatePackageName = function () {

        if ($scope.wfName == '') {
            $scope.errorPackageName = false;
        }

        if ($scope.PackageExistingName != '') {
            console.log($scope.wfName);
            console.log($scope.PackageExistingName);
            if ($scope.wfName == $scope.PackageExistingName) {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;
                console.log($scope.PackageExistingName);
                return false;
            }
        }
        var inp = {packagename: $scope.wfName};
        $http.post(API_URL + "validatepackagename", inp).then(function mySuccess(response) {
            if (response.data.msg == 'invalid') {

                if (response.data.msg == 'empty') {
                    $scope.errorPackageName = false;
                }

                $scope.buttonvalidation = true;
                $scope.errorPackageName = true;
            } else {
                $scope.errorPackageName = false;
                $scope.buttonvalidation = false;

            }
            //
        },
                function myError(response) {
                    console.log(response);
                });

    };


    $scope.editPackage = function (pr) {


        $scope.getPackageMenuList(pr.id);
        $("#show-edit").click();
        $scope.action = 'edit';
        $scope.Labelaction = 'EDIT';
        $scope.packageId = pr.id;

        /*$scope.presetType = pr.type.toString();
         $scope.presetName = pr.Preset_name;
         $scope.presetId = pr.Preset_id;*/
    };

    /*
     *  Get Preset List
     *  This method get all the active preset from DB
     */
    $scope.getPackageMenuList = function (packageid) {

        var inp = {packageId: packageid};
        $http.post(API_URL + "getPackageMenuList", inp).then(function mySuccess(response) {
            $scope.menuList = response.data.menulist;
            $scope.packageCode = response.data.packageDetails[0].code;
            $scope.wfName = response.data.packageDetails[0].name;
            $scope.PackageExistingName = response.data.packageDetails[0].name;
            $scope.wfdesc = response.data.packageDetails[0].description;
            $scope.newworkflowlist = response.data.assignMenulist;
        },
                function myError(response) {
                    console.log(response);
                });
    };
    $scope.showPackageDetails = function (pr) {

        $("#viewpackage").click();
        $scope.showPackageInformation(pr);
        //$scope.wfStages = $scope.AllStages;
        //$scope.wfCircles = $scope.Circle;
    };

    $scope.showPackageInformation = function (pr) {

        var inp = {packageId: pr.id};
        $http.post(API_URL + "getPackageDetails", inp).then(function mySuccess(response) {
            $scope.packageCode = response.data.packageDetails[0].code;
            $scope.wfName = response.data.packageDetails[0].name;
            $scope.wfdesc = response.data.packageDetails[0].description;
            $scope.newworkflowlist = response.data.assignMenulist;
        },
                function myError(response) {
                    console.log(response);
                });
    };

    $scope.deletePackage = function (pr) {
        bootbox.confirm("Are you sure want to delete this) ?", function (result) {
            if (result) {
                showLoader('please wait for a while...');
                var inp = {packageId: pr.id};
                $http.post(API_URL + "deletepackage", inp).then(function mySuccess(response) {
                    if (response.data.msg == 'success') {
                        showNotify('Successfully deleted', 'success');
                        $scope.showpackageList();
                        hideLoader();
                    } else {
                        showNotify('Unable to delete record', 'danger');
                        hideLoader();
                    }
                    //
                },
                        function myError(response) {
                            console.log(response);
                        });

            }

        });

    }

});