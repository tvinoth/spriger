/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$q, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder) 
{	
	$scope.chapterdata      =   [];
        $('.chosen-select').chosen({}); 
        $scope.apsemailsetup    =   [];
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'View-Source';
        $scope.errorvalidationmsg   =   false;
        
        $scope.contentloadtimer     =   1;
        $scope.chapterinformation       =   function(jobid,metadata) 
	{
            var inp                     =   {'jodId' :jobid,'metadataID':metadata};
            var deferred                =   $q.defer();
            $http.post(BASE_URL+"viewSourceChapter",inp) .then(function mySuccess(response) 
            {
                $scope.chapterdata      =   response.data.chapterdata;
                $scope.filterchapterdata      =   response.data.filterchapterdata;
                deferred.resolve(response);
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.chapterinformation();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                deferred.reject(response);
            });	
            $scope.contentloadtimer++;
            return deferred.promise;
	};
        
        $scope.contentloadtimer     =   1;
        $scope.chapterinfodetails   =   function(){
            
            $('.required_field').removeClass('val-error');
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).val();
                    value       =   value.trim();
                    if(value    ==  '' || value ==  ' ' || value.length ==  0){
                    validation  =   false;
                    $(this).addClass('val-error');
                }
            });
            
            if(validation   ==  false){
                $scope.filterchapterdata  =   [];
                showNotify('All fields are required', 'danger' );
                return false;
            }
            
            if(($scope.bookname  ==  '' || $scope.bookname   ==  undefined) || ($scope.round  ==  '' || $scope.round   ==  undefined)){
//                 || ($scope.chaptername  ==  '' || $scope.chaptername   ==  undefined) 
                $scope.filterchapterdata  =   [];
                showNotify('All fields are required', 'danger' );
                return false;
            }else{
                
                var inp                     =   {'jodId' :$scope.bookname,'bookId':$("#bookidselect").find(":selected").data('bookid'),'roundId':$scope.round
//                    ,'metadataId':$scope.chaptername
                    };
                var deferred                =   $q.defer();
                $http.post(BASE_URL+"viewSourceChapter",inp) .then(function mySuccess(response) 
                {
                    if(response.data.result     ==  401)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation,function(key,val)
                            {
                                $.each(val,function(key,errval)
                                {
                                    $.notify(errval,'error');
                                });
                            });
                        }
                        showNotify( response.data.errMsg  , 'danger' );
                        hideLoader();
                    }
                
                    $scope.chapterdata      =   response.data.filterchapterdata;
//                    $scope.filterchapterdata      =   response.data.filterchapterdata;
                    deferred.resolve(response);
                }, 
                function myError(response) 
                {
                    if($scope.contentloadtimer    <  10){
                        $scope.chapterinformation();
                    }
                    if($scope.contentloadtimer    ==  10){
                        showNotify('Kindly reload page error occured.'  , 'danger' );
                        return false;
                    }
                    deferred.reject(response);
                });	
                $scope.contentloadtimer++;
                return deferred.promise;
            }
        }
        
        $scope.allchaptercheck  =   function(){
            var checkedall  =   $(".allchapter").is(':checked');
            if(checkedall   ==  true)
                $(".openchapter").prop('checked',true); 
            else
                $(".openchapter").prop('checked',false); 
        }
        
        $scope.openchapter  =   function(){
            var totalcheckbox   =   $(".openchapter").length;
            var checkedall      =   $(".openchapter:checked").length;
            if(totalcheckbox   ==  checkedall)
                $(".allchapter").prop('checked',true); 
            else
                $(".allchapter").prop('checked',false); 
        }
        
        $scope.roundchangedetails =   function() 
	{
            $("div[id^='viewsource_']").removeClass('val-error');
            var validation  =   true;
            $scope.chapterdata  =   [];
            var bookname    =   $("#viewsource_bookidselect").find('option:selected').val();
            var round    =   $("#viewsource_roundidselect").find('option:selected').val();
            if((bookname  ==  '' || bookname   ==  undefined || bookname ==  ' ' || bookname.length ==  0) || (round  ==  '' || round   ==  undefined || round ==  ' ' || round.length ==  0)){
                $scope.filterchapterdata  =   [];
                $("div[id^='viewsource_']").not('#viewsource_sourcetype_chosen').addClass('val-error');
                $.notify("All fields are required", "error");
                return false;
            }
            $("div[id^='viewsource_']").not('#viewsource_sourcetype_chosen').removeClass('val-error');
            var inp                     =   {'jodId' :bookname,'bookId':$("#viewsource_bookidselect").find(":selected").data('bookid'),'roundId':round};
            var deferred                =   $q.defer();
            $http.post(BASE_URL+"viewSourceChapter",inp) .then(function mySuccess(response) 
            {
                if(response.data.result     ==  400)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    return false;
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                    
                $scope.chapterdata      =   response.data.chapterdata;
                deferred.resolve(response);
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.chapterinformation();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
                deferred.reject(response);
            });	
            $scope.contentloadtimer++;
            return deferred.promise;
	};
        
        $scope.openchapterfiles     =   function() 
        {        
            $('.required_field').removeClass('val-error');
            var validation  =   true;
            $('.required_field').each(function(index){
                    var value   =   $(this).find('option:selected').val();
                    value       =   value.trim();
                    if(value    ==  '' || value ==  ' ' || value.length ==  0 || value.indexOf('?') !=   '-1'){
                    validation  =   false;
                    if($(this).attr("id")   ==  "viewsource_sourcetype"){
                        $("#viewsource_sourcetype_chosen").addClass('val-error');
                    }
                    $(this).addClass('val-error');
                }
            });
            var bookname    =   $("#viewsource_bookidselect").find('option:selected').val();
            var round    =   $("#viewsource_roundidselect").find('option:selected').val();
            var sourcetype    =   $("#viewsource_sourcetype").find('option:selected').val();
            var checkedall      =   $(".openchapter:checked").length;
            if(checkedall   ==  0){
                showNotify('Select minimum one chapter', 'danger' );
                return false;
            }
            
            if(validation   ==  false){
                showNotify('All fields are required', 'danger' );
                return false;
            }
            
            $("div[id^='viewsource_']").removeClass('val-error');
            var inputchapter    =   [];
            $(".openchapter:checked").each(function(){
                if($(this).val() != '')
                inputchapter.push($(this).val())
            });
            
            if(inputchapter.length   ==  0){
                showNotify("Chapter data's are empty", "danger" );
                return false;
            }
//            var viewsourcetype  =   $("#resourceid_"+item.METADATA_ID).val();
//            if(viewsourcetype == '' || viewsourcetype == undefined || viewsourcetype.indexOf('?') !=   '-1'){
//                $("#resourceid_"+item.METADATA_ID).addClass('val-error');return false;
//            }
            
            showLoader('Please wait while checkout...');
            var inp             = 	{
                                jobId       :   bookname,
                                roundId     :   round,
                                resourcetype :  sourcetype,
                                chapterId    :   inputchapter
                        };  

            $http.post(BASE_URL + 'openChapterFiles', inp)
            .then(function mySuccess(response) 
            {
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    if (typeof response.data.validation !== 'undefined') {
                        $.each(response.data.validation,function(key,val)
                        {
                            $.each(val,function(key,errval)
                            {
                                $.notify(errval,'error');
                            });
                        });
                    }
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }

                if(response.data.result     ==  500)
                {
                    showNotify( response.data.errMsg  , 'warning' );
                    hideLoader();
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    var filehandlerid   =   response.data.rmID;
                    $scope.checkfilestatusopenornot(attempt,filehandlerid);
                }
            }, 
            function myError(response) 
            {
            });
        };
        
        $scope.checkfilestatusopenornot     =   function(attempt,filehandlerid) 
        {           
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Opendrive'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(attempt,filehandlerid); }, 2000 );
                    } else {
                        hideLoader();
                        showNotify("File handler is not running. Please check..", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    hideLoader();
                    showNotify("File handler is not running. Please check....", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    hideLoader();
                    showNotify( response.data.errMsg, 'success' );
                }
            }, 
            function myError(response) 
            {
                hideLoader();
            });
        };
        
        
        $scope.clearfile        =   function()
        {
            var apssourceFile   =   document.getElementById("apsSource").value    =   '';
        }
});
    