/*
 *  Dashboard Controller
 *  This controller contains all the methods related to dashboard screen.
 */
ngApp.controller('ngController', function ( $scope, $http) {
	$scope.chkFilesCount        =   false;
	$scope.chkFilesAssigned     =   true;
	$scope.chkMyPerformance     =   false;
	$scope.chkMyPerformanceRes  =   true;
	$scope.chkFilesAssignedRes  =   true;
	$scope.chkFilesCountRes     =   true;
	$scope.myPerformaceRes      =   "";
	$scope.myFilesAssignedRes   =   "";
	$scope.myFilesCountRes      =   "-";
	
	$scope.myPerformance        =   "";
	$scope.myFilesCount         =   [];
	$scope.myFilesAssigned      =   [];

	$scope.menuChild            =   'Dashboard';
	$scope.menuParent           =   'Dashboard';
	$scope.customParam          =   "";
	/*
	 *  Get Files Assigned to Me
	 *  This method pass the user id and get the files assigned to the user.
	 *  It will show the count in the widget and keep the response for detailed view.
	 */
        $scope.contentloadtimer         =   1;
	$scope.getFilesAssignedToMe     =   function() {
            $scope.filesAssignedToMe    =   [];
            var inp = {	user_id : ''};
            $http.post(API_URL+"getAssignedFilesList", inp) .then(function mySuccess(response) {
                $scope.filesAssignedToMe    =   response.data.data;
                $scope.chkFilesAssignedRes  =   false;	
                $scope.myFilesAssignedRes   =   response.data.data.length;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  5){
                    $scope.getFilesAssignedToMe();
                }
                if($scope.contentloadtimer    ==  5){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;
	};
	/*
	 *  Get Files Count
	 *  This method pass the user id, manager, circle of the logged in user and get the files count for this user.
	 *  It will show the count in the widget and keep the response for detailed view.
	 */
        $scope.contentloadtimer =   1;
	$scope.getFilesCount    =   function() {
            $scope.filesCount   =   [];
            var inp             =   {user_id : '', manager : '', circle_id : '', team_id : ''};
            $http.post(API_URL+"getFilesCountList", inp) .then(function mySuccess(response) {
                if(response.data.data   ==  '-'){
                    $scope.filesCount   =   [];
                }else{
                    $scope.myFilesCount =   response.data.data;	
                }
                $scope.chkFilesCountRes =   false;	
                $scope.myFilesCountRes  =   response.data.data;
            }, 
            function myError(response) {
                if($scope.contentloadtimer    <  5){
                    $scope.getFilesCount();
                }
                if($scope.contentloadtimer    ==  5){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;
	};	
	/*
	 *  Get My Performance
	 *  Skeleton method... need to implement the logic
	 */
	$scope.getMyPerformance         =   function() {
            $scope.myPerformance        =   "My Performance details will come here";
            $scope.chkMyPerformanceRes  =   false;
            $scope.myPerformaceRes      =   "-";
	}
        
	$scope.gotoCheckOutPage = function(item) 
        {
            if(item.batchid ==  null || item.batchid ==  '')
            {
                window.location.href    =   BASE_URL+"checkout/"+item.job_stage_id;
                return false;
            }
            if(item.batchid !=  '')
            {
                window.location.href    =   BASE_URL+"checkout/"+item.batchid+"/batch";
            }
	};
	$scope.gotoProjectStatus        =   function(jobID) {
            window.location.href    =   "./project-status/"+jobID;
	};
	/*
	 *  Show Files Assigend to Me
	 *  This method shows the list of files assigned to me from the response we get it from getFilesAssignedToMe method.
	 */
	$scope.showFilesAssignedToMe    =   function() {
            $scope.chkFilesCount        =   false;
            $scope.chkMyPerformance     =   false;
            $scope.chkFilesAssigned     =   true;
            angular.element("#assignedtome").addClass("boxactiveshow");
            angular.element("#performance").addClass("hideboxactiveshow");
            angular.element("#filescount").addClass("hideboxactiveshow");
            angular.element("#performance").removeClass("boxactiveshow");
            angular.element("#filescount").removeClass("boxactiveshow");
            angular.element("#assignedtome").removeClass("hideboxactiveshow");
            
	};
	/*
	 *  Show Files Count
	 *  This method shows the list of files from the response we get it from getFilesCount method.
	 */
	$scope.showFilesCount = function() {
            $scope.chkFilesAssigned     =   false;
            $scope.chkMyPerformance     =   false;
            $scope.chkFilesCount        =   true;
            angular.element("#performance").removeClass("boxactiveshow");
            angular.element("#assignedtome").removeClass("boxactiveshow");
            angular.element("#filescount").addClass("boxactiveshow");
            angular.element("#filescount").removeClass("hideboxactiveshow");
            angular.element("#performance").addClass("hideboxactiveshow");
            angular.element("#assignedtome").addClass("hideboxactiveshow");
            if($scope.chkFilesCount)
            {	
            	$scope.filesCount = $scope.myFilesCount;
            } else {		
            }
	};
	/*
	 *  Get My Performance
	 *  Skeleton method... need to implement the logic
	 */
	$scope.showMyPerformance    =   function() {
            $scope.chkFilesCount        =   false;
            $scope.chkFilesAssigned     =   false;
            $scope.chkMyPerformance     =   true;
            angular.element("#performance").addClass("boxactiveshow");
            angular.element("#filescount").removeClass("boxactiveshow");
            angular.element("#assignedtome").removeClass("boxactiveshow");
            angular.element("#filescount").addClass("hideboxactiveshow");
            angular.element("#assignedtome").addClass("hideboxactiveshow");
            angular.element("#performance").removeClass("hideboxactiveshow");
            if($scope.chkMyPerformance){
                    $scope.performance  =   $scope.myPerformance;
            }
	};
	$scope.getFilesAssignedToMe();
        $scope.getFilesCount();
	$scope.getMyPerformance();

});