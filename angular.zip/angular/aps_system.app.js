/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$q, $http,$timeout,$window,DTOptionsBuilder, DTColumnBuilder,fileUploadService) 
{	
	$scope.JobID 		=   "";
	$scope.Msgsuccess 	=   false;
	$scope.errorresponse 	=   "";
	$scope.msg 	 	=   "";
	$scope.SessionMsg 	=   true;
        $scope.sendproofdisabled    =   true;
	
        if(isNaN(getUrlParameter(1))){
		$scope.JobID 	=   "";
	}else{
		$scope.JobID 	=   getUrlParameter(1);
                $scope.bookname =   getUrlParameter(1);
	}
        
        $scope.apsemailsetup    =   [];
 	$scope.menuParent 	=   'Pre-Production';
	$scope.menuChild 	=   'Aps-Report';
        
        //aps proof
        $scope.apstypeofcontact =   [{'id':1,'name':'Author'},{'id':2,'name':'Editor'}];
        $scope.apstypeofstage   =   [{'id':118,'name':300},{'id':120,'name':650}];
        $scope.stagename        =   $scope.apstypeofstage[0].id;
        $scope.authoreditor     =   $scope.apstypeofcontact[0].id;
        $scope.errorvalidationmsg   =   false;
	        
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
        */
        
	$scope.chapterList              =   function(){
		
		$scope.ApsList              =   [];
		var inp                     =   {'jodId' : $scope.JobID,'stage':$scope.stagename};
		
		$http.post( BASE_URL+"getaps_chapter" , inp ) .then( function mySuccess( response ) {
			
			$scope.ApsList          =   response.data.apschapter;
			$scope.getBookinfo( $scope.JobID );
			
			setTimeout( function() {
				$scope.$digest();
			} , 7000 );
		  
		} ,  function myError( response ){
			
			showNotify( response.data.errMsg , 'danger' );
			
		});			
			
	};
     
	 
	$scope.getBookinfo 	=	 function( jbid ) {

            $scope.introductory     =      {};

            if( jbid != '' ){

                $http.get( API_URL+"getBookInfoByJoid/"+jbid ).then(function mySuccess(response) {    

                    var bookinfo       =       response.data.bookinfo;
						bookinfo           =       bookinfo[0];
						$scope.bookinfo    =       bookinfo;

						$scope.introductory.spiContactEmpId    =        bookinfo.empId;
						$scope.introductory.spiContactname     =        bookinfo.pmName;
						$scope.introductory.spiEmail           =        bookinfo.pmEmail;
						$scope.introductory.titleName          =        bookinfo.bookTitle;
						$scope.introductory.mailFrom           =        bookinfo.proofRecipient;
						$scope.introductory.mailCc             =        bookinfo.productionEditor;
						$scope.introductory.mailFrom           =        'no-reply@spi-global.com';

						$scope.introductory.jobId              =       jbid;

						var threword   =   bookinfo.bookTitle.split(" ");
						threword       =   'Your Book : '+threword[0]+' '+threword[1]+' '+threword[2];

						if( bookinfo.authorName == '' ){
							var subPre     =   bookinfo.printIssn+', '+bookinfo.editorName+':'+threword; 
						}
						else {
							var subPre     =   bookinfo.printIssn+', '+bookinfo.authorName+':'+threword;
						}
                    
                    console.log( 'Am here print subject' );
                    console.log( subPre );
                    $scope.apsemailsetup.authoreditorsubject		=	subPre;

                },function myError(response) {

               });   

            }
                
	};
             
		
        $scope.searchprocess   =   function(){
            $scope.chapterList();
        }
        
        $scope.proof_check      =   function(position,item){
			
            angular.forEach( item , function( par , index ){
                if (position    !=  index) 
                par.checked     =   false;
            });
        
		}
        
        $scope.bookinformation          =   function(){
			
            var inp         	=   	{'jodId' : $scope.JobID};
            var deferred      	=   	$q.defer();
            
	    $http.post( BASE_URL+"getaps_bookinfo" , inp ).then( function mySuccess( response ){
				
                $rootScope.ApsBookinfo  		=   response.data.jobinfo;
                $scope.apsemailsetup.ccemail    =   response.data.ccemail;
                $scope.apsemailsetup.subject    =   response.data.subjectline;
                $scope.apsProofletter   		=   response.data.proofletter;
                
				deferred.resolve(response);
				
				
            }, function myError(response) {
                deferred.reject(response);
                showNotify(response.data.errMsg, 'danger' );
            });			
			
            return deferred.promise;
			
	};
        
        if($scope.JobID     !=  '')
        {
            $scope.bookinformation();
            $scope.chapterList();
        }
        
        $scope.bookinfodetails 	=   function() {
            var bookid  =   $scope.bookname;
            if(bookid   ==  '')
            return false;
            $window.location.href   =   BASE_URL+"aps_system/"+bookid;
		};
	
        $scope.proofapssubmit       =   function( typeofvieworsendemail ){
            $scope.sendproofdisabled    =   true;
            $scope.errorvalidationmsg   =   false;
            
            var checkemptychapter   =   $('input[name="authorproofchapter[]"]:checked').map(function(){return $(this).val();}).get();
            
            if(checkemptychapter.length ==  0){
                
                //$scope.sendproofdisabled    =   false;
                showNotify('Kindly select anyone chapter', 'danger' );
                return false;
                
            }
			
            var apssourceFile       =   angular.element(document.getElementById("apsSource").files[0]);
            var apssourceFilename   =   $("#apsSource").val();
            var apsMailFile         =   angular.element(document.getElementById("myFileField").files[0]);
            var apsmailattchFilename=   $("#myFileField").val();
            var checktoemail        =   $("#toemail").val();
            var getccemail          =   $("#ccemail").val();
            var authorname          =   $("#authorname").val();
            var authoreditortype    =   $("#authoreditor:checked").val();
			
            if( $scope.bookname     ==   undefined || $scope.stagename   ==   undefined || authorname == '' || $scope.apsemailsetup.fromapsemail   ==   undefined || $scope.apsemailsetup.fromapsemail   ==   '' || checktoemail  ==   '' || $scope.apsemailsetup.proofletter   ==   undefined || $scope.apsemailsetup.proofletter   ==   '' || $scope.apsemailsetup.authoreditorsubject ==  undefined || $scope.apsemailsetup.authoreditorsubject ==  '' || $scope.apsemailsetup.proof_returendate ==  undefined  || $scope.apsemailsetup.proof_returendate ==  '' ) 
            {
                //$scope.sendproofdisabled    =   false;
                $scope.adderrorMsg  =   'Mandatory fields are required';
                showNotify($scope.adderrorMsg  , 'danger' );
                return false;
            }
			
            if( apssourceFilename !=     "") 
            {
                var sourceSize      =   (angular.element(document.getElementById("apsSource").files[0].size / 1024));
                if(sourceSize[0] >= 3072)
                {
                    //$scope.sendproofdisabled    =   false;
                    $scope.adderrorMsg  =   'File size should be below 3 Mb';
                    showNotify($scope.adderrorMsg  , 'danger' );
                    return false;
                }
            }
            
            if(checktoemail !=  '')
            {
                var checkmultitoemail       =   checktoemail.indexOf(",");
                $scope.validtoemailidres    =   $scope.validateemailid(checkmultitoemail,checktoemail);
                if($scope.validtoemailidres ==  false)
                {
                    //$scope.sendproofdisabled    =   false;
                    showNotify('Invalid Email Id', 'danger' );
                    return false;
                }
            }
            
            if(getccemail     !=   '')
            {
                var checkccemail            =   getccemail.indexOf(",");
                $scope.validccemailidres    =   $scope.validateemailid(checkccemail,getccemail);
                if($scope.validccemailidres   ==  false)
                {
                    //$scope.sendproofdisabled    =   false;
                    showNotify('Invalid Email Id', 'danger' );
                    return false;
                }
            }

            if( apsmailattchFilename !=     "") 
            {
                var sourceSize      =   (angular.element(document.getElementById("myFileField").files[0].size / 1024));
                if(sourceSize[0] >= 3072)
                {
                    //$scope.sendproofdisabled    =   false;
                    $scope.adderrorMsg  =   'File size should be below 3 Mb';
                    showNotify($scope.adderrorMsg  , 'danger' );
                    return false;
                }
            }
            
            showLoader('Please wait while add new setup...'); 
            if( typeofvieworsendemail    ==  1 ) {
                var uploadUrl       =   BASE_URL+"storeapsproofsystem";
                promise             =   fileUploadService.uploadFileToUrl($scope.bookname,$scope.stagename,authoreditortype,checkemptychapter.toString(),apssourceFile[0],checktoemail,
                getccemail,authorname,$scope.apsemailsetup.fromapsemail,$scope.apsemailsetup.proofletter,$scope.apsemailsetup.authoreditorsubject,$scope.apsemailsetup.proof_returendate,
                $scope.apsemailsetup.subject,apsMailFile[0],uploadUrl);
                promise.then(function mySuccess(response) 
                {
                    $scope.errorvalidationmsg       =   false;
                    if(response.data.result  ==  200){
                        //$scope.sendproofdisabled    =   false;
                        $scope.apsemailsetup.authoreditorsubject    =   '';
                        $scope.apsemailsetup.proof_returendate      =   '';
                        $scope.apsemailsetup.fromapsemail           =   '';
                        $scope.apsemailsetup.proofletter            =   '';
                        $scope.apsemailsetup.subject                =   '';
                        $("#apsSource").val('');
                        $("#myFileField").val('');
                        getccemail                                  =   '';
                        $scope.ApsList      =   response.data.apschapter;
                        showNotify(response.data.errMsg  , 'success' );
                    }
                    hideLoader();
                }, function myError(errorresponse) 
                {
                    //$scope.sendproofdisabled    =   false;
                    hideLoader();
                    if(errorresponse.data.errMsg)
                    {
                        showNotify(errorresponse.data.errMsg  , 'danger' );
                    }
                    if(errorresponse.data.validation.length >=1)
                    {
                        $("#redofailed").html('');
                        $scope.errorvalidationmsg       =   true;
                        $scope.shownotavaiablechapter   =   errorresponse.data.validation;
                        $('#show-redo').trigger('click');
                        $scope.Msgbox 	=	"Validation Errors";
                    }
                });
            }else{
                var inp             = 	{bookId                 :   $scope.bookname,
                                        roundId                 :   $scope.stagename,
                                        author_or_editor_type   :   authoreditortype,
                                        chapter                 :   checkemptychapter.toString(),
                                        toemail                 :   checktoemail,
                                        ccemail                 :   getccemail,
                                        author_or_editor_name   :   authorname,
                                        proof_letter_type       :   $scope.apsemailsetup.proofletter,
                                        from_email              :   $scope.apsemailsetup.fromapsemail,
                                        author_or_editor_subject_line   :       $scope.apsemailsetup.authoreditorsubject,
                                        proof_returned_date     :   $scope.apsemailsetup.proof_returendate,
                                        subject                 :   $scope.apsemailsetup.subject
                                    };         
                $http.post(BASE_URL + 'apsemailpreview', inp).then(function mySuccess(response) 
                {
                    if( response.data.result  ==  200 ){
						
                        $scope.errorvalidationmsg   =   false;
                        
                        if( response.data.params.prooflinkstatus    == 1 ){
                            $scope.sendproofdisabled    =   false;
                        }else{
                           $scope.sendproofdisabled    =   false; 
                        }
                        
                        hideLoader();
                        $('#show-redo').trigger('click');
                        $scope.Msgbox 	=	"E-Mail Preview";
                        $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
                        var size = {width: $(window).width() , height: $(window).height() }
                       
                        /*CALCULATE SIZE*/
                        var offset = 20;
                        var offsetBody = 150;
                        $('#modal-redo').css( 'height' , size.height - offset );
                        $('.modal-body').css( 'height' , size.height - ( offset + offsetBody ) );
                        $('#modal-redo').css( 'top', 0 );
                        
                        //$('#xmlContent2').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                        //$('#xmlContent2').html(response.data);
						
						
                    }else{
                        
                        hideLoader();
                        $scope.sendproofdisabled    =   true;
                        
                        showNotify(response.data.errMsg, 'danger');
                        if(response.data.validation.length >=1)
                        {
                            $scope.errorvalidationmsg       =   true;
                            $scope.shownotavaiablechapter   =   response.data.validation;
                        }
                    }
                }, 
                function myError(response) 
                {
                    if(response.data.validation.length >=1)
                    {
                        $("#redofailed").html('');
                        $scope.errorvalidationmsg       =   true;
                        $scope.shownotavaiablechapter   =   response.data.validation;
                        $('#show-redo').trigger('click');
                        $scope.Msgbox 	=	"Validation Errors";
                    }
                    
                    hideLoader();
                    $scope.sendproofdisabled    =   false;
                    showNotify(response.data.errMsg, 'danger');
                });
                
            }
        }
        
        $scope.clearfile        =   function()
        {
            var apssourceFile   =   document.getElementById("apsSource").value    =   '';
        }
	
        $scope.doOpenmergepdf   =   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID) 
        {     
            var checkemptychapter   =   $('input[name="authorproofchapter[]"]:checked').map(function(){return $(this).val();}).get();
            
            if(checkemptychapter.length ==  0){
                showNotify('Kindly select anyone chapter', 'danger' );
                return false;
            }
            
            var inp             = 	{
                                            jobId       :   $scope.bookname,
                                            metadataid  :   checkemptychapter.toString(),
                                            roundid     :   $scope.stagename
                                        };
                                        
            $scope.jobandcucview    =   "Merge PDF";
            var window_dimensions   =   "directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=0,resizable=0, width=1200,height=850";
            $http({
                    url         :   BASE_URL + "doOpenMergepdf",
                    method      :   'POST',
                    data        :   inp
                 })
            .success(function(response) 
            {
                if(response.result     ==  400)
                {
                    showNotify( response.errMsg  , 'danger' );
                }
                if(response.result     ==  404)
                {
                    showNotify( response.errMsg  , 'danger' );
                }
                if(response.xmlcount >= 1)
                {
                    window.open(response.errMsg, "Pdf File View", window_dimensions );
                }
                
            })
            .error(function(response) 
            {
                showNotify( response.errMsg  , 'danger' );
            });
        }
    
        //open openjobrawfile
        $scope.openjobrawfile   =   function(jobId)
        {
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            $(currentChapter).attr('disabled','true');          
            showLoader('Please wait while Open Drive ...');
            var inp             =   {
                                        jobId       :   jobId
                                    };   
            $http.post(BASE_URL + 'openrawfile', inp)
            .then(function mySuccess(response) 
            {
                if(response.data.result     ==  404)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  401)
                {
                    showNotify( response.data.errMsg  , 'danger' );
                    hideLoader();
                }
                if(response.data.result     ==  200)
                {
                    var attempt         =   1;
                    $scope.checkfilestatusopenornot(jobId,attempt,response.data.rmID);
                }
                $(currentChapter).removeAttr('disabled','true');
            }, 
            function myError(response) 
            {
                hideLoader();
                $(currentChapter).removeAttr('disabled','true');
            });
        }
        
        $scope.checkfilestatusopenornot     =   function(jobId,attempt,filehandlerid) 
        {           
            var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
            var inp             = 	{rmiID  :   filehandlerid,
                                    typeofstatus   :    'Opendrive'};
            $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
            {
                if(response.data.result     ==  500)
                {
                    attempt++;
                    if(attempt <= 5) {
                        $timeout( function(){ $scope.checkfilestatusopenornot(jobId,attempt,filehandlerid); }, 2000 );
                    } else {
                        hideLoader();
                        $(currentChapter).removeAttr('disabled','true');
                        showNotify("File handler is not running. Please check.", 'danger');
                    }
                }
                if(response.data.result     ==  404)
                {
                    hideLoader();
                    $(currentChapter).removeAttr('disabled','true');
                    showNotify("File handler is not running. Please check.", 'danger');
                }
                if(response.data.result     ==  200)
                {
                    hideLoader();
                    showNotify( response.data.errMsg, 'success' );
                    $(currentChapter).removeAttr('disabled','true');
                }
            }, 
            function myError(response) 
            {
                hideLoader();
                $(currentChapter).removeAttr('disabled','true');
            });
        };
        
        $scope.validateemailid  =   function(checkmultipleemail,currentemailvaluevalid)
        {
            var emailReg        =   /^\b[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b$/i;
            var validationfailedorsuccess   =   true;
            if(checkmultipleemail !==   -1)
            {
                var morethanemailvalid  =   currentemailvaluevalid.split(',');
                angular.forEach(morethanemailvalid, function(value, key) {
                    if(value != ''){
                        if(!(value).match(emailReg)){
                            return validationfailedorsuccess = false;
                        }else{
                            return validationfailedorsuccess   =   true;
                        }}
                    });
            }else{
                if(!(currentemailvaluevalid).match(emailReg)){
                    validationfailedorsuccess   =   false;
                }else{
                    validationfailedorsuccess   =   true;
                }
            }
            return validationfailedorsuccess;
        }
});

    ngApp.service('fileUploadService', function ($http, $q) 
    {
        this.uploadFileToUrl 	=   function (bookId,roundId,author_or_editor_type,chapter,apssourceFile,
        toemail,ccemail,author_or_editor_name,from_email,proof_letter_type,author_or_editor_subject_line,
        proof_returned_date,subject,apsMailFile,uploadUrl)
        {
            var fileFormData 	=   new FormData();
            fileFormData.append('bookId', bookId);
            fileFormData.append('roundId', roundId);
            fileFormData.append('author_or_editor_type', author_or_editor_type);
            fileFormData.append('chapter', chapter);
            fileFormData.append('Source_file', apssourceFile);
            fileFormData.append('toemail', toemail);
            fileFormData.append('ccemail', ccemail);
            fileFormData.append('author_or_editor_name', author_or_editor_name);
            fileFormData.append('proof_letter_type', proof_letter_type);
            fileFormData.append('from_email', from_email);
            fileFormData.append('author_or_editor_subject_line', author_or_editor_subject_line);
            fileFormData.append('proof_returned_date', proof_returned_date);
            fileFormData.append('subject', subject);
            fileFormData.append('mail_attachment_file', apsMailFile);            
            var deffered        =   $q.defer();
            $http.post(uploadUrl, fileFormData, 
            {
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
            }).then(function mySuccess(response) 
            {
                deffered.resolve(response);
            },
            function myError(response) 
            {
                deffered.reject(response);
            });
            return deffered.promise;
        }
    });
    