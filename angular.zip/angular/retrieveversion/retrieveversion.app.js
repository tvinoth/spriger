/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope, $rootScope, $q, $http, $timeout, $window, DTOptionsBuilder, DTColumnBuilder)
{
    $scope.chapterdata = [];
    $('.chosen-select').chosen({});
    $scope.apsemailsetup = [];
    $scope.menuParent = 'Pre-Production';
    $scope.menuChild = 'View-Source';
    $scope.errorvalidationmsg = false;
    $scope.alfrescoConsId = "";

    $scope.allchaptercheck = function () {
        var checkedall = $(".allchapter").is(':checked');
        if (checkedall == true)
            $(".openchapter").prop('checked', true);
        else
            $(".openchapter").prop('checked', false);
    }

    $scope.openchapter = function () {
        var totalcheckbox = $(".openchapter").length;
        var checkedall = $(".openchapter:checked").length;
        if (totalcheckbox == checkedall)
            $(".allchapter").prop('checked', true);
        else
            $(".allchapter").prop('checked', false);
    }

    $scope.chapterdata = [];

    $scope.roundchangedetails = function ()
    {
        $("div[id^='viewsource_']").removeClass('val-error');
        var validation = true;
        $scope.chapterdata = [];
        $scope.alfrescodata = [];
        var bookname = $("#viewsource_bookidselect").find('option:selected').val();
        var round = $("#viewsource_roundidselect").find('option:selected').val();
        var process = $("#viewsource_processtype").find('option:selected').val();
        if ((bookname == '' || bookname == undefined || bookname == ' ' || bookname.length == 0) || (round == '' || round == undefined || round == ' ' || round.length == 0) || (process == '' || process == undefined || process == ' ' || process.length == 0)) {
            $.notify("All fields are required", "error");
            return false;
        }

        var inp = {'jodId': bookname, 'bookId': $("#viewsource_bookidselect").find(":selected").data('bookid'), 'roundId': round, 'processId': process};
        var deferred = $q.defer();
        $http.post(BASE_URL + "viewretrieveChapterList", inp).then(function mySuccess(response)
        {
            if (response.data.result == 400)
            {
                showNotify(response.data.errMsg, 'danger');
                return false;
            }
            if (response.data.result == 401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation, function (key, val)
                    {
                        $.each(val, function (key, errval)
                        {
                            $.notify(errval, 'error');
                        });
                    });
                }
                showNotify(response.data.errMsg, 'danger');
                hideLoader();
            }

            $scope.chapterdata = response.data.chapterdata;
            deferred.resolve(response);
        },
                function myError(response)
                {
                    deferred.reject(response);
                });
        return deferred.promise;
    };

    //retrieve versions
    $scope.getretrieve = function ()
    {
        $scope.alfrescodata = [];
        if ($scope.chaptername == undefined || $scope.chaptername == '') {
            return false;
        }

        showLoader('Please wait while Submit ...');
        var inp = {
            alfrescoId: $scope.chaptername
        };

        var deferred = $q.defer();
        $http.post(API_URL + "alfrescoRetrieveVersions", inp).then(function mySuccess(response)
        {

            hideLoader();
            if (response.data.result == 404)
            {
                showNotify(response.data.errMsg, 'danger');
                return false;
            }
            if (response.data.result == 401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation, function (key, val)
                    {
                        $.each(val, function (key, errval)
                        {
                            $.notify(errval, 'error');
                        });
                    });
                }
                showNotify(response.data.errMsg, 'danger');
            }
            if (response.data.result == 200) {
                $scope.alfrescodata = response.data.data;
                $scope.alfrescoConsId = response.data.alfrescoId;
//                    $("#show-alfresco").trigger('click');
            }
            deferred.resolve(response);
        },
                function myError(response)
                {
                    hideLoader();
                    deferred.reject(response);
                });

        return deferred.promise;
    }

    //download versions
    $scope.downloadretrieve = function (item, ID)
    {
        showLoader('Please wait while Submit ...');
        var inp = {
            alfrescoId: ID,
            objectId: item.ObjectId
        };

        var deferred = $q.defer();
        $http.post(API_URL + "alfrescoDownloadVersions", inp).then(function mySuccess(response)
        {
            if (response.data.result == 404)
            {
                hideLoader();
                showNotify(response.data.errMsg, 'danger');
                return false;
            }
            if (response.data.result == 401)
            {
                hideLoader();
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation, function (key, val)
                    {
                        $.each(val, function (key, errval)
                        {
                            $.notify(errval, 'error');
                        });
                    });
                }
                showNotify(response.data.errMsg, 'danger');
            }
            if (response.data.result == 200) {
                var attempt = 1;
                var filehandlerid = response.data.rmID;
                $scope.checkfilestatusopenornot(attempt, filehandlerid);
            }
            deferred.resolve(response);
        },
                function myError(response)
                {
                    hideLoader();
                    deferred.reject(response);
                });

        return deferred.promise;
    }

    //show client ack remarks commands
    $scope.showAlfrescoerror = function (data) {
        var printMsg = (data.REMARKS == null || data.REMARKS == "") ? 'Remarks not found..' : data.REMARKS;
        $scope.Msgbox = "Alfresco Error Log Files";
        $('#trigger-alfresco').trigger('click');
        $('#redofailed').html('<p class="text-center">' + printMsg + '</p>');
    };

    $scope.checkfilestatusopenornot = function (attempt, filehandlerid)
    {
        var inp = {rmiID: filehandlerid,
            typeofstatus: 'Opendrive'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                attempt++;
                if (attempt <= 5) {
                    $timeout(function () {
                        $scope.checkfilestatusopenornot(attempt, filehandlerid);
                    }, 2000);
                } else {
                    hideLoader();
                    showNotify("File handler is not running. Please check..", 'danger');
                }
            }
            if (response.data.result == 404)
            {
                hideLoader();
                showNotify("File handler is not running. Please check....", 'danger');
            }
            if (response.data.result == 200)
            {
                hideLoader();
                showNotify(response.data.errMsg, 'success');
            }
        },
                function myError(response)
                {
                    hideLoader();
                });
    };


    $scope.clearfile = function ()
    {
        var apssourceFile = document.getElementById("apsSource").value = '';
    }
});
    