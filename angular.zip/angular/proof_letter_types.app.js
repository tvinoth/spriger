/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout,$location, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    $scope.userId 	=   '0';	
    $scope.menuParent 	=   'Customization';
    $scope.menuChild 	=   'Proof Letter Setup';
    $scope.errorMsg 	=   "";
    $scope.stgaelist    =   [];
    $scope.roundlist    =   [];
    $scope.editeditem   =   {};
    if(isNaN(getUrlParameter(1))) 
    {
        $scope.JobID 	=   "";
    } 
    else 
    {
        $scope.JobID 	=   getUrlParameter(1);
    }
	
    $scope.addnewstage  =   function()
    {
        if( $scope.subject   ==   undefined || $scope.emailbody   ==   undefined) 
        {
            $scope.adderrorMsg  =   'all fields are required';
            showNotify($scope.adderrorMsg  , 'danger' );
            return false;
        }
        showLoader('Please wait while add new setup...'); 
        var inp     =   {   
                        emailsubject    :   $scope.subject,
                        emailbody       :   $scope.emailbody,
                        existId         :   '',
                        Typeofrequest   :   'insert'
                    };
            $http.post(BASE_URL+'doAddnewproofsetup',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {   
                hideLoader();
                $scope.emailbody    =   undefined;
                $scope.subject      =   undefined;
                $scope.getemailStageList();
                showNotify(response.data.errMsg, 'success' );
            } 
            else
            {
                hideLoader();
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            hideLoader();
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    $scope.resetForm    =   function()
    {
        $scope.emailbody    =   undefined;
        $scope.subject      =   undefined;
    }
	
    $scope.currentuserid    =   '';
    
    $scope.openchapterlistdetails   =   function(book)
    {
        $window.location.href       = 	BASE_URL+"remainderchapterlist/"+book.JOB_ID;
    }
    
    $scope.getemailStageList	= 	function() 
    {
        $scope.emaillist    = 	[];
        $http.get(BASE_URL+"dogetproofletterlist").then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
            }
            $scope.emaillist        = 	response.data.emaillist;
            $scope.userId           =   response.data.userId;
        }, 
        function myError(response) {
                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
        });			
    };
    
    $scope.emaillistselected        =   {};    
    $scope.getTemplate  =   function (contact) {
        if (contact.ID === $scope.emaillistselected.ID) return 'edit';
        else return 'display';
    };

    $scope.editStage    =   function (contact) {
        $scope.emaillistselected    =   angular.copy(contact);
    };
    
    $scope.showSuccessredologview   =   function(item){
        var inp     =   {   
                            emailstageid:   item
                        };
        $http.post(BASE_URL+'viewemailproofsetupcontent',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Proof Letter Setup";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    $scope.showplaceholder  =   function()
    {
        var placeholdercontent     =   "[bookid] , [to_name] ,[contact_personname], [chapter_no], [stage_name] ,[round_name], [am_name],[pm_name]";
        $('#show-redo').trigger('click');
        $scope.Msgbox 	=	"Email Setup Placeholder View";
        $('#redofailed').html('<p class="text-left">'+placeholdercontent+'</p>');   
    }
    $scope.undostage    =   function () {
        $scope.emaillistselected    =   {};
    };
            
    $scope.updateexiststage     =   function(position,item)
    {
        var getsubjectvalue     =   $("#emailsubject_"+position).val();
        var getemailcontent     =   $("#emailbodycontent_"+position).val();
        var updateexistidval    =   item.ID;
        if((getsubjectvalue     ==   undefined || getsubjectvalue     ==  '') || (getemailcontent       ==   undefined || getemailcontent     ==  '')) 
        {
            $scope.adderrorMsg  =   'all fields are required';
            showNotify($scope.adderrorMsg  , 'danger' );
            return false;
        }
        showLoader('Please wait while add new setup...'); 
        var inp     =   {   
                        emailsubject    :   getsubjectvalue,
                        emailbody       :   getemailcontent,
                        existId         :   updateexistidval,
                        Typeofrequest   :   'update'
                    };
            $http.post(BASE_URL+'doAddnewproofsetup',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {   
                hideLoader();
                $scope.undostage();
                $scope.emaillist[position]   =   response.data.validation;
                showNotify(response.data.errMsg, 'success' );
            } 
            else
            {
                hideLoader();
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            hideLoader();
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    $scope.removestage  =   function(position,item)
    {
        bootbox.confirm("Are you sure to delete on this ?", function( result ) {
            if(result){
                var inp     =   {   
                                emailstageid:   item
                            };
                $http.post(BASE_URL+'proofletterdelete',inp).then(function mySuccess(response) {
                    if(response.data.status == 1) 
                    {   
                        $scope.emaillist.splice(position, 1); 
                        showNotify(response.data.errMsg, 'success' );
                    } 
                    else
                    {
                        showNotify(response.data.errMsg, 'danger' );
                    }
                },function myError(response) {
                    showNotify(response.data.errMsg,'danger' );
                });
            }
        });
    }
    $scope.getemailStageList();   
});