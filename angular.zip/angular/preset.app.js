/*
 *  Preset Master Controller
 *  This controller contains all the methods related to customization > Preset screen.
 */
ngApp.controller('ngController', function ($scope, $http,DTOptionsBuilder, DTColumnBuilder) {
	$scope.userId = 0;	
	$scope.UserDetails = {};
	
 	$scope.menuParent = 'Customization';
	$scope.menuChild = 'Preset';
	
	$scope.preset = "";
	$scope.errorMsg = "";
	$scope.presetId = 0;

	/*
	 *  Get Preset List
	 *  This method get all the active preset from DB
	 */
	$scope.showPresetList = function() {
            $scope.presetList = [];
            var inp = {	roundId : 0, opt : 'All'};
            $http.post(API_URL+"getPresetMasterDetail", inp) .then(function mySuccess(response) {
                $scope.presetList = response.data.preset;	
            }, 
            function myError(response) {
                console.log(response);
            });			
	};
        $scope.showPresetList();
	/*
	 *  Get Preset Details
	 *	Preset Id is the input.
	 *  This method get the Preset details for the given Preset id.
	 */
	$scope.showPresetDetails = function(pr) {
		var roles = '', title = 'Preset Details', content = '';	
				
		content += '<table class="table table-bordered">'+
					'<tr><th>Preset Name </th><td>'+pr.Preset_name+'</td></tr>'+
					'<tr><th>Preset Type </th><td>'+pr.typeDisplay +'</td></tr>'+
					'</table>';
		showInfo(title, content);
			
	};	
	/*
	 *  Add Preset
	 *  This method used to add new Preset details
	 */
	$scope.addPreset = function() {
		$scope.clearPreset();
		$("#show-edit").click();		
	};
	/*
	 *  Clear Preset Details
	 *  This method used to clear Preset details 
	 */
	$scope.clearPreset = function() {
		$scope.presetName = "";
		$scope.presetType = "";
		$scope.presetId =0;
		$scope.errorMsg = "";
		$("#edit-close").click();	
	};
	/*
	 *  Edit Preset Details
	 *  This method used to edit existing Preset details
	 */
	$scope.editPreset = function(pr) {
		console.log(pr);
		$("#show-edit").click();	
		$scope.presetType = pr.type.toString();
		$scope.presetName = pr.Preset_name;
		$scope.presetId = pr.Preset_id;
	};
	/*
	 *  Save Preset
	 *  This method used to save Preset details
	 */
	$scope.savePreset = function() {
		if($scope.presetName == "") {
			 $scope.errorMsg = "Please enter preset name.";
		} else {
			var inp = {	userId: '', presetId : $scope.presetId, presetName: $scope.presetName, presetType:$scope.presetType};
			
			console.log(inp);
			$http.post(API_URL+"savePreset", inp) .then(function mySuccess(response) {
				if(response.data[0].flag) {
					$scope.errorMsg = response.data[0].msg;
				} else {
					showMessage('Preset', response.data[0].msg, 'success');
					$scope.clearPreset();
					$scope.showPresetList();	
				}
				 console.log(response);
			}, 
			function myError(response) {
				 console.log(response);
			});		
		}			
	};
	/*
	 *  Delete Preset
	 *  This method deletes the given Preset information.
	 */
	$scope.deletePreset = function(presetId) {
		bootbox.confirm("Are you sure you want to delete?", function(result) {
			if(result) {				
				var inp = {	presetId: presetId
							};
				$http.post(API_URL+"deletePreset", inp) .then(function mySuccess(response) {
					var res = response.data;					
					showMessage('Preset', 'Preset successfully deleted.', 'success');
					$scope.showPresetList();
				}, 
				function myError(response) {
					// console.log(response);
				});
				
			}
		});	
	};
});