/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */

ngApp.controller('ngController', function ( $scope, $http ,$q, $window ,  $timeout ,$rootScope,$filter,$compile, $interval, DTOptionsBuilder, DTColumnBuilder ) {
    $scope.projectList  =   [];
    $scope.Checkout     =   false;
    $scope.showProject  =   false;
    $scope.menuParent   =   'Pre-Production';
    $scope.menuChild    =   'ArtProcess';
    
    $scope.downloadButtonDisabled     =   false;      
    $scope.downloadButtonText     =   "Download Raw Files";
    
    $scope.openFolderButtonText   =   "Open Folder";
    
    $scope.checkinButtonDisabled     =   true;      
    $scope.checkinButtonText     =   "Check-in";
    
    $scope.submitButtonDisabled     =   true;      
    $scope.submitButtonText     =   "Submit";
    
    $scope.savechapterdisabled  =   false;
    $scope.noOfAttemptsToCheckIndesign  =   10;
    $scope.artProcesscomplete    =   true;
   
    $scope.chapterList      =   [];    
    $scope.artCheckout  =       function( chapterObj ){
        
        var chapterInfo     =       chapterObj;
      
        //bootbox.confirm("Are you sure to proceed with this ?", function(result) {
            
            if( true ){ 
        
                var inp     =      {
                    user_id     :   '' ,
                    meta_id     :   chapterInfo.METADATA_ID , 
                    job_id      :   chapterInfo.JOB_ID,
                    meta_round     :   chapterInfo.metaRound
                };
                $scope.getjobId     =   chapterInfo.JOB_ID;
                var bt_ele_id   =   '#artCheckout_'+chapterInfo.METADATA_ID;
                var checkxout_btn_ele   =   document.querySelector( bt_ele_id );
                angular.element(checkxout_btn_ele).addClass('disabled');
        
               $http.post( BASE_URL +"startArtPreProduction"  , inp ).then(                
                    function mySuccess( response ){
                       var resObj  =   response.data;
                      
                       if( resObj.status   ==  1 ){
                            var roundid     =   (chapterInfo.CURRENT_ROUND== null?chapterInfo.metaRound:chapterInfo.CURRENT_ROUND);    
                            if( resObj.params.token_key != null ){    
                               window.location.href        =       BASE_URL+"artCheckout/"+chapterInfo.METADATA_ID+"/"+roundid+"/"+resObj.params.token_key;                                        
                            }else{                                
                               window.location.href        =       BASE_URL+"getChapterInfo/"+chapterInfo.JOB_ID;                                  
                            }
                            
                        }else{                            
                                showInfo( resObj.msg , resObj.errMsg );
                                angular.element(checkxout_btn_ele).removeClass('disabled');
                                
                        }    
                    },function myError( response ){
                        
                    
                });
                
            }
            
        //});
    }
    
    $scope.noArt  = function(chapterObj){
        
        var chapterInfo     =       chapterObj;
    
        bootbox.confirm("No art file(s) for this Chapter, Are you sure you want to proceed?", function(result){
            if(result){
                showLoader('Process is inprogress...');
                var inp     =      {
                                        user_id     :   '',
                                        meta_id     :   chapterInfo.METADATA_ID , 
                                        job_id      :   chapterInfo.JOB_ID,
                                        meta_round  :   chapterInfo.metaRound
                                    }; 
                $http.post( BASE_URL+"addNoArt" , inp ) .then(function mySuccess(response){ 
                    hideLoader();
                    if(response.data.status == 'success' ){
                        $scope.savechapterdisabled     =   true;
                        showNotify(response.data.artMsg, 'success' );
                        //$scope.getChaptersOfBookByJobid(response.data.job_id);
                        $timeout( function(){ window.location.href    =    BASE_URL+'getChapterInfo/'+response.data.job_id; }, 2000 );               
                    }
                    if(response.data.status == 'failed' ){
                        showNotify(response.data.artMsg, 'danger' );
                    }
                    if( response.data.status == 404){
                        $scope.heightofmodal        =   600;
                        $scope.showallresponse      =   response.data.msg;
                        $scope.existchapterlist     =   response.data.shownotavaiablechapter;
                    }

                },function myError(response) {
                    $scope.spitcomplete =   true;
                    $scope.submitButtonDisabled     =   false;
                    $scope.savechapterdisabled  =   false;
                    showLoader( 'Oops! Try again after sometimes.' );
                });
                }
            });
    }
    
    $scope.insertArtitem     =   function(srcFolder){
        var     allatrchapteritems  =   $(".artchapteritems").find("tr").length;
        var     checkfigureitemsavailableornot      =   $("table").hasClass("artchapteritems");
        if(allatrchapteritems    ==  1 && checkfigureitemsavailableornot    ==  true)
        {
            bootbox.confirm("No art file(s) found for this Chapter, Are you sure you want to proceed?", function(result){
            if(result){
                showLoader('Please wait while adding Chapters...');
                var meta            =   $('input[name="metaid"]').val();
                var artName         =   $('input[name="chapters[]"]').map(function(){return $(this).val();}).get();
                var files           =   $('select[name="file[]"]').map(function(){return $(this).val();}).get();
                var type            =   $('select[name="type[]"]').map(function(){return $(this).val();}).get();
                var complexity      =   $('select[name="complexity[]"]').map(function(){return $(this).val();}).get();
                var mode            =   $('select[name="mode[]"]').map(function(){return $(this).val();}).get();
                var workinvolved    =   $('select[name="workinvolved[]"]').map(function(){return $(this).val();}).get();
                var inputcolor      =   $('select[name="inputcolor[]"]').map(function(){return $(this).val();}).get();
                var outputcolor     =   $('select[name="outputcolor[]"]').map(function(){return $(this).val();}).get();
                var remarks         =   $('input[name="remarks[]"]').map(function(){return $(this).val();}).get();
                var chaptername     =   $('input[name="chaptername"]').val();

                var inp    =    {
                                    artName     :   artName ,
                                    files       :   files , 
                                    type        :   type , 
                                    complexity  :   complexity , 
                                    mode        :   mode , 
                                    workinvolved:   workinvolved , 
                                    inputcolor  :   inputcolor ,
                                    outputcolor :   outputcolor ,
                                    metaid      :   meta,
                                    remarks     :   remarks,
                                    chaptername : chaptername
                                }; 
                $http.post( BASE_URL+"addArtInfo" , inp ) .then(function mySuccess(response){ 
                    hideLoader();
                    if(response.data.status == 'success' ){
                        $scope.savechapterdisabled     =   true;
                        showNotify(response.data.artMsg, 'success' );
                        $timeout( function(){ window.location.href    =    BASE_URL+'getChapterInfo/'+response.data.jobId; }, 2000 );               
                    }
                    if(response.data.status == 'failed' ){
                        showNotify(response.data.artMsg, 'danger' );
                    }
                    if( response.data.result == 404){
                        $scope.heightofmodal        =   600;
                        $scope.showallresponse      =   response.data.msg;
                        $scope.existchapterlist     =   response.data.shownotavaiablechapter;
                    }

                },function myError(response) {
                    $scope.spitcomplete =   true;
                    $scope.submitButtonDisabled     =   false;
                    $scope.savechapterdisabled  =   false;
                    showLoader( 'Oops! Try again after sometimes.' );
                });
                }
            });
        }
        else
        {
			
            showLoader('Please wait while adding Chapters...');
            var meta            =   $('input[name="metaid"]').val();
            var artName         =   $('input[name="chapters[]"]').map(function(){return $(this).val();}).get();
            var files           =   $('select[name="file[]"]').map(function(){return $(this).val();}).get();
            var type            =   $('select[name="type[]"]').map(function(){return $(this).val();}).get();
            var complexity      =   $('select[name="complexity[]"]').map(function(){return $(this).val();}).get();
            var mode            =   $('select[name="mode[]"]').map(function(){return $(this).val();}).get();
            var workinvolved    =   $('select[name="workinvolved[]"]').map(function(){return $(this).val();}).get();
            var inputcolor      =   $('select[name="inputcolor[]"]').map(function(){return $(this).val();}).get();
            var outputcolor     =   $('select[name="outputcolor[]"]').map(function(){return $(this).val();}).get();
            var remarks         =   $('input[name="remarks[]"]').map(function(){return $(this).val();}).get();
            var chaptername     =   $('input[name="chaptername"]').val();

            var inp    =    {
                                artName     :   artName ,
                                files       :   files , 
                                type        :   type , 
                                complexity  :   complexity , 
                                mode        :   mode , 
                                workinvolved:   workinvolved , 
                                inputcolor  :   inputcolor ,
                                outputcolor :   outputcolor ,
                                metaid      :   meta,
                                remarks     :   remarks,
                                chaptername : chaptername
                            }; 
            $http.post( BASE_URL+"addArtInfo" , inp ) .then(function mySuccess(response){
                
                hideLoader();
                if(response.data.status == 'success' ){
                    $scope.closeFolder(srcFolder);/* userwork folder close */
                    $timeout( function(){ }, 2000 );
                    $scope.savechapterdisabled     =   true;
                    showNotify(response.data.artMsg, 'success' );
                    $timeout( function(){ window.location.href    =    BASE_URL+'getChapterInfo/'+response.data.jobId; }, 2000 );               
                }
                if(response.data.status == 'failed' ){
                    showNotify(response.data.artMsg, 'danger' );
                }
                if( response.data.result == 404){
                    $scope.heightofmodal        =   600;
                    $scope.showallresponse      =   response.data.msg;
                    $scope.existchapterlist     =   response.data.shownotavaiablechapter;
                }

            },function myError(response) {
                $scope.spitcomplete =   true;
                $scope.submitButtonDisabled     =   false;
                $scope.savechapterdisabled  =   false;
                showLoader( 'Oops! Try again after sometimes.' );
            });
        }
    }
    
    $scope.jobandcucview    =   '';
    $scope.viewjobSheet     =   function(jobid,stage,chapterId) 
    {     
        var inp             =   {
                                    jobId       :   jobid,
                                    stagename   :   stage,
                                    chapterId   :   chapterId
                                };
//            e.target.name
        $scope.jobandcucview    =  stage + " Jobsheet View";
        $('#show-cucview').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        $http({
                url         :   BASE_URL + "consolidate_jobsheetview",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if(response.xmlcount >= 1)
            {
                $scope.heightofmodal        =   700;
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $scope.heightofmodal        =   100;
                $('#xmlContent').html(response.errMsg);
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
        
    $scope.noartinsertArtitem     =   function(srcFolder){
			
        showLoader('Please wait while adding Chapters...');
        var meta            =   $('input[name="metaid"]').val();
        var artName         =   $('input[name="chapters[]"]').map(function(){return $(this).val();}).get();
        var files           =   $('select[name="file[]"]').map(function(){return $(this).val();}).get();
        var type            =   $('select[name="type[]"]').map(function(){return $(this).val();}).get();
        var complexity      =   $('select[name="complexity[]"]').map(function(){return $(this).val();}).get();
        var mode            =   $('select[name="mode[]"]').map(function(){return $(this).val();}).get();
        var workinvolved    =   $('select[name="workinvolved[]"]').map(function(){return $(this).val();}).get();
        var inputcolor      =   $('select[name="inputcolor[]"]').map(function(){return $(this).val();}).get();
        var outputcolor     =   $('select[name="outputcolor[]"]').map(function(){return $(this).val();}).get();
        var remarks         =   $('input[name="remarks[]"]').map(function(){return $(this).val();}).get();
        var chaptername     =   $('input[name="chaptername"]').val();

        var inp    =    {
                            artName     :   artName ,
                            files       :   files , 
                            type        :   type , 
                            complexity  :   complexity , 
                            mode        :   mode , 
                            workinvolved:   workinvolved , 
                            inputcolor  :   inputcolor ,
                            outputcolor :   outputcolor ,
                            metaid      :   meta,
                            remarks     :   remarks,
                            chaptername : chaptername
                        }; 
        $http.post( BASE_URL+"addArtInfo" , inp ) .then(function mySuccess(response){
            hideLoader();
            if(response.data.status == 'success' ){
                $scope.closeFolder(srcFolder);/* userwork folder close */
                $timeout( function(){ }, 2000 );
                showNotify(response.data.artMsg, 'success' );
                $timeout( function(){ window.location.href    =    BASE_URL+'getChapterInfo/'+response.data.jobId; }, 4000 );               
            }
            if(response.data.status == 'failed' ){
                showNotify(response.data.artMsg, 'danger' );
            }
            if( response.data.result == 404){
                $scope.heightofmodal        =   600;
                $scope.showallresponse      =   response.data.msg;
                $scope.existchapterlist     =   response.data.shownotavaiablechapter;
            }

        },function myError(response) {
            $scope.spitcomplete =   true;
            $scope.submitButtonDisabled     =   false;
            $scope.savechapterdisabled  =   false;
            showLoader( 'Oops! Try again after sometimes.' );
        });
    }
    
        //delete popup chapter list
    $scope.deleteArtItem    =   function(index){
        bootbox.confirm("Are you sure you want to delete?", function(result){
            if(result){
                var deleterow       =   document.getElementById("chapter_"+index);
                $(deleterow).remove();
//                var removeindex     =   $scope.chapterlist.indexOf(index);
//                $scope.chapterlist.splice(removeindex, 1);   
            }
        });	
    }
   
    /*
     *  Check RMI Status
    *  This method check the RMI status for the selected folios.
    */
   
    $scope.getChaptersOfBookByJobid =   function( jobid ){
        
        var inp  =   {
            jobid  :   jobid            
        };
       
        $http.post( BASE_URL +"getChapterList"  , inp ).then(                
                function mySuccess( response ){
                    $scope.chapterList      =      response.data.data;
                    $scope.vm               =   {};
                    $scope.vm.dtOptions     =   DTOptionsBuilder.newOptions().withOption( 'order' , [ 0 ,'asc' ]);
                },
                function myError( response ){
        }); 
        
                
    }
    
    
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showNotify('Font Downloaded successfully.'  , 'success' );
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showNotify('Page(s) checked out successfully.'  , 'success' );
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    showNotify('Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showNotify(response.data[0].remarks  , 'danger' );
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
                showNotify("File handler is not running. Please check."  , 'danger' );
            }
	}
	},
        function myError(response) {
            
                showLoader( 'Oops! Try again after sometimes.' );
                    
	});		
        
    };    
    
    /*
     *  Drive Open
     *  
     */
    
    $scope.openDrive = function( path , opt ) {
         
       // bootbox.confirm("Are you sure to open this book working directive ?", function(result) {
        var result   =   true;
        $scope.openButtonDisabled   =   true;
            if( result ){
                
                $scope.openFolderButtonText     =   "In Progress";
                var method = "";
                
                //showLoader('Please wait while opening...');
                
                method = "doOpenDriveServer";

                var inp = {

                           filePath : path ,
                           methodName : method  ,
                           processname  :   'checkout'
                           
                };

                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                    if(response.data[0].rmiId > 0) {
                        
                        var attempt = 5;
                        $scope.checkFhStatus(response.data[0].rmiId, attempt, opt);
                        
                        
                    } else {
                       // hideLoader();
                        showNotify( 'Having problem in insert data.', 'danger');
                    }
                    
                    
                },function myError(response) {
                        showLoader( 'Oops! Try again after sometimes.' );
                });
                
                $timeout(function () {
                    $scope.openButtonDisabled   =   false;
                    $scope.openFolderButtonText     =   "Open Folder";
                    $scope.submitButtonDisabled     =   false;      
                    $scope.checkinButtonDisabled     =   false;      
                }, 2000); 
                    
            }
       // });    
        
    };
    
    /*
     *  Checkin
     *  
     */
    /*
     *  Checkin with close userwork folder
    */
	// close user work folder function starts here
	$scope.closeFolder = function( srcFolder ) {
		 method = "closeFolderServer";
                var inp = {
                           filePath : srcFolder ,
                           methodName : method  
                };
                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {
                  return true;
                },function myError(response) {
                    showNotify( response.data  , 'danger' );                    
                });
	}
	// close user work folder function ends here
    $scope.artCheckin =   function( jobId,meta_id ,  method , src , dest , ext , del, srcFolder  ){
       $scope.closeFolder(srcFolder);/* userwork folder close */
       // bootbox.confirm("Are you sure to proceed with this ?", function(result) {
           var result   =   true;
            if( result ){
                
                 $scope.checkinButtonText     =   "In Progress";
                 showLoader('Please wait while copying files...');
                 
                 var inp = {
                    method_name    :  method , 
                    src_path  :   src,
                    dest_path :   dest,
                    ext       :   ext ,
                    isdelete  :   del ,
                    meta_id   :    meta_id
                };
                
                $http.post( API_URL+"artCheckin" , inp ) .then(function mySuccess(response) {
                    
                    hideLoader();
                    
                    if( response.data.status ){
                        $scope.$emit('eventBroadcastedName',response.data.errMsg);
                        window.location.href    =    BASE_URL+'getChapterInfo/'+jobId;
                         
                    }else{
                       // showLoader( response.data.errMsg );
                    }
                    
		}, 
		function myError(response) {
                   // showLoader( 'Oops! Try again after sometimes.' );
		});
                
                $timeout(function () {
                    $scope.checkinButtonText     =   "Check-in";
                    $scope.checkinButtonDisabled = true;
                }, 2000); 
                
            }
            
        //});
       
    }
    
    $scope.$on('eventBroadcastedName', function(event, data) 
    {
        showNotify( data, 'success');
    });
    $scope.artcomplete    =   true;
    $scope.jobId           =   "";
    $scope.bookidshow      =   "";
    var uploaded    =   false;
    $scope.filetype         =   filetype;
    $scope.fileextension    =   fileextension;
    $scope.complexity       =   complexity;
    $scope.modetype         =   modetype;
    $scope.workinvolved     =   workinvolved;
    $scope.colours          =   colours;
    
    $scope.artComplete   =   function( job_id , meta_id ,  method , src , dest , ext , del)
    {
        $scope.chapterlist          =   [];
        $scope.partlist             =   [];
        $scope.existchapterlist     =   '';
        $scope.showallresponse      =   '';
        $scope.submitButtonDisabled =   true;
        $scope.submitButtonText     =   "In Progress";

        var inp = {
           method_name    :  method , 
           src_path  :   src,
           dest_path :   dest,
           ext       :   ext ,
           isdelete  :   del ,
           job_id    :   job_id , 
           meta_id      : meta_id
        };
           
        var resultofartfigure    =   $scope.artFigureDetails(inp);
       
        resultofartfigure.then(function(rest) 
        {
            var artCompletecall      =   $scope.artCompletecall(job_id , meta_id ,  method , src , dest , ext , del );
        })
        .catch(function(fallback) {
    
        }); 
     }
     
    $scope.artCompletecall   =   function( job_id , meta_id ,  method , src , dest , ext , del  )
    {
        $scope.chapterlist          =   [];
        $scope.partlist             =   [];
        $scope.existchapterlist     =   '';
        $scope.showallresponse      =   '';
        $scope.submitButtonDisabled =   true;
        $scope.submitButtonText     =   "In Progress";

            var inp = {
               method_name    :  method , 
               src_path  :   src,
               dest_path :   dest,
               ext       :   ext ,
               isdelete  :   del ,
               job_id    :   job_id , 
               meta_id      : meta_id
           };
           
        var deferred    =   $q.defer();
        if( !uploaded )
            showLoader('Please wait while copying files...' );
        
        var jobid       =   job_id;
        
        $http.post( API_URL+"artCompleted" , inp ).then(function mySuccess(response) {
            $scope.submitButtonDisabled     =   false;
            $scope.bookidshow       =   response.data.Book_id;
            $scope.chaptershow      =   response.data.chaptername;
            $scope.chapterlist      =   response.data.art;
            uploaded    =   true;
            if( response.data.status == 1 ){
               
                var keys        =   Object.keys(response.data.art);
                var totalart    =   keys.length;
                if(response.data.art.length >= 1)
                {
                    angular.element('#show-doopenfiles').trigger('click');
                    $scope.heightofmodal        =   600;
                    $scope.saveChapterbutton    =   true;
                }
                else
                {
                    hideLoader(); 
                   // showNotify( 'No art file(s) found for this Chapter... '  , 'danger' );
                    bootbox.confirm("No art file(s) found for this Chapter, Are you sure you want to proceed?", function(result){
                        if(result){
                            showLoader('Please wait while submiting files...' );
                            $scope.submitButtonDisabled     =   true;
                             $("table").removeClass("artchapteritems");
							var srcFolder = $("#doCloseFolder").val();
                            $scope.noartinsertArtitem(srcFolder);
                            angular.element('#chapterinfo').trigger('click');
                            $scope.saveChapterbutton    =   false;
                        }
                    });
                }
            }
            if( response.data.status == 0){
                $scope.artcomplete =   true;
                showNotify( response.data.errMsg  , 'danger' );
            }   
            deferred.resolve(response);
                 hideLoader();   
        }, function myError(response) {
            hideLoader();   
                        $scope.artcomplete =   true;
                        showNotify( 'Oops! Try again after sometimes.' , 'danger' );
                        deferred.reject(response);
		});
                $timeout(function () {
                    $scope.submitButtonText     =   "Submit";
                }, 2000); 
            return deferred.promise;
     }
       
    $scope.artInputFileDownload =   function( job_id, meta_id , method , src , dest , ext , del ){
    
           showLoader('Please wait while copying files...');
           var result = true;
           
            if( result ){
                
                $scope.downloadButtonText     =   "Download In Progress";
                var q_string =   ( (location.pathname+location.search).substr(1) );
                var obj      =   q_string.split( '/' );
                var tokenkey        =   obj[obj.length - 1];
                
                var inp = {
                    method_name    :  method , 
                    src_path  :   src,
                    dest_path :   dest,
                    ext : ext ,
                    isdelete  : del ,
                    job_id : job_id , 
                    meta_id      : meta_id , 
                    tokenkey    :   tokenkey
                };
                
                $http.post( API_URL+"artInputFileDownload" , inp ) .then(function mySuccess(response) {
                
                    if(response.data.status == "success") {
			hideLoader();
                        
                    } else {
                        
                        hideLoader();
			showNotify( response.data[0]['errMsg'] , 'danger' );
                        
                        return false;
                    }
                   
                    $timeout(function () {

                        $scope.downloadButtonDisabled     =   true;

                        $scope.downloadButtonText     =   "Download Completed";

                        angular.element('#openFolderBtn').trigger('click');
                        
                        hideLoader();
                     
                    }, 3000); 
                    
                    
                    
		}, 
		function myError(response) {
                    
                    showLoader( 'Oops! Try again after sometimes.' );
                    
                    
		});
                
                 
                    
            }
            
    
       
    }
    
    $scope.artFigureDetails =   function( param1 )
    {
        $scope.artmeatachapterlist  =   [];
        $scope.artmeatadatarror     =   "";
        var deferred    =   $q.defer();
        $http.post( API_URL+"generateMetaxml" , param1 ) .then(function mySuccess(response) {

            if(response.data.Status == "1") {
                deferred.resolve(response);
            }
            if(response.data.Status == 0) {
                $scope.submitButtonDisabled =   false;
                $scope.submitButtonText     =   "Submit";
                hideLoader();
                deferred.reject(response);
                showNotify( response.data.Msg , 'danger' );
            } 
            if( response.data.Status == 404){
                angular.element('#show-doartmetafiles').trigger('click');
                $scope.submitButtonDisabled =   false;
                $scope.submitButtonText     =   "Submit";
                $scope.bookidshow           =   response.data.Book_id;
                $scope.chaptershow          =   response.data.chaptername;
                hideLoader();
                $scope.artmeatadatarror     =   response.data.Msg;
                $scope.artmeatachapterlist  =   response.data.artmeataimage;
            }
        }, 
        function myError(response) {
            $scope.submitButtonDisabled =   false;
            $scope.submitButtonText     =   "Submit";
            deferred.reject(response);
            showLoader( 'Oops! Try again after sometimes.' );
        });
        return deferred.promise;
    }
    
    
    var q_string =   ( (location.pathname+location.search).substr(1) );
    var obj      =   q_string.split( '/' );
    $scope.getChaptersOfBookByJobid(angular.element("#currentjob").val());       
    
    $scope.qmsspike                 =       function(jobId, userId, bookId,type)
    {
        if(type     ==  'qms')
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
            $('#iframeqms').attr('src',$scope.srciframepath);
        }
        else
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
            $('#iframespike').attr('src',$scope.srciframepath);
        }
    };
    
     $timeout(function () {
        angular.element('#downloadButton').trigger('click');
        var isDownloaded    =       $("input[name='isTokenDownloaded']").val();
        if( isDownloaded == 2 ){
            $scope.checkinButtonDisabled    =       false;
            $scope.submitButtonDisabled     =       false;
        }
        
    }, 2000); 
    
    //showLoader('Please wait while copying files...' );
    
});