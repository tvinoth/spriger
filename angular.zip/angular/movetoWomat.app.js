/*
 *  Dashboard Controller
 *  This controller contains all the methods related to dashboard screen.
 */


ngApp.service('fileUpload', ['$http' , "$rootScope" , function ($http , $rootScope) {
    
        this.uploadFileToUrl = function( file, uploadUrl , data ){
        var fd = new FormData();
        fd.append('file', file);
        fd.append( 'data' , JSON.stringify( data ) );
        
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        })
        .success(function( response ){
            $rootScope.error        =   response;
                    //deffered.resolve(response);
        })
        .error(function( response ){
            $rootScope.error        =   response;
           //deffered.reject(response);
        });
        //return deffered.promise;
    }
}]);

ngApp.directive( 'fileModel' , ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

ngApp.controller('ngController', function ( $scope  , $http , fileUpload , $timeout , $window, DTOptionsBuilder , DTColumnBuilder ) {
	
        $scope.userId = 0;
	$scope.booksCollect     =       [];
	$scope.menuChild    =   'metaExtractorUpdate';
	$scope.menuParent   =   'Pre-Production';
	$scope.customParam  =   "";
        $scope.selected_book    =   '';
        $scope.jobsheetStatus      =       {};
        $scope.spiContactempid      =       '';
        $scope.spiContactname       =       '' ;       
        $scope.spiEmail             =       '';
        $scope.titleName            =       '';
        $scope.metaext              =       {};
        
        $scope.editor_fm_dates      =       false;
        $scope.author_caption       =       false;
        $scope.editor_caption       =       false;
        $scope.default_caption      =       true;
		$scope.metaext.node 		=	"Remarks";
        $scope.options=1;
        $scope.bookinfo =   {};
		$scope.metaext.metaid		=	'';
        
        $scope.errors       =       null;
        
        $scope.showXMLInModal_ref   =       function(){
            var jobid = $scope.metaext.jobId;
            
            if($scope.metaext.metaid == undefined || $scope.metaext.metaid == null || $scope.metaext.metaid == 0){
				var Cid   = '';
			}else{
				var Cid   = $scope.metaext.metaid;
			}
			
			    
            if( $scope.metaext.round == undefined || $scope.metaext.round == null || $scope.metaext.round == 0 ){
                $scope.showFormErrors( { 'round' : 'Required Field Validation Error!' , 'bookId' : 'Required Field Validation Error!' } );
                return false;
            }
            
            if( jobid !== undefined ){
                $scope.showXMLInModal( jobid , $scope.metaext.round, Cid );
            }else{
               $scope.showFormErrors( { 'bookId' : 'Required Field Validation Error!' } );
            }
            
        };
       
        $scope.showXMLInModal       =       function( jobId , round, Cid  ){   
        
        var inp = { jobId: jobId };
        
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	if(Cid == ''){
            urlpost     =   API_URL + "getJobXMLInfo/"+jobId+'/'+round;
        }else{
             urlpost     =   API_URL + "getJobXMLInfo/"+jobId+'/'+round+'/'+Cid;
        }
        $http({
                url: urlpost,
                method: 'GET',
             })
            .success(function(response) {
                 var size = {width: $(window).width() , height: $(window).height() };
               
                /*CALCULATE SIZE*/
                var offset = 20;
                var offsetBody = 150;
                $('#modal-preview').css('height', size.height - offset );
                $('.modal-body,#xmlContent').css('height', size.height - (offset + offsetBody));
                $('#modal-preview').css('top', 0);
                $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
                $('#xmlContent').html(response);
        
            })
            .error(function(response) {
		console.log(response);
            });
        };
       
        $scope.consalidateinfodetails   =   function(book){
            window.location.href        =   BASE_URL+"metaextractor/show/"+book.JOB_ID;
        }
        
        $scope.updateJobsheet       =       function( forms ){
            
            showLoader('Please wait update is in progress');
            $scope.errorshow    =   false;
            $http.post( BASE_URL+"movetowomatbystage" , forms ) .then(function mySuccess(response){
                hideLoader(); 
                $scope.getWrongInstructionStatus();
                if( response.data.status == 401 ){    
                    $scope.errorshow    =   true;
                    $scope.shownotavaiablechapter   =   response.data.errMsg;
                    showNotify( "All field's are required" , 'danger' );
                }
                if( response.data.status == 0 ){                                 
                    showNotify( response.data.errMsg , 'danger' );
                }
                if( response.data.status ==  1){
                    $scope.resetForm( forms );
                    showNotify( response.data.errMsg  , 'success' );
                }
                /*if(typeof response.data.REMARKS !== undefined){
                    if(response.data.REMARKS == 'Failure' || response.data.REMARKS == '' ){
                    showNotify( 'Jobsheet updation got failed '  , 'danger' );
                    
                    }else if(response.data.REMARKS == 'Success'){
                        showNotify('Jobsheet updated successfully'  , 'success' );
                        $scope.resetForm( forms );
                    }else{
                        showNotify( response.data.errMsg  , 'danger' );
                    }
                }
                else{
                    if( response.data.status ==  1){
                        showNotify( response.data.errMsg  , 'success' );
                    }else{
                        showNotify( response.data.errMsg  , 'danger' );
                    }
                }*/
                
            },function myError(response){
                hideLoader();
                showNotify('Oops , something went wrong try again after sometimes.','danger' ); 
                /*if( response.data.status == 0 ){
                    $scope.errors           =           response.data.validationerror;
                    var errors      =   $scope.errors;
                    $scope.showFormErrors( errors );                    
                    return false;
                }*/
                
            });
        };
        
        $scope.showFormErrors       =       function( errors ){
            for (var property1 in errors) {
                $( '.'+property1+'_help' ).text( errors[property1] );
                $( '.'+property1+'_help' ).parents('.form-group').addClass('has-error');
            }
        };    
        
        $scope.resetForm            =       function( formobj ){
            $scope.metaext = {};

            $('.chosen-select')
            .find('option:first-child').prop('selected', true)
            .end().trigger('chosen:updated');
            
            $('#selectNode').removeAttr('disabled');
            $('#instruction').removeAttr('disabled');
             $("#metaupdatebutton").removeAttr('disabled');
            $('#metaidselect > option').remove();
            $('.chosen-select').chosen({});  
             
        };
        
        $scope.bookidwrng   =   "";
        
        $scope.contentloadtimer             =   1;
        $scope.getWrongInstructionStatus    =   function(){
            $scope.vm                       =   {};
            $scope.vm.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
            
            var input               = 	{ jobid : $scope.bookidwrng };
            $scope.jobsheetStatus   =   null;        
            $http.post(BASE_URL+"getApiStatusOfmovetowomat",input) .then(function mySuccess(response) 
            {
                $scope.jobsheetStatus   =   response.data;
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getWrongInstructionStatus();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });	
            $scope.contentloadtimer++;
        };
    
        $scope.getWrongInstructionStatus();
        
        $(document).ready(function () {
        
            $( "input,select" ).focus(function() {
                $('.help-block').text('');
                $('.help-block').parents('.form-group').removeClass('has-error');
            });
			
			//check exist dispatched
			$scope.checkIfDispatched	=	function()
			{
				$("#metaupdatebutton").removeAttr('disabled','true');
				if($scope.metaext.process == 'WRONG_INSTRUCTION')
				{
					var bookid = $("#bookidselect_chosen").find('span').text();
					var inp 	=	{
										'bookid': bookid,
										'stageid':$scope.metaext.round,
										'purposetype':$scope.metaext.process
									}
					$http.post( API_URL+"checkIfDispatched",inp ).then(function mySuccess(response) {    
							if(response.data.result 	==	200)
							{
                                                                $("#metaupdatebutton").attr('disabled','disabled');
                                                            
								showNotify( response.data.errMsg, 'danger' );
							}
						 },function myError(response) {
							showNotify( response.data.errMsg, 'danger' );
						});  
				}
			}			
			
            $("#bookidselect").chosen().change(function() {
                var jbid    =   $(this).val();
                $("#metaupdatebutton").removeAttr('disabled','true');
                $scope.metaext     =      {};
                 $('#metaidselect')
                    .find('option:first-child').prop('selected', true)
                    .end().trigger('chosen:updated');
            
                 $('#getChaptersList')
                    .find('option:first-child').prop('selected', true)
                    .end().trigger('chosen:updated');
                $("#metaupdatebutton").removeAttr('disabled');
                if( jbid != '' ){
                    
                     $http.get( API_URL+"getBookInfoByJoid/"+jbid ).then(function mySuccess(response) {    
                        
                        var bookinfo       =       response.data.bookinfo;
                        bookinfo           =       bookinfo[0];
                        $scope.bookinfo    =       bookinfo;
                        $scope.metaext.jobId          =       jbid;
                        $scope.metaext.bookId         =       bookinfo.bookId;
						$scope.metaext.node         =       "Remarks";
                       
                     },function myError(response) {
                         
                    });   
                    
                }
                
            });
       
            $("#getChaptersList").chosen().change(function() {
                
                var roundsel    =   $(this).val();
                var jbid        =   $scope.metaext.jobId;
                var toAppend2 = '';
                var METAEXTRACTOR_WRONG       =       {  '0' : '--SELECT--' , 'WRONG_INSTRUCTION' : 'WRONG_INSTRUCTION' };
                var METAEXTRACTOR_THREE       =       {  '0' : '--SELECT--',  'NOTIFICATION' : 'NOTIFICATION_PROOF_RUN' , 'CORRECTION' : 'CORRECTION_NOTIFICATION','WRONG_INSTRUCTION' : 'WRONG_INSTRUCTION' };
                
                $('#leterrFormat > option').remove();
                $('#metaidselect > option').remove();
                $("#metaupdatebutton").removeAttr('disabled','true');
                
                var options_opt               =       METAEXTRACTOR_WRONG;
                
                //$("#metaidselect").chosen();
               // console.log(roundsel); return false;
                if( roundsel =='116' || roundsel == '118' ){
                    
                    $http.get( BASE_URL+"getChaptersByJoid/"+jbid ).then(function mySuccess(response) {                            
                        var toAppend = '<option value="">--select--</option>';
                        $.each( response.data.chapters ,function(i,o){
                            toAppend += '<option value="'+o.METADATA_ID+'">'+o.CHAPTER_NO+'</option>';
                        });
                        
                        $('#metaidselect').append(toAppend);
                        $("#metaidselect").attr('disabled', false).trigger("chosen:updated").chosen();
                        
                        toAppend2 = '';
                        options_opt =   METAEXTRACTOR_THREE;
                        $.each( options_opt ,function(i,o){
                            toAppend2 += '<option value="'+i+'">'+o+'</option>';
                        });
                        
                        $('#leterrFormat').html(toAppend2);                 
                        //$('#selectNode').attr('disabled' , 'disabled');
                       // $('#instruction').attr('disabled' , 'disabled');
                        
                    },function myError(response) {
                         
                    });   
                    
                }else{
                     
                    $('#selectNode').removeAttr('disabled');
                    $('#instruction').removeAttr('disabled');
                        
                    $.each( options_opt ,function(i,o){
                        toAppend2 += '<option value="'+i+'">'+o+'</option>';
                    });    
                    
                    $('#leterrFormat').html(toAppend2);  
                    $("#metaidselect").attr('disabled', true).trigger("chosen:updated");
                   
                }
               
            });
       
       
        });
        
        $scope.showMeataextratorremarksview = 	function(params){   

             var printMsg    =   ( params.UPDATE_REMARKS == null ) ? 'remarks not found..' : params.UPDATE_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Update";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
                
        //show meta extrator remarks commands
        
        $scope.showUploadRemarksview = 	function(params){   
             var printMsg    =   ( params.UPLOAD_REMARKS == null ) ? 'remarks not found..' : params.UPLOAD_REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Jobsheet Uploade";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	


        $scope.retryJobsheetUpdate 			= 	function(params){

           var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
           showLoader();
           showNotify( 'please wait for a while...' , 'success');
           var jobid        =   params.JOB_ID;
           var dynamic_url  =   "sendInputForReceiptJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/WRONG_INSTRUCTION';   

           $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

                if(response.data.status == 1) {      

                  $timeout( function(){  
                    hideLoader();
                    showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );


                    $timeout( function(){  
                       $window.location.reload();
                    }, 2000 );

                   }, 5000 );



                } else if( response.data.status == 0 ){
                    showNotify( response.data.errMsg , 'danger' );
                    hideLoader();
                } else {
                   showNotify( 'Request got failed..' , 'danger');
                   hideLoader();
                }

            },function myError(response) {
                console.log(response);
                $scope.retryJobsheetUpdate();
            });

        };
        
        $scope.contentloadtimer         =   1;
        $scope.retryJobsheetUpload      = 	function(params){   
            
        console.log( params );
        
        var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
        showLoader();

        showNotify( 'please wait for a while...' , 'success');
        var jobid        =   params.JOB_ID;           
        var dynamic_url  =   "sendRequestReceiptJobSheetUpload/"+jobid+'/'+params.ROUND_ID+'/WRONG_INSTRUCTION';      

        $http.get(BASE_URL+dynamic_url ) .then(function mySuccess(response) {
            hideLoader();
             if(response.data.status == 1) {                    
                console.log( response.data );
                 $timeout( function(){ 

                 if( response.data.msg == 'Success' ){                        
                     showNotify( response.data.errMsg , 'success' );
                 }
                 else{
                    showNotify( response.data.errMsg , 'danger' );
                 }
                  $timeout( function(){  
                    $window.location.reload();
                  }, 2000 );

                }, 7000 );



             } else {
                showNotify( 'Request got sending failed. Try again after sometimes..' , 'danger');
             }

         },function myError(response) {
                if($scope.contentloadtimer    <  10){
                    $scope.retryJobsheetUpload();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });
            $scope.contentloadtimer++;

        //$('#show-redo').trigger('click');
        //$scope.Msgbox 	=	"Success Redo";
        //$('#redofailed').html('<p class="text-center">please wait for a while..</p>');

        };
    

});