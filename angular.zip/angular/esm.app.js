/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */

ngApp.controller('ngController', function ($scope, $q, $rootScope, $filter, $compile, $timeout, $http, $interval, $window, DTOptionsBuilder, DTColumnBuilder)
{
    $scope.userId = '0';
    $scope.menuParent = 'Pre-Production';
    $scope.menuChild = 'Cuc';
    $scope.errorMsg = "";
    if (isNaN(getUrlParameter(1))) {
        $scope.JobID = "";
    } else {
        $scope.JobID = getUrlParameter(1);
    }
    $rootScope.isExistcheckoutesm   =   0;
    /*
     *  Get Book info
     *  This method get all the active Book info from DB
     */
    $scope.currentuserid = '';
    $scope.loadspinner = true;
    $scope.contentloadtimer = 1;
    /*$scope.getCucJobList    = 	function() 
     {
     $scope.cucjoblist   = 	[];
     $http.get(BASE_URL+"doCucjoblist") .then(function mySuccess(response) 
     {
     $scope.loadspinner      =   false;
     $scope.bodyloadspinner  =   true;
     if(response.status != 200)
     {
     showNotify( 'Kindly reload page error occured.'  , 'danger' );
     }
     $scope.cucjoblist       = 	response.data.cucjoblist;
     $scope.userId           =   response.data.userId;
     //            $('#example').dataTable();
     }, 
     function myError(response) {
     if($scope.contentloadtimer    !==  10){
     $scope.getCucJobList();
     }
     if($scope.contentloadtimer    ==  10){
     showNotify('Kindly reload page error occured.'  , 'danger' );
     return false;
     }
     });
     $scope.contentloadtimer++;
     };*/
    $scope.getCucJobList = function () {

        $scope.dtOptions = DTOptionsBuilder.newOptions()
                .withOption('ajax', {
                    //dataSrc: "data",
                    //                                        data: ,
                    url: BASE_URL + 'getall_book_info',
                    type: 'POST'
                })
                .withDataProp('data')// parameter name of list use in getLeads Fuction
                .withOption('createdRow', function (row, data, dataIndex) {
                    // Recompiling so we can bind Angular directive to the DT
                    $compile(angular.element(row).contents())($scope);
                })
                .withOption('stateSave', false)
                .withOption('processing', true) // required - for show progress bar
                .withOption('serverSide', true)// required - for server side processing
                .withOption('responsive', true)// required - for server side processing
                .withOption('paging', true)// required
                .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                .withDisplayLength(10) //// Page size
                .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                .withOption('order', [[0, 'desc'], [0, 'desc']]); //withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


        $scope.dtColumns = [
            DTColumnBuilder.newColumn('BOOK_ID').withTitle('Book Id'),
            DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Book Title'),
            DTColumnBuilder.newColumn('PM_NAME').withTitle('PM Name'),
            DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created date'),
            DTColumnBuilder.newColumn('QUERY').withTitle('Query').notSortable(),
            DTColumnBuilder.newColumn('SPIKE').withTitle('Spike').notSortable()
        ];
        $scope.dtInstance = {};
    };
    if ($scope.JobID == "") {
        $scope.getCucJobList();
    }

    /*$scope.cucjoblist   =   [];
     $scope.totalPages   =   0;
     $scope.currentPage  =   1;
     $scope.range        =   [];
     $scope.getPosts = function(pageNumber){
     
     if(pageNumber===undefined){
     pageNumber = '1';
     }
     $http.get(BASE_URL+"doCucjoblist?page=" + pageNumber) .then(function mySuccess(response) 
     {
     if(response.status != 200)
     {
     showNotify( 'Kindly reload page error occured.'  , 'danger' );
     }
     $scope.cucjoblist       =   response.data.cucjoblist.data;
     $scope.totalPages       =   response.data.cucjoblist.total;
     $scope.currentPage      =   response.current_page;
     
     // Pagination Range
     var pages = [];
     
     for(var i=1;i<=response.data.cucjoblist.last_page;i++) {          
     pages.push(i);
     }
     
     $scope.range = pages; 
     }, 
     function myError(response) {
     if($scope.contentloadtimer    !==  10){
     $scope.getPosts();
     }
     if($scope.contentloadtimer    ==  10){
     showNotify('Kindly reload page error occured.'  , 'danger' );
     return false;
     }
     });
     
     };
     $scope.getPosts(); */
    /*$scope.maxSize = 5;
     $scope.totalCount = 0;
     $scope.pageIndex = 1;
     $scope.pageSizeSelected = 5;
     
     $scope.init = function(){
     $http({
     method: 'GET',
     url: BASE_URL+"/doCucjoblist?pageIndex=" + $scope.pageIndex + "&pageSize=" + $scope.pageSizeSelected
     }).then(function successCallback(response){
     $scope.totalCount = response.data.cucjoblist.total; 
     $scope.numPages =  Math.ceil($scope.totalCount / $scope.pageSizeSelected);
     $scope.cucjoblist    =   response.data.cucjoblist.data;
     });
     };
     $scope.init();*/

    $scope.bookinfodetails = function (book)
    {
        $window.location.href = BASE_URL + "getChapterEsmlist/" + book;
    }

    $scope.getCucList = function ()
    {
        $scope.cuc = {};
        $scope.cuc.dtOptions = DTOptionsBuilder.newOptions().withOption('order', []);
        $scope.CucList = [];
        var inp = {jodId: $scope.JobID}
        var deferred = $q.defer();
        $http.post(BASE_URL + "doEsmjobChapterlist", inp).then(function mySuccess(response)
        {
            if (response.status != 200)
            {
                showNotify('Kindly reload page error occured.', 'danger');
            }
            $scope.CucList = response.data.cuclist;
            $scope.currentuserid = response.data.user_id;
            $scope.JobEsm = response.data.jobESm;
            deferred.resolve(response);
        },
                function myError(response) {
                    if ($scope.contentloadtimer < 10) {
                        $scope.CucList = [];
                        $scope.getCucList();
                    }
                    if ($scope.contentloadtimer == 10) {
                        showNotify('Kindly reload page error occured.', 'danger');
                        return false;
                    }
                    deferred.reject(response);
                });
        return deferred.promise;
        $scope.contentloadtimer++;
    };
    if ($scope.JobID != "") {
        $scope.getCucList();
    }



    /*
     *  Get Chapter file open
     *  This method get all the active Book info from DB
     */
    
    $scope.docheckout = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype)
    {
        showLoader('Please wait while checkout...');
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId
        };
        
        $http.post(BASE_URL + 'checkEsmDataispresentornot', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(".alertdangershow").css('display', 'block');
                    }
                    else if (response.data.result == 200)
                    {
                        bootbox.confirm("No ESM found,Are you sure want to proceed ?", function (result) {
                        if (result) {
                                $scope.autocheckout(taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype);
                            }
                        });
                    }else if (response.data.result == 201)
                    {
                        $scope.autocheckout(taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype);
                    }
                },
                        function myError(response)
                        {
                            hideLoader();
                        });
    };
    
    $scope.autocheckout = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype)
    {
        showLoader('Please wait while checkout...');
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID,
            checkouttype: checkouttype
        };
        
        var currentChapter = angular.element(document.getElementById("chapter_" + taskmetaid));
        $(currentChapter).find('button').attr('disabled', 'true');
        $http.post(BASE_URL + 'doEsmCheckoutprocess', inp)
                .then(function mySuccess(response)
                {
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(".alertdangershow").css('display', 'block');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 401)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }

                    if (response.data.result == 500)
                    {
                        showNotify(response.data.errMsg, 'warning');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 200)
                    {
                        $scope.checkesmexist    =   0;
                        var attempt = 1;
                        var timesheetid = response.data.records[0].jobtimesheetid;
                        var filehandlerid = response.data.rmID;
                        $scope.checkfilestatusopenornot1(taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype, attempt, timesheetid, filehandlerid);
                    }
                },
                        function myError(response)
                        {
                            $scope.checkesmexist    =   0;
                            $(currentChapter).find('button').removeAttr('disabled', 'true');
                        });
    };
    
    $scope.checkfilestatusopenornot1 = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype, attempt, timesheetid, filehandlerid)
    {

        var currentChapter = angular.element(document.getElementById("chapter_" + taskmetaid));
        var inp = {rmiID: filehandlerid,
            typeofstatus: 'Checkout'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                attempt++;
                if (attempt <= 5) {
                    $timeout(function () {
                        $scope.checkfilestatusopenornot1(taskmetaid, jobId, CHAPTER_NO, BOOK_ID, checkouttype, attempt, timesheetid, filehandlerid);
                    }, 2000);
                } else {
                    hideLoader();
                    $(currentChapter).find('button').removeAttr('disabled', 'true');
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if (response.data.result == 404)
            {
                hideLoader();
                $(currentChapter).find('button').removeAttr('disabled', 'true');
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if (response.data.result == 200)
            {
                currentChapter.remove();
                var templateElement = '<span id="removeall_' + taskmetaid + '"><div class="btn-group" id="chaptersubmit_' + taskmetaid + '"><button type="button" class="btn btn-success btn-xs pointer"   ng-click="doChapterProceed(' + "'" + taskmetaid + "'" + ',' + "'" + jobId + "'" + ',' + "'" + CHAPTER_NO + "'" + ',' + "'" + BOOK_ID + "'" + ',' + "'" + timesheetid + "'" + ')">Submit</button></div><span>';
                var temp = $compile(templateElement)($scope);
                angular.element(document.getElementById("checkinbutton_" + taskmetaid)).append(temp);
                hideLoader();
                showNotify(response.data.errMsg, 'success');
            }
        },
                function myError(response)
                {
                    hideLoader();
                    $(currentChapter).find('button').removeAttr('disabled', 'true');
                });
    };
    $scope.doCheckin = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID, jobtimesheetid)
    {
        var currentChapter = angular.element(document.getElementById("chaptercheckin_" + taskmetaid));
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID,
            jobtimesheetid: jobtimesheetid
        };
        showLoader('Please wait while checkin...');
        $(currentChapter).find('button').attr('disabled', 'true');
        $http.post(BASE_URL + 'doCucCheckinprocess', inp)
                .then(function mySuccess(response)
                {
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 401)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 500)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 200)
                    {
                        var checkintype = "old";
                        var templateElement = '<div class="btn-group" id="chapter_' + taskmetaid + '"><button type="button" class="btn btn-success btn-sm pointer"  ng-click="chapterinfodetails(' + "'" + taskmetaid + "'" + ',' + "'" + jobId + "'" + ',' + "'" + CHAPTER_NO + "'" + ',' + "'" + BOOK_ID + "'" + ',' + "'" + checkintype + "'" + ')">Checkout</button></div>';
                        var temp = $compile(templateElement)($scope);
                        angular.element(document.getElementById("removeall_" + taskmetaid)).remove();
                        angular.element(document.getElementById("checkinbutton_" + taskmetaid)).append(temp);
                        hideLoader();
                        showNotify(response.data.errMsg, 'success');
                    }
                },
                        function myError(response)
                        {
                            hideLoader();
                            $(currentChapter).find('button').removeAttr('disabled', 'true');
                            showNotify(response.data.errMsg, 'danger');
                        });
    };
    //final submit
    $scope.doChapterProceed = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID, jobtimesheetid)
    {
        showLoader('Please wait while Submit ...');
        var currentChapter = angular.element(document.getElementById("chaptersubmit_" + taskmetaid));
        var statusmessage = angular.element(document.getElementById("statuscomplete_" + taskmetaid));
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID,
            jobtimesheetid: jobtimesheetid
        };
        $(currentChapter).find('button').attr('disabled', 'true');
        $http.post(BASE_URL + 'emsCompleteprocess', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                    }
                    if (response.data.result == 401)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                    }
                    if (response.data.result == 500)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                    }
                    if (response.data.result == 200)
                    {
                        $scope.CucList = [];
                        $scope.getCucList();
                        showNotify(response.data.errMsg, 'success');
                    }
                },
                        function myError(response)
                        {
                            hideLoader();
                            $(currentChapter).find('button').removeAttr('disabled', 'true');
                        });
    }

    //open drive
    $scope.doChapterOpenDrive = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID)
    {
        showLoader('Please wait while Open Drive ...');
        var currentChapter = angular.element(document.getElementById("chaptersubmit_" + taskmetaid));
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID
        };
        $http.post(BASE_URL + 'cucOpendrive', inp)
                .then(function mySuccess(response)
                {
                    if (response.data.result == 404)
                    {
                        hideLoader();
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                    }
                    if (response.data.result == 401)
                    {
                        hideLoader();
                        showNotify(response.data.errMsg, 'danger');
                    }
                    if (response.data.result == 500)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        hideLoader();
                    }
                    if (response.data.result == 200)
                    {
                        var openattempt = 1;
                        var filehandlerid = response.data.rmID;
                        $scope.checkfiledriveopenstatus(openattempt, filehandlerid);
                    }
                },
                        function myError(response)
                        {
                            hideLoader();
                            //$scope.loadspinner      =	false;
                            //showMessage('Message', response.data.errMsg, 'error' );
                            //showNotify( response.data.errMsg  , 'danger' );
                        });
    }

    $scope.checkfiledriveopenstatus = function (openattempt, filehandlerid)
    {
        var inp = {rmiID: filehandlerid,
            typeofstatus: 'Opendrive'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                openattempt++;
                if (openattempt <= 5) {
                    $timeout(function () {
                        $scope.checkfiledriveopenstatus(openattempt, filehandlerid);
                    }, 2000);
                } else {
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if (response.data.result == 404)
            {
                hideLoader();
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if (response.data.result == 200)
            {
                hideLoader();
                showNotify(response.data.errMsg, 'success');
            }
        },
                function myError(response)
                {
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                });
    };
    $scope.jobandcucview = '';
    $scope.doJobsheetView = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID)
    {
        $scope.jobandcucview = "Job Sheet View";
        var inp = {
            metadataid: taskmetaid,
            jobId: jobId,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID
        };
        $('#show-cucview').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
        $http({
            url: BASE_URL + "getCucJobView",
            method: 'POST',
            data: inp
        })
                .success(function (response)
                {
                    if (response.xmlcount >= 1)
                    {
                        $scope.heightofmodal = 600;
                        $('#xmlContent').html(response.errMsg);
                    } else
                    {
                        $scope.heightofmodal = 100;
                        $('#xmlContent').html(response.errMsg);
                    }
                })
                .error(function (response)
                {
                    hideLoader();
                    $('#xmlContent').html(response.errMsg);
                });
    }

    $scope.jobandcucview = '';
    $scope.doChapterCucview = function (taskmetaid, jobId, CHAPTER_NO, BOOK_ID)
    {
        var inp = {
            jobId: jobId,
            metadataid: taskmetaid,
            Chapter: CHAPTER_NO,
            bookid: BOOK_ID
        };
        $scope.jobandcucview = "Cuc Sheet View";
//        $('#show-cucview').trigger('click');
        var window_dimensions = "directories=0,titlebar=0,toolbar=0,location=0,status=0,menubar=0,scrollbars=0,resizable=0, width=1200,height=850";
//        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        $http({
            url: BASE_URL + "getCucView",
            method: 'POST',
            data: inp
        })
                .success(function (response)
                {
                    if (response.xmlcount >= 1)
                    {
//                $('#show-cucview').trigger('click');
//                $scope.heightofmodal        =   600;
                        window.open(response.errMsg, "CUC Log View", window_dimensions);
//                $('#xmlContent').html(response.errMsg);
                    } else
                    {
//                $scope.heightofmodal        =   100;
                        var myWindow = $window.open("", "CUC Log View", window_dimensions);
                        myWindow.document.write(response.errMsg);
//                $('#xmlContent').html(response.errMsg);
                    }
                })
                .error(function (response)
                {
//            $('#xmlContent').html(response.errMsg);
                    var myWindow = $window.open("", "CUC Log View", window_dimensions);
                    myWindow.document.write(response.errMsg);
                });
    }

    $scope.dochaptererrorlog = function (item)
    {
        showNotify("You are not allowed to access this Chapter, as it is locked by other user (" + item.Chapter_User_Name + '-' + item.EMPLOYEE_ID + ")", 'danger');
    }

    $scope.buttonchangeprocess = function (type) {
        var currentChapter = angular.element(document.getElementById("txtDoopenrawfile"));
        if (type == 1) {
            $(currentChapter).val('Downloading');
            $(currentChapter).attr('disabled', 'true');
        } else if (type == 2) {
            $(currentChapter).val('Opening');
            $(currentChapter).attr('disabled', 'true');
        } else {
            $(currentChapter).val('Open Raw File');
            $(currentChapter).removeAttr('disabled');
        }
    }
    //open openjobrawfile
    $scope.openjobrawfile = function (jobId)
    {
        var currentChapter = angular.element(document.getElementById("txtDoopenrawfile"));
        $scope.buttonchangeprocess(1);
        showLoader('Please wait while Open Drive ...');
        var inp = {
            jobId: jobId
        };
        $http.post(BASE_URL + 'cucOpenrawFile', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.result == 404)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation, function (key, val)
                            {
                                $.each(val, function (key, errval)
                                {
                                    $.notify(errval, 'error');
                                });
                            });
                        }
                        $scope.buttonchangeprocess(0);
                        showNotify(response.data.errMsg, 'danger');
                    }
                    if (response.data.result == 200)
                    {
                        var attempt = 1;
//                showNotify( "Kindly wait while download raw files"  , 'success' );
                        // check tool end response
                        if (typeof response.data.lastID !== 'undefined' && response.data.lastID != '') {
                            $scope.checkToolresponse(response.data.lastID, jobId, attempt);
                        } else {
                            showNotify(response.data.errMsg, 'success');
                            var attempt = 1;
                            var filehandlerid = response.data.rmID;
                            $scope.buttonchangeprocess(2);
                            $scope.checkfilestatusopenornot(filehandlerid, attempt);
                        }
                    }
                },
                        function myError(response)
                        {
                            $scope.buttonchangeprocess(0);
                            hideLoader();
                            showNotify(response.data.errMsg, 'danger');
                        });
    }

    $scope.checkToolresponse = function (ID, jobId, attempt)
    {
        var inp = {ID: ID};
        $http.post(API_URL + 'checkToolStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                attempt++;
//                $.notify(response.data.errMsg,'error');
                $timeout(function () {
                    $scope.checkToolresponse(ID, jobId, attempt);
                }, 4000);
            }
            if (response.data.result == 404)
            {
                $scope.buttonchangeprocess(0);
                showNotify("File handler is not running. Please check....", 'danger');
            }
            if (response.data.result == 400)
            {
                $scope.buttonchangeprocess(0);
                showNotify(response.data.errMsg, 'danger');
            }
            if (response.data.result == 200)
            {
//                showNotify( response.data.errMsg, 'success' );
                $scope.RawfileOpenrequestInsert(jobId);
            }
        },
                function myError(response)
                {
                    $scope.buttonchangeprocess(0);
                });
    };
    $scope.RawfileOpenrequestInsert = function (jobId) {
        var inp = {jobId: jobId}
        showLoader('Please wait while Open Drive ...');
        $http.post(BASE_URL + 'rawfileOpenrequestInsert', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.result == 404)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation, function (key, val)
                            {
                                $.each(val, function (key, errval)
                                {
                                    $.notify(errval, 'error');
                                });
                            });
                        }
                        showNotify(response.data.errMsg, 'danger');
                        hideLoader();
                        $scope.buttonchangeprocess(0);
                    }
                    if (response.data.result == 200)
                    {
                        var attempt = 1;
                        var filehandlerid = response.data.rmID;
                        $scope.buttonchangeprocess(2);
                        $scope.checkfilestatusopenornot(filehandlerid, attempt);
                    }
                },
                        function myError(response)
                        {
                            $scope.buttonchangeprocess(0);
                            hideLoader();
                            showNotify(response.data.errMsg, 'danger');
                        });
    };
    $scope.checkfilestatusopenornot = function (filehandlerid, attempt)
    {
        var inp = {rmiID: filehandlerid,
            typeofstatus: 'Opendrive'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                attempt++;
                if (attempt <= 5) {
                    $timeout(function () {
                        $scope.checkfilestatusopenornot(filehandlerid, attempt);
                    }, 2000);
                } else {
                    hideLoader();
                    $scope.buttonchangeprocess(0);
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if (response.data.result == 404)
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if (response.data.result == 200)
            {
                $scope.buttonchangeprocess(0);
                hideLoader();
                showNotify(response.data.errMsg, 'success');
            }
        },
                function myError(response)
                {
                    $scope.buttonchangeprocess(0);
                    hideLoader();
                });
    };
    $scope.Msgsuccess = true;
    $scope.hidemsg = function ()
    {
        $scope.Msgsuccess = false;
    }

    //show client ack remarks commands
    $scope.showLogview = function (acaREMARKS) {
        var printMsg = (acaREMARKS == null || acaREMARKS == "") ? 'Remarks not found..' : acaREMARKS;
        $('#show-redo').trigger('click');
        $scope.Msgbox = "Remarks";
        $('#redofailed').html('<p class="text-center">' + printMsg + '</p>');
    };
    $scope.retrycucbackground = function (jobid)
    {
        showLoader('Please wait while retry...');
        $http.get(BASE_URL + "cucback/" + jobid).then(function mySuccess(response)
        {
            var temp = '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - In Progress</code>';
            angular.element(document.getElementById("cucretry_" + jobid)).remove();
            var elem = angular.element(document.getElementById("cuc_" + jobid)).append(temp);
            hideLoader();
        }, function myError(response)
        {
            hideLoader();
        });
    };
    $scope.doOpenLogFolder = function (item)
    {
        showLoader('Please wait while checkout...');
        var inp = {
            metadataid: item.taskmetaid,
            jobId: item.jobid,
            Chapter: item.CHAPTER_NO,
            bookid: item.BOOK_ID
        };
        var taskmetaid = item.taskmetaid;
        var currentChapter = angular.element(document.getElementById("logfile_" + taskmetaid));
        $(currentChapter).find('button').attr('disabled', 'true');
        $http.post(BASE_URL + 'cucOpendrive', inp)
                .then(function mySuccess(response)
                {
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 401)
                    {
                        showNotify(response.data.errMsg, 'danger');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }

                    if (response.data.result == 500)
                    {
                        showNotify(response.data.errMsg, 'warning');
                        $(currentChapter).find('button').removeAttr('disabled', 'true');
                        hideLoader();
                    }
                    if (response.data.result == 200)
                    {
                        var attempt = 1;
                        var filehandlerid = response.data.rmID;
                        $scope.checkfilestatusopenornot(taskmetaid, item.jobid, item.CHAPTER_NO, item.BOOK_ID, '', attempt, '', filehandlerid);
                    }
                },
                        function myError(response)
                        {
                            $(currentChapter).find('button').removeAttr('disabled', 'true');
                        });
    };
    $scope.esmcountShow = function (MetadataID, chaptername)
    {
        showLoader();
        var inp = {metadataId: MetadataID, jodId: $scope.JobID};
        $scope.chaptername = chaptername;
        $scope.MetadataID = MetadataID;
        $rootScope.isExistcheckoutesm   =   0;
        $http.post(BASE_URL + "getesmViewInfo", inp).then(function mySuccess(response)
        {
            hideLoader();
            if (response.data.result == 401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation, function (key, val)
                    {
                        $.each(val, function (key, errval)
                        {
                            $.notify(errval, 'error');
                        });
                    });
                }
                showNotify(response.data.errMsg, 'danger');
                hideLoader();
            }

            if (response.data.result == 404)
            {
                showNotify(response.data.errMsg, 'danger');
                hideLoader();
            }
            //open chapter wise
            if (response.data.result == 200)
            {
                $scope.esmchapterlist = response.data.esmchapterlist;
                if (response.data.esmchapterlist.length >= 1)
                {
                    $scope.heightofmodal = 600;
                } else
                {
                    $scope.heightofmodal = 600;
                }
                $scope.esmmetaid = MetadataID;
                angular.element('#show-openesm').trigger('click');
            }
        },
                function myError(response)
                {
                    hideLoader();
                    showNotify(response.data.msg, 'danger');
                });
    };
    $scope.qmsspike = function (jobId, userId, bookId, type)
    {
        if (type == 'qms')
        {
            $scope.bookTitle = bookId;
            $scope.srciframepath = QMS_URL + "?titleID=" + jobId + '&userId=' + userId + '&type=Magnus';
            $('#iframeqms').attr('src', $scope.srciframepath);
        } else
        {
            $scope.bookTitle = bookId;
            $scope.srciframepath = SPIKE_URL + "?titleID=" + jobId + "&type=Magnus";
            $('#iframespike').attr('src', $scope.srciframepath);
        }
    };
    $scope.retryvalidation = function (item) {

        showLoader('Please wait while checkout...');
        var inp = {
            metaId: item.METADATA_ID,
            jobid: item.jobid,
        };
        $http.post(BASE_URL + 'api/esmvalidation', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.status == 1)
                    {
                        $scope.CucList = [];
                        $scope.getCucList();
                        showNotify(response.data.errMsg, 'success');
                    } else {

                        showNotify(response.data.errMsg, 'success');
                    }
                },
                        function myError(response)
                        {
                            // $(currentChapter).find('button').removeAttr('disabled','true');
                        });
    }

    $scope.retryvalidationview = function () {

        showLoader('Please wait while checkout...');
        var inp = {
            metaId: $scope.esmmetaid,
            jobid: $scope.JobID,
        };
        $http.post(BASE_URL + 'api/esmvalidation', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.status == 1)
                    {
                        $scope.esmchapterlist = [];
                        $scope.esmcountShow($scope.MetadataID, $scope.chaptername);
                        angular.element('#show-openesm').trigger('click');
                        showNotify(response.data.errMsg, 'success');
                    } else {

                        showNotify(response.data.errMsg, 'success');
                    }
                },
                        function myError(response)
                        {
                            // $(currentChapter).find('button').removeAttr('disabled','true');
                        });
    }


    $scope.retryvid = function (item) {

        showLoader('Please wait...');
        var inp = {
            metaId: item.taskmetaid,
            jobid: item.jobid,
        };
        $http.post(BASE_URL + 'api/esmvidretry', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.status == 1)
                    {
                        $scope.CucList = [];
                        $scope.getCucList();
                        showNotify(response.data.errMsg, 'success');
                    } else {

                        showNotify(response.data.errMsg, 'success');
                    }
                },
                        function myError(response)
                        {
                            // $(currentChapter).find('button').removeAttr('disabled','true');
                        });
    }

    $scope.addesmfiles = function (ID) {
        var esmIDarray = [];
//        var selectedesm_IDS = $('.metaesmgenerate_'+ID+':checked').each(function (inx) {
//            esmIDarray.push($(this).val());
//        });
//        if (esmIDarray.length == 0) {
//            showNotify('Kindly Select Anyone', 'danger');
//            return false;
//        }
        if($rootScope.isExistcheckoutesm    !=  0){
            showNotify('Kindly complete which is already opened video...', 'danger');
            return false;
        }
        
        $rootScope.isExistcheckoutesm   =   ID;
        showLoader('Please wait...');
        var inp = {
            jobId: $scope.JobID,
            metadataId: $scope.esmmetaid,
            esmId: ID
        };
        $http.post(BASE_URL + 'addEsmFiles', inp)
                .then(function mySuccess(response)
                {
                    if (response.data.result == 401)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation, function (key, val)
                            {
                                $.each(val, function (key, errval)
                                {
                                    $.notify(errval, 'error');
                                });
                            });
                        }
                        $rootScope.isExistcheckoutesm   =   0;
                        showNotify(response.data.errMsg, 'danger');
                    }
                    
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                    }
                    
                    if (response.data.result == 200)
                    {
//                        showNotify(response.data.errMsg, 'success');
                        var attempt = 1;
                        var filehandlerid = response.data.rmID;
                        $scope.checkesmfilestatusopenornot(filehandlerid, attempt, ID);
                    }
                },
                        function myError(response)
                        {
                            $rootScope.isExistcheckoutesm   =   0;
                            hideLoader();
                            showNotify(response.data.errMsg, 'danger');
                        });
    }


    $scope.checkesmfilestatusopenornot = function (filehandlerid, attempt, ID)
    {
        var inp = {rmiID: filehandlerid,
            typeofstatus: 'Opendrive'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response)
        {
            if (response.data.result == 500)
            {
                attempt++;
                if (attempt <= 5) {
                    $timeout(function () {
                        $scope.checkesmfilestatusopenornot(filehandlerid, attempt, ID);
                    }, 2000);
                } else {
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if (response.data.result == 404)
            {
                $rootScope.isExistcheckoutesm   =   0;
                hideLoader();
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if (response.data.result == 200)
            {
                $scope.updatesmmanagebutton(ID, 'addfile');
                hideLoader();
                showNotify(response.data.errMsg, 'success');
            }
        },
                function myError(response)
                {
                    $rootScope.isExistcheckoutesm   =   0;
                    hideLoader();
                });
    };
    $scope.submitesmfiles = function (ID) {
        showLoader('Please wait...');
        var inp = {
            jobId: $scope.JobID,
            metadataId: $scope.esmmetaid,
            esmId: ID
        };
        $http.post(BASE_URL + 'updateEsmFiles', inp)
                .then(function mySuccess(response)
                {
                    hideLoader();
                    if (response.data.result == 401)
                    {
                        if (typeof response.data.validation !== 'undefined') {
                            $.each(response.data.validation, function (key, val)
                            {
                                $.each(val, function (key, errval)
                                {
                                    $.notify(errval, 'error');
                                });
                            });
                        }
                        showNotify(response.data.errMsg, 'danger');
                    }
                    
                    if (response.data.result == 404)
                    {
                        showNotify(response.data.errMsg, 'danger');
                    }
                    
                    if (response.data.result == 200)
                    {
                        $rootScope.isExistcheckoutesm   =   0;
                        $scope.esmdatarefresh($scope.esmmetaid, 'FM1');
                    }
                },
                        function myError(response)
                        {
                            hideLoader();
                            showNotify(response.data.errMsg, 'danger');
                        });
    }

    $scope.deleteesmfiles = function (ID) {
        bootbox.confirm("Are you sure to delete on this ?", function (result) {
            if (result) {
                showLoader('Please wait...');
                var inp = {
                    jobId: $scope.JobID,
                    metadataId: $scope.esmmetaid,
                    esmId: ID
                };
                $http.post(BASE_URL + 'deleteEsmFiles', inp)
                        .then(function mySuccess(response)
                        {
                            if (response.data.result == 401)
                            {
                                if (typeof response.data.validation !== 'undefined') {
                                    $.each(response.data.validation, function (key, val)
                                    {
                                        $.each(val, function (key, errval)
                                        {
                                            $.notify(errval, 'error');
                                        });
                                    });
                                }
                                showNotify(response.data.errMsg, 'danger');
                            }
                            
                            if (response.data.result == 404)
                            {
                                showNotify(response.data.errMsg, 'danger');
                            }
                            
                            if (response.data.result == 200)
                            {
                                $rootScope.isExistcheckoutesm   =   0;
                                showNotify(response.data.errMsg, 'success');
                                $scope.esmdatarefresh($scope.esmmetaid, $scope.esmchaptername);
                            }
                        },
                                function myError(response)
                                {
                                    hideLoader();
                                    showNotify(response.data.errMsg, 'danger');
                                });
            }
        });
    }

    $scope.esmdatarefresh = function (MetadataID, chaptername)
    {
        var inp = {metadataId: MetadataID, jodId: $scope.JobID};
        $scope.chaptername = chaptername;
        $scope.MetadataID = MetadataID;
        $http.post(BASE_URL + "getesmViewInfo", inp).then(function mySuccess(response)
        {
            hideLoader();
            if (response.data.result == 401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation, function (key, val)
                    {
                        $.each(val, function (key, errval)
                        {
                            $.notify(errval, 'error');
                        });
                    });
                }
                showNotify(response.data.errMsg, 'danger');
                hideLoader();
            }

            if (response.data.result == 404)
            {
                showNotify(response.data.errMsg, 'danger');
                hideLoader();
            }
            //open chapter wise
            if (response.data.result == 200)
            {
                $scope.esmchapterlist = response.data.esmchapterlist;
                $scope.esmmetaid = MetadataID;
            }
        },
                function myError(response)
                {
                    hideLoader();
                    showNotify(response.data.msg, 'danger');
                });
    };
    $scope.updatesmmanagebutton = function (ID, type) {
        if (type == 'addfile') {
            $("#addesmfile_" + ID).text('');
            var templateElement = '<button type="button" class="btn btn-primary btn-xs pointer"  ng-click="submitesmfiles(' + ID + ')">Submit Video</button>'
            var temp = $compile(templateElement)($scope);
            angular.element(document.getElementById("addesmfile_" + ID)).append(temp);
        }
    }

});




/*ngApp.directive('postsPagination', function(){  
 return{
 restrict: 'E',
 template: '<ul class="pagination">'+
 '<li ng-show="currentPage != 1"><a href="javascript:void(0)" ng-click="getPosts(1)">«</a></li>'+
 '<li ng-show="currentPage != 1"><a href="javascript:void(0)" ng-click="getPosts(currentPage-1)">‹ Prev</a></li>'+
 '<li ng-repeat="i in range" ng-class="{active : currentPage == i}">'+
 '<a href="javascript:void(0)" ng-click="getPosts(i)">{{i}}</a>'+
 '</li>'+
 '<li ng-show="currentPage != totalPages"><a href="javascript:void(0)" ng-click="getPosts(currentPage+1)">Next ›</a></li>'+
 '<li ng-show="currentPage != totalPages"><a href="javascript:void(0)" ng-click="getPosts(totalPages)">»</a></li>'+
 '</ul>'
 };
 });*/