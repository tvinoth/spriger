/*
 *  Round Master Controller
 *  This controller contains all the methods related to customization > round screen.
 */
ngApp.controller('ngController', function ($scope, $http,DTOptionsBuilder, DTColumnBuilder) {
	$scope.userId = 0;
 	$scope.menuParent = 'Customization';
	$scope.menuChild = 'RoundList';
	
	$scope.roundCode = "";
	$scope.errorMsg = "";
	$scope.roundId = 0;

	/*
	 *  Get Round List
	 *  This method get all the active rounds from DB
	 */
	$scope.showRoundList = function() {
		$scope.roundList = [];
		var inp = {	roundId : 0, opt : 'All'};
		$http.post(API_URL+"getRoundMasterDetail", inp) .then(function mySuccess(response) {
			$scope.roundList = response.data.round;	
		}, 
		function myError(response) {
			 console.log(response);
		});			
	};
        $scope.showRoundList();
	/*
	 *  Get Round Details
	 *	Round Id is the input.
	 *  This method get the round details for the given round id.
	 */
	$scope.showRoundDetails = function(rnd) {
		var roles = '', title = 'Round Details', content = '';	
				
		content += '<table class="table table-bordered">'+
					'<tr><th>Round Code </th><td>'+rnd.CODE+'</td></tr>'+
					'<tr><th>Round Name </th><td>'+rnd.NAME +'</td></tr>'+
					'<tr><th>Description </th><td>'+rnd.DESCRIPTION +'</td></tr>'+
					'</table>';
		showInfo(title, content);
			
	};	
	/*
	 *  Add Round
	 *  This method used to add new round details
	 */
	$scope.addRound = function() {
		$scope.clearRound();
		$("#show-edit").click();		
	};
	/*
	 *  Clear Round Details
	 *  This method used to clear round details 
	 */
	$scope.clearRound = function() {
		$scope.roundCode = "";
		$scope.roundName = "";
		$scope.description = "";
		$scope.roundId =0;
		$scope.errorMsg = "";
		$("#edit-close").click();	
	};
	/*
	 *  Edit Round Details
	 *  This method used to edit existing round details
	 */
	$scope.editRound = function(rnd) {
		$("#show-edit").click();	
		$scope.roundCode = rnd.CODE;
		$scope.roundName = rnd.NAME;
		$scope.description = rnd.DESCRIPTION;
		$scope.roundId = rnd.id;
	};
	/*
	 *  Save Round
	 *  This method used to save round details
	 */
	$scope.saveRound = function() {
		if($scope.roundName == "") {
			 $scope.errorMsg = "Please enter round name.";
		} else {
			var inp = {	userId: '', roundId : $scope.roundId, roundCode : $scope.roundCode, roundName: $scope.roundName, description:$scope.description};
			$http.post(API_URL+"saveRound", inp) .then(function mySuccess(response) {
				if(response.data[0].flag) {
					$scope.errorMsg = response.data[0].msg;
				} else {
					showMessage('Round', response.data[0].msg, 'success');
					$scope.clearRound();
					$scope.showRoundList();	
				}
				 console.log(response);
				 //
			}, 
			function myError(response) {
				 console.log(response);
			});		
		}			
	};
	/*
	 *  Delete Round
	 *  This method deletes the given round information.
	 */
	$scope.deleteRound = function(roundId) {
		bootbox.confirm("Are you sure you want to delete?", function(result) {
			if(result) {				
				var inp = {	jobId : $scope.JobID, 
							roundId: roundId
							};
				$http.post(API_URL+"deleteRound", inp) .then(function mySuccess(response) {
					var res = response.data;					
					showMessage('Round', 'Round successfully deleted.', 'success');
					$scope.showRoundList();
				}, 
				function myError(response) {
					// console.log(response);
				});
				
			}
		});	
	};
});