/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$filter,$compile,$timeout, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder ,fileUploadService ) 
{
	$scope.userId 		= 	0;
 	$scope.menuParent 	= 	'Pre-Production';
	$scope.menuChild 	= 	'PrrReport';
	$scope.errorMsg 	= 	"";
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
        $scope.contentloadtimer     =   1;
	$scope.getspicastinfoList   =   function() 
	{
            $scope.prrList          =   [];
            $http.get(BASE_URL+"prrreport-list") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                }
                $scope.prrList      =   response.data.prr;	
            }, 
            function myError(response) 
            {
                if($scope.contentloadtimer    <  10){
                    $scope.getEproofList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });			
            $scope.contentloadtimer++;
	};
        
        $scope.getspicastinfoList();
	
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
	$scope.prrReportDwonload    = 	function(book) 
	{
            var inp                 =   {
                                            jobid   :   book.jobid,
                                            bookid  :   book.BOOK_ID,
                                            roundid :   book.ROUND_ID
                                        }
            showLoader('Please wait while download file...'); 
            $http.post('prrreport-download',inp).then(function mySuccess(response)
            {
                if(response.data.result  ==  200)
                {
                    hideLoader();
                    var url             =   response.data.link;   
                    $scope.downloadUrl  =   response.data.link;
                    //$("#dwnl_local").attr('href',response.data.link);
                    showNotify('Successfully downloaded'  , 'success' );
                    $scope.fileopened   =   1;
                    window.open(url, '_blank');
                    $timeout( function()
                    { 
                        $scope.deletfiles();
                    }, 15000 );
                    
                }
            },
            function myError(response)
            {
                hideLoader();
                showNotify(response.data.errMsg  , 'danger' );
            });                         
	};
        
        $scope.deletfiles   =   function()
        {
            $http.get(BASE_URL+"prrreport-delete") .then(function mySuccess(response) 
            {
                console.log('success');
            }, 
            function myError(response) 
            {

            });	
        }
            	
        //show client ack remarks commands
        $scope.showClientack   =   function(acaREMARKS){   
            var printMsg       =   (acaREMARKS == null || acaREMARKS == "" ) ? 'Remarks not found..' : acaREMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=   "Client Error Log Files";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
        
        $scope.prrReportSend        =   function(profiles)
        {
		    $scope.pmemailid        =   '';
            $scope.jobId            =   '';
            $scope.jobId            =   profiles.jobid;
            $scope.pmemailid        =   profiles.PE_MAIL;
            $scope.fileupload       =   false;   
            $scope.showerror        =   false;
			var bookId = profiles.BOOK_ID;
			$("#bookId").val(bookId);
            $("#show-sendmail").click();
        }
        
        //show meta extrator remarks commands
        $scope.showMeataextratorremarksview = 	function(params){   
            var printMsg    =   ( params.REMARKS == null || params.REMARKS == '' ) ? 'Error Log File not found..' : params.REMARKS;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Error Log Files";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	
        
        //show meta extrator remarks commands
        $scope.showApiMeataextratorremarksview  = 	function(params){ 
            var printMsg    =   ( params == null || params == '' ) ? 'Error Log File not found..' : params;
            $('#show-redo').trigger('click');
            $scope.Msgbox 	=	"Error Log Files";
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };	
        
        $scope.prrReportSendpm      =     function()
        {
            var excelFile            =   $scope.myFile;
			var fileName = $("#myFileField").val();
 			var file = fileName.replace(/.*(\/|\\)/, '');
			var bookId = $("#bookId").val();
			var uploadFileName = bookId+'_Production_Review_Report.xlsx';
			if(file != uploadFileName){
				 $scope.showerror    =   true;
				 $scope.adderrorMsg  =   'Kindly upload the correct file belongs to '+bookId+' !'
				return false;
			}
            if( $scope.pmemailid    ==     "") 
            {
                $scope.showerror    =   true;
                $scope.adderrorMsg  =   'all fields are required';
                return false;
            }
            if( excelFile ==     "" ||   excelFile == undefined ) 
            {
                $scope.showerror    =   true;
                $scope.adderrorMsg  =   'Kindly upload file';
                return false;
            } 
            else 
            {
                showLoader('Please wait while send Email...'); 
                $scope.showerror    =   false;
                $scope.fileupload   =   true;
                var uploadUrl       = 	BASE_URL+"prrreport-send";
		promise             = 	fileUploadService.uploadFileToUrl(excelFile,$scope.jobId,$scope.pmemailid, uploadUrl);
		promise.then(function (response) 
                {
                    if(response.data.result  ==  200)
                    {
                        var     temp    =   '<i class="fa fa-check bigger-150 green" title="Already Sent" aria-hidden="true"></i>';
                        angular.element(document.getElementById("sendremove_"+$scope.jobId)).remove();
                        var elem    =   angular.element(document.getElementById("senditem_"+$scope.jobId)).append(temp);
                        $scope.adderrorMsg  =   response.data.errMsg;
                        $('#show-sendmail').trigger('click');
                        $("#myFileField").val('');
                        var typeredo        =   "s5";
                        $scope.reporrtpath  =   response.data.Prrreporrtpath;
                        showNotify(response.data.errMsg  , 'success' );
                        var     temp    =   '<span id="s5sendprocess_'+$scope.jobId+'"><i class="fa fa-spinner fa-spin red"></i> In Progress</span>';
                        temp        =   $compile(temp)($scope);
                        var elem    =   angular.element(document.getElementById("s5senditem_"+$scope.jobId)).append(temp);
                        $scope.sendJobsheetNotification(typeredo,$scope.jobId,'104'); 
                    }
                    hideLoader();
		}, function (errorresponse) 
                {
                    hideLoader();
                    if(errorresponse.data.errMsg)
                    {
                        showNotify(errorresponse.data.errMsg  , 'danger' );
                    }
                    $scope.fileupload   =   false;
                    showNotify("Internal server error try again...", 'Warning');
		});
                } 
            };      
            
            $scope.cancelprrReport  =   function(){
                $("#myFileField").val('');
            }
            
        $scope.retrySpicastbackground      =     function(jobid,round)
        {
            showLoader('Please wait while retry...'); 
            $http.get(BASE_URL+"spicastbackground/"+jobid).then(function mySuccess(response)
            {
//                if(response.data.result  ==  200)
//                {
                var     temp    =   '<i class="fa fa-spinner fa-spin red"></i> In-Progress';
                angular.element(document.getElementById("spicastretry_"+jobid)).remove();
                angular.element(document.getElementById("spicastnorequest_"+jobid)).remove();
                angular.element(document.getElementById("spicastunprogress_"+jobid)).remove();
                var elem    =   angular.element(document.getElementById("spicast_"+jobid)).append(temp);
//                $scope.adderrorMsg  =   response.data.errMsg;
//                }
                hideLoader();
            }, function myError(response) 
            {
                hideLoader();
            });
            };
            
    $scope.sendJobsheetNotification     =       function(typeredo,jobid,round)
    {
        showLoader('Please wait s5 notification is sending...'); 
        $http.get(API_URL+"sendInputForJobsheetUpdate/"+jobid+"/"+round+'/NOTIFICATION').then(function mySuccess(response) 
        {
            if(typeredo     ==  's5')
            {
                if(response.data.status 	==  1 ) 
                {
                    var     temp    =   '<i class="fa fa-check bigger-130 green" title="Already Sent" aria-hidden="true"></i><code class="green"> - JS Update</code> <span><i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - JS Upload </code></span>';
                    angular.element(document.getElementById("s5sendremove_"+jobid)).remove();
                    angular.element(document.getElementById("s5sendprocess_"+jobid)).remove();
                    var elem    =   angular.element(document.getElementById("s5senditem_"+jobid)).append(temp);
                    showNotify( 'S5 notification send successfully.!' , 'success' );
                }
                if(response.data.status 	==  0 ) 
                {
                    var errorremrks =   response.data.errMsg;
                    var     temp    =   '<span id="s5sendremove_'+jobid+'"><i class="fa fa-exclamation-circle pointer bigger-150 red" title="S5 Notification Error log" aria-hidden="true" ng-click="showApiMeataextratorremarksview('+"'"+errorremrks+"'"+')"></i>&nbsp; <i class="fa fa-repeat pointer bigger-130 blue" title="S5 Notification retry" aria-hidden="true" ng-click="sendJobsheetNotification('+"'"+typeredo+"'"+','+jobid+','+round+')"></i></span>';
                            temp    =   $compile(temp)($scope);
                    angular.element(document.getElementById("s5sendremove_"+jobid)).remove();
                    angular.element(document.getElementById("s5sendprocess_"+jobid)).remove();
                    var elem    =   angular.element(document.getElementById("s5senditem_"+jobid)).append(temp);
                    showNotify( response.data.errMsg, 'danger' );
                }
            }
            if(typeredo     ==  'clientack')
            {
                if(response.data.status 	==  1 ) 
                {
                    var     temp    =   '<i class="fa fa-spinner fa-spin"></i> <code class="yellow"> - waiting for client response</code> ';
                    angular.element(document.getElementById("clientsendremove_"+jobid)).remove();
                    angular.element(document.getElementById("s5sendprocess_"+jobid)).remove();
                    var elem    =   angular.element(document.getElementById("clientsenditem_"+jobid)).append(temp);
                    showNotify( 'S5 notification send successfully.!' , 'success' );
                }
                if(response.data.status 	==  0 ) 
                {
                    var errorremrks =   response.data.errMsg;
                    var     temp    =   '<span id="clientsendremove_'+jobid+'"><i class="fa fa-exclamation-circle pointer bigger-150 red" title="S5 Notification Error log" aria-hidden="true" ng-click="showApiMeataextratorremarksview('+"'"+errorremrks+"'"+')"></i>&nbsp; <i class="fa fa-repeat pointer bigger-130 blue" title="S5 Notification retry" aria-hidden="true" ng-click="sendJobsheetNotification('+"'"+typeredo+"'"+','+jobid+','+round+')"></i></span>';
                            temp    =   $compile(temp)($scope);
                    angular.element(document.getElementById("clientsendremove_"+jobid)).remove();
                    angular.element(document.getElementById("s5sendprocess_"+jobid)).remove();
                    var elem    =   angular.element(document.getElementById("clientsenditem_"+jobid)).append(temp);
                    showNotify( response.data.errMsg , 'danger' );
                }
            }
            
            hideLoader();
        }, 
        function myError(response) 
        {
            hideLoader();
            console.log(response);
        });	
    };
    
    $scope.retryJobsheetUpdate  = 	function(params)
        {
            var printMsg            =   ( params.METAREMARKS == null ) ? 'remarks not found..' : params.METAREMARKS;
            showLoader();
            showNotify( 'please wait for a while...' , 'success');
            var jobid               =   params.jobid;
            var dynamic_url         =   "sendInputForJobsheetUpdate/"+jobid+'/'+params.ROUND_ID+'/NOTIFICATION';   
            $http.get(API_URL+dynamic_url).then(function mySuccess(response) {
                if(response.data.status == 1) {      

                    $timeout( function(){  
                    hideLoader();
                    showNotify( 'Jobsheet update response is :'+response.data.errMsg , 'success' );

                    $timeout( function(){  
                        $window.location.reload();
                    }, 2000 );

                    }, 5000 );
                } else {
                    showNotify( 'Request got failed..' , 'danger');
                    hideLoader();
                }
            },function myError(response) {
                console.log(response);
                showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });
    };
    
    $scope.showSuccessredologview   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.CLIACKID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID
                        };
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
      
});

        
    

    ngApp.directive('demoFileModel', function ($parse) {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) 
            {
                var model 	= 	$parse(attrs.demoFileModel),
                modelSetter     = 	model.assign; //define a setter for demoFileModel
                //Bind change event on the element
                element.bind('change', function ($scope) 
				{
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                        //set the model value
                        modelSetter(scope, element[0].files[0]);
						$scope.bookmapUploadMsg 	=	'';
                    });
                });
            }
        };
    });
	
    ngApp.service('fileUploadService', function ($http, $q) 
    {
            this.uploadFileToUrl 	= 	function (file,jobId,Mailid, uploadUrl) 
            {
            var fileFormData 	= 	new FormData();
            fileFormData.append('file', file);
			fileFormData.append('jobId', jobId);
			fileFormData.append('Mailid', Mailid);
            var deffered 		= 	$q.defer();
            $http.post(uploadUrl, fileFormData, 
			{
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined}
 
            }).then(function mySuccess(response) 
			{
                deffered.resolve(response);
 
            },
			function myError(response) 
			{
				deffered.reject(response);
			});
            return deffered.promise;
        }
    });