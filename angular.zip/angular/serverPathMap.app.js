/**
 * 
 * Author   :       Ananth B
 * Date     :       8 / 5 / 2018
 * Module   :       workflow server path 
 * 
 */

ngApp.controller('ngController', function ( $scope , $http , $rootScope,$filter , $window ,  $timeout , $interval , DTOptionsBuilder , DTColumnBuilder )  {
  
    
     $(document).ready(function () {
         
       
        $( "input[type='text'],select" ).focus(function(e) { 
            $('.help-block').remove('');
            $('.form-control,.is-invalid').removeClass();
        });
       
        function serverMapPath( formdata ){
            this.formdata   =   formdata;
        };
        
        serverMapPath.prototype =   {
            extractElementName  :   function( data ){
                
            },
            replaceSlashes  : function(){
                
            },
            getIndexCount :function (array_elements) {
                array_elements.sort();
                var current = null;
                var cnt = 0;
                for (var i = 0; i < array_elements.length; i++) {
                    if (array_elements[i] != current) {
                        if (cnt > 0) {
                        }
                        current = array_elements[i];
                        cnt = 1;
                    } else {
                        cnt++;
                    }
                }
                return cnt;
            },
            validatingForm  : function(){
                
                var obj             =   this.formdata;
                var returnErr       =   [];
                Object.keys(obj).forEach(function(key) {
                   var data =    obj[key];
                   if( data.value == '' || typeof data.value == undefined ){
                       returnErr.push( [ data.name , '* required field' ]);
                   }
                   
                });
                this.showError( returnErr );
                
                return ( returnErr );
            },
            formatingInput : function( elem ){
                
                $(elem).val( $(elem).val().replace( '\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '\\\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '\\\\\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '\\\\\\\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '/\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '/\\/\\' , '/' ) );
                $(elem).val( $(elem).val().replace( '//' , '/' ) );
                $(elem).val( $(elem).val().replace( '//' , '/' ) );
                $(elem).val( $(elem).val().replace( '////' , '/' ) );
                  
                var valueCheck      =       $(elem).val().slice(0,1);
                var errorMsg       =       '<span class="help-block"> Invalid input </span>';
                
                //first letter
                if( valueCheck == '/' || valueCheck == '\\' ){
                    valueCheck     =    $(elem).val().slice(1,$(elem).val().length);
                    $(elem).val( valueCheck );
                }
                
                //na small case
                if( $(elem).val() == 'na' )
                    $(elem).val('NA');
               
                
            },
            checkingFtpConnection:function(){
            },
            showError:function( data ){
                
                var findexistelm        =       [];
                var smp_obj             =       new serverMapPath($('#addServerMapPath').serializeArray());
                smp_obj.clearError();
                
                data.forEach( function( elementInfo ){
                    var namesof         =       elementInfo[0].replace(/[^a-zA-Z_]/g, "");
                    findexistelm.push( namesof );
                    var elementname  =   elementInfo[0].slice( 0,-2);
                    noofindex = smp_obj.getIndexCount( findexistelm );
                    $('input[name^='+elementname+']').addClass('form-control is-invalid');
                    var errorMsg    =       '<span class="help-block">'+elementInfo[1]+'</span>';
                    $('input[name^='+elementname+']').parent().parent().find('td:nth-child(11)').html( errorMsg );
                    $('input[name^='+elementname+']').parent().parent().addClass('has-error');
                });
                
            },
            clearError:function(){
                
            }
        };
        
        $(document).delegate('.addClear', "click", function(){ 
            $(this).parent().parent().find('input[type="text"],input[type="password"]').val('');
            $(this).parent().parent().find('select').val('1');
        });
        
        $(document).delegate('input[type="text"]', "blur", function(){ 
            var smp_obj =  new serverMapPath([]);
            smp_obj.formatingInput( $(this) );
        });
      
        $(document).delegate('input[class^="serverip"]', "keypress", function(){ 
            $(this).addClass('current_auto');
        });
      
    
        $(document).delegate("#saveWorkflowServerPath", "click", function(event){
            
            var formdata            =       $('#addServerMapPath').serialize();
            var smp_obj             =       new serverMapPath($('#addServerMapPath').serializeArray());
            var validationFlag      =       smp_obj.validatingForm();
            console.log( 'validation : ' , validationFlag.length );
            
            
            
            if( !validationFlag.length ){

                $.ajax({
                    type    :   'post',
                    url     :   BASE_URL+'storeServerPath',
                    data    :   formdata,
                    success :   function ( response ) {

                        if( response.status == 1 ){

                            window.location.href= BASE_URL+response.params.redirectUrl;
                            showNotify( response.errMsg , 'success' );

                        }else{
                            showNotify( response.errMsg , 'danger' );
                        }

                    }
                });

            }
            
        });
        
        $(document).delegate('tr[class^="rowwise_more_"]', "mouseover", function(){
            return false;
            var flagCheck       =       false;
            var elemColn        =       $(this).find('td').find(":text,:password");
            elemColn.each(function(){
                if( $(this).val() !== '' )
                    flagCheck = true;
            });
             
             if( flagCheck )
                $(this).parent().find('td:nth-child(11)').find('.addClear').show();
            
        });
        
        $(document).delegate('tr[class^="rowwise_more_"]', "mouseleave", function(){
            return false;
            $('.addClear').hide();
        });
        
        
        $(document).delegate("#resetServerPathForm", "click", function(event){
            $('.newRowInsert').remove();
            $('.dummyna,.rowdummy').val('');
            $('.original_na').val('NA');
            $('.ace').prop( 'checked' , false );
        });
        
        
        var delElem = '<div class="col-md-12"><div class="col-md-12"><button class="btn btn-minier btn-danger btn-round delete_fileshare"> Delete (-)</button></div></div>';
        function clone_Tr(that,tbodyID){
            
            var stageid = $(that).attr("data-stageid");
            var clonedRow = jQuery(that).parents('tr[class^=rowwise_more_]').clone();
            
            $(clonedRow).find('td:nth-child(1)').html('');
            $(clonedRow).find('th:nth-child(1)').html('');
            $(clonedRow).find('td:nth-child(2)').html('');
            $(clonedRow).find('td:nth-child(3)').html('');
            $(clonedRow).find('td:nth-child(3)').html(delElem);
            $(clonedRow).find('input').val('');
            $(clonedRow).find('select').val('');
            $(clonedRow).find('select option:nth-child(1)').attr('selected', 'selected')
            $(clonedRow).hide();
            $(clonedRow).attr( 'class' , 'newRowInsert');
            
            $(tbodyID + stageid).append(clonedRow);
            $(clonedRow).show('slow');
            
        }

        jQuery('.more_btn_source').click(function () {clone_Tr(this,"#src_row_tr");});
        jQuery('.more_btn_work').click(function () {clone_Tr(this,"#work_row_tr");});
        jQuery('.more_btn_destination').click(function () {clone_Tr(this,"#des_row_tr");});

        $(document).delegate('.delete_fileshare' , 'click', function () {
            $(this).parent().parent().parent().parent().remove();
        });

        jQuery("#showHideAll").click(function(){	
            if ($("#showHideAll").is(':checked')){ 
                jQuery("input[name^=passwordsrc],input[name^=passwordwp],input[name^=passworddes]").prop("type", "text");   
            }else{ 
                jQuery("input[name^=passwordsrc],input[name^=passwordwp],input[name^=passworddes]").prop("type", "password");
            } 
        }); 
        
	jQuery("#fillEmptyField").click(function(){	
            
            if ($("#fillEmptyField").is(':checked')){ 
                
                var elemColn    =       $(":text[value=''],:password[value='']");
                elemColn.each(function(){
                    $(this).val( 'NA' );
                    $(this).addClass( 'dummyna' );
                });
                
                $('.row_wise_na').prop( 'checked' , true );
                
            }else{ 
                $('.dummyna').val( '' );
                $('.row_wise_na').prop( 'checked' , false );
            } 
            
        }); 
	
        jQuery(document).delegate('.row_wise_na' , 'click' ,  function(){
            
            var index = $(this);
            var parentRwFind        =       $(index).parent().parent().parent();
            
            if( $(index).is(':checked') ){
                 
                var elemColn    =       $(parentRwFind).find(":text[value=''],:password[value='']");
                    elemColn.each(function(){
                    $(this).val( 'NA' );
                    $(this).addClass( 'dummyna rowdummy' );
                });
                
            }else{
                
                $(parentRwFind).find('.rowdummy').val( '' );
                
                 var elemColn    =       $(parentRwFind).find(":text[value='NA'],:password[value='NA']");
                    elemColn.each(function(){
                    $(this).attr( 'value' , '' );
                    $(this).addClass( 'original_na' );
                });
                
            }
            
        });
        
        $(".animsition-overlay").animsition({
            inClass: 'overlay-slide-in-bottom',
            outClass: 'overlay-slide-out-top',
            inDuration: 1500,
            outDuration: 800,
            linkElement: '.animsition-link',
            // e.g. linkElement: 'a:not([target="_blank"]):not([href^="#"])'
            loading: false,
            loadingParentElement: 'body', //animsition wrapper element
            loadingClass: 'animsition-loading',
            loadingInner: '<i class="fa fa-spinner fa-spin spin-normal"></i>', // e.g '<img src="loading.svg" />'
            timeout: false,
            timeoutCountdown: 5000,
            onLoadEvent: true,
            browser: [ 'animation-duration', '-webkit-animation-duration'],
            // "browser" option allows you to disable the "animsition" in case the css property in the array is not supported by your browser.
            // The default setting is to disable the "animsition" in a browser that does not support "animation-duration".
            overlay : true,
            overlayClass : 'animsition-overlay-slide',
            overlayParentElement : 'body',
            transition: function(url){ window.location.href = url; }
        });
        
        var workflowChg = document.getElementById("workflow_id");

        workflowChg.onchange = function() {
          if (this.selectedIndex !== 0) {
            window.location.href = this.value;
          }
        };

    });
    
    
});