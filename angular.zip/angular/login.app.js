var ngApp = angular.module('ngApp', []);

/*
 *  Forgot Password Directive.
 *  It will show a form to retrieve password.
 */

ngApp.directive("forgotPwd", function () {
	return {
		restrict : "E",
		template : '<div class="forgot-box visible widget-box no-border" ng-hide="showForget">'+
					'<div class="widget-body">'+
						'<div class="widget-main">'+
							'<h4 class="header red lighter bigger">'+
								'<i class="ace-icon fa fa-unlock"></i>'+
								'&nbsp;Retrieve Password'+
							'</h4>'+

							'<div class="space-6"></div>'+
							'<p>Enter your email and to receive instructions</p>'+

							'<form>'+
								'<fieldset>'+
									'<label class="block clearfix">'+
										'<span class="block input-icon input-icon-right">'+
											'<input type="email" class="form-control" placeholder="Email" />'+
											'<i class="ace-icon fa fa-envelope"></i>'+
										'</span>'+
									'</label>'+

									'<div class="clearfix">'+
										'<button type="button" class="width-35 pull-right btn btn-sm btn-danger">'+
											'<i class="ace-icon fa fa-lightbulb-o"></i>'+
											'<span class="bigger-110">Send Me!</span>'+
										'</button>'+
									'</div>'+
								'</fieldset>'+
							'</form>'+
						'</div>'+

						'<div class="toolbar center">'+
							'<a ng-click="showLoginForm()" class="back-to-login-link pointer">'+
							'Back to login'+
							'<i class="ace-icon fa fa-arrow-right"></i>'+
							'</a>'+
						'</div>'+
					'</div>'+
				'</div>'
	};
});

/*
 *  Change password Directive
 *  it will shown up to user to update their creadentials every 3 months once.
 *   *  
 */

ngApp.directive("chgPwdForm" , function(){
    
    return {
        restrict    :   "E" , 
        template    :   '<form name="frmChange" method="post" action="" onSubmit="return validatePassword()">'
                            +'<div style="width:500px;">'        
                            +'<div class="message"></div>'
                            +'<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" class="tblSaveForm">'
                            +'<tr class="tableheader">'
                            +'<td colspan="2">Change Password</td>'
                            +'</tr>'
                            +'<tr>'
                            +'<td width="40%"><label>Current Password</label></td>'
                            +'<td width="60%"><input type="password" name="currentPassword" class="txtField"/><span id="currentPassword"  class="required"></span></td>'
                            +'</tr>'
                            +'<tr>'
                            +'<td><label>New Password</label></td>'
                            +'<td><input type="password" name="newPassword" class="txtField"/><span id="newPassword" class="required"></span></td>'
                            +'</tr>'                
                            +'<td><label>Confirm Password</label></td>'
                            +'<td><input type="password" name="confirmPassword" class="txtField"/><span id="confirmPassword" class="required"></span></td>'
                            +'</tr>'
                            +'<tr>'
                            +'<td colspan="2"><input type="submit" name="submit" value="Submit" class="btnSubmit"></td>'
                            +'</tr>'
                            +'</table>'
                            +'</div>'
                        +'</form>' 
        };
    
});

/*
 *  Login Form Directive.
 *  It will show a form to enter user credentials to login.
 */

ngApp.directive("loginForm", function() {
    return {
		restrict : "E",
                template : '<div class="login-box visible widget-box no-border" ng-show="showLogin">'+
					'<div class="widget-body">'+
						'<div class="widget-main">'+
							'<h4 class="header blue lighter bigger">'+
							'<i class="ace-icon fa fa-sign-in green"></i>'+
							'&nbsp;Please Enter Your Information'+
							'</h4>'+

							'<div class="space-6"></div>'+

							'<div ng-show="loginCheck" class="alert alert-danger" id="error_msg" >{{loginError}}</div>'+
							'<form ng-submit="submitData()" method="post" id="loginForm" >'+
								'<fieldset>'+
									'<label class="block clearfix">'+
										'<span class="block input-icon input-icon-right">'+
										'<select name="domain_type" id="domain_type" class="form-control" required">'+
                                                                                '<option value="spi">SPI-GLOBAL</option><option value="spidom">SPIDOM</option><option value="magnus">MAGNUS</option></select>'+
										'</span>'+
									'</label>'+
                                                                        '<label class="block clearfix">'+
										'<span class="block input-icon input-icon-right">'+
										'<input type="text" class="form-control" ng-model="userName" required placeholder="Username" />'+
										'<i class="ace-icon fa fa-user"></i>'+
										'</span>'+
									'</label>'+

									'<label class="block clearfix">'+
										'<span class="block input-icon input-icon-right">'+
										'<input type="password" class="form-control" ng-model="pwd" required placeholder="Password" />'+
										'<i class="ace-icon fa fa-lock"></i>'+
										'</span>'+
									'</label>'+

									'<div class="space"></div>'+

									'<div class="clearfix">'+
										'<label class="inline">'+
											'<input type="checkbox" class="ace" name="remember_me" />'+
											'<span class="lbl"> Remember Me</span>'+
										'</label>'+

										'<button type="submit" class="width-35 pull-right btn btn-sm btn-primary" ng-model="subBtn" ng-disabled="subBtnDisabled" id="loginSubmit" >'+
											'<i class="ace-icon fa fa-key"></i>'+
											'<span class="bigger-110">Login</span>'+
										'</button>'+
									'</div>'+

									'<div class="space-4"></div>'+
								'</fieldset>'+
							'</form>'+

						'</div>'+

						'<div class="toolbar clearfix">'+
							'<div>'+
								'<a ng-click="showForgotPwd()" class="pointer forgot-password-link">'+
									'<i class="ace-icon fa fa-arrow-left"></i>'+
									'I forgot my password'+
								'</a>'+
							'</div>'+
						'</div>'+
					'</div>'+
				'</div>'
    };
});

/*
 *  Login Controller
 *  This controller contains all the login / forgot password related methods.
 */

ngApp.controller('ngController', function ($scope, $http , $timeout ) {
    
	$scope.showLogin        =   true;
        $scope.subBtnDisabled   =   false;
        $scope.showChgpwd       =   false;
        $scope.showForget       =   true;
        
	$scope.showForgotPwd    =   function() {
            
            $scope.showLogin    =   false;
            $scope.showForget  =   false;
           
	};
        
	$scope.showLoginForm    =   function() {
            $scope.showLogin    =   true;
            $scope.showChgpwd   =   false;
            $scope.showForget  =   true;
	};
        
        $scope.showPwdChgForm    =   function() {            
            $scope.resetForm();
            $scope.showLogin    =   false;
            $scope.showChgpwd   =   true;                    
	};
        
        $scope.resetForm            =       function( ){
            
            $('#currentPassword').val('');
            $('#newPassword').val('');
            $('#confirmPassword').val('');
            $( '.message_help' ).html( '' );
            //$( '.message' ).html( '');
        };
        /*
         * 
         * @returns {Boolean}
         */
        $scope.updateBtnDisabled  = false;
        
        $scope.storeValidatedPaswords   =   function( inp ){
            
            $scope.updateBtnDisabled       =   true;
            
            $http.post( BASE_URL+"updateExpiredCredentials", inp ).then(function mySuccess(response) {
                
                if(response.data.status  ==  1) {                    
                    
                    $scope.resetForm();
                    $( '.message' ).css({'color' : 'green'});
                    $( '.message' ).html( response.data.errMsg );
                    $scope.updateBtnDisabled       =   false;    
                    $('.loadingupdate' ).fadeOut(500);
                    $('.updatesuccess' ).fadeIn(500);
                   
                    $( '.message' ).addClass( 'blink' );
                    
                    $timeout( function(){
                        $scope.showLoginForm(); 
                        $('.forgot-box').hide();
                    }, 2000 );
                     
                    $scope.subBtnDisabled   =   false;     
                    
                    
                } else { 
                    
                    $('.loadingupdate' ).fadeOut(500);
                    $scope.updateBtnDisabled       =   false;
                    $( '.message_help' ).html( response.data.errMsg );
                    
                }
                
            }, 
            function myError(response) {
                $scope.updateBtnDisabled       =   false;
            });	
            
            
        };
       
	/*
	 *  Login Method
	 *  This method pass the login credentials to login method and get the response.
	 *  Based on the response, it will navigate the user to dashboard screen or throw an error.
	 */
        
        $scope.domaintype = '';
        
        $scope.submitData   =   function () {
            
            var domaintype_val  =   document.getElementById('domain_type').value;
            $scope.domaintype = domaintype_val;
            
            if(domaintype_val   ==  "" || domaintype_val    ==  undefined){
                $scope.loginCheck   =   true;
                $scope.loginError   =   "Login domain value is not found";
                return false;
            }else{
                $scope.loginCheck   =   false;
            }
            var passDec   =  encodeURIComponent(window.btoa($scope.pwd));
            var inp         =   {
                                    domain_type :   domaintype_val,
                                    user_name   :   $scope.userName,
                                    password    :   passDec
                                };
            $scope.loginCheck       =   false;
            $scope.loginError       =   "";
            $scope.subBtnDisabled       =   true;
            
            $http.post(BASE_URL+"login", inp).then(function mySuccess(response) {
                
                if(response.data.msg    ==  "success" ) {
                    
                    window.location.href    =   BASE_URL+"dashboard";    
                    
                } else if( response.data.status == 3 ){
                   $('.forgot-box').show(); 
                   $scope.showPwdChgForm();
                    
                }else {
                    
                    $scope.loginCheck       =   true;
                    $scope.loginError       =   response.data.errMsg;
                    $scope.subBtnDisabled   =   false;
                    
                }
                
            }, 
            function myError(response) {
                $scope.subBtnDisabled       =   false;
            });	
            
        };
          
           
        $scope.showFormErrors       =       function( errors ){
            
            for (var property1 in errors) {
               
                $( '.'+property1+'_help' ).text( errors[property1] );
                $( '.'+property1+'_help' ).parents('.form-group').addClass('has-error');
            }
            
            $('.loadingupdate' ).fadeOut(500);
            
        };
        
        $scope.removeErr        =   function(){
            
            var errors = { 'newpwd' : ''  ,'cnfpwd' : ''  ,'curpwd' : ''  };
            for (var property1 in errors) {
                $( '.'+property1+'_help' ).text( errors[property1] );
                $( '.'+property1+'_help' ).parents('.form-group').removeClass('has-error');
            }
            $('.message').html('');
            $( '.message_help' ).html( '' );
        };
        
        //$scope.showFormErrors( { 'cnfpwd' : 'Required Field Validation Error!' , 'newpwd' : 'Required Field Validation Error!' } );
       
        $scope.updateValidPassword     =       function() {
            
            $scope.removeErr();
           
            var currentPassword,newPassword,confirmPassword = true;
            
            var username            =   $scope.userName;
            var domaintype          =   $scope.domaintype;
            currentPassword     =   document.frmChange.currentPassword;
            newPassword         =   document.frmChange.newPassword;
            confirmPassword     =   document.frmChange.confirmPassword;
            
            $('.loadingupdate' ).fadeIn(500);
            
            var output  = false;
            
            if(!currentPassword.value) {
                $scope.showFormErrors( {  'curpwd' : 'Required field validation error!'} );
                currentPassword.focus();
                output = false;
            }
            else if(!newPassword.value) {
                $scope.showFormErrors( {  'newpwd' : 'Required field validation error!'} );
                newPassword.focus();
                output = false;
            }
            else if(!confirmPassword.value) {
                $scope.showFormErrors( {  'cnfpwd' : 'Required field validation error!'} );
                confirmPassword.focus();
                output = false;
            }else if( newPassword.value == confirmPassword.value && newPassword.value == currentPassword.value){
                $scope.showFormErrors( {  'curpwd' : 'All password should not be same!'} );
                currentPassword.focus();
                output = false;
            }else if( newPassword.value != "" && newPassword.value == confirmPassword.value) {

                if( newPassword.value.length < 8 ) {
                    $scope.showFormErrors( {  'newpwd' : 'Password must contain at least eight characters!'} );
                    newPassword.focus();
                    return false;
                }

                re = /[a-z]/;
                if(!re.test( confirmPassword.value) ) {
                    $scope.showFormErrors( {  'newpwd' : 'password must contain at least one lowercase letter (a-z)!'} );
                    confirmPassword.focus();
                    return false;
                }

                re = /[A-Z]/;                    
                if(!re.test( confirmPassword.value ) ) {
                    $scope.showFormErrors( {  'newpwd' : ' password must contain at least one uppercase letter (A-Z)!'} );
                    confirmPassword.focus();
                    return false;
                }
                
                re = /[0-9]/;
                if(!re.test( confirmPassword.value ) ) {
                    $scope.showFormErrors( {  'newpwd' : 'password must contain at least one number (0-9)!'} );
                    confirmPassword.focus();
                    return false;
                }

                //var regularExpression = /(?=.*?[#?!@$%^&*-)/;
                var regularExpression = /(?=.*?[#?!@$%^&*-])/;


                if(!regularExpression.test( newPassword.value ) ) {
                    newPassword.focus();
                    $scope.showFormErrors( {  'cnfpwd' : 'password must contain at least one special char ([#?!@$%^&*-)'} );
                    
                    return false;
                    
                }else{
                    
                    //proceed update process
                    var input         =   {
                                            username    :   username , 
                                            curpass     :   document.getElementById('currentPassword').value,
                                            newpass     :   document.getElementById('newPassword').value ,
                                            cnfpass     :   document.getElementById('confirmPassword').value ,
                                            domain_type :   domaintype
                                        };
                                            
                    console.log( input );
                    console.log( 'ready to initiate the update pass cred' );
                    
                    $scope.storeValidatedPaswords( input );
                    
                }
                
            
            }else if(newPassword.value != confirmPassword.value) {
                
                newPassword.value       =   "";
                confirmPassword.value   =   "";
                $scope.showFormErrors( {  'cnfpwd' : 'Password mismatch error occured!'} );
                newPassword.focus();
                output = false;
                
            }

            
            
            return output;
            
        }
        
        function confValidationRule( inpstr , id ){
            
            var re;
            
            //var currentPassword     =   document.frmChange.currentPassword;
            //var newPassword         =   document.frmChange.newPassword;
            //var confirmPassword     =   document.frmChange.confirmPassword;
            
            re = /[0-9]/;
            if(!re.test( inpstr ) ) {
                if( id == 1 )
                    $scope.showFormErrors( {  'newpwd' : 'password must contain at least one number (0-9)!'} );
                if( id == 2 )
                    $scope.showFormErrors( {  'cnfpwd' : 'password must contain at least one number (0-9)!'} );
                ////confirmPassword.focus();
                return false;
            }

            re = /[a-z]/;
            if(!re.test( inpstr) ) {
                if( id == 1 )
                $scope.showFormErrors( {  'newpwd' : 'password must contain at least one lowercase letter (a-z)!'} );
                if( id == 2 )
                $scope.showFormErrors( {  'cnfpwd' : 'password must contain at least one lowercase letter (a-z)!'} );
                //confirmPassword.focus();
                return false;
            }

            re = /[A-Z]/;                    
            if(!re.test( inpstr ) ) {
                if( id == 1 )
                $scope.showFormErrors( {  'newpwd' : ' password must contain at least one uppercase letter (A-Z)!'} );
                if( id == 2 )
                $scope.showFormErrors( {  'cnfpwd' : ' password must contain at least one uppercase letter (A-Z)!'} );
                //confirmPassword.focus();
                return false;
            }

            //var regularExpression = /(?=.*?[#?!@$%^&*-)/;
            var regularExpression = /(?=.*?[#?!@$%^&*-])/;


            if(!regularExpression.test( inpstr ) ) {
                //newPassword.focus();
                if( id == 1 )
                    $scope.showFormErrors( {  'newpwd' : 'password must contain at least one special char ([#?!@$%^&*-)'} );
                if( id == 2 )
                    $scope.showFormErrors( {  'cnfpwd' : 'password must contain at least one special char ([#?!@$%^&*-)'} );
                return false;

            }
            
            var regularExpression = /(?=.*?[(\"\':;`~|\\/)])/;

            if(regularExpression.test( inpstr ) ) {
                //newPassword.focus();
                if( id == 1 )
                    $scope.showFormErrors( {  'newpwd' : 'Avoid unwanted special chars ( \/\\`~:\";\',+=| )'} );
                if( id == 2 )
                    $scope.showFormErrors( {  'cnfpwd' : 'Avoid unwanted special chars ( \/\\`~:\";\',+=| )'} );
                return false;

            }
                
            return true;
            
        }
        
        $(document).ready(function(){  
        
            $('#newPassword,#confirmPassword').bind("blur", function () {
                var elmname     =       $(this).attr('name');
                var id;
                if( elmname == 'newPassword' ){
                    id      =   1;
                }
                if( elmname == 'confirmPassword' ){
                    id      =   2;
                }
                
                var inputstr        =       $(this).val();               
                var currentPassword1     =   document.frmChange.currentPassword;       
                
                if( inputstr.length > 3 && currentPassword1.value != "" ){
                    if(  confValidationRule( inputstr , id ) ){
                        
                    }else{
                        
                    }
                }
                
            });
            
            $('#newPassword,#confirmPassword').bind("keyup", function () {
                
                var tempvar     =   $( this ).val();
                
                if( tempvar.length > 1 ){
                    
                    var errors = { 'newpwd' : ''  ,'cnfpwd' : ''  ,'curpwd' : ''  };

                    for (var property1 in errors) {
                        $( '.'+property1+'_help' ).text( errors[property1] );
                        $( '.'+property1+'_help' ).parents('.form-group').removeClass('has-error');
                    }
                    
                }
                
            });
            
            
            
        });
        
     
});