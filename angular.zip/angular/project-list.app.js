/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ($scope, $http) {
   
    $scope.userId = 0;
    $scope.projectList = [];
    $scope.showProject = false;

    $scope.menuParent = 'Project List';
    $scope.menuChild = 'Project List';
    /*
     *  This method navigate the user to the setup page
     *  User click project from the project list, this method will invoke.
     */
    $scope.gotoProjetSetup = function(jobID){
            window.location.href=BASE_URL+"pre-production/tps-setup/"+jobID;
    };
    /*
     *  Show Project List
     *  This method pass the user id, team id of the logged in user and get the list of projects for this user.
     */
    $scope.showProjectList = function() {
            $scope.projectList = [];
            var inp = {	user_id : '', team_id : ''};
            console.log(inp);	
            $http.post(API_URL+"getProjectList", inp) .then(function mySuccess(response) {
                    console.log(response.data.data);	
                    $scope.projectList = response.data.data;

                    $scope.vm = {};
                    $scope.vm.dtOptions = {};
            }, 
            function myError(response) {
                     console.log(response);
            });			
    };
    $scope.showProjectList();

});