/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */


ngApp.controller( 'productionLocation' , function( $scope , $http ){
    
    //console.log( 'Am production Location Controller ...' );    
    
    $scope.getPrdlinfo        =       function(){
        
        $scope.prdLocList  =   null;
        
        $http.get( BASE_URL+"getProductionLocation" ) .then(
                
             function mySuccess( response ){  
                 $scope.prdLocList   =   response.data.locations; 
             } ,              
             function myError( response ){ 
             
             }
                  
        );
    }
    
    $scope.getPrdlinfo();
    

});

