/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('ngController', function ( $scope, $http ,$compile, $window ,  $timeout ,DTOptionsBuilder, DTColumnBuilder) {
	
    $scope.userId = 0;
    $scope.projectList = []; 
    $scope.Checkout =   false;
    $scope.showProject = false;
    $scope.menuParent   =   'Pre-Production';
    $scope.menuChild    =   'SplitProcess';
    
    $scope.downloadButtonDisabled     =   false;      
    $scope.downloadButtonText     =   "Download Raw Files";
    
    $scope.openFolderButtonText   =   "Open Folder";
    
    $scope.checkinButtonDisabled     =   true;      
    $scope.checkinButtonText     =   "Check-in";
    
    $scope.submitButtonDisabled     =   true;      
    $scope.submitButtonText     =   "Submit";
    $scope.savechapterdisabled  =   false;
    $scope.noOfAttemptsToCheckIndesign  =   10;
    
    /*
     *  This method navigate the user to the setup page
     *  User click project from the project list, this method will invoke.
     */
    
    $scope.gotoProjetSetup = function(jobID){
	window.location.href=BASE_URL+"pre-production/tps-setup/"+jobID;
    };
        
    $scope.currentuserid    =   '';
    $scope.contentloadtimer =   1;
    $scope.showProjectList  =   function(){
	
        $scope.projectList  =   [];
		
	var inp     =   { 
                            user_id : '' , 
                            team_id : ''
                        };
	
        $http.post(API_URL+"getSplitProjectList", inp) .then(
            function mySuccess(response) {
                $scope.projectList = response.data.data;
                $scope.currentuserid    = 	response.data.user_id;
                $scope.vm = {};
                $scope.vm.dtOptions = {};
            },function myError(response) {
                if($scope.contentloadtimer    <  10){
                    $scope.showProjectList();
                }
                if($scope.contentloadtimer    ==  10){
                    showNotify('Kindly reload page error occured.'  , 'danger' );
                    return false;
                }
            });	
            $scope.contentloadtimer++;
    };
    
        /*$scope.showProjectList      =   function () {

                $scope.dtOptions    =   DTOptionsBuilder.newOptions()
                                        .withOption('ajax', {
                                                //dataSrc: "data",
        //                                        data: ,
                                                url: BASE_URL + 'getSplitProjectList',
                                                type: 'POST'
                                        })
                                        .withDataProp('data')// parameter name of list use in getLeads Fuction
                                        .withOption('createdRow', function(row, data, dataIndex) {
                                            // Recompiling so we can bind Angular directive to the DT
                                            $compile(angular.element(row).contents())($scope);
                                        })
        //                                .withOption('rowCallback', rowCallback)
        //                                .withOption('drawCallback', drawCallback)
                                        /*.withOption('columnDefs', { "visible": false, "targets": 1 })*/
                                       /* .withOption('stateSave', false)
                                        .withOption('processing', true) // required - for show progress bar
                                        .withOption('serverSide', true)// required - for server side processing
                                        .withOption('responsive', true)// required - for server side processing
                                        .withOption('paging', true)// required
                                        .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                                        .withDisplayLength(10) //// Page size
                                        .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                                        .withOption('order', [[0, 'desc'], [0, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


                $scope.dtColumns    =   [
                                            DTColumnBuilder.newColumn('BOOK_ID').withTitle('Book Id'),
                                            DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Book Title'),
                                            DTColumnBuilder.newColumn('PM_NAME').withTitle('PM Name'),
                                            DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created date'),
                                            DTColumnBuilder.newColumn('QUERY').withTitle('Action').notSortable(),
                                            DTColumnBuilder.newColumn('SPIKE').withTitle('Job Sheet View').notSortable()
                                        ];

                $scope.dtInstance   =   {};
        };*/
        
        $scope.showProjectList();
    
    $scope.splitCheckout    =   function( job , cur ){
        
        var bt_ele_id       =   '#Checkout_'+job.JOB_ID;
        var checkxout_btn_ele   =   document.querySelector( bt_ele_id );
        angular.element(checkxout_btn_ele).addClass('disabled');
        
        var result          =   true;
            if(result) {
               
            var inp =   { 
                            user_id :   '' , 
                            job_id  :   job.JOB_ID 
                        };

            $http.post( API_URL+"startSplitProcess", inp    ) .then(
                function mySuccess(response) {

                    var resObj  =   response.data;
                    if( resObj.status   ==  1 ){

                        if( resObj.params.token_key != null ){                                
                           window.location.href        =       BASE_URL+"splitCheckout/"+job.JOB_ID+"/"+job.ROUND+"/split/"+resObj.params.token_key;                                        
                        }else{                                
                           window.location.href        =       BASE_URL+"splitCheckout/"+job.JOB_ID+"/"+job.ROUND+"/split";                                  
                        }

                    }else{                            
                            showInfo( resObj.msg , resObj.errMsg );
                            angular.element(checkxout_btn_ele).removeClass('disabled');
                    }                        

                },function myError(response) {  
                        showNotify( response.data.errMsg  , 'danger' );
                });

        }else{
            angular.element(checkxout_btn_ele).removeClass('disabled');   
        }
    }
    
    /*
     *  Check RMI Status
    *  This method check the RMI status for the selected folios.
    */
   
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    };    
    
    /*
     *  Drive Open
     */
    
    $scope.openDrive = function( path , opt ) {
         
       // bootbox.confirm("Are you sure to open this book working directive ?", function(result) {
        var result   =   true;
        $scope.opendrivebuttondisabld   =   true;
            if( result ){
                
                $scope.openFolderButtonText     =   "In Progress";
                var method = "";
                showLoader('Please wait while opening...');
                
                method = "doOpenDriveServer";

                var inp = {

                           filePath : path ,
                           methodName : method  ,
                           processname  :   'checkout'
                           
                };

                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                    if(response.data[0].rmiId > 0) {
                        
                        var attempt = 5;
                        $scope.checkFhStatus(response.data[0].rmiId, attempt, opt);
                        
                        
                    } else {
                        hideLoader();
                        showMessage('Download Status', 'Having problem in insert data.', 'success');
                    }
                    
                    
                },function myError(response) {
                    
                        showNotify( response.data  , 'danger' );
                    
                });
                
                $timeout(function () {
                    $scope.openFolderButtonText     =   "Open Folder";
                    $scope.submitButtonDisabled     =   false;      
                    $scope.checkinButtonDisabled     =   false;      
                }, 2000); 
                $scope.opendrivebuttondisabld       =   false;    
            }
       // });    
        
    };
    
    /*
     *  Checkin with close userwork folder
    */
	// close user work folder function starts here
	$scope.closeFolder = function( srcFolder ) {
		 method = "closeFolderServer";
                var inp = {
                           filePath : srcFolder ,
                           methodName : method  
                };
                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {
                  return true;
                },function myError(response) {
                    showNotify( response.data  , 'danger' );                    
                });
	}
	// close user work folder function ends here
    $scope.splitCheckin =   function( job_id, method , src , dest , ext , del, srcFolder  ){
		$scope.closeFolder(srcFolder);/* userwork folder close */
       // bootbox.confirm("Are you sure to proceed with this ?", function(result) {
           var result   =   true;
            if( result ){
                
                 $scope.checkinButtonText     =   "In Progress";
                 showLoader('Please wait while copying files...');
                 
                 var inp = {
                    method_name    :  method , 
                    src_path  :   src,
                    dest_path :   dest,
                    ext       :   ext ,
                    isdelete  :   del ,
                    job_id    :   job_id
                };
              
                $http.post( API_URL+"splitCheckin" , inp ) .then(function mySuccess(response) {
                    
                    hideLoader();
                    
                    if( response.data.status ){
                         
                        window.location.href    =    BASE_URL+'preproduction/split-job-list';
                         
                    }else{
                        showLoader( response.data.errMsg );
                    }
                    
		}, 
		function myError(response) {
                    
                        showLoader( response.data.errMsg );
                    
		});
                
                $timeout(function () {
                    
                    $scope.checkinButtonText     =   "Check-in";
                    $scope.checkinButtonDisabled = true;
                    
                }, 2000); 
                
            }
            
        //});
       
    }
    
    $scope.spitcomplete    =   true;
    $scope.jobId           =   "";
    $scope.bookidshow      =   "";
   
    $scope.splitComplete   =   function( job_id , method , src , dest , ext , del )
    {
        $scope.chapterlist  =   [];
        $scope.partlist     =   [];
        $scope.existchapterlist =   [];
        $scope.showallresponse  =   '';
        $scope.heightofnotexist     =   0;
        $scope.heightofexistchapter     =   0;
        $scope.shownotavaiablechapter   =   '';
                $scope.savechapterdisabled  =   false;
                $scope.submitButtonText     =   "In Progress";
                showLoader('Please wait while copying files...');
                 var inp = {
                    method_name    :  method , 
                    src_path  :   src,
                    dest_path :   dest,
                    ext       :   ext ,
                    isdelete  :   del ,
                    job_id    :   job_id
                };
                
                var jobid       =   job_id;
                
                $http.post( API_URL+"splitCompleted" , inp ) .then(function mySuccess(response) {
                    
                    hideLoader();
                    
                    if( response.data.status == 1)
                    {
                        $scope.totalpage    =   false;
                        $scope.showallresponse  =   '';
                        $scope.arabic_page  =   "";
                        $scope.roman_page   =   "";
//                        $scope.chapterlist  =   response.data.chapternames;
                        $scope.chapterlist  =   Object.keys(response.data.chapternames).map(function(key) {
                            return response.data.chapternames[key];
                        });
  
                        $scope.chaptersequence  =   response.data.chaptersequence;
                        $scope.partsequence =   response.data.partsequence;
                        $scope.partlist     =   response.data.partnames;
                        $scope.esmlist     =   response.data.esm;
                        $scope.totalnoofchp =   response.data.totalpages;
                        if(response.data.totalpages >= 1)
                        {
                            $scope.heightofmodal    =   400;
                            $scope.saveChapterbutton    =   true;
                        }
                        else
                        {
                            $scope.heightofmodal    =   100;
                            $scope.saveChapterbutton    =   false;
                        }
                        $("#show-doopenfiles").click();
                        $scope.ChapterJobId =   response.data.jobID;
                        $scope.bookidshow   =   response.data.Book_id;
                        //angular.element(document.getElementById("submitbutton").remove());
                    }
                    if( response.data.status == 0)
                    {
                        $scope.spitcomplete =   true;
                        showNotify( response.data.msg  , 'danger' );
                    }
                    
		}, 
		function myError(response) {
                        $scope.spitcomplete =   true;
//                        showNotify( response.data.errMsg ,'danger');
		});
                
                 $timeout(function () {
                    
                    $scope.submitButtonText     =   "Submit";
                    
                }, 2000); 
            
     }
        
    $('#show-openfiles').on('hidden.bs.modal', function () 
    {
         $scope.submitButtonDisabled    =   false;
         $scope.existchapterlist        =   [];
    });
    
    $scope.doAddChapteritem     =   function( srcFolder)
    {        
		
		$scope.closeFolder(srcFolder); /* userwork folder close */
        $scope.savechapterdisabled  =   true;
        showLoader('Please wait while adding Chapters...');
        var chapternames            =   $('input[name="chapters[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
        var chapterfiles            =   $('input:hidden[name="chaptersfile[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
        var chapterpagecount        =   $('input[name="chapterspagecount[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
        var partnames               =   $('select[name="partnames[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
        var partselectednames       =   $('.getpartval').not(".softdelete").map(function(){return $(this).val();}).get();
        var getdeletedpart          =   $('.softdelete').map(function(){return $(this).val();}).get();
        var chaptersequence         =   $('input[name="chaptersequence[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
        var esm                     =   $('input[name="esm[]"]:checked').not(".softdelete").map(function(){return $(this).val();}).get();
        var chapterstitle            =   $('input[name="chapterstitle[]"]').not(".softdelete").map(function(){return $(this).val();}).get();
		var chaptTitle				 =  '0';
		
        var duplicatechapternum     =   [];
        var duplicatepartnum        =   [];
        var readchaptersequenceduplicate    =   $('.chpseq').not(".softdelete").map(function(){
            if($(this).val()){
                duplicatechapternum.push($(this).val());
            }
        });
        var readpartsequenceduplicate       =   $('.partseq').not(".softdelete").map(function(){
            if($(this).val()){
                duplicatepartnum.push($(this).val());
            }});
        
        var sorted_arr  =   duplicatepartnum.slice().sort();
        var partresults =   [];
        for (var i  =   0; i < sorted_arr.length - 1; i++) {
            if (sorted_arr[i + 1] == sorted_arr[i]) {
                partresults.push(sorted_arr[i]);
            }
        }
        
        var chpsorted_arr   =   duplicatechapternum.slice().sort();
        var chapterresults  =   [];
        for (var i  =   0; i < chpsorted_arr.length - 1; i++) {
            if (chpsorted_arr[i + 1] == chpsorted_arr[i]) {
                chapterresults.push(chpsorted_arr[i]);
            }
        }
        var deletedpartvalues   =   [];
        for (var i  =   0; i < getdeletedpart.length - 1; i++) {
            if (getdeletedpart[i] !=    '' && isNaN(getdeletedpart[i])) {
                deletedpartvalues.push(getdeletedpart[i]);
            }
        }
		
		 for (var i  =   0; i < chapterstitle.length - 1; i++) {
            if (chapterstitle[i] == '') {
				showNotify( "Chapter title should not be empty" , 'danger' );
				hideLoader();
				$scope.savechapterdisabled  =   false;
				 return false;
            }
        }
        
        if(chapterresults.length >=1 ){
            showNotify( "Chapter number should be uniqeue" , 'danger' );
            hideLoader();
            $scope.savechapterdisabled  =   false;
            return false;
        }
        
        if(partresults.length >=1 ){
            showNotify( "Part number should be uniqeue" , 'danger' );
            hideLoader();
            $scope.savechapterdisabled  =   false;
            return false;
        }
      
        var partnamecount   =   Object.values($scope.partlist);
        var     partvalue   =   [];
        if(partnamecount.length   >=  1){
            partvalue       =   partselectednames.filter(consmval => consmval.length == 0);
            if(partvalue.length   >=  1){
                 var r = confirm(" Chapter(s) not mapped to Part. Do you want to continue ");
				if (r == true) {
				
				} else {
					hideLoader();
					$scope.savechapterdisabled  =   false;
					return false;
				} 
		       
               
            }
        }
        
        var chaptercontainspace =   [];
        chaptercontainspace     =   chapternames.filter(val => val.indexOf(' ') >= 0);
        
        if(chaptercontainspace.length   >=  1){
            showNotify(chaptercontainspace.toString()+' ,Kindly remove unwanted space.', 'danger' );
            hideLoader();
            return false;
        }
        
        var differentpart   =   deletedpartvalues.filter(value => -1 !== partnames.indexOf(value));
        if(differentpart.length   >=  1){
            showNotify(deletedpartvalues.toString()+' has been removed but you are mapped part items '+differentpart.toString(), 'danger' );
            hideLoader();
            $scope.savechapterdisabled  =   false;
            return false;
        }
        
        var inp    =    {
                            job_id          :   $scope.ChapterJobId,
                            chapternames    :   chapternames ,
                            chapterfiles    :   chapterfiles ,
                            partnamesjob    :   partnames,
                            chaptersequence :   chaptersequence,
                            chapterpagecount:   chapterpagecount,
                            esm             :   esm,
                            chapterstitle   :   chapterstitle,
                            deletedpartvalues   :   deletedpartvalues,
                            partisavailornot:   (partvalue.length>=1?1:0)
                        }; 
        $http.post( BASE_URL+"doAddchaterInfo" , inp ) .then(function mySuccess(response)
        {    
            hideLoader();
            if(response.data.isPar == 1 && response.data.status == 1){
                $scope.closeFolder(srcFolder); /* userwork folder close */
                $('.modal-content').fadeOut(800);
                showNotify( response.data.msg , 'success' );
                $timeout( function(){ 
                     window.location.href    =    BASE_URL+'par_report/'+$scope.ChapterJobId;
                } , 4000 );
            }
            
            if(response.data.status == 1 && response.data.isPar == 0){
                $scope.closeFolder(srcFolder); /* userwork folder close */
                $('.modal-content').fadeOut( 800 );
                showNotify( response.data.msg , 'success');
                
                $timeout( function(){
                      window.location.href    =    BASE_URL+'preproduction/split-job-list';
                 } , 4000 );
                 
            }
            
            if( response.data.status == 0){
                
                showNotify( response.data.msg , 'danger' );
                
                $scope.savechapterdisabled  =   false;
                $scope.submitButtonDisabled =   false;
                
                if(response.data.notexistdata == 1)
                {
                    $scope.heightofnotexist     =   20;
                }
                if(response.data.notexistdata >= 1)
                {
                    $scope.heightofnotexist     =   80;
                }
                
                $scope.showallresponse  =   response.data.msg;
                $scope.shownotavaiablechapter  =   response.data.shownotavaiablechapter;
                
               // showNotify( response.data.errMsg  , 'danger' );
               
            }
        }, 
        function myError(response) {
            $scope.spitcomplete =   true;
            $scope.submitButtonDisabled     =   false;
            $scope.savechapterdisabled  =   false;
//            showLoader( 'Oops! Try again after sometimes.' );
        });
    }
	
	
    
    //delete popup chapter list
    $scope.deleteChapterItem    =   function(item){
        var getpartitemdelete   =   $("#deletechapter_"+item).attr('data-getchapteritem');
        var templateElement     =   '<i class="ace-icon fa fa-undo green fa-2x" data-getchapteritem='+"'"+getpartitemdelete+"'"+'  ng-click="revertChapterItem('+item+')" aria-hidden="true" id="deletechapter_'+item+'"></i>';
        if($scope.partlist.indexOf(getpartitemdelete)   !=  -1)
        {
            var removeindex     =   $scope.partlist.indexOf(getpartitemdelete);
            $scope.partlist.splice(removeindex, 1);  
        }
        
        var temp                =   $compile(templateElement)($scope);
        angular.element("#deletechapter_"+item).remove();
        angular.element("#revert_"+item).append(temp);
        angular.element("#chaptername_"+item).addClass('softdelete');
        angular.element("#chapterfilename_"+item).addClass('softdelete');
        angular.element("#partsname_"+item).addClass('softdelete');
        angular.element("#sequencename_"+item).addClass('softdelete');
        angular.element("#chapternumber_"+item).addClass('softdelete');
        $("#addnoaction_"+item).find('td').not('td:last').addClass('no-action-trigger');
        var numberofundeletechapter     =   [];
        if(angular.element("#sequencename_"+item).hasClass('chpseq'))
        {
            $('.chpseq').not('.softdelete').each(function(i)
            {
                $(this).val(i+1);
            });
        }
        else
        {
            $('.partseq').not('.softdelete').each(function(i)
            {
                $(this).val(i+1);
            });
        }
    }
    //revert delete item
    $scope.revertChapterItem    =   function(item){
        var getpartitemdelete   =   $("#deletechapter_"+item).attr('data-getchapteritem');
        var templateElement     =   '<i class="fa fa-times-circle red fa-2x" data-getchapteritem='+"'"+getpartitemdelete+"'"+'  ng-click="deleteChapterItem('+item+')" aria-hidden="true" id="deletechapter_'+item+'"></i>';
        if(getpartitemdelete.indexOf('PART')   !=  -1 || getpartitemdelete.indexOf('part')   !=  -1)
        {
            $scope.partlist.push(getpartitemdelete);
        }
        var temp                =   $compile(templateElement)($scope);
        angular.element("#deletechapter_"+item).remove();
        angular.element("#revert_"+item).append(temp);
        angular.element("#chaptername_"+item).removeClass('softdelete');
        angular.element("#chapterfilename_"+item).removeClass('softdelete');
        angular.element("#partsname_"+item).removeClass('softdelete');
        angular.element("#sequencename_"+item).removeClass('softdelete');
        angular.element("#chapternumber_"+item).removeClass('softdelete');
        $("#addnoaction_"+item).find('td').not('td:last').removeClass('no-action-trigger');
        
        if(angular.element("#sequencename_"+item).hasClass('chpseq'))
        {
            $('.chpseq').not('.softdelete').each(function(i)
            {
                $(this).val(i+1);
            });
        }
        else
        {
            $('.partseq').not('.softdelete').each(function(i)
            {
                $(this).val(i+1);
            });
        }
    }

    $scope.splitInputFileDownload =   function( job_id, method , src , dest , ext , del ){
       
       //bootbox.confirm("Are you sure to proceed with this ?", function(result) {
           showLoader('Please wait while copying files...');
           var result = true;
           
            var q_string        =       ( (location.pathname+location.search).substr(1) );
            var obj             =       q_string.split( '/' );
            var tokenkey        =       obj[obj.length - 1];;
           
            if( result ){
                
                $scope.downloadButtonText     =   "Download In Progress";
                
                var inp = {
                    method_name    :  method , 
                    src_path  :   src,
                    dest_path :   dest,
                    ext : ext ,
                    isdelete  : del ,
                    job_id : job_id , 
                    tokenkey    :   tokenkey
                };
                
                $http.post( API_URL+"splitInputFileDownload" , inp ) .then(function mySuccess(response) {
                
                    if(response.data.status == "success") {
			
                    } else {
                        
                        hideLoader();
			showNotify( response.data[0]['errMsg'] , 'danger' );
                        
                        return false;
                    }
                   
                    $timeout(function () {

                        $scope.downloadButtonDisabled     =   true;

                        $scope.downloadButtonText     =   "Download Completed";

                        angular.element('#openFolderBtn').trigger('click');
                        
                        hideLoader();
                     
                    }, 3000); 
                    
                    
                    
		}, 
		function myError(response) {
                    
                    showNotify( response.data.errMsg, 'danger' );
                    
                    
		});
                
                 
                    
            }
            
        //});
       
    }
    
    $timeout(function () {
        
        angular.element('#downloadButton').trigger('click');
        
        var isDownloaded    =       $("input[name='isTokenDownloaded']").val();
        if( isDownloaded == 2 ){
            $scope.checkinButtonDisabled    =       false;
            $scope.submitButtonDisabled     =       false;
        }
        
    }, 2000); 
    
    $scope.qmsspike                 =       function(jobId, userId, bookId,type)
    {
        if(type     ==  'qms')
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
            $('#iframeqms').attr('src',$scope.srciframepath);
        }
        else
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
            $('#iframespike').attr('src',$scope.srciframepath);
        }
    };
    
    $scope.showXMLInModal = function( jobId , round ){   
        
        var inp = { jobId: jobId };
        
        $('#show-edit').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');
	
        $http({
                url: API_URL + "getJobXMLInfo/"+jobId+'/'+round,
                method: 'GET',
             })
            .success(function(response) {
		$('#xmlContent').html(response);
            })
            .error(function(response) {
		console.log(response);
            });
    }
    
});