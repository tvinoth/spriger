/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile,$timeout, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    $scope.userId 	= 	'0';
    $scope.menuParent 	= 	'Pre-Production';
    $scope.menuChild 	= 	'Indexing';
    $scope.errorMsg 	= 	"";
    if(isNaN(getUrlParameter(1))) 
    {
        $scope.JobID 	= 	"";
    } 
    else 
    {
        $scope.JobID 	= 	getUrlParameter(1);
    }
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
    $scope.currentuserid    =   '';
    
    /*$scope.contentloadtimer =   1;
    $scope.getCucJobList    = 	function() 
    {
        $scope.cucjoblist   = 	[];
        $http.get(BASE_URL+"doIndexingjoblist") .then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
            }
            $scope.cucjoblist          = 	response.data.cucjoblist;
            $scope.userId               =       response.data.userId;
        }, 
        function myError(response) {
            if($scope.contentloadtimer    !==  10){
                $scope.getCucJobList();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
        });			
        $scope.contentloadtimer++;
    };
    
    if($scope.JobID     ==  ""){
        $scope.getCucJobList();
    }*/
    
    $scope.getCucJobList        =   function () {

            $scope.dtOptions    =   DTOptionsBuilder.newOptions()
                                    .withOption('ajax', {
                                            //dataSrc: "data",
    //                                        data: ,
                                            url: BASE_URL + 'doIndexingjoblist',
                                            type: 'POST'
                                    })
                                    .withDataProp('data')// parameter name of list use in getLeads Fuction
                                    .withOption('createdRow', function(row, data, dataIndex) {
                                        // Recompiling so we can bind Angular directive to the DT
                                        $compile(angular.element(row).contents())($scope);
                                    })
                                    .withOption('stateSave', false)
                                    .withOption('processing', true) // required - for show progress bar
                                    .withOption('serverSide', true)// required - for server side processing
                                    .withOption('responsive', true)// required - for server side processing
                                    .withOption('paging', true)// required
                                    .withPaginationType('full_numbers') //for get full pagination options // first / last / prev / next and page numbers
                                    .withDisplayLength(10) //// Page size
                                    .withOption('lengthMenu', [10, 25, 50, 100, 1000])
                                    .withOption('order', [[0, 'desc'], [0, 'desc']]);//withOption('aaSorting',[0,'asc']) for default sorting column // here 0 means first column	


            $scope.dtColumns    =   [
                                        DTColumnBuilder.newColumn('BOOK_ID').withTitle('Book Id'),
                                        DTColumnBuilder.newColumn('JOB_TITLE').withTitle('Book Title'),
                                        DTColumnBuilder.newColumn('PM_NAME').withTitle('PM Name'),
                                        DTColumnBuilder.newColumn('CREATED_DATE').withTitle('Created date')
                                    ];

            $scope.dtInstance   =   {};
    };

    if($scope.JobID     ==  ""){
        $scope.getCucJobList();
    }
        
    $scope.openchapterlistdetails   =   function(book)
    {
        $window.location.href       = 	BASE_URL+"doIndexinglist/"+book;
    }
    
    $scope.contentloadtimer =   1;
    $scope.getCucList 	= 	function() 
    {
        $scope.CucList 	= 	[];
        var inp         =       {jodId:$scope.JobID}
        $http.post(BASE_URL+"doIndexingchapterlist",inp) .then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error occured.'  , 'danger' );
            }
            $scope.CucList          = 	response.data.cuclist;
            $scope.currentuserid    = 	response.data.user_id;
            $scope.cuc              =   {};
            $scope.cuc.dtOptions    =   DTOptionsBuilder.newOptions().withOption('order', []);
        }, 
        function myError(response) {
            if($scope.contentloadtimer    <  10){
                $scope.getCucList();
            }
            if($scope.contentloadtimer    ==  10){
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
        });		
        $scope.contentloadtimer++;
    };
    
    if($scope.JobID     !=  ""){
        $scope.getCucList();
    }
    
	/*
	 *  Get Chapter file open
	 *  This method get all the active Book info from DB
	 */
    $scope.chapterinfodetails 	=   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,checkouttype) 
    {        
        showLoader('Please wait while checkout...');
        var inp             = 	{
                            metadataid  :   taskmetaid,
                            jobId       :   jobId,
                            Chapter     :   CHAPTER_NO,
                            bookid      :   BOOK_ID,
                            checkouttype:   checkouttype
                    };  
        
        var currentChapter  =   angular.element(document.getElementById("chapter_"+taskmetaid));
        $(currentChapter).find('button').attr('disabled','true');
        $http.post(BASE_URL + 'doIndexingCheckoutprocess', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(".alertdangershow").css('display','block');
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'warning' );
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                var attempt         =   1;
                var timesheetid     =   response.data.records[0].jobtimesheetid;
                var filehandlerid   =   response.data.rmID;
                $scope.checkfilestatusopenornot(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,checkouttype,attempt,timesheetid,filehandlerid);
            }
        }, 
        function myError(response) 
        {
            $(currentChapter).find('button').removeAttr('disabled','true');
        });
    };
    
    $scope.checkfilestatusopenornot     =   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,checkouttype,attempt,timesheetid,filehandlerid) 
    {           
        var currentChapter  =   angular.element(document.getElementById("chapter_"+taskmetaid));
        var inp             = 	{rmiID  :   filehandlerid,
                                typeofstatus   :    'Checkout'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
        {
            if(response.data.result     ==  500)
            {
                attempt++;
                if(attempt <= 5) {
                    $timeout( function(){ $scope.checkfilestatusopenornot(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,checkouttype,attempt,timesheetid,filehandlerid); }, 2000 );
                } else {
                    hideLoader();
                    $(currentChapter).find('button').removeAttr('disabled','true');
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if(response.data.result     ==  404)
            {
                hideLoader();
                $(currentChapter).find('button').removeAttr('disabled','true');
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if(response.data.result     ==  200)
            {
                currentChapter.remove();
                var templateElement     =   '<span id="removeall_'+taskmetaid+'"><div class="btn-group" id="chaptercheckin_'+taskmetaid+'"><button type="button" class="btn btn-warning btn-xs pointer"  ng-click="doCheckin('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+','+"'"+timesheetid+"'"+')">Checkin</button></div>&nbsp;&nbsp;&nbsp;<div class="btn-group" id="chaptersubmit_'+taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"   ng-click="doChapterProceed('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+','+"'"+timesheetid+"'"+')">Submit</button></div>&nbsp;&nbsp;&nbsp;<i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+taskmetaid+'" ng-click="doJobsheetView('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+')"></i>&nbsp;&nbsp;&nbsp;<i class="fa fa-folder-open-o pointer bigger-150 green fa-5x" aria-hidden="true" title="Open Folder" id="chapteropendrive_'+taskmetaid+'" ng-click="doChapterOpenDrive('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+')"></i><span>';   
                var temp                =   $compile(templateElement)($scope);
                angular.element(document.getElementById("checkinbutton_"+taskmetaid)).append(temp);
                hideLoader();
                showNotify( response.data.errMsg, 'success' );
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            $(currentChapter).find('button').removeAttr('disabled','true');
        });
    };
    
    $scope.doCheckin        =   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,jobtimesheetid)
    {
        var currentChapter  =   angular.element(document.getElementById("chaptercheckin_"+taskmetaid));
        var inp    = 	{
                                        metadataid  :   taskmetaid,
                                        jobId       :   jobId,
                                        Chapter     :   CHAPTER_NO,
                                        bookid      :   BOOK_ID,
                                        jobtimesheetid   :  jobtimesheetid
                                    };
        showLoader('Please wait while checkin...');  
        $(currentChapter).find('button').attr('disabled','true');
        $http.post(BASE_URL + 'doIndexingCheckinprocess', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                var checkintype         =   "old";
                var templateElement     =   '<div class="btn-group" id="chapter_'+taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"  ng-click="chapterinfodetails('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+','+"'"+checkintype+"'"+')">Checkout</button></div>';
                var temp                =   $compile(templateElement)($scope);
                angular.element(document.getElementById("removeall_"+taskmetaid)).remove();
                angular.element(document.getElementById("checkinbutton_"+taskmetaid)).append(temp);
                hideLoader();
                showNotify( response.data.errMsg  , 'success' );
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            $(currentChapter).find('button').removeAttr('disabled','true');
            showNotify( response.data.errMsg  , 'danger' );
        });
    };
    //final submit
    $scope.doChapterProceed 	=       function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID,jobtimesheetid)
    {
        showLoader('Please wait while Submit ...');
        var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+taskmetaid));
	var statusmessage   =   angular.element(document.getElementById("statuscomplete_"+taskmetaid));
        var inp             = 	{
                                metadataid  :   taskmetaid,
                                jobId       :   jobId,
                                Chapter     :   CHAPTER_NO,
                                bookid      :   BOOK_ID,
                                jobtimesheetid   :  jobtimesheetid
                            };
        $(currentChapter).find('button').attr('disabled','true');                    
        $http.post(BASE_URL + 'indexingCompleteprocess', inp)
        .then(function mySuccess(response) 
        {
            hideLoader();
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
            }
            if(response.data.result     ==  200)
            {
//                var templateElement     =   '<i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+taskmetaid+'" ng-click="doJobsheetView('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+')"></i>&nbsp;&nbsp;<i class="fa fa-eye pointer bigger-150 green fa-5x" aria-hidden="true" title="Cuc View" id="chaptercucview_'+taskmetaid+'" ng-click="doChapterCucview('+"'"+taskmetaid+"'"+','+"'"+jobId+"'"+','+"'"+CHAPTER_NO+"'"+','+"'"+BOOK_ID+"'"+')"></i>';     
                var templateElement     =   '<button type="button" class="btn btn-success btn-xs" title="Completed">Completed</button>';
                var temp                =   $compile(templateElement)($scope);
                angular.element(document.getElementById("removeall_"+taskmetaid)).remove();
                angular.element(document.getElementById("checkinbutton_"+taskmetaid)).append(temp);
                angular.element(document.getElementById("statuscomplete_"+taskmetaid)).text("Completed");
                $(currentChapter).find('button').removeAttr('disabled','true');
                showNotify( response.data.errMsg  , 'success' );
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            $(currentChapter).find('button').removeAttr('disabled','true');
        });
    }
    
    //open drive
    $scope.doChapterOpenDrive 	=       function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID)
    {
        showLoader('Please wait while Open Drive ...');
        var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+taskmetaid));
        var inp             = 	{
                                    metadataid  :   taskmetaid,
                                    jobId       :   jobId,
                                    Chapter     :   CHAPTER_NO,
                                    bookid      :   BOOK_ID
                                };   
        $http.post(BASE_URL + 'indexingOpendrive', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
                $(currentChapter).find('button').removeAttr('disabled','true');
            }
            if(response.data.result     ==  401)
            {
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  500)
            {
                hideLoader();
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  200)
            {
                var openattempt     =   1;
                var filehandlerid   =   response.data.rmID;
                $scope.checkfiledriveopenstatus(openattempt,filehandlerid);
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            //showMessage('Message', response.data.errMsg, 'error' );
            //showNotify( response.data.errMsg  , 'danger' );
        });
    }
    
    $scope.checkfiledriveopenstatus     =   function(openattempt,filehandlerid) 
    {           
        var inp             = 	{rmiID  :   filehandlerid,
                                typeofstatus   :    'Opendrive'};
        $http.post(API_URL + 'checkFileStatus', inp).then(function mySuccess(response) 
        {
            if(response.data.result     ==  500)
            {
                openattempt++;
                if(openattempt <= 5) {
                    $timeout( function(){ $scope.checkfiledriveopenstatus(openattempt,filehandlerid); }, 2000 );
                } else {
                    hideLoader();
                    showNotify("File handler is not running. Please check.", 'danger');
                }
            }
            if(response.data.result     ==  404)
            {
                hideLoader();
                showNotify("File handler is not running. Please check.", 'danger');
            }
            if(response.data.result     ==  200)
            {
                hideLoader();
                showNotify( response.data.errMsg, 'success' );
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            showNotify("File handler is not running. Please check.", 'danger');
        });
    };
    
    $scope.jobandcucview    =   '';
    $scope.doJobsheetView   =   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID) 
    {     
        $scope.jobandcucview    =   "Job Sheet View";
        var inp                 =   {
                                        metadataid  :   taskmetaid,
                                        jobId       :   jobId,
                                        Chapter     :   CHAPTER_NO,
                                        bookid      :   BOOK_ID
                                    };
        $('#show-cucview').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        $http({
                url         :   BASE_URL + "getIndexingJobView",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if(response.xmlcount >= 1)
            {
                $scope.heightofmodal        =   600;
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $scope.heightofmodal        =   100;
                $('#xmlContent').html(response.errMsg);
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    $scope.jobandcucview    =   '';
    $scope.doChapterCucview =   function(taskmetaid,jobId,CHAPTER_NO,BOOK_ID) 
    {     
        var inp             = 	{
                                        jobId       :   jobId,
                                        metadataid  :   taskmetaid,
                                        Chapter     :   CHAPTER_NO,
                                        bookid      :   BOOK_ID
                                    };
        $scope.jobandcucview    =   "Indexing Sheet View";
        $('#show-cucview').trigger('click');
        
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        
        $http({
                url         :   BASE_URL + "getIndexingView",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if(response.xmlcount >= 1)
            {
                $scope.heightofmodal        =   600;
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $scope.heightofmodal        =   100;
                $('#xmlContent').html(response.errMsg);
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    
    //open openjobrawfile
    $scope.openjobrawfile   =   function(jobId)
    {
        var currentChapter  =   angular.element(document.getElementById("txtDoopenrawfile"));
        $(currentChapter).attr('disabled','true');          
        showLoader('Please wait while Open Drive ...');
        var inp             = 	{
                                    jobId       :   jobId
                                };   
        $http.post(BASE_URL + 'indexingOpenrawFile', inp)
        .then(function mySuccess(response) 
        {
            hideLoader();
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'danger' );
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                showNotify( response.data.errMsg  , 'success' );
            }
            $(currentChapter).removeAttr('disabled','true');
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            //showMessage('Message', response.data.errMsg, 'error' );
            //showNotify( response.data.errMsg  , 'danger' );
        });
    }
    
    $scope.dochaptererrorlog    =   function(item) 
    {   
        showNotify("You are not allowed to access this Chapter, as it is locked by other user ("+item.Chapter_User_Name+'-'+item.EMPLOYEE_ID+")", 'danger');
    }
    
    $scope.Msgsuccess           =   true;
    $scope.hidemsg 		=   function()
    {
        $scope.Msgsuccess   =   false;
    }
    
    $scope.qmsspike                 =       function(jobId, userId, bookId,type)
    {
        if(type     ==  'qms')
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   QMS_URL+"?titleID="+jobId+'&userId='+userId+'&type=Magnus';   
            $('#iframeqms').attr('src',$scope.srciframepath);
        }
        else
        {
            $scope.bookTitle        =   bookId;
            $scope.srciframepath    =   SPIKE_URL+"?titleID="+jobId+"&type=Magnus";   
            $('#iframespike').attr('src',$scope.srciframepath);
        }
    };
    
    //retrieve versions
    $scope.alfrescodata     =   [];
    $scope.getretrieve      =       function(taskmetaid,jobId,alfrescoID)
    {
        showLoader('Please wait while Submit ...');
        var inp             = 	{
                                    metadataId  :   taskmetaid,
                                    jobId       :   jobId,
                                    alfrescoId  :   alfrescoID
                                };
                                
        var deferred        =   $q.defer();
        $http.post(API_URL+"alfrescoRetrieveVersions",inp) .then(function mySuccess(response) 
        {
            
                hideLoader();
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                return false;
            }
            if(response.data.result     ==  401)
            {
                if (typeof response.data.validation !== 'undefined') {
                    $.each(response.data.validation,function(key,val)
                    {
                        $.each(val,function(key,errval)
                        {
                            $.notify(errval,'error');
                        });
                    });
                }
                showNotify( response.data.errMsg  , 'danger' );
            }
            if(response.data.result     ==  200){
                $scope.alfrescodata     =   response.data.data;
                $("#show-openfiles").trigger('click');
            }
            deferred.resolve(response);
        }, 
        function myError(response) 
        {   
            hideLoader();
            deferred.reject(response);
        });	
        
        return deferred.promise;
    }
    
    //show client ack remarks commands
    $scope.showClientack   =   function(acaREMARKS){   
        var printMsg       =   (acaREMARKS == null || acaREMARKS == "" ) ? 'Remarks not found..' : acaREMARKS;
        $scope.Msgbox 	=   "Alfresco Error Log Files";
        $('#trigger-alfresco').trigger('click');
        $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
    };
    
});