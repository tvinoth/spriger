ngApp = angular.module('ngApp', ['datatables']);  //,'angularUtils.directives.dirPagination'
//ngApp.value('ngApp', 'ngMaterial');
 /*
 *  File Upload Directive
 *  This will enable two way binding of file field
 */
ngApp.directive('uploadFileModel', function ($parse) {
	return {
		restrict: 'A', //the directive can be used as an attribute only
		/*
		 link is a function that defines functionality of directive
		 scope: scope associated with the element
		 element: element on which this directive used
		 attrs: key value pair of element attributes
		 */
		link: function (scope, element, attrs) {
                    var model = $parse(attrs.uploadFileModel),
                            modelSetter = model.assign; //define a setter for uploadFileModel

                    //Bind change event on the element
                    element.bind('change', function () {
                    //Call apply on scope, it checks for value changes and reflect them on UI
                    scope.$apply(function () {
                            //set the model value
                        modelSetter(scope, element[0].files[0]);
                    });
                    });
		}
	};
});

/*
 *  Get URL Parameters
 *  This method get the parameters from the URL.
 */

function getUrlParameter(param) {
	var res, sPageURL =  window.location.href,
	sURLVariables = sPageURL.split(/[/]/);
    if(param == 1) {
		res = sURLVariables[sURLVariables.length-1];
	} else if(param == 2) {
		res = sURLVariables[sURLVariables.length-2];
	}
	return res;
}
/*
 *  Toggle Menu
 *  This method toggle the menu from side to top
 */
 
 function toggleMenu(opt){
	if(opt == "Toggle") {
		if(localStorage.getItem('menuPosition') == "Side") {
                    localStorage.setItem('menuPosition', "Top");
		} else {
                    localStorage.setItem('menuPosition', "Side");
		}
	} else {
		if(localStorage.getItem('menuPosition') == undefined || localStorage.getItem('menuPosition') == "") { 
                    localStorage.setItem('menuPosition', "Side");
		}
	}	
    $(".menuSide").hide();
    $(".menuTop").attr( "style","margin-top:17px;" );
    $(".menuTop").addClass("h-sidebar");		
	
}
 toggleMenu('Selected');

/*
 *  Common Controller
 *  This controller contains all the methods related to use common bootstrap method to use tooltip
 */

ngApp.directive('tooltip', function(){
    return {
        restrict: 'A',
        link: function(scope, element, attrs){
            $(element).hover(function(){
                // on mouseenter
                $(element).tooltip('show');
            }, function(){
                // on mouseleave
                $(element).tooltip('hide');
            });
        }
    };
});


/*
 *  Common Controller
 *  This controller contains all the methods related to common methods like Lounge hours, change password etc
 */
//ngApp.controller('menutopController',menutopController).directive('myDirectivetest', function() {
//    return {
//        scope: { someCtrlFn: '&callbackFn' },
//        link: function(scope, element, attrs) {
//            scope.someCtrlFn();
//        },
//    }
//});

//function menutopController($scope,$q,$http) {
//    $scope.mastermenu           =   [];
//    $scope.transmenuList        =   [];
//    $scope.contentloadtimer     =   1;
////    $scope.getMenutransaction   =   function()
////    {
//        showLoader();
//        var deferred            =   $q.defer();
//        $http.get(BASE_URL+'getmenu').then(function mySuccess(response)
//        {
//            hideLoader();
//            $scope.mastermenu       =   response.data.menulilst;
////            var filtered            =   $filter('orderBy')(response.data.childmenu, 'PACKAGE_DISPLAY_ORDER');
//            $scope.transmenuList    =   response.data.childmenu;
//            deferred.resolve(response);
//        },
//        function myError(response) 
//        {
//            if($scope.contentloadtimer    <  5){
//                menutopController();
//            }
//            if($scope.contentloadtimer    ==  5){
//                hideLoader();
//                showNotify('Kindly reload page error occured.'  , 'danger' );
//                return false;
//            }
//            deferred.reject(response);
//        });
//        $scope.contentloadtimer++;
//        return deferred.promise;
////    }
//    
//    $.ajaxSetup({
//            headers: {
//                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//            }
//        });
//}


/*ngApp.controller('menutopController', function ( $scope, $q,$http,$filter, DTOptionsBuilder, DTColumnBuilder ) {
    $scope.mastermenu           =   [];
    $scope.transmenuList        =   [];
    $scope.contentloadtimer     =   1;
    $scope.getMenutransaction   =   function()
    {
        showLoader();
        var deferred            =   $q.defer();
        $http.get(BASE_URL+'getmenu').then(function mySuccess(response)
        {
            hideLoader();
            $scope.mastermenu       =   response.data.menulilst;
//            var filtered            =   $filter('orderBy')(response.data.childmenu, 'PACKAGE_DISPLAY_ORDER');
            $scope.transmenuList    =   response.data.childmenu;
            deferred.resolve(response);
        },
        function myError(response) 
        {
            if($scope.contentloadtimer    <  5){
                $scope.getMenutransaction();
            }
            if($scope.contentloadtimer    ==  5){
                hideLoader();
                showNotify('Kindly reload page error occured.'  , 'danger' );
                return false;
            }
            deferred.reject(response);
        });
        $scope.contentloadtimer++;
        return deferred.promise;
    }
    
    $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        
    $scope.getMenutransaction();
});*/
        

    ngApp.controller('ngUserdetailscontrol', function ( $scope, $q,$http,$filter, DTOptionsBuilder, DTColumnBuilder ) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        /*$scope.UserDetails      =   JSON.parse(localStorage.getItem("UserDetails"));
        if($scope.UserDetails   ==  null || $scope.UserDetails   ==  'undefined' || $scope.UserDetails   ==  ''){
            window.location.href=   BASE_URL+"?expired";
        }
        
        if($scope.UserDetails   !=  null || $scope.UserDetails   !=  'undefined' || $scope.UserDetails   !=  ''){
            $scope.userName     =   $scope.UserDetails.user_name;
            $scope.roleName     =   $scope.UserDetails.role_name;
            $scope.userId       =   $scope.UserDetails.user_id;
        }else{
            $scope.contentloadtimer =   1;
            $scope.getUserDetail    =   function (){	
                var deferred        =   $q.defer();
                $scope.userName     =   "";
                $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) {
                    if(response.data.msg == "success") {
                        $scope.userName     = 	response.data.user_name;
                        $scope.roleName     = 	response.data.role_name;
                        $scope.userId       = 	response.data.user_id;
                        $scope.UserDetails  = 	response.data;	
                    } else {
                        window.location.href= BASE_URL+"?expired";
                    }
                    deferred.resolve(response);
                },
                function myError(response) {
                    if($scope.contentloadtimer    !==  5){
                        $scope.getUserDetail();
                    }
                    if($scope.contentloadtimer    ==  5){
                        showNotify('Kindly reload page error occured.'  , 'danger' );
                        return false;
                    }
                    deferred.reject(response);
                });
                $scope.contentloadtimer++;
                return deferred.promise;
            };
        }*/
        
    //    $scope.$on('parentmethod', function (event, args) {
    //            $scope.userName     =   args.message;
    //        })
    });

    ngApp.controller('ngCommonCntrl', function ( $scope, $q,$http, DTOptionsBuilder, DTColumnBuilder ) {
	
	$scope.loungeBtn        =   "Start";
	$scope.loungeChkOut     =   true;
	$scope.crntPwd          =   "";
	$scope.newPwd           =   "";
	$scope.confPwd          =   "";
	$scope.menuChild        =   'Dashboard';
	$scope.menuParent       =   'Dashboard';

	/*
	 *  Get User Details
	 *  This method get the logged in user details from the session.
	*/
    
    /*
     *  Save Lounge Hours
     *  This method save the lounge hour details in to DB for the logged in user.
    */

        $scope.saveLoungeHours = function() {

        var inp = {userId : '',
                           remark : $scope.loungeRemark,
                           reason : $scope.loungeReason,
                          };
        $http.post(API_URL+"saveLoungeHours", inp).then(function mySuccess(response) {
            if(response.data[0].id > 0) {
                showMessage('Lounge Hours', response.data[0].msg, 'success');

                if(response.data[0].flag > 0) {
                        $scope.clearLoungeHours();
                }	 else {
                        $scope.showLoungeHours();
                }			
                $("#lounge_cancel").click();
            }			
        },
        function myError(response) {
            console.log(response);
        });
    };
	/*
	 *  Get Lounge Hours
	 *  This method get the lounge hours for the logged in user.
	 */
    $scope.showLoungeHours = function() {
        var inp = {userId : ''};
        $scope.loungeChkOut = true;$scope.loungeBtn = "Start";		
            $http.post(API_URL+"getLoungeHours", inp).then(function mySuccess(response) {
            if(response.data.length > 0) {
                $scope.loungeCheckout = response.data[0].lounge_in;
                $scope.loungeActivity = response.data[0].lounge_reason;		
                $scope.loungeRemark =  response.data[0].remarks;		
                $scope.loungeChkOut = false;	
                $scope.loungeBtn = "Stop";		
            }			
        }, 
        function myError(response) {
            console.log(response);
	});
    };

    /*
     *  Clear Lounge Hour Form
     *  This method clear all the fields related to lounge hours
     */
	
    $scope.clearLoungeHours = function() {
        $scope.loungeCheckout = "";
        $scope.loungeActivity = "";
        $scope.loungeRemark = "";
        $scope.loungeReason = "";
        $scope.loungeChkOut = true;
        $scope.loungeBtn = "Start";		
    };

    /*
     *  Change Password
     *  This method is used to change the logged in user password.
    */
    
    $scope.changePassword = function() {
            if($scope.crntPwd == "") {
                    alert('Please enter current Password');
                    return;
            }
            else if($scope.newPwd == "") {
                    alert('Please enter new Password');
                    return;
            }
            else if($scope.confPwd == "") {
                    alert('Please enter confirm Password');
                    return;
            }
            else if($scope.confPwd == $scope.newPwd) {
                    var inp = {userId : '',
                                       pwd : $scope.crntPwd,
                                       newPwd : $scope.newPwd,
                                      };
                    $http.post(API_URL+"changePassword", inp).then(function mySuccess(response) {
                            console.log(response);
                            if(response.data[0].flag > 0) {
                                    $("#pwd_cancel").click();
                                    showMessage('Change Password', response.data[0].msg, 'success');
                                    $scope.clearPassword();
                            } else {
                                    alert(response.data[0].msg);
                            }			
                    }, 
                    function myError(response) {
                             console.log(response);
                    });
            } else {
                    alert('Confirm Password is not matching with new password');
                    return;
            }		
        };
    /*
     *  Clear Password
     *  This method clear all the fields related to change password form.
     */
        $scope.clearPassword = function() {
                $("#pwd_cancel").click();
                $scope.crntPwd = "";
                $scope.newPwd = "";
                $scope.confPwd = "";
        };
	
    });

    ngApp.controller( 'ngNotificationError', function ( $scope, $q ,$http,$filter, DTOptionsBuilder, DTColumnBuilder ) {

        $scope.displayErrMsgByStatusCode    =       function( ){

            var params  =   { cntlr : getQueryStringValue('cntlr')  ,  code : getQueryStringValue('statusCode') };
            $http.post(BASE_URL+'getStatusCodeError' , params ).then(function mySuccess(response){
                showNotify( response.data.errStr , response.data.notify );
            },function myError(response){
            });	

        };

        $scope.displayErrMsgByStatusCode();
    });

	
    function getQueryStringValue (key) {  

        return decodeURIComponent(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + encodeURIComponent(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));  
    } 
    ngApp.directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }            
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });

    ngApp.directive('numbersOnlywithdot', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9.]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }            
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });
    
    ngApp.directive('numbersPrintvalidation', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9,-]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }            
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });
    
    ngApp.directive('emailsOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[`~!#$%^&*()|+\=?;:'"<>\{\}\[\]\\\/]/gi, '');
                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }

                        return transformedInput;
                    }
                    return undefined;
                }            
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });