ngApp.controller('ngController', function ($scope,$filter,$compile, $http, $timeout , $interval,$window,DTOptionsBuilder, DTColumnBuilder  ) 
{
    $scope.userId 		=   0;	
    $scope.UserDetails 	=   {};
    $scope.menuParent       =   'Production';
    $scope.menuChild        =   'BG Process';
    $scope.errorMsg 	=   "";
    
    $scope.noOfAttemptsToCheckIndesign  =   10;

    var statusCode          =      {Success : 2 , Failed : 3 , "In-progress" : '1.5'};
    $scope.statustypes      =          statusCode;

    $('.chosen-select').chosen({}); 
    /*
     *  Get User Details
     *  This method get the logged in user details from the session.
     */
    $scope.getProcesstypes      =   function() 
    {
        $scope.processList      =   [];
        $http.get(BASE_URL+"bgprocesstypes").then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify('Kindly reload page error ocured.'  , 'danger' );
            }
            $scope.processList      =   response.data.bgtypes;	
        }, 
        function myError(response) 
        {
            showNotify('Kindly reload page error ocured.'  , 'danger' );
        });			
    };
    
    $scope.getProcesstypes();
     
    $scope.changeProcess    =   function() 
    {
        var inp             =   {
                                    processid   :   $scope.process,
                                    status      :   $scope.statusitems
                                };

        if($scope.process ==    '' || $scope.process ==    undefined){
            return false;
        }
        if($scope.statusitems ==    '' || $scope.statusitems    ==    undefined){
            return false;
        }

        showLoader('Please wait while getting data...'); 

        $http.post('getbgprocessfailed',inp).then(function mySuccess(response){
            hideLoader();
            if(response.data.result  ==  200){
                $scope.bgprocessList    =   response.data.downloadfailed;
            }
        },function myError(response){
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
        }); 

    };

    /*
     *  Get Book info
     *  This method get all the active Book info from DB
     */

    //show client ack remarks commands
    $scope.showClientack   =   function(acaREMARKS){   
        var printMsg       =   (acaREMARKS == null || acaREMARKS == "" ) ? 'Remarks not found..' : acaREMARKS;
        if($scope.process   ==  1){
        $scope.Msgbox 	=   "Spice Error Log Files";
        }
        else if($scope.process   ==  2){
        $scope.Msgbox 	=   "Taps Error Log Files";
        }else{
            $scope.Msgbox 	=   "Error Log Files";
        }
        $('#show-redo').trigger('click');
        $('#redofailed').html('<p style="word-break:break-all;white-space:pre;">'+printMsg+'</p>');
    };
           
    $scope.retrySpicastbackground      =     function(item)
    {
        if($scope.process   ==  1)
        var sendurl     =   API_URL+"doSpicerequest/"+item.JOB_STAGE_ID;
        if($scope.process   ==  2)
        var sendurl     =   API_URL+"domoveTaps/"+item.JOB_ID+'/'+item.METADATA_ID+'/'+item.ROUND_ID+'/'+''+item.CHAPTER_NO+''+'/'+''+item.CHAPTER_TITLE+'';
        showLoader('Please wait while retry...'); 
        $http.get(sendurl).then(function mySuccess(response)
        {
            if(response.data.result  ==  200)
            {
                var     temp    =   '<span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>';
                angular.element(document.getElementById("spicastretry_"+item.METADATA_ID)).remove();
                var elem    =   angular.element(document.getElementById("spicast_"+item.METADATA_ID)).append(temp);
                showNotify(response.data.errMsg  , 'success' );
            }
            else
            {
                showNotify(response.data.errMsg  , 'danger' );
            }
            hideLoader();
        }, function myError(response) 
        {
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
        });
    };
    
	$scope.retryEproofS650 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "doeproofpackagecreateBook/"+jobid+'/'+params.ROUND_ID+'/package';
       	
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {
              
               $timeout( function(){
                    
                  hideLoader();                    
                  showNotify( response.data.errMsg , 'success' );
                  $timeout( function(){  
						$window.location.reload();
                  }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
   
	$scope.packagefileUploadEproofs650    =   function(params){
        
        console.log( params );
        params.type=	'eproof';
 
		showLoader('Please wait while opening...');  
		showNotify( 'File Transfer Initialized...' , 'success' );

        $http.post( BASE_URL+"packageFileTransferS650Eproof" , params ).then(function mySuccess(response) {

			if( response.data.status == 1 ){
				showNotify('am ok to proceed');
				$scope.retryEproofS650(params);				
			}

			if( response.data.status == 0 ){   
				showNotify( response.data.errMsg , 'danger' );
			}
			if( response.data.status == 500 ){   
				hideLoader();
				showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );
			}

        }, 
        function myError(response) {
		
			hideLoader();
			console.log(response);
			showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );
			
        });  

			
    };
    
    
    $scope.retryEproof 			= 	function(params){
       
       var printMsg    =   ( params.REMARKS == null ) ? 'remarks not found..' : params.REMARKS;
       showLoader();
       showNotify( 'please wait for a while...' , 'success');
       var jobid        =   params.JOB_ID;
       var dynamic_url  =   "doeproofpackagecreate/"+jobid+'/'+params.METADATA_ID+'/'+params.ROUND_ID+'/package';
       	
       $http.get(BASE_URL+dynamic_url).then(function mySuccess(response) {

            if(response.data.status == 1) {
              $timeout( function(){  
                hideLoader();
                
                if( response.data.msg !== 'success' ){
                    showNotify( response.data.errMsg , 'danger' );
                }else{
                    showNotify( response.data.errMsg , 'success' );
                }
                
                $timeout( function(){  
                   $window.location.reload();
                }, 2000 );

               }, 5000 );

            } else if( response.data.status == 0 ){
                showNotify( response.data.errMsg , 'danger' );
                hideLoader();
            } else {
               showNotify( 'Request got failed..' , 'danger');
               hideLoader();
            }

        },function myError(response) {
            console.log(response);
            showNotify( 'Oops, Kindly reload the page...' , 'danger' );
        });

    };
    
        
        
    $scope.retryCucbackground      =     function(item)
    {
        var sendurl     =   BASE_URL+"cucback/"+item.JOB_ID;
        showLoader('Please wait while retry...'); 
        $http.get(sendurl).then(function mySuccess(response)
        {
            if(response.data.result  ==  200)
            {
                var     temp    =   '<span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>';
                angular.element(document.getElementById("spicastretry_"+item.JOB_ID)).remove();
                var elem    =   angular.element(document.getElementById("spicast_"+item.JOB_ID)).append(temp);
                showNotify(response.data.errMsg  , 'success' );
            }
            else
            {
                showNotify(response.data.errMsg  , 'danger' );
            }
            hideLoader();
        }, function myError(response) 
        {
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
        });
    };
        
    $scope.downloadPackageZip  = function( params , type  ){
       
		if( params.METADATA_ID == null || typeof params.METADATA_ID == undefined ){
			
			var inp     =       {  job_id : params.JOB_ID , round : params.ROUND_ID , type : type };
			var apiurl		=	API_URL+"downloadPackageZipS650";
		
		}else{
			
			var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID , type : type };
			var apiurl		=	API_URL+"downloadPackageZip";
			
		}
		
        showLoader('Please wait while opening...');                
            
        $http.post( apiurl , inp ).then(function mySuccess(response) {
            
            if( response.data.status == 1 ){
                var attempt = 5;
                $scope.checkFhStatus( response.data.rmiId, attempt ,  '' );
            }

            if( response.data.status == 0 || response.data.status == 'failed'){   
                hideLoader();
                showNotify( 'Please Try once again , Already downloaded / source file not exist.' , 'danger' );
            }

        }, 
        function myError(response) {

            hideLoader();
            console.log( response );
            showNotify( 'Oops, Try again after sometimes' , 'danger' );

        });            
        
    };
    
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }
	}
	},
        function myError(response) {
                 showNotify( response.data  , 'danger' );
                    
	});		
        
    };
    
    
    $scope.retryBookMerge    =  function( params ){
        
        bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function(result) {
            
        if(result) {

            var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID  , bgprocessid : '' };

            showLoader('Please wait while opening...');  

            $http.post( BASE_URL+"retryBookMergeProcess" , inp ).then(function mySuccess(response) {

                if( response.data.status == 1 ){
                    var attempt = 5;
                    showNotify( response.data.errMsg , 'success' );
                }

                if( response.data.status == 0 ){   
                    hideLoader();
                    showNotify( response.data.errMsg , 'danger' );
                }

                $scope.changeProcess();
                hideLoader();

            }, 
            function myError(response) {
                hideLoader();
                console.log(response);
                showNotify( 'Oops, Try again after sometimes' , 'danger' );
            });  

            }
            
        });
        
    };
    
    
    $scope.retryBgProcess    =  function( params ){
        
        bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function(result) {
            
        if(result) {

            var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID  , bgprocessid : '' };

            showLoader('Please wait while opening...');  

            $http.post( BASE_URL+"retryCommonWayBackgroundProcess" , inp ).then(function mySuccess(response) {

                if( response.data.status == 1 ){
                    var attempt = 5;
                    showNotify( response.data.errMsg , 'success' );
                }

                if( response.data.status == 0 ){   
                    hideLoader();
                    showNotify( response.data.errMsg , 'danger' );
                }

                $scope.changeProcess();
                hideLoader();

            }, 
            function myError(response) {
                hideLoader();
                console.log(response);
                showNotify( 'Oops, Try again after sometimes' , 'danger' );
            });  

            }
            
        });
        
    };
    
    $scope.retryBgProcessApn  = function( params  , printtype ){
        
        bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function(result) {
            
        if(result) {

            var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID  , bgprocessid : '' , producttype : printtype };

            showLoader('Please wait while opening...');  

            $http.post( BASE_URL+"retryBgProcessApnPDF" , inp ).then(function mySuccess(response) {

                if( response.data.status == 1 ){
                    var attempt = 5;
                    showNotify( response.data.errMsg , 'success' );
                }

                if( response.data.status == 0 ){   
                    hideLoader();
                    showNotify( response.data.errMsg , 'danger' );
                }

                $scope.changeProcess();
                hideLoader();

            }, 
            function myError(response) {
                hideLoader();
                console.log(response);
                showNotify( 'Oops, Try again after sometimes' , 'danger' );
            });  

            }
            
        });
        
        
    };
    
    $scope.retryBgProcessPackage    =  function( params ){
        
        bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function(result) {
            
        if(result) {

            var inp     =       {  job_id : params.JOB_ID , metaid : params.METADATA_ID , round : params.ROUND_ID  , bgprocessid : '' };

            showLoader('Please wait while opening...');  

            $http.post( BASE_URL+"retryCommonWayBackgroundProcess" , inp ).then(function mySuccess(response) {

                if( response.data.status == 1 ){
                    var attempt = 5;
                    showNotify( response.data.errMsg , 'success' );
                }

                if( response.data.status == 0 ){   
                    hideLoader();
                    showNotify( response.data.errMsg , 'danger' );
                }

                $scope.changeProcess();
                hideLoader();

            }, 
            function myError(response) {
                hideLoader();
                console.log(response);
                showNotify( 'Oops, Try again after sometimes' , 'danger' );
            });  

        }
            
        });
        
    };
    
    
    $scope.packagefileUpload    =   function(params){
        
        params.type =	'package';
        
        //bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function( result ) {
            
            if( true ){
            
                showLoader();  
                showNotify( 'Please wait for a while File Transfer Initialized' , 'success' );

                $http.post( BASE_URL+"packageFileTransfer" , params ).then(function mySuccess(response) {

                    if( response.data.status == 1 ){
						hideLoader();
                        //showNotify( 'File Transfer successfully completed' , 'success' );
                        //showNotify( 'Packaging Meta preparation initializing...' , 'success' );
                        setTimeout( function(){  $scope.retryBgProcessPackage( params ); } , 5000 );
                    }

                    if( response.data.status == 0 ){
                        hideLoader();
                        setTimeout( function(){ showNotify( response.data.errMsg , 'danger' ); } , 4000 );
                    }

                    if( response.data.status == 500 ){
                        hideLoader();
                        setTimeout( function(){ showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' ); } , 4000 );

                    }

                }, 
                function myError(response) {

                    hideLoader();
                    console.log(response);
                    setTimeout( function(){ showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' ); } , 4000 );


                }); 
            }    
		//});		
    };
    
    $scope.retryRazorbackground      =     function(item)
    {
        var sendurl     =   API_URL+"Indexer/doRazorrequest/"+item.JOB_ID+"/"+item.BOOK_ID+"/"+item.METADATA_ID;
        showLoader('Please wait while retry...'); 
        $http.get(sendurl).then(function mySuccess(response)
        {
            if(response.data.status  ==  1)
            {
                var     temp    =   '<span class="label label-warning arrowed-in arrowed-in-right"> - waiting for razor response</span>';
                angular.element(document.getElementById("razorretry_"+item.METADATA_ID)).remove();
                var elem    =   angular.element(document.getElementById("razor_"+item.JOB_ID)).append(temp);
                showNotify(response.data.errMsg  , 'success' );
            }
            else
            {
                showNotify(response.data.errMsg  , 'danger' );
            }
            hideLoader();
        }, function myError(response) 
        {
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
        });
    };
    
    $scope.retryIndexerbackground      =     function(item)
    {
        var embbedtype  =   (item.EMBBED_TYPE   ==  1?"Embedded":"Non-Embedded");
        var sendurl     =   API_URL+"Indexer/GetIndexerInfo/"+item.JOB_ID+"/"+item.BOOK_ID+"/"+embbedtype;
        showLoader('Please wait while retry...'); 
        $http.get(sendurl).then(function mySuccess(response)
        {
            if(response.data.status  ==  1)
            {
                var     temp    =   '<span class="label label-warning arrowed-in arrowed-in-right"> - waiting for razor response</span>';
                angular.element(document.getElementById("indexerretry_"+item.METADATA_ID)).remove();
                var elem    =   angular.element(document.getElementById("indexer_"+item.JOB_ID)).append(temp);
                showNotify(response.data.errMsg  , 'success' );
            }
            else
            {
                showNotify(response.data.errMsg  , 'danger' );
            }
            hideLoader();
        }, function myError(response) 
        {
            hideLoader();
            showNotify(response.data.errMsg  , 'danger' );
        });
    };
    
    $scope.packagefileUploadEproof    =   function(params){
        
        console.log( params );
        params.type=	'eproof';
        
        //bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function( result ) {
            
            if( true ){
                
                showLoader('Please wait while opening...');  
                showNotify( 'File Transfer Initialized...' , 'success' );

                $http.post( BASE_URL+"packageFileTransfer" , params ).then(function mySuccess(response) {

                    hideLoader();
                    if( response.data.status == 1 ){
                        $scope.retryEproof(params);
                    }

                    if( response.data.status == 0 ){   
                        showNotify( response.data.errMsg , 'danger' );
                    }

                    if( response.data.status == 500 ){   
                        hideLoader();
                        showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );
                    }

                }, 
                function myError(response) {

                    hideLoader();
                    console.log(response);
                    showNotify( 'File transfer Failed , Close the already opened folder , Please try once again...' , 'danger' );

                });  
                
            }
            
        //});
			
    };
    	
    $scope.showSuccessredologview   =   function(typeoflog,item){
        var inp     =   {   
                            typeoflog   :   typeoflog,
                            clientid:   item.CLIACKID,
                            jobID   :   item.JOB_ID,
                            roundID :   item.ROUND_ID , 
                            metaid  :   item.METADATA_ID ,
                        };
        
        $http.post(BASE_URL+'doSuccessredologview',inp).then(function mySuccess(response) {
            if(response.data.status == 1) 
            {      
                hideLoader();
                $('#show-redo').trigger('click');
                $scope.Msgbox 	=	"Success/Redo Log View";
                $('#redofailed').html('<p class="text-left">'+response.data.errMsg+'</p>');
            } 
            else
            {
                showNotify(response.data.errMsg, 'danger' );
                hideLoader();
            }
        },function myError(response) {
            showNotify(response.data.errMsg,'danger' );
        });
    }
    
    
    $scope.retryLowresProcess   =   function( item ){
        
        bootbox.confirm("Are you sure you want to trigger this Bgprocess ?", function(result) {
            
            if( result ){
                
               showLoader();
               var inp     =   {   
                                round :   item.ROUND_ID , 
                                metaid  :   item.METADATA_ID ,
                            };

               $http.post( BASE_URL+'triggerlowres' , inp ).then(function mySuccess(response) {
                   
                    if(response.data.status == 1){      
                       
                       showNotify(response.data.errMsg, 'success' );
                       
                        setTimeout( function(){ 
                            hideLoader();  
                            window.location.reload();
                        } , 5000 );
                        
                       
                    } else {
                       
                       showNotify(response.data.errMsg, 'danger' );
                       hideLoader();
                       
                    }
                   
               },function myError(response) {
                   showNotify(response.data.errMsg,'danger' );
               });

            }
        });

    };
    
        
    
    });
