/*
 *  Round Master Controller
 *  This controller contains all the methods related to job and job info.
 */
ngApp.controller('ngController', function ($scope,$rootScope,$filter,$compile, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder) 
{
    $scope.userId 	= 	'0';	
    $scope.UserDetails 	= 	{};
    $scope.menuParent 	= 	'Production';
    $scope.menuChild 	= 	'Art Wrok';
    $scope.errorMsg 	= 	"";
    /*
     *  Get User Details
     *  This method get the logged in user details from the session.
     */	
    $scope.getUserDetail = 	function ()
    {	
        $scope.userName 	= 	"";
        $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) 
        {
            if(response.data.msg    == 	"success") 
            {
                $scope.userName     = 	response.data.user_name;
                $scope.roleName     = 	response.data.role_name;
                $scope.userId       = 	response.data.user_id;
                $scope.UserDetails  = 	response.data;
                $scope.getCucList();
            } else {
                window.location.href 	= 	BASE_URL+"?expired";
            }
        }, 
        function myError(response) 
        {
            showMessage('Message', 'Kindly reload page error ocured.', 'error' );
        });	
    };
			
    
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
    $scope.currentuserid    =   '';
    $scope.getCucList 	= 	function() 
    {
        $scope.CucList 	= 	[];
        $http.get(BASE_URL+"doCuclist") .then(function mySuccess(response) 
        {
            if(response.status != 200)
            {
                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
            }
            $scope.CucList          = 	response.data.cuclist;
            $scope.currentuserid    = 	response.data.user_id;
        }, 
        function myError(response) {
                showNotify( 'Kindly reload page error ocured.'  , 'danger' );
        });			
    };
        
    /*
     *  Get Chapter file open
     *  This method get all the active Book info from DB
    */
   
    $scope.chapterinfodetails 	=   function(chapter,checkouttype) 
    {   
        //$scope.loadspinner  =	true;
        if($scope.bindappendcheckin){
            var checkouttype     =   "new";
        }
        
        var checkouttype        =   checkouttype;
        showLoader('Please wait while checkout...');
        
        if(checkouttype     ==  'old'){
            
            $scope.checkininuputs    = 	{
                                    metadataid  :   chapter.taskmetaid,
                                    jobId       :   chapter.jobid,
                                    Chapter     :   chapter.CHAPTER_NO,
                                    bookid      :   chapter.BOOK_ID,
                                    stageid     :   chapter.STAGE,
                                    roundid     :   chapter.ROUND_ID,
                                    roundname   :   chapter.roundname,
                                    stagename   :   chapter.STAGE_NAME,
                                    jobtimesheetid   :   chapter.jobtimesheetid,
                                    checkouttype:   checkouttype
                                }; 
        }
        
        if($scope.globallastdata){
            
            var currentChapter  =   angular.element(document.getElementById("chapter_"+$scope.globallastdata[0].taskmetaid));
            var inp    = 	{
                                    metadataid  :   $scope.globallastdata[0].taskmetaid,
                                    jobId       :   $scope.globallastdata[0].jobid,
                                    Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
                                    bookid      :   $scope.globallastdata[0].BOOK_ID,
                                    stageid     :   $scope.globallastdata[0].STAGE_ID,
                                    roundid     :   $scope.globallastdata[0].ROUND_ID,
                                    stagename   :   $scope.globallastdata[0].STAGE_NAME,
                                    roundname   :   $scope.globallastdata[0].roundname,
                                    jobtimesheetid   :   $scope.globallastdata[0].jobtimesheetid,
                                    checkouttype :   'old'
                                };
            $scope.bindappendmeatid     =   $scope.globallastdata[0].taskmetaid;
        }
        else 
        {
            var currentChapter  =   angular.element(document.getElementById("chapter_"+chapter.taskmetaid));
            var inp             = 	{
                                            metadataid  :   chapter.taskmetaid,
                                            jobId       :   chapter.jobid,
                                            Chapter     :   chapter.CHAPTER_NO,
                                            bookid      :   chapter.BOOK_ID,
                                            stageid     :   chapter.STAGE,
                                            roundid     :   chapter.ROUND_ID,
                                            roundname   :   chapter.roundname,
                                            stagename   :   chapter.STAGE_NAME,
                                            jobtimesheetid   :   chapter.jobtimesheetid,
                                            checkouttype:   checkouttype
                                        };            
            $scope.bindappendmeatid     =   chapter.taskmetaid;
        }
        
        currentChapter.attr('disabled','true'); 
        
        $http.post(BASE_URL + 'doCucCheckoutprocess', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'danger' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'warning' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                currentChapter.remove();
                if($scope.globallastdata)
                {
                    var templateElement     =   '<span id="removeall_'+$scope.globallastdata[0].taskmetaid+'"><div class="btn-group" id="chaptercheckin_'+$scope.globallastdata[0].taskmetaid+'"><button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doCheckin()">Checkin</button></div><div class="btn-group" id="chaptersubmit_'+$scope.globallastdata[0].taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"   ng-click="doChapterProceed()">Submit</button></div><i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+$scope.globallastdata[0].taskmetaid+'" ng-click="doJobsheetView()"></i><i class="fa fa-folder-open-o pointer bigger-150 green fa-5x" aria-hidden="true" title="Open Folder" id="chapteropendrive_'+$scope.globallastdata[0].taskmetaid+'" ng-click="doChapterOpenDrive()"></i><span>';
                    $scope.bindappend       =   1;        
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("checkinbutton_"+$scope.globallastdata[0].taskmetaid)).append(temp);
                    $scope.globallastdata   =   response.data.records;  
                }
                else
                {
                    $scope.bindappend       =   1;
                    var templateElement     =   '<span id="removeall_'+chapter.taskmetaid+'"><div class="btn-group" id="chaptercheckin_'+chapter.taskmetaid+'"><button type="button" class="btn btn-primary btn-xs pointer"  ng-click="doCheckin()">Checkin</button></div><div class="btn-group" id="chaptersubmit_'+chapter.taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"   ng-click="doChapterProceed()">Submit</button></div><i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+chapter.taskmetaid+'" ng-click="doJobsheetView()"></i><i class="fa fa-folder-open-o pointer bigger-150 green fa-5x" aria-hidden="true" title="Open Folder" id="chapteropendrive_'+chapter.taskmetaid+'" ng-click="doChapterOpenDrive()"></i><span>';   
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("checkinbutton_"+chapter.taskmetaid)).append(temp);
                    $scope.globallastdata   =   response.data.records;  
                }
                //$scope.getCucList();
                hideLoader();
                //$scope.loadspinner      =	false;
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            currentChapter.attr('disabled','false');
            showNotify( response.data.errMsg  , 'danger' );
            //showMessage('Message', response.data.errMsg, 'warning' );
        });
    };
    

    
    $scope.doCheckin        =   function(chapter,checkintype)
    {
        showLoader('Please wait while checkin...');        
        if($scope.bindappend){
            var checkintype     =   "new";
        }
        
        var checkintype         =   checkintype;
        if(checkintype          ==  "new"){
            
            if($scope.globallastdata){
                
                var currentChapter  =   angular.element(document.getElementById("chaptercheckin_"+$scope.globallastdata[0].taskmetaid));
                var inp    = 	{
                                        metadataid  :   $scope.globallastdata[0].taskmetaid,
                                        jobId       :   $scope.globallastdata[0].jobid,
                                        Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
                                        bookid      :   $scope.globallastdata[0].BOOK_ID,
                                        stageid     :   $scope.globallastdata[0].STAGE_ID,
                                        roundid     :   $scope.globallastdata[0].ROUND_ID,
                                        stagename   :   $scope.globallastdata[0].STAGE_NAME,
                                        roundname   :   $scope.globallastdata[0].roundname,
                                        jobtimesheetid   :  $scope.globallastdata[0].jobtimesheetid,
                                        checkintype :   checkintype
                                };
            }
            
        }else{   
            if($scope.checkininuputs){
                var currentChapter  =   angular.element(document.getElementById("chaptercheckin_"+$scope.checkininuputs.metadataid));
                var inp    = 	{
                                        metadataid  :   $scope.checkininuputs.metadataid,
                                        jobId       :   $scope.checkininuputs.jobId,
                                        Chapter     :   $scope.checkininuputs.Chapter,
                                        bookid      :   $scope.checkininuputs.bookid,
                                        stageid     :   $scope.checkininuputs.stageid,
                                        roundid     :   $scope.checkininuputs.roundid,
                                        stagename   :   $scope.checkininuputs.stagename,
                                        roundname   :   $scope.checkininuputs.roundname,
                                        jobtimesheetid   :  $scope.checkininuputs.jobtimesheetid,
                                        checkintype :   checkintype
                                    };
            }
            else 
            {
                var currentChapter  =   angular.element(document.getElementById("chaptercheckin_"+chapter.taskmetaid));
                 var inp    = 	{
                                        metadataid  :   chapter.taskmetaid,
                                        jobId       :   chapter.jobid,
                                        Chapter     :   chapter.CHAPTER_NO,
                                        bookid      :   chapter.BOOK_ID,
                                        stageid     :   chapter.STAGE,
                                        roundid     :   chapter.ROUND_ID,
                                        stagename   :   chapter.STAGE_NAME,
                                        roundname   :   chapter.roundname,
                                        jobtimesheetid   :  chapter.jobtimesheetid,
                                        checkintype :   checkintype
                                    };
            }
        }
         
        currentChapter.attr('disabled','true');           
        $http.post(BASE_URL + 'doCucCheckinprocess', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'warning' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'warning' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                if($scope.bindappendmeatid)
                {
                    var taskmetaid          =   $scope.bindappendmeatid;
                    $scope.bindappendcheckin    =   1;
                    var templateElement     =   '<div class="btn-group" id="chapter_'+taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"  ng-click="chapterinfodetails()">Checkout</button></div>';
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("removeall_"+taskmetaid)).remove();
                    angular.element(document.getElementById("checkinbutton_"+taskmetaid)).append(temp);
                }
                else
                {
                    var templateElement     =   '<div class="btn-group" id="chapter_'+chapter.taskmetaid+'"><button type="button" class="btn btn-success btn-xs pointer"  ng-click="chapterinfodetails()">Checkout</button></div>';
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("removeall_"+chapter.taskmetaid)).remove();
                    angular.element(document.getElementById("checkinbutton_"+chapter.taskmetaid)).append(temp);
                }
                showNotify( response.data.errMsg  , 'success' );
                hideLoader();
                //$scope.loadspinner      =	false;
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            currentChapter.attr('disabled','false');
            showNotify( response.data.errMsg  , 'warning' );
        });
    };
    //final submit
    $scope.doChapterProceed 	=       function(chapter,type)
    {
        showLoader('Please wait while Submit ...');
        var currentChapter          =   '';
        var inp                 =   {};
        if($scope.bindappend)
        {
            var submittype      =   "new";
        }
        if($scope.globallastdata)
        {
            var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+$scope.globallastdata[0].taskmetaid));
            var inp    = 	{
                                    metadataid  :   $scope.globallastdata[0].taskmetaid,
                                    jobId       :   $scope.globallastdata[0].jobid,
                                    Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
                                    bookid      :   $scope.globallastdata[0].BOOK_ID,
                                    stageid     :   $scope.globallastdata[0].STAGE_ID,
                                    roundid     :   $scope.globallastdata[0].ROUND_ID,
                                    stagename   :   $scope.globallastdata[0].STAGE_NAME,
                                    roundname   :   $scope.globallastdata[0].roundname,
                                    jobtimesheetid   :  $scope.globallastdata[0].jobtimesheetid,
                                    submittype  :   submittype
                                };
            currentChapter.attr('disabled','true'); 
        }
//        else
//        {
//            if($scope.checkininuputs) 
//            {
//                var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+$scope.checkininuputs.metadataid));
//                var inp    = 	{
//                                        metadataid  :   $scope.checkininuputs.metadataid,
//                                        jobId       :   $scope.checkininuputs.jobId,
//                                        Chapter     :   $scope.checkininuputs.Chapter,
//                                        bookid      :   $scope.checkininuputs.bookid,
//                                        stageid     :   $scope.checkininuputs.stageid,
//                                        roundid     :   $scope.checkininuputs.roundid,
//                                        stagename   :   $scope.checkininuputs.stagename,
//                                        roundname   :   $scope.checkininuputs.roundname,
//                                        jobtimesheetid   :  $scope.checkininuputs.jobtimesheetid,
//                                        submittype  :   submittype
//                                    };
//            }
//            else 
//            {
//                var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+chapter.taskmetaid));
//                 var inp 	= 	{
//                                        metadataid  :   chapter.taskmetaid,
//                                        jobId       :   chapter.jobid,
//                                        Chapter     :   chapter.CHAPTER_NO,
//                                        bookid      :   chapter.BOOK_ID,
//                                        stageid     :   chapter.STAGE,
//                                        roundid     :   chapter.ROUND_ID,
//                                        stagename   :   chapter.STAGE_NAME,
//                                        roundname   :   chapter.roundname,
//                                        jobtimesheetid   :  chapter.jobtimesheetid,
//                                        submittype  :   submittype
//                                    };
//            }
//        }
                    
        //$scope.loadspinner  =	true;                        
        $http.post(BASE_URL + 'cucCompleteprocess', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'warning' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'danger' );
                currentChapter.removeAttr('disabled');
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                if($scope.bindappendmeatid)
                {
                    var taskmetaid          =   $scope.bindappendmeatid;
                    var templateElement     =   '<i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+taskmetaid+'" ng-click="doJobsheetView()"></i>&nbsp;<i class="fa fa-eye pointer bigger-150 green fa-5x" aria-hidden="true" title="Cuc View" id="chaptercucview_'+taskmetaid+'" ng-click="doChapterCucview()"></i>';     
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("removeall_"+taskmetaid)).remove();
                    angular.element(document.getElementById("checkinbutton_"+taskmetaid)).append(temp);
                }
                else
                {
                    var templateElement     =   '<i class="fa fa-info-circle pointer bigger-150 blue fa-5x" aria-hidden="true" title="Job Sheet View" id="chapterjobsheetview_'+chapter.taskmetaid+'" ng-click="doJobsheetView()"></i>&nbsp;<i class="fa fa-eye pointer bigger-150 green fa-5x" aria-hidden="true" title="Cuc View" id="chaptercucview_'+chapter.taskmetaid+'" ng-click="doChapterCucview()"></i>';      
                    var temp                =   $compile(templateElement)($scope);
                    angular.element(document.getElementById("removeall_"+chapter.taskmetaid)).remove();
                    angular.element(document.getElementById("checkinbutton_"+chapter.taskmetaid)).append(temp);
                }
                //$scope.getCucList();
                currentChapter.removeAttr('disabled');
                showNotify( response.data.errMsg  , 'success' );
                hideLoader();
                //$scope.loadspinner      =	false;
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            currentChapter.attr('disabled','false');
            showNotify( response.data.errMsg  , 'warning' );
        });
    }
    
    //open drive
    $scope.doChapterOpenDrive 	=       function(chapter,opennew)
    {
        showLoader('Please wait while Open Drive ...');
        //$scope.loadspinner  =	true;
        if($scope.bindappend)
        {
            var opendrivetype   =   "new";
        }
        
        if($scope.globallastdata)
        {
            var currentChapter  =   angular.element(document.getElementById("chaptersubmit_"+$scope.globallastdata[0].taskmetaid));
            var inp    = 	{
                                    metadataid  :   $scope.globallastdata[0].taskmetaid,
                                    jobId       :   $scope.globallastdata[0].jobid,
                                    Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
                                    bookid      :   $scope.globallastdata[0].BOOK_ID,
                                    stageid     :   $scope.globallastdata[0].STAGE_ID,
                                    roundid     :   $scope.globallastdata[0].ROUND_ID,
                                    stagename   :   $scope.globallastdata[0].STAGE_NAME,
                                    roundname   :   $scope.globallastdata[0].roundname,
                                    jobtimesheetid   :  $scope.globallastdata[0].jobtimesheetid,
                                    opendrivetype  :   opendrivetype
                                };
        }
//        if($scope.checkininuputs) 
//        {
//            var inp    = 	{
//                                    metadataid  :   $scope.checkininuputs.metadataid,
//                                    jobId       :   $scope.checkininuputs.jobId,
//                                    Chapter     :   $scope.checkininuputs.Chapter,
//                                    bookid      :   $scope.checkininuputs.bookid,
//                                    stageid     :   $scope.checkininuputs.stageid,
//                                    roundid     :   $scope.checkininuputs.roundid,
//                                    stagename   :   $scope.checkininuputs.stagename,
//                                    jobtimesheetid   :  $scope.checkininuputs.jobtimesheetid,
//                                    roundname   :   $scope.checkininuputs.roundname
//                                };
//        }
//        if($scope.globallastdata)
//        {
//            var inp    = 	{
//                                    metadataid  :   $scope.globallastdata[0].taskmetaid,
//                                    jobId       :   $scope.globallastdata[0].jobid,
//                                    Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
//                                    bookid      :   $scope.globallastdata[0].BOOK_ID,
//                                    stageid     :   $scope.globallastdata[0].STAGE_ID,
//                                    roundid     :   $scope.globallastdata[0].ROUND_ID,
//                                    stagename   :   $scope.globallastdata[0].STAGE_NAME,
//                                    jobtimesheetid   :  $scope.globallastdata[0].jobtimesheetid,
//                                    roundname   :   $scope.globallastdata[0].roundname
//                                };
//        }
//        else 
//        {
//             var inp 	= 	{
//                                    metadataid  :   chapter.taskmetaid,
//                                    jobId       :   chapter.jobid,
//                                    Chapter     :   chapter.CHAPTER_NO,
//                                    bookid      :   chapter.BOOK_ID,
//                                    stageid     :   chapter.STAGE,
//                                    roundid     :   chapter.ROUND_ID,
//                                    jobtimesheetid   :  chapter.jobtimesheetid,
//                                    stagename   :   chapter.STAGE_NAME
//                                };
//        }                
        $http.post(BASE_URL + 'cucOpendrive', inp)
        .then(function mySuccess(response) 
        {
            if(response.data.result     ==  404)
            {
                showNotify( response.data.errMsg  , 'warning' );
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  401)
            {
                showNotify( response.data.errMsg  , 'danger' );
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  500)
            {
                showNotify( response.data.errMsg  , 'danger' );
                //$scope.loadspinner      =	false;
                hideLoader();
            }
            if(response.data.result     ==  200)
            {
                //$scope.getCucList();
                showNotify( response.data.errMsg  , 'success' );
                hideLoader();
                //$scope.loadspinner      =	false;
            }
        }, 
        function myError(response) 
        {
            hideLoader();
            //$scope.loadspinner      =	false;
            showNotify( response.data.errMsg  , 'warning' );
        });
    }
    
    $scope.jobandcucview    =   '';
    $scope.doJobsheetView   =   function(cucinfo,sheettype) 
    {     
        var inp                 =   {};
        if($scope.bindappend)
        {
            var sheettype       =   "new";
        }
        var sheettype           =   sheettype;
        $scope.jobandcucview    =   "Job Sheet View";

        if(sheettype          ==  "new")
        {
            if($scope.globallastdata)
            {
                var currentChapter  =   angular.element(document.getElementById("chapterjobsheetview_"+$scope.globallastdata[0].taskmetaid));
                var inp             = 	{
                                        jobId       :   $scope.globallastdata[0].jobid,
                                        metadataid  :   $scope.globallastdata[0].taskmetaid,
                                        Chapter     :   $scope.globallastdata[0].CHAPTER_NO,
                                        bookid      :   $scope.globallastdata[0].BOOK_ID,
                                        stageid     :   $scope.globallastdata[0].STAGE_ID,
                                        roundid     :   $scope.globallastdata[0].ROUND_ID,
                                        stagename   :   $scope.globallastdata[0].STAGE_NAME,
                                        roundname   :   $scope.globallastdata[0].roundname,
                                        jobtimesheetid  :   $scope.globallastdata[0].jobtimesheetid,
                                        sheettype   :   sheettype
                                    };
            }
        }
        else
        {   
            if($scope.checkininuputs) 
            {
                var currentChapter  =   angular.element(document.getElementById("chapterjobsheetview_"+$scope.checkininuputs.metadataid));
                var inp    = 	{
                                        metadataid  :   $scope.checkininuputs.metadataid,
                                        jobId       :   $scope.checkininuputs.jobId,
                                        Chapter     :   $scope.checkininuputs.Chapter,
                                        bookid      :   $scope.checkininuputs.bookid,
                                        stageid     :   $scope.checkininuputs.stageid,
                                        roundid     :   $scope.checkininuputs.roundid,
                                        stagename   :   $scope.checkininuputs.stagename,
                                        roundname   :   $scope.checkininuputs.roundname,
                                        jobtimesheetid   :  $scope.checkininuputs.jobtimesheetid,
                                        sheettype   :   sheettype
                                    };
            }
            else 
            {
                var currentChapter  =   angular.element(document.getElementById("chapterjobsheetview_"+cucinfo.taskmetaid));
                 var inp            = 	{
                                        jobId       :   cucinfo.jobid,
                                        metadataid  :   cucinfo.taskmetaid,
                                        Chapter     :   cucinfo.CHAPTER_NO,
                                        bookid      :   cucinfo.BOOK_ID,
                                        stageid     :   cucinfo.STAGE_ID,
                                        roundid     :   cucinfo.ROUND_ID,
                                        stagename   :   cucinfo.STAGE_NAME,
                                        roundname   :   cucinfo.roundname,
                                        jobtimesheetid  :   cucinfo.jobtimesheetid,
                                        sheettype   :   sheettype
                                    };
            }
        }
        
        $('#show-cucview').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        $http({
                url         :   API_URL + "getCucJobView",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if(response.xmlcount >= 1)
            {
                $scope.heightofmodal        =   400;
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $scope.heightofmodal        =   100;
                $('#xmlContent').html(response.errMsg);
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    $scope.jobandcucview    =   '';
    $scope.doChapterCucview =   function(cucinfo,cuctype) 
    {     
        var inp             = 	{
                                        jobId       :   cucinfo.jobid,
                                        metadataid  :   cucinfo.taskmetaid,
                                        Chapter     :   cucinfo.CHAPTER_NO,
                                        bookid      :   cucinfo.BOOK_ID,
                                        stageid     :   cucinfo.STAGE_ID,
                                        roundid     :   cucinfo.ROUND_ID,
                                        stagename   :   cucinfo.STAGE_NAME,
                                        roundname   :   cucinfo.roundname,
                                        jobtimesheetid  :   cucinfo.jobtimesheetid,
                                        cuctype     :   cuctype
                                    };
        var currentChapter      =   angular.element(document.getElementById("chaptercucview_"+cucinfo.taskmetaid));
        $scope.jobandcucview    =   "Cuc Sheet View";
        
        $('#show-cucview').trigger('click');
        $('#xmlContent').html('<p class="text-center"><i class="ace-icon fa fa-spinner fa-spin orange bigger-300"></i><div id="contentLoader"></div></p>');	
        $http({
                url         :   API_URL + "getCucView",
                method      :   'POST',
                data        :   inp
             })
        .success(function(response) 
        {
            if(response.xmlcount >= 1)
            {
                $scope.heightofmodal        =   400;
                $('#xmlContent').html(response.errMsg);
            }
            else
            {
                $scope.heightofmodal        =   100;
                $('#xmlContent').html(response.errMsg);
            }
        })
        .error(function(response) 
        {
            hideLoader();
            $('#xmlContent').html(response.errMsg);
        });
    }
    
    $scope.Msgsuccess           =   true;
    $scope.hidemsg 		=   function()
    {
        $scope.Msgsuccess   =   false;
    }
    $scope.getUserDetail();
    
     $timeout(function () {
        
        angular.element('#downloadButton').trigger('click');
        
        var isDownloaded    =       $("input[name='isTokenDownloaded']").val();
        if( isDownloaded == 2 ){
            $scope.checkinButtonDisabled    =       false;
            $scope.submitButtonDisabled     =       false;
        }
        
    }, 2000); 
});