ngApp.controller('ngController', function ($scope,$filter,$compile, $http,$interval,$window,DTOptionsBuilder, DTColumnBuilder  ) 
{
	$scope.userId 		=   0;	
	$scope.UserDetails 	=   {};
 	$scope.menuParent       =   'Production';
        $scope.menuChild        =   'BG Process';
	$scope.errorMsg 	=   "";
        $scope.statustypes      =   [{id:'',name:'Yet to start'},{id:0,name:'In-Queue'},{id:1,name:'In-Progress'},{id:3,name:'Failed'},{id:2,name:'Completed'}];
        $('.chosen-select').chosen({}); 
	/*
	 *  Get User Details
	 *  This method get the logged in user details from the session.
	 */
	$scope.getUserDetail = 	function ()
	{	
	    $scope.userName 	= 	"";
	    $http.get(BASE_URL+"getUserDetail") .then(function mySuccess(response) 
            {
                if(response.status     ==  500)
                {
                    showNotify('Kindly reload page error ocured.'  , 'danger' );
                }
                if(response.data.msg 	== 	"success") 
                {
                    $scope.userName 	=   response.data.user_name;
                    $scope.roleName 	=   response.data.role_name;
                    $scope.UserDetails 	=   response.data;
                    $scope.getroundList();
                    $scope.getbookList();
                } 
                else 
                {
                    window.location.href    = 	BASE_URL+"?expired";
                }
            }, 
            function myError(response) 
            {
                showNotify('Kindly reload page error ocured.'  , 'danger' );
            });	
        };
			
	$scope.getUserDetail();
	
        $scope.getroundList         =   function() 
	{
            $scope.processList      =   [];
            $http.get(BASE_URL+"jobround") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error ocured.'  , 'danger' );
                }
                $scope.processList  =   response.data.prr;	
            }, 
            function myError(response) 
            {
                showNotify('Kindly reload page error ocured.'  , 'danger' );
            });			
	};
        
        $scope.getbookList   =   function() 
	{
            $scope.bookList        =   [];
            $http.get(BASE_URL+"getjoblist") .then(function mySuccess(response) 
            {
                if(response.status != 200)
                {
                    showNotify('Kindly reload page error ocured.'  , 'danger' );
                }
                $scope.bookList    =   response.data.book;	
            }, 
            function myError(response) 
            {
                showNotify('Kindly reload page error ocured.'  , 'danger' );
            });			
	};
        
        $scope.changeProcess    =   function() 
	{
            var inp             =   {
                                        processid   :   $scope.process,
                                        status      :   $scope.statusitems
                                    };
                                    return false;
            if($scope.process ==    '' || $scope.process ==    undefined)
            {
                return false;
            }
            if($scope.statusitems ==    '' || $scope.statusitems    ==    undefined)
            {
                return false;
            }
            showLoader('Please wait while getting data...'); 
            $http.post('getbgprocessfailed',inp).then(function mySuccess(response)
            {
                hideLoader();
                if(response.data.result  ==  200)
                {
                    $scope.bgprocessList    =   response.data.downloadfailed;
                }
            },
            function myError(response)
            {
                hideLoader();
                showNotify(response.data.errMsg  , 'danger' );
            });                         
	};
        
	/*
	 *  Get Book info
	 *  This method get all the active Book info from DB
	 */
        
        //show client ack remarks commands
        $scope.showClientack   =   function(acaREMARKS){   
            var printMsg       =   (acaREMARKS == null || acaREMARKS == "" ) ? 'Remarks not found..' : acaREMARKS;
            if($scope.process   ==  1)
            $scope.Msgbox 	=   "Spice Error Log Files";
            if($scope.process   ==  2)
            $scope.Msgbox 	=   "Taps Error Log Files";
            $('#show-redo').trigger('click');
            $('#redofailed').html('<p class="text-center">'+printMsg+'</p>');
        };
           
        $scope.retrySpicastbackground      =     function(item)
        {
            if($scope.process   ==  1)
            var sendurl     =   API_URL+"doSpicerequest/"+item.JOB_STAGE_ID;
            if($scope.process   ==  2)
            var sendurl     =   API_URL+"domoveTaps/"+item.JOB_ID+'/'+item.METADATA_ID+'/'+item.ROUND_ID+'/'+''+item.CHAPTER_NO+''+'/'+''+item.CHAPTER_TITLE+'';
            showLoader('Please wait while retry...'); 
            $http.get(sendurl).then(function mySuccess(response)
            {
                if(response.data.result  ==  200)
                {
                    var     temp    =   '<span class="label label-warning arrowed-in arrowed-in-right">In Progress</span>';
                    angular.element(document.getElementById("spicastretry_"+item.METADATA_ID)).remove();
                    var elem    =   angular.element(document.getElementById("spicast_"+item.METADATA_ID)).append(temp);
                    showNotify(response.data.errMsg  , 'success' );
                }
                else
                {
                    showNotify(response.data.errMsg  , 'danger' );
                }
                hideLoader();
            }, function myError(response) 
            {
                hideLoader();
                showNotify(response.data.errMsg  , 'danger' );
            });
        };
    });