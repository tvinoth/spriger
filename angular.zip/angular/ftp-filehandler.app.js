/*
 *  Project List Controller
 *  This controller contains all the methods related to project list screen.
 */
ngApp.controller('filemoveController', function ( $scope, $http , $window ,  $timeout ) {
	
    $scope.userId = 0;
    $scope.projectList = [];
    $scope.Checkout =   false;
    $scope.showProject = false;
    $scope.menuParent   =   'Pre-Production';
    $scope.menuChild    =   'SplitProcess';
    
    $scope.downloadButtonDisabled     =   false;      
    $scope.downloadButtonText     =   "Download Raw Files";
    
    $scope.openFolderButtonText   =   "Open Folder";
    
    $scope.checkinButtonDisabled     =   true;      
    $scope.checkinButtonText     =   "Check-in";
    
    $scope.submitButtonDisabled     =   true;      
    $scope.submitButtonText     =   "Submit";
    $scope.savechapterdisabled  =   false;
    $scope.noOfAttemptsToCheckIndesign  =   10;
    
    
    //Mohan changes 
    
     $scope.filemovementProcess =   function( job_id, method , src , dest , openpath,  del, ext, stage  ){
       
       //bootbox.confirm("Are you sure to proceed with this ?", function(result) {
           showLoader('Please wait while copying files...');
            var result = true;
           if(job_id =='' || src =='' ||  dest == ''){
                result = false;
            }
                    
            if( result ){
                
                $scope.downloadButtonText     =   "Download In Progress";
                
                var inp = {
                    method_name     :  method , 
                    src_path        :   src,
                    dest_path       :   dest,
                    ext             : ext ,
                    isdelete        : del ,
                    openpath        : openpath,
                    job_id          : job_id,
                    stage_id        : stage
                };
                console.log(inp);
                $scope.jobSheetdata(job_id, stage, method);
                return false;
                $http.post( API_URL+"fileMovement" , inp ) .then(function mySuccess(response) {
                
                    if(response.data.status == "success") {
                        
                        if(openpath !=''){
                            
                            $scope.filemovementWithopenDrive(openpath,'');
                            $scope.jobSheetdata(job_id, stage, method);
                            alert('dd');
                            $scope.downloadButtonText     =   "Download Completed";
                            hideLoader();
                        }
			
                    } else {
                        
                        hideLoader();
			showNotify( response.data[0]['errMsg'] , 'danger' );
                        
                        return false;
                    }
                   
                    /*$timeout(function () {

                        $scope.downloadButtonDisabled     =   true;

                        $scope.downloadButtonText     =   "Download Completed";

                        angular.element('#openFolderBtn').trigger('click');
                        
                        hideLoader();
                     
                    }, 3000); */
                    
                    
                    
		}, 
		function myError(response) {
                    
                    showLoader( 'Oops! Try again after sometimes.' );
                    
                    
		});
                
                 
                    
            }else{
                
                function myError(response) {
                    
                    showLoader( 'Oops! problem in sending data.' );
                    
                }
            }
        }
        
  $scope.filemovementWithopenDrive = function( path , opt ) {
         
       // bootbox.confirm("Are you sure to open this book working directive ?", function(result) {
        var result   =   true;
       
            if( result ){
                
                $scope.openFolderButtonText     =   "In Progress";
                var method = "";
                showLoader('Please wait while opening...');
                
                method = "doOpenDriveServer";

                var inp = {

                           filePath : path ,
                           methodName : method  ,
                           processname  :   'checkout'
                           
                };

                $http.post( API_URL+"saveFhInfo", inp ).then(function mySuccess(response) {

                    if(response.data[0].rmiId > 0) {
                        
                        var attempt = 5;
                        $scope.checkFhStatus(response.data[0].rmiId, attempt, opt);
                        
                        
                    } else {
                        hideLoader();
                        showMessage('Download Status', 'Having problem in insert data.', 'success');
                    }
                    
                    
                },function myError(response) {
                    
                        showLoader( 'Oops! Try again after sometimes.' );
                    
                });
                
                /*$timeout(function () {
                    $scope.openFolderButtonText     =   "Open Folder";
                    $scope.submitButtonDisabled     =   false;      
                    $scope.checkinButtonDisabled     =   false;      
                }, 2000); */
                    
            }
        }
        
    $scope.jobSheetdata = function(jobId, stageId,checkout) {
         
        var inp = { jobId    : jobId ,stageId  : stageId, action: checkout };
        $http.post( API_URL+"jobsheet", inp ).then(function mySuccess(response) {
            
             
         },function myError(response) {
                    
                        showLoader( 'Oops! Try again after sometimes.' );
                    
                });
        
    };
        
          /*
     *  Check RMI Status
    *  This method check the RMI status for the selected folios.
    */
   
    $scope.checkFhStatus = function(rmiId, attempt, opt) {
    
        var inp = {rmiID : rmiId};
        $http.post(API_URL+"checkFhStatus", inp).then(function mySuccess(response) {
	console.log(response);
        
	$scope.IsRunning = response.data[0].is_running;   // status, remarks
	if(response.data[0].status == 1) {
            if(response.data[0].remarks == 'completed' || response.data[0].remarks == 'success') {
		hideLoader();
		if(opt == "Fonts") {
                    showMessage('Download Status', 'Font Downloaded successfully.', 'success');
		} else if(opt == "InDesign") {
                    hideLoader();
                    $scope.checkoutBtn = "Open File";
                    showMessage('Download Status', 'Page(s) checked out successfully.', 'success');						
                    //$scope.checkFileStatus();
                    $scope.checkoutProcess();
		} else {
                    
                    //showMessage('Download Status', 'Folder Opened Successfully.' , 'success');
                    
                    showNotify( 'Folder Opened Successfully.'  , 'success' );
                    
		}
            } else {    
                    hideLoader();
                    showMessage('Download Status', response.data[0].remarks, 'error');
            }
	} else {
            attempt++;
            if(attempt < $scope.noOfAttemptsToCheckIndesign) {
            	$timeout( function(){ $scope.checkFhStatus(rmiId, attempt, opt); }, 7000 );
            } else {
		hideLoader();
		showMessage('Download Status', "File handler is not running. Please check.", 'error');
            }
	}
	},
        function myError(response) {
            
                 showLoader( 'Oops! Try again after sometimes.' );
                    
	});		
        
    };  
});
     